#!/usr/bin/env python3
"""Frozen owned worker-1 legacy progress-write fault; never a migration.
Use fault-off with the same seed before cleanup. No arbitrary SQL targets.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import signal
import subprocess
import sys
import threading
import time
import tomllib
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, ProxyHandler, Request
import uuid


REPOSITORY = Path(__file__).resolve().parents[3]
ENDPOINT = "/api/cleanup-expired-onboardings"
EXPIRED_AT = datetime(2000, 1, 1, 12, tzinfo=timezone.utc)
EXPECTED_KEYS = {"expiredCompleted0", "expiredCancelled", "recentCompleted", "recentCancelled",
                 "nullCompleted", "nullCancelled", "active", "foreignRecent"}


class Blocked(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Blocked(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def public_error(error):
    return {"error_type": type(error).__name__,
            "message": str(error) if isinstance(error, Blocked) else "Private command/configuration diagnostics withheld."}


def decode_json_values(stdout):
    """psql rows are complete JSON values; json_agg may put newlines inside one."""
    decoder = json.JSONDecoder()
    values = []
    cursor = 0
    while cursor < len(stdout):
        while cursor < len(stdout) and stdout[cursor].isspace():
            cursor += 1
        if cursor == len(stdout):
            break
        value, cursor = decoder.raw_decode(stdout, cursor)
        values.append(value)
        if cursor < len(stdout) and not stdout[cursor].isspace():
            raise json.JSONDecodeError("Expected whitespace between JSON values", stdout, cursor)
    return values


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regular(value):
    path = Path(value).absolute()
    require(path.resolve() == path and path.is_file() and not path.is_symlink(),
            "Input must be a real regular file without symlink ancestors.")
    require(path.stat().st_uid == os.getuid(), "Input must belong to the current user.")
    return path


def read_json(path):
    return json.loads(regular(path).read_text())


def uid(value):
    require(isinstance(value, str), "Seed ID must be a UUID string.")
    require(str(uuid.UUID(value)) == value, "Seed ID must be a canonical lowercase UUID.")
    return value


def literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def instant(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        # Preserve the original redirect status/body as evidence; never follow it.
        return None


def http(request, timeout):
    opener = build_opener(ProxyHandler({}), NoRedirect())
    try:
        response = opener.open(request, timeout=timeout)
    except HTTPError as error:
        response = error
    with response:
        return response.status, {key.lower(): value for key, value in response.headers.items()}, response.read(1048576).decode("utf-8", errors="replace")


class Probe:
    def __init__(self, args):
        evidence = Path(args.evidence).absolute()
        require(evidence.resolve() == evidence, "Evidence directory must not have symlink ancestors.")
        evidence.mkdir(parents=True, exist_ok=True, mode=0o700)
        require(evidence.is_dir() and evidence.stat().st_uid == os.getuid(), "Evidence directory is not owned.")
        self.run = evidence / (args.mode + "-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
        self.run.mkdir(mode=0o700)
        self.save("input.json", {"mode": args.mode, "transition": args.transition,
                                 "session": str(Path(args.session).absolute()), "seed": str(Path(args.seed).absolute()),
                                 "repository": str(REPOSITORY), "probe_sha256": sha(Path(__file__)), "at": stamp()})
        module_path = REPOSITORY / "scripts/verification/environment.py"
        spec = importlib.util.spec_from_file_location("d15_owned_environment", module_path)
        environment = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(environment)
        self.session = environment.private_session(args.session)
        expected = Path.home() / ".local/state/trooptotask-verification" / hashlib.sha256(str(REPOSITORY).encode()).hexdigest()[:16] / "worker-1"
        require(self.session == expected, "Only this checkout's exact worker-1 session is allowed.")
        state, self.workdir, self.environment = environment.owned(self.session)
        require(state["repository"] == str(REPOSITORY), "Provider belongs to a different checkout.")
        status = environment.status(self.session)
        self.container = "supabase_db_" + state["project"]
        records = environment.containers(state, self.workdir, self.environment)
        matches = [item for item in records if item["Name"] == "/" + self.container and item["State"]["Running"]]
        require(len(matches) == 1, "Exact owned database container is not running.")
        self.project = state["project"]
        self.worker = read_json(self.session / "session.json")
        require(self.worker.get("repository") == str(REPOSITORY) and self.worker.get("worker") == "1"
                and self.worker.get("phase") == "running", "Worker-1 is not running for this checkout.")
        supervisor = self.worker["supervisor"]
        require(type(supervisor["pid"]) is int and supervisor["pid"] > 0, "Invalid supervisor identity.")
        proc = Path("/proc") / str(supervisor["pid"])
        stat = (proc / "stat").read_text()
        current_start = stat[stat.rfind(")") + 2:].split()[19]
        require(current_start == str(supervisor["start"]) and (proc / "cmdline").read_bytes().decode() == supervisor["command"],
                "Owned supervisor was replaced.")
        origin = urlsplit(self.worker["origin"])
        require(origin.scheme == "http" and origin.hostname == "127.0.0.1" and origin.port
                and not origin.username and not origin.password and origin.path in ("", "/")
                and not origin.query and not origin.fragment, "App origin is not owned loopback HTTP.")
        config = tomllib.loads((self.workdir / "supabase/config.toml").read_text())
        require(config["auth"]["site_url"] == self.worker["origin"], "App origin differs from the owned provider configuration.")
        port = self.worker["controlPort"]
        require(type(port) is int and 0 < port < 65536, "Invalid owned control port.")
        self.save("doctor-request.json", {"method": "POST", "url": f"http://127.0.0.1:{port}",
                                          "body": {"command": "doctor"}, "authorization": "owned token withheld"})
        code, headers, body = http(Request(f"http://127.0.0.1:{port}", data=b'{"command":"doctor"}', method="POST",
                                          headers={"Authorization": "Bearer " + self.worker["token"], "Content-Type": "application/json"}), 30)
        doctor = json.loads(body)
        self.save("doctor-result.json", {"http_status": code, "authenticated": headers.get("x-t2t-session") == self.worker["id"],
                                         "status": doctor.get("status"), "code": doctor.get("code")})
        require(code == 200 and headers.get("x-t2t-session") == self.worker["id"] and doctor.get("status") == "PASS",
                "Owned authenticated doctor did not pass; refusing a stale/unavailable worker.")
        seed_path = regular(args.seed)
        self.seed = read_json(seed_path)
        ledger_path = regular(self.session / "verify-trooptotask-owned.json")
        ledger = read_json(ledger_path)
        fixture = read_json(self.session / "fixtures.json")
        require(self.seed.get("kind") == "onboarding-legacy" and re.fullmatch(r"[0-9a-f]{8}", self.seed.get("tag", "")), "Use the recorded onboarding-legacy seed.")
        require(len(self.seed.get("packets", [])) == 1 and len(self.seed.get("progress", [])) == 3, "Use the fixed legacy cohort.")
        self.org = uid(fixture["ids"]["orgA"])
        self.packet = self.seed["packets"][0]
        self.packet_id = uid(self.packet["id"])
        require(self.packet["organization_id"] == self.org and self.packet["template_id"] is None and self.packet["status"] == "in_progress", "Use the original null-template seed capture.")
        for table, rows in (("personnel_onboardings", self.seed["packets"]), ("onboarding_step_progress", self.seed["progress"])):
            for row in rows:
                require(row["organization_id"] == self.org, "Legacy seed must be Organization A.")
                uid(row["id"])
                require(any(entry.get("kind") == self.seed["kind"] and entry.get("tag") == self.seed["tag"] and entry.get("table") == table and entry.get("organization") == "orgA" and row["id"] in entry.get("ids", []) for entry in ledger.get("seeded", [])), "Seed ID not in this worker's ledger.")
        self.target = next(row for row in self.seed["progress"] if row["step_name"] == "Orientation" and row["step_type"] == "checkbox")
        self.target_id = uid(self.target["id"])
        require(all(row["onboarding_id"] == self.packet_id and row["template_step_id"] is None and row["active"] is True for row in self.seed["progress"]), "Use exact original legacy progress.")
        self.function = "t2t_d15_legacy_write_fault_" + self.seed["tag"]
        self.marker = "t2t-d15 project=" + self.project + " seed=" + self.target_id
        self.save("ownership.json", {"provider": status, "worker": "1", "supervisor_identity_matches": True, "container": self.container, "container_id": matches[0]["Id"], "seed_sha256": sha(seed_path), "ledger_sha256": sha(ledger_path), "target": self.target, "packet": self.packet})
        self.command = ["docker", "exec", "-i", "-e", "PGPASSWORD=postgres", self.container, "psql", "-X", "-q", "-A", "-t", "-U", "supabase_admin", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]

    def save(self, name, value):
        descriptor = os.open(self.run / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "w") as output:
            json.dump(value, output, indent=2)
            output.write("\n")

    def plan(self, name, sql):
        path = self.run / (name + ".sql")
        if path.exists():
            require(path.read_text() == sql, "A recorded SQL plan changed within this run.")
        else:
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "w") as output:
                output.write(sql)

    def log(self, name, value):
        descriptor = os.open(self.run / (name + ".outputs.jsonl"), os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "a") as output:
            output.write(json.dumps({"at": stamp(), **value}) + "\n")

    def sql(self, name, sql):
        sql = "SET statement_timeout = '10s'; SET lock_timeout = '3s';\n" + sql
        self.plan(name, sql)
        result = subprocess.run(self.command, input=sql,
                                cwd=self.workdir, env=self.environment, text=True, capture_output=True, timeout=15)
        self.log(name, {"exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr[-4000:]})
        require(result.returncode == 0, "Controlled SQL failed; inspect the run's public SQL/results.")
        return decode_json_values(result.stdout)

    def object_state(self):
        name = literal(self.function)
        return self.sql("fault-state", f"""SELECT json_build_object(
 'function', (SELECT json_build_object('marker', obj_description(p.oid, 'pg_proc')) FROM pg_proc p
              JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public' AND p.proname = {name} AND p.pronargs = 0),
 'trigger', (SELECT json_build_object('marker', obj_description(t.oid, 'pg_trigger')) FROM pg_trigger t
             WHERE t.tgrelid = 'public.onboarding_step_progress'::regclass AND t.tgname = {name} AND NOT t.tgisinternal),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger t WHERE t.tgrelid = 'public.onboarding_step_progress'::regclass
                         AND t.tgname LIKE 't2t_d15_legacy_write_fault_%' AND NOT t.tgisinternal));
""")[0]

    def remove_fault(self):
        state = self.object_state()
        require(all(item is None or item.get("marker") == self.marker for item in (state["function"], state["trigger"])),
                "Fault object ownership differs; refusing to drop it.")
        self.sql("fault-remove", f"""BEGIN;
DROP TRIGGER IF EXISTS {self.function} ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.{self.function}();
COMMIT;
SELECT json_build_object('event', 'fault-remove-committed');
""")
        after = self.object_state()
        require(after["function"] is None and after["trigger"] is None, "Fault cleanup did not remove both owned objects.")
        return after

    def snapshot(self, name):
        packet_ids = ",".join(literal(row["id"]) + "::uuid" for row in self.seed["packets"])
        progress_ids = ",".join(literal(row["id"]) + "::uuid" for row in self.seed["progress"])
        return self.sql(name, f"""SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ({packet_ids})) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ({progress_ids})) s), '[]'::json));
""")[0]

    def fault_on(self):
        before = self.snapshot("before")
        require(before["packets"][0]["template_id"] is None, "Use a fresh unassigned legacy packet.")
        expected = {row["id"]: row for row in self.seed["progress"]}
        require(len(before["progress"]) == 3 and all(all(row.get(key) == value for key, value in expected[row["id"]].items()) for row in before["progress"]), "Legacy progress changed before fault install.")
        current = self.object_state()
        require(current["function"] is None and current["trigger"] is None and current["probe_trigger_count"] == 0, "An owned fault already exists; remove it first.")
        self.sql("fault-install", f"""BEGIN;
CREATE FUNCTION public.{self.function}() RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $d15$
BEGIN
 IF NEW.id = {literal(self.target_id)}::uuid AND NEW.organization_id = {literal(self.org)}::uuid AND NEW.onboarding_id = {literal(self.packet_id)}::uuid THEN
  RAISE EXCEPTION USING ERRCODE = 'P0001', MESSAGE = 't2t-d15 intentional owned legacy progress fault';
 END IF;
 RETURN NEW;
END;
$d15$;
COMMENT ON FUNCTION public.{self.function}() IS {literal(self.marker)};
CREATE TRIGGER {self.function} BEFORE INSERT OR UPDATE ON public.onboarding_step_progress FOR EACH ROW EXECUTE FUNCTION public.{self.function}();
COMMENT ON TRIGGER {self.function} ON public.onboarding_step_progress IS {literal(self.marker)};
COMMIT;
SELECT json_build_object('event', 'owned-legacy-fault-installed');
""")
        return self.object_state()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["fault-on", "fault-off"])
    parser.add_argument("--session", required=True)
    parser.add_argument("--seed", required=True)
    parser.add_argument("--evidence", required=True)
    args = parser.parse_args()
    args.transition = None
    try:
        probe = Probe(args)
        result = probe.fault_on() if args.mode == "fault-on" else probe.remove_fault()
        probe.save("result.json", result)
        print(json.dumps({"mode": args.mode, "run": str(probe.run), "result": result}))
    except Exception as error:
        print(json.dumps(public_error(error)))
        sys.exit(1)
