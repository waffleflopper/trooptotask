#!/usr/bin/env bash
# usage: rows.sh NAME DESC -> read-only affected table rows
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
F='() => Array.from(document.querySelectorAll("#training-affected-soldiers tbody tr")).map(r=>Array.from(r.cells).map(c=>c.textContent.trim().replace(/\s+/g," ")).join("|"))'
J=$(python3 -c 'import json,sys;print(json.dumps({"pageId":int(sys.argv[2]),"function":sys.argv[1]}))' "$F" "$P")
MAXOUT=12000 $E/t.sh "$1" "READ-ONLY affected rows: $2" evaluate_script "$J" | python3 $E/jx.py
