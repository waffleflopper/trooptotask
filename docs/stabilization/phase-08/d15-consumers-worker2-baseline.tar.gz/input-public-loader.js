async () => {
 const path=location.pathname.replace(/\/$/,'')+'/__data.json';
 const response=await fetch(path,{redirect:'manual'});
 const text=await response.text();
 const records=text.split('\n').filter(Boolean).map(line=>JSON.parse(line));
 const markers=[];const onboardings=[];
 const decode=(data,index,depth=0)=>{if(depth>15)throw Error('Unexpected business data depth');if(index<0)return null;const v=data[index];if(v===null||typeof v!=='object')return v;if(Array.isArray(v))return v.map(x=>decode(data,x,depth+1));return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,decode(data,x,depth+1)]));};
 for(const record of records){
  const datasets=[record.data,...(record.nodes??[]).map(n=>n?.data)].filter(Array.isArray);
  for(const data of datasets)for(const value of data){
   if(value&&typeof value==='object'&&!Array.isArray(value)){
    if(Object.hasOwn(value,'activeOnboardingPersonnelIds'))markers.push(decode(data,value.activeOnboardingPersonnelIds));
    if(Object.hasOwn(value,'onboardings')){
     const packets=decode(data,value.onboardings);
     if(Array.isArray(packets))onboardings.push(packets.map(p=>({id:p.id,personnelId:p.personnelId,templateId:p.templateId,status:p.status,startedAt:p.startedAt,completedAt:p.completedAt,cancelledAt:p.cancelledAt,steps:p.steps})));
    }
   }
  }
 }
 return {method:'GET',path,status:response.status,markerArrays:markers,onboardingArrays:onboardings,projection:'public business fields only; full loader body not retained'};
}
