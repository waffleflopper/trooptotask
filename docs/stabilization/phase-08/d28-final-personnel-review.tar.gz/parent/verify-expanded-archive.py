import argparse,hashlib,json,tarfile,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('scratch',type=Path);a=p.parse_args()
out=Path(tempfile.mkdtemp(prefix='expanded-archive-',dir=a.scratch))
with tarfile.open(a.archive) as t:
    assert all(x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts for x in t.getmembers())
    t.extractall(out,filter='data')
inv=json.loads((out/'inventory.json').read_text())
entries=inv if isinstance(inv,list) else inv['payloads']
assert {x['path'] for x in entries}=={x.relative_to(out).as_posix() for x in out.rglob('*') if x.is_file() and x.relative_to(out).as_posix()!='inventory.json'}
for item in entries:
    b=(out/item['path']).read_bytes()
    assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256'],item['path']
print(json.dumps({'path':str(a.archive),'sha256':hashlib.sha256(a.archive.read_bytes()).hexdigest(),'payloads':len(entries),'freshExtract':str(out),'exactSetAndHashes':'PASS'},indent=2))
