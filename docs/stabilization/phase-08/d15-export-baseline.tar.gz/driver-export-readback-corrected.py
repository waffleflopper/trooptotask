from drive import *
import hashlib,collections
TABLES=['personnel_onboardings','onboarding_step_progress','personnel_trainings']
KEYS={'personnel_onboardings':'personnelOnboardings','onboarding_step_progress':'onboardingStepProgress'}
def save(name,value): (E/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
def rows(table,org,tag):return control(['rows',table,org],tag)['rows']
def byid(rows):return {r['id']:r for r in rows}
def readset(tag,tables=TABLES+['data_exports']):
 return {(o,t):rows(t,o,tag+'-'+t+'-'+o) for o in ['orgA','orgB'] for t in tables}
def seeded():return {(o,t):json.loads((E/('seeded-'+t+'-'+o+'.json')).read_text())['rows'] for o in ['orgA','orgB'] for t in TABLES}
def unchanged(tag):
 now=readset(tag,TABLES);old=seeded();assert all(byid(now[k])==byid(old[k]) for k in old),tag
 save(tag+'-comparison',{'result':'PASS','scope':'Complete packet/progress fields including timestamps and selected Training fields in A/B','rowCounts':{o:{t:len(now[o,t]) for t in TABLES} for o in ['orgA','orgB']}})
def button(page,name,tag):
 s=snap(page,tag+'-before');click(page,uid(s,'button "'+name+'"'),tag)
def setup():
 for cmd,tag in [('doctor','doctor-initial'),('tools','native-tool-schemas')]:
  args=['npm','run','--silent','verify:app','--',cmd,'--worker','1'];save(tag+'-command',args);r=subprocess.run(args,text=True,capture_output=True);(E/(tag+'.json')).write_text(r.stdout);(E/(tag+'-stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stderr
 fixture=control(['fixture'],'fixture');control(['rows','organization_memberships','orgA','id',fixture['ids']['orgOwnerMembership']],'owner-membership');readset('original');control(['seed','onboarding-history'],'history-seed');control(['seed','onboarding-legacy'],'legacy-seed');readset('seeded')
 actor=control(['actor','orgOwner','home'],'owner-actor');snap(actor['pageId'],'owner-home');screen(actor['pageId'],'owner-home');save('pages',{'owner':actor['pageId']})
 print('Owned setup, exact before rows and normal owner sign-in captured.',flush=True)
def compare_json(tag):
 p=json.loads((E/(tag+'.json')).read_text());expected=seeded();fixture=json.loads((E/'fixture.json').read_text());assert p['organizationId']==fixture['ids']['orgA']
 results={}
 for table,key in KEYS.items():
  a=expected['orgA',table];b=expected['orgB',table];assert byid(p[key])==byid(a),(table,'raw top-level');assert p[key]==p['sections'][key]
  assert not set(byid(b))&set(byid(p[key]));inv=[x for x in p['sectionInventory'] if x['key']==key];assert len(inv)==1 and inv[0]['table']==table and inv[0]['rowCount']==len(a)
  results[key]={'rows':len(a),'completeSavedFields':True,'topLevelMatchesSection':True,'foreignRowsAbsent':True,'inventory':inv[0]}
 save(tag+'-comparison',{'result':'PASS','sections':results,'savedTrainingNotRecomputed':True})
def cell(value):return json.dumps(value,separators=(',',':'),ensure_ascii=False) if isinstance(value,(dict,list)) else value
def human(key):return re.sub(r'\b\w',lambda m:m[0].upper(),key.replace('_',' '))
def compare_workbook(tag,json_tag):
 file=str((E/(tag+'.xlsx')).relative_to(ROOT));p=json.loads((E/(json_tag+'.json')).read_text());result={}
 for table,key in KEYS.items():
  title={'personnel_onboardings':'Raw - Personnel Onboardings','onboarding_step_progress':'Raw - Onboarding Step Progress'}[table]
  book=control(['workbook',file,title],tag+'-'+table+'-sheet');headers=book['headers'];a=seeded()['orgA',table];assert set(headers)=={human(k) for r in a for k in r},(table,headers)
  actual=[]
  for values in book['rows']:actual.append(dict(zip(headers,values+[None]*(len(headers)-len(values)))))
  expected=[{human(k):cell(v) for k,v in r.items()} for r in a];assert {r['Id']:r for r in actual}=={r['Id']:r for r in expected},(table,actual,expected)
  result[key]={'rows':len(actual),'allHeadersAndSavedCellsMatch':True}
 book=control(['workbook',file,'Onboarding Progress'],tag+'-readable-sheet');assert book['headers']==['Person','Status','Started At','Completed At','Cancelled At']
 labels={r['id']:' '.join(str(x) for x in [r.get('rank'),str(r['last_name'])+',',r.get('first_name')] if x) for r in p['personnel']}
 expected=[[labels[r['personnel_id']],r['status'],r['started_at'],r['completed_at'],r['cancelled_at']] for r in p['personnelOnboardings']]
 observed=[r+[None]*(5-len(r)) for r in book['rows']];assert sorted(observed,key=str)==sorted(expected,key=str),(observed,expected)
 book=control(['workbook',file,'Export Inventory'],tag+'-inventory-sheet');keycol=book['headers'].index('JSON Key');countcol=book['headers'].index('Rows')
 for table,key in KEYS.items():assert [r[countcol] for r in book['rows'] if r[keycol]==key]==[len(seeded()['orgA',table])]
 save(tag+'-comparison',{'result':'PASS','raw':result,'readableRows':len(observed),'readableSavedLabelsStatusDatesMatch':True,'inventoryCountsMatch':True,'savedTrainingNotRecomputed':True})
def lifecycle(before,tag,artifact):
 now=readset(tag+'-after-lifecycle',['data_exports']);added=[r for r in now['orgA','data_exports'] if r['id'] not in byid(before['orgA','data_exports'])];assert len(added)==1,added
 r=added[0];owner=json.loads((E/'owner-membership.json').read_text())['rows'][0]['user_id'];assert r['requested_by']==owner and r['status']=='completed' and r['file_size_bytes']==artifact['bytes'] and r['completed_at'] and r['created_at'],r
 assert byid(now['orgB','data_exports'])==byid(before['orgB','data_exports']);save(tag+'-lifecycle-comparison',{'result':'PASS','added':r,'foreignUnchanged':True,'downloadSha256':artifact['sha256']})
def download(page,fmt,tag):
 before=readset(tag+'-before-lifecycle',['data_exports']);family='export' if fmt=='json' else 'export-excel';control(['network','arm-observe',str(page),family],tag+'-network-arm');control(['export','arm',str(page)],tag+'-capture-arm');button(page,'Export JSON' if fmt=='json' else 'Export Excel',tag+'-click')
 s=snap(page,tag+'-after');assert 'Export downloaded successfully.' in s,s;screen(page,tag+'-after');network=control(['network','state',str(page)],tag+'-network-state');assert len(network['calls'])==1 and network['calls'][0]['method']=='POST' and network['calls'][0]['status']==200,network
 capture=control(['export','state',str(page)],tag+'-capture-state');assert capture['captured'];extension='json' if fmt=='json' else 'xlsx';artifact=control(['export','save',str(page),str((E/(tag+'.'+extension)).relative_to(ROOT))],tag+'-saved-artifact')
 assert artifact['filename'].endswith('.'+extension) and artifact['bytes']>0 and hashlib.sha256((E/(tag+'.'+extension)).read_bytes()).hexdigest()==artifact['sha256'];assert 'filename="'+artifact['filename']+'"' in network['calls'][0]['contentDisposition'];assert network['calls'][0]['contentType']=='application/json' if fmt=='json' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'==network['calls'][0]['contentType']
 lifecycle(before,tag,artifact);unchanged(tag+'-saved-packets');control(['network','restore',str(page)],tag+'-network-restore');control(['export','restore',str(page)],tag+'-capture-restore')
 return artifact
def downloads():
 page=json.loads((E/'pages.json').read_text())['owner'];download(page,'json','owner-json');compare_json('owner-json');download(page,'excel','owner-excel');compare_workbook('owner-excel','owner-json');native('navigate_page',{'pageId':page,'type':'reload'},'owner-exports-reload');s=snap(page,'owner-exports-reloaded');assert 'button "Export JSON"' in s and 'button "Export Excel"' in s;unchanged('owner-after-reload');print('Native JSON and Excel, complete saved fields, readable progress, inventory, lifecycle and reload pass.',flush=True)
def denials():
 page=control(['actor','onboardingConfigure','settings/exports'],'onboarding-only-exports-actor')['pageId'];s=snap(page,'onboarding-only-exports-denied');assert 'Export JSON' not in s and ('permission' in s.lower() or 'Access restricted' in s),s;screen(page,'onboarding-only-exports-denied')
 cases=[(page,'orgA','onboarding-only',403),(json.loads((E/'pages.json').read_text())['owner'],'orgB','foreign-owner',404)]
 for page,org,tag,status in cases:
  before=readset(tag+'-before')
  for fmt in ['json','excel']:
   r=control(['export','request',str(page),org,fmt],tag+'-'+fmt+'-ordinary-post');assert r['status']==status and r['body'] and r['contentDisposition'] is None,r
  after=readset(tag+'-after');assert all(byid(before[k])==byid(after[k]) for k in before);save(tag+'-comparison',{'result':'PASS','statuses':[status,status],'completePacketProgressAndSelectedTrainingAndExportRecordsUnchanged':True})
 print('Ordinary valid POST denials and Settings denial pass with unchanged A/B saved rows and export records.',flush=True)
def recovery():
 page=json.loads((E/'pages.json').read_text())['owner'];before=readset('failed-export-before');control(['network','arm-fail',str(page),'export'],'failure-network-arm');control(['export','arm',str(page)],'failure-capture-arm');button(page,'Export JSON','failure-click');s=snap(page,'failure-visible');assert 'Export failed. Please try again.' in s and 'Export downloaded successfully.' not in s,s;screen(page,'failure-visible');r=control(['network','state',str(page)],'failure-network-state');assert len(r['calls'])==1 and r['calls'][0]['status']==503;r=control(['export','state',str(page)],'failure-capture-state');assert not r['captured'];after=readset('failed-export-after');assert all(byid(before[k])==byid(after[k]) for k in before);save('failure-comparison',{'result':'PASS','client503':True,'noBlob':True,'savedPacketProgressTrainingAndExportRecordsUnchanged':True,'providerFailureClaim':False});control(['network','restore',str(page)],'failure-network-restore');control(['export','restore',str(page)],'failure-capture-restore');download(page,'json','retry-json');compare_json('retry-json');readset('final');print('Visible client failure/no artifact/no saved effects and real native retry pass.',flush=True)
if __name__=='__main__':globals()[os.environ['D15_ACTION']]()
