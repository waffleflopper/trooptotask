#!/usr/bin/env bash
# usage: m.sh LABEL [PAGE]  -> read-only measurement of rendered forecast marks via native evaluate_script
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7
label=$1; page=${2:-2}
args=$(jq -n --rawfile f "$E/driver/measure.js" --argjson p $page --arg fp "$E/measure/$label.json" '{pageId:$p,function:$f,filePath:$fp}')
"$E/driver/d.sh" "measure-$label" -- npm run --silent verify:app -- tool evaluate_script "$args" --worker 1 >/dev/null
echo "measure/$label.json"
