(() => {
	if (window.__x4) return 'already';
	const x = (window.__x4 = { blobs: [], anchors: [], responses: [], orig: { createObjectURL: URL.createObjectURL, click: HTMLAnchorElement.prototype.click, fetch: window.fetch } });
	URL.createObjectURL = function (obj) { const u = x.orig.createObjectURL.call(URL, obj); if (obj instanceof Blob) x.blobs.push({ url: u, blob: obj, size: obj.size, type: obj.type, t: new Date().toISOString() }); return u; };
	HTMLAnchorElement.prototype.click = function () { if (this.href?.startsWith('blob:')) { x.anchors.push({ download: this.download, href: 'blob:<captured>', t: new Date().toISOString() }); return; } return x.orig.click.call(this); };
	window.fetch = function (input, init) { const url = typeof input === 'string' ? input : input.url; const p = x.orig.fetch.call(this, input, init); if (/\/export/.test(url)) p.then((r) => x.responses.push({ url: url.replace(location.origin, ''), method: init?.method || 'GET', status: r.status, contentType: r.headers.get('content-type'), contentDisposition: r.headers.get('content-disposition'), cacheControl: r.headers.get('cache-control'), contentLength: r.headers.get('content-length') })); return p; };
	return 'export hook installed';
})()
