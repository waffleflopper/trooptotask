import json,re
from pathlib import Path
RAW=Path('.verification/evidence/verify-trooptotask/workspace-final')
checks=[]
def check(name,passed,**evidence):
 checks.append({'name':name,'passed':bool(passed),**evidence})
 if not passed: raise AssertionError(name)
def text(name): return (RAW/name).read_text()
def script(name):
 obj=json.loads(text(name))
 block='\n'.join(item.get('text','') for item in obj['content'])
 return json.loads(re.search(r'```json\n(.*?)\n```',block,re.S)[1])
def rows(name): return re.findall(r'^\s*uid=\S+ row "(Open [^"]+)"',text(name),re.M)
full=['Open SPC Able, Synthetic','Open SPC Baker, Synthetic','Open SPC Unassigned, Synthetic']
for base,expected in [('manager-roster',full),('viewer-roster',full),('scoped-roster',[full[0]]),('personnelEmpty-roster',[]),('foreign-roster',['Open SPC Foreign, Synthetic']),('switch-A-roster',full),('switch-to-B-after',['Open SPC Foreign, Synthetic']),('switch-B-reloaded',['Open SPC Foreign, Synthetic']),('switch-to-A-after',full),('switch-A-reloaded',full)]:
 name=base+'.txt';check('native roster '+base,rows(name)==expected,artifact=name,expected=expected,observed=rows(name))
for actor,expected in [('viewer',full),('scoped',[full[0]]),('personnelEmpty',[]),('foreign',['Open SPC Foreign, Synthetic'])]:
 name=actor+'-reloaded.txt';check('reload roster '+actor,rows(name)==expected,artifact=name,expected=expected,observed=rows(name))
manage=['Add Person','Manage Groups','Archive','Edit']
for name in ['manager-roster.txt','switch-A-roster.txt','switch-to-A-after.txt','switch-A-reloaded.txt']:
 buttons=re.findall(r'button "([^"]+)"',text(name));check('management affordances '+name,all(x in buttons for x in manage),artifact=name,required=manage,observed=buttons)
for name in ['viewer-roster.txt','viewer-reloaded.txt','scoped-roster.txt','scoped-reloaded.txt','personnelEmpty-roster.txt','personnelEmpty-reloaded.txt','foreign-roster.txt','foreign-reloaded.txt','switch-to-B-after.txt','switch-B-reloaded.txt']:
 buttons=re.findall(r'button "([^"]+)"',text(name));check('denied management affordances '+name,not any(x in buttons for x in manage) and 'link "Import"' not in text(name) and not any(x.startswith('Archive ') for x in buttons),artifact=name,denied=manage+['Import','Archive Person'],observed=buttons)
check('native search only Able',rows('manager-search-able.txt')==[full[0]],artifact='manager-search-able.txt')
check('manager Group catalog',all(x in text('manager-groups-dialog-after.txt') for x in ['Alpha','Bravo']),artifact='manager-groups-dialog-after.txt')
check('pin persists and moves Bravo first','button "Unpin Bravo"' in text('manager-pin-proof-reloaded.txt') and text('manager-pin-proof-reloaded.txt').index('row "Collapse Bravo"')<text('manager-pin-proof-reloaded.txt').index('row "Collapse Alpha"'),artifacts=['manager-pin-proof.png','manager-pin-proof-reloaded.txt','manager-pin-proof-reloaded.png'])
check('pin restored','button "Pin Bravo"' in text('manager-unpin-proof-reloaded.txt') and 'button "Unpin Bravo"' not in text('manager-unpin-proof-reloaded.txt') and text('manager-unpin-proof-reloaded.txt').index('row "Collapse Alpha"')<text('manager-unpin-proof-reloaded.txt').index('row "Collapse Bravo"'),artifacts=['manager-unpin-proof.png','manager-unpin-proof-reloaded.txt','manager-unpin-proof-reloaded.png'])
rank=script('rank-dom.json');choices=[x['text'].strip() for x in rank['options']]
check('active rank choices and original SPC',choices==['SGT','SPC','PFC','VFY-ACTIVE-A'] and all(x['display']!='none' and x['hidden']!='true' for x in rank['options']) and rank['rankButton'].strip()=='SPC',artifacts=['rank-menu.png','rank-dom.json'],observed=rank)
selected=script('rank-selected.json');check('keyboard rank selection',selected['rankButton'].strip()=='SGT' and selected['listboxOpen'] is False,artifacts=['rank-keyboard-enter.json','rank-selected.json'],observed=selected)
check('rank draft canceled','dialog "Add Personnel"' not in text('manager-rank-cancel-after.txt'),artifact='manager-rank-cancel-after.txt')
for name in ['manager-open-able-after.txt','manager-detail-reloaded.txt']:
 detail=text(name);check('detail context '+name,'heading "SPC Able, Synthetic"' in detail and 'StaticText "Alpha / 68W / Medic"' in detail,artifact=name)
for base,expectedPresence,expectedCatalog in [('manager', [True,True,True,False],[True,True,False]),('viewer',[True,True,True,False],[True,True,False]),('scoped',[True,False,False,False],[True,True,False]),('personnelEmpty',[False,False,False,False],[True,True,False]),('foreign',[False,False,False,True],[False,False,True]),('switch-A',[True,True,True,False],[True,True,False]),('switch-B',[False,False,False,True],[False,False,True]),('switch-A-returned',[True,True,True,False],[True,True,False])]:
 name=base+'-page-data.json';data=script(name);check('actual page-data scope '+base,data['status']==200 and list(data['presence'].values())==expectedPresence and list(data['catalog'].values())==expectedCatalog,artifact=name,expectedPresence=expectedPresence,expectedCatalog=expectedCatalog,observed=data)
(RAW/'native-observation-checks.json').write_text(json.dumps({'boundary':'Saved actual native snapshots/screenshots and read-only authenticated page-data; no app state or handler mutation','checks':checks},indent=2)+'\n')
print(f'{len(checks)} native observation checks PASS')
