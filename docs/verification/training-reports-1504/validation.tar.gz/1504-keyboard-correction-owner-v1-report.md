# 1504 keyboard correction — owner v1 report

Base: HEAD 2e3aea52. Uncommitted; root owns commit, integration and the live rerun. This is not new live acceptance.

## Defect
Live receipt 329 (final-v1 accept): pressing Enter on the detail error's Retry starts a reload. The error unmounts with its button, so `document.activeElement` becomes `body`.

## Decision
Retry now returns focus the same way the first drill-down does. `TrainingReportsPage.svelte` pulls the existing `tick()` → focus `#DETAIL_ID` step into `focusDetail()`. Both `openDetail(scope)` and the new `retryDetail()` call it. The Affected soldiers section (`tabindex=-1`, `aria-busy` while loading) stays mounted during the reload, so focus lands on the region that is updating.
- Focus moves only when the user activates the detail Retry. There is no effect, and paging, page-size and late responses do not move focus.
- `TrainingBriefingSession` is unchanged. Request-id/abort guards, retained previous page and honest range, the 25/100 sizes, table/status types, exports, URL/filters and print are all untouched.
- `TrainingAffectedSoldiersSection.svelte` is unchanged.

## Changed files
- `src/features/training/components/TrainingReportsPage.svelte`
- `src/features/training/components/TrainingReportsPage.test.ts` adds one interaction test. A failed page 2 keeps "Rows 1–25 of 30". Focusing and activating Retry refetches page 2 and focus ends on the Affected soldiers region. The result shows "Rows 26–30 of 30" with no alert.

## Verification (Node 24, TMPDIR/NODE_DISABLE_COMPILE_CACHE as briefed)
- Red without the fix: the new test fails at the `activeElement` assertion (`1504-keyboard-correction-owner-v1/vitest-red-without-fix.log`).
- `npx vitest run src/features/training/components/TrainingReportsPage.test.ts`: 11/11 passed (`vitest-page.log`)
- `npx vitest run src/features/training`: 35 files, 383 tests passed (`vitest-training.log`)
- `npx prettier --check` and `npx eslint` on the touched files: clean (`prettier.log`, `eslint.log`)
- `npm run check`: 0 errors, 0 warnings (`svelte-check.log`)

## Nonblocker dispositions
- V1 (1024 wide, sidebar expanded, grid 839px in a 720px scroll container): this is the designed overflow. The grid is a wide matrix inside a horizontal scroll container, it scrolls at 390, and all widths were judged legible. No change.
- V2 (what-if chips monochrome vs Paper's colored before/after): #1504 only requires the chips to "match the model" (their values). Its only color rule is for the type risk bars (red/amber). The text already carries the before/after values, and acceptance found the Paper structure matched. It's a cosmetic difference, not a requirement violation. No change.

## Remaining risks
- jsdom proves the focus transfer, not real keyboard Enter. The live rerun should repeat receipt 329's step and expect focus on the Affected soldiers region.
- Print/PDF clipping is still unproven until the native transport is repaired. No chart or CSS changes were made.
