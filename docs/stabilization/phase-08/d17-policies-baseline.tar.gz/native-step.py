import json, re, subprocess, sys
from pathlib import Path
run=Path(sys.argv[1]); page=int(sys.argv[2]); label=sys.argv[3]; action=sys.argv[4]
assert run.is_dir() and not (run/(label+'-action.json')).exists()
def tool(name,args,file):
 p=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args),'--worker','1'],capture_output=True,text=True,timeout=60)
 (run/file).write_text(p.stdout)
 if p.returncode: raise RuntimeError(f'{name}: {p.stderr} {p.stdout}')
 return json.loads(p.stdout)
def view(x): return '\n'.join(c.get('text','') for c in x.get('content',[]) if c.get('type')=='text')
x=tool('take_snapshot',{'pageId':page},label+'-before.json')
if action in ['click','fill']:
 role,name=sys.argv[5:7]
 source=view(x)
 if action=='click' and len(sys.argv)>7:
  scope=sys.argv[7]; scope_role,scope_name=scope.split(':',1) if ':' in scope else ('dialog',scope); assert scope_role in ['region','dialog']; lines=source.splitlines(); start=next(i for i,line in enumerate(lines) if scope_role+' '+json.dumps(scope_name) in line); indent=len(lines[start])-len(lines[start].lstrip()); end=next((i for i in range(start+1,len(lines)) if lines[i].strip() and len(lines[i])-len(lines[i].lstrip())<=indent),len(lines)); source='\n'.join(lines[start:end])
 matches=re.findall(r'^\s*uid=(\S+) '+re.escape(role)+' '+re.escape(json.dumps(name))+r'(?:\s|$)',source,re.M)
 if len(matches)!=1: raise RuntimeError(f'Expected one {role} {name}: {matches}\n{view(x)}')
 args={'pageId':page,'uid':matches[0],'includeSnapshot':True}
 if action=='fill':args['value']=sys.argv[7]
 y=tool(action,args,label+'-action.json')
else:
 assert action in ['back','forward','reload','url']
 if action in ['back','forward']:
  y=tool('evaluate_script',{'pageId':page,'function':'() => { history.'+action+'(); return { requested: "'+action+'" }; }'},label+'-action.json')
 else:
  args={'pageId':page,'type':action}
  if action=='url':args['url']=sys.argv[5]
  y=tool('navigate_page',args,label+'-action.json')
z=tool('take_snapshot',{'pageId':page},label+'-after.json')
s=view(z)
print('\n'.join(line for line in s.splitlines() if any(k in line for k in ['RootWebArea','menuitem','dialog','textbox','spinbutton','region','StaticText "Saved"','StaticText "Unsaved','button "Edit"','button "Save','button "Cancel','button "Update','button "Set URL','button "Reset','Organization name updated','role="alert"'])))
