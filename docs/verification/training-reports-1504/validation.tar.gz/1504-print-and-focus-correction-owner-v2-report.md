# #1504 print and focus correction — owner v2 report

Base HEAD f19c699389bba18298af5c0ebfc36bb48aa20a14. Uncommitted; patch at `.verification/1504-print-and-focus-correction-owner-v2/correction.patch`.

## Files changed

- `src/routes/+layout.svelte`: wraps `<Toaster />` in `<div class="contents" data-print-chrome>`. The existing print rule in `app.css` (`body:has([data-print-report='training']) [data-print-chrome] { display: none !important }`) now removes the notifications host while a training brief prints. On screen, `display: contents` adds no box, so the toaster section, fixed `ol`, hotkey, and aria-label region are unchanged. No change to `app.css` or `sonner.svelte`.
- `src/features/training/components/TrainingAffectedSoldiersSection.svelte:62`: the guard now accepts `pager.disabled || !pager.isConnected`. The `activeElement` guard (pager or BODY) and the one-shot `pager = null` are unchanged.
- `src/features/training/components/TrainingReportsPage.test.ts`: added two tests that share one delayed-response helper:
  - Positive: focused Next requests page 2, and the held response comes back as page 1 of 1 (20 rows), which removes the nav. Focus moves to the Affected soldiers region.
  - Negative: same delayed response, but the user moves focus to the "100 rows per page" radio before the response arrives. Focus stays on the radio.

## Response to the all-participant census

I looked at the actual v3 page images myself. The short PDF has page 1 landscape with the brief, then a blank portrait page 2. The long PDF has five complete landscape pages, then a blank portrait page 6. The extra page uses the default page size (portrait), not `training-brief`. That points to an in-flow box whose `page` is `auto`, placed after the named-page content. Overflow continuing from the report would have stayed landscape.

In-flow print participants, in order: `body > div(display:contents)`, which contains three things:
1. `.app`: BannerStack (`data-print-chrome`, hidden) and the sidebar wrapper. The wrapper holds the sidebar (hidden), the inset header (`data-print-chrome`, hidden) and `main#main-content`, which contains the report root (`page: training-brief`). `.app` therefore starts and ends with the report, so its start and end page are `training-brief`. The leave-org dialog, feedback and What's New are conditional, and they portal or position as overlays only when open.
2. The svelte-sonner static `<section>`: in flow, block-level, `page: auto`, so it uses the default page. Changing named page between `.app` and this section is a forced break, and the section is placed on a new default (portrait) page, even though it is 0px tall. **This is the only in-flow participant after the report.**
3. `#svelte-announcer`: absolutely positioned, out of flow, so it creates no class A break point. `<script>` is `display: none`.

This also explains the history:
- v2 (580c24fa): only wrapper, inset and main were reset. `.app` kept its scoped `height: 100vh`, so the report overflowed `.app` and the section sat at y=100vh on page 1.
  - Long v2: the forced break moved the section onto the already-existing overflow page 2, so there was no extra page.
  - Short v2: no overflow page existed, so a new portrait page was created.
- v3 (31024cb0): the `:has` ancestor reset let `.app` grow to the full content height. The section then followed page 5, and the forced break created portrait page 6. That is why long output regressed.

The failed premise ("only report ancestors produce the page") is confirmed as failed. The ancestor height reset was not the cause and is not the fix.

**Kept the scoped ancestor reset:** it is not compensating code for the blank page. It is what makes `.app` (100vh flex), html/body and the shell containers hold the report in flow instead of letting it overflow a viewport-sized box. Without it, print would depend on Chrome fragmenting overflow from a fixed-height box. I added no new height or `@page` override.

**Diagnosis confidence: high from source and all four PDFs (v2 and v3, short and long), but UNPROVEN LIVE.** I have no browser, print-media census or rendered PDF on this patch.

## Checks (Node 24, synthetic env from .env.example)

- Red: `focus-red.log`. The positive test fails because activeElement is `<body>`. The negative test passes.
- Green: `focus-green.log`. `TrainingReportsPage.test.ts` passes 14 of 14.
- `prettier --check` on the 3 files passes (`format.log`). `eslint` on the 3 files has 0 problems (`lint.log`).
- `npm run check`: 0 errors, 0 warnings (`check.log`).
- I did not run the full 7 gates or the build (root owns those). I added no print or geometry CSS-string test.

## Source findings

- Addressed: P2 independent review, `TrainingAffectedSoldiersSection.svelte:62` detached pager. Reproduced red, then green, with a moved-focus negative case. Settled behaviors kept: Next to last and Previous to first, radio, horizon, Retry. The existing tests still pass.
- Addressed in source: the trailing blank portrait print page (toaster section after the named page).
- Unresolved / not touched: the f19c AuthContext wording (root-owned). No other scope additions were needed.

## Fresh print obligations for root's live round

1. Native print to PDF of the empty Bravo + Targeted brief: exactly 1 page, landscape 792×612, with the content from v3 page 1.
2. Native print to PDF of the loaded 25-row detail brief: exactly 5 landscape pages with no trailing portrait page, and all 25 rows legible.
3. Visually check that no notification or toast appears in the PDF. If possible, also print once while a toast is visible.
4. Optional print-media census: in print emulation, confirm that `section[aria-label^="Notifications"]` is not rendered (display none via its ancestor) and that nothing in flow follows `[data-print-report='training']`.
5. Screen regression: after any action, toasts still appear bottom-right, and the Alt+T hotkey still focuses the Notifications region. Another page's print (not training) is unchanged, because the rule is scoped to `:has([data-print-report='training'])`.
6. Keyboard, live: page Next with a held response that shrinks to one page (if a fixture allows it). Focus should land on the Affected soldiers region, not BODY.
