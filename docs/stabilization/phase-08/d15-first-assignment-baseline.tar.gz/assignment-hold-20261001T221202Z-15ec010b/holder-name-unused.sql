SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('unused', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = 't2t-d15-hold-352a72c5b46b40e687790edc6b568c8d'));
