SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 870 AND backend_start = '2026-10-02 03:19:05.19175+00'::timestamptz AND application_name = 't2t-d15-overlap-15eb8911126b4e9e97e11374a0aa8397' AND usename = 'supabase_admin' AND datname = 'postgres';
