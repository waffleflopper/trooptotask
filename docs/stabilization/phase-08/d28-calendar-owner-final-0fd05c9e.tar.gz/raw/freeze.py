import pathlib,subprocess,hashlib,json,sys,datetime,os
root=pathlib.Path.cwd();dest=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
names=sorted(set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0'))-{''})
rows=[];aggregate=hashlib.sha256()
for name in names:
 vm=name=='.agents/skills/verify-trooptotask/SKILL.md' or name.startswith('.agents/skills/verify-trooptotask/features/') and name.endswith('.md')
 if name.endswith('.md') and not vm or pathlib.Path(name).name.startswith('.env'):continue
 b=(root/name).read_bytes();rows.append({'path':name,'bytes':len(b),'sha256':sha(b)});aggregate.update(name.encode()+b'\0'+b+b'\0')
deps=[];dep=root/'node_modules';depRoot=dep.resolve()
for current,ds,fs in os.walk(depRoot):
 ds.sort();fs.sort()
 for fn in fs:
  p=pathlib.Path(current)/fn;relative=str(p.relative_to(depRoot))
  if p.is_symlink():deps.append({'path':relative,'symlink':os.readlink(p)})
  else:
   b=p.read_bytes();deps.append({'path':relative,'bytes':len(b),'sha256':sha(b)})
external=[]
for p in [pathlib.Path('/home/waffleflops/.cache/t2t-1376-calendar-owner-next-integration-map.md'),pathlib.Path('/home/waffleflops/.cache/t2t-1376-calendar-provider-final-native-plan.md'),pathlib.Path(__file__),dest/'run.py',dest/'tmp-binding.json',dest/'selected-cases.json',pathlib.Path('/home/waffleflops/.cache/t2t-1376-calendar-provider-final-literal-originals.json')]:
 b=p.read_bytes();external.append({'path':str(p.resolve()),'bytes':len(b),'sha256':sha(b)})
obj={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'candidate':aggregate.hexdigest(),'sources':rows,'dependencies':deps,'nodeModulesResolved':str(depRoot),'external':external}
output=dest/(sys.argv[1]+'.json');assert not output.exists();output.write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:v for k,v in obj.items() if k not in ['sources','dependencies','external']}));print('sources',len(rows),'dependencies',len(deps),'external',len(external))
if sys.argv[1]!='freeze-before':
 before=json.loads((dest/'freeze-before.json').read_text());cmp={k:obj[k]==before[k] for k in ['head','tree','candidate','sources','dependencies','nodeModulesResolved','external']};(dest/'freeze-comparison.json').write_text(json.dumps(cmp,indent=2));print(cmp)
