#!/usr/bin/env python3
"""Fixed final worker-2 Calendar/Training consumer selection; native snapshots select every action."""
import datetime,hashlib,json,os,re,subprocess,sys
from pathlib import Path
os.environ['D15_RUN']='d15-consumers-worker2-final'
ROOT=Path(__file__).resolve().parents[3];assert Path.cwd().resolve()==ROOT
B=ROOT/'.verification/evidence/verify-trooptotask/d15-consumers-worker2-final';B.mkdir(parents=True,exist_ok=True)
COUNT=0
def run(script,*args):
 global COUNT
 COUNT+=1;r=subprocess.run(['python3',str(ROOT/'.verification/tmp/d15-consumers-worker2'/script),*map(str,args)],capture_output=True,text=True)
 if r.returncode:
  p=B/f'final-driving-failure-{COUNT}.json'
  with p.open('x') as f:json.dump({'command':[script,*map(str,args)],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},f,indent=2)
  print(r.stderr,flush=True);raise SystemExit('Driving failure preserved at '+str(p))
 return r.stdout
def ctl(tag,*args):return run('drive.py','control',tag,*args)
def tool(tag,name,args):return run('drive.py','tool',tag,name,json.dumps(args))
def act(mode,page,tag,needle=None):return run('action.py',mode,page,tag,*([needle] if needle else []))
def snapshot(page,tag):
 tool(tag,'take_snapshot',{'pageId':page,'filePath':str((B/(tag+'.txt')).relative_to(ROOT))})
 return (B/(tag+'.txt')).read_text()
def screen(page,tag):tool(tag+'-screen','take_screenshot',{'pageId':page,'filePath':str((B/(tag+'.png')).relative_to(ROOT)),'fullPage':True})
def projection(page,tag,file='public-loader.js'):return tool(tag,'evaluate_script',{'pageId':page,'function':(ROOT/'.verification/tmp/d15-consumers-worker2'/file).read_text(),'waitForStableDom':False})
def rows(stage,tables=('personnel_trainings','personnel_onboardings','onboarding_step_progress')):
 for org in ['orgA','orgB']:
  for table in tables:ctl(stage+'-'+org+'-'+table,'rows',table,org)
def confirm(page,tag,title,button):
 text=snapshot(page,tag+'-before');tail=text.split('alertdialog '+json.dumps(title),1)[1];line=next(l for l in tail.splitlines() if 'button '+json.dumps(button) in l);uid=re.search(r'uid=([^\s]+)',line).group(1)
 tool(tag+'-click','click',{'pageId':page,'uid':uid,'includeSnapshot':True});snapshot(page,tag+'-after');screen(page,tag)
def progress(message):print(message,flush=True)
ctl('fixture','fixture');rows('original',('personnel','groups','personnel_trainings','personnel_onboardings','onboarding_step_progress'))
ctl('consumer-seed','seed','onboarding-consumers');seed=json.loads((B/'consumer-seed-stdout.json').read_text());fixture=json.loads((B/'fixture-stdout.json').read_text())
assert len(seed['packets'])==4 and len(seed['progress'])==11 and len(seed['people'])==1
rows('seeded',('personnel_onboardings','onboarding_step_progress'))
P={}
for role,dest in [('calendarLane','calendar'),('calendarScoped','calendar'),('trainingScopedConfig','training'),('onboardingScoped','onboarding')]:
 ctl('actor-'+role,'actor',role,dest);P[role]=json.loads((B/('actor-'+role+'-stdout.json')).read_text())['pageId']
C=P['calendarLane'];S=P['calendarScoped'];T=P['trainingScopedConfig'];O=P['onboardingScoped'];name=seed['people'][0]['last_name']
for page,label in [(C,'calendar-wide-initial'),(S,'calendar-scoped-initial'),(T,'training-initial'),(O,'onboarding-initial')]:snapshot(page,label);screen(page,label)
for page,label in [(C,'calendar-wide'),(S,'calendar-scoped'),(O,'onboarding')]:projection(page,label+'-loader')
for page,label in [(C,'calendar-wide'),(S,'calendar-scoped')]:projection(page,label+'-dom','calendar-dom.js')
progress('Initial native scope/projections captured; four normal actor pages reused')
act('click',C,'calendar-menu','button "More Calendar actions"');act('click',C,'calendar-off','menuitemcheckbox "Show Onboarding"');act('reload',C,'calendar-off-persisted');projection(C,'calendar-off-dom','calendar-dom.js')
act('click',C,'calendar-on-menu','button "More Calendar actions"');act('click',C,'calendar-on','menuitemcheckbox "Show Onboarding"');act('reload',C,'calendar-on-persisted');projection(C,'calendar-on-dom','calendar-dom.js')
ctl('training-current-observe','network','arm-observe',str(T),'personnel-trainings')
act('click',T,'training-current-open',f'button "{name} Verification Required Training: Not Done"');act('click',T,'training-current-save','button "Save"');run('capture-write.py',T,'training-current-create','POST','personnel-trainings')
act('reload',T,'training-current-persisted');act('reload',O,'onboarding-current-persisted');projection(O,'onboarding-current-loader');rows('after-current')
act('click',O,'onboarding-current-detail',f'button "SC SPC {name}, Synthetic');act('click',O,'onboarding-current-completed','button "Completed 1"');act('click',O,'onboarding-current-detail-close','button "Close"')
act('click',O,'history-current-enter','link "History"');act('click',O,'history-current-companion',f'button "SPC {name}, Synthetic');projection(O,'history-current-loader');act('click',O,'onboarding-current-history-return','link "Onboard"')
run('delete-training-v2.py',T,'training-current-delete','Current');act('reload',O,'onboarding-current-deleted-persisted');projection(O,'onboarding-current-deleted-loader');rows('after-current-delete')
progress('Native current create/delete, active completion and terminal History captured')
act('click',T,'training-expired-open',f'button "{name} Verification Required Training: Not Done"');act('click',T,'training-expired-picker','button "Completion Date"');run('select-expired.py',T,'training-expired-date');act('click',T,'training-expired-save','button "Save"');run('capture-write.py',T,'training-expired-create','POST','personnel-trainings')
act('reload',T,'training-expired-persisted');act('reload',O,'onboarding-expired-persisted');projection(O,'onboarding-expired-loader');rows('after-expired')
act('click',O,'onboarding-expired-detail',f'button "SC SPC {name}, Synthetic');act('click',O,'onboarding-expired-completed','button "Completed 1"');act('click',O,'onboarding-expired-close','button "Close"')
run('delete-training-v2.py',T,'training-expired-delete','Expired');act('reload',O,'onboarding-expired-deleted-persisted');projection(O,'onboarding-expired-deleted-loader');rows('after-expired-delete')
ctl('training-observer-final','network','state',str(T));ctl('training-observer-restore','network','restore',str(T))
progress('Native literal expired create/delete and presence-based completion captured')
ctl('lifecycle-observe','network','arm-observe',str(O),'onboarding')
act('click',O,'lifecycle-cancel-detail',f'button "SC SPC {name}, Synthetic');act('click',O,'lifecycle-cancel-confirm','button "Cancel"');act('click',O,'lifecycle-cancel-save','button "Cancel Onboarding"');run('capture-write.py',O,'lifecycle-cancel','PUT','onboarding');run('marker-load.py','cancelled');rows('after-cancel',('personnel_onboardings','onboarding_step_progress'))
run('reopen.py',O,'lifecycle-reopen-api');run('marker-load.py','reopened');rows('after-reopen',('personnel_onboardings','onboarding_step_progress'))
act('reload',O,'lifecycle-reopened-persisted');act('click',O,'lifecycle-complete-detail',f'button "SC SPC {name}, Synthetic');act('click',O,'lifecycle-complete-warning','button "Mark Complete"');confirm(O,'lifecycle-complete-save','Complete Onboarding','Mark Complete');run('capture-write.py',O,'lifecycle-complete','PUT','onboarding');run('marker-load.py','completed');rows('after-complete')
progress('Native cancel, ordinary API reopen, native warning/complete and fresh Calendar transitions captured')
act('click',O,'history-completed-enter','link "History"')
completed=json.loads((B/'lifecycle-complete.network-response').read_text())['completedAt'];d=datetime.date.fromisoformat(completed[:10]);needle=f'COMPLETED {d.strftime("%b").upper()} {d.day}, {d.year} FINAL PROGRESS'
act('click',O,'history-completed-inactive',needle);act('reload',O,'history-completed-persisted');act('click',O,'history-completed-inactive-reopened',needle)
ctl('actor-calendarSwitch','actor','calendarSwitch','calendar');CS=json.loads((B/'actor-calendarSwitch-stdout.json').read_text())['pageId']
act('click',CS,'calendar-switch-menu','button "Switch organization"');act('click',CS,'calendar-switch-B','menuitem "VO Verification Organization B member"');act('reload',CS,'calendar-switch-B-persisted')
for kind,file in [('loader','public-loader.js'),('dom','calendar-dom.js')]:projection(CS,'calendar-switch-B-'+kind,file)
act('click',CS,'calendar-switch-A-menu','button "Switch organization"');act('click',CS,'calendar-switch-A','menuitem "VO Verification Organization A member"');act('reload',CS,'calendar-switch-A-persisted')
for kind,file in [('loader','public-loader.js'),('dom','calendar-dom.js')]:projection(CS,'calendar-switch-A-'+kind,file)
progress('Native saved inactive History witness and positive B→A Calendar isolation captured')
for page,label in [(T,'training'),(O,'onboarding')]:ctl(label+'-cleanup-hook-state','network','state',str(page));ctl(label+'-cleanup-hook-restore','network','restore',str(page))
rows('preclean',('personnel','groups','personnel_trainings','personnel_onboardings','onboarding_step_progress'));ctl('seed-cleanup','clean-seeds');rows('cleaned',('personnel','groups','personnel_trainings','personnel_onboardings','onboarding_step_progress'))
run('drive.py','app','final-doctor','doctor')
progress('Seed cleanup and final doctor complete; coordinator must verify rows/ledger and exact inventory before disposal')
