# D30 #1378 unchanged-app baseline (re-capture)

- Revision: `172295422a6b97838ad6cd9c3b4d5f079a1245aa` (detached; no application source modified)
- Candidate digest: `4d8fa99d3e2e76049b1c343efd78354648fef8a0f9cc21958a57d9568f7a5b86`
- Worker: 1 only; origin `http://127.0.0.1:46569`; session `9d003870-701f-4fac-b40b-449e14682bac`
- Browser: Chromium 152.0.7977.82 (owned verify:app profile, native DevTools tools only)
- Doctor: PASS initially (`doctor-initial.json`) and after the run (`doctor-final.json`); owned cleanup PASS (`cleanup-worker.json`)
- Fixture: `fixture.json` (Org A `536d6591-...`, Org B `70bf1318-...`, local date 2026-10-08)
- Captured: 2026-10-08. This re-captures a baseline whose earlier archive was lost; it is not a repaired-candidate run.

Status vocabulary: live-verified = observed in the owned app and matching the recipe expectation; observation = live-verified with a noted deviation or open question.

## Results per path

| # | Path | Role / Org | Expected (recipe) | Observed | Status | Evidence |
|---|------|-----------|-------------------|----------|--------|----------|
| 1a | `/calendar` month statuses | calendarConfigure / A | Sep 2026: Able Leave 14-16 "Alpha seeded leave", Baker Training 15, Unassigned Leave 15, Unit Closure 15; no Foreign | Exactly as expected; no Foreign | live-verified | p1-calendar-sep2026.* |
| 1b | 3-Month and back | calendarConfigure / A | Sep-Nov view keeps statuses/closure; return to month | Sep-Nov showed Leave x3 Able, Training Baker, Leave Unassigned, closure 15; returned to "September 2026" month view | live-verified | p1-calendar-3month.*, p1-calendar-back-month.txt |
| 1c | Month/year picker to Sep 2026 | calendarConfigure / A | Picker dialog, choose Sep | Picker opened (Oct focused), Sep selected | live-verified | p1-picker-open.txt |
| 1d | Reload same data | calendarConfigure / A | After reload, same Sep data | Reload returned to current month (Oct, per recipe gotcha); re-picked Sep, same three seeded descriptions | live-verified | p1-calendar-after-reload.txt, p1-calendar-sep2026-reread.* |
| 1e | `/calendar/assignments` Sep 15 | calendarConfigure / A | Staff=Able, Group=Alpha, Retiring=Baker; archived type not an active control | Staff "SPC Able, Synthetic - Alpha", Group "Alpha", Retiring "SPC Baker, Synthetic - Bravo"; only 3 active types; entered via Planning > Assignment Planner | live-verified | p1-assignments-*.txt/json/png |
| 1f | `/calendar/bulk` offered people | calendarConfigure / A | Able, Baker (+Unassigned) and Leave offered; Foreign absent | Able, Baker, Unassigned checkboxes, 3 status types; no Foreign. Select/unselect Able: "1 of 3" -> "0 of 3" | live-verified | p1-bulk-add.*, p1-bulk-add-able-selected.txt |
| 1g | `/calendar/settings` catalogs | calendarConfigure / A | Status (3) / Assignment (3 active, archived excluded) / Closures (2) | Status Types 3, Assignment Types 3 (Staff, Group, Retiring; Archived excluded), Closures 2 | live-verified | p1-settings-*.* |
| 1h | `/calendar/reports` status-day | calendarConfigure / A, 2026 | Able Leave 4; Unassigned Leave 1; Baker Training 1+3=4, Retiring 1, total 5; no Foreign | Baker 0/1/4 total 5; Able 4/0/0 total 4; Unassigned 1/0/0 total 1; "3 personnel", "10 total"; no Foreign | live-verified | p1-reports-status-day.* |
| 1i | calendarScoped scoped read | calendarScoped / A | Only Able/Alpha; range response only availabilityAlpha | Grid shows only ALPHA / Able with seeded leave; range GET 200 with Alpha ID only, no Baker/Unassigned/Foreign | live-verified | p1-scoped-sep2026.*, p1-scoped-range-response.json |
| 1j | manager denial on `/calendar` | manager / A | Access Restricted; no Calendar data | "Access Restricted" page; page-data 200 with no seeded/availability content. Note: document title was "Sign In - Troop to Task" on this denied page | observation | p1-manager-calendar-denied.*, p1-manager-calendar-pagedata.json |
| 2a | `/auth/login` form | signed out | Email, Password, Show password, Sign In | All present plus reset/renew/request-access links | live-verified | p2-login-form.* |
| 2b | Password toggle | signed out | Show/Hide toggles input type | type text with "Hide password", back to password | live-verified | p2-login-password-shown.txt |
| 2c | Wrong password | orgInvitee email, synthetic wrong password (one attempt) | Form stays usable; "Email or password is incorrect" | Alert "Email or password is incorrect", stayed on /auth/login | live-verified | p2-login-wrong-password.* |
| 2d | `/auth/forgot-password` | signed out, nonexistent synthetic email | Generic reply | "Check your email" / "If an account exists for ..." generic | live-verified | p2-forgot-*.* |
| 2e | `/auth/request-access` | signed out | Form renders; submit gated | Form with required fields; Submit disabled after only First Name filled (no request submitted) | live-verified | p2-request-access*.* |
| 2f | tokenless `/auth/logout` | signed out | No-session logout entry path | Landed on public `/` with Sign In | live-verified | p2-tokenless-logout.* |
| 2g | tokenless `/auth/confirm` | signed out | Unavailable link page | "Link unavailable" with recovery links | live-verified | p2-tokenless-confirm.* |
| 2h | tokenless `/auth/mfa-verify` | signed out | (no recipe expectation) | Renders "Verify your code" form, Verify disabled, sign-out button; no redirect to login | observation | p2-tokenless-mfa-verify.* |
| 2i | tokenless `/auth/renew-invite` | signed out | Request form | "Request a fresh setup link" form | live-verified | p2-tokenless-renew-invite.* |
| 2j | tokenless `/auth/reset-password` | signed out | Unavailable reset | "Reset link unavailable" | live-verified | p2-tokenless-reset-password.* |
| 2k | tokenless `/auth/setup-account` | signed out | Unavailable setup | "Setup link unavailable" | live-verified | p2-tokenless-setup-account.* |
| 2l | tokenless `/auth/accept-invite` | signed out | Unavailable invite | "Invite unavailable" | live-verified | p2-tokenless-accept-invite.* |
| 2m | Manager sign-in then sign-out | manager / A | Lands on /org/A/personnel; Account menu > Sign Out returns to `/` | As expected. Note: the separate manager context (page 4) was also signed out (next visit to /account/security redirected to /auth/login), i.e. sign-out ended the user's other session | observation | p2-manager-signed-in.*, p2-account-menu.txt, p2-manager-signed-out.* |
| 3 | `/account/security` | manager (fresh login) | Renders | Email, Password (live requirement checks update; Update disabled until match), MFA "Disabled" | live-verified | p3-account-security*.* |
| 4a | `/suspended` normal member | manager / A | Redirect to /dashboard | /suspended -> /dashboard -> single-Org home `/org/A` | live-verified | p4-suspended-normal-member.* |
| 4b | `/suspended` signed out | signed out | Redirect to /auth/login | /auth/login | live-verified | p4-suspended-signed-out.* |
| 4c | Suspended user held | orgInvitee (seed platform-admin membership); suspended by platformReviewer via User detail UI | Held on /suspended incl. direct dashboard | After admin Suspend (reason "D30 baseline synthetic suspension"; detail flipped to Suspended/Unsuspend User without reload; `user_suspensions` row + `suspend_user` audit), reload -> /suspended "ACCOUNT SUSPENDED"; direct /dashboard and /org/<temp> also -> /suspended. Note: suspended page offers no sign-out control | live-verified | p4-admin-user-suspended.*, p4-platform-state-suspended.json, p4-invitee-*.* |
| 4d | Unsuspend via UI | platformReviewer | Restored access | Unsuspend dialog -> Active / Suspend User; suspensions []; invitee /dashboard -> temp Org home | live-verified | p4-admin-unsuspend-dialog.txt, p4-admin-user-unsuspended.*, p4-platform-state-unsuspended.json, p4-invitee-after-unsuspend.* |
| 5a | Admin search | platformReviewer | Directory + global search find records | Users search "orgInvitee" -> one record; global search for temp Org -> suggestion -> detail | live-verified | p5-admin-users-search.*, p5-admin-global-search.* |
| 5b | Admin list pages | platformReviewer | Users, Organizations, Access Requests | Users (paged, Next enabled), Organizations (temp Org listed), Access Requests (two pending seed requests, linked Org) | live-verified | p5-admin-users.*, p5-admin-organizations.*, p5-admin-access-requests.* |
| 5c | Org detail Suspend dialog open/cancel | platformReviewer, temp Org | Dialog opens; cancel no effect | Dialog with reason; Cancel -> still Active; platform-state suspended_at null | live-verified | p5-admin-org-suspend-*.*, p5-platform-state-after-cancel.json |
| 5d | Org detail Transfer Ownership dialog open/cancel | platformReviewer, temp Org | Dialog with member choice and exact-name confirm; cancel no effect | Dialog lists orgMember/orgInvitee, confirm field, Transfer disabled; Cancel closed; memberships unchanged | live-verified | p5-admin-org-transfer-*.* |
| 5e | User detail Suspend dialog open/cancel | platformReviewer, orgInvitee | Dialog; cancel no effect | Dialog; Cancel -> Active | live-verified | p5-admin-user-suspend-*.* |
| 5f | orgMember `/admin` denial | orgMember / A | Denied; no privileged payload | "403 You don't have permission"; page-data nodes 403 "Platform admin access is required", no platform data | live-verified | p5-orgmember-admin-*.* |
| 6a | `/settings/logs` resolved labels | orgOwner / A (+ `seed audit`) | Owner summaries; same-A labels resolve; foreign IDs stripped; masked values kept | 100 of 107 loaded, 106 in 30 days; witness resolves "SPC Able Synthetic", "Verification Required Training", "Verification Leave"; masked email and [redacted] kept; foreign-ID witness shows no labels; owner email actor, System for null, stored legacy actor. Search "Calendar" filtered to one row. Note: the pre-seed `calendar_report.viewed` event (calendarConfigure user) shows actor "System" because that fixture membership has `email: null` (fixture artifact, not product evidence) | live-verified | p6-logs*.*, p6-audit-rows-orgA-before-seed.json, p6-seed-audit.json |
| 6b | orgAdmin denied Logs | orgAdmin / A | Denied, no audit rows | 403 page; page-data node 403 "Only the organization owner..." | live-verified | p6-logs-orgadmin-*.* |
| 6c | Invite synthetic address -> pending -> resend -> revoke | orgOwner / A; `d30-baseline-invite-1722954@example.test` | Pending row; delivery failure visible; resend keeps same ID; revoke closes | Invite: "Invitation created, but email delivery failed..." + 1 pending (row f9b3e8ca... pending); Resend once: "Invitation email delivery failed. The pending invitation is still intact..." same single row pending; Revoke (no confirmation dialog): "Invitation revoked.", 0 pending, History "Revoked"; row status revoked; persists after reload. Revoked row is retained history (removed with worker disposal) | live-verified | p6-members-*.*, p6-invitation-rows-*.json |
| 6d | `/settings/ranks` catalog | orgOwner / A | Catalog with seeded PFC/SPC/SGT + VFY codes | 4 active / 1 retired; Army 3 of 28; search "VFY" -> VFY-ACTIVE-A active custom | live-verified | p6-ranks*.* |
| 7a | Starter pack list | orgOwner / A, GET api/getting-started | Pack listed, canApply | 200; first-week-operations, canApply true, not applied | live-verified (API) | p7-getting-started-owner.json |
| 7b | Apply | orgOwner, POST .../apply | Creates 2 Training Types + template + 4 steps; orientation step linked | 200 created 7; rows: 2 types, 1 template, 4 steps; "Complete unit orientation" training_type_id = Unit Orientation ID | live-verified (API) | p7-apply-first.json, p7-starter-*-after-apply.json |
| 7c | Reapply skipped | orgOwner | All skipped, no duplicates | 200 created [] skipped 7; counts unchanged | live-verified (API) | p7-apply-second.json, p7-starter-rows-after-reapply.json |
| 7d | trainingView 403 | trainingView / A | 403, unchanged rows | 403 "You don't have permission..."; list shows canApply false with both denied actions; rows/steps unchanged | live-verified (API) | p7-apply-trainingView-denied.json, p7-getting-started-trainingView.json, p7-starter-*-after-denied.json |
| 7e | Delete created records | orgOwner, DELETE api/onboarding-templates, api/training-types | Gone | Three DELETEs 200; types/template/steps counts 0; readiness back to 0 applied | live-verified (API) | p7-delete-created.json, p7-starter-*-after-delete.json |
| 8a | Critical Tasks matrix | ictConfigurator / A | Active Alpha + All-MOS tasks; A Personnel; no archived/foreign | VERIFY-ICT-ALPHA and VERIFY-ICT-ALL; Able 50% (Alpha current, Demonstration), Baker 0%, Unassigned 0%; no archived/foreign | live-verified | p8-ict-matrix.* |
| 8b | Task Library | ictConfigurator / A | Active tasks; Archived filter shows only archived; workspace reuse | Active: ALPHA (68W), ALL; config controls present; Archived -> only VERIFY-ICT-ARCHIVED. Navigation probe: one `library/__data.json` with `0001` (layout digit 0) | live-verified | p8-ict-library*.* |

Starter-pack proof is ordinary authenticated HTTP from a signed-in page (no rendered Apply control at this revision, per dashboard.md), separate from native interaction.

## Cleanup

- Feedback observer armed for the invitation case and restored; no network/export controls armed; no Calendar grants changed.
- UI-created: invitation (revoked; status retained as history), starter artifacts (deleted via endpoints, absence read back). orgInvitee suspension restored visibly; its two audit IDs recorded via `platform-audit` and removed by cleanup.
- `clean-seeds`: platform-admin and audit cohorts removed (`cleanup-clean-seeds.json`); audit seed action count 0 in A and B.
- Final doctor PASS; `verify:app cleanup --worker 1` PASS. Worker 2 never touched.

## Redaction

Page-data probes were written to return node status summaries only. An early probe output containing session access/refresh token values was overwritten before packaging; a final scan found no JWT or refresh-token values. One deliberately wrong synthetic password string (not a credential) appears in `p2-login-password-shown.txt`.
