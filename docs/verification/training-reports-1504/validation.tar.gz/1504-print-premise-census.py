from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path.cwd()
cases = [
    ('v2-short', '1504-final-v2', 'no-applicable-dark.pdf'),
    ('v2-long', '1504-final-v2', 'seeded-page1-25rows-light.pdf'),
    ('v3-short', '1504-final-v3', 'empty-bravo-targeted-light.pdf'),
    ('v3-long', '1504-final-v3', 'seeded-25-row-detail-light.pdf'),
]
pdfs = []
for name, run, filename in cases:
    path = root / '.verification/evidence/verify-trooptotask' / run / 'accept/pdf' / filename
    info = subprocess.check_output(['pdfinfo', str(path)], text=True)
    pages = int(re.search(r'^Pages:\s+(\d+)', info, re.M).group(1))
    dimensions = subprocess.check_output(['pdfinfo', '-f', '1', '-l', str(pages), str(path)], text=True)
    pdfs.append({'case': name, 'path': str(path.relative_to(root)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'pages': pages, 'pageSizes': re.findall(r'^Page\s+\d+ size:\s+(.+)$', dimensions, re.M)})

receipt = root / '.verification/evidence/verify-trooptotask/1504-final-v3/accept/receipts/208-body-outside-app.stdout'
value = json.loads(receipt.read_text())['structuredContent']['message']
body = json.loads(re.search(r'```json\n(.*?)\n```', value, re.S).group(1))
result = {
    'failedPremise': 'Every box capable of producing the extra unnamed page is an ancestor of the report, so resetting ancestor heights will remove the fragment.',
    'pdfMetadata': pdfs,
    'screenBodySiblingObservation': body,
    'screenObservationSha256': hashlib.sha256(receipt.read_bytes()).hexdigest(),
    'actors': [
        {'actor': 'report ancestors', 'owner': 'src/app.css', 'changed': '31024cb0 adds scoped height and overflow reset', 'result': 'v3 still has extra default portrait page in short and long PDF; height-only premise not sufficient'},
        {'actor': 'report root', 'owner': 'src/features/training/components/TrainingReportsPage.svelte', 'page': 'training-brief landscape', 'result': 'PDF content pages remain landscape'},
        {'actor': 'toast host sibling', 'owner': 'src/routes/+layout.svelte and src/lib/components/ui/sonner/sonner.svelte', 'dependency': 'svelte-sonner Toaster.svelte section outside .app with fixed-position ol inside', 'result': 'screen receipt shows static visible SECTION after .app, outside report; print effect unproven'},
        {'actor': 'Svelte announcer sibling', 'owner': 'SvelteKit', 'result': 'screen receipt absolute positioned; no print cause established'},
        {'actor': 'shell chrome', 'owner': 'AppShellHeader/BannerStack/sidebar', 'result': 'existing data-print-chrome/sidebar selectors hide named chrome; no new height fix is justified without all print participants census'}
    ],
    'limits': 'No visual judgment or print-media measurement is supplied by this script. PDF metadata and captured screen DOM cannot identify a confirmed CSS cause. Claude owns diagnosis/correction and fresh rendered proof.'
}
(root / '.verification/1504-print-premise-census.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'cases': len(pdfs), 'pages': {item['case']: item['pages'] for item in pdfs}, 'premise': result['failedPremise'], 'state': 'all participant census recorded; no correction yet'}))
