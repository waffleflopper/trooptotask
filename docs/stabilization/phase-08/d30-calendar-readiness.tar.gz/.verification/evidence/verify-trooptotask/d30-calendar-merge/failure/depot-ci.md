# Depot CI failure receipt

Read-only inspection of PR #1578. Retrieved using the existing Depot CLI and the documented `GetJob` API. No retry, workflow mutation, source change, database operation, or service operation was performed.

- GitHub check run: `113492833737`, `CI / Repository and application`, failure.
- PR head: `ed4758185d0cf720c86fda625ef5fa1e6dddfde0`.
- Depot run: `zs0t8qxjh0`.
- Workflow: `2h2sxsrwlq`, `.depot/workflows/ci.yml`.
- Job: `czlkdhqtrr`, `ci.yml:validation`.
- Attempt: `swjjqw0dcx`, attempt 1, failed, 2026-10-08 19:11:30–19:16:36 UTC.
- Actual tested ref: `refs/pull/1578/merge`.
- Actual tested SHA: `1c31f518cd86f14a84c811961d4246ac721617a0`, merging the PR head into `172295422a6b97838ad6cd9c3b4d5f079a1245aa`.

Failed command: `npm run test`, executing `vitest run` in the `Vitest` step. The process exited with code 1. Vitest reported 4 failed test files, 725 passed files, 4 failed tests and 7285 passed tests.

| Assertion location | Error / received value |
| --- | --- |
| `src/routes/org/[orgId]/calendar/layout.svelte.test.ts:47:23` | Expected `restrictMock('org-1')`; received one call with no arguments. |
| `src/routes/org/[orgId]/critical-tasks/critical-tasks-layout.svelte.test.ts:84:46` | Expected `personnelIctCompletionsStore.orgId` to equal `org-1`; received the empty string. |
| `src/routes/org/[orgId]/personnel/layout.svelte.test.ts:36:23` | Expected `restrictMock('org-1', expect.any(Object))`; received one call with the stores object as the only argument. |
| `src/routes/org/[orgId]/training/(workspace)/layout.svelte.test.ts:36:23` | Expected `restrictMock('org-1')`; received one call with no arguments. |

All four failing scenarios are denied/revoked workspace tests. The logs identify assertion mismatches; determining whether the tests or production behavior should change requires the retained clearing-state contract. No independent local reproduction was performed in this bounded investigation. The production build subsequently logged `✔ done`; the failure receipt concerns the Vitest step.

`depot-job-binding.json` records a sanitized API response. `failure-excerpt.jsonl` contains only checkout SHA evidence, the test command, four assertion stacks, test totals, process exit status and the final build completion line. Logs were fetched by pinned attempt ID.

Sources: [failed job](https://depot.dev/orgs/rvsvvkd4rp/workflows/2h2sxsrwlq?job=czlkdhqtrr&repo=waffleflopper%2Ftrooptotask), [Depot CI API](https://depot.dev/docs/api/ci/reference), [Depot CI logs CLI](https://depot.dev/docs/cli/reference/depot-ci).
