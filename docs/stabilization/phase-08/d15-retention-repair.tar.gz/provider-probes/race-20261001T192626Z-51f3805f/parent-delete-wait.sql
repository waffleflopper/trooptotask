SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('waiting', COALESCE(json_agg(json_build_object(
 'pid', a.pid, 'wait_event_type', a.wait_event_type, 'wait_event', a.wait_event,
 'blocked_by_holder', 953 = ANY(pg_blocking_pids(a.pid)), 'parent_delete', true)), '[]'::json))
FROM pg_stat_activity a WHERE a.datname = 'postgres' AND a.pid <> 953
 AND a.state = 'active' AND a.wait_event_type = 'Lock' AND 953 = ANY(pg_blocking_pids(a.pid))
 AND a.query ~* 'delete[[:space:]]+from[[:space:]]+("?public"?[.])?"?personnel_onboardings"?([[:space:]]|$)';
