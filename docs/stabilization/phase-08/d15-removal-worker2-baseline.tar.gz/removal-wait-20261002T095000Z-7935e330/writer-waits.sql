SET statement_timeout = '10s'; SET lock_timeout = '3s';
WITH RECURSIVE candidates AS (
 SELECT a.*, CASE WHEN query ~ '(^|[^[:alnum:]_$"])(public|"public")[.](reconcile_onboarding_packet|"reconcile_onboarding_packet")[[:space:]]*[(]' THEN 'reconciliation-ordinary-rpc'
 WHEN query ~* 'delete[[:space:]]+from[[:space:]]+("?public"?[.])?"?onboarding_step_progress"?([[:space:]]|$)' THEN 'progress-ordinary-delete' END AS query_class
 FROM pg_stat_activity a WHERE datname='postgres' AND usename='authenticator'
 AND state='active' AND wait_event_type='Lock'
), chain(root_pid,node_pid,path) AS (
 SELECT pid,pid,ARRAY[pid] FROM candidates
 UNION ALL SELECT c.root_pid,b.pid,c.path || b.pid FROM chain c
 CROSS JOIN LATERAL unnest(pg_blocking_pids(c.node_pid)) b(pid)
 WHERE NOT b.pid=ANY(c.path) AND cardinality(c.path)<12
), reached AS (SELECT root_pid,json_agg(path) AS paths FROM chain
 WHERE node_pid=2903 GROUP BY root_pid)
SELECT json_build_object('holder_matches',EXISTS(SELECT 1 FROM pg_stat_activity
 WHERE pid=2903 AND backend_start='2026-10-02 09:50:02.075539+00'::timestamptz AND application_name='t2t-d15-removal-67ea4e789df0467085a15fae95983ac4' AND usename='supabase_admin' AND datname='postgres'), 'waiting',COALESCE((SELECT json_agg(json_build_object(
 'pid',a.pid,'backend_start',a.backend_start::text,'query_class',a.query_class,
 'query_bytes',octet_length(a.query),'activity_query_capture_size',current_setting('track_activity_query_size'),
 'state',a.state,'wait_event_type',a.wait_event_type,'wait_event',a.wait_event,'blocking_paths',r.paths)
 ORDER BY a.pid) FROM candidates a JOIN reached r ON r.root_pid=a.pid),'[]'::json));
