if (!window.__hk) {
	const hk = (window.__hk = { log: [], mode: null, release: null, exports: [], blobs: [], origFetch: window.fetch, origCOU: URL.createObjectURL });
	const sha = async (buf) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', buf))].map((b) => b.toString(16).padStart(2, '0')).join('');
	const b64 = (buf) => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return btoa(s); };
	window.fetch = async (input, init) => {
		const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
		const summary = /\/api\/training-reports(\?|$)/.test(url);
		const entry = { at: new Date().toISOString(), url: url.replace(location.origin, ''), summary };
		hk.log.push(entry);
		if (summary && hk.mode === 'hold') { hk.mode = null; entry.held = true; await new Promise((r) => (hk.release = r)); }
		if (summary && hk.mode === 'fail') { hk.mode = null; entry.status = 503; entry.synthetic = true; return new Response('{"message":"synthetic 503"}', { status: 503, headers: { 'content-type': 'application/json' } }); }
		const res = await hk.origFetch.call(window, input, init);
		entry.status = res.status;
		if (/\/api\/training-reports\/export/.test(url)) {
			const buf = await res.clone().arrayBuffer();
			hk.exports.push({ url: entry.url, status: res.status, headers: Object.fromEntries([...res.headers].filter(([k]) => !/cookie/i.test(k))), size: buf.byteLength, sha256: await sha(buf), b64: b64(buf) });
		}
		return res;
	};
	URL.createObjectURL = function (obj) {
		const out = hk.origCOU.call(URL, obj);
		if (obj instanceof Blob) obj.arrayBuffer().then(async (buf) => hk.blobs.push({ type: obj.type, size: buf.byteLength, sha256: await sha(buf), url: out }));
		return out;
	};
}
window.__unhook = () => { if (!window.__hk) return 'none'; window.fetch = window.__hk.origFetch; URL.createObjectURL = window.__hk.origCOU; if (window.__hk.release) window.__hk.release(); delete window.__hk; return 'restored ' + (window.fetch.toString().includes('native code') && URL.createObjectURL.toString().includes('native code')); };
window.__d1 = () => {
	const pick = [...document.querySelectorAll('[aria-label="Training report actions"] button, [aria-label="Training report actions"] [role=status], [data-testid="training-report-filters"] button, [aria-label="Forecast horizon"] [role=radio]')];
	const ctrls = pick.map((el) => { const r = el.getBoundingClientRect(); const cx = r.left + r.width / 2, cy = r.top + r.height / 2; const hit = document.elementFromPoint(cx, cy); return { n: (el.getAttribute('aria-label') || el.textContent.trim()).slice(0, 24), x: +r.left.toFixed(1), y: +r.top.toFixed(1), w: +r.width.toFixed(1), h: +r.height.toFixed(1), hits: !!hit && (hit === el || el.contains(hit)), checked: el.getAttribute('aria-checked') }; });
	const alert = document.querySelector('[role=alert]');
	const host = document.querySelector('[data-testid="training-briefing-forecast"]');
	const cap = host?.firstElementChild?.querySelector('p') ? host.firstElementChild.getBoundingClientRect() : null;
	const svg = host?.querySelector('svg')?.getBoundingClientRect();
	const toolbar = document.querySelector('[aria-label="Training report controls"]')?.getBoundingClientRect();
	const bl = document.querySelector('main')?.innerText.match(/Bottom line\s+(\d+%)[\s\S]{0,40}?(\d+%)/);
	return { vw: innerWidth, theme: document.documentElement.dataset.theme, url: location.search, updating: /Updating briefing/.test(document.body.innerText), alert: alert ? alert.innerText.replace(/\s+/g, ' ').slice(0, 120) : null, alertTop: alert ? +alert.getBoundingClientRect().top.toFixed(1) : null, toolbarBottom: toolbar ? +toolbar.bottom.toFixed(1) : null, bl: bl ? bl[1] + '>' + bl[2] : null, captionAboveSvg: cap && svg ? cap.bottom <= svg.top + 0.5 : null, ctrls };
};
window.__d2 = () => {
	const svg = document.querySelector('[data-testid="training-briefing-forecast"] svg');
	const R = (e) => e.getBoundingClientRect();
	const ov = (a, b) => a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
	const texts = [...svg.querySelectorAll('text')].map((t) => ({ t: t.textContent.trim(), r: R(t) }));
	const bars = [...svg.querySelectorAll('rect')].filter((r) => /fill-warning(?!\/10)/.test(r.getAttribute('class') || '') && R(r).height > 0).map(R);
	const issues = [];
	for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) if (ov(texts[i].r, texts[j].r)) issues.push('text/text ' + texts[i].t + ' x ' + texts[j].t);
	for (const t of texts) for (const b of bars) if (ov(t.r, b)) issues.push('text/bar ' + t.t);
	const s = R(svg);
	for (const t of texts) if (t.r.left < s.left - 0.5 || t.r.right > s.right + 0.5) issues.push('outside ' + t.t);
	return issues;
};
'hooks installed';
