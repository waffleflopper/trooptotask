import json,pathlib,subprocess
p=pathlib.Path(__file__).parent
fx=json.loads(json.loads((p/'fixture.control.json').read_text())['stdout'])['ids']
owner='420ca9ac-8f5e-452f-90b6-5a29cb5f2564'
cases=[('no-calendar',7,'orgA','personA','statusLeave',False),('scoped-bravo',16,'orgA','personB','statusLeave',False),('scoped-unassigned',16,'orgA','personUnassigned','statusLeave',False),('empty-alpha',17,'orgA','personA','statusLeave',False),('foreign-org',15,'orgB','personForeign','statusForeign',False),('foreign-status',15,'orgA','personA','statusForeign',False),('member-control',8,'orgA','personA','statusLeave',False),('member-forged',8,'orgA','personA','statusLeave',True)]
for name,page,org,person,status,forged in cases:
 marker='D27 composition denied '+name
 body={'personnelId':fx[person],'statusTypeId':fx[status],'startDate':'2026-09-14','endDate':'2026-09-14','note':marker}
 headers={'Content-Type':'application/json'}
 if forged:
  body.update({'userId':owner,'actorUserId':owner,'role':'owner','isPrivileged':True,'capabilities':{k:'configure' for k in ['personnel','calendar','training','ict','onboarding','ratingScheme']},'scopeSet':{'kind':'organization'}})
  headers.update({'X-Actor-Id':owner,'X-Role':'owner'})
 probes=[{'path':'/org/'+fx[org]+'/api/availability','body':body},{'path':'/org/'+fx[org]+'/api/availability/batch','body':{'records':[body]}}]
 fn='async () => { const probes='+json.dumps(probes)+'; const results=[];for(const p of probes){const r=await fetch(p.path,{method:"POST",headers:'+json.dumps(headers)+',body:JSON.stringify(p.body)}); results.push({...p,status:r.status,response:await r.json()});} return results;}'
 subprocess.run(['python3',str(p/'capture.py'),name+'-denied','evaluate_script',json.dumps({'pageId':page,'function':fn})],check=True)
 rows=json.loads((p/(name+'-denied.json')).read_text()); print(name,[r['status'] for r in rows]);assert all(r['status'] in [400,403,404] for r in rows)
 for target in ['orgA','orgB']:
  stem=name+'-'+target+'-absent';subprocess.run(['python3',str(p/'control.py'),stem,'rows','availability_entries',target,'note',marker],check=True)
  assert json.loads(json.loads((p/(stem+'.control.json')).read_text())['stdout'])['count']==0
