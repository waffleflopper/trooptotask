import json, os, re, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PAGE=2
counter=0

def tool(name,args,label):
    result=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args)],capture_output=True,text=True,check=False)
    (ROOT/(label+'.json')).write_text(result.stdout)
    if result.stderr: (ROOT/(label+'.stderr.log')).write_text(result.stderr)
    result.check_returncode()
    value=json.loads(result.stdout)
    if value.get('isError'): raise RuntimeError(value)
    return '\n'.join(c['text'] for c in value.get('content',[]) if c.get('type')=='text')

def snap(label, page=None, show=True):
    page=PAGE if page is None else page
    path=ROOT/(label+'.txt')
    tool('take_snapshot',{'pageId':page,'filePath':str(path)},label+'-snapshot')
    text=path.read_text()
    if show: print(text,flush=True)
    return text

def uid(text,role,name):
    pattern=r'uid=([^ ]+) '+re.escape(role)+r' "'+re.escape(name)+r'"(?: |$)'
    matches=re.findall(pattern,text,re.M)
    if len(matches)!=1: raise RuntimeError(f'{role} {name!r}: {matches}')
    return matches[0]

def click(name,label,role='button',page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    text=tool('click',{'pageId':page,'uid':uid(before,role,name),'includeSnapshot':True},label)
    print(text,flush=True)
    return text

def fill(fields,label,page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    elements=[{'uid':uid(before,role,name),'value':str(value)} for role,name,value in fields]
    text=tool('fill_form',{'pageId':page,'elements':elements,'includeSnapshot':True},label)
    print(text,flush=True)
    return text

def key(key,label,page=None):
    page=PAGE if page is None else page
    print(tool('press_key',{'pageId':page,'key':key,'includeSnapshot':True},label),flush=True)

def navigate(url,label,page=None):
    page=PAGE if page is None else page
    print(tool('navigate_page',{'pageId':page,'type':'url','url':url},label),flush=True)
    return snap(label+'-ready',page)

def reload(label,page=None):
    page=PAGE if page is None else page
    print(tool('navigate_page',{'pageId':page,'type':'reload'},label),flush=True)
    return snap(label+'-ready',page)

def click_prefix(prefix,label,page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    names=re.findall(r'uid=[^ ]+ button "([^"]+)"',before)
    matches=[name for name in names if name.startswith(prefix)]
    if len(matches)!=1: raise RuntimeError(f'{prefix}: {matches}')
    print(tool('click',{'pageId':page,'uid':uid(before,'button',matches[0]),'includeSnapshot':True},label),flush=True)

def control(args,label):
    result=subprocess.run(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args],capture_output=True,text=True,check=False)
    (ROOT/(label+'.json')).write_text(result.stdout)
    if result.stderr: (ROOT/(label+'.stderr.log')).write_text(result.stderr)
    result.check_returncode()
    print(label+': '+result.stdout,flush=True)
    return json.loads(result.stdout)

def click_dialog(name,label,page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    dialogs=list(re.finditer(r'^.*uid=[^ ]+ (?:alertdialog|dialog) ',before,re.M))
    if len(dialogs)!=1: raise RuntimeError('Expected one visible dialog')
    print(tool('click',{'pageId':page,'uid':uid(before[dialogs[0].start():],'button',name),'includeSnapshot':True},label),flush=True)

def http(requests,label,page=None):
    page=PAGE if page is None else page
    fn='async () => { const requests = '+json.dumps(requests)+'; const results=[]; for (const request of requests) { const response=await fetch(request.path,{method:request.method,headers:{"Content-Type":"application/json"},body:JSON.stringify(request.submitted)}); results.push({...request,status:response.status,body:await response.text()}); } return results; }'
    print(tool('evaluate_script',{'pageId':page,'function':fn,'filePath':str(ROOT/(label+'.json')),'waitForStableDom':False},label+'-tool'),flush=True)
    values=json.loads((ROOT/(label+'.json')).read_text())
    print(label+': '+json.dumps(values),flush=True)
    return values

def upload(filename,label,page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    print(tool('upload_file',{'pageId':page,'uid':uid(before,'button','Upload file'),'filePaths':[str(ROOT/filename)],'includeSnapshot':True},label),flush=True)
    return snap(label+'-preview',page)

def click_row(row_name,button_name,label,page=None):
    page=PAGE if page is None else page
    before=snap(label+'-before',page,False)
    lines=before.splitlines()
    matches=[i for i,line in enumerate(lines) if re.search(r'row "'+re.escape(row_name)+r'"(?: |$)',line)]
    if len(matches)!=1: raise RuntimeError('Expected one named row')
    start=matches[0];indent=len(lines[start])-len(lines[start].lstrip());end=start+1
    while end<len(lines) and len(lines[end])-len(lines[end].lstrip())>indent:end+=1
    target=uid('\n'.join(lines[start:end]),'button',button_name)
    print(tool('click',{'pageId':page,'uid':target,'includeSnapshot':True},label),flush=True)
