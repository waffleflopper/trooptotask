#!/usr/bin/env python3
"""Read only archived business evidence; no live requests or provider writes."""
import datetime, json, re
from pathlib import Path
ROOT = Path(__file__).resolve().parents[3]
B = ROOT / '.verification/evidence/verify-trooptotask/d15-consumers-worker2-final'
def read(name): return json.loads((B / name).read_text())
def rows(stage, org, table):
    value = read(f'{stage}-{org}-{table}-stdout.json')
    assert value['count'] == len(value['rows'])
    return sorted(value['rows'], key=lambda row: row['id'])
def projection(name):
    value = read(name + '-stdout.json')
    text = '\n'.join(part.get('text', '') for part in value['content'])
    return json.loads(re.search(r'```json\s*([\s\S]*?)```', text)[1])
seed = read('consumer-seed-stdout.json')
packets = {row['key']: row for row in seed['packets']}
alpha = packets['alphaActive']['personnel_id']
bravo = packets['bravoActive']['personnel_id']
foreign = packets['foreignActive']['personnel_id']
tables = ('personnel', 'groups', 'personnel_trainings', 'personnel_onboardings', 'onboarding_step_progress')
core, supplemental = [], []
for org in ('orgA', 'orgB'):
    for table in tables:
        assert rows('original', org, table) == rows('cleaned', org, table)
        core.append(f'{org}/{table} full original exact')
marker_cases = {
    'calendar-wide': [alpha, bravo], 'calendar-scoped': [alpha],
    'calendar-cancelled-wide': [bravo], 'calendar-cancelled-scoped': [],
    'calendar-reopened-wide': [alpha, bravo], 'calendar-reopened-scoped': [alpha],
    'calendar-completed-wide': [bravo], 'calendar-completed-scoped': [],
    'calendar-switch-B': [foreign], 'calendar-switch-A': [bravo]
}
for name, expected in marker_cases.items():
    value = projection(name + '-loader')
    assert value['status'] == 200 and len(value['markerArrays']) == 1
    assert sorted(value['markerArrays'][0]) == sorted(expected)
    core.append(name + ' public markers exact')
presence_cases = {'onboarding': False, 'onboarding-current': True, 'onboarding-current-deleted': False,
                  'onboarding-expired': True, 'onboarding-expired-deleted': False}
for name, completed in presence_cases.items():
    value = projection(name + '-loader')
    assert value['status'] == 200 and len(value['onboardingArrays']) == 1
    assert [row['id'] for row in value['onboardingArrays'][0]] == [packets['alphaActive']['id']]
    steps = value['onboardingArrays'][0][0]['steps']
    active = [step for step in steps if step['stepType'] == 'training' and step['active']]
    inactive = [step for step in steps if step['stepType'] == 'training' and not step['active']]
    assert len(active) == len(inactive) == 1 and active[0]['completed'] is completed and inactive[0]['completed'] is True
    core.append(name + ' active presence and inactive true')
stages = ('after-current', 'after-current-delete', 'after-expired', 'after-expired-delete',
          'after-cancel', 'after-reopen', 'after-complete', 'preclean')
for stage in stages:
    for org in ('orgA', 'orgB'):
        assert rows('seeded', org, 'onboarding_step_progress') == rows(stage, org, 'onboarding_step_progress')
        core.append(f'{stage}/{org} full saved progress exact')
for stage in stages:
    for org in ('orgA', 'orgB'):
        before = rows('seeded', org, 'personnel_onboardings')
        after = rows(stage, org, 'personnel_onboardings')
        for original, saved in zip(before, after, strict=True):
            if original['id'] != packets['alphaActive']['id'] or stage.startswith('after-current') or stage.startswith('after-expired'):
                assert original == saved
            else:
                assert {k:v for k,v in original.items() if k not in ('status','completed_at','cancelled_at')} == {k:v for k,v in saved.items() if k not in ('status','completed_at','cancelled_at')}
                expected = 'cancelled' if stage == 'after-cancel' else 'in_progress' if stage == 'after-reopen' else 'completed'
                assert saved['status'] == expected
                assert (saved['completed_at'] is not None) == (expected == 'completed')
                assert (saved['cancelled_at'] is not None) == (expected == 'cancelled')
supplemental.append('All parent fields unchanged except authoritative target status and terminal dates')
all_seed_ids = {row['id'] for key in ('people','packets','progress') for row in seed[key]}
assert len(all_seed_ids) == 16
assert not any(row['id'] in all_seed_ids for org in ('orgA','orgB') for table in tables for row in rows('cleaned', org, table))
supplemental.append('All 16 recorded seed IDs absent after cleanup')
for name in ('training-current-create','training-current-delete','training-expired-create','training-expired-delete','lifecycle-cancel','lifecycle-complete'):
    capture = read(name + '-capture.json')
    assert capture['status'] == 200 and capture['requestExists'] and capture['responseExists']
    read(name + '.network-request'); read(name + '.network-response')
    supplemental.append(name + ' native 200 and complete business request/response')
expired = read('training-expired-create.network-response')
assert expired['completed_at'][:10] == '2024-10-01' and expired['expiration_date'][:10] == '2025-10-01'
supplemental.append('Expired record retains literal picker dates')
reopen = projection('lifecycle-reopen-api')
assert reopen['status'] == 200 and reopen['body']['status'] == 'in_progress'
assert reopen['body']['completedAt'] is None and reopen['body']['cancelledAt'] is None
complete = read('lifecycle-complete.network-response')
assert complete['incompleteCount'] == 3 and 'There are 3 steps still incomplete.' in (B / 'lifecycle-complete-save-before.txt').read_text()
supplemental.append('Ordinary reopen clears terminal dates; real native warning and response report three incomplete active steps')
history = (B / 'history-current-companion-after.txt').read_text()
assert 'Consumer Required Training' in history and 'Incomplete' in history
history_final = (B / 'history-completed-inactive-reopened-after.txt').read_text()
assert 'Removed Training' in history_final and 'Previously completed' in history_final and 'STARTED MAR 1, 2026' in history_final
supplemental.append('Native History retains terminal incomplete and inactive previously-completed witnesses; March remains visible')
for name, tint in (('calendar-wide-dom',True), ('calendar-off-dom',False), ('calendar-on-dom',True)):
    value = projection(name)
    target = [row for row in value['rows'] if seed['people'][0]['last_name'] in row['person']]
    assert len(target) == 1 and target[0]['activeDot'] is True
    assert any(cell['onboardingTint'] for cell in target[0]['cells']) is tint
supplemental.append('Native preference off/on changes tint with persistent header dot')
info = read('final-info-stdout.json')
ledger = json.loads((Path(info['session']) / 'verify-trooptotask-owned.json').read_text())
public_ledger = {'seeded': ledger['seeded'], 'grants': ledger['grants']}
assert public_ledger == {'seeded': [], 'grants': []}
with (B / 'clean-ledger-public.json').open('x') as stream: json.dump(public_ledger, stream, indent=2)
doctor = read('final-doctor-stdout.json')
assert doctor['status'] == 'PASS' and doctor['candidate'] == info['candidate']
assert len(core) == 41
record = {'status':'PASS','candidate':info['candidate'],'capturedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'checks':core,'supplementalChecks':supplemental,'comparison':'Whole selected rowsets genuinely captured before seed vs after cleanup; no excluded ledger or native IDs',
          'ledgerEmpty':True,'drivingGaps':[],'disposal':'Pending exact owned cleanup and raw namespace inventory'}
with (B / 'final-observations-before-disposal.json').open('x') as stream: json.dump(record, stream, indent=2)
print(json.dumps({'status':'PASS','coreChecks':len(core),'supplementalChecks':len(supplemental),'originalRows':sum(len(rows('original',org,table)) for org in ('orgA','orgB') for table in tables),'ledgerEmpty':True}))
