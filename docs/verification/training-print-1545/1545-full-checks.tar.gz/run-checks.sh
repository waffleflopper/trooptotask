#!/usr/bin/env bash
set -u
cd /home/waffleflops/.cache/t2t-1545-state
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH
export TMPDIR=/home/waffleflops/.cache/t2tp-aknVLp
set -a
source .env
set +a
unset NODE_ENV
record_dir=.verification/evidence/issue1545-final-state-0860cfd9
for check_name in "$@"; do
  start_time=$(date -u +%FT%TZ)
  npm run "$check_name" > "$record_dir/$check_name.log" 2>&1
  result_code=$?
  end_time=$(date -u +%FT%TZ)
  line_count=$(wc -l < "$record_dir/$check_name.log")
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "npm run $check_name" "$result_code" "$line_count" "$start_time" "$end_time" "$record_dir/$check_name.log" | tee -a "$record_dir/results.tsv"
done
