import json,pathlib,collections,datetime
r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-twoport-final-native-20261007')
def read(n):return json.loads(json.loads((r/(n+'.json')).read_text())['stdout'])
seed=read('print-seed');types=seed['types'];groups=seed['groups'];tag=seed['tag'];people=[x for x in read('dense-sql-personnel')['rows'] if x['last_name'].startswith('PrintA'+tag)];assert len(people)==112;people.sort(key=lambda x:x['last_name']);sqlrecords=[x for x in read('dense-sql-personnel_trainings')['rows'] if x['training_type_id'] in {x['id'] for x in types}];assert len(sqlrecords)==1902
recordpairs={(x['personnel_id'],x['training_type_id']):x for x in sqlrecords};assert len(recordpairs)==1902
expected=[];expectedpairs=[];counts=dict(applicable=0,ready=0,horizonReady=0,missing=0,expired=0,lapsing=0)
for person in range(1,113):
 group=(person-1)//8;slot=(person-1)%8+1;who=people[person-1];assert who['last_name']==f'PrintA{tag}{person:03d}' and who['group_id']==groups[group]['id'] and who['rank']=='PFC' and who['mos']=='68V'
 for index,t in enumerate(types):
  if index==23 and group>=7:continue
  pair=(who['id'],t['id']);offset=(None if person<=100 else 365) if index==0 else [None,None,-20,-5,10,30,120,365][slot-1]
  counts["applicable"]+=1;counts["missing"]+=int(offset is None);counts["ready"]+=int(offset is not None and offset>=0);counts["horizonReady"]+=int(offset is not None and offset>=90);counts["expired"]+=int(offset is not None and offset<0);counts["lapsing"]+=int(offset is not None and 0<=offset<90)
  if offset is None:assert pair not in recordpairs
  else:
   row=recordpairs[pair];expiry=(datetime.date(2026,10,7)+datetime.timedelta(days=offset)).isoformat();assert row['expiration_date']==expiry and row['completion_date']=='2025-09-02' and row['notes'] is None and row['certificate_url'] is None
  if index==0:
   if person>100:continue
   status,expiry,lapse,flag='Not Done',None,None,'No'
  else:
   if slot>6:continue
   status,expiry,lapse,flag={1:('Not Done',None,None,'No'),2:('Not Done',None,None,'No'),3:('Expired 20d ago','2026-09-17',None,'No'),4:('Expired 5d ago','2026-10-02',None,'No'),5:('10d left','2026-10-17','2026-10-18','Yes'),6:('30d left','2026-11-06','2026-11-07','Yes')}[slot]
  expected.append((['PFC',f'PrintA{tag}{person:03d}, Synthetic',groups[group]['name'],t['name'],status,expiry,lapse,flag],pair))
expected.sort(key=lambda x:(x[0][5] is not None,x[0][5] or '',x[0][1],next(i for i,t in enumerate(types) if t['name']==x[0][3])))
assert counts==dict(applicable=2632,ready=1272,horizonReady=642,missing=730,expired=630,lapsing=630),counts
w=json.loads((r/'dense-workbook-rows.json').read_text());actual=w['Requirements'][1:];assert len(expected)==1990 and actual==[x[0] for x in expected]
summary=dict(w['Summary'][1:])
for key,value in [('Soldiers',112),('Applicable requirements',2632),('Ready',1272),('Ready today (%)',48),('Ready by 5 Jan (%)',24),('Not ready, expired',630),('Not ready, not recorded',730),('Lapse by 5 Jan',630)]:assert summary[key]==value,(key,summary[key])
a=read('dense-report-wire')['structuredContent']['networkRequest'];b=json.loads((r/'dense-report.network-response').read_text());v=b['briefing']['bottomLine'];assert a['status']=='200' and v['soldierCount']==112 and v['today']['ready']==1272 and v['today']['applicable']==2632 and v['horizon']['ready']==642 and v['expired']==630 and v['notRecorded']==730 and v['lapsing']==630
assert b['input']['viewId']==seed['views'][0]['id'] and b['input']['rank']=='PFC' and b['input']['mos']==['68V'] and b['input']['horizonDays']==90
out={'status':'PASS','boundary':'literal independent1902 SQL dated-record rules plus native1990 workbook rows and request report facts','day':'2026-10-07','tag':tag,'nativeFilename':'training-report-2026-10-07.xlsx','literalInput':b['input'],'bottomLine':v,'independentlyDerivedCounts':counts,'all1902SavedRecordsExactDates':True,'all1990WorkbookRowsExactOrderDatesAndIds':True,'statusCounts':dict(collections.Counter(x[4] for x in actual)),'pairsInWorkbookOrder':[x[1] for x in expected],'savedCompletionIds':[x['id'] for x in sqlrecords],'first':actual[0],'last':actual[-1]};(r/'dense-comparison.json').write_text(json.dumps(out,indent=2));print('PASS112/24/2632/1272/642/730/630/630/1990;1902exact SQL dates and all workbook identity/order/date bindings')
