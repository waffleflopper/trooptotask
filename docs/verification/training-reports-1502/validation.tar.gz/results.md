# Slice 1502 accepted local checks

Candidate source is revision `1760b89ce58b40ffe2b505a82da0bf076ec61353` plus source.patch. The patch contains all nine changed Training source/test files, including the three new files. Domain wording is a separate non-executable change. The final production worker fingerprint includes the already-packaged baseline archive, source and existing driving recipes; later final/validation archives are packaging only.

Commands all used the Node24 prefix and non-secret environment in runtime.txt.

- npm run format PASS.
- npm run gate PASS. Format check, lint, governance, Svelte/type checking and tests all completed. 661 files / 6,456 tests; zero type errors/warnings.
- npm run build PASS with synthetic unreachable provider settings.
- Parent focused model/status/filter/clock checks PASS, 136 tests / 4 files. That command included a nonexistent server test filename, so it did not supply the intended server-query evidence. The correctly named src/features/training/server/trainingReportsQuery.server.test.ts then passed separately (9 tests / 1 file). Earlier pre-review parent-focused.log covered5 files / 143 tests before the two new fixture tests.
- Touched retained-domain Markdown formatting PASS; final acceptance Markdown/link/whitespace check is recorded separately.

Warnings retained in accepted logs: three existing mutable Map/Set Svelte lint warnings;418 historical governance findings, regression gate passed; minified chunk-size warning; optional @opentelemetry/api resolution warning. The test suite's intentional bad-revision fixture prints a fatal Git line, but all tests pass. No gate, test, assertion, scan, suppression or budget was weakened.

The pure model tests derive forecast parity separately through getTrainingStatus at each future date. Literal fixtures protect leap/DST calendar boundaries, expiration-only/never-expiring and applicability/exemption cases, display rounding versus exact bands/drop/cliff/dominance/gap/focus thresholds, earliest ties, overlapping-union suppression, selected population/filter and empty-denominator semantics. What-if fixtures independently renew literal person/type pairs and rebuild. Scope checks distinguish a valid empty list from invalid/stale null and cover sorting/selected focus identities. Added fixtures separate170/201 from 169/200 despite displayed 85%, distinguish2/2 CPR loss from 5/8 while unrelated requirements change the total-row denominator, and freeze input while exercising both public functions.

Offline performance is a bounded source probe, not production journey latency. benchmark-1502.mjs loads the actual module through Vite middleware mode, without an HTTP listener, browser or database. Identical generated workloads use2 warmups / 5 samples. --before-concentration-fix projects only the old concentratedRows loop in memory. Final source SHA and projected SHA are retained in logs. The unusual2,048 people / 20 types, all missing with distinct duty roles case improves from411.16 ms to 40.37 ms median. The150 people / 20 types / 6 groups case was9.91 ms / 9.64 ms;4,000 people / 25 types / 50 groups was308.88 ms / 310.65 ms. These timings are parent measurements, not writer claims. No timing budget or app-network claim was inferred. Other per-column ledger scans remain bounded by selected columns and output grid size.

No new database migration, provider authorization, route, API contract, catalog read or export path changed in 1502. The completed 1501 database fresh/upgrade evidence remains applicable to unchanged SQL. Remote production was neither accessed nor modified. New model integration, visible forecast/grid/focus/details and redesigned exports are deferred 1503/1504.

Deslop was not installed. Parent directly checked unnecessary layers, dead paths, broad casts, suppressions, stale consumers and unrelated changes. The new model is pure, uses the existing clock once per applicable person/type and introduces no request waterfall. One private ledger is not serialized; scope details rebuild from the same input and stable Person/Training Type identities.
