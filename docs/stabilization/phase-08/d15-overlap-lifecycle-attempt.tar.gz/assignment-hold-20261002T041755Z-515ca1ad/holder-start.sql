SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.personnel_onboardings
WHERE organization_id = '2136f91e-e059-4843-8985-fcba75f1ff2c'::uuid AND id = '3a175ee7-8fea-4aa2-a2f2-a95de88d5988'::uuid AND personnel_id = 'e5ad42ae-51e5-49a3-ac8f-665492cfac8f'::uuid AND template_id IS NULL AND status = 'in_progress' AND completed_at IS NULL AND cancelled_at IS NULL
FOR UPDATE;
SELECT json_build_object('event', 'ready');
