# D27 corrective verification

Tested application revision: `9bf37d57ce3913e0e9fd7974132f1a9382500a76`, owned worker 1, session `1f9a3e0d-29ea-44f9-9d49-b752077bd8ea`, candidate `64cc44c18a494610ad34910d2244dac60b666012c808a35fb8f3d2c8e24b7d43`, origin `http://127.0.0.1:45815`. T3 preview navigated through its environment-port target to `http://localhost:45815`. Actual browser: Chrome 152.0.7977.130 / Electron 44.4.2 / T3Code 0.0.46-nightly.20261004.2657; Node 24.21.0/npm 11.12.0; America/Anchorage, October 4/5, 2026. The launcher's provisioned Chromium 152.0.7977.82 profile did not drive these observations. Current developer instructions required T3 preview controls. No production database was accessed.

Before correction, all three actual-factory Dashboard cases fail with the exact missing-roster error. The Starter route's actual selector fails owner/configurator orientation creation. After correction, Dashboard/provider/report checks pass four suites / 25 tests; Starter checks pass two suites / 18 tests; types report zero errors/warnings. Initial launch became stale during formatting and earned no live credit. Fresh launch and before/final doctor identify the corrected frozen candidate.

Normal visible sign-in, What's New dismissal and Home/reload were performed for each synthetic actor:

- dashboardView: expected and observed 3/4 present, Training currency 25%, evaluations 2 overdue/1 due, packet 67%; ordinary page-data Critical Tasks 1/7 = 14%.
- dashboardScoped: expected and observed 2/2 present, Training currency 50%, packet 67%; page-data Critical Tasks 1/4 = 25%.
- dashboardEmpty: expected and observed settled 0/0 with no scoped facts; page-data Critical Tasks 0/0 = 0%.

All three lack the Dashboard load-error alert before and after reload. Screenshots and visible text accompany separately identified authenticated page-data. No visible Critical Tasks card exists in the compact Overview.

Starter API/provider proof: dashboardEmpty's ordinary POST returns 403; Types/Templates/Steps remain identical. The normally signed-in owner POST returns 200, seven created and zero failed. Readbacks show two Training types, one template and four steps; Complete unit orientation is a Training step linked by exact ID to Unit Orientation. Reload and reapply return 200, zero created, seven skipped and zero failed. Exact after/reapply rowsets match and all original rows remain unchanged. No rendered Apply control exists; this establishes endpoint/provider behavior, not native Apply interaction.

Cleanup uses the owner's ordinary DELETE endpoints for only the seven recorded new Starter rows, all returning 200. Readbacks equal exact pre-apply rowsets. clean-seeds removes the journaled Dashboard cohort; final doctor and owned cleanup pass. Captures survive disposal.

Tool recovery: sign-out lands on the public root, so waiting for sign-in fields timed out. Explicit /auth/login navigation and a fresh snapshot recovered. An attempted npm verify:app seed command was unsupported; the documented control.mjs seed succeeded. Neither attempt earns behavior credit.

Session access/refresh values were redacted at their flattened page-data array slots before saving (two per response, six total). No passwords, cookies or credential headers were saved. Synthetic source IDs remain. Newly unrun full-map source-failure, foreign/switch and deeper consumer paths retain only their applicable unchanged historical evidence. Independent acceptance must read the expanded observations and complete corrective diff. No hosted parity or performance improvement is claimed.
