window.__compact = (c) => ({
	w: c.svg.w, theme: c.theme, anchor: c.goal.anchor, goalBox: c.goal.box,
	lineThroughGlyphCells: c.lineHits.map((l) => l.glyphsTouched).join(''),
	lineBeforeGoal: c.lineHits.every((l) => l.drawnBeforeGoal), areaBeforeGoal: c.areaInfo.every((a) => a.drawnBeforeGoal),
	laterMarksOnGoal: c.marksNearGoal.filter((m) => m.drawnAfterGoal).map((m) => `${m.tag}:${m.text ?? m.cls}:${m.glyphsTouched}`),
	underGoal: c.marksNearGoal.filter((m) => !m.drawnAfterGoal).map((m) => `${m.tag}:${m.cls.slice(0, 20)}`),
	halo: `${c.goal.strokeWidth}/${c.goal.paintOrder}/${c.goal.linejoin}/${c.goal.stroke === c.goal.bg}`,
	captionAbove: c.caption?.aboveSvg ?? null, caption: c.caption?.text,
	textOverlaps: c.textOverlaps, textOverBars: c.textOverBars, outside: c.outside,
	labels: c.texts.filter((t) => !/^\d+%$/.test(t) || true).join(' '),
	srCount: c.srRows.length, srTail: c.srRows.slice(-2)
});
window.__sweep = async (horizons = [30, 60, 90, 180]) => {
	const out = [];
	for (const h of horizons) {
		const radio = document.querySelector(`[role=radio][aria-label="${h} days"]`) || [...document.querySelectorAll('[role=radio]')].find((r) => r.textContent.trim() === `${h} D`);
		radio.click();
		const t0 = performance.now();
		let ok = false;
		while (performance.now() - t0 < 8000) {
			await new Promise((r) => setTimeout(r, 150));
			const heading = document.querySelector('[data-testid=training-briefing-forecast]')?.closest('section')?.innerText || document.body.innerText;
			if (radio.getAttribute('aria-checked') === 'true' && heading.includes(`NEXT ${h} DAYS`) && !document.querySelector('[aria-busy=true]')) { ok = true; break; }
		}
		await new Promise((r) => setTimeout(r, 300));
		const bl = [...document.querySelectorAll('section')].find((s) => s.innerText.startsWith('Bottom line'))?.innerText.split('\n').filter(Boolean).slice(1, 7).join(' ');
		out.push({ h, stable: ok, url: location.search, bl, ...window.__compact(window.__census()) });
	}
	return out;
};
'sweep installed'
