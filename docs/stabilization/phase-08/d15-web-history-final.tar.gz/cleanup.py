from drive import *
import importlib.util,hashlib
control(['clean-seeds'],'clean-seeds')
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  now=control(['rows',table,org],'restored-'+table+'-'+org)['rows'];old=json.loads((E/('original-'+table+'-'+org+'.json')).read_text())['rows'];assert {r['id']:r for r in now}=={r['id']:r for r in old},(org,table)
 for seedname in ['history-seed','legacy-seed']:
  file=E/(seedname+'.json')
  if not file.exists():continue
  seed=json.loads(file.read_text());people=seed.get('people',[seed['person']] if 'person' in seed else [])
  for person in people:
   if person['organization_id']==json.loads((E/'fixture.json').read_text())['ids'][org]:
    assert control(['rows','personnel',org,'id',person['id']],'absent-'+person['id'])['count']==0
(E/'restoration-comparison.json').write_text(json.dumps({'result':'PASS','scope':'Exact selected A/B parent/progress/Training fields, including original March note/history; row timestamps outside selected fields are not claimed.','temporaryPersonsRemoved':True},indent=2)+'\n')
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1');ledger=json.loads((private/'verify-trooptotask-owned.json').read_text());assert not ledger['seeded'] and not ledger['grants'];(E/'ledger-clean.json').write_text(json.dumps({'seeded':ledger['seeded'],'grants':ledger['grants']},indent=2)+'\n')
frozen=json.loads((E/'prelaunch-input-hashes.json').read_text());assert all((not (ROOT/r['path']).exists()) if r.get('deleted') else hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in frozen['entries']);(E/'postrun-input-comparison.json').write_text(json.dumps({'result':'PASS','inputs':len(frozen['entries']),'candidate':frozen['candidate'],'revision':frozen['revision']},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('owned_env',ROOT/'scripts/verification/environment.py');env=importlib.util.module_from_spec(spec);spec.loader.exec_module(env);state,workdir,environ=env.owned(env.private_session(str(private)));status=env.status(private);project=state['project'];records=env.containers(state,workdir,environ)
(E/'owned-provider.json').write_text(json.dumps({'project':project,'ports':status['ports'],'config_sha256':state['config_sha256'],'session':str(private),'workdir':str(workdir),'containers':[{'id':c['Id'],'name':c['Name'],'running':c['State']['Running'],'labels':{k:c['Config']['Labels'][k] for k in ['com.supabase.cli.project','com.docker.compose.project']}} for c in records]},indent=2)+'\n')
for action in ['doctor','cleanup']:
 command=['npm','run','--silent','verify:app','--',action,'--worker','1'];(E/(action+'-final-command.json')).write_text(json.dumps(command,indent=2)+'\n');r=subprocess.run(command,text=True,capture_output=True);(E/(action+'-final.json')).write_text(r.stdout);(E/(action+'-final-stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stderr or r.stdout
resources={}
for kind in ['container','volume','network']:
 command=['docker',kind,'ls']+(['-a'] if kind=='container' else [])+['--filter','label=com.supabase.cli.project='+project,'--format','{{json .}}'];(E/(kind+'-empty-command.json')).write_text(json.dumps(command,indent=2)+'\n');r=subprocess.run(command,env=environ,text=True,capture_output=True);assert r.returncode==0,r.stderr;resources[kind]=[json.loads(line) for line in r.stdout.splitlines() if line.strip()];assert not resources[kind]
resources['privateWorkerExists']=private.exists();assert not private.exists();(E/'owned-project-empty.json').write_text(json.dumps({'project':project,'resources':resources},indent=2)+'\n')
print('Original selected fields restored; temporary Persons absent; frozen inputs unchanged; empty ledger, final doctor and exact owned disposal pass.')
