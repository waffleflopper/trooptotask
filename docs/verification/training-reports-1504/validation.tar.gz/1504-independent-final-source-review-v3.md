# Independent final source review v3 — #1504 / PR1511

## Bounded verdict

**Source/spec/consumer acceptance PASS for the interaction correction at `77b55954cd1545814e1581e9d54e254d43c9c14b` relative to reviewed source `a586bf50289e92d995d0c1a681f9178030a10f61`, on base `ee1ca2b275d71cd0b9a51367b58c4754a687a443`. No actionable new source objection was found.** Report Retry now has a stable labelled focus target; controlled “no cell selected” is explicit and preserves omitted-prop consumer behavior; detail print uses the existing section-break contract. Native v6 Retry/selection and the corrected short/long PDFs remain pending evidence in this lane. This source acceptance does not certify their outcomes.

This is the sequential bounded follow-on to the actual v5 artifact audit. It is independent reasoning using the inherited parent model, not independent test/browser execution or model diversity. No browser, service, test, network, image/layout judgment, remote SQL, Git mutation, source/helper/recipe edit or nested delegation occurred. Sole new writes are this report and scratch `.verification/review-1504-final-source-v3-e8b17/`. Poteto generic persona and t2t-engineer apply under the parent's bounded authority; previously read AGENTS, Poteto full skill/prompt and relevant principle leaves, repository testing/DoD/contracts and normative issue amendments remain the reading map. The #1504/#1433 saved requirements were reread in the v5 artifact round. These workflows supply no new execution or lifecycle permission.

The user boundary remains finish clean local reviews, push the same **DRAFT** PR and STOP. No ready/monitor/Phase 08 integration or remote migration authority is inferred.

## Complete census and prior-pin reconciliation

Actual immutable Git bytes were reconciled, not assumed from prior filenames. The full cumulative PR now contains **145 physical paths: 52 added / 89 modified / 4 deleted**, including **22 archives** and **123 text/source paths including deletions**. This is two more physical paths than source v2's 143: the new v5 archive plus shared `operational-matrix/root.svelte`, which was unchanged versus main at a586 and now joins the cumulative changed-file census.

All 143 source-v2 base/a586 recorded size/hash/deletion pins match actual Git blobs. Of those prior paths, 139 retain identical head states (including all four deletions and the 21 old archives); four have the reviewed new bytes below. The shared root and v5 archive are the two newly counted paths. Every present changed working file matched its exact 77b559 blob when inspected, and all four deleted files remain absent. The inspected working tree was clean and HEAD exactly 77b559.

All **70 inherited-main access dependency** paths were separately reread from the immutable base, a586 and 77b559. Their prior recorded base/head pins match actual bytes, and every dependency head state is continuous from a586. They remain inherited-main changes rather than PR additions. Their authorization/provider/Group-scope review remains the pinned source-v2 reasoning, with no new delta here.

The source-v2 report remains 65,587 bytes / SHA256 `a59d7e2f4cee65b43eae768f47fa3936a444529d2ae7f5d6337b8d4199ea342e`; this report adds actual new implementation reasoning and does not rewrite its historical native-pending qualification. The v5 artifact report remains 26,499 bytes / SHA256 `29e9c4078e99874f22eb59dd994b6c372160434ee21f54c0637f10e14941c687`; its F1/F2 failures at a586 remain true historical evidence.

`a586..77b559` has six changed physical paths: five source/recipe deltas and one archive-only addition. `a799b5a4..77b559` is the four source files plus the recipe. The source/recipe delta serialization (`git diff --binary a586 77b559 -- src .agents/skills/verify-trooptotask/features/training-completions-reports.md`) is 31,253 bytes / SHA256 `9832c819d9882fb0e16a76a3ba8174ee050373981e6d0247f07ba7f96b0eb4a7`.

| Delta path | a586 bytes / SHA256 | 77b559 bytes / SHA256 | Review |
| --- | --- | --- | --- |
| `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | 31527 / `912b1e214fa71fc0f20deb8875db46f28bfa2c1bd6d608c581b092bf33762786` | 32102 / `fb3924708ca3c5a91cce6518db8265d458d6e50455584c05ab18ad8ff8ca0712` | Retry stable-region/no-steal and selected-state checks; short/long print checks. |
| `docs/verification/training-reports-1504/final-attempt-v5.tar.gz` | absent | 1755326 / `3227b88d8b18171dc5b9416a729d2252484e854cfbe0bdab7bca481ab1356aaf` | Archive bytes only; separately audited actual v5 artifacts at a586. |
| `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | 5890 / `e5d89a046aa2433e7753fd6d2016cd83eb34623490458f24512b26c0e920ccc2` | 5910 / `b279c8b2482ff74495785067e66270b977dcba000e93651d14bbe2ad14a7e443` | One existing data-print-section marker. |
| `src/features/training/components/TrainingReportsPage.svelte` | 23423 / `66da8b44ff387c1c5186b96f98714ad53e137fc0d783dbd14455e0c9481f1bc8` | 23651 / `bc112bec56ffe4c7be6a05a0f230d2c3bdc7c62aa4e0f1d36529ad8519b43d4d` | Explicit null selection, shared focusSection seam, stable briefing region including no-data branches. |
| `src/features/training/components/TrainingReportsPage.test.ts` | 21299 / `997369e5ff2244a57102bc0d40e05326ba4646034ab9f9750056df30f8dffb85` | 26068 / `08fc5ebfb02bedf95f36d9efa485c2a8969692ae9ecd65784eec20653a2b1c7c` | Five independently specified interaction tests; no CSS/geometry assertion. |
| `src/lib/components/ui/operational-matrix/root.svelte` | 2288 / `5b9920b0256003dc7a8d4d49024a3f206c5e0b0ee2e3c615f8128b2e917bd2fd` | 2456 / `975d2518edd5cdbe57f9f441f8031246cc1c9a954ba1faea59f8fabf4de191ed` | Nullable controlled-none prop; omitted/undefined behavior retained. |

The four continued deletions are `trainingReportScreenModel.ts`, its test, `trainingReportWorkbook.test.ts`, and the old export route `server.test.ts`. No old report owner, compatibility layer or export is reintroduced. Complete per-path base/a586/77b559 size/hash/deletion/working-state reconciliation is preserved in scratch `census.json`, with the 70 access dependencies listed separately. The earlier source report supplies the full original changed-path and inherited-dependency tables; this round independently validates their actual pins before reusing the prior reasoning.

## F1 correction: explicit Retry focus, persistent no-data region

At a586, both native report Retry click and Enter succeeded but ended at BODY because the alert's Retry control unmounted. The new `retryBriefing()` calls the unchanged `session.retry()` then the narrow `focusSection(BRIEFING_ID)` helper. That helper awaits Svelte `tick()` and focuses the DOM section. It reuses the existing detail-open/detail-Retry seam, now taking a section ID because there are two demonstrated targets.

The unchanged ReportWorkspace.Root renders a native `<section aria-label="Training readiness briefing">` and spreads HTML attributes. New `id="training-briefing"`, `tabindex=-1`, `aria-busy={loading}` and `outline-none` therefore reach the actual section. Root now wraps the no-types, no-applicable-requirements and ordinary briefing branches, so the focus target persists while loading and through either no-data result. No custom role, focus mirror, effect or new component abstraction is needed. Existing no-data titles/descriptions and Clear filters behavior remain identical; only the stable region encloses them.

Focus transfer occurs on the explicit Retry event after the removal tick, not in a response callback or effect. Normal filter/horizon changes continue to call `update()` without focus transfer. The unchanged session resolves/rejects requests, updates canonical controls/URL, cancels stale work and closes details as previously reviewed; no extra fetch, waterfall or post-response focus code was added. Thus a user who moves focus after Retry's initial focus transfer keeps it when the response arrives. Error/export alerts remain outside the stable region with their retained alert semantics.

The five new component tests include a deferred successful Retry that requires focus on the labelled region while busy and after the MOS response; a no-types result that keeps that same region focused; and a negative no-steal case where the user moves focus to 30 days during the deferred response. The no-steal case already passed before the fix and is correctly described as a guard against response autofocus, not a red reproduction.

The owner red log's no-data test title said “no applicable requirements,” but its actual fixture sets `filterOptions.types=[]` and expects “No training types configured.” Root renamed only the title to “no training types”; the current test accurately names its exercised branch. This is not evidence that the separate null-percent no-applicable branch was natively exercised. Source inspection establishes that both branches share the same unconditional root; no duplicate branch test is required to establish that structural ownership. Rendered no-data layout/print remains a later native acceptance question.

Disposition: F1 source implementation accepted at 77b559. V5 F1 remains OPEN at a586; successful native click/Enter Retry with loading/after focus and no-steal at the new pin is not certified by these component tests or source.

## F2 correction: null means controlled with no selection

The shared Root prop is now `selectedCell?: OperationalMatrixCellIdentity | null`, documented inline. `undefined`/omitted continues to select the internal click memory; an identity continues to select that identity; `null` selects no cell. The actual expression `selectedCell === undefined ? internalSelectedCell : (selectedCell ?? undefined)` normalizes controlled-null to the existing context's identity-or-undefined type. Context/types/cell code are byte-unchanged, so no nullable state leaks into other callers.

Training Reports now returns `null` whenever its open scope is not a cell (idle/closed detail or a Focus scope), and otherwise supplies the real row/type identity. Both its accessible label and the primitive's `data-selected` now resolve from the same controlled meaning. The selected flag remains true for an open cell's loading/error/loaded detail; closing/replacing that scope clears the selection. No dummy identity, remount key, local mirror, synchronization effect or styling-only workaround was added.

The shared cell still stores click memory and calls existing handlers, rejects disabled/read-only selection and emits the existing payload. Explicit per-cell `selected` behavior remains the unchanged OR in `isCellSelected`; Training Reports does not set that override. The new mode changes only callers that supply null. Independent searches of all imports/Root uses and `getOperationalMatrixContext`/selectedCell reads identify exactly these consumers:

| Consumer | Prop mode | Effect of this delta |
| --- | --- | --- |
| `TrainingReportsPage.svelte` | identity or explicit null | Controlled active cell / controlled no cell, matching detail ownership. |
| `TrainingMatrix.svelte` | omitted | Uncontrolled click memory retained. Existing status/edit callbacks and selected styles unchanged. |
| `IctMatrix.svelte` | omitted | Uncontrolled click memory retained; virtualized rows and task callbacks unchanged. |
| `IctReadinessMatrixTable.svelte` | omitted, cells readOnly | Uncontrolled default retained; no new actions or selected state introduced. |
| `OperationalMatrixTest.svelte` | controlled identity | Existing identity and callback behavior retained. |

No outside consumer directly calls `context.selectedCell()`. Only shared `cell.svelte` consumes `isCellSelected`. The three other production consumer files, controlled-identity test harness/test, context/types/cell and report-workspace dependencies were read and independently byte-compared at a586/77b559. They all remain identical; their actual hashes are in the consumer appendix below.

The two new report interaction tests first open an actual cell, establish its selected accessible name and data hook, then require removal after a successful horizon change or a Focus link opening. Focus replacement also checks the Focus link's `aria-current=true`. These independently express the native v5 bug and its untested adjacent scope-replacement contract. The data-selected hook is the shared selection-state contract driving the observed outline; this assertion checks that contract, not geometry or CSS copy. Expected names and state come from fixed fixture facts and the issue's scope meaning; they do not recompute expected selection with the implementation.

Disposition: F2 source implementation and affected-consumer compatibility accepted at 77b559. The old a586 stale-state observation remains preserved. Native click→horizon and click→Focus, plus actual new-pin absence of selected data/label/outline, remain future proof, not a source-review claim.

## F3 correction: existing detail section print marker

`TrainingAffectedSoldiersSection` adds only `data-print-section` to the existing native ReportWorkspace.Section. The unchanged Section forwards it onto the labelled section enclosing heading, controls, status/range, table and detail state. The existing scoped print rule in `src/app.css` applies `break-inside: avoid` to Training sections carrying that marker and to rows. All other briefing sections already use it.

This is the smallest implementation matching the section-print contract; no new CSS, geometry constants, row policy, table pagination, status presentation, data/export pipeline or PDF generator was added. The detail's loaded-page/range contract, disconnected/disabled pager focus guard and canonical 25/100 function binding are unchanged. The page's 30/60/90/180 and Group/MOS/Duty role getter bindings are also unchanged by this delta.

The marker plausibly keeps a short detail together, but source cannot prove a browser fragmentation result. A section taller than a page necessarily needs fragmentation; the existing row rule remains, and actual 25/100-row PDF text/metadata and delegated visual inspection must establish no missing rows, blank/truncated pages or heading-only fragments. Possible whitespace before a moved detail requires the same real PDF judgment. No mirror test of the presence of this CSS attribute was added to substitute for native acceptance.

Disposition: source correction accepted; **F3's corrected PDF outcome remains unestablished here**. Actual v5 PDF content still splits the short detail heading/status/range onto page 3 and table onto page 4. This report cannot close that historical visual finding or certify a future PDF.

## Recipe, retained contracts and performance

The recipe adds independent native requirements for report Retry focus during loading/after/no-data, no response steal after user focus movement, and selection clearing after filter/horizon or Focus replacement. Its print paragraph now expressly requires short heading/range/table cohesion and long-detail fragmentation without missing rows or header-only fragments. Existing native-print invocation-before-capture and exact URL binding requirements remain intact. The retained component-catalog print/primitive descriptions remain accurate; inline prop documentation explicitly defines the new null mode.

Every other source/model/route/query/provider/workbook/settings/migration state in the prior cumulative review is byte-continuous. The direct/reverse consumer and retained-contract conclusions therefore continue at their actual prior pins: policy admission before scoped reads, Group and Organization data boundaries, report model/filter/clock semantics, deterministic Focus and cell rederivation, page clamp, full-filtered workbook independent of open/narrow detail, TrainingStatusCell/record consumers, Dashboard currency and Onboarding record-existence meanings. This delta adds no auth bypass, data read, bulk load, extra request, new session state or expensive model work. Unchanged session cancellation/lifecycle code remains the reviewed owner of stale response protection.

The goal SQL remains `supabase/migrations/20261004100618_training_readiness_goal.sql`, **484 bytes**, SHA256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`. The four goal regression SQL files are continuous. Historical isolated fresh/upgrade receipts keep their own pins; no SQL or database command was executed here. Remote production application remains a separate release obligation.

## Actual saved red/green and required-check evidence

The owner report was read as a statement of intent; actual saved source/logs were separately inspected. Its four-file `source.diff` equals the actual a799→77b559 source delta after normalizing only diff header prefixes/index lines and the one corrected no-types test title. No unreviewed owner code delta is hidden by that reconciliation. The recipe is a separate root-owned reviewed change.

Actual owner `red.log` records **4 failed / 17 passed** in the 21-test page suite: ordinary Retry expected the briefing region but saw BODY; no-types Retry also saw BODY; horizon-close retained `data-selected=true`; cell→Focus retained one selected TD. The no-steal guard was part of the 17 passing cases. Actual green log records **3 files / 30 tests PASS** for the page and matrix suites. Actual broader suites log records **93 files / 661 tests PASS**; Svelte-check owner log records 0 errors/0 warnings and lint/format log is clean. Owner green uses the pre-rename no-data title; the current final title-only correction is covered by full v7.

Full root v7 execution records contain all **seven required commands with exit 0**, and their actual log outcomes are:

| Required command | Saved result |
| --- | --- |
| `npm run format` | exit 0 |
| `npm run format:check` | Prettier all matched files pass, exit 0 |
| `npm run lint` | 0 errors / 15 warnings, exit 0; warnings remain in unrelated retained/calendar/onboarding and older verification artifacts |
| `npm run governance:check` | regression checks PASS, exit 0; 201 recorded Phase 08 debt findings remain open against main |
| `npm run check` | Svelte-check 0 errors / 0 warnings, exit 0 |
| `npm run test -- --maxWorkers=4` | 689 files / **6889 tests PASS**, exit 0 |
| `npm run build` | production build PASS, exit 0 |

The test log's `fatal: bad revision '1234567890abcdef'` is the negative `scripts/ci/changes.test.ts:85` fixture that expects scope resolution to throw; the aggregate exits 0. It is not a failed native action or a clean-console proof. The actual v6 launch source checkpoint pins 77b559/base ee1, 145 paths, seven exit-0 checks, and a scoped source patch SHA256 independently reproduced as `216bd8d64ff20528e2a2e14c87efec8c985b4b1eb2216ee1c8b9e110a0395476`. Only that source/check binding was read from the new run; no native/PDF outcome is audited or certified here.

These are inspected saved executions, not reviewer-run tests. The tests meaningfully reproduce the four previously failing interaction cases and constrain the no-steal alternative; fixture builders supply response data but are not used as expected focus/selection oracles. Print has an explicit native acceptance boundary instead of a geometry/CSS mirror test.

## Findings and final limits

| Item | Severity / disposition at this pin |
| --- | --- |
| New actionable source bug in the correction | **None found** after all five source/recipe deltas and affected shared consumers were reviewed. |
| V5 F1 report Retry BODY | P3 historical failure at a586; source correction accepted at 77b559; new-pin native loading/after/no-data/no-steal proof pending. |
| V5 F2 stale selected TD | P3 historical failure at a586; source correction/consumer compatibility accepted at 77b559; new-pin native horizon/Focus proof pending. |
| V5 F3 short detail print split | P3 historical page split at a586; source marker accepted; new-pin short/25/100-row PDF contents and delegated visuals pending. |
| N1 unchecked radio Tab stop | Baseline not established; no new investigation or change, and no regression claim. |
| LayerCake/negative-rect console messages | Retained old-pin counterevidence; no clean-console or new-pin chart/PDF claim. |
| Whole-issue native acceptance and remote goal SQL | Separate gates; neither inferred from green source/tests nor performed by this lane. |

The implementation is source-review clean at the exact 77b559 pin. The fresh owned native run is required to close acceptance evidence, particularly pointer/Enter Retry before and after loading, user-moved focus, controlled selection clearing/reopening, no-data rendering and short/long print contents. That pending evidence is a verification limit, not an invented new source bug. The v5 artifacts and reports remain untouched and retain their genuine failures. This review authorizes no lifecycle expansion beyond the user's draft-push-and-stop boundary.

## Unchanged consumer/dependency hashes

These exact files were read and compared at a586 and 77b559; all are byte-identical and their working bytes matched 77b559 when inspected.

| Path | Bytes | SHA256 |
| --- | --- | --- |
| `src/features/critical-tasks/components/IctMatrix.svelte` | 15559 | `4d4fbc1417f856edf2ccf23770a5ae6c19d30a5471a0982c9a88e6877851d272` |
| `src/features/critical-tasks/components/IctReadinessMatrixTable.svelte` | 5933 | `70ae5a9f40d6024196271cb0226dfb1895f778a61d4fddf4b8bb45ad464b63da` |
| `src/features/training/components/TrainingMatrix.svelte` | 11398 | `c36e04aca73ddd84fdf6d464f1d7c33f699de15e8b51f55af85344a59b34731b` |
| `src/lib/components/ui/operational-matrix/OperationalMatrixTest.svelte` | 3394 | `68e363482aa4702b40ab7c0825a77efcb4fd7450bf33e06f2e5843f6aab894f2` |
| `src/lib/components/ui/operational-matrix/OperationalMatrix.test.ts` | 3098 | `ef04b68487c938864a367ce1d06cdcc9b1f2218af63611c748bbc2122923f19d` |
| `src/lib/components/ui/operational-matrix/context.ts` | 1153 | `27752ce1c597b8d3068f5f64c6ba5627d7ffd50b824c283af6ea65fb43332d51` |
| `src/lib/components/ui/operational-matrix/cell.svelte` | 2150 | `ccc90d5025d3055ff5dea862cea5e75671c3f47b0cf43d105f773d5e035f38cd` |
| `src/lib/components/ui/operational-matrix/types.ts` | 939 | `e62d5f9fa1d311f4f8d1297ad0e546b9052a579e9b5ab652487afe44409db70d` |
| `src/lib/components/ui/report-workspace/report-workspace-root.svelte` | 546 | `cc224212cbf54cca16dc68a79f6ef180bde77e64e1b09a8bbf7d6bb8a2db4101` |
| `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | 2752 | `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` |
| `src/lib/components/ui/report-workspace/report-workspace-state.svelte` | 1885 | `a978880a5b04ee73ea9ce8588d8199dc9189320ee708a38ada2aa291597f2490` |
| `src/app.css` | 14610 | `8536b4f70d589435a87181e445ab5a4d5e607e8351d855b049eade028b7683a8` |

## Evidence anchors

| Evidence | Bytes | SHA256 |
| --- | --- | --- |
| `.verification/1504-final-interaction-correction-owner-v1-report.md` | 9139 | `038927238eb02efb37c574516bd6b8639713b65dcf11250096f5810aa776a7dd` |
| `.verification/1504-final-interaction-correction-owner-v1/source.diff` | 11566 | `770e85094c32c10eda444b60d1d159069cb5439ae55b3b58d5730740ede6f8bd` |
| `.verification/1504-final-interaction-correction-owner-v1/red.log` | 172218 | `6be3208cd178ed7c030f96a5e6b0b249cfc952a7e30a905bb2f1e12ef420814d` |
| `.verification/1504-final-interaction-correction-owner-v1/green.log` | 262 | `44e29b7d5480e97656108f401f6d5fbe92dc029153fcb0ccc4bc12ffb975a17e` |
| `.verification/1504-final-interaction-correction-owner-v1/suites.log` | 181 | `a17c53ea497053221c04975b87a2d99a73e8d373698a70737be140c78e6db9ea` |
| `.verification/1504-v7-required-checks.json` | 1192 | `aa039c9b4199b62e3d5219da8bf283a54924cd2586d9229d307ccb287814fc94` |
| `.verification/1504-v7-test.log` | 370 | `75f4e3aa5a7cbcf125cda3b57b7a8495cee916043bdf5b000e0307087a3e44d5` |
| `.verification/1504-v7-check.log` | 273 | `f8ae14b6c8ccf1cb89ee4a5d9d74406bdbe4708b1c5853325f456d8bcad1f770` |
| `.verification/1504-v7-lint.log` | 3629 | `a4864f93caaa1c41c520fb657ee8fd02a509b34f5e10722c086d65c01369997d` |
| `.verification/1504-v7-build.log` | 139012 | `dad4c88d39d08aa15938d6b2191035c1c32ca837c2af4fa5ad3c11e08264cd57` |
| `.verification/evidence/verify-trooptotask/1504-final-v6/root-source-checkpoint.json` | 35122 | `a17dbcd0dc5d4409ee4d9cdbdbf608238290ddf99954fa9ccd9b61a58dbdb4bf` |
| `.verification/review-1504-final-source-v3-e8b17/census.json` | 123616 | `8dbab54c3e3278a9ac9a0ba148d5d9990a51afc7711025d45726abfeadbb6796` |
| `.verification/review-1504-final-source-v3-e8b17/owner-diff-reconciliation.json` | 362 | `00d0690b0b689f5dd969e0670a407c58d88a0287d4f4a907997cc975565f7372` |
