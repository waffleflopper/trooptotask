#!/usr/bin/env bash
# runprobe.sh NAME PAGE path...  -> saves full JSON to E/NAME.json, decodes xlsx bodies
E=.verification/evidence/verify-trooptotask/1504-baseline-v1; n=$1; shift
$E/r.sh $n "read-only same-origin GET probes (HTTP proof, separate from UI)" -- npm run --silent verify:app -- tool evaluate_script "$(python3 $E/mkprobe.py "$@")" >/dev/null
python3 - "$E" "$n" <<'PY'
import sys,re,json,base64,subprocess
E,n=sys.argv[1],sys.argv[2]; s=open(f'{E}/receipts/{n}.stdout').read()
m=re.search(r'```json\n(.*)\n```',json.loads(s)['content'][0]['text'],re.S) if s.strip().startswith('{') else None
if not m: print(s[:1500]); sys.exit()
d=json.loads(m.group(1)); 
for i,x in enumerate(d):
  b=x['body']
  if isinstance(b,dict) and 'b64' in b:
    p=f'{E}/{n}-{i}.xlsx'; open(p,'wb').write(base64.b64decode(b.pop('b64'))); b['savedAs']=p
    dec=json.loads(subprocess.run(['python3',f'{E}/decode_xlsx.py',p],capture_output=True,text=True).stdout)[0]
    b['decoded']={k:[list(r.values()) for r in v] for k,v in dec['sheets'].items()}
json.dump(d,open(f'{E}/{n}.json','w'),indent=1)
for x in d:
  b=x['body']; summ = b.get('decoded') if isinstance(b,dict) and 'decoded' in b else (b.get('briefing',{}).get('bottomLine') if isinstance(b,dict) and 'briefing' in b else b)
  print(x['status'], x['path'].split('/api/')[-1], json.dumps(summ)[:700])
PY
