from pathlib import Path
import sys,subprocess,json,os,hashlib,datetime,time
p=Path(__file__).resolve().parent
label=sys.argv[1];argv=sys.argv[2:]
overrides=json.loads((p/'temporary-allocation.json').read_text())['environment']
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
patch=subprocess.check_output(['git','diff','e674edcf0204e9a4e2e15a19d747cdd33c33a47c..HEAD'])
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/f'{label}.stdout').open('wb') as stdout, (p/f'{label}.stderr').open('wb') as stderr:
 result=subprocess.run(argv,stdout=stdout,stderr=stderr,env={**os.environ,**overrides})
record={'argv':argv,'cwd':str(Path.cwd()),'revision':revision,'patchSHA256':hashlib.sha256(patch).hexdigest(),'environment':overrides,'startedUTC':started,'durationSeconds':round(time.monotonic()-start,3),'exit':result.returncode}
(p/f'{label}.command.json').write_text(json.dumps(record,indent=2)+'\n')
print(label,'exit',result.returncode,'seconds',record['durationSeconds'])
for suffix in ['stdout','stderr']:
 lines=(p/f'{label}.{suffix}').read_text().splitlines()
 print(suffix,'\n'+'\n'.join(lines[-50:]))
sys.exit(result.returncode)
