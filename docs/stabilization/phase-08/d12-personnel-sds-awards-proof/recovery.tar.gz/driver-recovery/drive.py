import sys
from flow import call
label,kind,*args=sys.argv[1:]
call(label,kind,*args)
