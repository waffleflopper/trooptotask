from drive import *
import importlib.util, hashlib
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1')
command=['npm','run','--silent','verify:app','--','doctor']
(E/'doctor-initial-command.json').write_text(json.dumps(command,indent=2)+'\n')
r=subprocess.run(command,text=True,capture_output=True)
(E/'doctor-initial.json').write_text(r.stdout); (E/'doctor-initial-stderr.log').write_text(r.stderr)
assert r.returncode==0,r.stderr
spec=importlib.util.spec_from_file_location('owned_env',ROOT/'scripts/verification/environment.py'); env=importlib.util.module_from_spec(spec); spec.loader.exec_module(env)
state,workdir,environ=env.owned(env.private_session(str(private))); status=env.status(private)
records=env.containers(state,workdir,environ)
public={'project':state['project'],'ports':status['ports'],'config_sha256':state['config_sha256'],'session':str(private),'workdir':str(workdir),'containers':[{'id':c['Id'],'name':c['Name'],'running':c['State']['Running'],'labels':{k:c['Config']['Labels'][k] for k in ['com.supabase.cli.project','com.docker.compose.project']}} for c in records]}
(E/'owned-provider.json').write_text(json.dumps(public,indent=2)+'\n')
control(['fixture'],'fixture')
for org in ['orgA','orgB']:
 for short,table in [('packets','personnel_onboardings'),('progress','onboarding_step_progress'),('templates','onboarding_templates'),('definitions','onboarding_template_steps')]: control(['rows',table,org],'original-'+short+'-'+org)
actor=control(['actor','onboardingConfigure','onboarding/templates'],'configure-actor')
page=actor['pageId']; (E/'page-id.json').write_text(json.dumps({'pageId':page}))
print(snap(page,'configure-templates-initial'))
