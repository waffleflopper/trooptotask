import json,os,subprocess,sys,pathlib
name,args,label=sys.argv[1:]
env=dict(os.environ,PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH'])
r=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,args],text=True,capture_output=True,env=env)
p=pathlib.Path('.verification/evidence/verify-trooptotask/d21-settings-recovery')/(label+'.json');p.write_text(r.stdout)
if r.stderr: print(r.stderr,file=sys.stderr)
try:
 j=json.loads(r.stdout)
 for c in j.get('content',[]):
  if c.get('type')=='text':
   value=c['text'];print(value if name!='take_snapshot' else '\n'.join(value.splitlines()[-50:]))
except Exception:print(r.stdout)
sys.exit(r.returncode)
