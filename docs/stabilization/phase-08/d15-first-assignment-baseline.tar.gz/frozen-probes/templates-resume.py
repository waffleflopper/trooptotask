from drive import *
page=json.loads((E/'page-id.json').read_text())['pageId']; seed=json.loads((E/'legacy-seed.json').read_text())
s=snap(page,'orientation-A-resume'); click(page,uid(s,'button "Save Changes"'),'orientation-A-save')
print(snap(page,'template-A-final')); screen(page,'template-A-final')
for letter in ['B']:
 if letter=='B':
  s=snap(page,'duplicate-b-before'); click(page,uid(s,'button "Duplicate Verification Onboarding A"'),'duplicate-b-submit')
 s=snap(page,'rename-'+letter+'-before'); click(page,uid(s,'button "Edit Verification Onboarding A Copy"'),'rename-'+letter+'-open')
 s=snap(page,'rename-'+letter+'-dialog'); fill(page,uid(s,'textbox "Name"'),'D15 Assignment Race '+letter+' '+seed['tag'],'rename-'+letter+'-fill')
 s=snap(page,'rename-'+letter+'-filled'); click(page,uid(s,'button "Save"'),'rename-'+letter+'-save')
 s=snap(page,'orientation-'+letter+'-before'); click(page,uid(s,'button "Edit Verification Orientation"'),'orientation-'+letter+'-open')
 s=snap(page,'orientation-'+letter+'-dialog'); print(s)
 if 'textbox "Name"' in s: field='textbox "Name"'
 else: field='textbox "Step Name"'
 fill(page,uid(s,field),'Orientation','orientation-'+letter+'-fill')
 s=snap(page,'orientation-'+letter+'-filled'); click(page,uid(s,'button "Save Changes"'),'orientation-'+letter+'-save')
 print(snap(page,'template-'+letter+'-final')); screen(page,'template-'+letter+'-final')
templates=control(['rows','onboarding_templates','orgA'],'prepared-templates')['rows']
s=snap(page,'orientation-A-resume'); click(page,uid(s,'button "Save Changes"'),'orientation-A-save')
print(snap(page,'template-A-final')); screen(page,'template-A-final')
for letter in ['B']:
 match=[t for t in templates if t['name']=='D15 Assignment Race '+letter+' '+seed['tag']]; assert len(match)==1
 body={'onboardingId':seed['packets'][0]['id'],'newTemplateId':match[0]['id']}
 (E/('request-'+letter.lower()+'.json')).write_text(json.dumps(body,indent=2)+'\n')
 control(['rows','onboarding_template_steps','orgA','template_id',match[0]['id']],'prepared-definitions-'+letter)
control(['rows','personnel_onboardings','orgA','id',seed['packets'][0]['id']],'prepared-parent')
control(['rows','onboarding_step_progress','orgA','onboarding_id',seed['packets'][0]['id']],'prepared-progress')
