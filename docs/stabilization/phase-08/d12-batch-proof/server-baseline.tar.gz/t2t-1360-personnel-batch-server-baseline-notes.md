# D12 batch/backfill server baseline

Base: 480e1e5142beb3b3a3667b6f956cef78a99a70d6, the merged #1445 tree.
Worktree: /tmp/t2t-1360-personnel-batch-server.
Branch: stabilization/1360-personnel-batch-server.

Only the three assigned existing test files changed. Production source is unchanged. No service, browser, database, migration or publication operation ran.

The final focused command was npm run test -- src/lib/server/core/useCases/personnelBatch.test.ts src/lib/server/core/useCases/personnelMergeBatch.test.ts src/lib/server/adapters/supabaseDataStore.test.ts, with synthetic PUBLIC_SUPABASE_URL=http://127.0.0.1:1 and PUBLIC_SUPABASE_ANON_KEY=offline-anon-key. The URL was not contacted: the adapter uses its arranged mocked HTTP transport and the operation cases use fake providers.

Actual result: 3 test files, 41 tests, 5 failed and 36 passed. All 35 preexisting tests passed. New separate-request same-value replay passed.

Failing baseline cases:

- Hidden Bravo canonical slug: ordinary Alpha reads omit Bravo; the atomic fake checks all uniqueness before any insertion. Current operation raises the uniqueness error, returns no result, creates neither Alpha Person (including the unrelated Rivera name), preserves the complete hidden row, and emits no success audit. The expected future result preserves Rivera's unsuffixed name and advances only Smith to smith-jamie-2.
- Partial date-backfill failure: first Person persisted and acknowledged; failure before the second update aborts with a raw internal error and discards accumulated response/audit. Saved fields and IDs prove the first change and unchanged second row. A separate restored request already skips the applied first row and updates the second; current missing indexed/unconfirmed response and missing first audit remain failing requirements.
- Equal repeated rows with fresh returned objects: current result contains two updates and no skip, because the original matching snapshot does not receive acknowledged dates.
- X -> Y -> X with a blank later DEROS: current final ETS remains Y; second row skips against initial X. File-order handling is the coordinator's newly explicit routine sequential rule, not historical approval. The expected final ETS is X; blank DEROS preserves the latest acknowledged DEROS. Returned update history must contain both distinct accepted dates, without changing ID or other fields.
- Real Supabase adapter plus mocked HTTP transport: current error loses code/details, preventing precise collision-candidate recovery. Existing rethrowOrWrap still returns generic HTTP 500 without provider constraint/slug disclosure; the privacy assertions pass.

Durable outputs:

- /tmp/t2t-1360-personnel-batch-baseline-final.txt: final focused failing output.
- /tmp/t2t-1360-personnel-batch-baseline.txt: earlier same five behavior failures before test-only typing correction.
- /tmp/t2t-1360-personnel-batch-baseline-types.txt: initial check exposed only a test reference to AuditPort.events, corrected to the existing auditPort.events seam.
- /tmp/t2t-1360-personnel-batch-baseline-types-final.txt: corrected check, 0 errors/0 warnings.
- /tmp/t2t-1360-personnel-batch-baseline-types-committed-inputs.txt: final frozen-test-input type check.

Focused ESLint, Prettier check and git diff --check pass. The temporary missing-brace authoring error was corrected before the first executable regression run. No full gate/build/live provider enforcement is claimed by this worker baseline. The atomic and failure timing models are controlled port behavior, not SQL execution or observed production outages.

Next work waits for the coordinator's portable contracts and explicit repair brief. Preserve ordinary request-user scope, one healthy bulk insert, bounded confirmed-candidate retries, numeric URLs, safe indexed unconfirmed update errors, update-only catch and normal audit. Do not reinterpret intentional validation/matching per-row results as defects, introduce transactional promises, broaden privileges or move another issue.
