# Proposed focused final native selection

No app, native browser or production build was launched in this source/lower stage. Root reviews this proposal before a separately owned final stage.

## Required affected proof

Use one fresh owned worker1 and one verify:app production build after freezing the accepted merged source, controls and recipes. Reuse the maintained dense print/report fixture only. Select Dense/PFC/MOS68V/90-day through native controls, then download the whole workbook through native Export. Observe the real report body and exact ordinary provider rows separately. Preserve actual candidate, IDs, role, literal day, seed tag and request ID. Do not recreate a request when the supported same-request full-body capture suffices.

Independent fresh setup facts must show112 People,24 Types,1902 saved Completions and the matching applicability rules. Verify all1902 saved IDs/dates and all1990 affected workbook rows with exact Person/Type pair identities, canonical order and dates. Independently derive2632 applicable,1272 ready now,642 ready at90-day horizon,730 missing,630 expired and630 lapsing at matching inputs. Never use1892 as the completion count. Existing original baseline People/Types are excluded by the PFC/MOS/view input, with actual scope/input facts recorded. The fresh literal dates are based on its recorded day and fixture offsets, not blindly copied from an earlier session.

This is the smallest useful real-provider adjacency to the paging repair. It exercises changed catalog and Completion page ordering with more than1000 saved records through the actual report/workbook path. The lower installed-SDK tests already prove all ten projected query contracts under tied sorts, physical order drift and later-page errors, so no1001-Type UI fixture, normal26-page repeat, extra batching, reverse-consumer matrix or fresh PDF is required.

Restore all controls, complete cohort-dependent comparisons, then supported journal cleanup. Compare original captured fields/key sets and every temporary ID; doctor, supported cleanup and actual PID/start/group/ports/containers/directory/preexisting-resource closure precede root packaging. Root owns packaging, review, CI and publication.

## Reuse with exact behavior bindings

The shared error merge retains public behavior for Training's real inputs. Completion/Batch intended local failures become shared RequestFailure values. Before the merge their explicit statuses were recognized by the old boundary; after the merge the same400/404 statuses/reasons are recognized by class identity. Current operation-to-delivery tests prove400/404 and Batch400, and stored rows/audits remain unchanged on a provider spoof404 rendered generic500. Shared policy denial remains403; actual Svelte HttpErrors/redirects remain forwarded. Current main's shared boundary tests prove untrusted provider status is not authority.

The real Catalog duplicate constraint rejection remains an untrusted Error without status. Both old and new boundary yield generic500, and Catalog mapping, route, component and editor logic are unchanged. Therefore reuse4e84 native duplicate-name error/draft/correction/retry; do not replay a genuine500 only because main merged. Reuse4e84 ordinary scoped/None/foreign403/404, root93ab failed-save lifetime/Cancel proof and#1562 retired-editor proof with their source/input bindings. No controlled503, Offline/lazy emulator replacement, new rare status matrix or closed-editor replay.

Certificate behavior needs no new native replay. Native repeat and mixed imports at4e84 omit certificate, acknowledge200, retain saved ID7519577b-6647-4218-836f-c7c37284203b and full10 SQL fields including https://example.test/d28-ordinary. The installed SDK's completed payload columns omit certificate_url, id and created_at. Batch/upsert/mapping code is unchanged by this repair.

All59 protected Training UI/store/utility sources remain byte-exact against4e84. Reuse normal paging/filter/empty, CRUD/metadata, reverse consumers and accepted print artifact/layout proof with their original bindings. No fresh whole PDF, theme/paper sweep, Short/Empty PDF regeneration, six-part repeat or64-case replay. Historical control FAIL/UNRUN and deferred rank/absent native Starter Apply observations stay explicit. Purpose archive fixed-page/metadata/late-error proof is separate and does not assert stability under changing physical order for its preexisting unordered select* path.
