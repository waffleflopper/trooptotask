window.__m = () => {
	const host = document.querySelector('[data-testid="training-briefing-forecast"]');
	if (!host) return { error: 'no forecast' };
	const svg = host.querySelector('svg');
	if (!svg) return { error: 'no svg' };
	const R = (r) => ({ l: +r.left.toFixed(1), t: +r.top.toFixed(1), r: +r.right.toFixed(1), b: +r.bottom.toFixed(1) });
	const dist = (a, b) => {
		const dx = Math.max(0, b.l - a.r, a.l - b.r);
		const dy = Math.max(0, b.t - a.b, a.t - b.b);
		return Math.hypot(dx, dy);
	};
	const texts = [...svg.querySelectorAll('text')];
	const goalEl = texts.find((t) => /^Goal \d+%$/.test(t.textContent.trim()));
	if (!goalEl) return { error: 'no goal text' };
	const g = R(goalEl.getBoundingClientRect());
	const svgR = R(svg.getBoundingClientRect());
	const cs = getComputedStyle(goalEl);
	const ctx = document.createElement('canvas').getContext('2d');
	ctx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
	const tm = ctx.measureText(goalEl.textContent.trim());
	const marks = [];
	const ctm = (el, x, y) => new DOMPoint(x, y).matrixTransform(el.getScreenCTM());
	for (const p of svg.querySelectorAll('path')) {
		const cls = p.getAttribute('class') || '';
		if (!/stroke-foreground|fill-foreground/.test(cls)) continue;
		const len = p.getTotalLength();
		let min = Infinity, maxX = -Infinity;
		for (let i = 0; i <= 400; i++) {
			const q = p.getPointAtLength((len * i) / 400);
			const s = ctm(p, q.x, q.y);
			maxX = Math.max(maxX, s.x);
			min = Math.min(min, dist(g, { l: s.x, r: s.x, t: s.y, b: s.y }));
		}
		const sw = parseFloat(getComputedStyle(p).strokeWidth) || 0;
		marks.push({ kind: /fill-foreground/.test(cls) ? 'area' : 'line', gap: +(min - (/fill-foreground/.test(cls) ? 0 : sw / 2)).toFixed(1), maxX: +maxX.toFixed(1) });
	}
	for (const c of svg.querySelectorAll('circle')) marks.push({ kind: 'dot', gap: +dist(g, R(c.getBoundingClientRect())).toFixed(1), rect: R(c.getBoundingClientRect()) });
	let band = null;
	for (const rc of svg.querySelectorAll('rect')) {
		const cls = rc.getAttribute('class') || '';
		if (!/fill-warning/.test(cls)) continue;
		const r = R(rc.getBoundingClientRect());
		if (r.r - r.l === 0 && r.b - r.t === 0) continue;
		const kind = /warning\/10/.test(cls) ? 'band' : 'bar';
		if (kind === 'band') band = r;
		marks.push({ kind, gap: +dist(g, r).toFixed(1), rect: r });
	}
	for (const t of texts) { if (t === goalEl) continue; const r = R(t.getBoundingClientRect()); marks.push({ kind: 'text:' + t.textContent.trim(), gap: +dist(g, r).toFixed(1), rect: r }); }
	const rule = svg.querySelector('.stroke-success');
	const ruleR = rule ? R(rule.getBoundingClientRect()) : null;
	const nearest = marks.sort((a, b) => a.gap - b.gap).slice(0, 4);
	const clipAnc = [];
	for (let el = svg; el && el !== document.body; el = el.parentElement) {
		const o = getComputedStyle(el);
		if (o.overflowX !== 'visible') { const r = el.getBoundingClientRect(); clipAnc.push({ tag: el.tagName, ov: o.overflowX, right: +r.right.toFixed(1), clipsGoal: r.right < g.r }); }
	}
	const checked = document.querySelector('[aria-label="Forecast horizon"] [aria-checked="true"]');
	return {
		vw: innerWidth, theme: document.documentElement.dataset.theme, horizon: checked?.textContent.trim(), url: location.search,
		goal: goalEl.textContent.trim(), goalRect: g, ruleY: ruleR ? +((ruleR.t + ruleR.b) / 2).toFixed(1) : null, textMidY: +((g.t + g.b) / 2).toFixed(1),
		ruleL: ruleR?.l, ruleR: ruleR?.r, svg: svgR, edgeSlack: +(svgR.r - g.r).toFixed(1), font: cs.fontFamily, fontSize: cs.fontSize, fill: cs.fill,
		measuredW: +tm.width.toFixed(1), boxW: +(g.r - g.l).toFixed(1), plexLoaded: document.fonts.check('11px "IBM Plex Mono"'),
		minGap: nearest[0]?.gap, nearest, band, bandOverrun: band && ruleR ? +(band.r - ruleR.r).toFixed(1) : null, clipAnc,
		sr: [...host.querySelectorAll('.sr-only tbody tr')].map((r) => r.textContent.replace(/\s+/g, ' ').trim()).slice(-2)
	};
};
window.__STATES = {
	ordinary: '',
	view: 'view=d5faffe6-67c1-4368-80ef-b4ac185757f9',
	mixed: 'view=d5faffe6-67c1-4368-80ef-b4ac185757f9&role=BriefingBoundaryacde5f6c',
	cliff: 'types=41a31da3-0f38-46e8-9df1-c491537aaf00',
	finalbucket: 'role=BriefingBoundaryacde5f6c&types=b4f06d13-e268-4e4d-b4e7-586eeb6b9816',
	flat100: 'role=Medic&types=75fb00cb-e32b-4ed3-b439-6d638e9514b3',
	nearEnd: 'mos=68W&role=BriefingBoundaryacde5f6c&types=f0f77e42-bf0d-4dc2-a3b0-a8edc7c0d120',
	atGoal: 'types=f6db63c5-b5f2-4742-abaa-337f5a0f72c7'
};
window.__go = async (qs) => {
	const a = document.createElement('a');
	a.href = location.pathname + (qs ? '?' + qs : '');
	a.setAttribute('data-drv', 'nav');
	document.body.appendChild(a);
	a.click();
	a.remove();
	await window.__wait(() => location.search === (qs ? '?' + qs : '') && window.__settled(), 10000);
	await new Promise((r) => setTimeout(r, 300));
};
window.__all = async (names) => {
	const rows = [];
	for (const n of names) {
		try {
			await window.__go(window.__STATES[n]);
			rows.push(...(await window.__sweep(n)));
		} catch (e) {
			rows.push({ state: n, error: String(e) });
		}
	}
	return rows;
};
window.__wait = async (pred, ms = 8000) => { const t0 = performance.now(); while (performance.now() - t0 < ms) { if (pred()) return true; await new Promise((r) => setTimeout(r, 100)); } return false; };
window.__settled = () => !/Updating briefing/.test(document.body.innerText) && !!document.querySelector('[data-testid="training-briefing-forecast"] svg text');
window.__go = async (qs) => { const a = document.createElement('a'); a.href = location.pathname + (qs ? '?' + qs : ''); document.body.appendChild(a); a.click(); a.remove(); await window.__wait(() => location.search === (qs ? '?' + qs : ''), 10000); await new Promise(r => setTimeout(r, 1500)); await window.__wait(() => window.__settled(), 10000); await new Promise(r => setTimeout(r, 300)); };
window.__sweep = async (state) => { const out = []; for (const name of ['30 days', '60 days', '90 days', '180 days']) { const radio = [...document.querySelectorAll('[role=radio]')].find((r) => r.textContent.trim() === name.replace(' days', ' D')); if (radio.getAttribute('aria-checked') !== 'true') { radio.click(); await new Promise(r => setTimeout(r, 300)); } await window.__wait(() => radio.getAttribute('aria-checked') === 'true' && window.__settled()); await new Promise((r) => setTimeout(r, 400)); const m = window.__m(); const bl = document.querySelector('main')?.innerText.match(/Bottom line\s+(\d+%)[\s\S]{0,40}?(\d+%)/); out.push({ state, url: location.search, bl: bl ? bl[1] + '>' + bl[2] : null, h: m.horizon, vw: m.vw, theme: m.theme, goal: m.goal, minGap: m.minGap, nearestKind: m.nearest?.[0]?.kind, edgeSlack: m.edgeSlack, boxW: m.boxW, measuredW: m.measuredW, plotW: m.ruleR - m.ruleL, bandOverrun: m.bandOverrun, dy: +(m.textMidY - m.ruleY).toFixed(1), clip: m.clipAnc.some((c) => c.clipsGoal), sr: m.sr }); } return out; };
window.__fmt = (rows) => rows.map(r => r.error ? JSON.stringify(r) : [r.state, r.h, r.bl, r.vw, r.theme, r.goal, 'gap', r.minGap, r.nearestKind, 'slack', r.edgeSlack, 'w', r.boxW, 'plot', +r.plotW.toFixed(1), 'band+', r.bandOverrun, 'dy', r.dy, r.clip ? 'CLIP' : '', r.sr.join('|')].join(' '));
window.__run = (names) => { window.__last = null; window.__all(names || Object.keys(window.__STATES)).then((r) => { window.__last = r; }, (e) => { window.__last = [{ error: String(e) }]; }); return 'started'; };

'installed';
