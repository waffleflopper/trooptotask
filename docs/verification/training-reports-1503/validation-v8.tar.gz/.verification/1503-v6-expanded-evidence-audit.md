# Issue 1503 v6 expanded evidence audit — nonvisual

**Artifact integrity: PASS within the saved-record boundaries below. Current product acceptance: UNAVAILABLE / all requested outcomes UNRUN.** The independent Claude task completed with no product verdict because native T3 input/snapshot delivery was unavailable. This audit does not convert form filling, HTTPS page loading, archive recovery, source/model calculations or prior failed evidence into native visual acceptance. No 1503 completion, release or publication approval is issued.

## Scope and authority

This bounded worker audited the entire inventory and expanded bytes of `docs/verification/training-reports-1503/visual-unavailable-v6.tar.gz`, all 61 indexed supported raw records, relevant actual native tool input/output, root restoration/ID/stop/absence records and the temporal qualification. Read-only artifact inspection and hashing were used; only this ignored report was written/formatted. No screenshot/image/Paper was opened; no appearance, layout, color, font, focus-visible or visual judgment was made. No app source, script, recipe or adapter was changed or executed; no browser, DB, service, test, staging, commit, publication or child agent was used. Same-provider artifact reading is not independent live execution or model diversity.

The existing complete v6 nonvisual source verdict remains separate. Its copied report is byte-identical to `.verification/1503-prefinal-source-review-v6.md`, SHA `4ead50efef86dfb2a8decd6b4b69b0bda1e51f525efbd0a572ef30f33db23529`. No new complete-source review is claimed here. Root reports source unchanged; the archived `SOURCE.patch` is byte-identical to the saved `.verification/1503-source-v6.patch` and hash-bound below. New browser-driving authorization is pending with the user; this worker did not choose a fallback or launch another worker.

## Exact archive and candidate binding

- Archive bytes: **254498**; SHA-256 **`8e44e2ba1a5005c74b977816ac1c0e6478fa13e3f2e3e162f99855dcc1ae6ff5`**.
- Expanded root: `.verification/packaged/1503/visual-unavailable-v6/`.
- Base: `0fa2960956572a8f5dea2de2ab5c8d4893178589`.
- Merged HEAD/revision: `3c0b6f2a9cb4e923ba86d0dda2a698c5e255a04c`.
- Source/scripts/SQL patch: `eab7bf70b31c2715772984ada6fe1721e72b86957541dcdcce4e5ec2a4c992bd`.
- Worker candidate: `67cd9d795d2de52bbd5cd9db1718e44e8465085f4338fc68e95cb0c3445e1112`.
- Owned session: `223a5780-ad58-4738-92f0-703a634ce774`, worker 1.
- Source digest: `88e721a75e75128717fd72e9e46af216e045cace67c23817f73bda982b6ddc7c`.
- Build digest: `d884c0d56958ac6461ea74e83ef386b33c5cc8d4f5be2ada8997028a2a5e8f8a`.
- Scratch adapter digest: `aac7a76e5e1abcf14f9edc187cda8fe6869dc3f758a8aff67eafd757d97f84b0`.
- Primary owned origin: `http://127.0.0.1:36443`; observed public origin: `https://omarchy.tail930090.ts.net:18031`.
- Mechanical cookie namespace: `t2t_verify_223a5780ad58473892f0703a634ce774_`.

All common candidate/revision/session/origin/source/build/adapter/cookie-prefix fields in the six saved start/check receipts match `SOURCE-BINDING.json`. Root/driver doctors and launch match the same candidate, revision and session. This links transport to the frozen candidate; browser actions themselves use tab IDs/origin, not an embedded source digest. Actual preview-list position59 binds tab5 to this exact delegated thread and `profileId: default`, not a separate provisioned browser profile.

`TASK-RESULT.json` records provider `claudeAgent`, model `claude-opus-5-5`, terminal `completed`, result available and no pending child runs for delegated task `1503-final-chart-acceptance-v6`. Terminal task completion is not acceptance success. `ANNOTATION-AUTHOR` artifacts are source/census predictions with their existing limits; no visual interpretation or re-verdict is made from them.

## Complete inventory and supported recovery

The inventory contains **126 unique payload paths**. Every payload's full current SHA-256 matches its inventory entry. The expanded directory has exactly these 126 plus `inventory.json`; no extra or missing file exists. The tar has **127 regular files**, no links, and every member is byte-for-byte equal to its expanded counterpart. All payloads decode as text; every JSON payload parses. Counts are 47 top-level, 6 adapter-static, 12 driver, 18 supported-command and 43 supported-raw payloads. There is no successful screenshot or workbook payload in this archive.

Inventory SHA: `46a6ce68765dbdb69115bed5ccd5adbc66451c0466846085077ba2f23457ce4d`. Supported index SHA: `34d558d1849c746f5955ce1508ff80b5d6139051dd485ed225d90f1d62df78d7`.

Root's recovery record reports 98 supported T3 activity items, including **43 actual dynamic-tool JSON records** and **18 separately labelled durable command texts**. This worker verified all 61 unique positions/itemIds/paths, byte counts, sanitized UTF-16 lengths and full hashes against that index. Each dynamic record parses as actual `toolName`, `input`, `output`; each JSON content string agrees with its structured output where both are present. Command text retains its command and durable stdout/stderr representation and is not recast as a complete MCP/API envelope. The original 98-item activity listing was not re-fetched by this bounded audit; the supported recovery's itemIds/index and saved actual records establish the available provenance.

Thirteen stored texts exceeded the initial 2000 UTF-16-unit limit and have recovered tails: positions **2,4,6,8,10,12,13,15,23,38,40,91,94**, maximum 30547 units. Index length/hash checks cover each recovered file. No current actual action is inferred from an older hand log, private provider JSONL or model-written summary. References to 108 intrinsically omitted console entries occur only in preserved prior-v5 history; they do not become newly recovered v6 console evidence. This round has no complete browser network/console collection, successful image snapshot, authenticated chart or exported workbook.

The 43 actual dynamic records consist of: 2 tool searches, 4 status calls, 3 open calls, 18 evaluate calls, 2 waits, 5 native clicks, 4 snapshots, 1 preview-list, 1 native key press, 1 resize and 2 tab closes. Tool availability and action acknowledgement are kept separate from page effects.

## Credential handling and redaction boundary

Exactly **two one-use carrier capability occurrences** are replaced with `[REDACTED_ONE_USE_CAPABILITY]`: command-text position28 (reading the private navigation expression) and actual evaluate position29 (the navigation input). Index original/sanitized UTF-16 lengths are 361 -> 326 and 362 -> 327, each with one occurrence. Their hashes attest sanitized bytes, not unredacted originals. No distinct-capability identity or original token can be reconstructed from these redactions; they represent the carrier URL appearing in the two recorded contexts.

The driver's redaction note identifies the carrier-navigation input and conditionally suggests redacting the later fill expression. Root retained the fill expression because it contains no literal credential or carrier capability: command position32 and actual evaluate position34 read `window.name`, clear it, parse its temporary actor data, check the exact origin/login path, assign email/password fields, dispatch only input/change events and return booleans. It contains no submit or login fetch. Actual position34 returns `{filled:true, carrierCleared:true}`; position38 returns `emailFilled:true`/`pwFilled:true`, without their values. The private relay body/password/cookies are not captured in the archived records. Later position82 explicitly clears `window.name`; protected-route observation81 also returns length0.

The full archived text scan found **zero matches** for JWT-like values, an unredacted long `/__t2t_1503_fill/` capability, private PEM material or a literal password/access-token/refresh-token/service-role assignment. This is a bounded pattern scan plus relevant actual-input inspection, not a universal proof that every possible secret format is absent. Root's package reports credential scan PASS. The retained credential-free expression is useful action provenance; neither it nor the fill booleans demonstrate authentication. Owned cleanup removes the private carrier/expression files as recorded below.

## Actual HTTPS page and native-host failure evidence

The six root/driver adapter start/check receipts record PASS with HTTP1 login true and native HTTP2 `{alpn:'h2', certificateVerified:true, status:200}` on the exact run. No certificate bypass, HTTP1 forcing, host rewrite or localhost browser fallback is reported. `TRANSPORT-CORRECTION.md` preserves the prior H2 authority defect, narrow scratch correction and then-current no-live-proof limitation. Actual v6 receipts add live public login transport proof to that older source-only correction; they do not add native chart acceptance.

Actual preview open21 loads the exact HTTPS `/auth/login` in tab5, with available true but **visible false**. Evaluate23 reports the same HTTPS origin, navigation protocol **h2**, Linux T3Code Nightly `0.0.46-nightly.20261004.2644`, Electron44.4.2 / Chrome152.0.7977.130, America/Anchorage, 1280x800, pixel ratio1.6000000238 and local date Oct3. This is actual browser-page protocol/environment evidence, not a Mac claim. Worker doctor metadata names a separate unprovisioned `/usr/bin/chromium` binary (152.0.7977.82); that metadata is not evidence that its browser performed the T3 actions.

Stage command26 returns PASS for `orgOwner`. Navigation evaluate29 returns a client error as its location replacement changes the context; subsequent wait31 finds the password field and evaluate34 successfully reads/clears the carrier and fills the form. The client error is preserved rather than called a failed relay; the later actual booleans support the fill, while carrier-file absence supports eventual cleanup. No actual credential or body was emitted.

The native input chain remains unsuccessful:

| Actual positions | Evidence and bounded conclusion                                                                                                                                                                                                                              |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 35,36            | First native Sign In locator call returns an acknowledgement; subsequent page observation still shows `/auth/login`, password field, no Organization page, `window.name` length0.                                                                            |
| 43,44,45         | Second submit-button locator call is acknowledged; waiting for `/org` times out after 10000ms. Resource observation shows only the static login image among non-immutable resources, and the page remains `/auth/login`.                                     |
| 49,51,52         | A diagnostic capture-phase click/submit observer is attached, then a third native Sign In locator call is acknowledged. Later `obs:[]`, login URL unchanged, resources still only the static login image.                                                    |
| 55,56            | Fourth native Sign In coordinate click is acknowledged. Later `obs:[]`, URL unchanged and document focus false. The browser document's own visibility is `visible`; the T3 host separately reports `visible:false`. These distinct fields are not conflated. |
| 62,63,64         | A diagnostic keydown observer/focus is set in-page. Native Enter returns a client failure; subsequent `obs:[]`, URL unchanged. Scripted focus success is not native keyboard acceptance.                                                                     |
| 66               | Resize request to 1440x900 times out after 15000ms; later page71 still reports 1280x800.                                                                                                                                                                     |
| 37,67,72,75      | All four snapshot calls fail, including includeImage true at67. No snapshot/image is produced or judged.                                                                                                                                                     |
| 74,76,77,78,83   | One allowed fresh-tab retry opens tab6 with requested open true yet host visible false. A diagnostic observer is attached; a native Reset-link click is acknowledged but later yields `obs:[]` and the login URL remains.                                    |
| 85,86            | Close calls for tabs6 and5 each return empty successful output. The raw calls support requested closure; no post-close list was saved.                                                                                                                       |

Position67 names the unavailable preview automation host and instructs opening the thread in a connected T3 desktop app. Other snapshot/press errors name the same client; the independent root host probe likewise opens tab7 with visible false and receives the matching snapshot error. Root closeout records tab7 closed, but its archive contains open/snapshot outputs rather than a separate close receipt. These records ground an automation-host/input failure, not a product chart failure. The driver remained on the exact HTTPS origin and did not switch to localhost, integrated browser, Chrome/Playwright, API login or scripted submit. The tool's suggested shell fallback is not user authorization.

The click/submit/key listeners begin after the first two click attempts. Thus zero observed events is directly recorded for the later attempts, while the earlier attempts are bounded by their subsequent unchanged page/timeout/resource observations. A successful tool acknowledgement does not establish a delivered click. No page geometry or appearance judgment is made from the diagnostic element coordinates.

## Login/session inference limits

No actual login POST, authenticated Organization/Training page, native sign-out, or workbook download is observed. The fill is not submission. Resource lists at40/45/52 show scripts/fonts and the static login image, not a login action; empty later click/submit/key observations and persistent login URL further support unavailable native input.

**The raw field named `loginPosts` is not a POST counter.** Positions81 and82 literally return 1, calculated by filtering Resource Timing entries whose URL matches `/login/`, without checking a method. The static `auth-login-command-desk.png` resource accounts for a login-named entry in the other saved observations. Driver observation summary `loginPostsObserved:0` therefore means no login action was observed; it must not be represented as the literal raw counter result or a complete method-aware network trace.

Protected-route evaluate81 in tab6 uses a same-origin manual-redirect fetch and returns status0/type`opaqueredirect`, location null, cookieNames[], unchanged theme/mode and `window.name` length0. This proves only that this fetch did not expose an authenticated report response; the hidden redirect target and HttpOnly cookies are not readable through those fields. The original summary's categorical “no session was created / nothing to sign out” is stronger than this saved observation. This audit retains **no authenticated session observed**, rather than proving global server-session nonexistence or a native sign-out. Both tabs were requested closed and owned verification cleanup later clears helper artifact sessions, which is not retroactive native-login proof.

The saved T3 profile is `default`; mechanical namespace/unique public port and empty document-cookie names do not by themselves prove browser-profile isolation, provider identity roundtrip or fresh original production cookie-name behavior. The public login page demonstrably loaded over h2, so the child phrase “no round has accepted HTTPS in a real browser” is read as **no authenticated native app/visual HTTPS acceptance**, not denial of the actual login-page transport observation. No Mac execution is asserted.

## Temporal qualification — no observed midnight transition

The saved command6 date is **2026-10-03 23:15:31 AKDT**. The driver's persisted start/end files are **23:16:25 -> 23:20:51 AKDT on Oct3**. Actual browser values23/71/81 are **23:16:39 / 23:19:35 / 23:20:21 Oct3**, with matching Anchorage timezone/UTC offset. `TEMPORAL-QUALIFICATION.md` records root's result-read clock **2026-10-04 07:23:10 UTC = Oct3 23:23:10 AKDT**; that last value is root's recorded clock observation, not a clock re-run by this reviewer.

These values are all before local midnight. The child's original report/terminal summary says the cases were not captured “before local midnight” and discusses an Oct4 rerun. That is preserved verbatim as original provenance, with the explicit root qualification: **there was no observed asOf/date transition in this run; both cases remained unrun because of host input failure.** It is a future rerun warning. The seeded final witness expires Nov1 and lapses Nov2: 30 days from Oct3, 29 from Oct4. A later rerun must use the actual process-local date/fresh-date fixture if it changed; no application clock was frozen, and this audit supplies no simulated browser-time evidence.

## Complete original rows, exact seed absence and owned cleanup

Both root Organization A/B original and restored files are **byte-identical and JSON-equal**, including all twelve selected schema fields and their IDs/created timestamps. The driver after-reads also equal those originals; both goals remain **90**. Training A's one saved row is byte-identical and JSON-equal across all ten fields, including saved completion/expiration, notes/certificate and created/updated timestamps; Training B remains empty. This is complete equality of the captured readback boundary, not a broad claim about unselected data or all database tables.

| Original/restored captured file family | SHA-256                                                            |
| -------------------------------------- | ------------------------------------------------------------------ |
| Organization A                         | `cbf12d06c622e2e8c19d1ffed612d973ad23afe33277bb9f479680c0b45d5a0c` |
| Organization B                         | `56409db0d27713213aa74a53ecc1bce7aa90c96ac3be2355fe832d263b8df98f` |
| Training A                             | `59c35673a001c6cf401d8a6e7243d7e5729d87e990ffe1a0658a0d323b7473d9` |
| Training B                             | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |

Root's setup/readback/absence records bind to this exact candidate/session. For each of the four table sets, every setup ID is unique and the initial readback's ID set equals the setup ID set exactly: **100 Personnel, 13 Training Types, 1 Training View, 852 Training records (966 total)**. The after-cleanup `observed` arrays are all empty. The archived readback script selects the exact receipt IDs in <=100-ID batches, with canonical Organization restriction and owned session/candidate guards; the setup records those same IDs in the owned cleanup journal before insertion. This is exact owned-ID absence, not a loose role-prefix query or total count. Setup expected math/final-bucket values remain fixture predictions, not live D1/D2 or chart proof; the requested goal85/95 cases were never applied in the browser.

`ROOT-CLOSEOUT.sh` records candidate/session doctor guards, original Organization equality/goals90, ordinary journal-bound clean-seeds, exact-ID absence, complete Training equality, post-seed doctor, verified transport check, exact adapter stop and worker1 cleanup. The saved closeout log ends with PASS. These are root-owned actual restoration/cleanup records, not Claude live visual observations or operations executed by this reviewer. `root-clean-seeds.json` records cleaned true and artifactHttpSessionsCleared true; `root-restoration-audit.json` records exact-ID absence, full captured row equality and goals90.

`root-transport-stop.json` is PASS for this session and records helper, sidecar and forwarding gone, local listener gone and exact Serve mapping gone (public18031/local19031). `root-owned-cleanup.json` records PASS/phase cleaned; its standalone envelope lacks candidate/session fields, so its scope is tied through the guarded closeout script, the preceding exact receipts and the saved absence receipt. This round's **structured** `root-owned-absence.json` is PASS for session223a5780, names the exact worker1 directory as absent and separately lists `carrier.json`, `claimed-carrier.json`, `private-navigate.json`, `private-fill.json` absent. This is stronger saved provenance than v5's worker-directory absence, which remains only root's old observation. No service/process/DB absence query was rerun by this worker.

Relevant cleanup hashes: restoration audit `5a4d24114478dd7293bf17e102605ea99e402bd9f6230792f88f42e09196f81c`; seed absence `4b4d3a6c718bb56284143cf8aeee2a0d4dc858c5255fde68b88d18bccf8fae17`; owned absence `1943c4fee5258802376e42f0507a318f559bbbb840214f6da8155154fa45a44f`. No new worker was launched for this audit and root reports none awaiting a driver after closeout.

## Outcome and retained limits

- **Outcome1, chart:** UNRUN. D4 goal95/flat100, D3 goal85/final30day, widths/themes/horizons, gridline contact, goal1/100, font/label drift and 1024/180 remain without v6 live proof. No Paper or successful chart capture was available; no visual verdict is made here.
- **Outcome2, adjacent user flow:** UNRUN. D1/D2 live calculation, filters/reload, first paint/no duplicate request, Retry, keyboard/focus and native Export/download were not observed. There is no v6 workbook result to hash or decode.
- **Outcome3, driver browser/contract smoke:** UNRUN. The driver did no new source review. The complete separate v6 source review covers all 101 text paths plus tracked binaries and historical archives at its recorded time, with passing root-required checks and actual fresh/populated SQL; those remain source/SQL proof, not this round's native acceptance.

Prior v5 **D4 FAIL** and its H2/primary-localhost deviation remain historical failures/limits; D3's v5 passing measurements are not fresh v6 acceptance. V3 auth/race/server-fault proof and old actual v5 9431-byte workbook remain supplemental older-candidate evidence. The intrinsically omitted older console entries, unreleased renamed Training migration, main D26 manual hold and all release obligations remain qualified. Recovery/redaction is an evidence operation, not a product fix or accepted browser alternative.

There is **no integrity blocker found in the saved package**, with the explicit redaction/provenance/counter/temporal/session limits above. The acceptance blocker is the documented unavailable native T3 host/input path. User choice about reconnecting desktop preview or explicitly authorizing another owned verify-app browser remains pending with root. No change to that boundary or source is made by this audit.

## Complete 126-payload inventory

Every row below was fully hash-checked against the archive and expanded bytes. `inventory.json` itself is the 127th tar file and its hash is separately bound above; it cannot recursively inventory its own bytes.

| Payload                                           | SHA-256                                                            |
| ------------------------------------------------- | ------------------------------------------------------------------ |
| `ANNOTATION-AUTHOR-RESULT.json`                   | `51c2e468a3208e1a56a61cb9ba029f9ea8642829e6f1171cf09597a1758b1ada` |
| `ANNOTATION-AUTHOR.md`                            | `78ca9295b2bb558c47cead9452c7be60af75308b36f7e74e2aa3634a81fe18cb` |
| `BOUNDARY-SEED.mjs`                               | `1fc8ad6f95d6360cb8a25469609d8126af1084e995158590566021aa232a4051` |
| `DATABASE-RESULT.json`                            | `6b0f413b373a90c62c41cc952943fa348079a0ca832885645ee55a48fdd4537f` |
| `DRIVER-REPORT.md`                                | `b08265b5e72a8bf9a6aa59e2e4b32f8d3acae597122cb0080fc80cc911501c93` |
| `MIGRATION-INTEGRATION.md`                        | `3837bad25d64636c8e89b3698dd829b047e169a65034518b0f1252d052c3a9a8` |
| `NONVISUAL-SOURCE-REVIEW.md`                      | `4ead50efef86dfb2a8decd6b4b69b0bda1e51f525efbd0a572ef30f33db23529` |
| `ORIGINAL-BRIEF.md`                               | `0d29f129063e6498ffbab7bc37e846d46980c52034c7645d649ac7f17a8ee9d1` |
| `PRIOR-V5-ARTIFACT-AUDIT.md`                      | `c16017ce3672aedfcd39825d99247e5b2722fa26a5b6e46cdccb35ff597e59e1` |
| `REQUIRED-CHECKS.json`                            | `7908286801eae64f402824ca5b8a3b17605de759dcd2074b115a65533091836e` |
| `ROOT-CLOSEOUT.md`                                | `a0d5af737e5a7a3d54e0cbd58f6302f0bac1f9a4781a374a9be01c173bcf9c21` |
| `ROOT-CLOSEOUT.sh`                                | `70956fdd2e0c94c63f6967244d28b2a5b2fa8135973a44fbfc989d569d4d1a04` |
| `ROOT-HOST-PROBE.json`                            | `3861dc13acf1503eccd323aed25c291a613fdffbd8bcf682c3cb98b636fb3f77` |
| `SOURCE-BINDING.json`                             | `4c63c4942fac976be36aa21b8958caa1c59b80713cc568410b60699bbc976271` |
| `SOURCE.patch`                                    | `eab7bf70b31c2715772984ada6fe1721e72b86957541dcdcce4e5ec2a4c992bd` |
| `SUPPORTED-RAW-RECOVERY.md`                       | `ff6589008053163fb77055659e1c00a6d461b97d07aab6a15993e479d3922b2b` |
| `TASK-RESULT.json`                                | `b58be3375d5b431eaf12dad3a0f2a206f452d91bc25c867d99d480b62cb63a1f` |
| `TEMPORAL-QUALIFICATION.md`                       | `56e7c10c340c4cfe37a083529e24249a6f1e05e2fb3b14a3c45c010538b547ac` |
| `TRANSPORT-CORRECTION.md`                         | `70e6dac9b26b00809371ca5d4d8598bbea72bcd862d25292426d1bc2524453f2` |
| `adapter-static/README.md`                        | `9d2b931bc4194179c6229ddfb44a5fdbdffc5fb4aee7c00a13720c162e2b8ff6` |
| `adapter-static/command.mjs`                      | `b0ce865c10616ba20a9992213b10328244d466f4f01dd04dbf617fabbdf3c672` |
| `adapter-static/sidecar.mjs`                      | `e8c6e16fc85eb5d762c54a3b47de832b6a651f057323674f6728faddf3bd3b03` |
| `adapter-static/source-sha256.json`               | `aeb6d8c9926b8f6b832f2aab93b6ab02689d7f91c11e491f695670642198505a` |
| `adapter-static/transport.mjs`                    | `1eec58cf2ef2766b3e9bba3756f64106ecccf37b3597b647e9d8d7a6e7f348ae` |
| `adapter-static/transport.test.mjs`               | `a233ef8225977e398d0e731f8b5a9aaf9d15a2c50a2b7136d574cb7fd3d43314` |
| `driver/00-start-time.txt`                        | `60c073f40aa9590a984add28ad57118000d94392b048d9eb81093566b9409051` |
| `driver/01-adaptercheck-start.json`               | `d7f546b760616ce4851c18cea095fc81342e901f11dd8dafa6d0eb4840fe196f` |
| `driver/01-doctor-start.json`                     | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `driver/02-stage-receipt.json`                    | `fd7a88886a6e1a32b93fb43258d5cbcd3d6524b7541d32397aac7781b6c504e6` |
| `driver/10-browser-observations.json`             | `978ff389d8c038ab6750fbdcd6a974247d30c4022e777f5d0ca5d151a9f65e31` |
| `driver/90-organizations-orgA-after.json`         | `cbf12d06c622e2e8c19d1ffed612d973ad23afe33277bb9f479680c0b45d5a0c` |
| `driver/90-organizations-orgB-after.json`         | `56409db0d27713213aa74a53ecc1bce7aa90c96ac3be2355fe832d263b8df98f` |
| `driver/91-adaptercheck-end.json`                 | `444162878aa59115445a5ec917e7bc2548f3779449925ac5912b339c0e5446aa` |
| `driver/91-doctor-end.json`                       | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `driver/92-end-time.txt`                          | `52edeeed200b43c1bdf0b7fee75bc966d10d8fe6a2f17ba24226db635a96f762` |
| `driver/NOTES.md`                                 | `c97981e648fac7a4d836dee9fdc5ef01fdd42388cd1a4aab04b95a08e3c22d6c` |
| `driver/REDACTION-INDEX.md`                       | `2f73fa76e9e42eadeb7395a6a71cd835206135aade0598f332fdaaa10f6a99ac` |
| `root-clean-seeds.json`                           | `7d6810e68f7516d53485b4e21dbcab72f20599418fd5ce10bb1dd5ef6c903d0c` |
| `root-closeout.log`                               | `fae2a6c8fe12898e7b2b34832c0c6a2cfa6678cbbb3f4b7d77d32fd8e49e2280` |
| `root-doctor-after-seeds.json`                    | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `root-doctor-before-driver.json`                  | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `root-doctor-closeout.json`                       | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `root-doctor-start.json`                          | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `root-launch.json`                                | `2baa9f1ac2a714fffc187312655ac51877d9e7f92aa004e7c233cc87aca7f877` |
| `root-organizations-orgA-original.json`           | `cbf12d06c622e2e8c19d1ffed612d973ad23afe33277bb9f479680c0b45d5a0c` |
| `root-organizations-orgA-restored.json`           | `cbf12d06c622e2e8c19d1ffed612d973ad23afe33277bb9f479680c0b45d5a0c` |
| `root-organizations-orgB-original.json`           | `56409db0d27713213aa74a53ecc1bce7aa90c96ac3be2355fe832d263b8df98f` |
| `root-organizations-orgB-restored.json`           | `56409db0d27713213aa74a53ecc1bce7aa90c96ac3be2355fe832d263b8df98f` |
| `root-owned-absence.json`                         | `1943c4fee5258802376e42f0507a318f559bbbb840214f6da8155154fa45a44f` |
| `root-owned-cleanup.json`                         | `43b8a7db6331e3cd3333eaaf11a20b57f351b4ec57e2a5dba872a5686bfa5b05` |
| `root-public-fixture.json`                        | `5dfe2e6acb88da674b964dbae32e31c64408a7e45d9189857ce01fd29aeb7a47` |
| `root-restoration-audit.json`                     | `5a4d24114478dd7293bf17e102605ea99e402bd9f6230792f88f42e09196f81c` |
| `root-seed-absence.json`                          | `4b4d3a6c718bb56284143cf8aeee2a0d4dc858c5255fde68b88d18bccf8fae17` |
| `root-seed-readback.json`                         | `2703c618be2d67ef5f8aa40edac28087605ec60fc98032d0b58fee45203f9e29` |
| `root-seed-setup.json`                            | `7a73e520db7c26eea4de417a7f4b40f9d16f7dcac564de760c3a9c1ccca635ad` |
| `root-training-orgA-original.json`                | `59c35673a001c6cf401d8a6e7243d7e5729d87e990ffe1a0658a0d323b7473d9` |
| `root-training-orgA-restored.json`                | `59c35673a001c6cf401d8a6e7243d7e5729d87e990ffe1a0658a0d323b7473d9` |
| `root-training-orgB-original.json`                | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| `root-training-orgB-restored.json`                | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| `root-transport-background-completion-check.json` | `6232bea0042e13c49b7e30a1c78f8707c014f8c94d420073b3bcd29551e123c9` |
| `root-transport-check-after-seeds.json`           | `bbd8fe180f68076d34d23f75f31ad5084a6f35368f62fde2836c4f64f7eef480` |
| `root-transport-check-before-driver.json`         | `f797fcfb92f1e0b71e4b61dde49c90752f46d1d2aa41e05d80a0bcafa1951a44` |
| `root-transport-start.json`                       | `9f9f7c0d7728d77ce9c2352839ca5cbd07cd9e724d82dc905cd5ae396222828d` |
| `root-transport-stop.json`                        | `fe0f531465012616046ced16532d1dff38c91a2e5646067f53d2b35379e1be72` |
| `supported-commands/position-0002.txt`            | `afc8694a03462017f13edddcf03a3c2358bfe86ba1c4c3e6eaca492f22146875` |
| `supported-commands/position-0004.txt`            | `3ad16e8c0b2406fc9b1d04d2018c23e4da3ce36c245086f30091639f3ef2a8b4` |
| `supported-commands/position-0006.txt`            | `1b8055436e493481d15fa19e5c5d08394e408f2e3c8eb39452f90b3c41b5a092` |
| `supported-commands/position-0008.txt`            | `bc66315462942e675b004070671319eb160299b37905d648d8961f38cfb48400` |
| `supported-commands/position-0010.txt`            | `21b20d85b7edd14ae26e7cfdebe6aee7c31e4fb7cfff33752d2c743ba0a5a08c` |
| `supported-commands/position-0012.txt`            | `7cdf5d451e8af13ada97591aa579fc2b2bda241c91fdd2305cf60961c4be7ef4` |
| `supported-commands/position-0013.txt`            | `2ab390ebff24e5242771857404b113998fa432956f6d44070bab2823bc8950f2` |
| `supported-commands/position-0015.txt`            | `1d827702d6465f9fde7e3a3cf47a82f9e2b7b8870d366526d974eb9b5bc36358` |
| `supported-commands/position-0018.txt`            | `82d2db3f74ad7cb4280207702f7b82a2d838895f3d7fdd09e218637285791883` |
| `supported-commands/position-0019.txt`            | `46549d9c1b32bfc049df7b5a09080228fe0da3f01cbaae4b653337859433c03a` |
| `supported-commands/position-0026.txt`            | `0e731a4b953dc5772674cf36c9fbf2012779efc28b93367c38196173ae988a97` |
| `supported-commands/position-0028.txt`            | `a29d8ff85719954d9a8e244ebd5c78679a45f1e0b4a20ca861a913ffdb4d3007` |
| `supported-commands/position-0032.txt`            | `4099987bdaec2e1b6f5249454c642ab831eee4c33a392ae2a40c39b41e0291d9` |
| `supported-commands/position-0087.txt`            | `6541d3796665cc087d5dc6e6bc171f740d6404b076becf8e260b16e59daee434` |
| `supported-commands/position-0088.txt`            | `3c6a7681261aff56d23cd34b27a6c9dd1d33ebc8661810f0fa0b27ca25182001` |
| `supported-commands/position-0089.txt`            | `e0f202ceb513f777be7dbdfd0ce338e9351c1399c5d778630bd15a10c5d21e9c` |
| `supported-commands/position-0091.txt`            | `66d1de4b9aeedb8cdab63ebf81c6febe802d8c08272eab22103bac40eecf2162` |
| `supported-commands/position-0094.txt`            | `c70ccaaef2119427439857666fbafa310cdd185452661ff5c0c7070eb541a5da` |
| `supported-raw/position-0017.json`                | `3def90245c13d65aa7a9502f1e57cf2fe9f4d20f935103e763eb11b8242ef929` |
| `supported-raw/position-0020.json`                | `e8d14af6df5aca0f0a1cb3ad473bfbe34020d0d45c3b98c5a4eb8c6aba1c428f` |
| `supported-raw/position-0021.json`                | `51e3890ea5bd4b8eab563adff4d211a09738dc24b5146c416e7393dfac132e0d` |
| `supported-raw/position-0023.json`                | `b47fd4744e41a3a6ef3804a2fdac0c206af65245bfa0b2578d82c8b43b12c1a0` |
| `supported-raw/position-0025.json`                | `7be6eeb9dc0d9c9144ca47cb2a584305ba3726140531ed08b1f9bd41e83f216f` |
| `supported-raw/position-0029.json`                | `9a8b726b0596fcb9589bcd98546478bd0eb7ad00c85044cacae8032694bbdcd6` |
| `supported-raw/position-0031.json`                | `0afc9a334877689b4d2b3f46a0c1af38b1e3e2ff0429b0d91f8dd5ab29039c31` |
| `supported-raw/position-0034.json`                | `c1b61ed139ba670d10a6df3486214b7f09f212c159cf078c7f2406c118524639` |
| `supported-raw/position-0035.json`                | `7d9f6dfb219806804a8803e40477558ee14921f61e9a74bd944ffdabf0d52714` |
| `supported-raw/position-0036.json`                | `ee903295d7cfd2afbd16a105f721830493cac12143659644fe81b17444798100` |
| `supported-raw/position-0037.json`                | `7094ab94e942894b103a3fb1f9a241fe6628eb8ef0faca64610b4f42ab3feee9` |
| `supported-raw/position-0038.json`                | `ebd0cba6b5b11bf74898a3d25b7093ff5d35c102a1cdd53eda93fb5afb4d6b91` |
| `supported-raw/position-0040.json`                | `eb1c3f420b31d979b50e09ee3db7978022dc4141ada6111b7a2572d039b6ad81` |
| `supported-raw/position-0043.json`                | `57e080f0ff8ea7ad97e7c34f4616a571c3a9e65c5b3ad0e474f4d1f8b3f2a0d9` |
| `supported-raw/position-0044.json`                | `f0545dacc5fba9475bcc7529243e7ba1d672c5740799a168bbaef635f4910ffc` |
| `supported-raw/position-0045.json`                | `9f72df9c2e6028ee6181edefb9505a727aa33805b8bd07b8fd80d9c250ddd596` |
| `supported-raw/position-0047.json`                | `fbc1706aaacd9ac406ba70675bc45e31d732c2f937bfc4e1d4590045ce7a0a6b` |
| `supported-raw/position-0049.json`                | `8a52394b202b55914a2ee50482ed53cdc6894f1584fdcf80a4dca1b27e73079c` |
| `supported-raw/position-0051.json`                | `57e080f0ff8ea7ad97e7c34f4616a571c3a9e65c5b3ad0e474f4d1f8b3f2a0d9` |
| `supported-raw/position-0052.json`                | `18a10dfad7bdb8d40d2879e8c38fa5eee4add17c60b01b63cbdfcb4a54577533` |
| `supported-raw/position-0055.json`                | `ba245c131ef9023888557d8994a0eaa8b7c18df0ec9c65fc07c5a359bf4e6ee3` |
| `supported-raw/position-0056.json`                | `6fefa59a4aa02544fc6b2d7cd737c223edcb0cefa61d31ea5dae72de7da02d09` |
| `supported-raw/position-0058.json`                | `866939d6136b95e79234e39eeb96b177e47371d764384c85c55c0e0b49d0e479` |
| `supported-raw/position-0059.json`                | `d3859600dd0869ad68641d7c183352ae93e67f847be1b9029a87269e61129ced` |
| `supported-raw/position-0060.json`                | `1694c14ed0012bf9c6a43060109ef2b004ebc07bbb0cbc96e75978e80e32cc25` |
| `supported-raw/position-0062.json`                | `15e2283eac61705f65dd78ed42c097ce879a43c0cbae7932d4c7b828b5082455` |
| `supported-raw/position-0063.json`                | `4d76f9f603698b680e2ebb71fb7ae81a2865f1399696750b2b174c87a4a3b5fc` |
| `supported-raw/position-0064.json`                | `5e46f52a5a9d6363ca76cfe6c09fb9023c65069b45e1d091abd70f87fe4da41a` |
| `supported-raw/position-0066.json`                | `712fcf65dbbe525aa0e0e978e62cb70e97117c7a3b9bd63ee1a562bd7f3bd85a` |
| `supported-raw/position-0067.json`                | `aa276007b203716b4e539ebd2ef6744af128b4b7b038910685398ab90374c8c0` |
| `supported-raw/position-0069.json`                | `1694c14ed0012bf9c6a43060109ef2b004ebc07bbb0cbc96e75978e80e32cc25` |
| `supported-raw/position-0071.json`                | `e95afa5e79bb64338285284512c394e162c63d57e72cb3eea758bf647387b0ce` |
| `supported-raw/position-0072.json`                | `7094ab94e942894b103a3fb1f9a241fe6628eb8ef0faca64610b4f42ab3feee9` |
| `supported-raw/position-0074.json`                | `2b713074f1b69c19bc975912bec153e4d73f3530fa57bb7e82e28283191f266d` |
| `supported-raw/position-0075.json`                | `2cab397da2deff51abdb2dcfe73a1cc95b0c768bddcf44d5c378bce0470b9fbc` |
| `supported-raw/position-0076.json`                | `cfacd0dcd7b25e529251a4ba4322885e17918b04501f4a6bd6a54a0bea0c99fc` |
| `supported-raw/position-0077.json`                | `434e9ea100627505aa81b486e1adf8c19c1717b216b799f88746127585febb95` |
| `supported-raw/position-0078.json`                | `3325db263f5126e8a82f92244e8176496de66fceb9125ba046faa69ce6ac3516` |
| `supported-raw/position-0081.json`                | `945a99f50326ab7010221aa4b16cb28a6292b30ac8d045a261b766afd158e66c` |
| `supported-raw/position-0082.json`                | `6047f1095feab4865e6959dd5c7e56ec3bf451f0e7a1f9cd4bc43d0fd503dbba` |
| `supported-raw/position-0083.json`                | `b1faed27773fbc6a8d41c74c16ee601baf65141a7914d4c73adcf847ff75fe7b` |
| `supported-raw/position-0085.json`                | `decefd60b0bc8d3282a1733f2daeccc45c0a64bbadd040477befc90987bbdc78` |
| `supported-raw/position-0086.json`                | `01a3bf277fabaa607088f1e0a2b0a81ddd9ab71d8acf718a64b7f22ffe166b6d` |
| `supported-raw-index.json`                        | `34d558d1849c746f5955ce1508ff80b5d6139051dd485ed225d90f1d62df78d7` |

## Complete 61-record supported raw census

These paths and hashes also occur in the complete inventory above. The index retains the unique original supported itemId, position, UTF-16 recovery length and redaction count for each; no command text is labelled as a complete dynamic API envelope.

| Position | Record kind / actual tool        | Saved path                             | Redactions |
| -------: | -------------------------------- | -------------------------------------- | ---------: |
|        2 | `durable command text`           | `supported-commands/position-0002.txt` |          0 |
|        4 | `durable command text`           | `supported-commands/position-0004.txt` |          0 |
|        6 | `durable command text`           | `supported-commands/position-0006.txt` |          0 |
|        8 | `durable command text`           | `supported-commands/position-0008.txt` |          0 |
|       10 | `durable command text`           | `supported-commands/position-0010.txt` |          0 |
|       12 | `durable command text`           | `supported-commands/position-0012.txt` |          0 |
|       13 | `durable command text`           | `supported-commands/position-0013.txt` |          0 |
|       15 | `durable command text`           | `supported-commands/position-0015.txt` |          0 |
|       17 | `ToolSearch`                     | `supported-raw/position-0017.json`     |          0 |
|       18 | `durable command text`           | `supported-commands/position-0018.txt` |          0 |
|       19 | `durable command text`           | `supported-commands/position-0019.txt` |          0 |
|       20 | `mcp__t3-code__preview_status`   | `supported-raw/position-0020.json`     |          0 |
|       21 | `mcp__t3-code__preview_open`     | `supported-raw/position-0021.json`     |          0 |
|       23 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0023.json`     |          0 |
|       25 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0025.json`     |          0 |
|       26 | `durable command text`           | `supported-commands/position-0026.txt` |          0 |
|       28 | `durable command text`           | `supported-commands/position-0028.txt` |          1 |
|       29 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0029.json`     |          1 |
|       31 | `mcp__t3-code__preview_wait_for` | `supported-raw/position-0031.json`     |          0 |
|       32 | `durable command text`           | `supported-commands/position-0032.txt` |          0 |
|       34 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0034.json`     |          0 |
|       35 | `mcp__t3-code__preview_click`    | `supported-raw/position-0035.json`     |          0 |
|       36 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0036.json`     |          0 |
|       37 | `mcp__t3-code__preview_snapshot` | `supported-raw/position-0037.json`     |          0 |
|       38 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0038.json`     |          0 |
|       40 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0040.json`     |          0 |
|       43 | `mcp__t3-code__preview_click`    | `supported-raw/position-0043.json`     |          0 |
|       44 | `mcp__t3-code__preview_wait_for` | `supported-raw/position-0044.json`     |          0 |
|       45 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0045.json`     |          0 |
|       47 | `mcp__t3-code__preview_open`     | `supported-raw/position-0047.json`     |          0 |
|       49 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0049.json`     |          0 |
|       51 | `mcp__t3-code__preview_click`    | `supported-raw/position-0051.json`     |          0 |
|       52 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0052.json`     |          0 |
|       55 | `mcp__t3-code__preview_click`    | `supported-raw/position-0055.json`     |          0 |
|       56 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0056.json`     |          0 |
|       58 | `ToolSearch`                     | `supported-raw/position-0058.json`     |          0 |
|       59 | `mcp__t3-code__t3_preview_list`  | `supported-raw/position-0059.json`     |          0 |
|       60 | `mcp__t3-code__preview_status`   | `supported-raw/position-0060.json`     |          0 |
|       62 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0062.json`     |          0 |
|       63 | `mcp__t3-code__preview_press`    | `supported-raw/position-0063.json`     |          0 |
|       64 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0064.json`     |          0 |
|       66 | `mcp__t3-code__preview_resize`   | `supported-raw/position-0066.json`     |          0 |
|       67 | `mcp__t3-code__preview_snapshot` | `supported-raw/position-0067.json`     |          0 |
|       69 | `mcp__t3-code__preview_status`   | `supported-raw/position-0069.json`     |          0 |
|       71 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0071.json`     |          0 |
|       72 | `mcp__t3-code__preview_snapshot` | `supported-raw/position-0072.json`     |          0 |
|       74 | `mcp__t3-code__preview_open`     | `supported-raw/position-0074.json`     |          0 |
|       75 | `mcp__t3-code__preview_snapshot` | `supported-raw/position-0075.json`     |          0 |
|       76 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0076.json`     |          0 |
|       77 | `mcp__t3-code__preview_click`    | `supported-raw/position-0077.json`     |          0 |
|       78 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0078.json`     |          0 |
|       81 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0081.json`     |          0 |
|       82 | `mcp__t3-code__preview_evaluate` | `supported-raw/position-0082.json`     |          0 |
|       83 | `mcp__t3-code__preview_status`   | `supported-raw/position-0083.json`     |          0 |
|       85 | `mcp__t3-code__t3_preview_close` | `supported-raw/position-0085.json`     |          0 |
|       86 | `mcp__t3-code__t3_preview_close` | `supported-raw/position-0086.json`     |          0 |
|       87 | `durable command text`           | `supported-commands/position-0087.txt` |          0 |
|       88 | `durable command text`           | `supported-commands/position-0088.txt` |          0 |
|       89 | `durable command text`           | `supported-commands/position-0089.txt` |          0 |
|       91 | `durable command text`           | `supported-commands/position-0091.txt` |          0 |
|       94 | `durable command text`           | `supported-commands/position-0094.txt` |          0 |

## Closeout

**Package integrity PASS; current native product acceptance UNAVAILABLE, all three outcomes UNRUN.** The temporal correction and no-observed-login qualification govern the stronger statements in the preserved child narrative. No visual acceptance, completed issue, source mutation or publication is claimed. Only this ignored audit report was written.
