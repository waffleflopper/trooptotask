SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 1469 AND backend_start = '2026-10-01 22:12:03.765317+00'::timestamptz AND application_name = 't2t-d15-hold-352a72c5b46b40e687790edc6b568c8d' AND usename = 'supabase_admin' AND datname = 'postgres';
