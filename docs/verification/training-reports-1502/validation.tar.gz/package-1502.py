import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile


source, archive, expanded = map(Path, sys.argv[1:])
payloads = sorted(p for p in source.rglob('*') if p.is_file() and p.name != 'inventory.json')
inventory = []
patterns = [
    rb'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
    rb'(?i)authorization\s*[:=]\s*["\x27]?bearer\s+[^\s"\x27]+',
    rb'(?i)[?&](?:access_token|refresh_token|token)=[^&\s"\x27]+',
    rb'\bsb_(?:secret|publishable)_[A-Za-z0-9_-]{15,}',
    rb'\bsbp_[A-Za-z0-9_-]{15,}',
]
for path in payloads:
    assert not path.is_symlink(), path
    data = path.read_bytes()
    if path.suffix in {'.json', '.txt', '.md', '.log', '.tsv', '.patch'}:
        for pattern in patterns:
            assert not re.search(pattern, data), f'Credential pattern in {path.name}'
    inventory.append({'path': path.relative_to(source).as_posix(), 'sha256': hashlib.sha256(data).hexdigest()})
archive.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive, 'w:gz') as output:
    for path in payloads:
        output.add(path, arcname=path.relative_to(source).as_posix(), recursive=False)
    data = (json.dumps(inventory, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('inventory.json')
    entry.size = len(data)
    entry.mode = 0o644
    output.addfile(entry, io.BytesIO(data))
assert not expanded.exists(), expanded
expanded.mkdir(parents=True)
with tarfile.open(archive, 'r:gz') as archived:
    archived.extractall(expanded, filter='data')
manifest = json.loads((expanded / 'inventory.json').read_text())
actual = {p.relative_to(expanded).as_posix() for p in expanded.rglob('*') if p.is_file() and p.name != 'inventory.json'}
assert actual == {entry['path'] for entry in manifest}
for entry in manifest:
    assert hashlib.sha256((expanded / entry['path']).read_bytes()).hexdigest() == entry['sha256'], entry['path']
print(json.dumps({'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payloads': len(manifest), 'credentialScan': 'PASS', 'expandedHashes': 'PASS', 'expanded': str(expanded)}))
