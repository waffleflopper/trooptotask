"""Save ordinary business bodies, omitting private native-tool request/response headers."""
import json,os,re,subprocess,sys
from pathlib import Path
run=os.environ.get('D15_CHECKBOX_RUN','');page,reqid,label=sys.argv[1:]
if run not in ('baseline','final') or not page.isdigit() or not reqid.isdigit() or not re.fullmatch('[a-z0-9-]+',label): raise ValueError('Explicit run/page/request/label')
root=Path('.verification/evidence/verify-trooptotask')/f'd15-checkbox-{run}-native'
request=root/(label+'-request.network-request');response=root/(label+'-response.network-response')
if request.exists() or response.exists():raise ValueError('Refuse overwrite')
args={'pageId':int(page),'reqid':int(reqid),'requestFilePath':str(request.resolve()),'responseFilePath':str(response.resolve())}
command=['npm','run','--silent','verify:app','--','tool','get_network_request',json.dumps(args),'--worker','1']
r=subprocess.run(command,capture_output=True,text=True)
obj=json.loads(r.stdout) if r.returncode==0 else None
if r.returncode or obj.get('isError'):raise ValueError('Native business capture failed; no body credit')
if not request.is_file() or not response.is_file():raise ValueError('Missing bodies')
meta={'tool':'get_network_request','arguments':args,'exitCode':r.returncode,'redaction':'Private request/response headers omitted at capture; business bodies untouched','requestSha256':__import__('hashlib').sha256(request.read_bytes()).hexdigest(),'responseSha256':__import__('hashlib').sha256(response.read_bytes()).hexdigest()}
with (root/(label+'-body-metadata.json')).open('x') as f:json.dump(meta,f,indent=2)
print(request.read_text());print(response.read_text())
