import json,sys
import d18_ui as v,d18_native as n,d18_final as f
kind=sys.argv[1];table={'personnel':'personnel','personnel_training':'personnel_trainings','training_type':'training_types','rating_scheme_entry':'rating_scheme_entries','counseling_record':'counseling_records'}[kind]
s=f.read('04-source-seed')['sources']['orgA']; prefix='fault-'+kind
requests=n.rows(prefix+'-request-before','deletion_requests','orgA','resource_id',s[kind])['rows']
r=next(row for row in requests if row['status']=='pending')
b=n.rows(prefix+'-source-before',table,'orgA','id',s[kind])['rows']; assert len(b)==1
if kind=='counseling_record':f.file_capture(prefix+'-pdf-before')
print(v.helper(prefix+'-arm','deletion-review-failure','arm',r['id']),flush=True)
v.helper(prefix+'-state','deletion-review-failure','state',r['id'])
v.helper(prefix+'-observe','network','arm-observe','3','deletion-requests/review')
try:
 n.review_click(prefix+'-approve-fails',3,r['resource_description'],'Approve')
 v.snap(prefix+'-failed-visible',3); n.screenshot(prefix+'-failed',3)
 trace=v.helper(prefix+'-failed-trace','network','state','3'); assert trace['calls'][-1]['status']==500,trace
 a=n.rows(prefix+'-failed-source',table,'orgA','id',s[kind])['rows']
 pending=n.rows(prefix+'-failed-request','deletion_requests','orgA','id',r['id'])['rows']; assert pending==[r],pending
 if kind=='personnel':assert len(a)==1 and a[0]['archived_at'] and all(a[0][k]==val for k,val in b[0].items() if k!='archived_at')
 elif kind=='counseling_record':
  assert a==b
  f.file_capture(prefix+'-pdf-failed')
  assert f.read(prefix+'-pdf-failed-orgA-files')['files'][0]['present'] is False
  assert f.read(prefix+'-pdf-before-orgB-files')==f.read(prefix+'-pdf-failed-orgB-files')
 else:assert a==[],a
finally:
 print(v.helper(prefix+'-restore','deletion-review-failure','restore',r['id']),flush=True)
v.helper(prefix+'-restored-state','deletion-review-failure','state')
# An explicit second native approval, after restoring the actual provider failure.
n.review_click(prefix+'-explicit-retry',3,r['resource_description'],'Approve')
v.snap(prefix+'-retry-visible',3); n.screenshot(prefix+'-retry',3)
trace=v.helper(prefix+'-retry-trace','network','state','3'); assert [x['status'] for x in trace['calls']]==[500,200],trace
final=n.rows(prefix+'-source-final',table,'orgA','id',s[kind])['rows']
ack=n.rows(prefix+'-request-final','deletion_requests','orgA','id',r['id'])['rows'][0]
assert ack['status']=='approved' and ack['reviewed_by'] and ack['reviewed_at']
assert all(ack[k]==val for k,val in r.items() if k not in {'status','reviewed_by','reviewed_at'})
assert final==a if kind=='personnel' else final==[]
if kind=='counseling_record':f.file_capture(prefix+'-pdf-final')
v.helper(prefix+'-network-restore','network','restore','3')
(v.root/(prefix+'-comparison.json')).write_text(json.dumps(dict(status='PASS',kind=kind,requestId=r['id'],nativeHTTP=[500,200],pendingAfterFailure=True,reviewMetadataOnly=True,sourceOutcome='single preserved archive timestamp' if kind=='personnel' else 'counseling row retained with PDF absent until retry' if kind=='counseling_record' else 'source absent while pending; retry acknowledges'),indent=2)+'\n')
print('PASS',kind,r['id'],flush=True)
