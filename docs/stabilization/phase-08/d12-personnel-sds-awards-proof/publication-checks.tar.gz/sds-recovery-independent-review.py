from pathlib import Path
import json,re,subprocess,datetime
p=Path('/home/waffleflops/.cache/t2t-1360-retention-ownership/.verification/sds-recovery-independent-i617vwvi');checks=[]
def j(n):return json.loads((p/n).read_text())
def ck(n,v):checks.append({'observation':n,'pass':bool(v)});assert v,n
def txt(n):return '\n'.join(x.get('text','') for x in j(n).get('content',[]))
def response(n):return json.loads(re.search(r'```json\n(.*?)\n```',txt(n),re.S).group(1))
def rows(n):return j(n)['rows']
def row(n):x=rows(n);assert len(x)==1,n;return x[0]
def changed(a,b):return {k for k in a if a[k]!=b[k]}
def tm(v):return datetime.datetime.fromisoformat(v)
expected={'blood_type':'O+','basd':'2020-02-03','date_of_rank':'2024-06-01','marital_status':'Married','number_of_dependents':2,'children':[{'name':'Avery','age':7},{'name':'Morgan','age':None}],'civilian_education':'BSN','military_education':['BLC','Air Assault'],'emergency_contact_name':'Synthetic Contact','emergency_contact_relationship':'Sibling','emergency_contact_phone':'907-555-0100','spouse_name':'Synthetic Spouse','spouse_phone':'907-555-0101','vehicle_make_model':'Toyota Tacoma','vehicle_plate':'VFY482','vehicle_color':'Gray','personal_email':'synthetic-sds@example.test','personal_phone':'907-555-0102','address_street':'100 Synthetic Way','address_city':'Anchorage','address_state':'AK','address_zip':'99501'}
a=row('sds-after-retry.json');ck('full projection 28 fields',len(a)==28)
for k,v in expected.items():ck('initial literal saved '+k,a[k]==v)
ck('cancel no insert',rows('sds-after-cancel.json')==[]);ck('controlled503 no insert',rows('sds-after-failed-save.json')==[])
fill=j('sds-literal-fill-command.json')['command'];args=json.loads(fill[fill.index('fill_form')+1]);ck('22 actual native field arguments',len(args['elements'])==22)
snapshot=txt('sds-save-fail-after.json');reload=txt('sds-reloaded-form.json')
for e in args['elements']:ck('failure retains draft '+e['uid'],'uid='+e['uid']+' ' in snapshot and 'value="'+e['value']+'"' in snapshot)
ck('reload literal children', 'value="Avery, 7\nMorgan"' in reload);ck('reload trimmed military lines','value="BLC\nAir Assault"' in reload)
ck('503 actual request',j('sds-save-fail-network.json')['calls'][0]['status']==503)
ck('initial actual success feedback',any(x['type']=='success' and x['text']=='Soldier Data Sheet saved' for x in j('sds-retry-feedback.json')['entries']))
start=row('ack-set-before.json');setrow=row('ack-set-after.json');replay=row('ack-true-replay-after.json');clear=row('ack-clear-after.json');preserved=row('sds-ack-preserved-row.json');keyclear=row('sds-color-keyboard-after.json')
for n,r in [('ack-set.json',True),('ack-true-replay.json',True),('ack-clear.json',False)]:
 x=response(n);ck(n+' status/body',x['status']==200 and json.loads(x['body'])=={'personnelId':a['personnel_id'],'awardTrackingAcknowledged':r})
for label,b,c in [('set',start,setrow),('replay',setrow,replay),('clear',keyclear,clear)]:
 ck(label+' exact siblings',changed(b,c)<= {'award_tracking_acknowledged_at','updated_at'});ck(label+' updated_at monotonic',tm(c['updated_at'])>=tm(b['updated_at']))
ck('set nonnull',setrow['award_tracking_acknowledged_at'] is not None);ck('true replay later timestamp',tm(replay['award_tracking_acknowledged_at'])>tm(setrow['award_tracking_acknowledged_at']));ck('clear null',clear['award_tracking_acknowledged_at'] is None)
ck('native SDS changes only intended phone and timestamp',changed(replay,preserved)=={'emergency_contact_phone','updated_at'} and preserved['emergency_contact_phone']=='907-555-0199')
ck('keyboard clears only color and timestamp',changed(preserved,keyclear)=={'vehicle_color','updated_at'} and keyclear['vehicle_color'] is None)
for i in [1,2]:ck('no-row clear/replay '+str(i),rows('ack-no-row-before-'+str(i)+'.json')==rows('ack-no-row-after-'+str(i)+'.json')==[] and response('ack-no-row-clear-'+str(i)+'.json')['status']==200)
for state in ['set','clear']:
 for surface in ['personnel','dashboard']:
  x=response('ack-'+state+'-'+surface+'-flags.json');ids=[i for m in x['matches'] for i in m['ids']];ck(state+' '+surface+' selected public ids',(a['personnel_id'] in ids)==(state=='set') and x['status']==200)
b=row('existing-failure-before.json');c=row('existing-failure-after.json');r=row('existing-failure-retry-row.json');ck('existing fault full28 exact',b==c and len(b)==28);ck('existing fault fullaudit exact',rows('existing-failure-audit-before.json')==rows('existing-failure-audit-after.json'));ck('existing fault actual503',j('existing-failure-network.json')['calls'][0]['status']==503);ck('existing retry preserves all siblings',changed(b,r)=={'emergency_contact_phone','updated_at'} and r['emergency_contact_phone']=='907-555-0166')
for actor,field,value in [('manager','emergency_contact_phone','907-555-0188'),('personnelScoped','emergency_contact_name','Scoped Synthetic Contact')]:
 b=row('scope-'+actor+'-sds-before.json');c=row('scope-'+actor+'-sds-after.json');ck(actor+' native save siblings',changed(b,c)=={field,'updated_at'} and c[field]==value)
for pref in ['scope-alpha-denials','scope-view-only-denied']:
 for org in ['orgA','orgB']:
  for table in ['personnel','personnel_extended_info']:ck(pref+' '+org+' '+table+' full literal',rows(pref+'-before-'+org+'-'+table+'.json')==rows(pref+'-after-'+org+'-'+table+'.json'))
 b=rows('scope-foreign-attempt-audit-after.json' if pref=='switch-b' else pref+'-audit-before.json');c=rows(pref+'-audit-after.json');success=lambda x:[y for y in x if y['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared']];ck(pref+' success audit exact',success(b)==success(c))
for target in ['bravo','unassigned','foreign-person','missing']:
 for family in ['ack','sds']:ck(target+' '+family+' actual404',response('scope-alpha-denials-'+target+'-'+family+'.json')['status']==404)
for family in ['ack','sds']:ck('view-only '+family+' actual403',response('scope-view-only-denied-alpha-'+family+'.json')['status']==403)
for family in ['ack','sds']:ck('operate ordinaryAPI '+family+' 200',response('scope-operate-'+family+'-allowed.json')['status']==200)
ck('operate native detail403', 'heading "403"' in txt('scope-operate-detail-denial.json') and 'More info' not in txt('scope-operate-detail-denial.json'))
for name in ['scripts/verification/fixtures.mjs','src/lib/server/adapters/supabaseDataStore.ts','src/lib/server/adapters/supabaseScopeEnforcement.ts']:
 blobs=[subprocess.check_output(['git','show',rev+':'+name],cwd='/home/waffleflops/.cache/t2t-1360-personnel-sds-awards') for rev in ['cf195b9b76eb313d2bac0af3f175ed22c8791d71','287823cc920237e699e5f3c5b6443bf4cc3b8c28']];ck('baseline/final literal source '+name,blobs[0]==blobs[1])
base=Path('/home/waffleflops/.cache/t2t-1360-personnel-detail/.verification/evidence/verify-trooptotask/personnel-detail-baseline')
for family in ['ack','sds']:
 x=json.loads((base/('scope-bravo-denied-'+family+'.json')).read_text());text='\n'.join(y.get('text','') for y in x['content']);b=json.loads(re.search(r'```json\n(.*?)\n```',text,re.S).group(1));f=response('scope-alpha-denials-bravo-'+family+'.json');ck('baseline real Bravo '+family+' literal denial status/body',b['status']==f['status']==404 and b['body']==f['body'])
success=lambda x:[r for r in x if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared']]
for pref,status in [('early-empty-denied',404),('scope-empty-denied',404),('scope-viewer-denied',403),('scope-foreign-confirmed',404),('switch-b',403)]:
 for org in ['orgA','orgB']:
  for table in ['personnel','personnel_extended_info']:
   ck(pref+' '+org+' '+table+' full literal no effects',rows(pref+'-before-'+org+'-'+table+'.json')==rows(pref+'-after-'+org+'-'+table+'.json'))
 ck(pref+' successful audit literal no effects',success(rows('scope-foreign-attempt-audit-after.json' if pref=='switch-b' else pref+'-audit-before.json'))==success(rows(pref+'-audit-after.json')))
 if pref not in ['scope-foreign-confirmed','switch-b']:
  for family in ['ack','sds']:ck(pref+' '+family+' literal denied status',response(pref+'-alpha-'+family+'.json')['status']==status)
for family in ['ack','sds']:
 f=response('scope-foreign-org-denied-a-target-'+family+'.json');bfile=base/('scope-foreign-org-denied-'+family+'.json')
 if not bfile.exists():bfile=base/('scope-foreign-denied-a-target-'+family+'.json')
 if not bfile.exists():
  b=j('foreign-status-literal-comparison.json')['baseline'+family.upper()]
 else:
  btxt='\n'.join(x.get('text','') for x in json.loads(bfile.read_text()).get('content',[]));b=json.loads(re.search(r'```json\n(.*?)\n```',btxt,re.S).group(1))
 ck('foreign '+family+' literal404 Organization concealment',f['status']==b['status']==404 and f['body']==b['body']==json.dumps({'message':'Organization not found'},separators=(',',':')))
for n in ['switch-b-view-ack-denied.json','switch-b-view-sds-denied.json','switch-b-foreign-id-concealed.json']:
 r=response(n);ck(n+' permission first403',r['status']==403 and json.loads(r['body'])['message']=="You don't have permission. This requires Personnel can manage permissions. Talk to your organization owner or admin.")
ids=j('seed-lifecycle.json')['ids'];target=ids['person'];bravo=ids['duplicateBravo']
def publicids(n):
 r=response(n);ck(n+'200 selected public result',r['status']==200);return sorted(x for m in r['matches'] for x in m['ids'])
for n,expectedids in [('early-empty-ack-ids.json',[]),('scope-empty-flags.json',[]),('scope-alpha-flags.json',[target]),('scope-view-only-flags.json',[target]),('scope-viewer-flags.json',[target,bravo]),('consumer-home-ack-ids.json',[target,bravo]),('switch-a-ack-ids.json',[target,bravo]),('switch-b-ack-ids.json',[]),('switch-a-returned-ack-ids.json',[target,bravo]),('tail-roster-cleared-ack-ids.json',[])]:ck(n+' actual authorized exact IDs',publicids(n)==sorted(expectedids))
# Public scope IDs are independently derived from actual Person and full extended-info projections.
personmap={r['id']:r for r in rows('scope-viewer-denied-before-orgA-personnel.json')}
ackrows=rows('scope-viewer-denied-before-orgA-personnel_extended_info.json');actual={r['personnel_id'] for r in ackrows if r['award_tracking_acknowledged_at'] is not None}
ck('provider acknowledged IDs exact public viewer',sorted(actual)==publicids('scope-viewer-flags.json'))
alpha=next(r['group_id'] for r in personmap.values() if r['id']==target)
ck('provider Group-filtered IDs exact public Alpha',sorted(x for x in actual if personmap[x]['group_id']==alpha)==publicids('scope-alpha-flags.json'))
# All original rows must stay literal before cleanup; all collections must restore literal afterward.
tables=['personnel','personnel_extended_info','groups','organization_rank_catalog','leader_notes','counseling_records','personnel_documents','personnel_follow_ups','personnel_trainings','personnel_ict_completions','availability_entries','rating_scheme_entries']
for org in ['orgA','orgB']:
 for table in tables:
  before=rows('before-'+org+'-'+table+'.json');mid=rows('before-cleanup-'+org+'-'+table+'.json');after=rows('after-cleanup-'+org+'-'+table+'.json');midmap={r['id']:r for r in mid}
  ck('beforecleanup '+org+' '+table+' original entire rows literal',all(midmap.get(r['id'])==r for r in before))
  ck('aftercleanup '+org+' '+table+' whole collection literal',before==after)
ck('16 recorded seed IDs',len(ids)==16)
allafter=[r for org in ['orgA','orgB'] for t in tables for r in rows('after-cleanup-'+org+'-'+t+'.json')]
for label,value in ids.items():ck('seed absence '+label,not any(value in [r.get('id'),r.get('personnel_id')] for r in allafter))
allbeforeperson=rows('scope-alpha-denials-before-orgA-personnel.json');allmidperson=rows('before-cleanup-orgA-personnel.json');ck('dedicated parent full row unchanged',next(r for r in allbeforeperson if r['id']==target)==next(r for r in allmidperson if r['id']==target))
ck('server-created SDS cascade absent',rows('after-cleanup-orgA-personnel_extended_info.json')==rows('after-cleanup-orgB-personnel_extended_info.json')==[])
audits=rows('successful-audit-records.json');succ=success(audits)
from collections import Counter
ck('18 actual successful audit actions',Counter(r['action'] for r in succ)=={'personnel.extended_info.updated':7,'personnel.award_tracking_acknowledged':6,'personnel.award_tracking_cleared':5})
ck('success audit identity types/details',all(r['org_id']==a['organization_id'] and r['resource_type']=='personnel' and r['resource_id'] in [target,ids['duplicateAlpha'],bravo] and r['details']=={} and r['severity']=='info' for r in succ))
# Each successful mutation remains auditable, including clear-missing replay.
for pid,action,num in [(target,'personnel.extended_info.updated',7),(target,'personnel.award_tracking_acknowledged',5),(bravo,'personnel.award_tracking_acknowledged',1),(target,'personnel.award_tracking_cleared',2),(ids['duplicateAlpha'],'personnel.award_tracking_cleared',2),(bravo,'personnel.award_tracking_cleared',1)]:ck('audit target/action multiplicity '+pid+' '+action,sum(r['resource_id']==pid and r['action']==action for r in succ)==num)
for n in ['initial-doctor.json','early-empty-after-doctor.json','final-doctor-before-seed-cleanup.json','final-doctor-after-seed-cleanup.json','cleanup-tail-doctor.json']:
 d=j(n);ck(n+' actual PASS frozen identity',d['status']=='PASS' and d['revision']=='287823cc920237e699e5f3c5b6443bf4cc3b8c28' and d['candidate']=='c353948a812ff9ecfb503d68f8f5b9fa128eb12a7c921aebaa9015f8c718f328' and d['origin']=='http://127.0.0.1:34017')
ck('maintained row cleanup success',j('clean-recorded-seeds.json')['cleaned']);ck('maintained owned cleanup PASS',j('owned-cleanup.json')['status']=='PASS' and j('owned-cleanup.json')['phase']=='cleaned')
d=j('independent-disposal.json');ck('owned exact project nine ports closed',len(d['ports'])==9 and all(x['connectExit']!=0 for x in d['ports'].values()));ck('owned exact project containers volumes absent',all(x['exit']==0 and x['stdout']=='' for x in d['resources'].values()));ck('owned process identities absent',len(d['ownedProcessIdentities'])==4 and all(x['absent'] for x in d['ownedProcessIdentities'].values()));ck('owned private session absent',d['privateSessionAbsent']);ck('new exclusive task TMPDIR absent without old temp absence claim',d['tmpdir']['newExclusiveTaskDirectory'] and d['tmpdir']['absent'] and d['tmpdir']['path']=='/home/waffleflops/.cache/vw1r')
for n in ['scoped-actors-command.json','native-consumers-switch-command.json','final-restoration-cleanup-command.json']:ck('original failed scratch receipt retained '+n,j(n)['exit']==1)
ck('false native roster arrival is visibly Dashboard', 'RootWebArea "Verification Organization A — Dashboard — Troop to Task"' in txt('consumer-native-roster.json') and 'RootWebArea "Verification Organization A — Dashboard — Troop to Task"' in txt('tail-native-original-roster.json'))
for n in ['tail-roster-native-after.json','tail-roster-reload-after.json']:
 s=txt(n);ck(n+' actual settled restored Personnel roster', 'Add Person' in s and 'Able' in s and 'Baker' in s and 'MapLifecycle' not in s and 'MapDuplicate' not in s)
ck('early helper prerequisite failed before action',j('early-driver-prerequisite-failure.json')['exit']==1)
result={'result':'SCOPED_SDS_ACK_SOURCE_AND_RECOVERY_OBSERVATIONS_PASS','source':'287823cc920237e699e5f3c5b6443bf4cc3b8c28','checks':checks,'count':len(checks),'pngsVisuallyReviewed':32,'limits':['Artifact review; no independent execution or model diversity','Prior partial run stays INCONCLUSIVE','No exact prior B-view/A-ID journey; 403 checked against source ordering and adjacent baseline only','No native ACK UI, server stream fault, provider partial mutation, cross-tab hold, or performance acceptance','Whole issue #1360 stays open; full publication diff pending']}
Path(str(p)+'-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all':all(x['pass'] for x in checks),'path':str(p)+'-review.json'}))
