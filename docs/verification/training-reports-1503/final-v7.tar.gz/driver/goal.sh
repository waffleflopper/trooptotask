#!/usr/bin/env bash
# usage: goal.sh VALUE  (page 2 must be on settings/policies) - native fill + Save click via fresh snapshot UIDs
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7; D=$E/driver/d.sh; cd $ROOT
v=$1; ts=$(date +%H%M%S)
T() { local l=$1; shift; $D "$l" -- npm run --silent verify:app -- tool "$@" --worker 1; }
T goal$v-snap0 take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/goal$v-$ts-0.txt\"}" >/dev/null
uid=$(grep 'spinbutton "Training readiness goal' $E/snap/goal$v-$ts-0.txt | sed -E 's/.*uid=([0-9_]+).*/\1/')
T goal$v-fill fill "{\"pageId\":2,\"uid\":\"$uid\",\"value\":\"$v\"}" | grep -o 'Successfully[^"]*'
T goal$v-snap1 take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/goal$v-$ts-1.txt\"}" >/dev/null
save=$(sed -n '/region "Training Readiness"/,/spinbutton/p' $E/snap/goal$v-$ts-1.txt | grep 'button "Save"' | sed -E 's/.*uid=([0-9_]+).*/\1/')
grep -A4 'region "Training Readiness"' $E/snap/goal$v-$ts-1.txt
T goal$v-save click "{\"pageId\":2,\"uid\":\"$save\"}" | grep -o 'Successfully[^"]*'
T goal$v-wait wait_for '{"pageId":2,"text":["Saved"],"timeout":10000}' | grep -o 'Element[^"]*\|Timed[^"]*'
T goal$v-snap2 take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/goal$v-$ts-2.txt\"}" >/dev/null
sed -n '/region "Training Readiness"/,$p' $E/snap/goal$v-$ts-2.txt | head -8
T goal$v-shot take_screenshot "{\"pageId\":2,\"filePath\":\"$E/png/goal$v-$ts.png\"}" >/dev/null
