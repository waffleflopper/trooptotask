import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ExcelJS from 'exceljs';
const root = path.dirname(fileURLToPath(import.meta.url));
const read = async (name) => JSON.parse(await fs.readFile(path.join(root,name),'utf8'));
const backup = await read('owner-a.json');
const book = new ExcelJS.Workbook();
await book.xlsx.readFile(path.join(root,'owner-a.xlsx'));
const expectedTables = ['organizations','groups','personnel','personnel_extended_info','organization_rank_catalog','leader_notes','personnel_follow_ups','counseling_records','personnel_documents','availability_entries','status_types','assignment_types','daily_assignments','special_days','notifications','audit_logs','data_exports','organization_memberships','organization_invitations','organization_invitation_email_outbox','access_request_organization_invitation_links','dashboard_configs','getting_started_progress','user_org_preferences','user_pinned_groups','beta_feedback','sign_in_rosters','training_types','training_views','personnel_trainings','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress','deletion_requests','ict_tasks','personnel_ict_completions','rating_scheme_entries'];
assert.deepEqual(backup.sectionInventory.map(s=>s.table).sort(),expectedTables.sort());
const normalize = (text) => text.replace(/[ _]/g,'').toLowerCase();
const index = (rows) => { const result = new Map(rows.map(row=>[row.id,row])); assert.equal(result.size,rows.length,'Duplicate source ID'); return result; };
const matches = (expected, actual) => { for (const row of expected) assert.deepEqual(actual.get(row.id),row,`Changed or missing saved row ${row.id}`); };
const inventory = book.getWorksheet('Export Inventory');
assert.equal(inventory.rowCount,39);
const report=[];
for (const section of backup.sectionInventory) {
 const source = (await read(`before-json-${section.table}.json`)).rows;
 const jsonRows = backup[section.key];
 assert.deepEqual(jsonRows,backup.sections[section.key]);
 assert.equal(jsonRows.length,section.rowCount);
 matches(source,index(jsonRows));
 const sheetName = `Raw - ${section.title}`.slice(0,31);
 const sheet = book.getWorksheet(sheetName);
 assert.ok(sheet,`Missing raw sheet ${section.table}`);
 const headers = sheet.getRow(1).values.slice(1);
 const prior = ['data_exports','audit_logs','notifications'].includes(section.table) ? (await read(`before-excel-${section.table}.json`)).rows : source;
 const idColumn=headers.findIndex(h=>h==='Id')+1;
 const excelRows=new Map();
 for (let n=2;n<=sheet.rowCount;n++) {
  const row=sheet.getRow(n); const id=row.getCell(idColumn).value;
  assert.ok(!excelRows.has(id),'Duplicate workbook source ID');excelRows.set(id,row);
 }
 const actorId=(await read('reload-lifecycle.json')).rows[0].requested_by;
 const visible = section.table==='notifications' ? prior.filter(row=>row.user_id===actorId) : prior;
 for(const expected of visible) {
  const actual=excelRows.get(expected.id);assert.ok(actual,`Workbook missing saved ${section.table} ${expected.id}`);
  for(const [key,value] of Object.entries(expected)) {
   const label = ({clinic_role:'Duty Role',deros:'PCS / DEROS'})[key] ?? key;
   const column=headers.findIndex(h=>normalize(h)===normalize(label))+1;
   assert.ok(column>0,`Workbook missing ${section.table} field ${key}`);
   const cell=actual.getCell(column).value??null;
   assert.deepEqual(typeof value==='object'&&value!==null ? JSON.parse(cell) : cell,value,`Workbook changed ${section.table} ${key}`);
  }
 }
 if(!['data_exports','audit_logs','notifications'].includes(section.table)) {
  assert.equal(jsonRows.length,source.length);assert.equal(sheet.rowCount-1,source.length);
 }
 report.push({table:section.table,jsonRows:jsonRows.length,excelRows:sheet.rowCount-1,precedingRowsCompared:visible.length});
}
assert.equal(backup.assignmentTypes.length,1008);assert.equal(backup.ictTasks.length,1007);
const later=await read('reload-lifecycle.json');
for(const [name,meta] of [['owner-a.json','json-save.json'],['owner-a.xlsx','excel-save.json'],['unmatched-failure-a.json','unmatched-failure-save.json'],['retry-a.json','retry-save.json']]) {
 const save=await read(meta);const bytes=(await fs.stat(path.join(root,name))).size;assert.equal(save.bytes,bytes);
 assert.equal(later.rows.filter(row=>row.file_size_bytes===bytes&&row.status==='completed'&&row.completed_at!==null).length,1,`Unconfirmed lifecycle ${name}`);
}
assert.equal(later.rows.filter(row=>row.status==='failed'&&row.completed_at!==null&&row.file_size_bytes===null).length,1);
const failure=await read('failure2-network.json');assert.equal(failure.calls[0].status,500);assert.equal((await read('failure2-capture-state.json')).captured,false);
const retry=await read('retry-network.json');assert.deepEqual(retry.calls.map(c=>c.status),[500,200]);
await fs.writeFile(path.join(root,'download-comparison.json'),JSON.stringify({status:'PASS',report,lifecycleCompleted:4,lifecycleFailed:1,nativeFailureStatus:500,explicitRetryStatus:200},null,2)+'\n');
console.log(JSON.stringify({status:'PASS',sections:report.length,assignmentRows:1008,taskRows:1007,lifecycleCompleted:4,lifecycleFailed:1}));
const other = await read('owner-b.json');
assert.notEqual(other.organizationId,backup.organizationId);
for (const section of other.sectionInventory) {
 const ownRows=other[section.key];assert.deepEqual(ownRows,other.sections[section.key]);assert.equal(ownRows.length,section.rowCount);
 const orgColumn=section.table==='organizations'?'id':['audit_logs','data_exports','dashboard_configs'].includes(section.table)?'org_id':'organization_id';
 for(const row of ownRows)assert.equal(row[orgColumn],other.organizationId,`Foreign row admitted by B ${section.table}`);
 try {const preceding=(await read(`before-b-${section.table}.json`)).rows;matches(preceding,index(ownRows));if(!['audit_logs','data_exports'].includes(section.table))assert.equal(ownRows.length,preceding.length);} catch(error){if(error.code!=='ENOENT')throw error;}
}
for(const section of backup.sectionInventory){const orgColumn=section.table==='organizations'?'id':['audit_logs','data_exports','dashboard_configs'].includes(section.table)?'org_id':'organization_id';for(const row of backup[section.key])assert.equal(row[orgColumn],backup.organizationId,`Foreign row admitted by A ${section.table}`);}
assert.equal((await read('viewer-denied-http.json')).status,403);assert.equal((await read('foreign-target-denied-http.json')).status,404);
assert.deepEqual(index((await read('after-denial-a-lifecycle.json')).rows),index((await read('reload-lifecycle.json')).rows));
assert.deepEqual(index((await read('after-denial-b-lifecycle.json')).rows),index((await read('b-json-lifecycle.json')).rows));
console.log(JSON.stringify({status:'PASS',nativeBSections:other.sectionInventory.length,viewerStatus:403,foreignTargetStatus:404,deniedLifecycleUnchanged:true}));
const seeded = new Map();const add = (table, rows) => {const ids=seeded.get(table)??new Set();for(const row of rows)ids.add(row.id);seeded.set(table,ids);};
for(const batch of (await read('seed-pages.json')).batches)add(batch.table,batch.records.map(r=>r.row));
for(const batch of (await read('seed-dashboard.json')).batches)add(batch.table,batch.rows);
add('audit_logs',(await read('seed-audit.json')).rows);
const cleanup=[];
for(const table of ['status_types','availability_entries','assignment_types','daily_assignments','special_days','training_types','personnel_trainings','training_views','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress','groups','personnel','organization_rank_catalog','user_pinned_groups','getting_started_progress','user_org_preferences','ict_tasks','personnel_ict_completions','dashboard_configs','rating_scheme_entries','data_exports','audit_logs']) {
 const before=(await read(`before-json-${table}.json`)).rows;const after=(await read(`after-clean-${table}.json`)).rows;
 const removed=seeded.get(table)??new Set();const original=before.filter(row=>!removed.has(row.id));
 matches(original,index(after));for(const row of after)assert.ok(!removed.has(row.id),`Temporary seed retained ${table}`);
 if(!['data_exports','audit_logs'].includes(table))assert.deepEqual(index(original),index(after));
 cleanup.push({table,originalRows:original.length,afterRows:after.length});
}
assert.deepEqual(index((await read('b-reload-lifecycle.json')).rows),index((await read('b-json-lifecycle.json')).rows));
await fs.writeFile(path.join(root,'cleanup-comparison.json'),JSON.stringify({status:'PASS',cleanup},null,2)+'\n');
console.log(JSON.stringify({status:'PASS',originalSourceSetsPreserved:22,allSeedDependentComparisonsBeforeCleanup:true,bLifecyclePersistedAfterReload:true}));
