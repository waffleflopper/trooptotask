from pathlib import Path
import json
import os
import subprocess
import time

root = Path.cwd()
environment = os.environ.copy()
environment.update({
    'PATH': '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + environment['PATH'],
    'TMPDIR': '/home/waffleflops/.cache/t2t-1502-tmp',
    'NODE_DISABLE_COMPILE_CACHE': '1',
    'PUBLIC_SUPABASE_URL': 'http://127.0.0.1:59999',
    'PUBLIC_SUPABASE_ANON_KEY': 'ci-synthetic-anon',
    'SUPABASE_SERVICE_ROLE_KEY': 'ci-synthetic-service',
    'ACCOUNT_SETUP_LINK_SECRET': 'ci-synthetic-setup',
    'ACCOUNT_SETUP_SESSION_SECRET': 'ci-synthetic-session',
    'APP_PUBLIC_ORIGIN': '',
    'PUBLIC_APP_ORIGIN': '',
    'PUBLIC_SITE_URL': '',
    'APP_PUBLIC_ORIGIN_ALLOWLIST': ''
})
Path(environment['TMPDIR']).mkdir(parents=True, exist_ok=True)
commands = [
    ['npm', 'run', 'format'],
    ['npm', 'run', 'format:check'],
    ['npm', 'run', 'lint'],
    ['npm', 'run', 'governance:check'],
    ['npm', 'run', 'check'],
    ['npm', 'run', 'test', '--', '--maxWorkers=4'],
    ['npm', 'run', 'build']
]
results = []
for index, command in enumerate(commands):
    name = command[2].replace(':', '-')
    log = root / f'.verification/1503-v8-{name}.log'
    current_environment = environment.copy()
    if name == 'build':
        current_environment['APP_PUBLIC_ORIGIN'] = 'http://127.0.0.1:4173'
    started = time.time()
    print(f'Start {name}', flush=True)
    with log.open('w') as output:
        completed = subprocess.run(command, cwd=root, env=current_environment, stdout=output, stderr=subprocess.STDOUT)
    results.append({'command': command, 'exitCode': completed.returncode, 'seconds': round(time.time() - started, 3), 'log': str(log.relative_to(root))})
    (root / '.verification/1503-v8-required-checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(f'{name}: exit {completed.returncode}', flush=True)
raise SystemExit(any(result['exitCode'] != 0 for result in results))
