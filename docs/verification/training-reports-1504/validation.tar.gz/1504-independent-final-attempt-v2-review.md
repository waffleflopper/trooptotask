# Independent nonvisual final-attempt-v2 review — #1504 / PR1511

Bounded verdict: the three correction-source files are sound at the pinned commit, and v2 supplies actual native structured-page mapping, seven independently observable native print invocations, saved PDF rendering, and native Enter/Retry focus proof. Two acceptance conditions remain open: the no-applicable report's extra portrait/textless page (P1) and boundary paging focus falling to BODY (K1). This is not final whole-task acceptance.

This review inspected existing source and expanded artifacts only. No application, test, gate, browser, service, database, connector or live print execution was performed by this reviewer. No images or PDF page images were viewed. PDF metadata and extracted text were inspected without visual judgment. T3 Claude owns layout, clipping, colors, legibility and page-break judgments. The reviewer inherits the parent model; there is no model diversity or independent live execution. The portable Poteto reviewer persona and project engineering/testing instructions from prior rounds remain the review method.

## Candidate and review composition

- Existing complete cumulative source review: base `a59c6c92bba242cde37f15a5d59e6d305e5267ac` → `2e3aea52ad01e33e173b769f285b0ab6103547d7`, 137 changed paths, documented in `.verification/1504-independent-cumulative-source-review-v1.md`, SHA-256 `c54fb7fc6588687f14e1af38c5b6e910de1a9e1b619b55ef9ec5470be036bdeb`.
- Existing expanded v1 review: `.verification/1504-independent-final-attempt-v1-artifact-review.md`, SHA-256 `702092b2c8ded6d3a2fce5e4c43d33a6018c9710771dd57636157875662f8fe1`. Its nonprint coverage and limitations stay pinned to 2e3; they are not recharacterized as v2 reruns.
- This source round: exact commit `580c24fa10d517065894ca4bc1e6856746890f7c`. Read-only Git comparison against 2e3 finds exactly three changed text/source files and the addition of `docs/verification/training-reports-1504/final-attempt-v1.tar.gz` (SHA-256 `0347ab3ccd6e78bc303fe65c8171126e9b0b98d4e9bf108b9cdd4ad33ab85104`). The earlier 137-path census and the v2 138-path source checkpoint agree: no other earlier source bytes changed.
- V2 live identity: candidate `933df98665f716d17a0cea97fe3f9ac0ca25443db2ce2f9e04c88e9c1c0e7104`; session `e0b0c74a-31e4-4474-81f0-30a8509a67a1`; origin `http://127.0.0.1:42797`; Chromium 152.0.7977.82, Arch Linux.
- Native app page: ID 2, isolated context `map-trainingConfigure-0d2bbcee-cfb4-4689-b4e2-dcee95797438`. Page 1 is about:blank. Actual `014-list-pages.stdout` and `215-list-pages-final.stdout` contain structured page objects with exact IDs, URLs, titles and selected/context fields. No second document has the exact report URL in those observations.
- Root's seven v3 gate receipts bind to 580c24fa and report all commands exit 0, 690 test files / 6,880 tests, zero type errors/warnings, 15 lint warnings / zero lint errors, and successful production build. The captured check/test logs support these totals; this reviewer did not run them. `gate-binding.json` also binds the focused print-control test receipt.
- Future CSS/component/paging changes, the recipe's post-cleanup reload note, future commits and future live artifacts are outside this report. Source reads use pinned Git blobs so concurrent later working-tree edits cannot silently expand this verdict.

The exact three-file diff is 3,947 bytes, SHA-256 `7117faf12c573f358402051bec80945636d85890906b3ae2ce1994d5fdfafdbe`.

| Reviewed file | 2e3 bytes; SHA-256 | 580c24fa bytes; SHA-256 |
|---|---|---|
| `scripts/verification/daemon.mjs` | 12787; `c28b1e68f74fb4481fe80c09f2d31bdd35f59026e36ece87e68bbd6619f72510` | 12825; `ce95182391fda1948594697e8d96bf60e44d7fae04f89f87b143aa4f63fc3bcf` |
| `src/features/training/components/TrainingReportsPage.svelte` | 23286; `b4fa53eaa63f1307a08ef1bba616c54d8809aaeaa9ad74a4b26a24fa3fdb4df8` | 23411; `702704e314e66ac4e8798b5b76fd3d9a9edaf260e680a8a73f3c273ec8e14dde` |
| `src/features/training/components/TrainingReportsPage.test.ts` | 12760; `9d069742e3b51ecd99be016fb5d40538213178ec934f9f4f0323efb6539eecb1` | 14292; `9e9fe2bf653851dc505866d335c9f292c2d82275e0ce3a0f3fdffa24892f6132` |

## Correction-source review

`scripts/verification/daemon.mjs:236` adds only `--experimentalStructuredContent` to the owned native MCP launch. Installed MCP 1.10.1 defaults that option false, and its ToolHandler attaches structured response data only when enabled. The flag preserves the existing private profile, executable, port and ownership handling. V2 `002`, `014` and `215` actually deliver `structuredContent.pages`; this is positive support for the installed transport/schema rather than a claim based on the implementation report. The earlier print-control source review remains applicable to unchanged capture/control code. This run exercises the positive capture and detachment path; it does not independently rerun every foreign/reloaded/timeout/path-replacement negative case.

`TrainingReportsPage.svelte:173–186` extracts the existing tick-plus-region focus into `focusDetail()`. Initial `openDetail()` and the explicit `retryDetail()` call it; the Retry callback at line 582 uses that handler. Ordinary pagination, page-size and filter callbacks are unchanged. This keeps focus recovery tied to an explicit initial open or Retry action and avoids making asynchronous response arrival a focus trigger. The model, section contents, charts and CSS have no changes in this correction.

`TrainingReportsPage.test.ts:307–335` adds a meaningful interaction test at the component/session/fetch boundary. It independently supplies a 30-row detail fixture, loads 25 page-1 rows, fails page 2 with 503, verifies the old range remains, activates a focused Retry, checks the attempted page-2 URL, then verifies region focus, the 26–30 range and absence of the alert. These are observable effects and attempted-scope retention, not copy/geometry assertions or an implementation mirror. Its simulated click and immediately resolved response do not alone prove native Enter or focus while a real response is held; the v2 receipts supply those additional observations. It does not cover K1.

No new authorization, model, export-scope, migration, retained-consumer or performance defect was found in these three deltas. The complete earlier source report supplies those wider conclusions at its own pin; this round is not another entire application sweep.

## Expanded archive integrity and evidence boundaries

Archive `docs/verification/training-reports-1504/final-attempt-v2.tar.gz`: 4,659,392 bytes; SHA-256 `a7eebee6b56f22187bc73da4b00b07f75f74bae655bd3e65d39b9ba2c72a7c05`. Expanded root `.verification/packaged/1504/final-attempt-v2`.

I checked every inventory payload's actual size/hash and every tar regular member's bytes against the expansion. The inventory has 832 unique payload entries; the expansion and tar have 833 regular files including the inventory itself. There are no missing/extra payloads, hash failures, duplicate inventory paths, symlinks, special members or traversal/unsafe member paths. `inventory.json` is 122,878 bytes; SHA-256 `06ca3a6b65df0ec5c979ebb774a647959d6abb5787e93cd3861c34cdc03c6ed0`. It is the complete artifact census and binding; repeating its 832 lines here would not add review evidence.

All 776 UTF-8 files, including the inventory, were scanned against token-value/JWT/Bearer/Supabase secret/private-key patterns with no matches. V2 has no redaction record or redacted payload. This is the final UTF-8 census, not the different v1 redaction-time count. This pattern scan does not promise detection of every possible secret format.

The action index has 316 unique named receipts and 316 complete stdout/stderr pairs; no overwritten/duplicate names or missing captures were found. There are 315 exit-0 actions. The only nonzero action is `016-click-training-nav`, exit 2 for a stale sidebar UID; the subsequent native breadcrumb action `018` repairs navigation. A command exit of 0 is not automatically a successful application result: deliberate 503 responses and beforeprint=0 states are retained below.

There are 64 AX snapshot files, 65 total .txt files, 10 PDF files, 33 PDF-page PNGs and 13 other PNG screenshots. PNG bytes, names, hashes and dimensions were inspected only. The 33 PDF PNGs represent 31 PDF pages plus two higher-resolution duplicates of the wide report's pages 1 and 2; they are not 33 distinct PDF pages. This v2 uniqueness result does not restore v1's overwritten `snap-p2-matrix-pre` or `snap-p3-group-open` captures, which remain missing as stated in the v1 report.

## Independently derived literal fixtures and observed data

Expectations derive from fixture personnel/type/completion rows and fixed day 2026-10-04, not the driver's decoded summaries. Org A is `f1b5242a-c278-4c2e-9e14-2ae7f3613a04`; Alpha is `429aed2d-00d7-46dd-8edf-065e83038b73`; Bravo is `64b399dc-5e03-451f-ae7b-ea89bcea45a6`. Required training is `b0c5ee05-d6cb-490d-a073-67e5ac27ea5a`; Targeted training is `c9ea77d1-9b63-4933-83c7-1a8f77a4a165`. The horizon end is 2027-01-02 and the goal is 90%.

| Fixture state | Independently expected | Actual observations |
|---|---|---|
| Original | 3 soldiers; 4 applicable pairs; 1 ready, 0 expired, 3 missing, 0 lapses; 25% → 25%. Required risk 2/0 before Targeted 1/0. | Original provider row and `s007`; Required Total detail contains Baker then Unassigned, both Not Done; cell and Focus requests/scopes are distinct and both focus the region (`008–015`). |
| Two literal dated imports | Baker Required: 2024-10-04 → 2025-10-04, expired 365 days. Able Targeted: 2025-10-19 → 2026-10-19, 15 days left and lapses 2026-10-20. Totals 2 ready / 1 expired / 1 missing / 1 lapse, 50% → 25%. | Preview `024–026` shows 2 valid selected rows while provider count stays 1. Batch POST `029` is 200. Actual provider `032` has the two new IDs and literal dates; `s035/s037` match after reload. |
| Dated exact detail/order | Required Total: Unassigned Not Done first, Baker Expired second. Alpha×Targeted: only Able, Yes for horizon lapse. Required risk 2/0 then Targeted 0/1; Focus Required 25% → 75%, Alpha 50% → 100%. | `s039/s041` and the full report snapshot match these exact identities, order, dates, states and figures. |
| 26 temporary people | All 26 require Required; only temp00 additionally requires Targeted. Together with original data: 29 people, 31 applicable pairs, 2 ready / 1 expired / 28 missing / 1 lapse; 6% → 3%. Required affected count 28. | `050` journals tag `f92c4a50`; `s052` matches. Actual page-1 `070` array is temp00–temp24, all Required/Not Done/Alpha. Actual page-2 `095` is temp25, Unassigned, then Baker expired. Combined 28 unique rows, no omissions or duplicates. |
| Seed cleanup and completion deletion | Return to the original 3 people / 4 pairs / 25% → 25% / 1,0,3,0. | `118` cleanup, `s120`; visible editor deletions `198/199` and `205/206` have actual DELETE 200 results; `s209/s213` restore original matrix/report. |

Preview's generic loaded-row counter includes the raw header; the actual selected/valid count is two and no preview write is shown. Temporary counts are independently derived from the seed definition and actual returned rows, not merely copied from a chart.

## Native focus and request behavior

- Original cell open and Focus link: `010/013` report `SECTION#training-affected-soldiers`.
- Initial seeded 503: `055/056` retain the actual error and no loaded range. Native Tab reaches the 25-row radio then Retry (`060/062/063`). Native Enter `064`, followed by held-state `065`, reports the region focused, busy true and “Loading affected soldiers.” The five generic tbody rows in this loading observation are skeletons (firstRow is null), not five loaded affected people. Real held request `066` is 200; after release, `068` retains region focus and shows Rows 1–25 of 28.
- Page-2 503: `082/083` retain page-1 rows/range and focus on Next. Native Shift+Tab reaches Retry (`088/089`). Native Enter `090`; held `091` reports region focus, busy true, “Loading page 2” and the old 1–25 range. The real held result `092` is 200; after release, `094` is still region-focused with Rows 26–28 of 28.
- The 100-row and 25-row controls retain their own radio focus (`075/078`); choosing 180 days retains horizon-radio focus and closes the detail (`102`). These observations support the correction's narrow focus behavior.
- At 1440, 1024 and 390 widths, `184/185/186` independently observe BUTTON Retry before native Enter and SECTION after load. Only the 1905-width held cases above prove the loading interval; the smaller-width checks prove their final focus/result. Later checks that reopen a previously loaded detail can retain old rows on failure; they must not be described as every width testing a fresh empty initial detail.
- Boundary paging remains defective: native Enter on Next `112→113` yields BODY on Rows 26–28; Enter on Previous `116→117` yields BODY on Rows 1–25. Pointer `098→099` also observes BODY. This is distinct from the repaired Retry path.

V2 checks failure/retry and a held response; it is not a fresh complete late-response/stale-scope suite. Full authorization, role boundaries, foreign-org, filter intersections, paging/export tails and other retained-consumer coverage remain grounded in the unchanged-source/v1 review with its stated gaps. In particular, v1's Baker rosterManager non-Training cards were Unavailable under that actor's lane contracts: those journeys are not passed flows, and v2 does not turn them into passed flows.

## Actual XLSX contents

I parsed the saved workbook's ZIP/XML directly rather than trusting `workbook_decode.json` or the driver's report. `accept/dated-unfiltered.xlsx` is 11,859 bytes, SHA-256 `4b76f969e35b276ab8b90451417ac63cb9cbaab92312ebaa2a2ba5cfe3786860`. Actual native observer/click/capture `042–047` binds the filename, XLSX MIME, buffer and export GET 200.

The sheet names and order are exactly **Summary, Forecast, Hot spots, Focus, Requirements**. There are no formula objects. Summary contains all eight normalized filter labels, 3 soldiers / 4 applicable pairs, goal 90, 50% → 25%, drop 25, and literal ready/expired/missing/lapse counts 2/1/1/1. Forecast contains today plus all 13 week-end rows through 2027-01-02; the one lapse belongs to 19–25 Oct and the shortened final interval is 28 Dec–2 Jan. Hot spots has Bravo, Unassigned, Alpha, Total; Required Total is 33%, Targeted 100% with a 100-point projected drop, and the overall 50% → 25%. Focus contains exactly the Required gap 25% → 75% and Alpha 50% → 100%.

Requirements has the three independently expected rows in order: Unassigned / Required / Not Done / No; Baker / Required / Expired / 365 days / 2025-10-04 / No; Able / Targeted / 15 days left / 2026-10-19 / lapse 2026-10-20 / Yes, with their exact ranks, names and areas. The quiet ready Able×Required pair, optional/nonapplicable pairs and foreign records are absent. The export occurs while a one-row Alpha×Targeted detail is open yet contains all three affected pairs for the unfiltered report, proving independence from active detail in this smoke. It does not rerun v1's larger full-filtered/unpaginated exports or access cases.

## PDF text, metadata and native print distinctions

I read actual metadata and extracted text of every page of every saved PDF. There are **31 PDF pages**, 30 landscape 792×612 and one portrait 612×792. None of this certifies visual legibility, chart clipping, semantic colors, page-break quality or row geometry.

Each of the ten save receipts below reports PASS with page ID 2, the full v2 candidate/session, the exact report URL and byte/hash values that match the actual saved PDF. Exact unfiltered URL is the v2 origin plus `/org/f1b5242a-c278-4c2e-9e14-2ae7f3613a04/training/reports`. Alpha and failed-refresh saves retain `?group=429aed2d-00d7-46dd-8edf-065e83038b73`. No-applicable saves `?group=64b399dc-5e03-451f-ae7b-ea89bcea45a6&types=c9ea77d1-9b63-4933-83c7-1a8f77a4a165`. Pre-save state receipts occur after native clicks and before the helper capture.

| Actual PDF | Receipt prefix; pre-save beforeprint | Pages | Bytes | SHA-256 |
|---|---|---|---|---|
| `alpha-detail-dark.pdf` | 145; 1 | 3 | 177624 | `df6de7fd15c7a97091606b6a06d2e82b93425f4e9fde8799d0638082c1d87645` |
| `dated-unfiltered-dark-r2.pdf` | 127; 0 | 3 | 173051 | `c947e365a2aa24fb121530a709f4401d3039f41ede9d1d54b80f92ab197ad598` |
| `dated-unfiltered-dark-r3.pdf` | 130; 0 | 3 | 173051 | `0194a389c8e4606c2554d69f4db16b12de20c02a8d322a8f849c9456808c6374` |
| `dated-unfiltered-dark-r4.pdf` | 132; 1 | 3 | 173051 | `66c61d888611f22dd4a2057d316f8bc7b99281a82a34e391678db5d914f02ccb` |
| `dated-unfiltered-dark.pdf` | 126; 0 | 3 | 173051 | `e0cbcfd5f86c4d16afe892874509329753d16f33209b8a897e9915ee137f8ac3` |
| `dated-unfiltered-light.pdf` | 121; 1 | 3 | 173059 | `60c865d417497abf13c1af085211b2621fa1878003440a38633bd3a486c5e036` |
| `failed-refresh-dark.pdf` | 155; 1 | 3 | 171284 | `72ca52935c506b405e68635f2ab3f4ab4eb30f779a95fec3daa667c9810ea48f` |
| `forecast-1920-collapsed-light.pdf` | 178; 1 | 3 | 173298 | `164eab657ad3356af4655789450c6d0252b57bbcb20853f7d64ce44dff307f88` |
| `no-applicable-dark.pdf` | 168; 1 | 2 | 70508 | `43f9497da472a778351c139c46ef09829e0c83adaea3cd4626127aad80b9a611` |
| `seeded-page1-25rows-light.pdf` | 072; 1 | 5 | 262708 | `cd315933ec97bfee39b9828c3341089911f055e122021a3e09651434523037cf` |

For prefixes 072, 121, 132, 145, 155, 168 and 178, actual pre-save observer state is armed true / before 1 / after 0: native invocation is observed independently of helper rendering. For 126, 127 and 130 the native click command was issued, but actual pre-save before is 0 / after 0. These three PDFs prove capture/rendering only; they do not prove that native click invoked print. A capture can itself render print media, so its resulting PDF cannot repair absent pre-save invocation evidence. No system dialog or physical-print success is certified.

All three dark failed-invocation attempts have the same extracted text and corresponding page-PNG bytes as successful dark-r4. I verified byte hashes for those PNGs; this is not an independent visual finding. The PDF binaries themselves differ. The 150-dpi wide-page PNG duplicates account for the two extra rasters; every actual PDF page has its corresponding page PNG.

Actual text supports the following narrower content conclusions:

- All applicable reports contain the title/subtitle, eight filter labels, Bottom line, Forecast, Hot spots, Type risk and Focus. The intentionally printed filter label “ROWS BY” is not a leaked interactive control. No PDF text contains Export Excel, Print brief, Clear filters, Retry, sidebar/org-switch/page-size controls or View-N-soldiers links.
- Light and dark unfiltered reports contain the literal dated 50% → 25%, counts 2/1/1/1, Required risk 2/0, Targeted risk 0/1 and the two expected Focus areas. Semantic text is present; color/readability claims belong to the visual owner.
- Alpha detail contains Group Alpha, 1 soldier, 100% → 50%, 2/0/0/1, and the one loaded Able×Targeted detail with 15D LEFT, Oct 19 2026, Yes and Rows 1–1 of 1.
- Failed-refresh preserves the shown Alpha filters/figures and prints the 503 stale-briefing alert, without Retry. Actual failed Bravo request `154` and `s153` support this. It is a report-refresh failure case, not a detail-failure print case.
- No-applicable page 1 contains Group Bravo / Targeted and the honest empty-state text. The fixture's Baker is nonapplicable to Targeted. Page 2 has zero extractable nonblank characters and is portrait; the driver's visual blank-page finding is independently corroborated only to that metadata/text extent.
- The seeded five-page PDF includes 6% → 3%, 2/1/28/1, risk Required 28/0 and Targeted 1/1, Focus Required 3% → 94% and Targeted 3% → 10%, then the loaded 1–25-of-28 detail. Extracted pages 4–5 contain all temp00–temp24 names exactly; temp25, Unassigned and Baker are on the unloaded second detail page and correctly absent from this capture. This proves the loaded 25 rows are retained in the printable document rather than truncated to a screen viewport. Visual row splits/header placement require Claude.
- The 1920 collapsed report contains Goal 90%, 50% start / 25% end and Today·4 Oct / 1 Nov / 1 Dec / 2 Jan ticks, plus all model sections. Text presence does not prove those marks fit, do not clip, or remain readable.

Native controls remain usable after captures and final structured page 2 remains in its original isolated context; positive temporary-client detachment is supported. No observation here proves all closed/reloaded/foreign/mismatched-document or publication-race controls under native runtime.

## Concrete residual findings and claim qualifications

**K1 — P2, boundary paging loses programmatic focus.** Pinned `src/lib/components/ui/data-table/data-table-pagination.svelte:27–28,37–38` disables Previous/Next when the completed page reaches its boundary. Training Reports leaves ordinary `onPage` delegated to the existing session handler. Actual `113-focus-after-enter-next.stdout` and `117-focus-after-enter-previous.stdout` return BODY after native keyboard activation. The explicit Retry focus fix does not address this separate route. Minimal correction: after an explicit boundary paging action that disables the activated button, preserve a useful focus destination (the remaining enabled pager or the affected region), without stealing focus on late/background results or unrelated control changes. Falsifiable acceptance: native Enter in both directions, including loading/final observations, retains a useful destination and preserves exact page identities; ordinary nonboundary/radio/filter behavior remains sound. This is open for the separately authorized correction.

**P1 — P2, no-applicable capture has an extra portrait/textless page.** `accept/pdf/no-applicable-dark.pdf`, bound by `168-e-print-save.stdout`, has landscape page 1 and portrait page 2 with no extractable text. Source context is pinned `src/app.css:350,404` (named landscape page and report root page assignment); the hypothesis that outside in-flow content creates an unnamed default page is not established by this source/text review. Do not present it as a proven cause. Minimal correction: remove the surplus page without removing the filtered report or changing other printed scopes, then produce a fresh no-applicable PDF with one landscape page and independently reviewed visual content. This review corroborates the page metadata/text condition; Claude owns the visual blankness and CSS diagnosis. Root has explicitly kept this acceptance condition open.

**E1 — evidence/environment limit, not a proved application defect.** Beforeprint=0 occurs in 126/127/130 despite native click commands. Escape 129 does not restore events; document reload 131 followed by 132 produces beforeprint=1. This supports a fresh-document workaround. The driver's assertion that an unclosed native dialog caused the zeros is an inference, not independently observed dialog state. Root's later recipe reload note was written after this run; it cannot be retroactive proof or source at 580c24fa. Later print cases have actual beforeprint=1 evidence. The captured `128` console includes LayerCake zero-width warnings and negative SVG rect-width errors. Do not claim a clean console or that text alone proves these errors harmless; the visual owner assesses rendered impact.

**Coverage wording must stay bounded.** `acceptance-report.md:5` says no blocker/all required prints clean, while its own findings retain P1/K1 and root requires corrections. That sentence cannot be the final acceptance verdict. Its coverage row for ordinary focus must retain the BODY boundary failures; its print PASS must retain the extra page and three rendering-only attempts. The “unchanged page print-media PASS” row is only read-only selector observation `181`: hasReportRoot false, 12 loaded rules, matching []. There was no unchanged-page print-media execution or PDF, so it is not a rendered-output certification. Full visual statements (“no clipping”, bands/colors, row splits, clean wrap) are Claude's assessments and are not adopted by this nonvisual report. V2 is a narrowed follow-up, not another full role/filter/retained-consumer acceptance run.

No additional actionable data, authorization, export-scope or correction-source defect was found within this bounded lane.

## Restoration, closure and final limitations

I compared actual original/restored provider JSON for both orgs and all four recorded tables, including every field, timestamps and IDs. Root originals/restored files are also byte-identical. Driver `210-*` JSON equals those originals despite its wrapper stripping a trailing newline. Org A personnel_trainings returns the exact original one row `e2b8c0cd-f5d6-4f18-94f9-16a05f92bd22`; org B returns zero. The restored training_types, training_views and organizations A/B rows match fully. Actual original/restored trainingConfigure preference JSON also matches; driver `211` agrees. Root audit is consistent with these independently compared payloads.

Final `214` observers are network disarmed/calls empty/held false, export disarmed/uncaptured, print disarmed; feedback was never armed. Final report/matrix and doctor preserve the same candidate/session. Actual root cleanup and seed-cleanup receipts are PASS, artifact HTTP sessions are cleared, and `root-owned-absence.json` records each exact owned process identity absent, no profile processes, the private worker directory absent and retained proof payloads. These are reviewed captured closeout observations, not an independent live process/filesystem check.

The native viewport/light/sidebar state returns to 1905×2053/light/expanded. Browser keys do **not** return byte-for-byte to the original state: `localStorage.theme=light` and `sidebar:state=true` were newly present, while the original mode-watcher system setting remains. The limitation is explicit; the private profile was subsequently destroyed. No exact browser-key restoration claim is warranted.

This report supports the small correction-source acceptance and its observed Retry/structured transport effects, with the limits above. It does not certify P1/K1 repairs, future changed bytes, visual/PDF quality, whole final acceptance, remote PR/CI/review readiness, merge or deployment.

## Selected exact receipt bindings

All following paths are relative to the expanded v2 root; the full inventory binds every remaining payload.

| Receipt | SHA-256 |
|---|---|
| `root-source-checkpoint.json` | `4201eea6e04da539ee5785e9eef1c55d25c8dd8077f64cfd00795bab4ab0b4ec` |
| `gate-binding.json` | `bd9e96edac5a25de91a963daf6b187a10cea3ca83921b4605cbe6206e6b6db06` |
| `accept/expectations.md` | `47202d27a52d50ff18980984da36dd43073ab7229b0a1cd0751d76ff8ce51b16` |
| `accept/receipts/index.jsonl` | `64d8834b4d6d959d939ac405f60e3b2351e821922451c83fae02603e2ae56af8` |
| `accept/receipts/014-list-pages.stdout` and `215-list-pages-final.stdout` | `c4cd7224c50a7d33e1cb3069f175609c3201253b729fe8ef3b2bcedc02e50bb4` |
| `accept/receipts/065-focus-while-loading.stdout` | `a96fded1bbcf043ad30e3a0df8a52b6e07f6e2c78802c016d3611fd50f363d1d` |
| `accept/receipts/068-focus-after-response.stdout` | `6197f07a86933a3e8f5cbfd4e05c62c63cab31bbeb81d1d9b2dd05a953f5ca15` |
| `accept/receipts/091-focus-while-loading-page2.stdout` | `b5914f6f1f56db960c370bbce375fa614d7404febd3a4240dd57bf6ad4c09175` |
| `accept/receipts/094-focus-after-page2.stdout` | `a852f523b2155026810d0af2129691872a6be52ee7e48fc57cc55eaaaab779cb` |
| `accept/receipts/113-focus-after-enter-next.stdout` | `175ce5d9a95ac3fc5548074b7e3423413ee5df8260f9e9c6579e77a597aa5658` |
| `accept/receipts/117-focus-after-enter-previous.stdout` | `7b9b260cf860ffce9b590b4ee070e28ab3ad89ccd173fee7b1d6f229a28e7b25` |
| `accept/receipts/072-d-print-state.stdout` and `132-d-print-state.stdout` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` |
| `accept/receipts/126-d-print-state.stdout`, `127-d-print-state.stdout`, `130-d-print-state.stdout` | `8f4a27098f6103d3864cb3f0bf700c3f3b6cfb632f824c4355e04c2cfcdf25bc` |
| `accept/receipts/168-e-print-save.stdout` | `b7c461251278c7dad412d7ca5abefb807bc796af9897ffa7ad61e8ce284d5e9b` |
| `accept/receipts/178-e-print-save.stdout` | `ef1ddfa948bff5553b6d9d8cc5644d0e54c662e2e8c7f05580b3ea7ac0e663b7` |
| `accept/receipts/214-final-network-state.stdout` | `e6c9ef790c09e5e0d7f6074793229f84f5fb8e4546fdfc2ed3ffd09218ddec96` |
| `accept/receipts/216-doctor-final.stdout` | `bf70496c43def0533247795a3ef544428b82759c9aca1c880ed3c523b2cebe5e` |
| `root-restoration-audit.json` | `f4db1a007c7cc51a4fc6a3a3682b8e4a117f4ea4a4caca0bfd6782b0149b5097` |
| `root-owned-cleanup.json` | `43b8a7db6331e3cd3333eaaf11a20b57f351b4ec57e2a5dba872a5686bfa5b05` |
| `root-clean-seeds.json` | `7d6810e68f7516d53485b4e21dbcab72f20599418fd5ce10bb1dd5ef6c903d0c` |
| `root-owned-absence.json` | `078f3f3eca4f59632de4578ff5f2d8b09dd6a97b4cc4af8b7c1ba54217e10002` |

