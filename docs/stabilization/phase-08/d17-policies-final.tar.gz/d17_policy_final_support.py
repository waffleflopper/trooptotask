import json,subprocess,pathlib,sys
RUN=pathlib.Path('.verification/evidence/verify-trooptotask/d17-policy-final')
CTL=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1']
NATIVE=['npm','run','--silent','verify:app','--']
def execute(label,args):
 path=RUN/(label+'.json');assert not path.exists(),str(path)
 p=subprocess.run(args,capture_output=True,text=True,timeout=65);path.write_text(p.stdout)
 if p.returncode:
  (RUN/(label+'-stderr.txt')).write_text(p.stderr)
  raise RuntimeError(label+' failed; inspect saved output')
 return json.loads(p.stdout)
def control(label,*args):return execute(label,[*CTL,*map(str,args)])
def tool(label,name,body):return execute(label,[*NATIVE,'tool',name,json.dumps(body),'--worker','1'])
def snapshot(label,page):return tool(label,'take_snapshot',{'pageId':page})
def text(obj):return '\n'.join(c.get('text','') for c in obj.get('content',[]) if c.get('type')=='text')
def step(label,page,*args,row=False):
 p=subprocess.run(['python3','.verification/runtime/d17-policy-native-'+('row-step' if row else 'step')+'.py',str(RUN),str(page),label,*map(str,args)],capture_output=True,text=True,timeout=150)
 (RUN/(label+'-command.txt')).write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(label+' failed; inspect saved native snapshots')
 print(label,flush=True)
 return text(json.load(open(RUN/(label+'-after.json'))))
def rows(label,org='orgA'):return control(label,'rows','organizations',org)
def screen(label,page):return tool(label,'take_screenshot',{'pageId':page,'filePath':str(RUN/(label+'.png'))})
