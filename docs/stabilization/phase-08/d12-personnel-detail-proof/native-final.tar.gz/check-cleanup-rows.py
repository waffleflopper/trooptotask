import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--worker', required=True)
args = parser.parse_args()
assert args.worker == '2'
p = Path(__file__).parent
tables = ['personnel', 'personnel_extended_info', 'leader_notes', 'counseling_records', 'personnel_documents', 'personnel_follow_ups', 'personnel_trainings', 'personnel_ict_completions', 'availability_entries', 'rating_scheme_entries']
def rows(label):
    value = json.loads((p / (label + '.stdout')).read_text())
    assert value['count'] == len(value['rows'])
    return sorted(value['rows'], key=lambda row: row['id'])
comparisons = []
for organization in ['orgA', 'orgB']:
    for table in tables:
        original = rows('original-' + organization + '-' + table)
        final = rows('final-' + organization + '-' + table)
        assert original == final, (organization, table)
        comparisons.append({'organization': organization, 'table': table, 'originalCount': len(original), 'finalCount': len(final), 'allFieldsEqual': True})
assert len(rows('final-orgA-personnel')) == 3
assert len(rows('final-orgB-personnel')) == 1
recorded = json.loads((p / 'recorded-seed-inventory.json').read_text())
absence = []
for entry in recorded['seeded']:
    organization = entry.get('organization', 'orgA')
    remaining = {row['id'] for row in rows('final-' + organization + '-' + entry['table'])}
    assert not remaining.intersection(entry['ids']), entry['table']
    assert not entry.get('files'), 'This accepted lifecycle run has metadata-only documents, no seeded Storage objects'
    absence.append({'table': entry['table'], 'recordedIDs': entry['ids'], 'allAbsent': True})
person_ids = {row['id'] for row in rows('final-orgA-personnel')}
sds_ids = {row['id'] for row in rows('final-orgA-personnel_extended_info')}
assert 'c09ed893-c575-40f0-b931-5ad11df5d794' not in person_ids
assert '7b1deddf-a4e6-4cce-b9dd-b379db43a481' not in sds_ids
assert recorded['grantNames'] == []
result = {'status': 'PASS', 'worker': 2, 'revision': 'a200c7b8936b2abcb4105cbebd4ad7789e8e6413', 'comparisons': comparisons, 'recordedSeedAbsence': absence, 'uiCreatedPersonAbsent': True, 'newSDSRowAbsent': True, 'scope': 'Exact original20 full A/B families including every field/timestamp; originalA3/B1. Metadata-only rows do not claim Storage-byte cleanup.'}
(p / 'literal-cleanup-row-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
