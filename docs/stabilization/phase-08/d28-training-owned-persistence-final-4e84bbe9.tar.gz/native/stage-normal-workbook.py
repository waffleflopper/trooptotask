import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
p=2;d.act_prefix('pages-required-detail-open','button','Total, Verification Required Training:',p);d.snap('pages-detail-first',p);d.get_wire('pages-detail-first-wire',p,'training-reports/detail');d.act('pages-detail-next','button','Next',p);d.snap('pages-detail-second',p);d.shot('pages-detail-second',p);d.get_wire('pages-detail-second-wire',p,'training-reports/detail')
d.call('pages-workbook-observe-arm',['network','arm-observe',str(p),'training-reports/export'],True);d.workbook('pages',p,['Summary','Forecast','Hot spots','Focus','Requirements'],'pages-native.xlsx');d.call('pages-workbook-observation',['network','state',str(p)],True);d.call('pages-workbook-observe-restore',['network','restore',str(p)],True)
d.select_listbox('pages-rank-filter','Filter by rank','PFC',p);d.snap('pages-pfc-filtered',p);d.shot('pages-pfc-filtered',p);d.get_wire('pages-pfc-filter-wire',p,'training-reports')
d.call('print-seed',['seed','training-print'],True)
for table in ['personnel','groups','training_types','training_views','personnel_trainings']:d.call('dense-sql-'+table,['rows',table,'orgA'],True)
d.tool('dense-report-reload','navigate_page',{'pageId':p,'type':'reload'});d.snap('dense-report-before-filters',p)
