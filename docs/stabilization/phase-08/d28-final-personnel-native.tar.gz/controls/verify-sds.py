import current as x
import json
d=x.d
row=lambda n:json.loads((d.E/(n+'.json')).read_text())['rows']['orgA']['personnel_extended_info'][0]
saved=row('sds-saved-full');expected={'blood_type':'O+','basd':'2020-01-02','date_of_rank':'2024-03-04','marital_status':'Single','number_of_dependents':2,'children':[{'name':'Alex','age':7},{'name':'Jamie','age':None}],'civilian_education':'Associate','military_education':['BLS','ACLS'],'emergency_contact_name':'Synthetic Contact','emergency_contact_relationship':'Sibling','emergency_contact_phone':'555-0101','spouse_name':'Synthetic Spouse','spouse_phone':'555-0102','vehicle_make_model':'Synthetic Sedan','vehicle_plate':'VFY1376','vehicle_color':'Blue','personal_email':'sheet@example.invalid','personal_phone':'555-0103','address_street':'1 Test Street','address_city':'Test City','address_state':'AK','address_zip':'99501'}
assert {k:saved[k] for k in expected}==expected
assert saved['personnel_id']==json.loads((x.c/'seed.json').read_text())['ids']['person'] and saved['award_tracking_acknowledged_at'] is None
for label in ['award-set-full','sds-phone-cleared-full','award-replayed-full','award-cleared-full']:
 r=row(label);assert r['id']==saved['id'] and r['created_at']==saved['created_at'] and set(r)==set(saved);target={**expected,**({'personal_phone':None} if label!='award-set-full' else {})};assert {k:r[k] for k in expected}==target
assert row('award-set-full')['award_tracking_acknowledged_at'] is not None
assert row('sds-phone-cleared-full')['award_tracking_acknowledged_at']==row('award-set-full')['award_tracking_acknowledged_at']
assert row('award-replayed-full')['award_tracking_acknowledged_at']>row('award-set-full')['award_tracking_acknowledged_at']
assert row('award-cleared-full')['award_tracking_acknowledged_at'] is None
base=json.loads((d.E/'award-cleared-full.json').read_text())['rows']
for actor,code in [('viewer',403),('personnelForeign',404)]:
 r=x.loaded('award-'+actor+'-denial');assert r['status']==code
 actual=json.loads((d.E/('award-'+actor+'-unchanged-full.json')).read_text())['rows']
 for org,ts in base.items():
  for table,rs in ts.items():
   if table!='audit_logs':assert actual[org][table]==rs,(actor,org,table)
seeded=json.loads((d.E/'seeded-full.json').read_text())['rows']
for org,ts in seeded.items():
 for table,rs in ts.items():
  if table not in ['audit_logs','personnel_extended_info']:assert rs==base[org][table],(org,table)
(d.E/'group2-assertions.json').write_text(json.dumps({'status':'PASS','sdsID':saved['id'],'editableLiteralValues':22,'actualSavedKeys':len(saved),'allFieldsKeysRetained':True,'sameCreatedAt':True,'parsedChildrenAndEducation':True,'nativePhoneClearedAndReopened':True,'acknowledgementRetainedDuringNativeSave':True,'ordinaryTrueReplayFalse':True,'viewer':403,'foreign':404,'fullDeniedRowsExact':True,'nativeAward':'UNRUN, no UI control','pngs':['sds-reopened.png','sds-phone-cleared.png'],'limitations':['No new concurrent storage/retention/lifetime campaign','Denials are ordinary authenticated HTTP, not native award controls']},indent=2))
