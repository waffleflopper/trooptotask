# Packaging and redactions

This fifth archive was packaged after the reviewed sanitizer run's final doctor, all 4,528 frozen-input checks, owned seed/cache cleanup and disposal. Packaging adds no fresh application, SQL, browser or service proof and does not relabel the tested candidate.

Every original relative filename and payload byte is preserved exactly, including input bodies, the PDF, source patch, CLI review, mock red/green logs, comparison script/results, the failed metadata-only download500 and the separate real-upload download200. No additional packaging redactions were required.

The original helper had already replaced the real signed URL token query value in `manager-real-document-download.json`; its original `redactedValues: 1` and marker remain unchanged. The two JWT-shaped strings in `tested.patch` are unusable static mock literals in offline credential-pattern tests, not live credentials, and are preserved. Other fake credential/URL literals and red-test outcomes are also unchanged. No actual fixture passwords or unredacted live tokens were found in these payloads. This run contains no PNGs and establishes no new native or ordinary signed-URL byte-fetch proof.

`ARTIFACT_SHA256SUMS` hashes every expanded payload file, including this packaging note, and excludes itself. All four earlier archives and all ignored originals remain unchanged.
