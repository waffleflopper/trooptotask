import { defineConfig } from 'vitest/config';
import { sveltekit } from '@sveltejs/kit/vite';
export default defineConfig({
 plugins: [sveltekit()],
 test: {
  include: ['.verification/evidence/verify-trooptotask/retention-provider-final/provider.test.ts'],
  exclude: [], environment: 'node', fileParallelism: false, testTimeout: 120000, hookTimeout: 120000
 },
 resolve: { conditions: ['browser'] }
});
