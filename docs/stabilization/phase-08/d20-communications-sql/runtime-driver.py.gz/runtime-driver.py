#!/usr/bin/env python3
"""Bounded D20 SQL verification in a new, owned CI-style Supabase project."""
from datetime import datetime, timezone
from functools import partial
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import tempfile
import tomllib

REPOSITORY = Path('/tmp/t2t-d20-communications-sql')
EVIDENCE = REPOSITORY / '.verification/evidence/d20-sql/runtime-delete'
EVIDENCE.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('ci_database', REPOSITORY / 'scripts/ci/database.py')
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)

def utc():
    return datetime.now(timezone.utc).isoformat()

metadata = {'started_at': utc(), 'scope': 'communications plus retained fresh SQL suite',
            'implementation_verification': True, 'independent_acceptance': False,
            'repository': str(REPOSITORY), 'commands': [], 'status': 'running'}

def save():
    (EVIDENCE / 'receipt.json').write_text(json.dumps(metadata, indent=2) + '\n')

def run(command, workdir, *, quiet=False, check=True, environment=None):
    started = utc()
    print('+ ' + ' '.join(command), flush=True)
    result = subprocess.run(command, cwd=workdir, env=environment,
                            stdout=subprocess.PIPE if quiet else None,
                            stderr=subprocess.STDOUT if quiet else None,
                            text=True)
    metadata['commands'].append({'argv': command, 'cwd': str(workdir), 'started_at': started,
                                 'ended_at': utc(), 'exit_code': result.returncode,
                                 'captured_output_suppressed': quiet})
    save()
    print(f'Command exit: {result.returncode}', flush=True)
    if check and result.returncode:
        raise subprocess.CalledProcessError(result.returncode, command)
    return result

def interrupted(signum, _frame):
    raise SystemExit(128 + signum)

for sig in (signal.SIGINT, signal.SIGTERM):
    signal.signal(sig, interrupted)

source = tomllib.loads((REPOSITORY / 'supabase/config.toml').read_text())
held = []
workdir = None
project_id = None
environment = None
started = False
exit_code = 0
try:
    environment = ci.local_docker_environment(REPOSITORY)
    metadata['docker_host'] = environment['DOCKER_HOST']
    before = run(['docker', 'ps', '-a', '--format', '{{.ID}} {{.Names}} {{.Ports}}'], REPOSITORY,
                 quiet=True, environment=environment)
    (EVIDENCE / 'containers-before.txt').write_text(before.stdout)
    metadata['source_commit'] = run(['git', 'rev-parse', 'HEAD'], REPOSITORY, quiet=True,
                                    environment=environment).stdout.strip()
    metadata['sql_sha256'] = hashlib.sha256((REPOSITORY / 'supabase/tests/communications_rls.sql').read_bytes()).hexdigest()
    metadata['sql_plan'] = 53
    for command in (['node', '--version'], ['npm', '--version'], ['supabase', '--version'],
                    ['docker', 'version', '--format', '{{.Client.Version}} / {{.Server.Version}}']):
        version = run(command, REPOSITORY, quiet=True, environment=environment)
        print(version.stdout.strip(), flush=True)
        metadata.setdefault('versions', {})[' '.join(command)] = version.stdout.strip()
    held = ci.reserve_ports(len(list(ci.port_fields(source))))
    ports = [sock.getsockname()[1] for sock in held]
    workdir = Path(tempfile.mkdtemp(prefix='t2t-ci-db-d20-'))
    project_id = workdir.name
    config = ci.prepare_project(REPOSITORY, workdir, project_id, ports)
    (EVIDENCE / 'isolated-config.toml').write_text(ci.config_text(config))
    (EVIDENCE / 'isolated-package.json').write_text((workdir / 'package.json').read_text())
    migrations = sorted((workdir / 'supabase/migrations').glob('*.sql'))
    tests = sorted((workdir / 'supabase/tests').glob('*.sql'))
    metadata.update({'project_id': project_id, 'workdir': str(workdir),
                     'ports': {'.'.join(field): port for field, port in zip(ci.port_fields(config), ports)},
                     'seed': config['db']['seed'], 'migration_count': len(migrations),
                     'migration_first': migrations[0].name, 'migration_last': migrations[-1].name,
                     'retained_sql_suite_count': len(tests), 'suite_names': [path.name for path in tests]})
    save()
    print(json.dumps({key: metadata[key] for key in ('project_id', 'workdir', 'ports', 'seed', 'migration_count', 'migration_first', 'migration_last', 'retained_sql_suite_count')}, indent=2), flush=True)
    for sock in held:
        sock.close()
    started = True
    startup = run(['supabase', 'start', '--exclude', ci.EXCLUDED_SERVICES], workdir,
                  quiet=True, environment=environment)
    # Startup can print synthetic credentials: keep only exact known migration names.
    known = {path.name for path in migrations}
    applied = []
    for line in startup.stdout.splitlines():
        if line.startswith('Applying migration '):
            name = line.removeprefix('Applying migration ').removesuffix('...').strip()
            if name in known:
                applied.append(name)
    (EVIDENCE / 'startup-migrations.txt').write_text('\n'.join(applied) + '\n')
    metadata['startup_reported_migration_count'] = len(applied)
    container = f'supabase_db_{project_id}'
    psql = ['docker', 'exec', '-e', 'PGPASSWORD=postgres', container,
            'psql', '-U', 'supabase_admin', '-d', 'postgres', '-v', 'ON_ERROR_STOP=1']
    version = run([*psql, '-Atc', 'SHOW server_version;'], workdir,
                  quiet=True, environment=environment)
    metadata['versions']['postgres'] = version.stdout.strip()
    print('Postgres: ' + version.stdout.strip(), flush=True)
    # Repository CI workaround for the disposable 17.6.1.106 supautils hint crash.
    run([*psql, '-c', "ALTER SYSTEM SET supautils.hint_roles = '';", '-c', 'SELECT pg_reload_conf();'],
        workdir, environment=environment)
    run(['supabase', 'test', 'db', 'supabase/tests/communications_rls.sql'], workdir,
        environment=environment)
    metadata['focused_status'] = 'passed'
    save()
    run(['npm', 'run', 'db:test'], workdir, environment=environment)
    metadata['retained_status'] = 'passed'
    metadata['status'] = 'passed'
except BaseException as error:
    metadata['status'] = 'failed'
    metadata['failure'] = str(error)
    exit_code = error.code if isinstance(error, SystemExit) and isinstance(error.code, int) else 1
    print(f'Bounded verification failed: {error}', flush=True)
finally:
    for sock in held:
        sock.close()
    previous = {sig: signal.signal(sig, signal.SIG_IGN) for sig in (signal.SIGINT, signal.SIGTERM)}
    cleanup = {'started_at': utc(), 'project_id': project_id}
    try:
        if started:
            result = run(['supabase', 'stop', '--project-id', project_id, '--no-backup'], workdir,
                         check=False, environment=environment)
            cleanup['stop_exit_code'] = result.returncode
            owned = run(['docker', 'ps', '-a', '--filter', 'name=' + project_id,
                         '--format', '{{.ID}} {{.Names}}'], workdir,
                        quiet=True, check=False, environment=environment)
            cleanup['owned_containers_remaining'] = owned.stdout.strip()
            volumes = run(['docker', 'volume', 'ls', '--filter', 'name=' + project_id,
                           '--format', '{{.Name}}'], workdir,
                          quiet=True, check=False, environment=environment)
            cleanup['owned_volumes_remaining'] = volumes.stdout.strip()
            networks = run(['docker', 'network', 'ls', '--filter', 'name=' + project_id,
                            '--format', '{{.Name}}'], workdir,
                           quiet=True, check=False, environment=environment)
            cleanup['owned_networks_remaining'] = networks.stdout.strip()
            cleanup['resource_check_exit_codes'] = [owned.returncode, volumes.returncode, networks.returncode]
            if result.returncode or any(cleanup['resource_check_exit_codes']) or any(
                    cleanup[key] for key in ('owned_containers_remaining', 'owned_volumes_remaining', 'owned_networks_remaining')):
                cleanup['status'] = 'failed'
                exit_code = 1
            else:
                cleanup['status'] = 'passed'
        if workdir is not None and cleanup.get('status') != 'failed':
            shutil.rmtree(workdir)
            cleanup['workdir_removed'] = not workdir.exists()
        if environment is not None:
            after = run(['docker', 'ps', '-a', '--format', '{{.ID}} {{.Names}} {{.Ports}}'], REPOSITORY,
                        quiet=True, check=False, environment=environment)
            (EVIDENCE / 'containers-after.txt').write_text(after.stdout)
        cleanup['ended_at'] = utc()
        metadata['cleanup'] = cleanup
        metadata['ended_at'] = utc()
        save()
        print('Cleanup: ' + json.dumps(cleanup, indent=2), flush=True)
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
raise SystemExit(exit_code)
