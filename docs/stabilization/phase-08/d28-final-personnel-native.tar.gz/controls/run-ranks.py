import sys,pathlib,json,subprocess
c=pathlib.Path(__file__).parent;sys.path.insert(0,str(c));import native_driver as d
run=json.loads((c/'run.json').read_text());tag=run['tag'];page=2
for code in ['SPC','PFC']:
 d.act('rank-'+code.lower()+'-details','button','Show details for '+code,page)
 d.snap('rank-'+code.lower()+'-reference-state',page)
d.shot('rank-references',page)
d.act('rank-add-open','button','Add custom rank',page)
r=d.snap('rank-add-form',page);nodes=list(d.walk(r['structuredContent']['snapshot']))
def uid(role,name):
 x=[n['id'] for n in nodes if n.get('role')==role and n.get('name')==name];assert len(x)==1;return x[0]
d.tool('rank-fill','fill_form',{'pageId':page,'elements':[{'uid':uid('textbox','Code'),'value':tag},{'uid':uid('textbox','Label'),'value':'Synthetic baseline rank'},{'uid':uid('spinbutton','Tie-break order'),'value':'120'}]})
d.act('rank-create','button','Add Rank',page)
d.snap('rank-created',page)
d.get_wire('rank-create-wire',page,'organization-ranks')
subprocess.run(['python3',str(c/'full-rows.py'),'rank-created-full',run['session']],check=True)
d.tool('rank-created-reload','navigate_page',{'pageId':page,'type':'reload'})
d.snap('rank-created-reopened',page)
d.act('rank-edit-menu','button','Actions for '+tag,page)
print(d.txt(d.snap('rank-edit-menu-options',page)))
