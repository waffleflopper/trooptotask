import csv, datetime, hashlib, json, pathlib, subprocess

repo = pathlib.Path.cwd()
out = repo / '.verification/evidence/d17-units-source'
out.mkdir(parents=True, exist_ok=True)
current = '9c5fed846f84696637699fded650d121c3a18768'
base = '1578e4ed07b8bc76358110b8d62aaa909e39adb0'
slices = [('1480','686ca07d84aac29f80542b0a5c112765924d2391'),
          ('1481','28405962cbaafb0ed551bad0f1f2ff773bef4b01'),
          ('1483','8e165314f7ed76940d0e3352d8aa9a3758f7e904'),
          ('1488','7d82b9691a342de887890b8bba3d3a8252115df3'),
          ('1491','b6a1e6bfdd6713c4e55a4e37658f5dc777fe8be7'),
          ('1493','475099bd94fbb161f6911755f76c1cf5a0ebe445'),
          ('1495',base),('final-source',current)]
commands=[]
def git(label,*args,allowed=(0,)):
    argv=['git',*args]; r=subprocess.run(argv,capture_output=True,cwd=repo)
    (out/(label+'.stdout')).write_bytes(r.stdout); (out/(label+'.stderr')).write_bytes(r.stderr)
    commands.append({'label':label,'argv':argv,'exit':r.returncode})
    assert r.returncode in allowed
    return r.stdout.decode()
assert git('head','rev-parse','HEAD').strip()==current
git('status','status','--short')
raw=git('current-tree','ls-tree','-r','--full-tree',current)
tree={}
for line in raw.splitlines():
    metadata,p=line.split('\t',1); mode,kind,oid=metadata.split(); tree[p]=(mode,kind,oid)
union=set(); slice_paths={}
for name,rev in slices:
    paths=git('slice-'+name,'diff','--name-only','--no-renames',rev+'^1',rev).splitlines()
    paths=[p for p in paths if p.startswith(('src/','supabase/','scripts/','.agents/'))]
    slice_paths[name]=paths; union.update(paths)
with (out/'source-state.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['path','state','mode','blob','bytes','sha256'])
    for p in sorted(union):
        if p not in tree: w.writerow([p,'absent','','','','']);continue
        mode,kind,oid=tree[p];data=subprocess.check_output(['git','cat-file','blob',oid])
        w.writerow([p,'present',mode,oid,len(data),hashlib.sha256(data).hexdigest()])
removed=sorted(p for p in union if p.startswith('src/') and p not in tree)
(out/'removed-source.paths').write_text('\n'.join(removed)+'\n')
for name,rev in slices[3:7]:
    rows=[]
    for p in slice_paths[name]:
        old=subprocess.run(['git','rev-parse',rev+':'+p],capture_output=True,text=True)
        now=tree.get(p)
        state='absent' if now is None else 'byte-identical' if old.returncode==0 and old.stdout.strip()==now[2] else 'later-changed-present'
        rows.append({'path':p,'state':state})
    (out/('applicability-'+name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
git('retirement-patch','diff','--no-renames',base,current,'--','src','.agents')
git('last-native-applicability','diff','080b4abc59ee221a9c76f21ada104138fc7f1af0',current,'--','src','supabase','scripts/module-boundaries.json','.agents')
git('schema-since-destruction','diff','7d82b9691a342de887890b8bba3d3a8252115df3',current,'--','supabase')
git('exports-merge-tree','diff','85a5c1e7aeb95fb88489d6c7ab1da3e8c156dea6',base)
argv=['rg','-n','-e','/api/units','-e','personnel\\.manageUnits','-e',"['\"]units['\"]",'src','scripts/module-boundaries.json']
r=subprocess.run(argv,capture_output=True);(out/'units-maintained-source.stdout').write_bytes(r.stdout);(out/'units-maintained-source.stderr').write_bytes(r.stderr)
commands.append({'label':'units-maintained-source','argv':argv,'exit':r.returncode});assert r.returncode in (0,1)
summary={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':current,'base':base,
         'seven_integrated_slices':slices[:-1],'source_support_union':len(union),'source_union':sum(p.startswith('src/') for p in union),
         'removed_source_count':len(removed),'source_scan_exit':r.returncode,
         'scope':'Read-only final source accounting; not database catalog, live execution or independent acceptance.'}
(out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(out/'capture.py').write_bytes(pathlib.Path(__file__).read_bytes())
print(json.dumps(summary,indent=2))
