import importlib.util,json,pathlib,sys,uuid,subprocess
from urllib.request import Request,build_opener,ProxyHandler,HTTPRedirectHandler
sys.dont_write_bytecode=True
R=pathlib.Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
S=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
E=R/'.verification/evidence/verify-trooptotask/d28-onboarding-ordinary-baseline-f064-20261007'
label,session_id=sys.argv[1:]
assert pathlib.Path.cwd()==R and str(uuid.UUID(session_id))==session_id
assert label.replace('-','').replace('_','').isalnum()
output=E/(label+'.json');assert not output.exists()
spec=importlib.util.spec_from_file_location('owned_environment',R/'scripts/verification/environment.py')
env=importlib.util.module_from_spec(spec);spec.loader.exec_module(env)
env.private_session(S)
state,workdir,environment=env.owned(S)
assert state['repository']==str(R)
status=env.status(S)
worker=json.loads((S/'session.json').read_text())
assert worker['id']==session_id and worker['repository']==str(R) and worker['worker']=='1' and worker['phase']=='running'
supervisor=worker['supervisor'];proc=pathlib.Path('/proc')/str(supervisor['pid'])
assert (proc/'stat').read_text().rsplit(')',1)[1].split()[19]==str(supervisor['start']) and (proc/'cmdline').read_bytes().decode()==supervisor['command']
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
req=Request('http://127.0.0.1:'+str(worker['controlPort']),data=b'{"command":"doctor"}',method='POST',headers={'Authorization':'Bearer '+worker['token'],'Content-Type':'application/json'})
with build_opener(ProxyHandler({}),NoRedirect()).open(req,timeout=30) as response:
 doctor=json.loads(response.read(1048576));assert response.status==200 and response.headers.get('X-T2T-Session')==session_id
assert doctor['status']=='PASS' and doctor['session']==session_id and doctor['candidate']==worker['candidate'] and doctor['origin']==worker['origin']
assert worker['origin'].startswith('http://127.0.0.1:') and worker['origin'].rsplit(':',1)[1].isdigit()
records=env.containers(state,workdir,environment)
db=[c for c in records if c['Name']=='/supabase_db_'+state['project'] and c['State']['Running']]
assert len(db)==1 and db[0]['Id'] in state['container_ids']
fixture=json.loads((S/'fixtures.json').read_text())
tables={'organizations':'id','onboarding_templates':'organization_id','onboarding_template_steps':'organization_id','personnel_onboardings':'organization_id','onboarding_step_progress':'organization_id','personnel':'organization_id','groups':'organization_id','organization_rank_catalog':'organization_id','training_types':'organization_id','personnel_trainings':'organization_id','organization_memberships':'organization_id','audit_logs':'org_id','getting_started_progress':'organization_id','user_org_preferences':'organization_id'}
rows={}
for org_key in ['orgA','orgB']:
 org=fixture['ids'][org_key];assert str(uuid.UUID(org))==org
 rows[org_key]={}
 for table,column in tables.items():
  sql="BEGIN READ ONLY; SELECT COALESCE(json_agg(row_to_json(x) ORDER BY x.id),'[]'::json) FROM (SELECT * FROM public."+table+" WHERE "+column+"='"+org+"') x; ROLLBACK;"
  command=['docker','exec','-e','PGPASSWORD=postgres',db[0]['Id'],'psql','-X','-qAt','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1','-c',sql]
  value=env.execute(command,workdir,environment,suppress_diagnostic=True)
  rows[org_key][table]=json.loads(value)
receipt={'session':session_id,'candidate':worker['candidate'],'origin':worker['origin'],'project':state['project'],'containerId':db[0]['Id'],'authority':'Privileged owned synthetic provider READ ONLY; not ordinary authorization proof','rows':rows}
output.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'path':str(output),'session':session_id,'counts':{o:{t:len(v) for t,v in ts.items()} for o,ts in rows.items()}}))
