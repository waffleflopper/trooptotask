# CI repair delta acceptance — GO

No established violation or actionable judgment finding in the seven-path delta. This GO accepts the bounded repair for review handoff; it does not establish repaired current-head CI success or authorize merge before the remaining release gates pass.

The ICT failure is a fixture admission error: its unchanged test permits ordinary rank reads while explicitly rejecting privileged rank reads. Binding the shared finite rank fixture to `store` restores that existing rule. Production ICT composition already captures the ordinary request client. The Training repair provides the existing finite rank fixture, using the same mocked rows and captured Organization; it preserves assertions for no Personnel lane access, catalog entries and deferred hydration. No expectations, guards, scanner coverage or diagnostic checks are weakened.

Actual CI failure output records near-heap allocation failure and exit 134, then the same three failed tests and one unhandled rejection reproduced locally. The focused repair evidence passes both failed suites and four adjacent suites: 68 tests, no unhandled error. Existing governance checks and fourteen CI runner-safety tests pass.

The workflow sets old-space 2560 MiB only for Svelte/TypeScript. All original validation commands, conditions, action pins, worker counts and budgets remain. Both local measured type checks finish with zero diagnostics: 2048 MiB peaks at 2,319,948 KiB RSS; 2560 MiB at 2,792,000 KiB (about 2.66 GiB process RSS). The recorded automatic heap exhaustion identifies the limiter; these single local x64 measurements support the sizing choice but do not measure whole-host use or guarantee fit on the documented 4 GB ARM64 VM. Current-head CI must establish that fit.

Changing this workflow selects the unchanged fresh isolated database job under existing classification rules. No migration, remote operation or weakened isolation is introduced. Production providers, driving controls and native application behavior are untouched; prior 85-path/four-archive acceptance and native e9 proof retain their original bindings. No full manual replay is justified.

Comment Sicko assessment: no new source/workflow comments added; no comment repair finding. Review stayed read-only except this report. No tests, builds, services, apps, databases, Docker, network, connectors or publication were executed. D29/D30 remain excluded; parent stops after #1573 merges. Model/effort inherited; Fast tier unverified.

# Exact inspected delta receipt

Base: `a1f6154710462a631e31f57f27f76223260a45e1`. Complete actual diff and actual changed/untracked membership match the manifest, exactly seven paths. Complete patch SHA-256 `82e880725a55f13fec4734532dd318bcb93bb56fe9e35d37a76618f0f83a7fb0` matches both saved patch and `git diff --binary` at the review endpoint. Every retained file byte length and hash matches.

- `.github/workflows/ci.yml` — 4579 bytes; SHA-256 `969a4db4bd328300131b7cb2cb3af1f3b20b68beb462693e64767992409b59bc`.
- `docs/ci.md` — 19263 bytes; SHA-256 `3467c36ec133139c55abd2d82c485d34ab828bfbc9aed4afcee1172b92beb658`.
- `docs/stabilization/EVIDENCE.md` — 662813 bytes; SHA-256 `0d3f1526a66c44a7ecc920568eedbd4e86efccae25e33345759f21b9fb61015f`.
- `docs/stabilization/TODO.md` — 207333 bytes; SHA-256 `c11368ab164d9fea4dca2da7e9ee410e1a36ff6943169811b34a53fef0f4765d`.
- `docs/stabilization/phase-08/d28-final-personnel-persistence.md` — 19213 bytes; SHA-256 `6cb48e4fac905d818b529493e22c25ab49f75f9b3b96a0c742e5dcde254b8e45`.
- `src/lib/server/adapters/inMemory.ts` — 75880 bytes; SHA-256 `c742fe5a67b5d2260203f79b4eb82f18a57c1c8cedc3892f095e05de80a4e028`.
- `src/routes/org/[orgId]/training/(workspace)/trainingWorkspace.server.test.ts` — 9270 bytes; SHA-256 `ea659f5614a85095f0165f1e12ae72068f970044dc17ea39c286674eb7696d38`.

Read actual full seven-path patch, full workflow and Training workspace test, shared fixture rank construction and surrounding return/factory logic. Large task records were reviewed for their substantive delta and retained-gate context, not claimed as a new whole-document audit.

Relevant unchanged consumers traced: ICT report source loader; the ICT scoped dashboard test's ordinary/privileged store guards and retained result expectations; fixture scope rules and shared rank methods; Training request/briefing composition and Training workspace loader; existing rank loader admission and finite contract. Existing CI path classifier selects database=true for `.github/workflows/ci.yml`; isolated database execution and unconditional exact-project cleanup remain in the workflow. Prior source acceptance is reused for unchanged production implementations.

# Evidence receipt and limits

Read actual preserved evidence in the parent cache, not a claimed new run:

- `ci-37727133511-failed-plain.log` / failed-log source: type-check near automatic heap ceiling (~1.94 GB), FATAL OOM and exit 134; full Vitest totals 722 passing suites / 7,247 passing tests, three failures in two suites and one unhandled rejection. Inspected actual failing call stacks, assertions, ordinary/privileged rejection, Training missing-listEntries failure and terminal status. Unrelated emitted failure-path warnings retain their successful-test context.
- `ci-repair-local-red.log`: same three failures, 14 passing tests and one unhandled rejection.
- `ci-repair-local-green-adjacent.log`: six suites / 68 tests pass. Scope includes ICT reports, Training workspace, rank operations, request contexts, ICT read model and in-memory ICT read model.
- `ci-repair-types-2048.log`: initial `/usr/bin/time` unavailable, exit 127 attempt preserved. `ci-repair-types-2048-measured.log` and its receipt: actual 0/0 diagnostics, exit 0, 25.672 seconds, maximum RSS 2,319,948 KiB. Failed timing setup is not a passing type check.
- `ci-repair-types-2560-measured.log` and its receipt: actual 0/0 diagnostics, exit 0, 21.124 seconds, maximum RSS 2,792,000 KiB. These are separate single runs; elapsed differences establish no speedup or benchmark. RSS is reported process memory, not simultaneous runner/OS total. Local x64 and CI ARM64 are explicitly distinct.
- `ci-repair-governance.log`: retained 139 ownership findings, no regression; same three ordinary-client and five admin-provider exceptions, zero documented feature couplings.
- `ci-repair-runner-safety.log`: fourteen unit tests pass with synthetic disposable-project identities and preserved cleanup behavior. This is a safety-test log, not a new actual database replay by this reviewer.

No waivers, skipped tests, changed assertions, inflated test timeouts or reduced scanned inputs appear in the delta. The heap option raises type-check capacity, not an acceptance threshold. Current-head full application and selected database CI, production build, clean review and merge remain parent release obligations. No fresh native artifact extraction or campaign was run.
