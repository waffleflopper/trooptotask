import { mergeConfig } from "vitest/config";
import original from "../vitest.config";
export default mergeConfig(original, { cacheDir: ".verification/vite-policy-cache" });
