from drive import *

def evaluate(page, function, tag):
    result=native('evaluate_script',{'pageId':page,'function':function,'waitForStableDom':False},tag)
    match=re.search(r'```json\s*([\s\S]*?)```',result)
    assert match, result
    return json.loads(match[1])

def capture_business(page, family, tag):
    assert family in ['onboarding','onboarding-steps']
    listing=native('list_network_requests',{'pageId':page,'resourceTypes':['fetch','xhr'],'includePreservedRequests':True},tag+'-list')
    matches=[]
    for line in listing.splitlines():
        m=re.fullmatch(r'reqid=(\d+) (POST|PUT|DELETE) http://127\.0\.0\.1:\d+/org/[0-9a-f-]{36}/api/'+family+r' \[(\d+)\]',line)
        if m:matches.append(m.groups())
    assert matches,listing
    for reqid,method,status in matches:
        prefix=tag+'-'+reqid
        request=E/(prefix+'-request.network-request');response=E/(prefix+'-response.network-response')
        assert not request.exists() and not response.exists()
        args={'pageId':page,'reqid':int(reqid),'requestFilePath':str(request),'responseFilePath':str(response)}
        # The native result includes private request headers. Keep only the separately saved business bodies.
        r=subprocess.run(['npm','run','--silent','verify:app','--','tool','get_network_request',json.dumps(args),'--worker','1'],text=True,capture_output=True)
        assert r.returncode==0, 'Business capture failed'
        result=json.loads(r.stdout);assert not result.get('isError'), 'Business capture tool failed'
        assert request.is_file() and response.is_file()
        write(E/(prefix+'-metadata.json'),json.dumps({'tool':'get_network_request','pageId':page,'reqid':int(reqid),'method':method,'status':int(status),'family':family,'requestBody':request.name,'responseBody':response.name,'redaction':'Cookie/Set-Cookie/authorization and other headers omitted; original business body files retained'},indent=2))
    return matches
