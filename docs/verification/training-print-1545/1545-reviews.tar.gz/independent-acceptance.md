# Issue 1545 final acceptance: CONDITIONAL PASS, nothing blocks merge

**Mode:** I reviewed the source and the saved evidence only. I did not run the app, a browser or any tests. The CodeRabbit result was not counted as visual proof.

**Exact source:**
- HEAD is `5b8b8f1cf12523031b81f67ff50e1f70b20d1f9e`, base `c2ca46279e45e44072b86bbe1eeadea1a6ab832d`, 24 files.
- The app code, helpers and scripts are identical to `873c9fa141437ef847ce5fd8c10956a243116ff0`, which is the build the final run tested (`10c67824…2724832`).
- The two later commits change only the recipe, `acceptance.md` and the 5 archives.

**Not yet passed:** CI on the final head is still pending. I make no claim that it passed.

## Archives inspected
- I extracted all 5 archives into fresh ignored scratch at `.verification/evidence/rev1545-nLzg/`.
- Every archive hash matches the table and every `SHA256SUMS` checks out. File sets are exact and there are no symlinks.
- The final archive (`ad06f100…cebcef6`) has 137 files and 42,446,313 bytes. It is byte-identical to the frozen round 3 proof root.
- All 11 receipt hashes match their PDFs and XLSX. Paper size and background settings match the PDF metadata.
- I found no tokens, passwords or private PDF. The full-checks env files contain only synthetic values.

## Pages inspected
I rendered these myself rather than relying on the run's PNGs:
- **Every page, on contact sheets:** dense Letter-on and A4-off (5 each), dark role A4-on and Letter-off (12 each), dated84 (11), bls25 (7), short (3), empty view (1) and empty actor (1).
- **Full size:** A4-off pages 1 and 3, Letter-off pages 4 and 12.
- **Text extraction:**
  - row ranges: 1–25, 26–50, 1–100 on all 7 appendix pages, 1–84 on all 6;
  - the "Only rows 26–50" note;
  - column headings and the key on all 4 dense matrix pages.
- **Approved mocks compared:** brief, matrix and the corrected appendix.
- **Also read:** the workbook summary (5 sheets, 1,990 requirement rows), the network logs (no calls), and `check.log` (0 errors, 0 warnings).

## Requirement verdicts
Every requirement passes in both the source and the PDFs:

- **Captured data:** print uses the loaded report and the matching loaded detail. A new scope with nothing loaded prints no appendix.
- **No extra work:** no new queries, recalculations or saved snapshots.
- **Unchanged elsewhere:** the normal screen, Excel (5 sheets) and other pages' printing are unchanged.
- **Worst-first summary:** top 5, using the existing sort.
- **Readability:** 13px core text and 11px drops, with extra sheets instead of shrinking.
- **Numbers:** the configurable goal and readiness as ready ÷ applicable requirements check out (48% today, 24% at horizon; Short 37% and 20%). Per-role totals check out by hand.
- **Order:** selected column order and canonical type order are kept. Row totals count all types. N/A prints as "—" and drops print as ▼n.
- **Appendix:** only loaded rows print, with range, scope and total on every page. Missing rows come first, then by expiry date.
- **Page layout:** continuation pages repeat context, headings and the key. The final type stays on the sheet with the totals. Margins are white, backgrounds-off removes fills without losing meaning, and dark theme prints white.
- **Empty cases:** neither empty case invents a 0%.

**Print lifecycle:** bls25 → bls-page2 printed fresh rows 26–50. That is real live evidence the snapshot was released and recaptured between PDF prints. The `printMounted` check remains invalid and proves nothing.

**Accepted differences from the mock:** the appendix uses the app's own status labels ("Not Done", "Expired 20d ago") and its date format ("Sep 15, 2026"). This keeps print consistent with the screen.

## Findings
1. **Recommended in this PR, no behaviour change: delete leftover print code.** The screen tree is now `print:hidden` and the CSS that read `data-print-section` is gone, so these do nothing:
   - `data-print-section` at `TrainingReportsPage.svelte:417,467,488`, `TrainingFocusSection.svelte:21`, `TrainingTypeRiskSection.svelte:23` and `TrainingAffectedSoldiersSection.svelte:119`;
   - about 15 `print:` classes inside that tree (`TrainingReportsPage.svelte:273,301,409,491,518–593`, `TrainingAffectedSoldiersSection.svelte:122,145`, `TrainingFocusSection.svelte:46`);
   - the redundant hide rule at `app.css:454`.

   Removing them changes nothing on screen or on paper, so CI alone is enough to verify it.
2. **Accepted limit, but `acceptance.md` should give the numbers.** Measured on the dense A4 page, the repeated table heading is about 104pt. Chromium stops repeating a heading above about 132pt (a quarter of the page), which leaves roughly 2–3 wrapped label lines to spare. Valid data can exceed that:
   - group names are allowed up to 100 characters (`groupEntity.server.ts:15`);
   - duty role (`clinicRole`) names have no length limit (`personnelEntity.server.ts:24`).

   If it happens, some continuation pages lose their headings but all data still prints. Please replace the word "pathological" with these figures.

## Coverage
- **Good enough:** the cycle tests, layout tests and the page's no-refetch test. Under the repository's testing rules, the PDFs are the right evidence for how the print pages look.
- **Minor gap:** no test checks that the page adds the print markup on `beforeprint` and removes it on `afterprint`. The live PDF evidence above covers this. Adding it to the existing page test would be cheap.

## Limits still open
- `Ctrl+P` and OS print cancellation could not be tested headless. Physical printing and a fresh grayscale check were not tested.
- Sign-out timing and switching scope while a detail request is held were not run. I accept them based on unchanged code plus round 1's A/B evidence.
- Goal 80→90 and the timing checks reuse earlier rounds' evidence, which is valid because those paths are unchanged.
- The 425 focused Training tests were reported by Claude with no log kept. The full checks (7,149 tests) ran on `91c79c6f`, which is before the last four visual fixes. Final-head CI is the gate that covers this.
