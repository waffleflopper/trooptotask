#!/usr/bin/env bash
# usage: uid.sh SNAPNAME 'grep pattern' -> first uid
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
grep -E "$2" $E/snaps/$1.txt | head -1 | grep -o 'uid=[0-9_]*' | cut -d= -f2
