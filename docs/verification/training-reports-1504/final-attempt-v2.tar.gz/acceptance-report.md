# #1504 final acceptance v2 (owned browser, PR1511), narrowed follow-up

## Verdict

**No #1504 blocker was observed in this narrowed lane.** The repaired print transport produced ten PDFs. Every page was rendered and inspected. All required print states print cleanly and the ~1920 collapsed-sidebar forecast does not clip. The keyboard Retry correction holds with real Enter: focus stays on the Affected soldiers region while loading and after the response.

Two minor findings and one environment limit need root disposition (see Findings). This lane certifies only its own live observations. Source/model review, cumulative acceptance and the v1 artifact audit belong to other lanes.

## Run identity

- HEAD `580c24fa10d517065894ca4bc1e6856746890f7c`, base `a59c6c92`, worker 1, candidate `933df986…0e7104`.
- Origin `http://127.0.0.1:42797`, session `e0b0c74a-31e4-4474-81f0-30a8509a67a1`, Chromium 152.0.7977.82 Arch Linux.
- Doctor PASS at start (`000-doctor`) and end (`216-doctor-final`), with the same candidate, revision and session.
- Actor `trainingConfigure` signed in through the normal form (`003`). Org A `f1b5242a…`, Alpha `429aed2d…`, Bravo `64b399dc…`. Fixture day 2026-10-04.
- Starting state: 1905×2053, `data-theme=light`, `mode-watcher-mode=system`, no `theme` key, no sidebar cookie (`004`).

Evidence lives under `.verification/evidence/verify-trooptotask/1504-final-v2/accept/`:

- `expectations.md` was written before any action.
- `receipts/index.jsonl` holds 316 receipts. Each records argv, exit code, timestamp and seconds, with `NAME.stdout`/`NAME.stderr` files. All names are unique: the scripts refuse to reuse a receipt, snapshot, screenshot or PDF name.
- Only one receipt is nonzero: `016`, a stale sidebar UID (exit 2), repaired once in `018`.
- Other folders: `snaps/`, `shots/`, `pdf/`, `pdfpages/` (every PDF page as PNG), plus the workbook and its decode.

## Coverage

| # | Path | Result |
|---|---|---|
| 1 | Original report via visible Reports link | PASS |
| 1 | Native cell and focus-link drill-down, focus to region, lower-section screenshot | PASS |
| 1 | Native tools work, and `list_pages` returns `structuredContent.pages` | PASS (`002`, `014`, `215`) |
| 2 | Dated two-row CSV: preview writes nothing, import, exact IDs, readback and reload | PASS |
| 2 | Dated briefing and details | PASS |
| 2 | Native 5-sheet workbook smoke, 3 affected rows | PASS |
| 3 | Keyboard Retry on initial cell detail 503: real Tab, Enter, held load | PASS |
| 3 | Seeded real page-2 failure, keyboard Shift+Tab/Enter Retry, page identities | PASS |
| 3 | Ordinary page-size, Next and filter changes do not move focus to the region | PASS, with finding K1 |
| 3 | PDF of the loaded 25-row page | PASS |
| 4/5 | Print light, dark, Alpha with detail, failed refresh, no-applicable, 1920 collapsed | PASS, with findings P1 and E1 |
| 5 | 1440/1024/390 keyboard Retry→region screenshots | PASS |
| 6 | Unchanged page print-media effect, read-only | PASS |
| 6 | Many-column print | UNAVAILABLE by design (bound to the 2 fixture types) |
| 7 | Restoration and final doctor | PASS, with key limitations |

## 1. Original report

- **Bottom line:** 3 soldiers, 25% stays 25%, Ready 1 / expired 0 / not recorded 3 / lapse 0 (`s007`). This matches the independent count of 4 applicable pairs.
- **Type risk:** Required 2/0 above Targeted 1/0.
- **Total Required cell (`008`):** Baker and Unassigned, both Not Done, "Rows 1–2 of 2". The page URL stays bare. The request was `detail?scope=cell&type=b0c5ee05…` (`015`).
- **Focus link "View 2 soldiers" (`011`):** `scope=focus&focus=gap%3Ab0c5…` returns the same 2 rows for 2 distinct soldiers. `activeElement` is `SECTION#training-affected-soldiers` after both actions (`010`, `013`).
- **Screenshot:** `shots/p1-original-focus-detail-full.png`, full page including the lower sections.

## 2. Dated import

- **CSV:** `p2-import.csv` uses literal fixture dates: Baker Required 2024-10-04 and Able Targeted 2025-10-19.
- **Preview (`024`):** 2 valid rows, 2 selected. Provider count stayed 1 (`026`).
- **Import (`028`):** batch POST 200 (`029`); the result reads Inserted 2, Updated 0, Exempted 0, Errors 0.
- **New IDs:**
  - Baker Required `11c2b595-74d2-48a2-bd89-08d07058c758`: 2024-10-04 → 2025-10-04.
  - Able Targeted `cffa85d5-2d1d-4eaa-b40a-c1e2868b494c`: 2025-10-19 → 2026-10-19.
- **Matrix after reload (`035`):** "15d left" and "Expired 365d ago".

Dated report (`s037`):

- **Bottom line:** 50% falls to 25%, "loses 25 points in 90 days". Ready 2, expired 1, not recorded 1, lapse 1.
- **Type risk:** Required 2/0 above Targeted 0/1.
- **Focus:** the Required gap (25% → 75%) and "Alpha — Verification Targeted Training" (Alpha 50% → 100%).
- **Total Required detail:** Unassigned Not Done first, then Baker "Expired 365d ago", Oct 4, 2025.
- **Alpha×Targeted detail:** Able "15d left", Oct 19, 2026, Yes.

Workbook (`044`–`049`):

- `dated-unfiltered.xlsx`, `training-report-2026-10-04.xlsx`, xlsx MIME, 11859 bytes, sha256 `4b76f969e35b276ab8b90451417ac63cb9cbaab92312ebaa2a2ba5cfe3786860`. Export GET returned 200.
- It was exported with the Alpha×Targeted detail open.
- Sheets are exactly Summary, Forecast, Hot spots, Focus, Requirements.
- Requirements holds exactly 3 rows: Unassigned Required Not Done; Baker Required Expired 2025-10-04; Able Targeted 15d left 2026-10-19 / 2026-10-20 Yes.
- Summary reads 50/25/goal 90/drop 25, counts 2/4/1/1/1, and all 8 filter labels.

This is a proportional transport/regression smoke. Full filter, access and export coverage stays bound to final-v1 on unchanged code. I am not claiming a rerun of v1's 565 actions.

## 3. Keyboard focus regression

All `activeElement` reads below come from read-only evaluation (`focus.sh`).

**A. Initial cell detail 503**, with the seeded 29-person data. Seed `training-pages` tag `f92c4a50`, first ID `78956818…`. The report shows 29 soldiers, 6% → 3%, Ready 2 / expired 1 / not recorded 28 / lapse 1, which matches expectations (`s052`).

- Arm-fail, then click Total Required. The region shows the alert "Unable to load affected soldiers … (503)" with Retry, no rows and no range (`055`).
- Restore and arm a hold. Native Tab lands on the "25 rows per page" radio, then Tab again lands on **Retry** (`060`, `062`).
- BEFORE Enter (`063`): focus is on Retry.
- Native Enter (`064`), WHILE held (`065`): focus is on `SECTION#training-affected-soldiers`, `aria-busy=true`, status "Loading affected soldiers".
- AFTER release (`068`): focus is still on the SECTION. Range "Rows 1–25 of 28", 25 rows. **Not BODY.**

**B. Real page-2 failure.**

- Arm-fail, then click Next. The alert reads "…(503). Showing the page that loaded before." The range stays "Rows 1–25 of 28" with 25 rows, and focus stays on Next (`082`).
- Restore and hold. Native Shift+Tab reaches Retry (`088`).
- Enter (`090`), WHILE held (`091`): focus is on the SECTION, busy, "Loading page 2", and the old range is still shown.
- AFTER (`094`): focus is on the SECTION, "Rows 26–28 of 28".
- Page 1 (`070`) holds temps #00–#24. Page 2 (`095`) holds temp #25, Unassigned, then Baker (expired). That is 28 unique requirements with no omission or duplicate.

**Ordinary controls:**

- After choosing 100, focus stays on the "100" radio and the range reads 1–28 (`075`). After choosing 25, focus stays on the "25" radio (`078`).
- After a horizon change to 180, focus stays on the "180 days" radio, the detail closes and the URL becomes `?horizon=180` (`102`).
- None of these move focus to the region.

**Width screenshots (`kbw.sh`, `184`–`186`).** At 1440, 1024 and 390, the sequence fail → Tab Tab → Retry → Enter ends with focus on the SECTION and rows loaded. Screenshots are `shots/k-{1440,1024,390}-retry-focused.png` and `k-*-region-focused-after-retry.png`; `k2-page2-retry-focused-1905.png` shows the Retry focus ring. The region takes programmatic focus without a visible ring, which is normal for `tabindex=-1`.

## 4–5. Print: helper sequence and every PDF page

Every case followed this sequence:

1. `print arm 2`.
2. Native click on **Print brief** (snapshot UID).
3. `print state 2` saved BEFORE the save.
4. `print save 2 EXACT_URL_from_list_pages NEW.pdf`.
5. `print restore 2`.

Receipts follow `NNN-a` through `NNN-f`. All PDFs are US Letter landscape at 792×612, except P1 below. They were rendered with `pdftoppm` and inspected page by page, plus `pdftotext`. These PDFs prove Chromium print rendering only, not the system dialog or a physical printer.

| PDF | Native state before save | Bytes / sha256 prefix | Pages | Visual verdict |
|---|---|---|---|---|
| `seeded-page1-25rows-light.pdf` (`072`) | before 1 | 262708 / `cd315933` | 5 | PASS. See note 1. |
| `dated-unfiltered-light.pdf` (`121`) | before 1 | 173059 / `60c865d4` | 3 | PASS. See note 2. |
| `dated-unfiltered-dark-r4.pdf` (`132`), app `data-theme=dark` (`133`) | before 1 | 173051 / `66c61d88` | 3 | PASS. See note 3. |
| `dated-unfiltered-dark.pdf`, `-r2`, `-r3` (`126`, `127`, `130`) | **before 0** | 173051 each | 3 | Pixel-identical to r4. Invocation not proven for these three; see E1. |
| `alpha-detail-dark.pdf` (`145`), URL `?group=429aed2d…` | before 1 | 177624 / `df6de7fd` | 3 | PASS. See note 4. |
| `failed-refresh-dark.pdf` (`155`) | before 1 | 171284 / `72ca5293` | 3 | PASS. See note 5. |
| `no-applicable-dark.pdf` (`168`), URL `?group=<Bravo>&types=<Targeted>` | before 1 | 70508 / `43f9497d` | 2 | Page 1 PASS. **Page 2 is blank and portrait (612×792); see P1.** See note 6. |
| `forecast-1920-collapsed-light.pdf` (`178`), 1920×1080, sidebar collapsed, screen SVG 1436 px (`177`) | before 1 | 173298 / `164eab65` | 3 | **PASS, no clipping.** See note 7. |

Notes:

1. **Seeded 25-row page.**
   - Page 1: title, subtitle, filter line and Bottom line.
   - Page 2: Forecast and Hot spots. The selected cell outline is shown, and there is no Rows by control.
   - Page 3: Type risk, Focus (no View links), then the Affected soldiers heading, status and "ROWS 1–25 OF 28". The table header starts on page 4, so the heading sits apart from its table.
   - Pages 4–5: all 25 rows, with the header repeated on page 5. No row is split.
   - There are no page-size radios, paging buttons or links. The section did not fit on one page, so a break is acceptable.
2. **Unfiltered light.** Same structure: header and Bottom line; Forecast and Hot spots; Type risk and Focus. Semantic bands and red/orange counts are present.
3. **Unfiltered dark.** The print rules force light paper, so it is readable with bands intact. One difference from light: the Type risk counts print black instead of red/orange. The bars and legend keep their colors.
4. **Alpha with detail.**
   - The filter line reads "GROUP: ALPHA".
   - The Bottom line reads 100% → 50%, and the forecast is titled "Alpha readiness".
   - Page 3 ends with Affected soldiers: Able, 15D LEFT, Oct 19, 2026, Yes, "ROWS 1–1 OF 1".
5. **Failed refresh.**
   - The alert "Unable to update the briefing … (503). Showing the last briefing that loaded." is printed under the filter line, and Retry is absent.
   - The numbers and filter line are the shown Alpha briefing, not the attempted Bravo.
   - On screen, the alert and Retry were present, and the URL and numbers stayed Alpha (`s153`, `154`).
6. **No-applicable.** Page 1 has the title, a filter line that wraps cleanly ("GROUP: BRAVO … TYPES: VERIFICATION TARGETED TRAINING"), and the honest empty state "No applicable requirements for these filters. No soldier in this selection is required to hold the selected training." Clear filters is absent.
7. **1920 collapsed forecast.** The page-1 render at 150 dpi shows the Goal 90% label, the 50% start and 25% end annotations, and the Today·4 Oct / 1 Nov / 1 Dec / 2 Jan ticks all inside the page. Chromium scales the whole document down to fit: text boxes are about 0.84× the 1905 run's. It stays readable, and Bottom line and Forecast now share page 1. The Hot spots and Type risk page (150 dpi) and the Focus page are intact.

## 6. Unchanged page print media

On the Training matrix (`181`), read-only:

- 12 loaded print-media rules match 0 elements.
- There is no `[data-print-report]`, so `html:root:has(…)` and `@page training-brief` do not apply.
- No PDF of that page was attempted, as required.

Many-column print is bound to the fixture's two applicable types. No temporary catalog types were created, because no current failure called for them. Wide forecast width was tested directly through the 1920 case instead.

## Findings

- **P1 (minor, print).** The filtered no-applicable PDF has a trailing blank page that is portrait (612×792) while page 1 is landscape. No other PDF has this.
  - Likely cause, not verified: in-flow content outside `[data-print-report='training']` lands on a default unnamed `@page`, because `page: training-brief` applies only to the report root (`src/app.css:350,404`).
  - Falsification: a correction yields a 1-page `no-applicable` PDF.
  - Content is complete, so I judge it a cosmetic paper defect, not a #1504 acceptance blocker. Root to dispose.
- **K1 (minor, keyboard, pagination unchanged by this correction).** Keyboard Enter on Next to the last page (`112`→`113`) or on Previous to page 1 (`116`→`117`, pointer case `099`) leaves `activeElement` = BODY, because the activated button becomes disabled.
  - Chromium keeps the sequential-focus start point, so Shift+Tab returns to Previous (`115`). For screen-reader users, focus is still lost.
  - This is the same class of defect as v1's V3, but on the pagination buttons. It is not the corrected Retry path.
  - Falsification: after boundary paging, focus lands on the remaining enabled pager button or on the region.
- **E1 (environment, not product).** After a successful native Print brief click, the unclosed native print dialog made later `window.print()` calls on the same document fire no events. This produced `before:0` in `126`, `127` and `130`; Escape (`129`) did not clear it.
  - The handler is a plain `onclick={() => window.print()}` with no app-level guard.
  - A reload restored invocation (`131`→`132`, before 1). Every later case reloaded first, and every accepted PDF has before 1.
  - The verify recipe could note "reload between print invocations".
- **Observed only:** after `print save`, the console shows LayerCake zero-width warnings and negative `<rect>` width errors (`128`). The PDFs render correctly, so I made no claim beyond this observation.
- **Unchanged from v1:** V1 (1024 grid overflow) and V2 (monochrome chips) keep root's no-change disposition. I did not repeat the full-width suite.

## Restoration

- **Imported completions:** removed through the visible matrix editor (Delete → "Delete Training Record" → Delete). Both DELETEs returned 200 (`206`). After reload the matrix shows the original cells (`s209`).
- **Seed:** `clean-seeds` (`118`) removed tag `f92c4a50`, and the reload showed 3 soldiers (`120`).
- **Provider readback (`210-*`, `211`):** parsed JSON equals root's untouched originals (`final-restoration-compare.txt`) for:
  - `personnel_trainings` A (1 row, `e2b8c0cd…`) and B (0 rows);
  - `training_types` A and B;
  - `training_views` A and B;
  - `organizations` A and B;
  - `trainingConfigure` preferences.

  Byte differences are only the trailing newline my receipt wrapper strips.
- **Final report:** 25% stays 25%, 1/0/3/0 (`s213`).
- **Observers:** network, export and print were restored after each use, and their final states on page 2 read disarmed and uncaptured (`214-*`). Feedback was never armed. Page 2 is the only app page used; page 1 is about:blank.
- **Viewport, theme and sidebar:** restored through native resize and visible controls (`187`, `189`, `173`) to 1905×2053, light, sidebar expanded (`190`).
- **Key limitations:** `localStorage.theme="light"` and cookie `sidebar:state=true` now exist where none did before. The visual state matches the original. I did no storage clearing.

The final doctor passed on the same candidate. The worker is handed back to root, with no cleanup run by me. No file was found matching a token pattern, and I captured no full-HTML document responses.
