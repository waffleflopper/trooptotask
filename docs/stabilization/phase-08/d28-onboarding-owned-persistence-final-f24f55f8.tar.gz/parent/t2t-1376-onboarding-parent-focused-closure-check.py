from pathlib import Path
import json, subprocess, hashlib, datetime
repo=Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
raw=repo/'.verification/evidence/verify-trooptotask/d28-onboarding-twoport-focused-f24f55f8-20261007'
cache=Path('/home/waffleflops/.cache/t2t-1376-onboarding-focused-native-f24f55f8-20261007')
def read(p):return json.loads(p.read_text())
def command(*args):return subprocess.check_output(args,text=True)
res=read(raw/'precleanup-owned-resources-final.json'); doctor=read(raw/'doctor-owned-provider-identities.json')
pre=read(cache/'preexisting-container-inspect.json')
current=json.loads(command('docker','inspect',*[x['Id'] for x in pre])); byid={x['Id']:x for x in current}
def stable(x):
 return {'Id':x['Id'],'Name':x['Name'],'Config':x['Config'],'HostConfig':x['HostConfig'],'Mounts':sorted(x['Mounts'],key=lambda y:y['Destination']),'Pid':x['State']['Pid'],'StartedAt':x['State']['StartedAt'],'Networks':x['NetworkSettings']['Networks']}
changed=[x['Id'] for x in pre if stable(x)!=stable(byid[x['Id']])]
allids=set(command('docker','ps','-aq','--no-trunc').split());remainingContainers=[x for x in doctor['containerIds'] if x in allids]
remainingPids=[]
for x in res['ownedGroupMembers']:
 if Path('/proc',str(x['pid'])).exists():remainingPids.append(x['pid'])
groups={x['group'] for x in res['ownedGroupMembers']};remainingGroups=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  tail=(p/'stat').read_text().rsplit(')',1)[1].split(); pg=int(tail[2])
  if pg in groups:remainingGroups.append({'pid':int(p.name),'group':pg,'state':tail[0],'start':tail[19]})
 except (FileNotFoundError,ProcessLookupError,PermissionError):pass
listeners=command('ss','-H','-ltn'); livePorts={int(line.split()[3].rsplit(':',1)[1]) for line in listeners.splitlines()};remainingPorts=sorted(set(res['ports'])&livePorts)
networkIds=set(command('docker','network','ls','--no-trunc','-q').split()); networkNames=set(command('docker','network','ls','--format','{{.Name}}').split());volumes=set(command('docker','volume','ls','-q').split());remainingNetworks=[x for x in doctor['networks'] if x['Id'] in networkIds or x['Name'] in networkNames];remainingVolumes=sorted(set(doctor['volumes'])&volumes)
inv=read(Path('/home/waffleflops/.cache/t2t-1376-onboarding-implementation-f064-20261007/source-inventory-final.json')); sourceErrors=[]
for x in inv['files']:
 p=repo/x['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=x['sha256'] or p.stat().st_size!=x['bytes']:sourceErrors.append(x['path'])
sourceErrors += [x for x in inv['deleted'] if (repo/x).exists()]
census=read(Path('/home/waffleflops/.cache/t2t-1376-onboarding-implementation-f064-20261007/source-census-final.json'))
controls=census['controlsSha256'];controlErrors=[]
for k,v in controls.items():
 p=Path(k)
 if not p.is_absolute():p=Path('/home/waffleflops/.cache/t2t-1376-onboarding-ordinary-baseline-f064-20261007')/k
 if hashlib.sha256(p.read_bytes()).hexdigest()!=v:controlErrors.append(k)
for n,h in [('destination-runner.py','6ebf71055c7be972e4e43d86a41d65954c0a7e541e8192e0714dbeb76b08fadb'),('destination-bindings.json','42d7022e11202dc66b2b700847eeb5871fe0595899046428bd7e891b42b2ad7c')]:
 if hashlib.sha256((cache/n).read_bytes()).hexdigest()!=h:controlErrors.append(n)
worker=Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
errors={'changedPreexisting':changed,'remainingOwnedContainers':remainingContainers,'presentOwnedPIDNumbers':remainingPids,'remainingOwnedGroups':remainingGroups,'remainingPorts':remainingPorts,'remainingExactNetworkIDsOrNames':remainingNetworks,'remainingOwnedVolumes':remainingVolumes,'sourceChanges':sourceErrors,'controlChanges':controlErrors,'workerDirectoryPresent':worker.exists()}
ok=not any(errors.values());out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if ok else 'FAIL','candidate':census['candidate'],'physicallyAbsentOwnedPIDs':len(res['ownedGroupMembers']),'ownedPorts':len(res['ports']),'doctorOwnedContainers':len(doctor['containerIds']),'ownedFullNetworkIDs':len(doctor['networks']),'ownedMountedVolumes':len(doctor['volumes']),'preexistingFullConfigHostConfigSortedMountsPIDStartedNetworksExact':len(pre)-len(changed),'sourceFileBytesExact':len(inv['files'])-len(sourceErrors),'deletedAbsent':len(inv['deleted']),'frozenControlsExact':len(controls)+2-len(controlErrors),'errors':errors,'limit':'Actual current own-resource/source checks. Whole-machine differences and full restoration accepted separately; private Config.Env compared without output.'}
p=Path('/home/waffleflops/.cache/t2t-1376-onboarding-parent-focused-actual-closure-source.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out));raise SystemExit(0 if ok else 1)
