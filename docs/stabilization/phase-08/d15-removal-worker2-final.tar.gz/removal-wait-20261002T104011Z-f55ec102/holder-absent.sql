SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('absent',NOT EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=1976 AND backend_start='2026-10-02 10:40:12.732725+00'::timestamptz AND application_name='t2t-d15-removal-ce4250b875b5415a8da494539ed66275' AND usename='supabase_admin' AND datname='postgres'));
