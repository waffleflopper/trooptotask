#!/usr/bin/env bash
# usage: d.sh LABEL -- command args...   (one receipt per invocation)
set -u
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7
cd "$ROOT"
export PATH=/home/waffleflops/.local/share/mise/installs/node/24/bin:$PATH TMPDIR=${TMPDIR:-/tmp} NODE_DISABLE_COMPILE_CACHE=1
label=$1; shift; [ "${1:-}" = "--" ] && shift
n=$(ls "$E/receipts"/*.json 2>/dev/null | wc -l); id=$(printf '%04d' $((n+1)))-$label
start=$(date -Is)
"$@" >"$E/receipts/$id.stdout" 2>"$E/receipts/$id.stderr"; code=$?
# sanitize any token-ish material defensively
sed -i -E 's/(sb-[A-Za-z0-9_-]*-auth-token[^=]*=)[^;" ]*/\1[REDACTED]/g; s/("(password|access_token|refresh_token|cookie|authorization)"\s*:\s*)"[^"]*"/\1"[REDACTED]"/Ig' "$E/receipts/$id.stdout" "$E/receipts/$id.stderr"
jq -n --arg id "$id" --arg start "$start" --arg end "$(date -Is)" --argjson code $code --args '{id:$id,start:$start,end:$end,exit:$code,argv:$ARGS.positional}' -- "$@" > "$E/receipts/$id.json"
echo "[$id exit=$code]"; cat "$E/receipts/$id.stdout"; [ -s "$E/receipts/$id.stderr" ] && { echo "--stderr--"; cat "$E/receipts/$id.stderr"; }
exit $code
