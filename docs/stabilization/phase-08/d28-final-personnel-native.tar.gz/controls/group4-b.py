import current as x,json
x.d.act('group4-switch-b','menuitem','VO Verification Organization B member',page=4)
r=x.d.snap('group4-roster-b',4)
x.d.shot('group4-roster-b',4)
print('B rows',x.names(r,'row'),flush=True)
print('B add', [a for a in x.names(r,'button') if 'Add' in a],flush=True)
a=x.d.call('group4-b-owner-actor',['actor','orgSettingsPeer','settings/general'],True)
(x.c/'b-owner-actor.json').write_text(json.dumps(a))
print('actor',a,flush=True)
