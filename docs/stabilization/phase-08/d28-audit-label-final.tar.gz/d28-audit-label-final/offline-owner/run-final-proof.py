from pathlib import Path
import hashlib, json, os, re, subprocess
folder=Path('.verification/evidence/audit-label-owner/final')
env=os.environ.copy()
env['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+env['PATH']
folder.mkdir(exist_ok=True)
paths=json.loads((folder.parent/'paths.json').read_text())
sources=[p for p in paths if p.endswith('.server.ts') and p.split('/')[-1] in ['personnelNames.server.ts','trainingTypeNames.server.ts','statusTypeNames.server.ts','memberEmails.server.ts']]
tests=[p for p in paths if p.endswith('.test.ts')]
proof={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'versions':{},'runs':[]}
for name,command in [('node',['node','--version']),('npm',['npm','--version'])]: proof['versions'][name]=subprocess.check_output(command,env=env,text=True).strip()
def hashes():
 return {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}
def run(name,command):
 before=hashes()
 result=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=folder/(name+'.log')
 log.write_text(json.dumps({'command':command,'versions':proof['versions'],'hashes':before},indent=2)+'\n\n'+result.stdout+'\nexit_code='+str(result.returncode)+'\n')
 proof['runs'].append({'name':name,'command':command,'exitCode':result.returncode,'log':str(log),'hashes':before})
 (folder/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 return result.returncode
originals={p:Path(p).read_bytes() for p in sources}
try:
 for source in sources:
  text=originals[source].decode()
  changed=re.sub(r"\.select\('[^']+'\)",".select('*')",text)
  Path(source).write_text(changed)
  code=run(Path(source).name.removesuffix('.server.ts')+'-projection-red',['npm','run','test','--',source.replace('.server.ts','.server.test.ts')])
  Path(source).write_bytes(originals[source])
  if code==0: raise RuntimeError('Projection fault unexpectedly passed')
finally:
 for source,content in originals.items(): Path(source).write_bytes(content)
if run('restored-focused',['npm','run','test','--',*tests])!=0: raise RuntimeError('Restored focused tests failed')
if run('scoped-lint',['npx','eslint',*paths])!=0: raise RuntimeError('Scoped lint failed')
if run('scoped-format',['npx','prettier','--check',*paths])!=0: raise RuntimeError('Scoped format failed')
env['PUBLIC_SUPABASE_URL']='http://verification.invalid'
env['PUBLIC_SUPABASE_ANON_KEY']='synthetic-verification-key'
proof['checkEnvironment']={'PUBLIC_SUPABASE_URL':env['PUBLIC_SUPABASE_URL'],'PUBLIC_SUPABASE_ANON_KEY':env['PUBLIC_SUPABASE_ANON_KEY']}
run('isolated-check-synthetic-env',['npm','run','check'])
proof['restoredHashes']=hashes()
proof['sourceRestorationVerified']=all(Path(p).read_bytes()==content for p,content in originals.items())
(folder/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'runs':len(proof['runs']),'restored':proof['sourceRestorationVerified'],'checks':[{r['name']:r['exitCode']} for r in proof['runs'][-4:]]}))
