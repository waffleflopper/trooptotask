import subprocess, pathlib, json, time, os, re, sys
root=pathlib.Path('/home/waffleflops/.cache/t2t-1360-personnel-sds-awards')
base=root/'.verification/evidence/verify-trooptotask/personnel-sds-awards-recovery'
os.environ['TMPDIR']='/home/waffleflops/.cache/vw1r'
def call(label,kind,*args):
 c=(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args] if kind=='control' else ['npm','run','--silent','verify:app','--',*args,'--worker','1'])
 
 if (base/(label+'.json')).exists(): raise RuntimeError('Evidence label already exists: '+label)
 start=time.time();p=subprocess.run(c,cwd=root,capture_output=True,text=True)
 (base/(label+'.json')).write_text(p.stdout);(base/(label+'.stderr')).write_text(p.stderr)
 (base/(label+'-command.json')).write_text(json.dumps({'command':c,'cwd':str(root),'exit':p.returncode,'durationSeconds':round(time.time()-start,3)},indent=2)+'\n')
 if p.returncode: raise RuntimeError(label+' exit '+str(p.returncode)+' '+p.stderr[:1000])
 data=json.loads(p.stdout)
 if data.get('isError'):raise RuntimeError(label+' '+str(data))
 print(label+': '+json.dumps(data)[:1200],flush=True)
 return data

def tool(label,name,args): return call(label,'app','tool',name,json.dumps(args,separators=(',',':')))
def snapshot(label,page):
 data=tool(label,'take_snapshot',{'pageId':page})
 return '\n'.join(item.get('text','') for item in data.get('content',[]))
def click(label,page,button):
 snap=snapshot(label+'-before',page)
 pattern=r'uid=([^ ]+) button '+re.escape(json.dumps(button))+'(?: |\n|$)'
 matches=re.findall(pattern,snap)
 if len(matches)!=1:raise RuntimeError('Need exactly one button '+button+', got '+str(matches))
 return tool(label,'click',{'pageId':page,'uid':matches[0]})
def fill(label,page,name,value,role='textbox'):
 snap=snapshot(label+'-before',page)
 found=re.findall(r'uid=([^ ]+) '+re.escape(role)+' '+re.escape(json.dumps(name))+r'(?: |\n|$)',snap)
 if len(found)!=1:raise RuntimeError('Need one '+role+' '+name+', got '+str(found))
 return tool(label,'fill',{'pageId':page,'uid':found[0],'value':value})

def shot(label,page):
 return tool(label+'-screenshot','take_screenshot',{'pageId':page,'filePath':str(base/(label+'.png')),'fullPage':True})

