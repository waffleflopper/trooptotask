import json, os, re, subprocess
from pathlib import Path
ROOT=Path.cwd()
RAW=ROOT/'.verification/evidence/verify-trooptotask/workspace-final'
ENV={**os.environ,'TMPDIR':'/home/waffleflops/.cache/vw1'}
CLI=['npm','run','--silent','verify:app','--']
CONTROL=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1']
def run(args,name=None):
 p=subprocess.run(args,env=ENV,text=True,capture_output=True)
 record={'command':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 with (RAW/'actions.jsonl').open('a') as out: out.write(json.dumps(record)+'\n')
 if name: (RAW/name).write_text(p.stdout)
 if p.returncode: raise RuntimeError(json.dumps(record))
 return json.loads(p.stdout)
def tool(name,params,record=None): return run(CLI+['tool',name,json.dumps(params),'--worker','1'],record)
def control(args,record=None): return run(CONTROL+args,record)
def snap(page,name):
 tool('take_snapshot',{'pageId':page,'filePath':str(RAW/name)})
 return (RAW/name).read_text()
def uid(text,role,label):
 matches=re.findall(r'^\s*uid=(\S+) '+re.escape(role)+r' '+re.escape(json.dumps(label))+r'(?:\s|$)',text,re.M)
 if len(matches)!=1: raise RuntimeError(f'Expected unique {role} {label}, got {matches}')
 return matches[0]
def click(page,role,label,name):
 text=snap(page,name+'-before.txt');tool('click',{'pageId':page,'uid':uid(text,role,label)})
 return snap(page,name+'-after.txt')
def shot(page,name): tool('take_screenshot',{'pageId':page,'filePath':str(RAW/name),'fullPage':True})
def data(page,name,org='orgA'):
 ids=json.loads((RAW/'fixture.json').read_text())['ids']
 keys=['personA','personB','personUnassigned','personForeign']
 source='async () => { const r=await fetch('+json.dumps('/org/'+ids[org]+'/personnel/__data.json')+'); const t=await r.text(); return { status:r.status, length:t.length, people:'+json.dumps({key:ids[key] for key in keys})+' , presence:Object.fromEntries(Object.entries('+json.dumps({key:ids[key] for key in keys})+').map(([k,id])=>[k,t.includes(id)])), catalog:{active:t.includes("VFY-ACTIVE-A"), retired:t.includes("VFY-RETIRED-A"), foreign:t.includes("VFY-ONLY-B")}}; }'
 return tool('evaluate_script',{'pageId':page,'function':source,'waitForStableDom':False},name)
