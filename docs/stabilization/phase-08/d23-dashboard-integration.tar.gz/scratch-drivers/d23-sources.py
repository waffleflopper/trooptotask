import importlib.util,json,re,sys,os
spec=importlib.util.spec_from_file_location('capture','.verification/tmp/d23-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
page=int(sys.argv[1]);tables=sys.argv[2:] or ['personnel_onboardings','rating_scheme_entries','personnel_trainings','availability_entries','daily_assignments','personnel_ict_completions','organizations']
def snapshot(label):
 r=m.native('take_snapshot',{'pageId':page},label+'.json');return '\n'.join(x.get('text','') for x in r.get('content',[]))
def click_link(label,name):
 txt=snapshot(label+'-before');modal=re.search(r'uid=(\S+) button "Got it"',txt)
 if modal:
  m.native('click',{'pageId':page,'uid':modal[1]},label+'-dismiss.json');txt=snapshot(label+'-dismissed')
 found=re.search(r'uid=(\S+) link "'+re.escape(name)+r'"',txt)
 if not found:raise RuntimeError(f'Missing {name} link in {label}')
 m.native('click',{'pageId':page,'uid':found[1]},label+'-click.json')
receipts=[]
for table in tables:
 for mode in os.environ.get('D23_SOURCE_MODES','hold,fail-hard').split(','):
  label=table+'-'+mode
  click_link(label+'-calendar','Calendar')
  m.call('helper','server-source',['arm',table,mode,'1','120000'],label+'-armed.json')
  click_link(label+'-home','Home')
  state=m.call('helper','server-source',['state'],label+'-matched.json')
  observed=snapshot(label+'-observed')
  if state['control']['phase'] not in ['held','synthetic-failure']:
   m.call('helper','server-source',['restore'],label+'-unmatched-restored.json');raise RuntimeError(f'Source {table} unmatched: {state}')
  if mode=='hold':m.call('helper','server-source',['release'],label+'-release.json')
  m.call('helper','server-source',['restore'],label+'-restored.json')
  settled=snapshot(label+'-settled')
  if mode=='fail-hard':
   retry=re.search(r'uid=(\S+) button "Retry Dashboard"',settled)
   if not retry:
    settled=snapshot(label+'-settled-later');retry=re.search(r'uid=(\S+) button "Retry Dashboard"',settled)
   if not retry:raise RuntimeError(f'Missing source failure/retry UI for {table}')
   m.native('click',{'pageId':page,'uid':retry[1]},label+'-recovery-click.json')
  else:m.native('navigate_page',{'pageId':page,'type':'reload'},label+'-recovery-reload.json')
  recovered=snapshot(label+'-recovered')
  receipts.append({'table':table,'mode':mode,'control':state['control'],'observed':label+'-observed.json','recovered':label+'-recovered.json'})
  (m.out/'source-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
  print(table,mode,'captured',flush=True)
