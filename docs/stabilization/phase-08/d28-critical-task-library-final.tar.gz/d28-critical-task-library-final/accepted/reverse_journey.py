import json
import native_driver as n
ids=json.load(open(n.ROOT/'fixture.json'))['ids']
n.PAGE=json.load(open(n.ROOT/'owner-entry.json'))['pageId']
n.click('Home','owner-home-open',role='link')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Overview'],'timeout':10000},'owner-home-ready'))
n.snap('owner-home');n.reload('owner-home-reload')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Overview'],'timeout':10000},'owner-home-reloaded-ready'))
n.snap('owner-home-settled')
fn=r'''async () => {
 const path=__PATH__;const response=await fetch(path);const raw=await response.text();
 let records;try {records=raw.split('\n').filter(Boolean).map(line=>JSON.parse(line));}
 catch {return {path,status:response.status,parseFailed:true};}
 let redactedCredentialSlots=0;
 const credentialKeys=['access_token','refresh_token'];
 const jwt=/eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{8,}/;
 const scrub=value=>{
   if(Array.isArray(value)){
     for(const item of value)if(item&&typeof item==='object'&&!Array.isArray(item))
       for(const key of credentialKeys){const index=item[key];if(Number.isInteger(index)&&typeof value[index]==='string'){value[index]='[REDACTED credential]';redactedCredentialSlots++;}}
     for(let i=0;i<value.length;i++)value[i]=scrub(value[i]);
   }else if(value&&typeof value==='object'){
     for(const [key,item] of Object.entries(value)){
       if(credentialKeys.includes(key)&&typeof item==='string'){value[key]='[REDACTED credential]';redactedCredentialSlots++;}
       else value[key]=scrub(item);
     }
   }else if(typeof value==='string'&&jwt.test(value)){redactedCredentialSlots++;return '[REDACTED credential]';}
   return value;
 };
 scrub(records);
 if(jwt.test(JSON.stringify(records)))return {path,status:response.status,redactionFailed:true};
 return {path,status:response.status,redactedCredentialSlots,records};
}'''.replace('__PATH__',json.dumps('/org/'+ids['orgA']+'/__data.json'))
print(n.tool('evaluate_script',{'pageId':n.PAGE,'function':fn,'filePath':str(n.ROOT/'owner-dashboard-http-redacted.json'),'waitForStableDom':False},'owner-dashboard-http-tool'))
print(n.tool('take_screenshot',{'pageId':n.PAGE,'filePath':str(n.ROOT/'owner-home.png')},'owner-home-shot'))
rows=json.load(open(n.ROOT/'completion-after-import.json'))['rows']
target=next(row for row in rows if row['personnel_id']==ids['personUnassigned'])
request={'method':'DELETE','path':'/org/'+ids['orgA']+'/api/personnel-ict-completions','submitted':{'id':target['id']}}
response=n.http([request],'completion-allowed-delete');assert response[0]['status']==200
n.control(['rows','personnel_ict_completions','orgA'],'completions-after-allowed-delete')
print(n.tool('close_page',{'pageId':n.PAGE},'owner-close'))
actor=n.control(['actor','manager','personnel'],'personnel-only-entry');n.PAGE=actor['pageId']
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Able, Synthetic'],'timeout':10000},'personnel-only-list-ready'))
n.snap('personnel-only-list');n.click_row('Open SPC Able, Synthetic','Details','personnel-only-detail-open')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Unavailable'],'timeout':10000},'personnel-only-detail-ready'))
n.snap('personnel-only-detail');n.reload('personnel-only-detail-reload')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Unavailable'],'timeout':10000},'personnel-only-detail-reloaded-ready'))
n.snap('personnel-only-detail-settled')
print(n.tool('close_page',{'pageId':n.PAGE},'personnel-only-close'))
print('REVERSE CONSUMER JOURNEY COMPLETE',flush=True)
