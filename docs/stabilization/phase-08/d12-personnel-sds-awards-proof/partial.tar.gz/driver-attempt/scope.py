import json,re
from flow import call,tool,snapshot,click,shot,base
from http import ack,flags,row,request,ORG,PERSON,siblings_equal
from sds import fill_values
seed=json.loads((base/'seed-lifecycle.json').read_text());fixture=json.loads((base/'fixture.json').read_text());owner=json.loads((base/'owner-page.json').read_text())['pageId'];checks=[]
BODY={'personnelId':PERSON,'bloodType':'O+','basd':'2020-02-03','dateOfRank':'2024-06-01','maritalStatus':'Married','numberOfDependents':2,'children':[{'name':'Avery','age':7},{'name':'Morgan','age':None}],'civilianEducation':'BSN','militaryEducation':['BLC','Air Assault'],'emergencyContactName':'Synthetic Contact','emergencyContactRelationship':'Sibling','emergencyContactPhone':'907-555-0188','spouseName':'Synthetic Spouse','spousePhone':'907-555-0101','vehicleMakeModel':'Toyota Tacoma','vehiclePlate':'VFY482','vehicleColor':'','personalEmail':'synthetic-sds@example.test','personalPhone':'907-555-0102','addressStreet':'100 Synthetic Way','addressCity':'Anchorage','addressState':'AK','addressZip':'99501'}
def projections(label):return {org:{t:call(label+'-'+org+'-'+t,'control','rows',t,org)['rows'] for t in ['personnel','personnel_extended_info']} for org in ['orgA','orgB']}
def successes(label):
 rows=call(label,'control','rows','audit_logs','orgA')['rows']
 return sorted((r['id'],r['action'],r.get('resource_id')) for r in rows if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared'])
def open_person(label,page):
 s=snapshot(label+'-before',page);name='Open SPC '+seed['name']+', Synthetic'
 m=re.search(r'row '+re.escape(json.dumps(name))+r'\n([\s\S]*?)(?=\n        uid=|\n  uid=)',s)
 if not m:raise RuntimeError('Exact Person row missing '+name)
 uid=re.search(r'uid=([^ ]+) button "Details"',m[1]).group(1)
 tool(label,'click',{'pageId':page,'uid':uid})
def denied_batch(label,page,targets):
 before=projections(label+'-before');auditBefore=successes(label+'-audit-before');results=[]
 for key,person,org,expectedA,expectedS in targets:
  a=ack(label+'-'+key+'-ack',page,person=person,org=org)
  b=request(label+'-'+key+'-sds',page,'/org/'+org+'/api/personnel/'+person+'/extended-info','PUT',{**BODY,'personnelId':person,'bloodType':'AB-'})
  assert a['status']==expectedA and b['status']==expectedS,(key,a,b)
  results.append({'case':key,'personnelId':person,'organizationId':org,'ackStatus':a['status'],'sdsStatus':b['status']})
 after=projections(label+'-after');auditAfter=successes(label+'-audit-after');assert before==after and auditBefore==auditAfter
 checks.append({'scenario':label,'result':'PASS','requests':results,'allFullABRowsExact':True,'successAuditsExact':True})
assert ack('scope-owner-alpha-set',owner)['status']==200
assert ack('scope-owner-bravo-set',owner,person=seed['ids']['duplicateBravo'])['status']==200
for role in ['manager','personnelScoped','scoped','personnelOperate','personnelEmpty','viewer','foreign']:
 actor=call('scope-'+role+'-login','control','actor',role,'personnel');page=actor['pageId'];(base/('scope-'+role+'-page.json')).write_text(json.dumps({'pageId':page},indent=2)+'\n')
 s=snapshot('scope-'+role+'-roster',page);shot('scope-'+role+'-roster',page)
 if role in ['manager','personnelScoped']:
  open_person('scope-'+role+'-detail-open',page);s=snapshot('scope-'+role+'-detail',page);shot('scope-'+role+'-detail',page);assert seed['name'] in s and 'More info' in s
  before=row('scope-'+role+'-sds-before')[0]
  click('scope-'+role+'-sds-open',page,'More info')
  values=({'Emergency phone':'907-555-0188'} if role=='manager' else {'Emergency contact':'Scoped Synthetic Contact'})
  fill_values('scope-'+role+'-sds-fill',page,values);click('scope-'+role+'-sds-save',page,'Save')
  after=row('scope-'+role+'-sds-after')[0];field=('emergency_contact_phone' if role=='manager' else 'emergency_contact_name');expected=('907-555-0188' if role=='manager' else 'Scoped Synthetic Contact')
  siblings_equal(before,after,{field,'updated_at'});assert after[field]==expected and after['award_tracking_acknowledged_at']==before['award_tracking_acknowledged_at']
  tool('scope-'+role+'-sds-reload','navigate_page',{'pageId':page,'type':'reload'});click('scope-'+role+'-reloaded-sds-open',page,'More info');ss=snapshot('scope-'+role+'-reloaded-form',page);shot('scope-'+role+'-reloaded-form',page);assert expected in ss;click('scope-'+role+'-reloaded-close',page,'Cancel')
  checks.append({'scenario':role+' native admitted save/reload preserves siblings','result':'PASS','before':before,'after':after})
  if role=='personnelScoped':
   f=flags('scope-alpha-flags',page);assert any(set(m['ids'])=={PERSON} for m in f['matches']),f
   denied_batch('scope-alpha-denials',page,[('bravo',seed['ids']['duplicateBravo'],ORG,403,404),('unassigned',fixture['ids']['personUnassigned'],ORG,403,404),('foreign-person',fixture['ids']['personForeign'],ORG,404,404),('missing','11111111-1111-4111-8111-111111111111',ORG,404,404)])
 elif role=='scoped':
  f=flags('scope-view-only-flags',page);assert any(set(m['ids'])=={PERSON} for m in f['matches']),f
  assert 'More info' not in s
  denied_batch('scope-view-only-denied',page,[('alpha',PERSON,ORG,403,403)])
 elif role=='personnelOperate':
  open_person('scope-operate-detail-open',page);s=snapshot('scope-operate-detail-denial',page);shot('scope-operate-detail-denial',page);assert 'More info' not in s and ('Forbidden' in s or '403' in s),s
  before=row('scope-operate-before')[0]
  r=request('scope-operate-sds-allowed',page,'/org/'+ORG+'/api/personnel/'+PERSON+'/extended-info','PUT',{**BODY,'emergencyContactName':'Scoped Synthetic Contact','emergencyContactPhone':'907-555-0177'});assert r['status']==200,r
  after=row('scope-operate-after')[0];siblings_equal(before,after,{'emergency_contact_phone','updated_at'});assert after['emergency_contact_phone']=='907-555-0177'
  assert ack('scope-operate-ack-allowed',page)['status']==200
  checks.append({'scenario':'operate-only API permitted while native dashboard remains denied','result':'PASS','before':before,'after':after,'nativeLimit':'Actual More info unavailable through denied detail dashboard; no bypassed UI pass.'})
 elif role=='personnelEmpty':
  f=flags('scope-empty-flags',page);assert any(m['ids']==[] for m in f['matches']),f
  assert seed['name'] not in s
  denied_batch('scope-empty-denied',page,[('alpha',PERSON,ORG,403,404)])
 elif role=='viewer':
  f=flags('scope-viewer-flags',page);assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
  denied_batch('scope-viewer-denied',page,[('alpha',PERSON,ORG,403,403)])
 elif role=='foreign':
  assert seed['name'] not in s
  denied_batch('scope-foreign-org-denied',page,[('a-target',PERSON,ORG,403,403)])
(base/'scope-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'boundary':'Native normal/denied affordances, ordinary authenticated requests, public authorized IDs and real28-field A/B provider rows; no full data stream retained.'},indent=2)+'\n')
