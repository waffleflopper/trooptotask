import json,re,hashlib
from pathlib import Path
from flow import call,tool,snapshot,click,shot,base,root
from http import flags,extract,ORG,PERSON
seed=json.loads((base/'seed-lifecycle.json').read_text());fixture=json.loads((base/'fixture.json').read_text());page=json.loads((base/'switch-page.json').read_text())['pageId']
def read(p):return json.loads(p.read_text())
baseline=Path('/home/waffleflops/.cache/t2t-1360-personnel-detail/.verification/evidence/verify-trooptotask/personnel-detail-baseline')
actual={key:extract(read(base/(label+'.json'))) for key,label in [('bPersonACK','switch-b-view-ack-denied'),('bPersonSDS','switch-b-view-sds-denied'),('aPersonUnderB','switch-b-foreign-id-concealed')]}
assert all(v['status']==403 for v in actual.values())
baselineView=extract(read(baseline/'scope-viewer-denied-ack.json'));assert baselineView['status']==403 and baselineView['body']==actual['aPersonUnderB']['body']
paths=['src/lib/server/adapters/httpAdapter.ts','src/routes/org/[orgId]/api/personnel/[id]/award-tracking/+server.ts','src/routes/org/[orgId]/api/personnel/[id]/extended-info/+server.ts','scripts/verification/fixtures.mjs']
evidence={p:{'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths}
comparison={'classification':'UNSUPPORTED_SCRATCH_EXPECTATION_PERMISSION403','failedCommand':'native-consumers-switch-command.json','failedExpectation':404,'actualResponses':actual,'baselineViewerACK':baselineView,'exactBViewForeignIDBaseline':'Not present; viewer403 is adjacent baseline, not a claim of exact same prior journey.','sourceBoundary':'Both routes declare manageRecords and unscoped policy. handleUseCaseRequest at httpAdapter.ts:583 awaits enforceRouteAuthorization before validation and config.fn. personnelSwitch fixture B membership is Personnel view. Route permission denial occurs before own Person lookup, so foreign-ID lookup404 is not reached.','sourceEvidence':evidence,'acceptance':'Genuine denial, no Person data disclosure, literal full A/B rows and successful-audit projection unchanged; independent scope/membership404 requirements preserved in scope-final-check.json.','appChanges':False}
assert 'blood_type' not in actual['aPersonUnderB']['body'] and PERSON not in actual['aPersonUnderB']['body']
(base/'switch-status-source-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
before={o:{t:read(base/('switch-b-before-'+o+'-'+t+'.json'))['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']}
after={o:{t:call('switch-b-after-'+o+'-'+t,'control','rows',t,o)['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']};assert before==after
previous=read(base/'scope-foreign-attempt-audit-after.json')['rows'];now=call('switch-b-audit-after','control','rows','audit_logs','orgA')['rows'];select=lambda rows:sorted((r['id'],r['action'],r.get('resource_id')) for r in rows if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared']);assert select(previous)==select(now)
click('switch-a-menu-open',page,'Switch organization');s=snapshot('switch-a-menu',page)
m=re.findall(r'uid=([^ ]+) menuitem "[^"\n]*Verification Organization A[^"\n]*"',s)
if len(m)!=1:raise RuntimeError('Need actual A menuitem, got '+str(m))
tool('switch-a-select','click',{'pageId':page,'uid':m[0]});s=snapshot('switch-a-returned',page);shot('switch-a-returned',page);assert seed['name'] in s
f=flags('switch-a-returned-ack-ids',page);assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
ownerFlags=extract(read(base/'consumer-home-ack-ids.json'));assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in ownerFlags['matches'])
checks=[{'scenario':'Native Org Dashboard and Personnel roster plus selected admitted ID projections','result':'PASS','observedIn':'native-consumers-switch.log and consumer native snapshots/screenshots; selected public IDs from consumer-home-ack-ids.json','limit':'No native ACK toggle or badge exists; projected IDs are separate public data proof.'},{'scenario':'Native Aconfigure→Bview→A switch; B roster only own Person and no Add Person; writes denied, foreign ID concealed, full A/B rows and success audits preserved','result':'PASS','ackStatus':403,'sdsStatus':403,'aForeignIDUnderBViewStatus':403,'allFullABRowsExact':True,'successAuditProjectionExact':True,'auditBefore':'scope-foreign-attempt-audit-after.json captured before consumer navigation; no writes intervened','limit':'No held-save cross-tab or server-stream-fault claim. Existing lower-level stale/deferred tests and unchanged accepted baseline remain separate.'}]
(base/'native-consumer-switch-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'retainedFailure':'native-consumers-switch.log/.stderr/-command.json and unchanged failed consumer-switch.py; source/status comparison in switch-status-source-comparison.json'},indent=2)+'\n')
tool('switch-page-close','close_page',{'pageId':page})
