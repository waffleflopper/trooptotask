from drive import *
import sys
mode=sys.argv[1]
assert mode in ['before','history']
seed=json.loads((E/'notes-legacy-seed.json').read_text())
if mode=='before':
 page=control(['actor','onboardingOperate','onboarding'],'notes-native-before-actor')['pageId']
 s=snap(page,'notes-native-before')
 assert seed['person']['last_name'] in s and 'NO TEMPLATE' in s,s
 screen(page,'notes-native-before')
else:
 from overlap import ordinary
 result=ordinary('onboardingOperate','onboarding',{'id':seed['packets'][0]['id'],'status':'completed'},'notes-supported-complete')
 assert result['status']==200,result
 page=control(['actor','onboardingView','onboarding/history'],'notes-native-history-actor')['pageId']
 write(E/'notes-history-page.json',json.dumps({'pageId':page},indent=2)+'\n')
print('notes '+mode+' native flow prepared.',flush=True)
