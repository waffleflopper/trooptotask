import assert from 'node:assert/strict';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import ExcelJS from 'exceljs';

const root = dirname(fileURLToPath(import.meta.url));
const json = async (name) => JSON.parse(await readFile(join(root, name), 'utf8'));
const rows = async (name) => (await json(name)).rows;
const sorted = (values) => [...values].sort((a, b) => a.id.localeCompare(b.id));
const checks = [];
const check = (name, fn) => { fn(); checks.push(name); };
const fixture = await json('fixture.json');
const original = await rows('baseline-personnel_trainings-orgA.json');
const created = await rows('16-create-rows.json');
const edited = await rows('25-edit-rows.json');
const retried = await rows('48-retry-rows.json');
const canceled = await rows('31-cancel-rows.json');
const failed = await rows('43-failed-save-rows.json');
const denied = await rows('137-denials-after-orgA.json');
const deleteFailed = await rows('160-delete-failed-rows.json');
const finalTraining = await rows('174-training-final-orgA.json');
const originalB = await rows('baseline-personnel_trainings-orgB.json');
const finalB = await rows('175-training-final-orgB.json');
const optional = (values) => values.find((row) => row.training_type_id === fixture.ids.trainingOptional);

check('create and edit retain the exact Optional completion identity and null dates', () => {
  const first = optional(created), last = optional(edited);
  assert.equal(first.id, '74743532-ea2c-413c-b169-51daea634d04');
  assert.equal(last.id, first.id);
  assert.equal(last.created_at, first.created_at);
  assert.equal(last.completion_date, null);
  assert.equal(last.expiration_date, null);
  assert.equal(last.notes, 'Worker2 optional edit');
  assert.equal(last.certificate_url, 'https://example.test/worker2/edit');
});
check('cancel and failed save leave all saved Training rows exactly unchanged', () => {
  assert.deepEqual(sorted(canceled), sorted(edited));
  assert.deepEqual(sorted(failed), sorted(edited));
});
check('retry persists the requested values on the same Optional completion', () => {
  const first = optional(created), last = optional(retried);
  assert.equal(last.id, first.id);
  assert.equal(last.created_at, first.created_at);
  assert.equal(last.completion_date, null);
  assert.equal(last.expiration_date, null);
  assert.equal(last.notes, 'Worker2 retry persisted');
  assert.equal(last.certificate_url, 'https://example.test/worker2/retry');
});
check('denied and failed-removal requests leave all saved Training rows unchanged', () => {
  assert.deepEqual(sorted(denied), sorted(retried));
  assert.deepEqual(sorted(deleteFailed), sorted(retried));
});
check('native removal and reload restore the exact original A and B Training rows', () => {
  assert.deepEqual(sorted(finalTraining), sorted(original));
  assert.deepEqual(sorted(finalB), sorted(originalB));
});

const originalOrg = (await rows('baseline-organizations-orgA.json'))[0];
const failedOrg = (await rows('70-goal-failed-rows.json'))[0];
const savedOrg = (await rows('76-goal-saved-rows.json'))[0];
const restoredOrg = (await rows('119-restored-orgA.json'))[0];
const orgB = (await rows('baseline-organizations-orgB.json'))[0];
const observedOrgB = (await rows('77-goal-orgB-sentinel.json'))[0];
check('goal failure preserves all fields, save changes only the goal, and native restore is exact', () => {
  assert.deepEqual(failedOrg, originalOrg);
  assert.deepEqual(savedOrg, { ...originalOrg, training_readiness_goal_percent: 85 });
  assert.deepEqual(restoredOrg, originalOrg);
  assert.deepEqual(observedOrgB, orgB);
});

const artifact = await json('owner-a.json');
const book = new ExcelJS.Workbook();
await book.xlsx.readFile(join(root, 'owner-a.xlsx'));
check('JSON retains 38 inventory sections including empty arrays with accurate counts', () => {
  assert.equal(artifact.organizationId, fixture.ids.orgA);
  assert.equal(artifact.sectionInventory.length, 38);
  assert.equal(Object.keys(artifact.sections).length, 38);
  for (const entry of artifact.sectionInventory) {
    assert.ok(Array.isArray(artifact.sections[entry.key]), entry.key);
    assert.equal(entry.rowCount, artifact.sections[entry.key].length, entry.key);
    assert.deepEqual(artifact[entry.key], artifact.sections[entry.key], entry.key);
  }
});

const rawRows = (sheetName) => {
  const sheet = book.getWorksheet(sheetName);
  assert.ok(sheet, sheetName);
  const keys = sheet.getRow(1).values.slice(1).map((value) => String(value).toLowerCase().replaceAll(' ', '_'));
  return Array.from({ length: sheet.rowCount - 1 }, (_, rowIndex) => Object.fromEntries(keys.map((key, index) => [key, sheet.getRow(rowIndex + 2).getCell(index + 1).value])));
};
const sources = [
  ['organizationProfile', [savedOrg], 'Raw - Organization Profile'],
  ['trainingTypes', await rows('baseline-training_types-orgA.json'), 'Raw - Training Types'],
  ['personnelTrainings', retried, 'Raw - Personnel Trainings'],
  ['trainingViews', await rows('baseline-training_views-orgA.json'), 'Raw - Training Views']
];
for (const [key, source, sheetName] of sources) {
  const actual = artifact[key];
  const workbookRows = rawRows(sheetName);
  check(`${key} preserves every provider-read field and row ID in JSON and Excel`, () => {
    assert.equal(actual.length, source.length, key);
    assert.equal(workbookRows.length, source.length, sheetName);
    for (const expected of source) {
      const jsonRow = actual.find((row) => row.id === expected.id);
      const excelRow = workbookRows.find((row) => row.id === expected.id);
      assert.ok(jsonRow, expected.id);
      assert.ok(excelRow, expected.id);
      for (const [field, value] of Object.entries(expected)) {
        assert.deepEqual(jsonRow[field], value, `${key}.${field}`);
        assert.deepEqual(excelRow[field], typeof value === 'object' && value !== null ? JSON.stringify(value) : value, `${sheetName}.${field}`);
      }
      assert.notEqual(expected.organization_id ?? expected.id, fixture.ids.orgB);
    }
  });
}
const inventory = book.getWorksheet('Export Inventory');
check('Excel inventory retains all 38 sections and exact affected row counts', () => {
  assert.equal(inventory.rowCount - 1, 38);
  for (const [key, source] of sources) {
    let observed;
    inventory.eachRow((row, index) => { if (index > 1 && row.getCell(5).value === key) observed = row.getCell(6).value; });
    assert.equal(observed, source.length, key);
  }
});
check('readable Organization Training Records resolve names and preserve exact original dates', () => {
  const sheet = book.getWorksheet('Training Records');
  assert.equal(sheet.rowCount - 1, 2);
  assert.deepEqual(sheet.getRow(2).values.slice(1), ['SPC Able, Synthetic', 'Verification Required Training', '2026-09-28', '2027-09-28']);
  assert.deepEqual(Array.from({ length: 6 }, (_, index) => sheet.getRow(3).getCell(index + 1).value), ['SPC Baker, Synthetic', 'Verification Optional Training', null, null, 'Worker2 retry persisted', 'https://example.test/worker2/retry']);
});
const lifecycle = await rows('112-excel-lifecycle-reloaded.json');
for (const [fileName, recordId] of [['owner-a.json', 'd6723914-152f-4436-9238-05eb30e4ae4a'], ['owner-a.xlsx', 'f67728e2-e10f-42cd-bcff-675a71e8f021']]) {
  const bytes = (await stat(join(root, fileName))).size;
  check(`${fileName} has a reloaded completed lifecycle record with matching requester, tenant and size`, () => {
    const row = lifecycle.find((value) => value.id === recordId);
    assert.equal(row.org_id, fixture.ids.orgA);
    assert.equal(row.requested_by, originalOrg.created_by);
    assert.equal(row.status, 'completed');
    assert.equal(row.file_size_bytes, bytes);
    assert.ok(row.completed_at);
  });
}
const person = new ExcelJS.Workbook();
await person.xlsx.readFile(join(root, 'able-person.xlsx'));
check('the native Person workbook preserves the original Required type and dates', () => {
  const sheet = person.getWorksheet('Training Records');
  assert.equal(sheet.rowCount - 1, 1);
  assert.deepEqual(sheet.getRow(2).values.slice(1), ['Verification Required Training', '2026-09-28', '2027-09-28']);
});

const result = { status: 'PASS', checks, candidate: '02631eb368fd88e8c4d4c2c19031268f4358c575', artifactCounts: { trainingTypes: 3, personnelTrainings: 2, trainingViews: 1, profileFields: 12, inventorySections: 38 } };
await writeFile(join(root, 'validation.json'), JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify(result, null, 2) + '\n');
