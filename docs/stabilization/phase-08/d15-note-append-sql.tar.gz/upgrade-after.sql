BEGIN;
CREATE EXTENSION IF NOT EXISTS pgtap WITH SCHEMA extensions;
SELECT no_plan();
SELECT is((SELECT count(*)::integer FROM supabase_migrations.schema_migrations WHERE version='20261002000100'),
  1,'only the held new note migration is applied after populated setup');
SELECT results_eq($$ SELECT * FROM upgrade_fixture.saved_rows ORDER BY table_name,id $$,
  $$ SELECT * FROM upgrade_fixture.note_before ORDER BY table_name,id $$,
  'every populated parent/progress/Person field and malformed legacy note is unchanged by upgrade');
SELECT ok(has_function_privilege('authenticated','public.append_onboarding_step_note(uuid,uuid,text)','EXECUTE')
  AND NOT has_function_privilege('anon','public.append_onboarding_step_note(uuid,uuid,text)','EXECUTE')
  AND NOT has_function_privilege('service_role','public.append_onboarding_step_note(uuid,uuid,text)','EXECUTE'),
  'upgraded append has only the ordinary authenticated application grant');
SELECT ok((SELECT provolatile='v' AND NOT prosecdef AND proconfig=ARRAY['search_path=""']::text[]
  FROM pg_proc WHERE oid='public.append_onboarding_step_note(uuid,uuid,text)'::regprocedure),
  'upgraded append is volatile invoker with empty search path');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','d1505000-0000-4000-8000-000000000003',true);
SELECT throws_ok($$ SELECT public.append_onboarding_step_note('d1505000-0000-4000-8000-000000000101',
  'd1505000-0000-4000-8000-000000000801','denied upgrade append') $$,
  '42501',NULL,'upgraded View remains unable to append');
SELECT set_config('request.jwt.claim.sub','d1505000-0000-4000-8000-000000000005',true);
SELECT throws_ok($$ SELECT public.append_onboarding_step_note('d1505000-0000-4000-8000-000000000101',
  'd1505000-0000-4000-8000-000000000805','denied upgrade append') $$,
  'P0002',NULL,'upgraded scoped Operate cannot append to Bravo');
RESET ROLE;
SELECT results_eq($$ SELECT * FROM upgrade_fixture.saved_rows ORDER BY table_name,id $$,
  $$ SELECT * FROM upgrade_fixture.note_before ORDER BY table_name,id $$,
  'upgraded denied requests preserve every populated field');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','d1505000-0000-4000-8000-000000000005',true);
SELECT is(public.append_onboarding_step_note('d1505000-0000-4000-8000-000000000101',
  'd1505000-0000-4000-8000-000000000803','Upgraded history note')->'notes'->1->>'text',
  'Upgraded history note','upgraded scoped operator appends to completed inactive history');
RESET ROLE;
SELECT is((SELECT notes->0 FROM public.onboarding_step_progress WHERE id='d1505000-0000-4000-8000-000000000803'),
  (SELECT row_data->'notes'->0 FROM upgrade_fixture.note_before WHERE table_name='progress'
    AND id='d1505000-0000-4000-8000-000000000803'),
  'upgraded ordinary append retains every original note attribute');
SELECT results_eq($$ SELECT table_name,id,CASE WHEN table_name='progress'
    THEN row_data-'notes'-'updated_at' ELSE row_data END FROM upgrade_fixture.saved_rows ORDER BY table_name,id $$,
  $$ SELECT table_name,id,CASE WHEN table_name='progress'
    THEN row_data-'notes'-'updated_at' ELSE row_data END FROM upgrade_fixture.note_before ORDER BY table_name,id $$,
  'upgraded append preserves every populated parent/Person and progress work field');
SELECT * FROM finish();
ROLLBACK;
