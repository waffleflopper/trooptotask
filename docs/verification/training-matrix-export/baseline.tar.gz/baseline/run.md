# Affected baseline

Candidate 63619109f005dad68641342e282eacbdc7f2394dfd9c54e15dd7b0a9d259c2da on base 228e6d5c8b0c9c3b38f922fb1a4b7c50e71eac4a. Owned app origin http://127.0.0.1:35829. Chromium 152.0.7977.82. Native verify-trooptotask controls, synthetic trainingConfigure actor, Organization A and its Alpha/Bravo/Unassigned roster.

The parent signed in through the normal form and inspected the unchanged matrix. Able Required was Current; Able Targeted and Baker/Unassigned Required were Not Done; other targeted/optional cells were N/A. The parent clicked Reports, inspected 25% required readiness, downloaded the real Excel workbook through Export Excel, read its Summary and checked the same briefing after reload. The saved workbook retained Summary, Forecast, Hot spots, Focus and Requirements.

Doctor passed before driving and after observations. Owned cleanup passed. The raw matrix/report/reload snapshots and workbook survived cleanup. The first launch using the shell's Node 26.8.2 failed because adapter-vercel requires Node 20, 22 or 24. Cleanup completed and the successful baseline used installed Node 24.21.0. No existing or production database was used.
