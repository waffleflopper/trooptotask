SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('7ef2c7e1-859d-4975-b4b8-a1a2cc504167'::uuid,'2917cbea-a576-4d58-b124-376003114601'::uuid,'fbb3a020-2c78-4389-b84f-aef7d2bc777c'::uuid,'0d995244-b8b3-4bad-9cf8-56ef470e010c'::uuid,'42e69ac7-84f6-4865-b493-5cba82851ce0'::uuid,'330a76a8-9260-4931-8657-f827a4ead267'::uuid,'f9a43390-f8b1-480c-8dbf-7e84dba2c714'::uuid,'778637b5-4603-491a-b188-c60df47a0a0b'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('7a6a87aa-cc12-4fb1-8faa-f374c8f01ffb'::uuid,'c9fb30dd-e909-4dc9-83f7-4d1726808615'::uuid,'d91d4720-7a70-40fe-b60b-47b80125c043'::uuid,'5ee8e6ae-c802-4f05-aff0-cdcd1ca99eb5'::uuid,'fbf85667-c905-4d68-9a6e-557068ac3239'::uuid,'3b2cccb2-0fe3-4c7c-befd-a714208c32a3'::uuid,'b4dc757c-af67-4b77-843e-5803374cf2bb'::uuid,'808af5ac-d537-4c2f-9a0a-73d2a86ba63f'::uuid)) s), '[]'::json));
