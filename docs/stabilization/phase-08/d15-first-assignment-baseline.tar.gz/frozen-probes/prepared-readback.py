from drive import *
import hashlib
seed=json.loads((E/'legacy-seed.json').read_text()); packet=seed['packets'][0]['id']
templates=control(['rows','onboarding_templates','orgA'],'prepared-templates-final')['rows']
for letter in ['A','B']:
 matches=[t for t in templates if t['name']=='D15 Assignment Race '+letter+' '+seed['tag']]; assert len(matches)==1
 body={'onboardingId':packet,'newTemplateId':matches[0]['id']}
 (E/('request-'+letter.lower()+'.json')).write_text(json.dumps(body,indent=2)+'\n')
 control(['rows','onboarding_template_steps','orgA','template_id',matches[0]['id']],'prepared-definitions-'+letter)
control(['rows','personnel_onboardings','orgA','id',packet],'prepared-parent')
control(['rows','onboarding_step_progress','orgA','onboarding_id',packet],'prepared-progress')
f=json.loads((E/'fixture.json').read_text())
(E/'warm-foreign-template-body.json').write_text(json.dumps({'onboardingId':packet,'newTemplateId':f['ids']['onboardingForeignTemplate']},indent=2)+'\n')
for name in ['owned-onboarding-http.mjs','onboarding-http.mjs']:
 (E/'frozen-probes'/name).write_bytes((ROOT/'.verification/tmp/d15-packets'/name).read_bytes())
print('Both native templates and original null-template packet captured; exact request bodies saved.')
