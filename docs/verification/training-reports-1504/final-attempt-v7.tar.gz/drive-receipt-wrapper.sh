#!/bin/bash
# usage: r7.sh NAME cmd...
cd /home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp NODE_DISABLE_COMPILE_CACHE=1
E=.verification/evidence/verify-trooptotask/1504-final-v7/drive
n=$1; shift
[ -e $E/$n.json ] && { echo "DUPLICATE receipt $n" >&2; exit 99; }
s=$(date -u +%FT%T.%3NZ)
"$@" >$E/$n.stdout 2>$E/$n.stderr; rc=$?
f=$(date -u +%FT%T.%3NZ)
python3 - "$E/$n.json" "$s" "$f" "$rc" "$@" <<'PY'
import json,sys
p,s,f,rc,*a=sys.argv[1:]
json.dump({"argv":a,"exit":int(rc),"start":s,"end":f},open(p,"w"),indent=1)
PY
cat $E/$n.stdout | head -c ${MAXOUT:-4000}; [ -s $E/$n.stderr ] && { echo "--stderr--"; head -c 2000 $E/$n.stderr; }
echo "[exit $rc]"
