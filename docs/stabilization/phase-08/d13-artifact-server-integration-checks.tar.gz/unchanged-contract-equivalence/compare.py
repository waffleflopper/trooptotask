"""Read-only D13 comparison. Writes only this authorized HOME-cache receipt directory."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess, tarfile
ROOT=Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-4e182844')
OUT=Path(__file__).resolve().parent
BASE='62c8d820c32a0202bd4b17c6cec2cbedbe5eabf7'
HISTORY={'auth':'17ed84529158d3d7e18659326e40a4c4d78430e8','retention':'bb524e4594477ba1054eff49746bd57b46842c4e','cascade_cap':'f21c2711748200694b2b230d1c69f88c63972f06','context':BASE}
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def blob(rev,path):
 p=subprocess.run(['git','show',f'{rev}:{path}'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return p.stdout if p.returncode==0 else None
def hashes(data):
 out={}
 for line in data.decode().splitlines():
  m=re.match(r'^([a-f0-9]{64}) [ *](.+)$',line)
  if m:out[m[2]]=m[1]
 return out
archives={}
for stem in ['d13-artifact-auth-negotiation','d13-artifact-auth-sessions','d13-artifact-retention-repair-small','d13-artifact-retention-repair-large','d13-artifact-cascade-export-baseline','d13-artifact-cap-concurrency','d13-artifact-context-review-refresh']:
 p=ROOT/'docs/stabilization/phase-08'/f'{stem}.tar.gz'
 with tarfile.open(p) as t:
  files={m.name:m for m in t.getmembers() if m.isfile()}
  inventory=hashes(t.extractfile('ARTIFACT_SHA256SUMS').read())
  bad=[n for n,h in inventory.items() if n not in files or sha(t.extractfile(n).read())!=h]
  extra=sorted(set(files)-set(inventory)-{'ARTIFACT_SHA256SUMS'})
  assert not bad and not extra,(stem,bad,extra)
  historical=blob(HISTORY['cascade_cap'] if 'cascade-export' in stem or 'cap-concurrency' in stem else HISTORY['retention'] if 'retention' in stem else HISTORY['context'] if 'context' in stem else HISTORY['auth'],str(p.relative_to(ROOT)))
  entry={'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes()),'archiveBytes':p.stat().st_size,'payloadFiles':len(inventory),'allInventoryHashesMatch':True,'exactInventoriedFileSet':True,'sameArchiveBytesAtAcceptedCommit':historical is not None and sha(historical)==sha(p.read_bytes()),'inventorySha256':sha(t.extractfile('ARTIFACT_SHA256SUMS').read())}
  if 'frozen-inputs.sha256' in files:
   entry['frozenManifestSha256']=sha(t.extractfile('frozen-inputs.sha256').read());entry['frozenInputs']=hashes(t.extractfile('frozen-inputs.sha256').read())
  if 'cap-concurrency' in stem:
   entry['preparedInputs']=hashes(t.extractfile('worker-prepared-inputs.log').read())
   entry['freshCopiedInputs']=hashes(t.extractfile('worker-fresh-copied-input-hashes.log').read())
   run=json.loads(t.extractfile('worker-database-run.json').read());entry['historicalRun']={k:run[k] for k in ['command','started_utc','finished_utc','exit','sql_sha256','runner_sha256','config_sha256','sql_sha256_after'] if k in run}
  archives[stem]=entry
# Record every accepted SQL/migration input and any later main additions without claiming a fresh current-chain replay.
oldsql=git('ls-tree','-r','--name-only',HISTORY['cascade_cap'],'--','supabase').decode().splitlines()
newsql=git('ls-files','supabase').decode().splitlines()
sql=[]
for p in sorted(set(oldsql+newsql)):
 old=blob(HISTORY['cascade_cap'],p);current=(ROOT/p).read_bytes() if (ROOT/p).is_file() else None
 if not (p.endswith('.sql') or p=='supabase/config.toml'):continue
 sql.append({'path':p,'acceptedCommitSha256':sha(old) if old is not None else None,'currentSha256':sha(current) if current is not None else None,'classification':'identical' if old==current else 'addedAfterAcceptedRun' if old is None else 'changedOrRemoved'})
cap=archives['d13-artifact-cap-concurrency']
capcopy=[]
for p,h in cap['freshCopiedInputs'].items():
 if p=='supabase/config.toml':continue # The runner transforms config for its disposable ports/project.
 capcopy.append({'path':p,'copiedHistoricalSha256':h,'currentSha256':sha((ROOT/p).read_bytes()),'identical':sha((ROOT/p).read_bytes())==h})
selected=[]
def group(name,paths,archive,history):
 manifest=archives[archive].get('frozenInputs',{})
 for p in paths:
  if not (ROOT/p).is_file():continue
  now=(ROOT/p).read_bytes();old=blob(HISTORY[history],p)
  selected.append({'group':name,'path':p,'currentSha256':sha(now),'acceptedCommit':HISTORY[history],'acceptedCommitSha256':sha(old) if old is not None else None,'commitIdentical':old==now,'archive':archive,'frozenInputSha256':manifest.get(p),'frozenInputIdentical':manifest.get(p)==sha(now) if p in manifest else None})
writer=['src/features/personnel/artifactWrites.server.ts','src/features/personnel/artifactWrites.server.test.ts','src/lib/server/adapters/supabaseScopeEnforcement.ts','src/lib/server/adapters/scopeRules.ts','src/lib/server/adapters/supabaseStorage.ts','src/lib/server/supabasePagination.server.ts','scripts/ci/personnel_roster_provider_probe.mjs','scripts/ci/personnel_retention_provider_probe.mjs','scripts/ci/personnel_group_upgrade_provider_probe.mjs','scripts/ci/database.py','supabase/config.toml']
writer+=git('ls-files','src/lib/access','src/lib/storage').decode().splitlines()
group('writer/provider/security',writer,'d13-artifact-auth-sessions','auth')
reverse=[]
for stem in ['personnelExport','organizationExport','personnelArchiveCascade','personnelLifecycle']:
 reverse +=[f'src/features/personnel/{stem}.server.ts',f'src/features/personnel/{stem}.server.test.ts']
for stem in ['organizationExport','organizationExportWorkbook']:
 reverse +=[f'src/lib/server/core/useCases/{stem}.ts',f'src/lib/server/core/useCases/{stem}.test.ts']
reverse += ['src/routes/org/[orgId]/api/export/+server.ts','src/routes/org/[orgId]/api/export/server.test.ts','src/routes/org/[orgId]/api/export-excel/+server.ts','src/routes/org/[orgId]/api/export-excel/server.test.ts','src/routes/org/[orgId]/api/personnel/[id]/export/+server.ts','src/routes/org/[orgId]/api/personnel/[id]/export/server.test.ts']
group('export/cascade',reverse,'d13-artifact-cascade-export-baseline','cascade_cap')
retention=[]
for stem in ['personnelRetention','personnelArtifactRetention']:
 retention +=[f'src/features/personnel/{stem}.server.ts',f'src/features/personnel/{stem}.server.test.ts']
retention += ['src/lib/server/core/useCases/archiveRetention.ts','src/lib/server/core/useCases/archiveRetention.test.ts','src/routes/api/cleanup-archived-records/+server.ts','.agents/skills/verify-trooptotask/helpers/artifact-retention.mjs','.agents/skills/verify-trooptotask/helpers/personnel-retention.mjs','.agents/skills/verify-trooptotask/helpers/control.mjs','scripts/verification/fixtures.mjs']
group('retention',retention,'d13-artifact-retention-repair-small','retention')
group('Note retained owner',['src/features/personnel/leaderNotes.server.ts','src/lib/server/adapters/personnelLeaderNotes.test.ts','src/lib/server/adapters/privateResources.test.ts','src/routes/org/[orgId]/api/personnel/[id]/leader-notes/+server.ts','src/routes/org/[orgId]/api/personnel/[id]/leader-notes/[noteId]/+server.ts'],'d13-artifact-context-review-refresh','context')
retentionMoves=[]
for p in ['src/features/personnel/personnelRetention.server.ts','src/features/personnel/personnelArtifactRetention.server.ts']:
 now=(ROOT/p).read_bytes();old=blob(HISTORY['retention'],p)
 normalized=now.replace(b"from './personnelCounselingRecords.server'",b"from '$lib/server/core/useCases/personnelCounselingRecords'").replace(b"from './personnelDocuments.server'",b"from '$lib/server/core/useCases/personnelDocuments'")
 retentionMoves.append({'path':p,'currentSha256':sha(now),'normalizedSha256':sha(normalized),'acceptedSha256':sha(old),'onlyTwoBucketImportSourcesChanged':normalized==old})
bucketEvidence={}
for current,old,name in [('src/features/personnel/personnelCounselingRecords.server.ts','src/lib/server/core/useCases/personnelCounselingRecords.ts','COUNSELING_RECORDS_BUCKET'),('src/features/personnel/personnelDocuments.server.ts','src/lib/server/core/useCases/personnelDocuments.ts','PERSONNEL_DOCUMENTS_BUCKET')]:
 pattern=rf'export const {name} = ([^;]+);'
 a=re.search(pattern,(ROOT/current).read_text()).group(1);b=re.search(pattern,blob(BASE,old).decode()).group(1)
 bucketEvidence[name]={'currentPath':current,'priorPath':old,'currentExpression':a,'priorExpression':b,'sameExpression':a==b}
contextpaths=['src/features/personnel/components/PersonnelDetailPageView.svelte','src/features/personnel/components/PersonnelDetailContent.svelte','src/routes/org/[orgId]/personnel/[personnelSlug]/+page.svelte','src/features/personnel/workspace/personnelDetailWorkspace.svelte.ts','src/features/personnel/workspace/personnelArtifactDraftSpecs.ts']
contextpaths += [f'src/features/personnel/components/Personnel{stem}PageView.svelte' for stem in ['Notes','FollowUps','Counselings','Documents','ArchivedArtifacts']]
contextpaths += [f'src/routes/org/[orgId]/personnel/[personnelSlug]/{stem}/+page.svelte' for stem in ['notes','follow-ups','counselings','documents','archived']]
group('context/client/runtime',contextpaths,'d13-artifact-context-review-refresh','context')
archiveComparison=[]
for name in ['d13-artifact-retention-repair-small','d13-artifact-retention-repair-large']:
 manifest=archives[name]['frozenInputs']
 for entry in selected:
  if entry['group']!='retention' or entry['path'] not in manifest:continue
  archived=manifest[entry['path']];normalized=next((x['normalizedSha256'] for x in retentionMoves if x['path']==entry['path']),entry['currentSha256'])
  archiveComparison.append({'archive':name,'path':entry['path'],'frozenInputSha256':archived,'currentSha256':entry['currentSha256'],'literalIdentical':archived==entry['currentSha256'],'identicalAfterOnlyBucketImportSourceNormalization':archived==normalized})
check=ROOT/'.verification/evidence/verify-trooptotask/d13-artifact-server-integration-checks'
clients=[]
for record in json.loads((check/'integrated-client-type-only-provenance.json').read_text()):
 p=record['path'];now=(ROOT/p).read_bytes();old=blob(BASE,p)
 def normalize(data):return re.sub(r'\s','',re.sub(r'import\s+type\s+[\s\S]*?;','',data.decode()))
 clients.append({'path':p,'baseSha256':sha(old),'currentSha256':sha(now),'onlyTypeImportsAndWhitespaceChanged':normalize(old)==normalize(now),'recordedCurrentHashMatches':sha(now)==record['currentSha256']})
result=json.loads((check/'integrated-focused-results.json').read_text())
focused=[]
for case in result['testResults']:
 p=str(Path(case['name']).relative_to(ROOT));focused.append({'path':p,'currentSha256':sha((ROOT/p).read_bytes()),'status':case['status'],'assertions':len(case['assertionResults']),'allAssertionsPassed':all(a['status']=='passed' for a in case['assertionResults'])})
focusedProvenance={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in check.iterdir() if p.is_file() and p.suffix in ['.json','.exit']}
handoff=json.loads(Path('/home/waffleflops/.cache/t2t-d13-server-cut-receipts/changed-paths.json').read_text())
cut=[]
for row in handoff['entries']:
 p=row['path'];present=(ROOT/p).is_file();h=sha((ROOT/p).read_bytes()) if present else None
 cut.append({'path':p,'status':row['status'],'preparedSha256':row.get('sha256'),'currentSha256':h,'identicalToIsolatedPreparation':h==row.get('sha256') if row['status']!='D' else not present})
changedNow=git('diff','--name-status',BASE).decode().splitlines()
untracked=git('ls-files','--others','--exclude-standard').decode().splitlines()
receipt={'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(ROOT),'rootHeadAtStart':git('rev-parse','HEAD').decode().strip(),'base':BASE,'status':'READ_ONLY_SOURCE_EQUIVALENCE_COMPLETE; FINAL_NATIVE_PROVIDER_ACCEPTANCE_PENDING_PARENT','method':'SHA-256 of actual current bytes vs accepted commit blobs and archive frozen manifests; all archive payload inventories checked in memory. Existing focused results inspected, not rerun. No services, browser, source/Git mutations.','acceptedCommits':HISTORY,'historicalArchives':[{k:v for k,v in e.items() if k not in ['frozenInputs','freshCopiedInputs','preparedInputs']} for e in archives.values()],'sqlInputs':sql,'copiedCapInputs':capcopy,'selectedReverseInputs':selected,'retentionBucketImports':retentionMoves,'bucketValueEvidence':bucketEvidence,'retentionSmallLargeManifestComparison':archiveComparison,'clientTypeOnlyComparison':clients,'focusedRun':{'recordedSuites':len(focused),'recordedTests':result['numTotalTests'],'recordedPassed':result['numPassedTests'],'success':result['success'],'independentlyRerun':False,'recordFiles':focusedProvenance,'tests':focused},'isolatedPreparedCut':{'base':handoff['base'],'patchSha256':sha(Path('/home/waffleflops/.cache/t2t-d13-server-cut-receipts/d13-server-artifacts-ownership.patch').read_bytes()),'paths':cut},'currentTrackedDiff':changedNow,'currentAddedPaths':untracked,'limits':['Current D13 working diff has no migration. Incoming D15 migration/runner/SQL additions are already on base main and are not byte-identical to the historical159-migration cap replay. No current160-chain fresh/upgrade replay claim.','Historical SQL cap receipt proves real PostgreSQL metadata contention only, not ordinary multipart Storage compensation, HTTP status, native UI or RLS admission.','All37/382 focused receipts support lower-level changed delivery/owned-operation and unchanged reverse-consumer checks. Finite real-SDK intercept faults are not live provider outages or real SQL/RLS proof.','Fresh current actor configure-read vs operate-write, context binding, four-family native lifecycles, real-file/native Open and affected ordinary HTTP proof remain parent-owned pending final acceptance; no new live claim here.','Reverse source byte equivalence permits only the behavior actually observed in each accepted historical packet. Retention imports changed with identical bucket expressions; writer contracts/public delivery/context have moved, and focused tests do not make fresh live acceptance unnecessary.','Whole repository CI/build/bot/independent packaged artifact acceptance and final issue closure are outside this read-only receipt.']}
active=ROOT/'.verification/evidence/verify-trooptotask/d13-artifact-server-final-native/frozen-inputs.sha256'
if active.is_file():
 activeBytes=active.read_bytes();activeInputs=hashes(activeBytes)
 checked={r['path']:r['currentSha256'] for r in sql+selected+clients+focused+cut if r.get('currentSha256')}
 receipt['activeFrozenManifestComparison']={'path':str(active.relative_to(ROOT)),'sha256':sha(activeBytes),'manifestInputs':len(activeInputs),'comparedCurrentInputs':len(checked),'allComparedInputsMatch':all(activeInputs.get(p)==h for p,h in checked.items()),'mismatchedOrMissingPaths':[p for p,h in checked.items() if activeInputs.get(p)!=h],'scope':'Source-input binding only. Active owned run was not observed or driven here; no live outcome credit.'}
receipt['rootHeadAtEnd']=git('rev-parse','HEAD').decode().strip()
receipt['recordedInputsUnchangedAtEnd']=all(sha((ROOT/r['path']).read_bytes())==r['currentSha256'] for r in sql+selected+clients+focused+cut if r.get('currentSha256'))
assert receipt['recordedInputsUnchangedAtEnd']
(OUT/'comparison.json').write_text(json.dumps(receipt,indent=2)+'\n')
inputs={r['path']:r['currentSha256'] for r in sql+selected+clients+focused+cut if r.get('currentSha256')}
(OUT/'current-inputs.sha256').write_text(''.join(f'{h}  {p}\n' for p,h in sorted(inputs.items())))
print(json.dumps({'head':receipt['rootHeadAtStart'],'archivesVerified':len(archives),'archivePayloadsVerified':sum(e['payloadFiles'] for e in archives.values()),'oldMigrations':sum(x['path'].startswith('supabase/migrations/') and x['acceptedCommitSha256'] is not None for x in sql),'sqlChanged':[{k:r[k] for k in ['path','classification']} for r in sql if r['classification']!='identical'],'selectedChanged':[r['path'] for r in selected if not r['commitIdentical']],'retentionImportOnly':all(r['onlyTwoBucketImportSourcesChanged'] for r in retentionMoves),'clientTypeOnly':all(r['onlyTypeImportsAndWhitespaceChanged'] for r in clients),'focused':{'suites':len(focused),'tests':result['numTotalTests'],'passed':result['numPassedTests']},'cutDifferent':[r['path'] for r in cut if not r['identicalToIsolatedPreparation']],'copiedCapMatch':all(r['identical'] for r in capcopy),'receiptSha256':sha((OUT/'comparison.json').read_bytes()),'currentInputs':len(inputs)},indent=2))
