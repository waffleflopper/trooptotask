from pathlib import Path
import subprocess,json,hashlib,tarfile
w=Path('/home/waffleflops/.cache/t2t-1360-personnel-detail');p=w/'.verification/evidence/personnel-detail-integration-checks';head='a200c7b8936b2abcb4105cbebd4ad7789e8e6413';base='e674edcf0204e9a4e2e15a19d747cdd33c33a47c';pre='34f3abe4be37e9fe1bf06bc3742b90b15b770ebe';checks=[]
def ck(n,v):checks.append({'observation':n,'pass':bool(v)});assert v,n
def blob(ref,n):
 r=subprocess.run(['git','show',ref+':'+n],cwd=w,capture_output=True);return r.stdout if r.returncode==0 else None
d=json.loads((p/'source-byte-applicability.json').read_text());ck('46 comparisons',len(d['comparisons'])==46)
for r in d['comparisons']:
 ref=r.get('reference',pre if r['owner']=='detail' else base);before=blob(ref,r['file']);after=blob(head,r['file']);sha=lambda b:'ABSENT' if b is None else hashlib.sha256(b).hexdigest();ck('source before/current identical '+r['file'],before==after and sha(before)==r['beforeSHA256'] and sha(after)==r['afterSHA256'])
patch=subprocess.check_output(['git','diff',base+'..'+head],cwd=w);ck('full actual33 source patch equals raw transcript',patch==(p/'post-diff.stdout').read_bytes());ck('exact tested source patch8fa54',hashlib.sha256(patch).hexdigest()=='8fa54f271af3900a906890ff952de382849155182807d766e5a7c52c0f8b1e77')
ck('merge additive5file resolution patch exact',subprocess.check_output(['git','diff',pre+'..'+head,'--',*d['sharedAdditiveResolution']],cwd=w)==(p/'merge-shared-resolution.patch').read_bytes())
for n in ['focused','types','governance','format','lint','candidate-digest','final-diff-check']:
 c=json.loads((p/(n+'.command.json')).read_text());ck(n+' exact candidate exit0',c['revision']==head and c['exit']==0 and c['patchSHA256']=='8fa54f271af3900a906890ff952de382849155182807d766e5a7c52c0f8b1e77')
for n,parts in [('focused',['Test Files  15 passed (15)','Tests  179 passed (179)']),('types',['svelte-check found 0 errors and 0 warnings']),('governance',['590 unresolved findings compared with '+base,'08-M04: 60','Governance regression checks passed','documented feature permission couplings: 0']),('format',['All matched files use Prettier code style!']),('lint',['0 errors, 2 warnings'])]:ck(n+' actual stdout result',all(x in (p/(n+'.stdout')).read_text() for x in parts))
ck('recorded candidate digest68e',(p/'candidate-digest.stdout').read_text().strip()=='68e180a5b122ad08dd2115f90803b808e1c521874a8e7084157c94e730b1a0d2');ck('original merge failure four conflicts preserved',json.loads((p/'merge.command.json').read_text())['exit']==1 and (p/'merge.stdout').read_text().count('CONFLICT (content)')==4)
for n in d['oldGlobalRemovals']:ck('old central pair path absent '+n,blob(head,n) is None)
manifest=json.loads(blob(head,'scripts/module-boundaries.json'));ck('legitimate retained17 literal',manifest['owners']['personnel']['files']==d['remainingHistoricalM04'] and len(d['remainingHistoricalM04'])==17)
for key in ['routeSupabaseAllowlist','routeAdminAllowlist','permissionCouplings']:
 if key in manifest:ck('no new allowance '+key,manifest[key]==json.loads(blob(base,'scripts/module-boundaries.json')).get(key))
r=subprocess.run(['rg','-n','core/useCases/personnel(ExtendedInfo|AwardTracking|ReadinessLanes)|lib/domain/readinessSignals','src'],cwd=w,capture_output=True,text=True);ck('old import reverse paths absent',r.returncode==1 and not r.stdout)
files={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in p.rglob('*') if q.is_file()};ck('raw74payload300145bytes',len(files)==74 and sum((p/n).stat().st_size for n in files)==300145)
archive=w/'docs/stabilization/phase-08/d12-personnel-sds-awards-proof/shared-baseline.tar.gz';ck('baseline archive unchangede9c092',hashlib.sha256(archive.read_bytes()).hexdigest()=='e9c092036b9404dd1ea456e51fb4e8f2fe998d6c4071b1cfc8035b4ed80e62d5');raw=w/'.verification/evidence/verify-trooptotask/personnel-detail-baseline';names=[]
with tarfile.open(archive) as t:
 for m in t.getmembers():
  if not m.isfile() or m.name=='ARTIFACT_SHA256SUMS':continue
  names.append(m.name);ck('original baseline frozen payload '+m.name,t.extractfile(m).read()==(raw/m.name).read_bytes())
ck('original baseline exact1407file set',len(names)==1407 and set(names)=={str(q.relative_to(raw)) for q in raw.rglob('*') if q.is_file()})
result={'result':'STANDARDS_PASS_SCOPED_SOURCE_AND_FINAL_SELECTION_SPEC_PASS','head':head,'base':base,'digest':'68e180a5b122ad08dd2115f90803b808e1c521874a8e7084157c94e730b1a0d2','changedEntries':33,'integrationPacketFiles':files,'checks':checks,'count':len(checks),'findings':[],'priorAcceptance':'34 source/selection and merged287 SDS acceptance carry where byte-equivalent; additive resolved contracts/index/DTO/page imports inspected separately','pending':['Affected integrated actual final native/API journeys and full-row restoration/cleanup/disposal','Final complete packaged expanded artifacts/source/prose and whole-issue acceptance','Exact final candidate full DoD/CI/build and completed clean reviews/authorized merge'],'limits':['No services or live execution in this review','Shared baseline and prior native observations retain original revisions/limits','No independent execution/model diversity claim','Whole #1360 still open']}
out=Path('/home/waffleflops/.cache/t2t-1360-retention-ownership/.verification/personnel-detail-integrated-source-independent.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'allPass':all(c['pass'] for c in checks),'output':str(out)}))
