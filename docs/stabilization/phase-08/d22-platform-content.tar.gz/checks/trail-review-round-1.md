reviewed by claude-opus-5-5 (Claude Opus 5.5, 1M context)

## Audit of `.verification/preparation/decisions.tsv`

I made no edits, started no services and ran nothing that changes state. During the audit the parent committed **`b1e0eb71`** at 02:33:05Z. It contains the docs and archives only; nothing in `src`, `.agents`, `scripts` or `package.json` changed since `8cdb9237`. The working tree is now clean, 4 commits ahead of `origin/main 3de24c86`.

**Confirmed against live state:**
- **Row 1:** CodeRabbit approved head `83a034c8` at 00:43:12Z. Run 37165539200 succeeded with 677 test files passing. "Database contracts" was skipped, which fits a PR with no SQL change. The PR merged as `966f9151` at 00:48:03Z, and the "CI pending, no merge yet" wording was true when written.
- **Row 2:** the merge SHA and PR link resolve.
- **Row 5:** `doctor-before.json` and `doctor-final.json` both record revision `8cdb9237`, digest `0363ece4…`, session `75d8da18` and PASS. `cleanup-final.json` reports PASS. `observations.md` matches the digest and the receipt, including the failed first attempts and every non-claim (controlled-HTTP SDK, display-only Audit, no performance claim, no Toggle atomicity claim, coordinator rather than independent execution).
- **Archives:** all three SHA-256 values match the receipt. The final and provider archives hold 488 and 3 payloads, with 4 PNGs in the final one. The expanded directories match `inventory.json` with no mismatches and no extra files.
- **Receipt numbers:** governance shows 327 findings including 12 under M12, lint shows 3 inherited warnings, types are 0/0, helpers pass 18/18, format passes, and there is no SQL diff from `origin/main`.

## Attention

1. **Row 4 credits tests to a commit they didn't run on.** The row pairs `cd2a47ba` with "Focused472 tests pass", but that run (`content-integrated-focused-final.log`, started 01:24:52Z) used an uncommitted working tree. That tree predates the `origin/main`/D24 merge `33ad169f` (01:26:15Z) and `8cdb9237` (01:31:41Z), and contains UI work that isn't in `cd2a47ba`. No check log records a revision or tree hash. The receipt and the archive's `checks/` folder still present 472 as "focused final verification" of the frozen candidate. Treat the local 472 result as unpinned; exact-head CI is the real proof.

2. **Row 3's 26 UI tests ran before an edit to the same test file.** `content-ui-final.log` started 01:27:22Z. Types then failed on `contentForms.svelte.test.ts:56` at 01:27:45Z (`content-types-final.log`) and passed at 01:28:42Z after a fixture fix. The fix is probably type-only, but the 26-test log isn't byte-tied to the committed file.

3. **An unexplained test failure is missing from the trail.** At 01:24:26Z, `content-integrated-focused.log` shows 1 failure out of 306 tests (33 files): "Feedback editor ownership › retires the editor through the visible tab interaction while retaining its pending write". 26 seconds later the "final" run passes 472 tests across 47 files. Nothing records whether this was a fix, a flake or a different test selection. It's a lifetime/race test, so flakiness matters here.

4. **The independent pre-freeze source review isn't in the log.** The receipt says that review accepted `8cdb9237` after three corrections (5xx certainty, fixture types, deleted-file governance/doc references). There is no row and no pointer to a review artifact. Because the timing isn't recorded, I can't tell whether the 472-test and 26-test runs came before or after the 5xx-certainty fix.

5. **Several decisions that shaped the work have no row:**
   - **Provider SDK baseline (~00:55Z):** three iterations. The first run timed out at 5s; the probe was then corrected and later reformatted. `observations.md` admits the archived probe "was formatted later", so its archived bytes aren't the bytes that ran.
   - **Merge of `origin/main` including the unrelated D24 commit `3de24c86`:** a fork with no row.
   - **Aborted launch before the commit:** an earlier candidate `b1805687` appears in `content-verify-info.json`, and `content-native-tools.json` shows BLOCKED/NOT_LAUNCHED at 01:30Z.
   - **Browser pivot:** the baseline log's environment row ended on "pinned native Chrome installed". The final run used the system `/usr/bin/chromium` with `provisioned:false`, even though that same row recorded system Chromium crashing earlier.
   - **Commit `b1e0eb71`:** not logged, and its commit message has a subject only.

6. **Timing and durability of the log:**
   - Rows 2–4 all carry the same timestamp, 01:31:09Z. They were written up to 43 minutes after the events, so they are not contemporaneous.
   - Row 5's evidence paths are bare relative names that resolve only under the ignored `.verification/evidence/verify-trooptotask/d22-content-final/`. The durable pointer would be the archive name plus its hash.
   - The log is frozen at 5 rows inside `d22-platform-content.tar.gz`. Rows appended later won't reach the committed evidence unless it is re-archived.

7. **The committed receipt still makes a promise it hasn't kept.** It says "complete changed-file count and actual review scope will be recorded after packaging", but `b1e0eb71` was committed after packaging without that information. Fill it in or remove it before handoff.

8. **Some coverage is inherited, not re-proved.** The layout and admission change affects every admin page. For search, User/Organization detail, review and suspension, the final run proves only native support search/detail plus the HTTP seven-page admission matrix; the rest relies on D21's earlier evidence. The receipt labels this honestly, but it is still a gap in fresh proof.

9. **Gates still open, all correctly labeled as pending:**
   - complete independent acceptance of the source and expanded artifacts
   - a CodeRabbit review of the full intended diff
   - exact-published-head full CI
   - the PR itself, which doesn't exist yet

   Neither the log nor the receipt overclaims these. Merge and `Closes #1370` must wait for all of them.
