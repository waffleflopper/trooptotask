import json,hashlib,subprocess,pathlib
P=pathlib.Path(__file__).parent; R=pathlib.Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
entry=json.loads((P/'entry-inventory.json').read_text());run=lambda c:subprocess.run(c,cwd=R,text=True,capture_output=True,check=True).stdout
head=run(['git','rev-parse','HEAD']).strip();assert head=='080cc16f63930d9d3bad3b54ffa06561d898e5af'
paths=set(run(['git','diff','--name-only','HEAD']).splitlines())|set(run(['git','ls-files','--others','--exclude-standard']).splitlines());assert paths=={x['path'] for x in entry}
exit=[]
for x in entry:
 b=(R/x['path']).read_bytes();v={'path':x['path'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert v==x;exit.append(v)
(P/'exit-inventory.json').write_text(json.dumps(exit,indent=2)+'\n')
out={'head':head,'branch':run(['git','branch','--show-current']).strip(),'scopePaths':len(paths),'allEntryExitPathsSizesSHA256Exact':True,'sourceTestManifestPaths':27,'parentDocs':4,'archives':3,'entryInventorySHA256':hashlib.sha256((P/'entry-inventory.json').read_bytes()).hexdigest(),'exitInventorySHA256':hashlib.sha256((P/'exit-inventory.json').read_bytes()).hexdigest(),'sourceEditsByReviewer':0,'liveExecutionByReviewer':0}
(P/'scope-exit-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
