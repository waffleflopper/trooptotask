# 1503 final integration v8 smoke report

This file is interpretation. Raw captures live in `.verification/evidence/verify-trooptotask/1503-final-integration-v8/driver/`; see its `INDEX.md`. It does not declare 1503 complete. Root owns integration, cleanup, packaging and the PR.

## Binding

- Candidate `0196ae3f0e438f64565069e6dfc94525a4f1865678b71035fe5a5834a4bcda1d`, revision `c09b6737`, base `6555c3c8`.
- Session `8f3afad2-9a4d-4eb1-9acd-decfee2122a0`, worker 1, origin `http://127.0.0.1:33003`.
- Browser is the owned Chromium 152.0.7977.82 (Arch Linux) private profile.
- I re-hashed the following and each matches:
  - `SOURCE.patch` sha256 `32708d95…49ff07`.
  - The boundary seed sha256 `1fc8ad6f…4995`.
  - `ReportForecastChart.svelte` sha256 `706cd892…7b831`, the same chart bytes as v7.
- Doctor PASS at start (`0001`) and at the end (`0233`). Both report the same candidate.
- Driving ran 2026-10-04 from 02:03 to 02:38 AKDT, with asOf 4 Oct throughout. The app clock was not touched.
- The seed tag is `f0d50bb9` and the dedicated role is `BriefingBoundaryf0d50bb9`. The saved view is `d7aa2da3…` ("Boundary briefing f0d50bb9").
- The 30-day final-bucket witness was still on day 30: expiry 2026-11-02, lapse 2026-11-03, which is the horizon end.
- Authority is Robert's explicit "Use the owned verify:app browser". I used only native `verify:app` tools and the documented helper.
- One sign-in (`actor orgOwner training/reports`, page 2, context `map-orgOwner-39395fed…`) and one native Sign Out. That is one login POST (reqid 63) plus the sign-out.
- This is Linux synthetic-browser proof only. It makes no Mac, HTTPS or T3-browser claim.

## Proof classes

- **Native actions.** Sidebar links, listbox keyboard selection (ArrowDown/Enter), menu checkboxes (Space and click), Escape, horizon and Rows by radios, Clear filters, the hot-spot cell, Export Excel, Toggle theme, Settings goal fill and Save, Account menu › Sign Out.
- **Native navigation.** `reload`, one `navigate_page` to the protected route after Sign Out, and `emulate` for viewport and DPR.
- **Native observation.** `list_network_requests`, `get_network_request` and `list_console_messages`.
- **Read-only evaluation.** `location.href`, listbox option state, chart geometry and fonts (`measure.js`), and storage reads.
- **Direct HTTP.** One same-origin read-only GET of the SPC page HTML from the signed-in page, to show the numbers are in the server HTML.
- **Documented controls.** `network arm-observe … training-reports/export`, `export arm/state/save/restore` and `workbook`. These observe client responses only.
- **Privileged readback.** `rows organizations orgA|orgB`, `rows personnel_trainings orgA|orgB` and `rows training_types orgA`.
- **Storage write.** One `evaluate_script` removed two keys at restore (see Restoration).
- **Source inspection.** The seed definitions in `.verification/1503-boundary-seed.mjs`.

## Outcome 1. Shell, filters, SSR, cell, console: PASS, with one brief expectation corrected

**Shell.** Home, Training, Organization Settings (General) and Training › Reports loaded through visible sidebar links. Every `__data.json` and `app-shell-chrome` request returned 200. No `user-preferences` request occurred, and no new console message appeared across the client navigations.
- Home opened the "What's New" dialog. My first Training click landed on its overlay and only dismissed it, so `png/0012` is still the Dashboard. A second click reached Training.
- The dismissal stored `changelog-last-seen-<user>` in localStorage. No server write was observed. This is expected shell behavior, not a failure.

**SPC (expectation corrected).** The rank listbox options are absent from the snapshot, so I selected SPC with the focused keyboard. The URL became `?rank=SPC` and one `api/training-reports?rank=SPC` GET ran.
- The briefing shows 3 soldiers and **17%** ready: Ready 1, expired 0, not recorded 5, lapse 0.
- The brief expected 25% with 4 applicable, 1 ready and 3 missing. That expectation leaves out a seeded type. `Rounding 11 of 13 f0d50bb9` has `applies_to_mos ["68W"]` and no role restriction (provider readback `0045`, seed source line 80/89). So it also applies to Able (68W) and Unassigned (68W).
- Independent count: Required has 3 applicable and 1 ready, Targeted has 1 and 0, Rounding has 2 and 0. That is 6 applicable and 1 ready, so 17%.
- The grid agrees: Alpha Required 100%, Alpha Targeted 0%, Alpha and Unassigned Rounding 0%, Total Required 33%.
- This is correct product behavior on this fixture. The 25% figure only holds for the unseeded three-Person fixture.

**SSR.** Reloading `?rank=SPC` produced only the document GET (200) and the notification count. There was no initial `api/training-reports` GET. The server HTML already contains "17%" and "3 soldiers" (direct GET, 200).

**Mixed view.** I chose Clear filters, then picked the Boundary view with the keyboard and toggled the dedicated role with Space.
- Each change issued exactly one summary GET.
- The URL became `?view=d7aa2da3…&role=BriefingBoundaryf0d50bb9`.
- The briefing shows 100 soldiers, **74% → 61%**, Ready 752, expired 0, not recorded 261, lapse 139, and "loses 14 points".

**Rows and horizon.** Rows by Duty role and 180 days each issued one GET. The URL gained `&horizon=180&rowsBy=role`.
- Reload restored 180 days and Duty role, with only the document GET and the notification count.
- After reload the briefing read 74%→61% by 2 Apr, 139 lapses, with "DUTY ROLE" row labels.
- I did not separately drive 30 or 90 days in the mixed state here. The final-bucket state below drives 30 days, and the default load showed 90.

**Cell.** The cell "BriefingBoundaryf0d50bb9, At goal 85 f0d50bb9: 85% ready today, drops 10 points by 2 Apr" issued one request: `api/training-reports/detail?…&scope=cell&row=BriefingBoundaryf0d50bb9&type=383063e1…`.
- The response was 200 with `cache-control: private, no-store` and `vary: Cookie`.
- The body has 25 rows (15 Not Done, 10 warning-orange), totalRows 25, page 1, pageSize 25.
- The live status read "25 requirements not ready or lapsing by 2 Apr."
- The page URL did not change and contains no record IDs.

**Console.** The hydrated filtered page after reload logged 8 messages: Vercel insights and speed-insights 404s and MIME refusals, a CSP eval issue, and a CSS preload warning. None came from the app, hydration or preferences. The first post-login page showed the same classes. Messages from earlier full navigations are intrinsically omitted by the tool.

## Outcome 2. Critical chart states on the current build: PASS

**Goal changes.** Goal was changed natively in Settings › Policies (fill, then Save). The sequence was 90 → 85 → 95 → 90. Each step was read back from `rows organizations orgA` as 85, 95 and 90.

**Goal 85, final-bucket witness.** I set Types to "Final bucket fifty f0d50bb9" alone, the dedicated role, the All training view and 30 days. The URL was `?role=…&types=45e358b2…&horizon=30`.
- **Literal facts.**
  - The bottom line reads 100% → 50% BY 3 NOV, Ready 100, Lapse by 3 Nov 50, "loses 50 points in 30 days … between 2 Nov and 3 Nov".
  - The caption reads "2 NOV – 3 NOV · 50 lapse · Final bucket fifty f0d50bb9".
  - The screen-reader table runs 4 Oct 100% through 1 Nov 100%/0/No, then 3 Nov 50%/50/Yes. That matches the receipt's expiry 2026-11-02 and lapse 2026-11-03.
- **1440 light** (`png/0050`).
  - The final turn into 3 Nov is visible and unmasked, and it crosses the dashed goal rule only as data.
  - The red end dot has "50%" 8.4px below it. The "50" bar count sits 10.6px under that.
  - The band's right edge equals the plot edge (`rightVsPlot` 0).
  - "Goal 85%" sits in the right gutter, 13px from the rule end.
  - The start "100%" is 6px from its dot and 7.5px above the 100% gridline.
- **390 dark** (`png/0052`). The geometry is the same: end label 8.4px from its dot and 12.9px from the nearest gridline, goal label 19.6px inside its clip, caption 2 lines and right-aligned.
- Both captures have zero text overlaps and zero rule strikes, and drift is at most 0.1px.

**Goal 95, flat 100 (D4).** Filters were Types "Verification Required Training" and Duty role Medic, at 90 days. The URL was `?role=Medic&types=a6a532c7…`.
- The briefing reads 100% stays at 100%, Ready 1, "Nothing lapses before 2 Jan". The screen-reader table shows 100%/0/No every week through 2 Jan. The legend bands read 95+/85–94/75–84/65–74/<65.
- In both 1440 light and 390 dark, the green end label "100%" sits **2.4px below** the dashed Goal 95% rule. It is unstruck, 11.8px from its end dot and right-aligned under it (`png/0061`, `png/0063` at DPR2).
- "Goal 95%" is in the gutter, and the start "100%" sits above its dot.
- **D4 is resolved on this build.** The v7 note still applies: the goal rule passes between the end label and its dot. At 2x it still reads as the end dot's label. This is not blocking.

**Font.** IBM Plex Mono is loaded at 400 and 600 (`document.fonts.check` true, `fonts.status` loaded). The computed family is `"IBM Plex Mono", monospace`, and the rendered widths equal Plex canvas widths ("Goal 85%" 52.8px, "100%" 28.8px).

**Paper.** I did not reopen Paper this round. The chart bytes are unchanged from v7, and the v8 brief scopes this run as a freshness check. The v7 Paper relationship stands as recorded: the goal label moves from Paper's in-plot position to the muted right gutter, and the value labels keep Paper's sides, stepping past a rule only when they would cross it.

## Outcome 3. Native Export after mixed filtered reload: PASS

- **Setup.** This was the filtered reload `?view=d7aa2da3…&role=BriefingBoundaryf0d50bb9&horizon=180&rowsBy=role`. I armed `network arm-observe 2 training-reports/export` and `export arm 2`, then made a native click on the visible "Export Excel".
- **Response.** One GET `api/training-reports/export?view=…&role=…&horizon=180&rowsBy=role` returned 200 with `Content-Disposition: attachment; filename="training-report-2026-10-04.xlsx"` and the spreadsheetml type. The Blob was 12,254 bytes, sha256 `b4f463675c8ddb810c2d0f2fe244c36c81339bd25e877568e358f46c7155b69e`.
- **Sheet and headers.** The sheet is "Training Report". The headers are Name, Rank, MOS, Duty Role, Group plus the **12** saved-view columns (At goal 85 … Not applicable).
- **Rows.** There are **100** Person rows, all `BriefingBoundaryf0d50bb9`. No original or foreign Person appears.
- **Status labels.** 1,200 cells in total:
  - **613** `Current (2027-10-05)`.
  - **139** `10d left (2026-10-14)`.
  - **261** Not Done.
  - **187** N/A.
- This matches the briefing: 752 ready = 613 + 139, 261 not recorded and 139 lapses. Both controls were restored, and `network state` shows armed false.

## Restoration and state left for root

- **Goal.** Restored to 90 visibly and read back. The final `rows organizations orgA` and `orgB` are byte-identical (parsed JSON equal) to root's originals.
- **Training rows.** `personnel_trainings` OrgA `trainingCurrent` and OrgB are identical to root's originals. I wrote no training rows.
- **Theme.** Toggled natively light → dark → light → dark → light.
- **Storage.** The original storage had no `theme` key and `mode-watcher-mode` set to `system`. At restore I removed `theme`, which had been originally absent.
  - I also removed `changelog-last-seen-66bba05f…` (value `2026-09-26-foundation-and-fixes`). The dismissal of What's New wrote it. That the dialog appeared on first Home load shows it was absent or stale before. I did not capture storage before visiting Home, so its exact prior value is unknown.
  - The final keys are `mode-watcher-theme` and `mode-watcher-mode`, with `data-theme` light.
- **Viewport.** Emulation cleared (`viewport ""`, `colorScheme auto`) and the window resized to 1905×2053 at DPR 1, matching the original read.
- **Controls.** `network state` armed false and `export state` captured false.
- **Session.** Account menu › Sign Out landed on `/`. Navigating to the protected Reports URL ended at `/auth/login`.
- **Left running.** Final doctor PASS. Worker 1, the seed journal and its rows are left running for root's guarded comparison, `clean-seeds`, exact-ID absence and worker cleanup. I ran no cleanup, restart or launch.

## Failures, limitations and unrun paths

- **Non-zero receipt.** `0040-wait-spc` exit 2 timed out waiting for "25%", the brief's incorrect expectation (see Outcome 1).
- **Miss-click.** The first Training click was absorbed by the What's New overlay.
- **No-match.** One Clear-filters lookup found no button because the freshly opened report was unfiltered, so nothing was clicked.
- **Not rerun this round.** The 684-state sweep, 1024 width, the extreme goals 1/100, the hold/503/Retry D1 flow, focus-visible, export failure, live fallback-font rendering, stale-reply race, scoped and foreign actors, a real screen reader and Paper. v7 evidence on the same chart bytes and the older V3 supplements remain the qualified proof for those.
- **No current complete branch review.** The non-visual source review for this merge is still in progress with root, so this smoke is not complete branch acceptance.
- **Edits.** No source, helper, recipe, fixture or Paper edits. Driver files exist only in this run's driver directory.

## Verdict

The shell and preferences integration, the retained Training input/API, the SSR first paint, cell detail and native Export all pass on the merged candidate. D3 (goal 85, final 30-day bucket) still holds and D4 (goal 95, flat 100) is still resolved. One brief expectation was wrong: SPC is 17%, not 25%, because the seeded 68W-targeted type also applies to two original People. This is not a product defect. No new product failure was observed.
