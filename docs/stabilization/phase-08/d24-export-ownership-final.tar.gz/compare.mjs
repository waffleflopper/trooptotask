import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import ExcelJS from 'exceljs';

const root = path.dirname(new URL(import.meta.url).pathname);
const read = (name) => JSON.parse(fs.readFileSync(path.join(root, name), 'utf8'));
const inventory = read('section-inventory.json');
const lifecycle = read('lifecycle-reloaded.json').rows;
const actor = read('owner-actor.json');
const observations = [];
let jsonFields = 0;
let workbookFields = 0;
let unchangedCollections = 0;
const mutable = new Set(['audit_logs', 'data_exports', 'notifications', 'beta_feedback']);

for (const section of inventory) {
	for (const org of ['orgA', 'orgB']) {
		const before = read(`before-${org}-${section.table}.json`).rows;
		const after = read(`after-${org}-${section.table}.json`).rows;
		if (!mutable.has(section.table)) {
			assert.deepEqual(after, before, `${org} ${section.table} remains unchanged`);
			unchangedCollections += 1;
		}
	}
}

function saved(section, row, ownRecord) {
	const source = read(`after-orgA-${section.table}.json`).rows.find((fact) => fact.id === row.id);
	assert.ok(source, `${section.key} row ${row.id} has a stored A source`);
	return section.key === 'dataExports' && row.id === ownRecord.id
		? { ...source, status: 'processing', completed_at: null, file_size_bytes: null }
		: source;
}

function checkRow(section, row, ownRecord, sheet = false) {
	const source = saved(section, row, ownRecord);
	for (const [key, expected] of Object.entries(source)) {
		assert.ok(key in row, `${section.key} retains ${key}`);
		const actual = row[key];
		if (sheet && expected !== null && typeof expected === 'object') {
			assert.deepEqual(JSON.parse(actual), expected, `${section.key} ${key} structured value`);
		} else if (sheet && expected === '') {
			assert.equal(actual ?? '', '', `${section.key} ${row.id} ${key} blank cell`);
		} else {
			assert.deepEqual(actual ?? null, expected ?? null, `${section.key} ${row.id} ${key}`);
		}
		if (sheet) workbookFields += 1;
		else jsonFields += 1;
	}
}

const headers = { 'Duty Role': 'clinic_role', 'PCS / DEROS': 'deros', ETS: 'ets' };
const field = (header) => headers[header] ?? String(header).toLowerCase().replaceAll(' ', '_');

for (const stem of ['owner-initial', 'owner-feedback']) {
	const json = read(`${stem}.json`);
	const jsonBytes = fs.statSync(path.join(root, `${stem}.json`)).size;
	const jsonRecord = lifecycle.find((row) => row.file_size_bytes === jsonBytes);
	assert.ok(jsonRecord, `${stem} JSON size matches stored lifecycle`);
	assert.equal(jsonRecord.requested_by, read('feedback-stored.json').rows[0].user_id);
	assert.equal(jsonRecord.status, 'completed');
	assert.ok(Date.parse(jsonRecord.completed_at) >= Date.parse(jsonRecord.created_at));
	assert.equal(json.organizationId, actor.orgId);
	assert.equal(Object.keys(json.sections).length, 38);
	assert.equal(json.sectionInventory.length, 38);
	assert.equal(json.sections.personnel.length, 1008);
	for (const section of inventory) {
		const rows = json.sections[section.key];
		assert.deepEqual(json[section.key], rows, `${section.key} top-level mirror`);
		assert.equal(json.sectionInventory.find((entry) => entry.key === section.key).rowCount, rows.length);
		const foreign = new Set(read(`after-orgB-${section.table}.json`).rows.map((row) => row.id));
		for (const row of rows) {
			assert.ok(!foreign.has(row.id), `${section.key} excludes foreign source row`);
			checkRow(section, row, jsonRecord);
		}
		if (!mutable.has(section.table)) {
			const source = read(`after-orgA-${section.table}.json`).rows;
			assert.equal(rows.length, source.length, `${section.key} complete source enumeration`);
		}
	}

	const workbook = new ExcelJS.Workbook();
	await workbook.xlsx.readFile(path.join(root, `${stem}.xlsx`));
	assert.equal(workbook.worksheets.length, 57);
	const workbookBytes = fs.statSync(path.join(root, `${stem}.xlsx`)).size;
	const workbookRecord = lifecycle.find((row) => row.file_size_bytes === workbookBytes);
	assert.ok(workbookRecord, `${stem} Excel size matches stored lifecycle`);
	assert.equal(workbookRecord.status, 'completed');
	assert.equal(workbookRecord.requested_by, jsonRecord.requested_by);
	assert.ok(Date.parse(workbookRecord.completed_at) >= Date.parse(workbookRecord.created_at));
	for (const [index, section] of inventory.entries()) {
		const sheet = workbook.worksheets[19 + index];
		const names = sheet.getRow(1).values.slice(1).map(field);
		const rows = [];
		for (let rowIndex = 2; rowIndex <= sheet.rowCount; rowIndex += 1) {
			const cells = sheet.getRow(rowIndex).values;
			rows.push(Object.fromEntries(names.map((key, cellIndex) => [key, cells[cellIndex + 1] ?? null])));
		}
		if (!mutable.has(section.table)) {
			assert.equal(rows.length, json.sections[section.key].length, `${section.key} complete workbook enumeration`);
		}
		const foreign = new Set(read(`after-orgB-${section.table}.json`).rows.map((row) => row.id));
		for (const row of rows) {
			assert.ok(!foreign.has(row.id), `${section.key} workbook excludes foreign source row`);
			checkRow(section, row, workbookRecord, true);
		}
	}
	const personnel = workbook.getWorksheet('Personnel');
	assert.equal(personnel.rowCount - 1, 1008);
	const noteColumn = personnel.getRow(1).values.indexOf('Leader Notes');
	assert.ok(noteColumn > 0);
	for (let rowIndex = 2; rowIndex <= personnel.rowCount; rowIndex += 1) {
		assert.equal(personnel.getRow(rowIndex).getCell(noteColumn).value ?? '', '');
	}
	observations.push({ stem, jsonBytes, workbookBytes, personnelRows: 1008, feedbackRows: json.betaFeedback.length });
}

assert.deepEqual(read('feedback-reloaded.json').rows, read('feedback-stored.json').rows);
const summary = { unchangedCollections, jsonFields, workbookFields, observations };
fs.writeFileSync(path.join(root, 'source-comparison.json'), JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary));
