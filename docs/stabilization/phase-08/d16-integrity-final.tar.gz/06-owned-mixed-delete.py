import importlib.util,json,subprocess
from pathlib import Path
repo=Path.cwd(); e=repo/'.verification/evidence/verify-trooptotask/d16-integrity-final'; session=Path('/home/waffleflops/.local/state/trooptotask-verification/03a73328abf6e511/worker-1')
spec=importlib.util.spec_from_file_location('owned_environment',repo/'scripts/verification/environment.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
status=m.status(session); state,workdir,env=m.owned(session); m.containers(state,workdir,env)
f=json.loads((e/'fixture.json').read_text())['ids']; s=json.loads((e/'seed.json').read_text())['ids']
read=f"SELECT 'personnel' AS table_name,id,to_jsonb(p) AS row_data FROM public.personnel p WHERE organization_id IN ('{f['orgA']}','{f['orgB']}') UNION ALL SELECT 'entry',id,to_jsonb(r) FROM public.rating_scheme_entries r WHERE organization_id IN ('{f['orgA']}','{f['orgB']}')"
sql=f'''BEGIN;
CREATE TEMP TABLE mixed_delete_before AS {read};
CREATE TEMP VIEW mixed_delete_current AS {read};
DO $fn$ DECLARE rejected boolean := false; constraint_name text;
BEGIN
 BEGIN
  DELETE FROM public.personnel WHERE id='{s['officer']}' AND organization_id='{f['orgA']}';
  SET CONSTRAINTS ALL IMMEDIATE;
 EXCEPTION WHEN foreign_key_violation THEN
  GET STACKED DIAGNOSTICS constraint_name = CONSTRAINT_NAME;
  rejected := true;
  RAISE NOTICE 'Mixed legacy local evaluator deletion rejected with 23503 at %', constraint_name;
 END;
 IF NOT rejected THEN RAISE EXCEPTION 'Expected mixed historical links to block local deletion'; END IF;
 IF EXISTS ((SELECT * FROM mixed_delete_current EXCEPT SELECT * FROM mixed_delete_before) UNION ALL (SELECT * FROM mixed_delete_before EXCEPT SELECT * FROM mixed_delete_current)) THEN
  RAISE EXCEPTION 'Rejected deletion changed a saved row';
 END IF;
 RAISE NOTICE 'Both Organizations, every field and rated cascade sentinel are unchanged';
END; $fn$;
ROLLBACK;
'''
(e/'06-mixed-delete.sql').write_text(sql)
r=subprocess.run(['docker','exec','-i','-e','PGPASSWORD=postgres',f"supabase_db_{state['project']}",'psql','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1'],cwd=workdir,env=env,input=sql,capture_output=True,text=True)
(e/'06-mixed-delete-result.txt').write_text(json.dumps(status)+'\n'+r.stdout+r.stderr)
print(r.stdout+r.stderr); raise SystemExit(r.returncode)
