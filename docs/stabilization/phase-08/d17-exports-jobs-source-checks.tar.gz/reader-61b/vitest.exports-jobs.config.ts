import { mergeConfig, defineConfig } from 'vitest/config';
import base from '../vitest.config';
export default mergeConfig(base, defineConfig({ cacheDir: '.verification/vite-exports-jobs-cache', test: { maxWorkers: 2 } }));
