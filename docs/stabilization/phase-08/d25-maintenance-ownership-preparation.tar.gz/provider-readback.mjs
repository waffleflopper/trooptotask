import fs from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createClient } from '@supabase/supabase-js';
import { sessionPath } from '../../../../scripts/verification/core.mjs';

const repository = process.cwd();
const session = sessionPath('1');
const directory = path.dirname(new URL(import.meta.url).pathname);
const [mode, manifestName] = process.argv.slice(2);
const doctor = JSON.parse(execFileSync(process.execPath, ['scripts/verification/cli.mjs', 'doctor'], { cwd: repository, encoding: 'utf8' }));
if (doctor.status !== 'PASS') throw new Error('Owned doctor must pass before readback');
const state = JSON.parse(await fs.readFile(path.join(session, 'session.json'), 'utf8'));
const environment = JSON.parse(await fs.readFile(path.join(session, 'environment.json'), 'utf8'));
const provider = JSON.parse(await fs.readFile(path.join(session, 'provider.json'), 'utf8'));
const endpoint = new URL(provider.API_URL);
if (state.repository !== repository || state.phase !== 'running' || environment.repository !== repository || environment.phase !== 'running' || endpoint.hostname !== '127.0.0.1' || Number(endpoint.port) !== environment.ports['api.port']) throw new Error('Owned provider identity failed');
const fixture = JSON.parse(await fs.readFile(path.join(session, 'fixtures.json'), 'utf8'));
const client = createClient(provider.API_URL, provider.SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const checked = (result) => { if (result.error) throw new Error(result.error.message); return result.data; };
const allowed = new Set(['ict_tasks','assignment_types','personnel_ict_completions','daily_assignments','audit_logs','access_requests','account_setup_links','personnel_onboardings','onboarding_step_progress','personnel','personnel_documents','counseling_records','leader_notes','personnel_follow_ups','rating_scheme_entries']);
const columns = 'id,access_request_id,expires_at,claimed_at,used_at,failed_at,failure_reason,revoked_at,revocation_reason,created_at';
if(mode==='users') {
 const users=[];
 for(let page=1;;page++) {
  const result=await client.auth.admin.listUsers({page,perPage:1000});
  if(result.error) throw new Error(result.error.message);
  users.push(...result.data.users.map(user=>Object.fromEntries(['id','email','aud','role','created_at','updated_at','email_confirmed_at','is_anonymous'].map(key=>[key,user[key]??null]))));
  if(result.data.users.length<1000) break;
 }
 console.log(JSON.stringify({users:users.sort((a,b)=>a.id.localeCompare(b.id))},null,2));process.exit(0);
}

const ledger = JSON.parse(await fs.readFile(path.join(session, 'verify-trooptotask-owned.json'), 'utf8'));
const manifest = manifestName ? JSON.parse(await fs.readFile(path.join(directory, manifestName), 'utf8')) : ledger.seeded.map(({kind,table,organization,ids}) => ({kind,table,organization:organization??null,ids}));
for (const item of manifest) {
 if (!allowed.has(item.table) || !item.ids.every(id => /^[a-f0-9-]{36}$/.test(id)) || (item.organization && !['orgA','orgB'].includes(item.organization))) throw new Error('Target outside journaled synthetic cohort');
}
if (mode === 'manifest') { console.log(JSON.stringify(manifest,null,2)); process.exit(0); }
if (mode === 'legacy-setup-probe') {
 const entries = manifest.filter(item => item.table === 'account_setup_links' && item.kind === 'maintenance-retention-1001');
 if (entries.length !== 1) throw new Error('Large owned setup cohort required');
 const ids = entries[0].ids;
 const expiredIds = [];
 const original = [];
 for(let offset=0;offset<ids.length;offset+=100) {
  const rows=checked(await client.from('account_setup_links').select(columns).in('id',ids.slice(offset,offset+100)));
  original.push(...rows);
  expiredIds.push(...rows.filter(row => !row.claimed_at && !row.used_at && !row.revoked_at && Date.parse(row.expires_at)<=Date.now()).map(row=>row.id));
 }
 if(expiredIds.length !== 1001) throw new Error('Expected exactly 1001 unused expired synthetic links');
 const cutoff=new Date().toISOString();
 const eligible=[];
 for(let offset=0;;offset+=1000) {
  const rows=checked(await client.from('account_setup_links').select('id').lte('expires_at',cutoff).is('claimed_at',null).is('used_at',null).is('revoked_at',null).order('id').range(offset,offset+999));
  eligible.push(...rows.map(row=>row.id));
  if(rows.length<1000) break;
 }
 if(JSON.stringify(eligible.sort())!==JSON.stringify([...expiredIds].sort())) throw new Error('Global cleanup predicate includes non-cohort links');
 const response=await client.from('account_setup_links').update({revoked_at:cutoff,revocation_reason:'cleanup'}).lte('expires_at',cutoff).is('claimed_at',null).is('used_at',null).is('revoked_at',null).select(columns);
 const represented=checked(response).length;
 let count=0;
 for(let offset=0;offset<expiredIds.length;offset+=100) {
  const result=await client.from('account_setup_links').select('id',{head:true,count:'exact'}).in('id',expiredIds.slice(offset,offset+100)).not('revoked_at','is',null);
  if(result.error || result.count===null) throw new Error('Probe count readback failed');
  count+=result.count;
 }
 for(let offset=0;offset<expiredIds.length;offset+=100) checked(await client.from('account_setup_links').update({revoked_at:null,revocation_reason:null}).in('id',expiredIds.slice(offset,offset+100)));
 const restored=[];
 for(let offset=0;offset<ids.length;offset+=100) restored.push(...checked(await client.from('account_setup_links').select(columns).in('id',ids.slice(offset,offset+100))));
 const sorted=rows=>rows.sort((a,b)=>a.id.localeCompare(b.id));
 if(JSON.stringify(sorted(original)) !== JSON.stringify(sorted(restored))) throw new Error('Probe restoration changed exact setup witnesses');
 console.log(JSON.stringify({mode,represented,actualMutatedCount:count,expectedExpired:1001,exactRestoration:true,cutoff},null,2)); process.exit(0);
}
if(mode !== 'readback') throw new Error('Unknown readback mode');
const batches=[];
for(const item of manifest) {
 const rows=[];
 for(let offset=0;offset<item.ids.length;offset+=100) {
  let query=client.from(item.table).select(item.table==='account_setup_links'?columns:'*').in('id',item.ids.slice(offset,offset+100));
  if(item.organization) query=query.eq(item.table==='audit_logs'?'org_id':'organization_id',fixture.ids[item.organization]);
  rows.push(...checked(await query));
 }
 batches.push({...item,count:rows.length,rows:rows.sort((a,b)=>a.id.localeCompare(b.id))});
}
console.log(JSON.stringify({doctor,project:environment.project,batches},null,2));
