import json,sys
page=int(sys.argv[1]); paths=sys.argv[2:]
fn=open('.verification/evidence/verify-trooptotask/1504-baseline-v1/probe.js').read().strip()
print(json.dumps({"pageId":page,"function":"() => ("+fn+")("+json.dumps(paths)+")"}))
