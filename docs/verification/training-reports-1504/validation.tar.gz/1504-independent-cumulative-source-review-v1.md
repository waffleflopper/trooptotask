# Independent cumulative nonvisual source review for Training Reports #1433 / #1501–1504

**Verdict: scoped source/spec/consumer PASS. No actionable source defect or unresolved source requirement gap was found in the pinned cumulative candidate.** This is independent read-only source acceptance before current live proof. It does not certify the final browser journeys, downloaded workbook/PDF, appearance, packaging, restoration, current-head hosted CI, or whole final acceptance.

This reviewer used the supplied portable Poteto reviewer persona and the repository's t2t-engineer and testing contracts. Review was nonvisual: no screenshots or rendered PDFs were judged. No test, gate, browser, service, database, connector, nested worker, source change, Git write, or external write was performed. The sole write is this report. Independent source reasoning is not model diversity or independent live execution. T3 Claude retains visual/layout/design judgment.

## Exact candidate and review boundary

| Binding | Value |
| --- | --- |
| Current main base | `a59c6c92bba242cde37f15a5d59e6d305e5267ac` |
| Reviewed HEAD | `2e3aea52ad01e33e173b769f285b0ab6103547d7` |
| Merge integrating that main | `6e2fa4ccd42dc55526fb17ce179ff3978b8a7ad8` |
| HEAD's sole subsequent commit | `2e3aea52ad01e33e173b769f285b0ab6103547d7`, print-rule comment removal |
| Complete cumulative changed-path census | 137 entries: 47 additions, 86 modifications, 4 deletions |
| Text/source entries | 120, including all four deleted source/test entries |
| Historical binary evidence archives | 17, whole-file bytes/hash checked; no fresh expanded artifact audit |
| Worktree continuity | Every existing changed path equals its pinned HEAD blob; all four deleted paths are absent; actual HEAD equals reviewed HEAD |
| Full binary cumulative diff | 70866018 bytes, SHA-256 `2f6fb57bb47e53e17408cdf392769d1675089ca32f3c1392c250627221062691` |

The diff hash is for the exact read-only command `git -c diff.mnemonicPrefix=false diff --no-ext-diff --no-renames --binary BASE HEAD`, with the revisions above. It is sensitive to the command's diff representation; the per-file blob hashes below are the authoritative byte bindings.

I inspected the complete cumulative text/source changes against current main, current contents of new/replaced executable files, deleted baseline implementation/tests, requirement records, earlier acceptance records and source/control reviews, and direct/reverse consumer context. The 17 tar archives are in the complete census, but their historical image/browser/SQL payloads were not expanded and reaccepted in this round. The #1502 issue specification was read directly from its committed validation archive. Historical acceptance prose is requirements/provenance context, not evidence that this reviewer executed those runs or that those runs occurred on this current HEAD.

Root's `.verification/1504-v2-required-checks.json` records exit 0 for all seven required commands: format, format:check, lint, governance:check, check, test with four workers, and build. Inspected summary logs report 690 test files / 6,879 tests PASS, zero Svelte errors/warnings, and 15 lint warnings with zero lint errors. The expected negative CI revision test prints `fatal: bad revision '1234567890abcdef'` inside the successful test run. These are root's captured results, not independently executed checks. The source verdict is derived from the implementation and meaningful test boundaries, not merely those totals.

## Independently derived expectations

The normative contract is parent #1433 plus its recorded triage amendments, with each child brief taking precedence where specified. The semantic green → amber → red amendment supersedes the parent's old red-only examples. Existing server-calendar behavior and the Critical Tasks goal of 70 remain settled decisions.

| Requirement | Independent expectation used in review | Source conclusion |
| --- | --- | --- |
| #1501 readiness goal | An Organization stores a required integer 1–100, default 90. Blank, null, fractional, string, nonfinite and out-of-range API values fail. Owner/admin settings authority remains ordinary policy/RLS. Changing the goal changes presentation thresholds, not applicability/completion facts. | Strict request parsing, independent section state/save, exact provider acknowledgement, narrow read projection, raw export and SQL contract agree. |
| #1502 ready/applicable | Current, warning-yellow and warning-orange are ready; expired and not recorded are not. Optional types, exempt and N/A pairs never enter the required denominator. Expiration day is still ready; lapse is the following calendar day. | The pure analysis classifies each filtered Soldier/type pair with explicit asOf once, then builds all sections from those entries. |
| Forecast | Start at today's readiness; remove each ready dated requirement once on its first expired day. Points cover today and weekly ends with a short exact final bucket for 30/60/90/180. No renewal or task-completion assumption may increase the forecast. | One first-lapse offset drives the cumulative points and per-bucket bars. Calendar-day helpers preserve leap/month/DST boundaries. |
| Cliff | k = max(1, round(bucket count / 4)); select the earliest maximum consecutive k-bucket lapse sum. Highlight only with at least 5 lapses and exact share at least 40%. At most two leading types may be named only when the fewest such types cover at least 60%. | Exact count comparisons, earliest ties, and dominant-type naming match the rule. |
| Goal bands and drop | At least G is goal; G−10, G−20 and G−30 define descending bands. Horizon tone uses goal / G−20 / below G−20. Classify exact ratios before display rounding. Drop alert requires exact loss of at least 10 points. | Cross-multiplication keeps 84.5% below goal 85 and 9.8-point loss below alert even when displayed rounded. Low-goal legends clip at zero. |
| Rows and totals | Group/MOS/role rows sort by exact horizon readiness, worst first; empty-applicability rows last, then stable names/keys. Total aggregates the filtered population, including Soldiers with no applicable cells. | Grid rows, type cells and Total use the same analyzed requirements/population. Shared UI maps model bands without reclassification. |
| Focus | Build only templated Wave, Standing gap, Row drop candidates; exact ≥1-point recovery, tie order A/B/C then names, overlap exclusion at ≥50% of requirement-pair union, at most three. What-if recovers the candidate's required pairs using the specified full/row denominator. | Model-only candidate construction/scoring/selection is used for rendering and re-derived focus detail. No free-text or AI text path exists. |
| #1503 query/session | Normalize URL view/group/rank and repeated MOS/role/type selections, horizon and rowsBy; preserve view column order; SSR first paint then abortable refresh. Failed refresh keeps the shown briefing and retries the attempted input. Late replies/disposed sessions cannot repaint. | Shared parser/serializer, server normalization, keyed route remount and session request identities agree. No client roster/store fallback remains on Reports. |
| #1504 affected requirements | Cell scope is one selected type and optional row; focus scope is the selected model key under the same filters. Include exactly not-ready-now or horizon-lapsing pairs; not recorded first, then expiration ascending, stable ties. Page 25 or 100. Quiet valid cell is empty, invalid key is concealed 404. | Same pure analysis re-derives scope before ordered slicing; API caps/parses pagination and the table uses server pages without local sorting. |
| Workbook | Exactly Summary, Forecast, Hot spots, Focus, Requirements, in that order. Native figures, filter display labels, all forecast points, grid + Total, model focus sentences/numbers. Requirements is the complete filtered affected set, unpaginated and independent of open detail. | The shared workbook utility receives the server report and full affected rows from one authorized source read. Text remains text cells. |
| Browser print | Visible Print brief invokes window.print; printed filter line comes from the shown normalized report. Scoped print rules hide controls/chrome and target briefing sections. | Button binding, filter source, scoped CSS/data attributes and current shell selectors are present. Actual rendering and appearance remain unaccepted here. |
| Cleanup and retained consumers | Remove only unconsumed legacy report model/calculations/contracts/schema. Preserve filterPersonnel, trainingStatus, cell text/status component, matrix, Personnel/Dashboard/Person export/whole-Organization export/Onboarding semantics. | Actual reverse searches and consumer tracing support the deletion; retained semantics remain separate. |

Literal independent fixture reasoning provides an additional check on the expectations:

- In the maintained three-Soldier scenario, Required applies to all three and Targeted only to Able: four required pairs. Initially one current pair gives 1/4 = 25%; Required Total is 1/3 → 33%, Targeted is 0/1. Optional and foreign facts do not enter either count.
- With Baker Required expired and Able Targeted warning-orange, two pairs are ready: 2/4 = 50% today, one ready pair lapses inside the horizon, so 1/4 = 25% at the horizon and a 25-point loss. Alpha is 2/2 = 100% today and 1/2 = 50% later.
- Type risk therefore orders Required (2 not ready + 0 lapsing) before Targeted (0 not ready + 1 lapsing), on one shared maximum of 2. The unfiltered affected list is exactly Unassigned Required not recorded, Baker Required expired, Able Targeted lapsing; Able Required, Optional and N/A pairs are absent. Alpha-filtered Requirements contains only Able Targeted. Opening Required Total does not narrow the exported list.
- The separate pure-model fixture with 9 applicable pairs, 7 ready and 2 future lapses gives rounded 78% today, 56% later and rounded 22-point loss from the exact count loss. The server fixture with 6 applicable, 4 ready and 2 horizon-ready gives 67%, 33% and a 33-point loss. Those literal count expectations are distinct from comparing one implementation helper with itself.
- A zero-Soldier export still has five sheets: zero literal counts and blank readiness percentages in Summary, empty-scope Forecast and Hot spots Total, the Focus empty message, and Requirements headers with zero data rows. The corrected maintained recipe now states this behavior.

## Source, authorization and performance trace

`src/features/training/server/trainingReportsQuery.server.ts:55` admits Training view before its seven independent source reads at line 63. The report roster still uses the narrow Training-authorized Personnel roster port; it does not require an unrelated Personnel lane or perform an unrestricted Personnel fallback. The ordinary request completion/type/view/catalog stores retain organization/RLS bounds. The Organization dependency reads only the public name and readiness-goal projection for the requested Organization. A missing Organization fails closed. No settings administration authority is granted to a Training reader.

Summary output contains briefing/display metadata, not raw roster rows, completion notes, certificates or arbitrary record IDs. The three retained API paths keep `training.viewRecords`, private/no-store and Cookie variation. Detail re-derives the cell/focus at lines 164–177 before slicing; a supplied focus key cannot act as a record selector. Export at lines 181–194 loads once, builds the normalized report and complete affected set, and writes through the shared workbook utility. It neither accepts nor consults active detail page/scope. Shared workbook string values are native text rather than formula objects.

`trainingBriefing.ts:219` computes pair status once per analysis and uses maps rather than repeated record lookup per forecast date. Forecast subtraction does not repeatedly reclassify every pair at every week. At most 26 weekly buckets exist at the permitted horizon. Required model/row/focus work remains in memory and the response is bounded display data. Initial Reports SSR skips the matrix workspace bootstrap, eliminating redundant full roster/type/completion hydration and the former client rebuild. Later refreshes use one summary request; detail uses one scoped request. Export performs one provider-read batch; it repeats pure analysis for summary and affected rows, which is bounded repeated CPU work without a provider/request waterfall. No cross-request cache, persistent brief storage or new generalized abstraction was added.

The report session has independent report/detail abort controllers and request identities. It guards settlement even if a transport ignores abort, restores the shown controls after failure, preserves a loaded same-scope detail page and its range while the next page loads/fails, retries the attempted page, and resets page to 1 for a changed size. Report changes clear old detail. Dispose invalidates both continuations. The keyed route destroys the old session when new server data arrives. Export URLs come from `report.input`, so a pending draft filter cannot silently export a different filter from the displayed briefing.

This is a source/performance assessment, not a measured throughput or latency claim. Real provider volume, browser responsiveness and stale-response behavior still require the current live proof.

## Current-main integration and retained consumers

The merge at `6e2fa4c` has main `a59c6c92bba242cde37f15a5d59e6d305e5267ac` as its second parent. The current Reports route uses `getAppShellContext` and its live org ID; it does not restore the retired org-context API or store-hydration fallback. The layout still calls current `streamReadyFeatureLaneWorkspace`, keeps both org/training dependencies and ready-shell admission, and skips only the Reports matrix workspace. The new layout test imports the moved current-main `../appShell.test-support` file. Other Training routes retain the main workspace delivery. No new admission exemption or shared shell rewrite was introduced.

Shared changes preserve existing defaults: readiness-band's default ramp palette and Critical Tasks thresholds remain; Training uses the optional semantic palette and model-provided tiers. ReportWorkspace.Section retains its default card path. Toolbar wrapping is opt-in, accessible action names improve the existing boundary, and single-choice ToggleGroup ignores deselection. ReportForecastChart is the existing slice-1503 shared report-chart addition; #1504 adds no independent Type-risk chart abstraction.

The actual reverse-consumer search found no production/current-document consumers of the removed screen model, pivot/dashboard APIs, old report DTOs/input schema or TRAINING_NON_COMPLIANCE. Four source/test paths are deleted and the remaining barrels point to the briefing contract. Historical acceptance documents may name retired symbols as provenance.

| Retained consumer | Checked behavior |
| --- | --- |
| Training matrix/forms and Person statistics | Existing trainingStatus omitted-asOf behavior, applicability, exemption, optional visibility and status labels remain. The only status API addition is optional explicit asOf. |
| Personnel readiness card | Its separate due/missing/overdue classifications and capability boundary remain in personnelTrainingReadiness; it is not replaced by briefing percentages. |
| Dashboard | Distinct expired/warning Soldier currency projection remains; the new report's 50% fixture does not impose a Dashboard percentage. |
| Person Export records | The existing Training Records sheet still carries raw completion, expiration and Notes under its original authority; the five-sheet report export does not replace it. |
| Whole-Organization JSON/Excel export | Raw Training records/views and lifecycle remain; the raw Organization profile intentionally adds the readiness goal as field twelve. |
| Onboarding Training references | Completion existence still marks the step, including expired completion; currency is not substituted. |
| Critical Tasks | Existing 70 goal and readiness rollup/ramp threshold meaning remain; the shared rollup header now describes its actual retained consumer. |

The old TRAINING_ROLLUP temporary configuration is gone with the legacy report calculation path, as #1504 explicitly authorizes. The #1501 ready-state rule remains implemented in the new pure model, so absence of that intermediate symbol is not a requirement gap. Existing server-calendar acceptance remains settled; no new Organization timezone requirement was inferred. The stale headers-only empty-workbook recipe from the earlier source review is corrected. The obsolete AppShell test-support import encountered during integration is absent in this pinned source.

## Migration continuity

Only one migration differs from current main: the addition `20261004100618_training_readiness_goal.sql`. Its 484 bytes remain SHA-256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`, matching the previously accepted goal migration after its chronological rename. No existing main migration is rewritten.

The SQL adds a required smallint with default 90 and a named 1–100 check, without an RLS/policy change. It follows main's `20261004000100` progress-scope and `20261004000200` Critical Tasks retention migrations. CI includes the held goal migration plus before/after and fresh contracts. Old Organization snapshots subtract only this one separately asserted added field; no general unknown-column mask weakens predecessor ID/value comparisons. The goal contract checks default/type/null/range, old witness preservation, ordinary member/foreign denial and owner/admin success with exact A/B final values.

No SQL was executed here. The committed #1503 acceptance records retain their historical isolated fresh/populated proof and distinct cleanup qualifications. Current source continuity does not establish a new replay, remote application or release readiness. No remote/development database action is authorized or claimed by this report.

## Print-control source continuity

All seven print-control files at this HEAD have exactly the hashes accepted in `.verification/1504-independent-print-control-review-v2.md`. I checked the actual cumulative control integration, its direct daemon/core/browser/helper context, and installed `chrome-devtools-mcp` 1.10.1 source assumptions. This adds source continuity across the main merge; it does not relabel runtime UNRUN as PASS.

The daemon launches its owned private profile with the supported chromeArg array carrying `--remote-debugging-port=0`. Installed BrowserManager forwards those args even with pipe true; the launcher refrains from adding a debugging pipe when an explicit remote-debugging argument exists, and chooses transport from actual launch args. Installed response formatting supplies `structuredContent.pages` entries with numeric native ID and exact URL. Static support is therefore grounded in actual installed transport/schema rather than human-readable page text.

Capture retains recorded supervisor/MCP/browser PID-start-full-command identity, exact private canonical profile, derived loopback endpoint and socket-listener ownership. It requires the requested native page ID to map to exactly one exact full admitted report URL and separately requires a single live page at that URL. Repeated document checks cover complete ready state, URL, time origin, closure and main-frame navigation. Foreign URLs, duplicate exact URLs, changed/reloaded documents and mismatched page mappings fail closed. Callers cannot inject endpoint, script, media or PDF format options.

Protocol/font/stream work uses the capture clock; PDF bytes are bounded to 20 MiB and validated for header/EOF. Static traversal/symlink/existing-file rejection, exclusive mode-0600 partial, no-overwrite hard link and owned cleanup remain. The accepted P2 publication race is resolved: pinned parent identity is revalidated after the awaited document check and after link settlement, and the actual final file must match the operation's partial inode before success. Relocation/replacement tests exercise actual moves, preserved literal replacement bytes and cleanup of owned partial/published links.

The temporary session/client detaches/disconnects without closing the native page/browser. Late protocol settlement cannot resume the main capture continuation and publish after rejection. Publication awaits the filesystem link directly, then checks parent/final identity and deadline before acceptance. Unchanged local filesystem metadata/link/unlink operations are not independently cancellable/timeboxed; a hung filesystem is not proven to obey the nominal protocol deadline. This previously documented limitation is not a new concrete source regression.

The print observer merely attaches fixed beforeprint/afterprint event listeners; it neither invokes nor replaces window.print. PDF capture itself also emits print events. The native button receipt and observer state must therefore be preserved before capture, and PDF bytes alone cannot prove the button action.

**Current native runtime support remains UNRUN in this lane.** Root still owns actual port/profile/listener proof, native page-ID/exact-URL routing, live rejection cases, page usability after detachment, and pre-capture native Print brief click/events. T3 Claude owns printed/screen appearance. No system dialog, physical printer or native rendering outcome is certified here.

## Test adequacy and findings

**No P0/P1/P2/P3 source finding is raised.** There is no falsifiable residual failure requiring a code correction within this reviewed boundary.

The retained/additional tests predominantly prove independently specified behavior at cheap stable boundaries:

- Pure model tests use literal counts/dates for status inclusion, first-expired-day boundaries, horizons/short buckets, leap/month/DST behavior, exact 40%/60%/20%/10-point comparisons, rounded-display disagreements, earliest ties, deterministic sorting, all Focus templates, 1-point cutoff, overlap, cap, and what-if values. The clock-parity comparison against future getTrainingStatus is a useful additional invariant, supplemented by literal expected outcomes and separately built renewal fixtures; it is not the sole oracle.
- Server/API tests parse real generated workbook bytes and inspect exactly five sheet names, Summary/Forecast/Hot spots/Focus values, ordered affected rows, string labels, canonical filters, full >25-row export, and independence from open detail. Scoped Training-only access, denied capability, unknown scope and no-store boundaries retain focused coverage.
- Session tests deliberately settle deferred replies out of order, including ignored abort and dispose, and assert the actual shown report/detail, attempted retry, retained loaded range and 25/100 behavior. Component/route interaction tests add SSR no-fetch, accessible actions/regions, cell/focus requests, focus transfer, page transitions, filter/error recovery, export binding and direct window.print invocation.
- Goal tests cover blank/fractional/out-of-range client input and accessible linked error, strict API rejection, independent settings saves, exact persisted acknowledgement and late settings feedback. SQL contracts separately preserve old rows and existing authorization.
- Print-control tests use literal output/witness bytes and real filesystem effects for no-overwrite, stream bounds, partial cleanup, late settlement, changed documents and the repaired relocation windows; observer tests check actual event counts/restoration without stubbing print.

Legacy tests for the intentionally removed fallback/dashboard/pivot/sort/status-only contract were deleted/replaced with the new briefing contract; retained matrix/status/consumer tests remain. No new geometry/copy-change-detector test or skipped assertion was found in the meaningful acceptance coverage. The small Onboarding interaction test teardown timing adjustment is not treated as product proof.

The tests do not establish browser paint, real keyboard/screen-reader behavior, CSS fragmentation, physical print, live provider/RLS execution, request latency, native protocol behavior or shared-session Organization/sign-out races. Those limits remain evidence gaps rather than source findings fabricated from hypothetical failures.

## Missing current acceptance evidence

This scoped PASS permits proceeding to the authorized current live proof; it is not final issue/PR acceptance.

At the reviewed checkpoint, final current live artifacts were not yet available. No assertion is made about a final full Training journey, native workbook download/error/retry, scoped/foreign actor behavior, Organization/sign-out late-response behavior, expanded artifact completeness/integrity, print-only versus screen-only rendering, native controls after print capture, actual filters/section/page content in the PDF, T3 Claude's final visual acceptance, restoration/cleanup, or hosted current-head CI/review. Historical #1501–1503 runs keep their own candidate/base/worker/qualification scope.

Root owns the fresh proof, packaging and separate expanded artifact audit. A later artifact review must bind actual captures to this source candidate and distinguish native interaction, direct HTTP/provider checks, isolated SQL proof, visual judgment and unrun outcomes. No merge, deploy or remote-database authority is added.

## Complete cumulative changed-file census

For A/M entries, byte count and SHA-256 are the pinned HEAD blob; for D entries, they are the reviewed base blob whose current absence was confirmed. Commit bindings above pin both sides of every change. Archive rows establish byte census only.

| Status | Path | Bytes | SHA-256 | Review treatment |
| --- | --- | ---: | --- | --- |
| M | `.agents/skills/verify-trooptotask/SKILL.md` | 54799 | `7b8c727ed99c1b14c7274a388b261d09db5cc065e30f9ad55e7b6ea5065b2869` | Text/source diff |
| M | `.agents/skills/verify-trooptotask/features/critical-tasks-completions-readiness.md` | 16679 | `5d4834c8e763b412e951ca9ea617c0b120515612a274522c89ad6ec05e779ebc` | Text/source diff |
| M | `.agents/skills/verify-trooptotask/features/organization-settings-destruction.md` | 32945 | `8305c969f67490db2998a29051159b27afb7541a15628c997fd12f9bf88d3c94` | Text/source diff |
| M | `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | 31117 | `e43f93898e6a95d93c8da2b73f7325b5533f42bd415cc609b1b7500fc5304b18` | Text/source diff |
| M | `.agents/skills/verify-trooptotask/helpers/control.mjs` | 90530 | `d426c720af9eed040bbd4827352303e471c576792cf5adfecdd7f02a46af1bda` | Text/source diff |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.mjs` | 1053 | `05885ab449dc9b15805f159896234890762e2b25770c9e708b675e09a5db0489` | Text/source diff |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.test.mjs` | 1743 | `e9a3c9bb5c9ce486d200beae84e7b1a05f4cfa6dd867cc5d891d904c53b2b509` | Text/source diff |
| M | `.agents/skills/verify-trooptotask/helpers/settings-request.mjs` | 2102 | `3542f8b4e90a8204f42ca1d1e790e732b81a15325bd26d0c49a0ddb46b311956` | Text/source diff |
| M | `CONTEXT.md` | 11259 | `4637eb30bff5deb8a4b8e52e368787254bd4ac81849349af22fd4d984681534d` | Text/source diff |
| M | `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` | 80864 | `962b77b310e625a9cedd9cb35879ef4d3ce0a9e6c561654d6857a264a59ce1ca` | Text/source diff |
| M | `docs/architecture/CURRENT_OWNERSHIP.md` | 107351 | `ec21fe6bdd2bebe8c8e585a3f9064c5ac45f9e933361d495802010a82993f328` | Text/source diff |
| M | `docs/architecture/MODULE_CONVENTIONS.md` | 41230 | `dc323e853c6a32339fb9ca3d6be155c553f8f953ecd8ff277d7203043d67c6bb` | Text/source diff |
| M | `docs/component-catalog.md` | 86370 | `270034c569133007691d6a0a3fc9327630b73cbd38a059bf03665ddf40ae954f` | Text/source diff |
| M | `docs/domain/retained-feature-rules.md` | 8048 | `d83fde06bb80a92c854c64ba6c4718980ce406e7236b6e28c10541db9fdfc99c` | Text/source diff |
| A | `docs/verification/training-reports-1501/acceptance.md` | 11784 | `06b6904e31ed613c9e832826bc5d02bfadfd68241404132e1bcb18688692644a` | Text/source diff |
| A | `docs/verification/training-reports-1501/baseline.tar.gz` | 281614 | `0b2f279ddc5b7f22b849cfdb35d6617e9a09c3bca82b369077c7530d6a9a631a` | Archive bytes only |
| A | `docs/verification/training-reports-1501/final.tar.gz` | 537699 | `72ebffdbd185f85f7af876c428c5f127d94320cc09729d83411bec34a9b2ff4a` | Archive bytes only |
| A | `docs/verification/training-reports-1501/validation.tar.gz` | 235881 | `73af61b577db8e4d8144baaaa1d5842fb9afcef89c4c3b1fc7439de7cd727df6` | Archive bytes only |
| A | `docs/verification/training-reports-1502/acceptance.md` | 12101 | `a20f2a7430722f08c336079316cd58705f02306e1760bb76e3533bd2da246049` | Text/source diff |
| A | `docs/verification/training-reports-1502/baseline.tar.gz` | 182877 | `3f5eed79100b3747453564f95b366eaf66e3c48c7ab1fd72384ddce456c3da2f` | Archive bytes only |
| A | `docs/verification/training-reports-1502/final.tar.gz` | 857125 | `7587454d049dcd8397598fb5537d36410df82e2689524cd1d0d4dd5f43f12626` | Archive bytes only |
| A | `docs/verification/training-reports-1502/validation.tar.gz` | 94200 | `ccc30126735e7e9801314261127e293ae7b336aef96473a4270a9825b13e0df2` | Archive bytes only |
| A | `docs/verification/training-reports-1503/acceptance.md` | 13175 | `afe547eb816c30295b5e4ae21b70a3717a10fa08ede3487ca92e74372b387d8f` | Text/source diff |
| A | `docs/verification/training-reports-1503/baseline.tar.gz` | 1704184 | `fa83957d99b581bbb93df8b4337f139d827d8df9dfb3e5a8524c099248dee4c9` | Archive bytes only |
| A | `docs/verification/training-reports-1503/final-integration-v8.tar.gz` | 4770012 | `0469994bbce1b9e38229573a55c2f8b704f0f5831783232156b3528a98d4836b` | Archive bytes only |
| A | `docs/verification/training-reports-1503/final-v7.tar.gz` | 16701741 | `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200` | Archive bytes only |
| A | `docs/verification/training-reports-1503/independent-acceptance.md` | 57300 | `cd3e54b63594d997c49af701ebaf306841d95f2b253f7813e6d65b417444dd24` | Text/source diff |
| A | `docs/verification/training-reports-1503/validation-v8.tar.gz` | 3038956 | `c59b77f146140d46f2879a83e9d3bbf3f97470a7abd9574b4a9e56319995402e` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-failure-v2.tar.gz` | 4546927 | `506cdc2433025c1beebec1c8c9cb8e5d779db718498280f604cfd0281c266a5f` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-failure-v3.tar.gz` | 3567677 | `973f3cb2fd148afc95784530a38e902a1f0eb16fee3630a3478f4a2c88410299` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-failure-v4.tar.gz` | 2911869 | `bf1a94039ba6d48bb56a38ec4c5f1c3221a1746a3d70834221849a45a5403bc7` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-failure-v5.tar.gz` | 1696296 | `f316ce2e80ac8f038530c2cf1093b0ac834483face74caa9fb24566dca018d8b` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-failure.tar.gz` | 6591417 | `04d94812ab5c1543f3fe783f64dc9a981bae1b9bcdb02cdd15e39130ea3d0925` | Archive bytes only |
| A | `docs/verification/training-reports-1503/visual-unavailable-v6.tar.gz` | 254498 | `8e44e2ba1a5005c74b977816ac1c0e6478fa13e3f2e3e162f99855dcc1ae6ff5` | Archive bytes only |
| A | `docs/verification/training-reports-1504/baseline-v1.tar.gz` | 3741607 | `a29ca4b5220fdd1c500a59a674669bcce310130598a27d3bca419f03e11a3896` | Archive bytes only |
| M | `scripts/ci/database.py` | 32698 | `67189f0a4470552476e2b1899a564222f753e66e4c4a556eb4efeece5caab5d1` | Text/source diff |
| M | `scripts/module-boundaries.json` | 16452 | `dc4bdbab7e87dfcf6ec8d1f3615f3c8c0dd617242f2448373b9d2307f8253439` | Text/source diff |
| M | `scripts/verification/daemon.mjs` | 12787 | `c28b1e68f74fb4481fe80c09f2d31bdd35f59026e36ece87e68bbd6619f72510` | Text/source diff |
| A | `scripts/verification/print-capture.mjs` | 14213 | `820e041e5dcab48d98f119cc66dc12cd6710a1291960e99fdce9634412ce7f73` | Text/source diff |
| A | `scripts/verification/print-capture.test.mjs` | 16744 | `2073c15b6ccd1e454178616dac3b045ddf1a45b0c6452604a06bc54a84770a3c` | Text/source diff |
| M | `src/app.css` | 14434 | `b586ce456f4d11c12932d4f05f37019af3a7df64f674c9458cec514ff05380c1` | Text/source diff |
| M | `src/features/app-shell/components/AppShellHeader.svelte` | 25591 | `26bd934d4a9a592ed42c9caf165cd8ae4c00b9df410c1dd12dadbff1117ad4f6` | Text/source diff |
| M | `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts` | 26235 | `5e982bd1a4f547405009c22444b291259f64744b929007ac4eb5901a79a21a8a` | Text/source diff |
| M | `src/features/organization/PoliciesSettingsPage.svelte` | 3806 | `6387821b225c4dc09f17961d45991d1c7f0b6d9ec0117514f4cf99b57adf9a33` | Text/source diff |
| M | `src/features/organization/PoliciesSettingsSection.svelte` | 5926 | `0a3013074eafa30fc05cc77bafecaec607d0b494e9412904f0e411a588565c4e` | Text/source diff |
| M | `src/features/organization/policiesSettings.ts` | 1433 | `cb71f5ee1514d916ad50adaa0dc88158f15bd2de4eeb27a1256a93e60e37fa1d` | Text/source diff |
| M | `src/features/organization/policiesSettingsState.svelte.test.ts` | 995 | `24fdf5cbddc67e146412104144f4298837e1e7b3f86a5a2094590c6c53aef778` | Text/source diff |
| M | `src/features/organization/policiesSettingsState.svelte.ts` | 3836 | `e6d6a86506216a2bebb312b7b8b872ff9b5bbf638072f3937f8311e9b123295e` | Text/source diff |
| M | `src/features/organization/policiesSettingsTypes.ts` | 835 | `12c2b6158b1febe38fb9be7bdc335ca71c74b0d4626a7ccbf39d5328a0b81531` | Text/source diff |
| M | `src/features/organization/policy.server.test.ts` | 7060 | `0aeb4a5034df40434f32b0bcebc878a944496317c82f96cd14f69841329abb43` | Text/source diff |
| M | `src/features/organization/policy.server.ts` | 3560 | `ab31c004aa04c695861bbdc2f8c7289cdddc6143a9556abed70cd80b52464852` | Text/source diff |
| M | `src/features/organization/policyConstraints.ts` | 438 | `3277ff269a8b8fa5abc28d1823306d665771c77ccbf5d3b194a733c47b5c459c` | Text/source diff |
| M | `src/features/organization/policyProvider.server.test.ts` | 5262 | `b5fb2466ea43355975c8eedf995c5360a6930b0b952d5fecd482e3fdd1dc3751` | Text/source diff |
| M | `src/features/organization/rawExport.server.test.ts` | 6645 | `fcf0e931ef9285590c8ff77750e033a0631fa2956cbad5cf5498e7ceab63e1cb` | Text/source diff |
| M | `src/features/organization/rawExport.server.ts` | 1537 | `24d2c7e8f32f9ff7203ada500cb3fc73ecad4f2cde67d768dbd10364b33980f1` | Text/source diff |
| M | `src/features/organization/settingsProvider.server.test.ts` | 6480 | `b23aa3607a1042ae080dba4e77efb2a0b5f24392f79d3cefe7d50394d2cce91b` | Text/source diff |
| M | `src/features/organization/settingsProvider.server.ts` | 3494 | `db5e7cf7a33b2071d222475a3700547b61dbc45da9d7936fbc84250778536c92` | Text/source diff |
| M | `src/features/organization/settingsTypes.ts` | 1907 | `d8122efeaac05752409487c67d598639c9ecf7382578d19b7c5849ab0d01e92b` | Text/source diff |
| A | `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | 5435 | `471bcd2ec691e9788feb623f157b91b0b187d9c0ac887fc57afe1701db9de9f2` | Text/source diff |
| A | `src/features/training/components/TrainingFocusSection.svelte` | 2236 | `49ead5898bcbb10cdbd8d7e4f6e88191b0144a0557f44a55989beb4d1aa73ead` | Text/source diff |
| M | `src/features/training/components/TrainingReportsPage.svelte` | 23286 | `b4fa53eaa63f1307a08ef1bba616c54d8809aaeaa9ad74a4b26a24fa3fdb4df8` | Text/source diff |
| M | `src/features/training/components/TrainingReportsPage.test.ts` | 12760 | `9d069742e3b51ecd99be016fb5d40538213178ec934f9f4f0323efb6539eecb1` | Text/source diff |
| A | `src/features/training/components/TrainingTypeRiskSection.svelte` | 2759 | `33dee409eaeed3bc5d8ecabcff388b86ec79a7c4aa0af443e65cf322c2590d56` | Text/source diff |
| M | `src/features/training/contracts.ts` | 7148 | `7a9d7f410e94e218b4dc0fe61c7dc2f863e8e4dce53f0381962454617097c821` | Text/source diff |
| M | `src/features/training/index.server.ts` | 1808 | `40b0946bff46984dc7d44f986d35498ead42dbfee78c4c628ca692c87922ab14` | Text/source diff |
| M | `src/features/training/index.ts` | 1944 | `3c493ea7b65d8478564a8f2c80b5f347f41fb4f0909cc76e626811de113c4ebb` | Text/source diff |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.test.ts` | 10297 | `9c89254c232bb20c83b75a809b7f6b5821f00666b168ee1bb5f209d884feeb8c` | Text/source diff |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.ts` | 6735 | `cec6544443d09a1a5d61a06b0b0a6bb1bf5db48fff7a25a0dac36e3ea239105d` | Text/source diff |
| D | `src/features/training/read-model/trainingReportScreenModel.test.ts` | 7072 | `0833c6639b512d45a127e502813f8b2cd8be73ec853aa4a8d4bbc499a4468d2b` | Deleted baseline source/test |
| D | `src/features/training/read-model/trainingReportScreenModel.ts` | 11919 | `c4a5088e9f71f97f51ad161e95c59a79e491384e90b799c80c2fbf114fbf42f3` | Deleted baseline source/test |
| M | `src/features/training/server/trainingReportsQuery.server.test.ts` | 16694 | `a255269cc00b9589b8ee66545d2dde546f8262e3f3459ac6cf3015db5e6c4c92` | Text/source diff |
| M | `src/features/training/server/trainingReportsQuery.server.ts` | 7878 | `79b6574e127b89ddad76ed7a0a05dfac26ef2a81ce550d537eab4f0ded05449a` | Text/source diff |
| A | `src/features/training/utils/briefingFilterLabels.ts` | 1621 | `884489a6cc909c9438bcfc7db9c349f8f704a9f2a527fca8ede9065ce9917b7c` | Text/source diff |
| A | `src/features/training/utils/briefingReportInput.test.ts` | 2551 | `5aac480a55e0e96837ad4782e56cebbecb9b5b257188bbeb1b430ec59b52084f` | Text/source diff |
| A | `src/features/training/utils/briefingReportInput.ts` | 3530 | `5b3c49540eb8591151213eaa2be50506a7dc60b78b17dfbc4e7df7a6e6226e9b` | Text/source diff |
| M | `src/features/training/utils/reportCalculations.test.ts` | 2714 | `74916a25f2e7c32a85b90892a465bfa384891625bbeecc55e7baf54bba792dc2` | Text/source diff |
| M | `src/features/training/utils/reportCalculations.ts` | 949 | `2839a3c388902c378985251eb859f8b34447b0236c2f54648b4f6da6310ecef6` | Text/source diff |
| A | `src/features/training/utils/trainingBriefing.test.ts` | 42695 | `51954b8c21e2e394e7d4007ccc32747e862986d38f65cfaeca5158cd6ad1e184` | Text/source diff |
| A | `src/features/training/utils/trainingBriefing.ts` | 26284 | `fb6bf3af5c5fd4e4287c8a159fda126eb6fe3247853c02544effc08eb33c6863` | Text/source diff |
| A | `src/features/training/utils/trainingBriefing.types.ts` | 5125 | `2b6a3b651e78c99f7110c6ffa6a51b51467fc16b79c69311ba2eda30150f94af` | Text/source diff |
| D | `src/features/training/utils/trainingReportWorkbook.test.ts` | 3144 | `ffd36f90d9c5483a95a8df19a61fdcfaf68a6c308d2ca2302b2d86ac7a1fb4d3` | Deleted baseline source/test |
| M | `src/features/training/utils/trainingReportWorkbook.ts` | 6047 | `84ee4e8af3721dce0e1e6fcc981b700ec8684148f6e07a53cb2eb1170ab9a2ff` | Text/source diff |
| M | `src/features/training/utils/trainingStatus.test.ts` | 13373 | `a7f081e6ea5d1878f309bf7b39bbf76ad2ff2acd644646942b9a3174500e39f3` | Text/source diff |
| M | `src/features/training/utils/trainingStatus.ts` | 7205 | `ef0ae1f4efdf721a80bf83107c077567bc39369779d87d47f73cba13e92b8cd6` | Text/source diff |
| M | `src/lib/components/BannerStack.svelte` | 772 | `9c1f03e3aa25a60e9d8ee5704523a973a4030ed4a34a6308d295ea84f798cc63` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/ReadinessBand.test.ts` | 2477 | `8cfbe81c63d4678cafb43a25a253424e55409c5b3b29ddc891292853e30afe75` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/index.ts` | 503 | `fbc42884b8a9e0edb6c4a57ca8c8fa6805a9724233587c8d6546e109f127a35e` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/readiness-band-cell.svelte` | 4300 | `0d18beafb2e765306a34296cd7c7f03ac8632aabd6062541cd58cb3d5bc56e8e` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/readiness-band-legend.svelte` | 1532 | `5fe61e364f174547d6c47b6baae963d41b583584d77da2155076f228aff4b3a2` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/readiness-band-swatch.svelte` | 2743 | `44df84a36ea4f58199c46ee5b63428c70e535da0cc49bd0104bf32851b7b2205` | Text/source diff |
| M | `src/lib/components/ui/readiness-band/types.ts` | 1462 | `ad94ec16e0145657a4169005940e55f467668334dda4c9b8f688f52a3280bc42` | Text/source diff |
| A | `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | 10377 | `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` | Text/source diff |
| M | `src/lib/components/ui/report-chart/index.ts` | 352 | `1092440911915989fcd94b431998761d4f1d9659417fea254a72087be3b69230` | Text/source diff |
| M | `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | 2752 | `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` | Text/source diff |
| A | `src/lib/components/ui/toggle-group/index.ts` | 159 | `5ad8938622bce94f5d3611adbe7e13da8f5cd176f56d3eadeb6a8c8eaa334103` | Text/source diff |
| A | `src/lib/components/ui/toggle-group/toggle-group-item.svelte` | 958 | `cbde5673054945e9ca4e5d6a588ab9dacffabf38fd4e4d05d3f966165cc82b27` | Text/source diff |
| A | `src/lib/components/ui/toggle-group/toggle-group.svelte` | 1115 | `1a8ffb1f16373ccc2ad720aaa90e9e44012ba572875d0a544b184f7df868b900` | Text/source diff |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-actions.svelte` | 5146 | `9edbf5d1eb0a05358266386e856f4e0990cf6b3f3291b70ffd24ca399a179af3` | Text/source diff |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-select.svelte` | 1004 | `d533efc217a5e4e710dbe354f293c8728c13b8db721a90252b632fff631682cb` | Text/source diff |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar.svelte` | 2149 | `9c5e79b4f5adc62580aaa6f619f8a823f93e22158a4265ef0ad8bf30a73e6d96` | Text/source diff |
| M | `src/lib/domain/readinessRollup.ts` | 6983 | `737669f8b54d8df5422b0107f6d76e8fbb8fe107980e379e6f95db6cdf985058` | Text/source diff |
| M | `src/lib/server/adapters/inMemory.ts` | 50854 | `58fc873491d8f85d85b77b94d84bb4e681599c78a5eaf2f88cc7af4c4d0fc810` | Text/source diff |
| M | `src/routes/org/[orgId]/api/organization/settings/server.test.ts` | 1685 | `8f23cf37ededa97e0b0d061177d33dab3e12c651e8ae1505a83581ae01838f47` | Text/source diff |
| M | `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.test.ts` | 36536 | `d693459f995e8ae7f9124c6d5ef92b5ab3b7f9b3b69221cfdef3f7fba49bec1b` | Text/source diff |
| M | `src/routes/org/[orgId]/api/training-reports/+server.ts` | 852 | `a4c0df9f571653953281b2acf849ffacdc5eac128c398ac46fd4b1e215bb3467` | Text/source diff |
| M | `src/routes/org/[orgId]/api/training-reports/detail/+server.ts` | 987 | `06bd97fe5143520927805bb32d55189dc49e3475a867a9d65ca32a45a1de1324` | Text/source diff |
| M | `src/routes/org/[orgId]/api/training-reports/export/+server.ts` | 928 | `87411f0be57744195b120f322c5a56f6c3a2b3e0286ab34ed93d2f731d230f87` | Text/source diff |
| D | `src/routes/org/[orgId]/api/training-reports/export/server.test.ts` | 2655 | `6a19175bf802fece45ef976e5b7e055ce23c464e347a0734173b6754cbfb01ec` | Deleted baseline source/test |
| M | `src/routes/org/[orgId]/api/training-reports/reportInput.ts` | 1981 | `009576da7f537c6f19f46d534af1049a42a0cc449e777ed4ce545dfab6c0e87d` | Text/source diff |
| M | `src/routes/org/[orgId]/api/training-reports/server.test.ts` | 6284 | `d7be28cccb4ce0296dda348a8022af6bc0a8ba2d84de78f64a29dbd351efc2de` | Text/source diff |
| M | `src/routes/org/[orgId]/settings/policies/page.svelte.test.ts` | 9908 | `de92036ae278aa3b98946d85eb37982d58f6e0f21f29a5f3ec532eb83f588866` | Text/source diff |
| M | `src/routes/org/[orgId]/training/+layout.server.ts` | 1115 | `21cf76fda470075596c65ff58bc6a8a446daf495e77f166bd96b7f55d7411f87` | Text/source diff |
| A | `src/routes/org/[orgId]/training/layout.server.test.ts` | 2326 | `8190ea86c9c49900ded8bdc57b1020d19f212906fbe5f97b74a0bc000ca575f3` | Text/source diff |
| M | `src/routes/org/[orgId]/training/reports/+page.server.ts` | 1489 | `e7e6d2836201e64b50178082b5d355b1b4131006de77bb59ce1791a2345c1d2d` | Text/source diff |
| M | `src/routes/org/[orgId]/training/reports/+page.svelte` | 402 | `50375452496d62329f492c92d10a38d037105a517a61cb61e525ed66c9529eb1` | Text/source diff |
| A | `src/routes/org/[orgId]/training/reports/page.server.test.ts` | 2718 | `aeb04d05b65435943fac1d3cbb0c0912bd61ceae8fc684d89a5efa4511c6e947` | Text/source diff |
| M | `src/routes/org/[orgId]/training/reports/training-reports-page.svelte.test.ts` | 1948 | `7b9fdf08b9557ffeccb6d5d366dbc13ff439a23f374d53a1b6da28cacde8331a` | Text/source diff |
| M | `supabase/migration-tests/account_preferences_scope_before.sql` | 5912 | `140eeeb708d3413fe84042bcf0b9cadf917f29c582c929f08be1d211bf170ce5` | Text/source diff |
| M | `supabase/migration-tests/calendar_unassigned_populated_after.sql` | 4398 | `188f6f22c4f4e64041e4432191df15c0448283dd43a787aefa53f2e5a8d6e24e` | Text/source diff |
| M | `supabase/migration-tests/critical_task_archive_retention_before.sql` | 5499 | `5784480a5ec4ce29e5a0184e199c4d3dccb7a0e11851f7ad48f710efac55d2e4` | Text/source diff |
| M | `supabase/migration-tests/critical_tasks_populated_after.sql` | 3614 | `7bba26199cf6657413f432eeaec45cbc923d13d05bf4c178904320da0d320b8a` | Text/source diff |
| M | `supabase/migration-tests/deletion_request_cancellation_before.sql` | 11329 | `be3d5381caa3c55c1a6173b82340156ebc8988fcac860cb4f82740e4fb446c5c` | Text/source diff |
| M | `supabase/migration-tests/organization_file_upload_before.sql` | 3489 | `ba66b3617a2d6a92ca00d2950fd9b30ae7872eb65e0293cc015a4ba21a3a139e` | Text/source diff |
| M | `supabase/migration-tests/organization_file_upload_contract.sql` | 12531 | `b577e25a5d1534a29dd2bacd10a646c48cd762c98cff943ceaed30dcdfe48619` | Text/source diff |
| M | `supabase/migration-tests/organization_storage_cleanup_before.sql` | 8682 | `d84ef0838e68cccda4cf04770bc77fec34b2d8675d08cf9e57b8be7a24dc206e` | Text/source diff |
| M | `supabase/migration-tests/organization_storage_cleanup_contract.sql` | 17845 | `c95a5f1b12952f5feb4bc80b782f4ecab72f48aefaa961891e4a9305ff088ba6` | Text/source diff |
| M | `supabase/migration-tests/personnel_counseling_file_populated_after.sql` | 6202 | `ee8a49873cfe8dc1e376265dfc0c949cc12458208e9431c4f52f7eee7dc5a36b` | Text/source diff |
| M | `supabase/migration-tests/personnel_extended_info_populated_after.sql` | 3190 | `b29adbc1a5b198b9b1254264c549bfc67cb8d217d723cf04729919e4a4e122fd` | Text/source diff |
| M | `supabase/migration-tests/personnel_unassigned_populated_after.sql` | 3111 | `86cd11035201bd536e6cf9a06d2da4e2ad7dfbb6e37b247773885671e8f4e7b7` | Text/source diff |
| M | `supabase/migration-tests/platform_membership_before.sql` | 2961 | `af77afdf7345a31344e2575148f74f52cc725e9bb3bad2ffa2124c46ba3559ea` | Text/source diff |
| M | `supabase/migration-tests/rating_scheme_populated_after.sql` | 3964 | `67c70b777b71c46cd22a3d2cc9ac997971b14ca01dc80eca02ea8328957229b4` | Text/source diff |
| A | `supabase/migration-tests/training_readiness_goal_after.sql` | 456 | `9e7ad7b21cf73d8c5924d60cefc16b4e22d6a48a1db5ad1e50d6f8c8f417adc4` | Text/source diff |
| A | `supabase/migration-tests/training_readiness_goal_before.sql` | 2281 | `00a1fdc4afb86a4e2dcd9930c303aed95f1fb807f00013d333e80c648e36104e` | Text/source diff |
| A | `supabase/migration-tests/training_readiness_goal_contract.sql` | 4107 | `129eb2e3bfd28381b4fb20b815a7d8ba21a78a54112f53ac39f16ec6f0a8742e` | Text/source diff |
| A | `supabase/migration-tests/training_readiness_goal_fresh.sql` | 200 | `fce1306b65521fcb23d94a6f0511d94ea4b32d3eb4bcbd467c63a2ed54fa947c` | Text/source diff |
| M | `supabase/migration-tests/training_record_populated_after.sql` | 3284 | `627c5f6bb7c4334d92d5d9962b1d1278c6dc1aaffec4779b76ef7ecd62df0869` | Text/source diff |
| A | `supabase/migrations/20261004100618_training_readiness_goal.sql` | 484 | `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962` | Text/source diff |

## Requirement and prior-review input bindings

These are the exact local input bytes read for requirements, contracts and prior source conclusions. Claims in owner reports were checked against source rather than adopted as execution proof.

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| `AGENTS.md` | 6105 | `53d2f89e2f97c47a0deefb97969b1022fa1ec47cf3518add3f60f48a8a518cdc` |
| `.agents/skills/t2t-engineer/SKILL.md` | 6463 | `3f6fef32ec36aea2518cd8df30016508354e2b1088d83ad5bfe52faff2f02990` |
| `docs/architecture/TESTING.md` | 8435 | `ad4deb32c71437af2c6c7d2f40c262429390c0125a02748d96297a6613a35fd8` |
| `/home/waffleflops/.codex/plugins/cache/pstack-for-codex-local/pstack-for-codex/0.2.0/skills/poteto-mode/references/poteto-agent-prompt.md` | 699 | `10365f1ee5731c925980b3216d8aea767b549cc761f538280cf7b5b93818a5b4` |
| `.verification/1433-for-1504.json` | 25791 | `0fb86901e245748799c0b7d3aaba8117ac9d823ea67c8dcbc08386453a076536` |
| `.verification/1501-issue.json` | 4385 | `e4b841f2137b4dc5d691a0fef943e53e1a4d8de8f1605c744ba3f9e8a224af2b` |
| `.verification/1503-issue.json` | 5062 | `c0dda54ddc9bbbf0285a008434c0378f8939170539a190dd5f59aed8d8e30908` |
| `.verification/1504-issue.json` | 3874 | `f76a770a21d264bcacb6131e3c35e65c06f03c5c321a6fd55983b3dfabf2d5c3` |
| `.verification/1504-server-grounding.md` | 12431 | `7a1b0fb7f8d5f72c810da9ccca1a527e29cb3445389be710d1209a09cdfa9c43` |
| `.verification/1504-legacy-consumer-census.json` | 36649 | `b5e2faf69cca3fc0b74c51cae4a2351261f2d6d9525181a7e856ca41892de547` |
| `.verification/1504-implementation-report.md` | 11952 | `f9e52aa42d7e2cc515a300f4a7636f4fd326e0ffa754fe98ff7b339f8ffbcea1` |
| `.verification/1504-app-shell-merge-owner-v1-report.md` | 4109 | `4f05610214ea107e1019e1d97f29f9e06268335abfd3244a7fa16745b990ea32` |
| `.verification/1504-independent-source-review-v1.md` | 17532 | `01eb8032198da041fc565569a268883b588ad5f328efcd0e7edb3bdca287ea20` |
| `.verification/1504-independent-print-control-review-v1.md` | 14560 | `5e1ebc32d311f498bc86d2f5375050629419176d8dc9c015b31cc9124419d913` |
| `.verification/1504-independent-print-control-review-v2.md` | 11298 | `5a14a64d0bab373d44d7c92af10b5dccb4c24339ba185f5c378666631a0adda8` |
| `.verification/1504-print-control-grounding.md` | 6337 | `0ee9e43da2706b5b4763b0015bde876fa2324a2cfe5fadfef167528724b9aa46` |
| `.verification/1504-print-control-implementation-report.md` | 5920 | `9e73402efff064e6e08e45593779c021b0405862d703b08893ee75675cb8cea8` |
| `.verification/1504-print-publication-correction.json` | 1185 | `6212a7fa52e10e9e1dc96cd1998f6e55b1ad9c38e27ef63a514cbe03ec230901` |
| `.verification/1504-v2-required-checks.json` | 1191 | `fe64a8860724809a0523ae7dfa1a866c028929a024a88859276af9132cfc7ce4` |

#1502 issue input: `docs/verification/training-reports-1502/validation.tar.gz:issue-1502.json`, 4215 bytes, SHA-256 `4934ea93e18bb7ebaba6a52124ae794aad47279c70a83ac561d699e979fe7cb8`. Its surrounding archive is already bound in the cumulative census. Committed #1501–1503 acceptance records and #1503 independent-acceptance are likewise bound there.

## Additional direct/reverse context bindings

The following unchanged/current-main consumers and installed native source were inspected in the relevant contract/launch/response sections. Whole-file hashes pin the context; this table does not claim a whole-file third-party code audit.

| Context | Bytes | SHA-256 |
| --- | ---: | --- |
| `src/features/app-shell/appShellContext.ts` | 1958 | `a65cac8e74f4ba857afe4564267362725e9a1283bde8662c8d3d3f9b24eb50ea` |
| `src/features/app-shell/contracts.ts` | 3786 | `ef2e5ca07cf65169117675aa3a3ce5fa10de157248fcfcab179e9d7550ceaa2c` |
| `src/routes/org/[orgId]/+layout.server.ts` | 708 | `c57aed7858fe11a9e97141be255957c23d701f618c865753d3549f70332ea91f` |
| `src/routes/org/[orgId]/appShell.test-support.ts` | 1783 | `6911f75c55cc22069c8fb2cc84ed51dca8ace0f05dcadf306480867d71f3fbb6` |
| `src/lib/server/core/featureLaneWorkspaceLoad.ts` | 1381 | `806c50206218c9aa75351ac1ed364d7a2aacc93a8e69e74ca92c8dd9a9217f65` |
| `src/features/personnel/trainingRoster.server.ts` | 1702 | `b9d1904e2f297bcaae776c652c764ae99dfec98b675ee3925d6a5e4ced62dcc5` |
| `src/features/personnel/groupCatalog.server.ts` | 1656 | `932ccc10f6305302a683de0aacd9c36333698c33c7d73f3e51a3a4b65166b140` |
| `src/features/training/server/trainingCompletionRead.server.ts` | 897 | `3e533060d6c1af58829d47161a5d5173865ecca3f385e890bbd40b7fb29748d0` |
| `src/features/training/server/personnelTrainingReadiness.server.ts` | 3277 | `8270f1988ce67738f3775ccaeff1bf981cdb214c0d6f1fd1c402bc809589b12d` |
| `src/features/training/server/trainingSummaryQuery.server.ts` | 3452 | `9dbc32d6d13da5286f84d2e675801e8d7df1977a7f10882030656dbb4224dfe7` |
| `src/features/training/server/trainingExportRead.server.ts` | 1157 | `6dec4f0ef2bd6d276e476917c74d210a03c352d80b529915a29e0129ca5384b2` |
| `src/features/training/onboardingReferences.server.ts` | 4046 | `eb3a1457fbc09bf1a5a014318cd1d25a75481b9d78c4e3abab30a9bb040a9716` |
| `src/features/personnel/personnelExport.server.ts` | 8254 | `6a1c71bbda6394da668de0071316d7f56501858be3addaea732661ebe778b616` |
| `src/features/dashboard/read-model/dashboardScreenModel.svelte.ts` | 30045 | `e8ace46f3abb7c73c24be1ad50c7b8a6fbc47d7c0e8fcb8454045d2f09a3b3a2` |
| `src/features/training/utils/cellDisplayText.ts` | 1607 | `94d374c32042a1846cd5aca43ee333c2371ec3ff3f240a88ef35a3f6ae46fc17` |
| `src/features/training/utils/viewFiltering.ts` | 725 | `7c529022e23ff54983ad8ccc6fa96677f6eab9296ae6c69b6af2520c3f8d52c5` |
| `src/lib/domain/currencyStatus.ts` | 5108 | `adeb6f552e4410bc8403da73eb596ef463f3d055673ca519bbd678de42807b78` |
| `src/lib/utils/dates.ts` | 4112 | `73fdf0589c443c067427d7f8a1e2de3570a928453eb1bb5fd66b758be2fc82c9` |
| `src/lib/utils/workbook.ts` | 4679 | `e6c0a7944bb2a63bdc258c974dd2e7fc7bd05182e25ce4aa62d14a93b5fb5ef9` |
| `scripts/verification/core.mjs` | 11572 | `74b3072e7147eda6322c65bb47508bbe630e9c8d1c3d1e153c50adb75d48bb0e` |
| `scripts/verification/browser.mjs` | 5878 | `ebd009d8cdedf51962253b84264bfa5fac41d2be99d63729c8a77b195e47926a` |
| `node_modules/chrome-devtools-mcp/package.json` | 4668 | `be1a2831f39d9075956984ccaaee52a2babdbddf8812e8f23e808d7432f9fdc7` |
| `node_modules/chrome-devtools-mcp/build/src/BrowserManager.js` | 16072 | `e8ad9ae18a6836a0e56771afbf453b4b9ea1d384b4b0db9fccca04300a9fa222` |
| `node_modules/chrome-devtools-mcp/build/src/config/browser-options.js` | 4813 | `b0ef484ea18c99bc7a025bb9f7961da003811c3bd2c323f2ac5b68081169f29e` |
| `node_modules/chrome-devtools-mcp/build/src/McpResponse.js` | 46475 | `2e975bf142b12d292f7d43b2bd1453174c2b93b3913d255037abf0b31b2fc6ba` |
| `node_modules/chrome-devtools-mcp/build/src/tools/pages.js` | 14596 | `13ec3920dec71060f03a89c8f9fb1f75a22aa19b7d2b720e0d0a7b76f2fb55d4` |
| `node_modules/chrome-devtools-mcp/build/src/third_party/index.js` | 8305782 | `c988e0684584b75e87ae04b768c4f8ae7064401afe5187ec0d4878b2c6833f12` |

This report intentionally has no self-hash. Root can pin its completed bytes in the later acceptance packet without a circular binding.

