SET statement_timeout='10s'; SET lock_timeout='3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_save() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $save$
BEGIN
 IF NEW.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND EXISTS(SELECT 1 FROM public.personnel_onboardings p
 WHERE p.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND p.personnel_id='6be72128-f9a1-4826-b9de-70cfc381a90f'::uuid AND p.id=NEW.onboarding_id) THEN
  RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned Start progress-save fault';
 END IF;
 RETURN NEW;
END;$save$;
CREATE FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $delete$
BEGIN RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned Start compensation-delete fault'; END;$delete$;
CREATE TRIGGER t2t_d15_start_1a5b0fbc_62d0e8a5_save BEFORE INSERT ON public.onboarding_step_progress FOR EACH ROW EXECUTE FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_save();
CREATE TRIGGER t2t_d15_start_1a5b0fbc_62d0e8a5_delete BEFORE DELETE ON public.personnel_onboardings FOR EACH ROW
 WHEN (OLD.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND OLD.personnel_id='6be72128-f9a1-4826-b9de-70cfc381a90f'::uuid) EXECUTE FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete();
COMMENT ON FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_save() IS '{"container_id": "9b9d9a9efd9ecc89368c97bb943593097956b9815cc6909e82665fc91f46baf6", "organization_id": "952f59bb-9db8-4a2a-852b-3fcea91b2b24", "personnel_id": "6be72128-f9a1-4826-b9de-70cfc381a90f", "project": "t2t-verify-c889e5ca1bc142498682e59a", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "148eeb5f76213ec8350a144a4188b709660f0366b8283c276b3151ba3fc388b3", "session_id": "62d0e8a5-5d7a-4086-938d-01897994e20e", "template_id": "27a373f6-2843-4fbe-93f4-8442c01c1dc2", "worker": "1"}';
COMMENT ON FUNCTION public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete() IS '{"container_id": "9b9d9a9efd9ecc89368c97bb943593097956b9815cc6909e82665fc91f46baf6", "organization_id": "952f59bb-9db8-4a2a-852b-3fcea91b2b24", "personnel_id": "6be72128-f9a1-4826-b9de-70cfc381a90f", "project": "t2t-verify-c889e5ca1bc142498682e59a", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "148eeb5f76213ec8350a144a4188b709660f0366b8283c276b3151ba3fc388b3", "session_id": "62d0e8a5-5d7a-4086-938d-01897994e20e", "template_id": "27a373f6-2843-4fbe-93f4-8442c01c1dc2", "worker": "1"}';
COMMENT ON TRIGGER t2t_d15_start_1a5b0fbc_62d0e8a5_save ON public.onboarding_step_progress IS '{"container_id": "9b9d9a9efd9ecc89368c97bb943593097956b9815cc6909e82665fc91f46baf6", "organization_id": "952f59bb-9db8-4a2a-852b-3fcea91b2b24", "personnel_id": "6be72128-f9a1-4826-b9de-70cfc381a90f", "project": "t2t-verify-c889e5ca1bc142498682e59a", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "148eeb5f76213ec8350a144a4188b709660f0366b8283c276b3151ba3fc388b3", "session_id": "62d0e8a5-5d7a-4086-938d-01897994e20e", "template_id": "27a373f6-2843-4fbe-93f4-8442c01c1dc2", "worker": "1"}';
COMMENT ON TRIGGER t2t_d15_start_1a5b0fbc_62d0e8a5_delete ON public.personnel_onboardings IS '{"container_id": "9b9d9a9efd9ecc89368c97bb943593097956b9815cc6909e82665fc91f46baf6", "organization_id": "952f59bb-9db8-4a2a-852b-3fcea91b2b24", "personnel_id": "6be72128-f9a1-4826-b9de-70cfc381a90f", "project": "t2t-verify-c889e5ca1bc142498682e59a", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "148eeb5f76213ec8350a144a4188b709660f0366b8283c276b3151ba3fc388b3", "session_id": "62d0e8a5-5d7a-4086-938d-01897994e20e", "template_id": "27a373f6-2843-4fbe-93f4-8442c01c1dc2", "worker": "1"}';
COMMIT;
SELECT json_build_object('installed',true,'sqlstate','P0001');
