from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

root = Path.cwd()
out = root / '.verification/evidence/export-lifecycle-writer'
source = root / 'src/features/data-export/dataExportPersistence.server.ts'
test = root / 'src/features/data-export/dataExportPersistence.server.test.ts'
original = source.read_bytes()
env = {**os.environ, 'PATH': '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + os.environ['PATH']}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def version(command):
    return subprocess.check_output(command, cwd=root, env=env, text=True).strip()

manifest = {
    'worktree': str(root),
    'base': version(['git', 'rev-parse', 'HEAD']),
    'node': version(['node', '--version']),
    'npm': version(['npm', '--version']),
    'vitest': version(['npx', 'vitest', '--version']),
    'supabaseJs': json.loads((root / 'node_modules/@supabase/supabase-js/package.json').read_text())['version'],
    'runs': []
}

def run(label, command, expected):
    inputs = {str(path.relative_to(root)): digest(path) for path in [source, test]}
    entry = {
        'label': label,
        'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': command,
        'inputs': inputs,
        'expectedExit': expected,
        'log': str((out / (label + '.log')).relative_to(root))
    }
    result = subprocess.run(command, cwd=root, env=env, text=True, capture_output=True)
    entry['exitCode'] = result.returncode
    (out / (label + '.log')).write_text(json.dumps(entry, indent=2) + '\n\n' + result.stdout + result.stderr)
    manifest['runs'].append(entry)
    (out / 'proof.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    if result.returncode != expected:
        raise RuntimeError('Unexpected result for ' + label)

command = ['npm', 'run', 'test', '--', str(test.relative_to(root))]
try:
    run('baseline-green', command, 0)
    text = original.decode()
    tenant = "\t\t\t\t.eq('org_id', orgId)\n"
    if text.count(tenant) != 2:
        raise RuntimeError('Unexpected tenant mutation target')
    source.write_text(text.replace(tenant, ''))
    run('lost-tenant-red', command, 1)
    source.write_bytes(original)
    run('tenant-restored-green', command, 0)
    failure = ".update({ status: 'failed', completed_at: input.completedAt })"
    if text.count(failure) != 1:
        raise RuntimeError('Unexpected failed-byte mutation target')
    source.write_text(text.replace(failure, ".update({ status: 'failed', completed_at: input.completedAt, file_size_bytes: null })"))
    run('lost-failed-bytes-red', command, 1)
finally:
    source.write_bytes(original)
    manifest['restoredSources'] = {str(path.relative_to(root)): digest(path) for path in [source, test]}
    (out / 'proof.json').write_text(json.dumps(manifest, indent=2) + '\n')

run('restored-green', command, 0)
run('scoped-lint', ['npx', 'eslint', str(source.relative_to(root)), str(test.relative_to(root))], 0)
run('scoped-format', ['npx', 'prettier', '--check', str(source.relative_to(root)), str(test.relative_to(root))], 0)
