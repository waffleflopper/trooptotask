# D24 initial artifact review

The four initial owner/admin JSON and Excel exports support a scoped verification-baseline PR. No actionable data-preservation or workbook defect was found in the reviewed scope. This is initial artifact acceptance only. Later failure/retry, denial, context-switch, source-preservation, cleanup and candidate receipts remain for the parent's final independent acceptance.

## Reviewed scope and method

Reviewed `owner-a.json`, `owner-a.xlsx`, `admin-a.json`, `admin-a.xlsx`, the initial A/B provider readbacks, fixture and seed receipts, native owner Feedback source readback, initial capture receipts, and corresponding lifecycle readbacks/reloads. The run identifies revision `c40f2ac101a2893154cb060a382281bba708c275` and fingerprint `1bcb9652328a1e3f7cedd7d74b565b43084f60fc2a0b599c59105910e9305238`. This review does not approve a later edited or rebased candidate.

Expected values came from literal provider readback rows, fixture identities and stored label relationships. I independently expanded both actual XLSX files with ExcelJS. Source code was used to understand mappings and RLS policy, not to generate expected source values. The independent owner expansion matches the parent's `owner-workbook-expanded.json`.

[Literal comparison results](comparison-results.json), [readable-label and tenant-scope results](readable-and-scope-results.json), and [mutable snapshot results](mutable-results.json) preserve the detailed checks. Offline scripts and expanded workbooks are in this directory. No browser, service or database operation was performed by this reviewer.

## Verified results

- All 38 JSON inventory entries, section keys, section counts and top-level mirrors agree. Each workbook contains 57 sheets: inventory, 18 readable sheets and 38 raw sheets. Raw metadata and counts agree with its own inventory. Empty raw sheets remain present with the empty-record header; owner has 10 and admin has 11.
- Both JSON exports match the row-ID sets and all available literal fields for 29 static source tables. These comprise 58 table comparisons and 3,812 literal field comparisons, with 25 nonempty and four independently empty source tables per artifact. Both raw workbooks preserve those values and additional JSON fields.
- Eleven selected readable sheets per workbook match source identity/label relationships and stored values: Personnel, Calendar, Training Records, Daily Assignments, Counseling Records, Leader Notes, Personnel Follow-ups, Personnel Documents, Onboarding Progress, Critical Task Completions and Rating Scheme. All 64 readable Personnel `Leader Notes` cells are blank. Separate note sheets retain their source records.
- Counseling, Leader Notes, Documents and Follow-ups each contain both active and archived A-owned rows. Stored authors/uploaders, subjects, notes, timestamps, archive fields and document paths survive in JSON and raw worksheets. Readable document filenames match the final component of the stored path. This verifies document metadata, not downloaded Storage file bytes.
- The native owner Feedback submission produces one owner row. All 12 independently read-back fields match owner JSON and Excel, including exact message and requester. Admin excludes that peer Feedback row. No positive admin-owned Feedback witness was exercised.
- Notifications follow actor visibility. Owner exports zero recipient rows and excludes 26 independently observed peer rows. Admin exports its two recipient rows and excludes 32 peer rows. JSON and workbook fields match the corresponding source snapshots.
- Owner Audit preserves exactly 110 pre-JSON and 111 pre-Excel provider rows. Ordinary admin Audit is empty under the current owner/platform-admin SELECT policy. Empty admin Audit is expected behavior.
- Each capture produced one POST 200 and the expected MIME type/filename. Actual bytes and SHA-256 match the save receipts. Each newly created lifecycle row becomes completed, retains the requester and organization, and records actual byte size. Reload preserves the finalized row. Earlier completed export rows retain their exact stored values.
- The artifact contains its own export row while processing, before final byte size and completion time exist. Independent post-download readbacks show the same row completed. The extra Audit/export rows between sequential JSON and Excel downloads are expected mutable snapshot effects.

## Foreign-reference disposition

No B source rows are exported as rows, and no checked B private labels, document paths or note values are present. The scan covered 53 distinct B source row IDs. Three B resource UUIDs occur only inside stored `details` on two A-owned seeded Audit rows, `44fba8a1-0315-4eed-861b-081fd5668ede` and `8aed03f2-d0ed-4a4f-9b3a-805b322848b0`. Those stored details match the A source readbacks exactly. They are historical references, not B row admission.

`comparison-results.json` retains the broad scanner's initial `foreign_source_ids` finding. Its disposition is resolved by the row-aware and private-label checks in `readable-and-scope-results.json`. A blanket claim that every B UUID is absent would be false and would contradict faithful raw Audit preservation. Narrow the recipe and evidence claim to exported B source rows and B private values. Parent has accepted this correction.

## Explicit unrun scope

Five section tables lack independent provider source readbacks: `access_request_organization_invitation_links`, `dashboard_configs`, `getting_started_progress`, `user_org_preferences` and `user_pinned_groups`. Their manifest, zero counts and empty worksheets pass; their source-value and positive/negative row-selection acceptance remains unrun. Feedback is separately checked through the native owner source readback, although it appears as unreadback in the generic static comparison output.

Additional exported fields lacked independent source-fact readback: rank catalog `created_at`/`updated_at`, Training Types `created_at`, Training Records `created_at`/`updated_at`, Onboarding Templates and Steps `created_at`, and Feedback `user_email`/`created_at`/`updated_at`. Workbook-to-JSON consistency passes for them. Independent provider-value acceptance remains unrun.

`seed-training-pages` creates 26 additional Personnel rows, for 32 Personnel and four Training completion rows total. It does not cross the provider's 1,000-row page boundary. Paging beyond that boundary remains unrun; parent has accepted this correction. Four independently empty static tables also have no positive nonempty-row proof.

These omissions do not block publishing the first documentation/recipe baseline as `Refs #1372`, provided its acceptance states these limits and leaves the whole issue open. Global export ownership, remaining readback facts, broader page boundaries and complete D24 acceptance require subsequent owned work. Later run receipts and final candidate checks are outside this report.

The Poteto `prove-it-works` principle changed the review approach by requiring expansion of the actual downloaded XLSX bytes and independently recorded provider facts. `sequence-verifiable-units` keeps this initial artifact result distinct from final candidate and whole-issue acceptance.
