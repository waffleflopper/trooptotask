#!/bin/bash
# obs.sh NAME PAGE  -> read-only state + fetch list
n=$1; p=${2:-2}
FN='() => { const radios=[...document.querySelectorAll("[role=radio]")].map(r=>({group:(r.closest("[role=group],[role=radiogroup]")||{getAttribute:()=>null}).getAttribute("aria-label"), name:r.getAttribute("aria-label")||r.textContent.trim(), ariaChecked:r.getAttribute("aria-checked"), dataState:r.getAttribute("data-state"), tabIndex:r.tabIndex})); const a=document.activeElement; const t=document.body.innerText; return {url:location.href, focus:{tag:a.tagName, role:a.getAttribute("role"), ariaLabel:a.getAttribute("aria-label"), text:(a.textContent||"").trim().slice(0,80), id:a.id||null, ariaLabelledby:a.getAttribute("aria-labelledby")}, radios, ranges:t.match(/Rows \d+\S\d+ of \d+/gi), updating:/Updating briefing/.test(t), alerts:[...document.querySelectorAll("[role=alert]")].map(x=>x.textContent.trim().slice(0,160)).filter(Boolean)} }'
J=$(python3 -c 'import json,sys;print(json.dumps({"pageId":int(sys.argv[1]),"function":sys.argv[2],"waitForStableDom":False}))' "$p" "$FN")
MAXOUT=6000 /tmp/t.sh "$n-state" evaluate_script "$J" >/dev/null
MAXOUT=0 /tmp/t.sh "$n-net" list_network_requests "{\"pageId\":$p,\"resourceTypes\":[\"fetch\",\"xhr\"]}" >/dev/null
E=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v5/driver
python3 - "$E/$n-state.out" "$E/$n-net.out" <<'PY'
import json,sys,re
s=json.load(open(sys.argv[1]))['structuredContent']['message']
d=json.loads(s.split('```json\n',1)[1].rsplit('\n```',1)[0])
print('URL',d['url'].split('/training')[1]); print('FOCUS',d['focus']); print('RANGES',d['ranges'],'UPDATING',d['updating'],'ALERTS',d['alerts'])
for r in d['radios']: print('  ',r['group'],'|',r['name'],'|',r['ariaChecked'],r['dataState'],'ti',r['tabIndex'])
n=json.load(open(sys.argv[2]))['content'][0]['text']
tr=[l for l in n.splitlines() if 'training-reports' in l or '__data' in l]
print('NET training-reports/__data lines:',len(tr)); [print('  ',l[:260]) for l in tr]
PY
