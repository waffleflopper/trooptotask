import path from 'node:path';
import fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { repository, sessionPath, readJSON, writeJSON, processIdentity } from '../scripts/verification/core.mjs';

const [action, worker = '1'] = process.argv.slice(2);
if (!['setup', 'readback'].includes(action)) throw new Error('Use setup|readback [1|2] from the repository root.');
const session = sessionPath(worker);
const state = await readJSON(path.join(session, 'session.json'));
if (state.repository !== repository || state.worker !== worker || state.phase !== 'running')
  throw new Error('An owned running worker for this checkout is required.');
const identity = await processIdentity(state.supervisor?.pid);
if (identity?.start !== state.supervisor?.start || identity?.command !== state.supervisor?.command)
  throw new Error('The owned supervisor was replaced or stopped.');
const response = await fetch(`http://127.0.0.1:${state.controlPort}`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${state.token}`, 'Content-Type': 'application/json' },
  body: JSON.stringify({ command: 'doctor' }),
  signal: AbortSignal.timeout(180000)
});
if (!response.ok || response.headers.get('X-T2T-Session') !== state.id)
  throw new Error('The owned supervisor did not authenticate.');
const doctor = await response.json();
if (doctor.status !== 'PASS') throw new Error('The owned candidate doctor did not pass.');
const config = await readJSON(path.join(session, 'provider.json'));
const url = new URL(config.API_URL);
if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1') throw new Error('Provider must be owned loopback HTTP.');
const client = createClient(config.API_URL, config.SERVICE_ROLE_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const fixture = await readJSON(path.join(session, 'fixtures.json'));
const receiptFile = path.join(session, '1503-boundary-seed.json');
const ownershipFile = path.join(session, 'verify-trooptotask-owned.json');
const checked = (result) => {
  if (result.error) throw new Error(`Owned fixture operation failed: ${result.error.message}`);
  return result.data;
};
const note = (value) => process.stdout.write(JSON.stringify(value, null, 2) + '\n');
const exists = async (file) => {
  try { await fs.access(file); return true; }
  catch (error) { if (error.code === 'ENOENT') return false; throw error; }
};
if (action === 'readback') {
  const receipt = await readJSON(receiptFile);
  if (receipt.sessionId !== state.id || receipt.candidate !== doctor.candidate || receipt.organizationId !== fixture.ids.orgA)
    throw new Error('Seed receipt belongs to another session or candidate.');
  const observed = {};
  for (const item of receipt.rows) {
    const rows = [];
    for (let offset = 0; offset < item.ids.length; offset += 100) {
      rows.push(...checked(await client.from(item.table).select(item.select)
        .eq('organization_id', fixture.ids.orgA).in('id', item.ids.slice(offset, offset + 100))));
    }
    observed[item.table] = rows;
  }
  note({ sessionId: state.id, candidate: doctor.candidate, observed });
} else {
  if (await exists(receiptFile)) throw new Error('A seed receipt already exists; inspect it and use ordinary clean-seeds before a fresh worker.');
  const tag = randomUUID().slice(0, 8);
  const role = `BriefingBoundary${tag}`;
  const asOf = fixture.dates.ui;
  const plusDays = (offset) => {
    const [year, month, day] = asOf.split('-').map(Number);
    return new Date(Date.UTC(year, month - 1, day + offset)).toISOString().slice(0, 10);
  };
  const people = Array.from({ length: 100 }, (_, index) => ({
    id: randomUUID(), organization_id: fixture.ids.orgA, group_id: fixture.ids.groupA,
    first_name: 'Synthetic', last_name: `Briefing${tag}${String(index).padStart(3, '0')}`,
    rank: 'PFC', mos: index < 13 ? '68W' : '11B', clinic_role: role,
    slug: `briefing-${tag}-${index}`
  }));
  const definitions = [
    { name: 'At goal 85', ready: 85, applicable: 100, lapses: 10, band: 'goal' },
    { name: 'Near 84', ready: 84, applicable: 100, lapses: 10, band: 'near' },
    { name: 'Near edge 75', ready: 75, applicable: 100, lapses: 10, band: 'near' },
    { name: 'Below 74', ready: 74, applicable: 100, lapses: 10, band: 'below' },
    { name: 'Below edge 65', ready: 65, applicable: 100, lapses: 10, band: 'below' },
    { name: 'Far 64', ready: 64, applicable: 100, lapses: 10, band: 'far' },
    { name: 'Far edge 55', ready: 55, applicable: 100, lapses: 10, band: 'far' },
    { name: 'Critical 54', ready: 54, applicable: 100, lapses: 10, band: 'critical' },
    { name: 'Rounding 11 of 13', ready: 11, applicable: 13, lapses: 0, band: 'near', mos: ['68W'] },
    { name: 'Drop nine 85', ready: 85, applicable: 100, lapses: 9, band: 'goal' },
    { name: 'Cliff fifty', ready: 100, applicable: 100, lapses: 50, band: 'goal' },
    { name: 'Not applicable', ready: 0, applicable: 0, lapses: 0, band: 'none', mos: ['99Z'] }
  ];
  const types = definitions.map((definition, index) => ({
    id: randomUUID(), organization_id: fixture.ids.orgA, name: `${definition.name} ${tag}`,
    description: null, expiration_months: null, warning_days_yellow: 60, warning_days_orange: 30,
    applies_to_roles: [role], applies_to_mos: definition.mos ?? [], applies_to_ranks: [],
    excluded_roles: [], excluded_mos: [], excluded_ranks: [], color: '#6b7280', sort_order: 100 + index,
    expiration_date_only: true, can_be_exempted: false, exempt_personnel_ids: [], is_optional: false
  }));
  const records = definitions.flatMap((definition, typeIndex) => people.slice(0, definition.ready).map((person, personIndex) => ({
    id: randomUUID(), organization_id: fixture.ids.orgA, personnel_id: person.id,
    training_type_id: types[typeIndex].id, completion_date: null,
    expiration_date: plusDays(personIndex < definition.lapses ? 10 : 366), notes: `Owned boundary ${tag}`
  })));
  const views = [{ id: randomUUID(), organization_id: fixture.ids.orgA, name: `Boundary briefing ${tag}`,
    column_ids: types.map((type) => type.id), created_by: fixture.actors.trainingConfigure.id }];
  const tables = [
    { table: 'personnel', records: people, select: 'id,organization_id,group_id,first_name,last_name,rank,mos,clinic_role' },
    { table: 'training_types', records: types, select: 'id,organization_id,name,applies_to_roles,applies_to_mos,expiration_date_only,is_optional' },
    { table: 'training_views', records: views, select: 'id,organization_id,name,column_ids' },
    { table: 'personnel_trainings', records, select: 'id,organization_id,personnel_id,training_type_id,completion_date,expiration_date,notes' }
  ];
  const receipt = {
    sessionId: state.id, candidate: doctor.candidate, organizationId: fixture.ids.orgA, tag, role, asOf,
    goalRequired: 85, viewId: views[0].id, viewName: views[0].name,
    expected: definitions.map((definition, index) => ({ ...definition, id: types[index].id,
      displayPercent: definition.applicable ? Math.round(100 * definition.ready / definition.applicable) : null,
      dropAlert: definition.applicable ? 100 * definition.lapses / definition.applicable >= 10 : false })),
    rows: tables.map(({ table, records, select }) => ({ table, ids: records.map((row) => row.id), select }))
  };
  const ownership = await exists(ownershipFile) ? await readJSON(ownershipFile) : { seeded: [], grants: [] };
  ownership.seeded.push(...receipt.rows.map((item) => ({ kind: 'training-briefing-boundaries', table: item.table,
    ids: item.ids, organization: 'orgA', tag })));
  await writeJSON(receiptFile, receipt);
  await writeJSON(ownershipFile, ownership);
  for (const item of tables) {
    for (let offset = 0; offset < item.records.length; offset += 100)
      checked(await client.from(item.table).insert(item.records.slice(offset, offset + 100)));
  }
  note({ ...receipt, inserted: tables.map(({ table, records }) => ({ table, count: records.length })),
    cleanup: 'node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1 clean-seeds',
    proofLimit: 'Privileged owned fixture setup; goal is changed and restored through normal Settings UI. This does not prove ordinary write authorization.' });
}
