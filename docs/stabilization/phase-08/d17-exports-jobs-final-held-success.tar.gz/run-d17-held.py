import subprocess,sys,os,json,datetime,pathlib
root=pathlib.Path.cwd(); out=root/'.verification/evidence/verify-trooptotask/d17-exports-jobs-final-held-success';out.mkdir(parents=True,exist_ok=True)
name,kind,*args=sys.argv[1:]
cmd={'verify':['npm','run','--silent','verify:app','--'], 'helper':['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1'], 'command':[]}[kind]+args
if kind=='verify':cmd+=['--worker','1']
env=os.environ.copy();env.update(TMPDIR='/home/waffleflops/.cache/t2t1365tmp',npm_config_cache=str(root/'.verification/d17-held-npm-cache'))
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True)
(out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
(out/(name+'.command.json')).write_text(json.dumps({'argv':cmd,'cwd':str(root),'environmentOverrides':{k:env[k] for k in ['TMPDIR','npm_config_cache']},'start':start,'finish':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode},indent=2)+'\n')
print(r.stdout[:9000]);print('STDERR:',r.stderr[-3000:] if r.stderr else '(empty)');print('EXIT:',r.returncode)
sys.exit(r.returncode)
