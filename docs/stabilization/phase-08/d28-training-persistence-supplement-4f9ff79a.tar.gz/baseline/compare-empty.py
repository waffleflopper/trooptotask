import json,pathlib
r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-remaining-20261007');results={}
for name,soldiers,requirements,ready in [('short',112,336,124),('empty-view',112,0,0),('empty-people',0,0,0)]:
 x=json.loads((r/(name+'-workbook-rows.json')).read_text());summary={v[0]:v[1] if len(v)>1 else None for v in x['Summary'][1:]}
 assert len(x)==5;assert summary['Soldiers']==soldiers;assert summary['Applicable requirements']==requirements;assert summary['Ready']==ready
 assert len(x['Requirements'])==(269 if name=='short' else 1)
 if name!='short':assert summary['Ready today (%)'] is None and summary['Ready by 5 Jan (%)'] is None
 results[name]={'summary':summary,'sheetRows':{k:len(v) for k,v in x.items()}}
(r/'short-empty-workbook-comparison.json').write_text(json.dumps({'status':'PASS','results':results},indent=2));print('PASS Short268 affected rows;112-Person empty-view versus0-People, five sheets, zero requirement rows, blank readiness.')
