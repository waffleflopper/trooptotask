<script lang="ts">
	import { CalendarDate, type DateValue } from '@internationalized/date';
	import { RangeCalendar } from './index.js';

	let value = $state<{ start: DateValue | undefined; end: DateValue | undefined }>({
		start: undefined,
		end: undefined
	});
	let placeholder = $state<DateValue>(new CalendarDate(2026, 9, 30));
</script>

<RangeCalendar bind:value bind:placeholder />

<output aria-label="Selected start date">{value.start?.toString() ?? ''}</output>
<output aria-label="Selected end date">{value.end?.toString() ?? ''}</output>
