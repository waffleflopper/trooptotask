# Calendar Bulk Remove repair native proof

Status INCOMPLETE. The repaired route has historical native review and Back proof. This segment lost its owned supervisor before failure retry and final readback. It does not establish full affected-baseline acceptance.

## Frozen candidate and ownership

Exclusive checkout `/home/waffleflops/.cache/t2t-1376-calendar-persistence-owner`. Revision `4ebd0c58d7bdc57830056a2608d032526941ce0b`, tree `dec7a03a7c91480fc37e3eb0a956d4b5c2f52e70`, candidate `c348c7ead61139f923a0f99031bbc05bc80141bdf2c4f37f2bf695351980a9aa`. Launch and initial doctor both returned PASS, exit 0. Worker2 owned session `1021ceb3-08e5-4330-9cbd-0b64a496a490`, origin `http://127.0.0.1:45939`. No competing driver or alternate browser was used. The production build slot was released after launch/doctor.

Raw evidence lives at `.verification/evidence/verify-trooptotask/d28-calendar-bulk-remove-repair` in this checkout. `input-manifest.json` freezes all 5,086 executable/driving inputs, their full sizes and SHA-256 hashes. Post-disposal recomputation independently proved equal file set, every size/hash, aggregate candidate, revision/tree and clean Git state. No source, driving recipe or archive changed during this run.

## Completed observations

The actual operator Remove screen reviewed Baker Training for October 5, 2026. Native request 135 used the real canonical Organization UUID `541518e8-e8b5-4b5b-a733-700c7c6d93d2` in `/api/calendar-range`, with October 5 start/end and HTTP 200. The visible whole-entry warning identified Baker and the full saved October 4–6 span. Native Back retained Baker, Training and the selected day. Full A six/B one availability rows exactly matched originals both after review and Back, including every stored field. `baker-review-back-comparison.json` records those four comparisons. `baker-review-action.json`, `baker-review-range-state.json`, `baker-review-native-network.json`, `baker-review.png` and `baker-back-action.json` retain direct observations. The review PNG was physically inspected.

The observation hook was restored. A documented scoped synthetic range failure then returned 503 before dispatch and showed the actionable load alert with the same draft and an available Review button. `range-failure-state.json`, `range-failure-review-action.json` and physically inspected `range-failure.png` retain this observation. This proves client behavior for a synthetic failure, not a provider outage. B row readback completed. A row readback failed, so there is no A invariant credit after the synthetic failure. No confirmed removal, retry, overlap seed, scoped/empty/view-denied actor or held-range Organization switch was performed in this failed segment.

## Preserved attempts and supervisor loss

A first native select attempt supplied an option UUID and returned INCONCLUSIVE. It is preserved as `baker-status-selected.json`. A new snapshot and visible option text selection succeeded in `baker-status-native-text.json`; no application defect is inferred from the failed selection. The initial provider capture reader also ran before two capture files were complete and raised a JSON decode preparation error. All twelve original table/org captures were subsequently completed with actual helper exit 0. No data was changed by the premature read.

After synthetic failure, A readback returned exit 2 with `Map control blocked: fetch failed`; the redirected `range-failed-A.json` remains literally empty. Hook restoration then returned exit 2 with `Owned supervisor is unavailable or replaced`; `range-failure-restored.json` remains literally empty. These empty artifacts are intentionally retained and do not imply success. Doctor returned exit 2 with BLOCKED/UNOWNED_OR_UNAVAILABLE, preserved in `doctor-after-supervisor-loss.json`.

Read-only owned-state inspection found persisted phase running, absent supervisor/browser/MCP processes, and an app process still alive with matching recorded start/command identity. `supervisor-loss-owned-state.json` records those observations. The supervisor log was observed at 0 bytes. The app log was 584 bytes and had no matching failure marker in its bounded final lines. No specific supervisor termination reason is recorded, and no OOM cause is inferred. Root independently found no matching OOM kill in its bounded kernel search.

## Owned disposal and precise closure

Root authorized documented owned disposal. `npm run --silent verify:app -- cleanup --worker 2` actually completed exit 0, PASS/cleaned, with empty stderr. Literal outputs are `cleanup-after-supervisor-loss.stdout` and `.stderr`. Independent post-cleanup checks proved the worker directory absent, all four recorded process IDs absent and original port 45939 not listening. `failed-segment-closure.json` records these checks and all 5,086 frozen input checks. Its PASS is limited to integrity and owned disposal, not native verification completion. `failed-segment-inventory.json` freezes the 53 payloads excluding itself, 1,540,580 bytes, including all prior attempts.

No temporary seed or UI-created witness was created, and no fixture mutation was submitted. The failed hook restoration cannot be credited; documented disposal removed the owned browser and disposable environment instead. There is no final healthy doctor, no final A readback and no final acceptance PASS for this segment. All initial full originals remain in the raw directory. Existing and remote databases were untouched.

## Remaining bounded proof

Restart remains pending root authorization. A separate raw recovery directory must preserve this failed segment unchanged. The same source and driving recipe can be verified under a new owned session with new fixture identities and a fresh doctor. Repeat canonical review/Back, scoped 503 then restored real 200 retry, documented temporary overlap whole-entry warning and confirmed removal/reload, full historical/Baker/B sentinel preservation, scoped Alpha, explicit empty, view denial and real held A range across actual B admission/release. Use visible Organization navigation or genuine schema-supported native navigate_page Back where needed. Finish all seed-dependent comparisons before clean-seeds, restore every control/grant, final doctor and complete owned cleanup, then verify all frozen bytes/Git again. The previous broader 6adc baseline and its qualified script-based history action remain separate historical evidence.

Lower-level source proof and exact pre-refinement 7-file/19-test scope remain documented in `/home/waffleflops/.cache/t2t-1376-calendar-bulk-remove-repair-report.md`. Root owns final integration, full checks, independent acceptance, packaging, review and publication. No Calendar persistence cutover starts before the affected Remove baseline passes.
