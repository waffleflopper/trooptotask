from pathlib import Path
import json
import re

root = Path.cwd()
page = root / 'src/features/training/components/TrainingReportsPage.svelte'
detail = root / 'src/features/training/components/TrainingAffectedSoldiersSection.svelte'
focus = root / 'src/features/training/components/TrainingFocusSection.svelte'
actors = []
for path in [page, detail, focus]:
    text = path.read_text()
    for match in re.finditer(r'(?:onRetry|onclick)=\{[^}]+\}', text):
        line = text.count('\n', 0, match.start()) + 1
        actors.append({'path': str(path.relative_to(root)), 'line': line, 'handler': match.group(), 'context': text[max(0, match.start()-180):match.end()+90]})
handlers = {}
text = page.read_text()
for name in ['retryBriefing', 'retryDetail', 'clearFilters', 'exportExcel', 'focusSection']:
    match = re.search(r'(?:async )?function ' + name + r'\(', text)
    assert match, name
    handlers[name] = text[match.start():].split('\n\t}', 1)[0] + '\n\t}'
result = {
    'premise': 'The vanishing-focus gate was scoped to Retry/detail rather than every explicit action that removes its focused control.',
    'actors': actors,
    'handlerBodies': handlers,
    'observed': {'reportRetry': 'v5 BODY; v6 stable region accepted', 'detailRetry': 'stable region accepted', 'pagerBoundary': 'normal and disconnected cases accepted', 'emptyClearFilters': 'v6 BODY'},
    'sourceInferredNotYetNative': ['toolbar Clear filters shares the empty-panel handler', 'export error Retry clears its focused alert through exportError=null'],
    'candidateFixBoundary': 'Existing stable focusSection only for explicit vanishing Clear filters/export Retry actions; no response-time autofocus or shared alert rewrite.'
}
destination = root / '.verification/1504-disappearing-action-census.json'
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'actors': len(actors), 'premise': result['premise'], 'output': str(destination.relative_to(root))}))
