SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.onboarding_step_progress
WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND onboarding_id = '314c092f-7c4e-41d7-939d-331a4a7e3090'::uuid
 AND id = '5971b14f-45f7-4c5d-a5d6-9affbdc7f51a'::uuid AND template_step_id IS NULL AND step_name = 'Orientation'
 AND step_type = 'checkbox' AND completed AND active AND current_stage IS NULL
 AND training_type_id IS NULL AND stages IS NULL AND notes = '[{"text": "Legacy retained work d73013b9", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "e9ee5bc9-d349-41a4-b21f-f6f786b48e0d"}]'::jsonb
FOR UPDATE;
SELECT json_build_object('event', 'ready');
