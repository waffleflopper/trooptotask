const fs=require('node:fs/promises');
const path=require('node:path');
const ExcelJS=require(path.resolve('node_modules/exceljs'));
(async()=>{
const input='.verification/evidence/verify-trooptotask/d24-export-baseline';
const out='.verification/tmp/d24-artifact-review';
for(const name of ['owner-a','admin-a']){
const book=new ExcelJS.Workbook();await book.xlsx.readFile(path.join(input,name+'.xlsx'));
const sheets=book.worksheets.map(s=>({name:s.name,headers:s.getRow(1).values.slice(1).map(String),rows:Array.from({length:Math.max(s.rowCount-1,0)},(_,i)=>s.getRow(i+2).values.slice(1))}));
await fs.writeFile(path.join(out,name+'-expanded.json'),JSON.stringify({sheets},null,2)+'\n');
process.stdout.write(JSON.stringify({name,sheets:sheets.map(s=>({name:s.name,headers:s.headers.length,rows:s.rows.length}))})+'\n');
}
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1;});
