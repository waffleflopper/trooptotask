// @vitest-environment happy-dom
import '@testing-library/jest-dom/vitest';
import { CalendarDate } from '@internationalized/date';
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/svelte';
import RangeCalendarTest from './RangeCalendarTest.svelte';

describe('RangeCalendar cross-month keyboard focus', () => {
	afterEach(cleanup);

	it('keeps focus on the selected end date when completing a range across a month boundary', async () => {
		render(RangeCalendarTest, { initialDate: new CalendarDate(2026, 9, 30) });
		const start = screen.getByRole('button', { name: /September 30, 2026/ });
		start.focus();
		await fireEvent.keyDown(start, { key: 'Enter' });
		await fireEvent.keyDown(start, { key: 'ArrowRight' });
		const middle = await screen.findByRole('button', { name: /October 1, 2026/ });
		await waitFor(() => expect(document.activeElement).toBe(middle));
		await fireEvent.keyDown(middle, { key: 'ArrowRight' });
		const end = screen.getByRole('button', { name: /October 2, 2026/ });
		await waitFor(() => expect(document.activeElement).toBe(end));
		await fireEvent.keyDown(end, { key: ' ' });

		expect(screen.getByLabelText('Selected start date').textContent).toBe('2026-09-30');
		expect(screen.getByLabelText('Selected end date').textContent).toBe('2026-10-02');
		expect.soft(document.activeElement).toHaveAccessibleName(/October 2, 2026/);
		const selectedCells = screen.getAllByRole('gridcell', { selected: true });
		for (const date of [/September 30, 2026/, /October 1, 2026/, /October 2, 2026/]) {
			expect(selectedCells.some((cell) => within(cell).queryByRole('button', { name: date }))).toBe(true);
		}
	});
});
