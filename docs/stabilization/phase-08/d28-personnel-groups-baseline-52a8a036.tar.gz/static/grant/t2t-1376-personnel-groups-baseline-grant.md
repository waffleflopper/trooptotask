# D28 / #1376 Personnel/Groups unchanged-application baseline grant

Root grants the existing Personnel driver one owned worker1 launch, production build and complete affected native baseline. The source is Calendar-inclusive with accepted three-file verification preparation; Personnel product cutover is absent. No candidate/native/final/PR/issue acceptance is implied. Keep Calendar worker2 untouched. One heavy build is granted; release it after the actual build/doctor milestone.

Checkout: /home/waffleflops/.cache/t2t-1376-personnel-groups-owner
Branch: stabilization/1376-personnel-groups-owner
Revision: 52a8a036db7fb21af3fec5ab0d363c640753f817
Tree: 6ebc1d309f4f741ef8772fe60bb681c6f68d2c3e
Candidate: 6de035eee8f63783b4f042e7aaee9b52ddc5f51b62b46fa58b85324e44f460e7
Worker: 1
Run: d28-personnel-groups-baseline-52a8a036
Root external input and installed-dependency manifests are supplied separately. Freeze all declared file contents, symlink states, head/tree, dependencies and toolchain from this grant through actual terminal cleanup. No Git/source/helper/recipe/installed-package/toolchain/executable-driver changes while active. Dynamic sanitized run outputs and existing helper seed journals are permitted. Do not manufacture a new scenario registry.

## Commands and ownership

Use login:false and this exact PATH for every command:
/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:/home/waffleflops/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin
TMPDIR=/home/waffleflops/.cache/t2t-1376-personnel-groups-tmp
Node24.21.0/npm11.19.0/Supabase2.101.0/Docker29.7.2/Chromium152.0.7977.82.

Only npm run verify:app and documented verify-trooptotask helpers/native controls may launch or drive this owned disposable synthetic app/provider. Use actual page IDs and fresh accessible UIDs. No T3 preview/integrated browser/global Chrome/standalone Playwright/one-off browser driver, shared existing local DB, remote/production DB, new schema or arbitrary SQL. Synthetic seed/CRUD/delete and terminal owned cleanup are authorized only in this exact doctor-verified worker. No reset of existing local DB. No nested delegation, PR/comments/tracker/Git actions.

On BLOCKED doctor, stale input, unowned supervisor or source/product defect, preserve the actual failure and sanitized evidence, stop dependent mutation, restore/close the exact owned worker as supported, and report to root. A corrected fresh launch requires another root grant. Never rewrite failed observations or switch browser/provider.

## Required baseline selection

Follow the complete worker1-baseline-plan and all maintained affected recipes. Bind each actual ordered native/API/readback/lower-only action in the existing run journal. Distinguish author expectations from actual outcomes; no source analogy gives live credit.

1. Capture full original A/B Personnel, Group and all relevant member-pin rows including IDs/null/omitted fields/order before mutations. Record actual actor grants/fixture/local date and provider/app/build identities. Preserve original denominators and sentinels before seeds.
2. Roster/search/native clear/Group/A-Z, ordinary versus scoped/empty/unassigned/foreign visibility, stable-ID detail and reachable failure/current retry.
3. Tagged Group CRUD/validation/reload; controlled Add503/no dispatch/draft/retry; exact viewer same-org/foreign denial and no-effect rows. Delete a tagged Group with a tagged Person and preserve its ID/slug/dates while unassigning it.
4. Same actually admitted user Pin/Unpin/reload and reverse Calendar/Training consumers. Use initially unpinned safe names where possible. Failure rollback/current retry, actual real held200 save A to native B and quiet release, separate held503 Pin POST with no A effects. Unpin DELETE is not selected by delayed-failure mode. Capture held state before navigation can lose the hook. Native Back is distinct from scripted history. Record denied/unavailable lanes honestly.
5. Personnel create/edit/cancel/failure/current retry/nullable date clear/rank/Group/stable ID/canonical slug, empty/scope denial, hidden Bravo collisions; current boundaries remain unchanged.
6. Shared Onboarding Add Person under actual grants, exact outer selected saved Person, cancel packet without write; separate valid forbidden API probes. No packet/template owner rewrite.
7. Real CSV correction/blur/preview/no write/import and scoped collision recovery; exact created IDs/slugs/unknown Group behavior. Duplicate/Group date backfill, archived sentinel, supplied dates, stable IDs/replay/error/current retry.
8. Direct/approved/batch archive, event preservation/cascade metadata/restore/denial; actual reachable archived-only permanent removal with remaining-row sentinels. Fixture document metadata has no Storage objects and proves no file preservation.
9. Actual held Personnel save A through native scope change, quiet settled B and exact provider state. Same-ID detail/readiness/reverse Calendar/Training/ICT/Rating histories, loss distinctions, Group rename/delete labels, Dashboard/Settings/Sign-in consumers where admitted.
10. SDS known fields/save/cancel/failure/current retry and actual safe Person workbook with complete sheet/cell inspection for affected Person lookup. Award order/set/clear is separate API proof. Do not expand neighboring row-provider ownership.

SDK page sizes/chunks, code23505 named conflict/redaction/wrong-org/wrong-candidate/uncertain already committed no-replay outcomes, lifecycle acknowledgement/callback/notification partial effects, ordered pin replace/delete-then-insert failure and private filters are separate lower/API obligations. No dense browser cohort or fabricated native reorder/server provider outage is required. A synthetic503 is undispatched; held200 has reached the app. No SQL/atomicity/performance/new Storage claim.

## Restoration and close

Complete all seed-dependent comparisons before clean-seeds, which removes every journaled cohort. Restore hooks/grants/export/feedback controls and each member's exact original ordered names. Declare intentionally recreated pin IDs separately and preserve all unaffected IDs/fields; never claim literal row restoration for changed IDs. Use current app/API to restore originals and visibly remove tagged UI objects. Keep original and final raw row sets and actual failures.

Run final doctor, actual terminal owned cleanup, verify exact worker/process/origin absence and complete before/after source/external/dependency inventories. No passing launch/doctor alone is closure. Preserve all raw safe native snapshots/screenshots/statuses/provider sets/actual downloads and full workbook cells. No archive packaging, record changes or final acceptance by this driver. Root and independent artifact review own those after actual close.

Baseline observations may be PASS/ISSUES/BLOCKED/UNAVAILABLE. A discovered affected defect remains required repair and final proof. This grant does not allow product cutover. Continue only #1376; other owners/global facades and issue closure remain pending.
