# D30 #1378 final delta verification — candidate 0897bc3a

- Candidate revision: `0897bc3ace2975b8597bb78d257ab8a7fd772f0c` (branch `stabilization/1378-integrated-convergence`, detached)
- Candidate digest: `ed2ef425c469b9033a1babc006a989987cbcc07a9f8f4e2fc998ea87b55586b6`
- Worker: 2 only (worker 1 untouched). Origin `http://127.0.0.1:46417`. Browser Chromium 152.0.7977.82 (owned profile, native DevTools controls).
- Doctor: PASS at start (`doctor-start.json`) and final (`doctor-final.json`), same revision/digest/session `2afa90fb-...`. `clean-seeds` and owned `cleanup` PASS (`clean-seeds.json`, `cleanup.json`).
- Organization A `dcf712ac-c302-4e2f-8800-af57b0f2c5d2` (fixture in `fixture.json`). Scope: only the paths changed since the passing c14ccd17 final proof.
- Sanitization: no tokens, cookies or credentials captured (scanned for JWT/auth-token/secret/bearer). `b-auth/login-toggle-shown-snapshot.txt` intentionally shows the deliberately wrong synthetic password `Synthetic-Wrong-Password-1` in plain text (proof of the Show password toggle); it is not a credential. The `/auth/confirm` probe used a fabricated token hash `d30syntheticinvalidtokenhash0000`.
- Environmental console noise present on every page and not attributed to the change: `/_vercel/insights/script.js` and `/_vercel/speed-insights/script.js` (404 after sign-in / "Refused to execute script ... MIME type" before sign-in, confirmed by network status), a CSP `eval` issue, DevTools form-label "issues" and a CSS preload warning. No `Uncaught` error appeared in any capture.
- Rate-limit note: the 10-POST/15-min `/auth/*` limit hit once while signing in `dashboardNone` for Evals (visible "Too many requests. Please wait and try again."). Those two dashboardNone checks were then made by direct URL `navigate_page` on the already-signed-in dashboardNone page (11), which is the same direct-URL entry.

## (a) Lane denial repair — `a-lanes/`, `g-granted/`

Per case: `*-actor.json`, `*-snapshot.txt`, `*.png`, `*-console.txt`, `*-network.txt`, `*-pagedata.txt` (read-only same-session fetch of the route's `__data.json`, scanned for fixture Person/Training/Critical Task/Onboarding/Org B IDs, plus rendered headings).

| Route (direct URL) | Actor | Expected | Observed | Status |
|---|---|---|---|---|
| /critical-tasks | manager | Access Restricted, no data, no uncaught error | heading "Access Restricted" + "You don't have permission to view Critical Tasks..."; streamed chunk `{laneKey:"critical-tasks",access:"restricted"}`; 0 fixture IDs | live-verified |
| /training | manager | same | "Access Restricted" + "...view training..."; chunk `{laneKey:"training",access:"restricted"}`; 0 IDs | live-verified |
| /personnel | ictViewer | same | "Access Restricted" + "...view personnel..."; chunk `{laneKey:"personnel",access:"restricted"}`; 0 IDs | live-verified |
| /calendar | manager (control) | denial | "Access Restricted" + "You don't have permission to view this area..."; restricted chunk; 0 IDs | live-verified |
| /evals | manager (control) | denial | "Access Restricted" + "...view evaluations..."; restricted chunk; 0 IDs | live-verified |
| /onboarding | manager | record | framework error page: heading "403", "You don't have permission to view this page.", "Back to Dashboard" link; no uncaught error; 0 IDs (not the shared panel; Onboarding layout unchanged by this candidate) | live-verified (recorded) |
| all six | dashboardNone | same as above | CT/Training/Personnel/Calendar/Evals: same Access Restricted panel and messages, 0 IDs; Onboarding: same 403 page (document 403 logged as resource load error only) | live-verified |

Granted actors still hydrate:

| Check | Actor | Observed | Status |
|---|---|---|---|
| Calendar month statuses + reload | calendarConfigure | October 2026 grid, Alpha/Bravo/Unassigned rows; status cells "Verification Training" x3 and "Verification Retiring Status" x1 before and after reload (`cal-calendarConfigure-cells.txt`, `...-reload-cells.txt`) | live-verified |
| Training matrix | trainingView | matrix with Required/Targeted/Optional columns, Able CURRENT/NOT DONE/N/A, Baker, Unassigned rows; no foreign IDs | live-verified |
| Personnel roster | manager | Alpha/Able, Bravo/Baker, Unassigned rows (reached by client navigation, below) | live-verified |
| Critical Tasks matrix | ictConfigurator | VERIFY-ICT-ALPHA/ALL columns, Able 50% readiness, Baker, Unassigned; no foreign task | live-verified |
| Evals page | ratingView | Evals workspace (Grouped/Table, filters, Export, Overdue/60d/30d counters, "0 of 0 shown" — no rating entries seeded) with no restricted panel | live-verified |
| Restricted → granted client navigation | manager | from /critical-tasks (Access Restricted) clicked sidebar "Personnel": roster rendered, no "Access Restricted" text; resource timing shows `personnel/__data.json?x-sveltekit-invalidated=0010` (client navigation, no document load) | live-verified |

## (b) Auth UI — `b-auth/`

| Path | Observed | Status |
|---|---|---|
| /auth/login renders | "Sign in" heading, Email Address, Password, Show password, Sign In | live-verified |
| Password toggle | type password → text (button becomes "Hide password") → password (`login-toggle.txt`) | live-verified |
| Wrong password (once) | POST /auth/login?/login 200; alert "Email or password is incorrect"; form remains on /auth/login | live-verified |
| Tokenless /auth/confirm | "Link unavailable" / "This email link is invalid or has expired." with Sign In, Request Access, Reset Password, Renew Invite links | live-verified |
| Tokenless /auth/accept-invite | "Invite unavailable" / "...older format or has expired. Request a fresh invite." with renew link and sign out | live-verified |
| Manager sign-in / sign-out | `verify:app login manager` → /org/A/personnel; Account menu (Role: member, Account, Sign Out); Sign Out → `/`, public "Sign In" link, no Organization nav | live-verified |

## (c) Confirmation / invite finalization — `c-invite/`, `b-auth/confirm-fake-token-*`

- End-to-end `/auth/accept-invite` → `/api/auth/finalize-invite`: **unreachable**. Finalization requires a session whose auth flow is `invite`, established only by verifying a real invite token hash at `/auth/confirm`. The owned worker has no mail transport or token-bearing link capture (organization-invitations.md step 4: "setup completion remains unreachable until a safe control exists"). The recipe's existing-account path (Dashboard Accept) does not call finalize-invite or `autoAcceptOrgInvites`, so it would not exercise the changed signatures; it was not run.
- Partial live probes of the changed code: (1) `/auth/confirm?token_hash=<fabricated>&type=invite&next=/auth/accept-invite` rendered "Confirm your invite"; native click "Continue to Invite Setup" → POST 200 → `/auth/login?error=auth_link_invalid` with "This email link is invalid or has expired..." (the action reached `confirmAuthLink(locals, ...)` and its provider `verifyOtp` rejection). (2) Signed-in orgOwner same-origin POST `/api/auth/finalize-invite` (direct HTTP, not native UI) → 403 `{"code":"invite_not_pending",...,"accepted":0,"activated":false}`; the admitted no-pending-flow branch precedes the changed `checkSessionAssurance(locals)`/`autoAcceptOrgInvites(locals)` calls. Status: partial live-verified; acceptance/membership grant unreachable.

## (d) Admin — `d-admin/` (platformReviewer, temporary Organization from `seed platform-admin`, cleaned)

| Path | Observed | Status |
|---|---|---|
| Layout search | typed "ce88a465" in "Search platform admin records": `GET /admin/api/search?q=ce88a465` 200, option "Platform verification ce88a465 0 personnel" | live-verified |
| Org Suspend dialog | dialog "Suspend Platform verification ce88a465" with Reason, Cancel, Suspend; Cancel closed it, focus back on Suspend | live-verified |
| Org Transfer Ownership dialog | dialog with New Owner select, exact-name confirm textbox, disabled Transfer Ownership; Cancel closed it | live-verified |
| No effect | `platform-state` after dialogs: org `suspended_at` null, owner unchanged | live-verified |
| User Suspend dialog | orgCreator detail → "Suspend User" → dialog with Reason, Cancel, Suspend; Cancel closed it | live-verified |

## (e) Settings members — `e-members/` (orgOwner)

Invited `d30-delta-0897bc3a@example.test` (default Member/Editor, All groups): visible "Invitation created, but email delivery failed. You can resend it from Pending Invitations." (expected without mail transport); Pending Invitations shows the address with Resend/Revoke; provider row `996fd7bb-...` status pending; persisted after reload. Revoke → "0 pending invitations"; row status `revoked` with `revoked_at`; after reload Invitation History shows "Editor · Revoked today". Status: live-verified. The revoked history row remains until owned disposal (done).

## (f) Cron service-role adapter — `f-cron/`

Helper `retention cron missing|wrong|run audit|records|onboarding` against this owned origin with the worker-private generated credential (not recorded).

| Endpoint | missing | wrong | authorized |
|---|---|---|---|
| /api/cleanup-old-data | 401 `{"message":"Unauthorized"}` | 401 | 200 `{"auditLogsDeleted":0}` |
| /api/cleanup-archived-records | 401 | 401 | 200 `{"deletedCount":0,"orgsAffected":0,"families":[7 families: personnel-follow-ups, counseling-records, personnel-documents, leader-notes, personnel, critical-tasks, assignment-types, each deletedCount 0]}` |
| /api/cleanup-expired-onboardings | 401 | 401 | 200 `{"deletedCount":0,"orgsAffected":0}` |

No redirects. No retention seed was loaded, so zero-effect summaries are expected; this proves admission and response shape through the new adapter, not deletion effects. Status: live-verified.
