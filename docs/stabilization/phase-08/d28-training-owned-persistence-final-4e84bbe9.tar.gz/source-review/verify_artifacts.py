import collections, hashlib, json, pathlib, posixpath, re, subprocess, zipfile
import xml.etree.ElementTree as ET
ROOT = pathlib.Path('/home/waffleflops/.cache/t2t-1376-training-source-acceptance-20261007')
S = ROOT / 'd28-training-persistence-supplement-4f9ff79a/baseline'
P = ROOT / 'd28-training-person-save-focused-93ab5146/raw'
NS = {'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def read_json(p):
    value=json.loads(p.read_text())
    if isinstance(value,dict) and 'stdout' in value:
        try:return json.loads(value['stdout'])
        except json.JSONDecodeError:pass
    return value

def workbook(p):
    with zipfile.ZipFile(p) as z:
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS):
                shared.append(''.join(t.text or '' for t in si.findall('.//m:t',NS)))
        rels = {v.attrib['Id']:v.attrib['Target'] for v in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        result = {}
        for sheet in ET.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',NS):
            ref=sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
            target=rels[ref];target=posixpath.normpath('xl/'+target) if not target.startswith('/') else target[1:]
            rows=[]
            for row in ET.fromstring(z.read(target)).findall('m:sheetData/m:row',NS):
                cells={}
                for c in row.findall('m:c',NS):
                    index=0
                    for char in re.match('[A-Z]+',c.attrib['r'])[0]: index=index*26+ord(char)-64
                    v=c.find('m:v',NS);value=v.text if v is not None else None
                    if c.attrib.get('t')=='s':value=shared[int(value)] if value is not None else None
                    elif c.attrib.get('t')=='inlineStr':value=''.join(t.text or '' for t in c.findall('.//m:t',NS))
                    elif value is not None:
                        try:value=float(value);value=int(value) if value.is_integer() else value
                        except ValueError:pass
                    cells[index-1]=value
                vals=[cells.get(i) for i in range(max(cells,default=-1)+1)]
                while vals and vals[-1] is None:vals.pop()
                rows.append(vals)
            result[sheet.attrib['name']]=rows
        return result

receipts={'workbooks':[]}
for f in ROOT.glob('d28-*/*/*.xlsx'):
    w=workbook(f)
    receipts['workbooks'].append({'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'sheets':{n:len(rows) for n,rows in w.items()}})
for name in ['pages','dense','short','empty-view','empty-people']:
    actual=workbook(S/(name+'-report.xlsx'));recorded=read_json(S/(name+'-workbook-rows.json'))
    normalize=lambda rows:[next((r[:i+1] for i in range(len(r)-1,-1,-1) if r[i] is not None),[]) for r in rows]
    assert {n:normalize(r) for n,r in actual.items()}=={n:normalize(r) for n,r in recorded.items()},name
    assert list(actual)==['Summary','Forecast','Hot spots','Focus','Requirements']
    for n in actual:
        if n!='Requirements':assert len(actual[n])>0
receipts['actualWorkbookXMLMatchesRecordedReaders']=5
seed=read_json(S/'print-seed.json');actual=workbook(S/'dense-report.xlsx');expected=[]
for person in range(1,113):
    group=(person-1)//8;slot=(person-1)%8+1
    for i,t in enumerate(seed['types']):
        if i==0:
            if person>100:continue
            status,expiry,lapse,flag='Not Done',None,None,'No'
        else:
            if i==23 and group>=7:continue
            if slot>6:continue
            status,expiry,lapse,flag={1:('Not Done',None,None,'No'),2:('Not Done',None,None,'No'),3:('Expired 20d ago','2026-09-17',None,'No'),4:('Expired 5d ago','2026-10-02',None,'No'),5:('10d left','2026-10-17','2026-10-18','Yes'),6:('30d left','2026-11-06','2026-11-07','Yes')}[slot]
        expected.append(['PFC',f'PrintA{seed["tag"]}{person:03d}, Synthetic',seed['groups'][group]['name'],t['name'],status,expiry,lapse,flag])
expected.sort(key=lambda r:(r[5] is not None,r[5] or '',r[1],next(i for i,t in enumerate(seed['types']) if t['name']==r[3])))
assert len(expected)==1990 and actual['Requirements'][1:]==expected
receipts['denseLiteralRows']={'exact':1990,'statuses':dict(collections.Counter(r[4] for r in expected))}
for name,people,req,ready,affected in [('pages',29,31,1,30),('dense',112,2632,1272,1990),('short',112,336,124,268),('empty-view',112,0,0,0),('empty-people',0,0,0,0)]:
    w=workbook(S/(name+'-report.xlsx'));summary={r[0]:r[1] if len(r)>1 else None for r in w['Summary'][1:]}
    assert summary['Soldiers']==people and summary['Applicable requirements']==req and summary['Ready']==ready and len(w['Requirements'])-1==affected
    if not affected:assert summary['Ready today (%)'] is None and summary['Ready by 5 Jan (%)'] is None
receipts['literalSummaryAndEmptyDistinctions']=True
original=read_json(P/'original-completions.json')['rows'];failed=read_json(P/'failed-row.json')['rows'];retry=read_json(P/'retry-row.json')['rows'];restored=read_json(P/'restore-keyboard-rows.json')['rows']
assert original==failed
for key in original[0]:
    if key not in ['notes','certificate_url','updated_at']:assert retry[0][key]==original[0][key]
    if key!='updated_at':assert restored[0][key]==original[0][key]
assert retry[0]['notes']=='D28 retry draft retained' and retry[0]['certificate_url']=='https://example.test/d28-retry'
wire=read_json(P/'retry-wire.json');wire=wire['structuredContent']['networkRequest'];assert wire['status']=='200';assert json.loads(wire['responseBody'])['id']==original[0]['id']
receipts['personFailureRetryRestoration']={'failedRowExact':True,'retryIdentityDatesAndDraftExact':True,'restoredExceptUpdatedAt':True,'wireStatus':wire['status']}
for org in ['orgA','orgB']:
    for table in ['training_types','training_views','personnel_trainings','personnel']:
        before=read_json(S/f'original-{org}-{table}.json')['rows'];after=read_json(S/f'afterclean-{org}-{table}.json')['rows']
        assert sorted(before,key=lambda r:r['id'])==sorted(after,key=lambda r:r['id'])
journal=read_json(S/'precleanup-seed-journal.json');n=0
for target in journal['seeded']:
    after=read_json(S/f'afterclean-orgA-{target["table"]}.json')['rows'];assert not set(target['ids']) & {r['id'] for r in after};n+=len(target['ids'])
assert n==2081
post=read_json(S/'postcleanup-seed-journal.json');assert not post['seeded'] and not post['grants']
temp_groups={i for t in journal['seeded'] if t['table']=='groups' for i in t['ids']}
before=[r for r in read_json(S/'precleanup-orgA-groups.json')['rows'] if r['id'] not in temp_groups];after=read_json(S/'afterclean-orgA-groups.json')['rows'];assert sorted(before,key=lambda r:r['id'])==sorted(after,key=lambda r:r['id']) and len(after)==2
receipts['supplementRestoration']={'eightOriginalSetsAllFieldsExact':True,'temporaryIDsAbsent':n,'twoOriginalGroupsExact':True,'journalsEmpty':True}
(ROOT/'artifact-content-verification.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipts.items() if k!='workbooks'},indent=2));print('Workbook files parsed',len(receipts['workbooks']))
