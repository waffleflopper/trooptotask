import json
import native_driver as n

fixture = json.loads((n.ROOT / 'fixture.json').read_text())
ids = fixture['ids']
rows = json.loads((n.ROOT / 'upsert-saved-rows.json').read_text())['rows']
able = next(row for row in rows if row['personnel_id'] == ids['personA'] and row['ict_task_id'] == ids['ictTaskGeneral'])
baker = next(row for row in rows if row['personnel_id'] == ids['personB'])
verdicts = []
for role in ['ictViewer', 'ictScoped', 'ictEmpty', 'ictForeign', 'rosterManager']:
    actor = n.control(['actor', role, 'critical-tasks'], role + '-login')
    n.PAGE = actor['pageId']
    visible = n.snap(role + '-matrix')
    if role == 'ictViewer':
        assert 'button "Record Completion"' not in visible and 'button "Import Completions"' not in visible
    if role == 'ictScoped':
        assert 'Able, Synthetic' in visible and 'Baker, Synthetic' not in visible and 'Unassigned, Synthetic' not in visible
    if role == 'ictEmpty':
        assert 'Able, Synthetic' not in visible and 'Baker, Synthetic' not in visible
    if role == 'ictForeign':
        assert 'VERIFY-ICT-FOREIGN' in visible and 'VERIFY-ICT-ALPHA' not in visible and 'Able, Synthetic' not in visible
    before_a = n.control(['rows', 'personnel_ict_completions', 'orgA'], role + '-before-a')['rows']
    before_b = n.control(['rows', 'personnel_ict_completions', 'orgB'], role + '-before-b')['rows']
    target = baker if role == 'ictScoped' else able
    last_name = 'Baker' if role == 'ictScoped' else 'Able'
    marker = 'D28 denied ' + role
    payload = {'personnelId': target['personnel_id'], 'ictTaskId': target['ict_task_id'], 'completedAt': fixture['dates']['uiBefore'], 'validationMethod': 'Demonstration', 'validatedBy': 'D28 denied validator', 'notes': marker}
    batch = {'records': [{'rowNumber': 2, 'values': {'firstName': 'Synthetic', 'lastName': last_name, 'taskCode': 'VERIFY-ICT-ALL', 'completedAt': fixture['dates']['uiBefore'], 'validationMethod': 'Demonstration', 'validatedBy': 'D28 denied validator', 'notes': marker}}]}
    path = '/org/' + ids['orgA'] + '/api/personnel-ict-completions'
    requests = [{'path': path, 'method': 'POST', 'submitted': payload}, {'path': path, 'method': 'PUT', 'submitted': {**payload, 'id': target['id']}}, {'path': path, 'method': 'DELETE', 'submitted': {'id': target['id']}}, {'path': path + '/batch', 'method': 'POST', 'submitted': batch}]
    results = n.http(requests, role + '-valid-denials')
    for result in results[:3]:
        assert result['status'] in [403, 404], result
    result = results[3]
    if result['status'] == 200:
        body = json.loads(result['body'])
        assert body['inserted'] == [] and body['updated'] == [] and len(body['errors']) > 0
    else:
        assert result['status'] in [403, 404], result
    after_a = n.control(['rows', 'personnel_ict_completions', 'orgA'], role + '-after-a')['rows']
    after_b = n.control(['rows', 'personnel_ict_completions', 'orgB'], role + '-after-b')['rows']
    assert after_a == before_a and after_b == before_b
    verdicts.append({'role': role, 'pageId': n.PAGE, 'statuses': [result['status'] for result in results], 'unchangedA': True, 'unchangedB': True})
(n.ROOT / 'denial-verdicts.json').write_text(json.dumps(verdicts, indent=2) + '\n')
print('FIVE native actors plus valid HTTP POST/PUT/DELETE/batch denials PASS')
