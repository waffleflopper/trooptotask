# Independent nonvisual final-attempt-v3 artifact review

## Bounded verdict

**V3 does not establish final acceptance.** The expanded records support the specified original/dates/detail/native workbook journeys, the ordinary stable-count two-page keyboard boundary and Retry behavior, the proportional access spot-check after the main merge, and exact restoration of the recorded fixture scope. The print failure remains: both actual saved PDFs have an additional textless portrait page. The source-derived disconnected-pager P2 remains open at the live pin; this run does not exercise shrinking the affected count to one page. Dependent print cases are UNRUN.

This is an independent Standards + Spec **artifact analysis**, using the same inherited model. I did not drive the app, run tests/gates/services, inspect images, judge rendered PDF appearance, or independently execute the native journeys. No model diversity or independent live execution is claimed. I reused the supplied portable Poteto persona, current t2t defaults, prior requirements/source/consumer reviews and prior expanded artifact reviews within the parent's narrower read-only authority. The only review write is this report.

The driver owns visual judgments; this report only corroborates document metadata, extracted text, accessibility snapshots, saved request observations, literal provider readbacks, and actual XLSX ZIP/XML. A capture-control PASS establishes capture/identity, not product print acceptance.

## Pins and integrity

All paths below are relative to `.verification/packaged/1504/final-attempt-v3/` unless otherwise specified.

| Binding | Actual value |
|---|---|
| Live HEAD | `068348401a486cda9d7af740ea5166cf8df34009` |
| Live base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Candidate | `cf12aef243d2e9ffb9860c926381c4961306997ae1ced2f8c558aa5a1b2f0c0d` |
| Session | `4ff43aa1-0899-40fd-9d53-9fe519862f7e` |
| Worker/origin | Worker 1; `http://127.0.0.1:34391` |
| Browser | Chromium 152.0.7977.82 Arch Linux, `/usr/bin/chromium` |
| Archive | `docs/verification/training-reports-1504/final-attempt-v3.tar.gz`, 5,452,614 bytes |
| Archive SHA256 | `0231f92582ce913d59ff37e09cfd9a5316a33b6dbe5f4f734e8abb68f44791cc` |
| Inventory SHA256 | `752578e9283ff84f78f20230e3d53ab8fc0459e6959118d6289c102720be904a` (145,707 bytes) |
| Action-index SHA256 | `97993f27c06431abd31c2c452786b4900f060e945b9368e2626483db8c21835a` (234,154 bytes) |

I independently reconciled all **1,015 unique inventoried payloads**, their SHA256/byte sizes, the expanded file set, and tar-member bytes. There are 1,016 regular expanded/tar files when the inventory itself is included. No missing/extra payload, mismatched hash/size, duplicate tar payload, unsafe traversal, or symlink was found. I scanned all 980 fully UTF-8-decodable regular files, including the inventory, plus all 83 actual XLSX XML parts for the identified token/private-key patterns. No hit or redaction was found. This is a bounded pattern scan, not a general proof about every conceivable secret representation.

`root-source-checkpoint.json` contains all 139 reviewed PR paths and HEAD SHA256/deletion states. Every path and hash/deletion state agrees with my previously pinned complete source census in `.verification/1504-independent-final-source-review-v1.md`; there are no extra or mismatching entries. Its `sourcePatchSha256=11a85725a5755138d385c8755cd2cf398c50e12bb2a416b568ee7da74349bae3` is an artifact checkpoint value; I do not equate it with my separately serialized complete binary-diff hash `23e1742077c76ca83c7e06ee5f2c9c036b48186bc229bf46db3759d5186809d6`. Per-file continuity is the independent binding.

`root-launch.json`, start/closeout/after-seed doctors and driver `000-doctor`/`327-doctor-final` agree on candidate, session, revision, browser and origin. Native `list_pages` has actual `structuredContent.pages`, including numeric page IDs and isolated contexts, rather than a text-only list. `gate-binding.json` binds the seven saved v4 command logs to this HEAD with SHA256; my preceding source review read those actual logs: 689 test files/6,880 tests; check 0 errors/0 warnings; lint 15 warnings/0 errors; production build PASS. No command was rerun in this artifact review.

Root reports the archive/architecture wording were subsequently committed as `f19c6993`, then a separate correction as `53ab7cc9997746e243817fb4a283d99b0d3a0825`. These are post-live successors, **not** the v3 tested source. I did not inspect/certify either correction here. The live candidate does not become their acceptance evidence.

## Receipt accounting and native/read-only boundaries

The actual index contains **415 unique indexed command receipts: 412 exit 0 and 3 exit 2**, with all stdout/stderr pairs present. These are commands/observations/helpers, not 415 native end-user actions. The native tool set includes 43 clicks, 48 press-key calls, 10 navigations, 53 snapshots, 17 screenshots, 55 waits, 7 resizes, 3 hovers and 1 fill; other receipts are read-only script observations, request lists, doctor and documented control operations. Seven actor helper receipts create the separately isolated actor journeys.

The three failures are preserved:

| Receipt | Actual failed condition and bounded repair |
|---|---|
| `149-wait` | Timed out waiting for “Rows 1–28 of 28” after Arrow roving focus, before selection. Subsequent native Enter `154`–`157` selected 100 and showed 28 rows. |
| `269-wait` | Text-match timeout on page 8; `270-rm-training.txt` shows the actual loaded Training matrix. It is not proof the requested exact combined text existed. |
| `288-click-baker-details` | An empty UID was passed while still on the person page. `291`–`296` used the actual Roster link and Baker Details affordance. The invalid click itself proves no journey. |

There is also an exit-0 no-op: `069-focus-before-next` shows the 25 rows radio rather than Next, and `073-state-held` has no calls/no held response. The next Tab `074`, focus observation `075` and Enter `076` establish the actual Next attempt. I do not count `071` as successful paging.

53 snapshot destinations and the 17 screenshot `filePath` arguments are unique. Snapshot/screenshot/receipt/print scripts explicitly refuse reused destinations. All 59 snapshot/saved workbook/PDF destination values extracted from structured receipts are distinct. There is no v3 overwritten-name evidence comparable to the v1 omissions. The first driver receipt is 2026-10-04T12:43:39-08:00, the final page list is 13:15:40-08:00.

The 27 PNGs are **8 individual PDF page rasters, 17 native screenshots, and 2 montages**. They are not 27 different PDF pages. No PNG was viewed here. The eight PDF raster paths correspond to pages 1–6 of the long PDF and 1–2 of the short PDF; each has one raster, unlike the duplicate-resolution v2 census.

## Independently derived literal expectations and observed effects

Expectations below come from the untouched fixture/readbacks, known applicability rules, dates and elementary pair counts; I did not import the app's report calculators or treat the driver's decoded JSON as an oracle.

A has Able/Alpha/SPC/68W/Medic, Baker/Bravo/SPC/11B/NCO and Unassigned/SPC/68W/NCO. Required applies to all three; Targeted applies to Able because the NCO exclusion wins for Unassigned and Baker does not match MOS; Optional contributes no required pair. That gives four applicable pairs. The original Able Required completion is 2026-09-27, expiration 2027-09-27. Fixture day is **2026-10-04**, goal 90, horizon end **2027-01-02**.

| State | Independently expected | Actual primary receipts/snapshots |
|---|---|---|
| Original A | 3 people, 4 applicable pairs; Ready 1, expired 0, missing 3, lapse 0; 25% today/end. Required risk 2/0 before Targeted 1/0. | `004-matrix-original.txt`, `007-report-original.txt`; real Reports navigation `005`. `008-network-load` shows one report `__data.json` GET and no duplicate report-summary fetch in that observed list. |
| Original Required cell / Targeted Focus | Required cell Baker then Unassigned, both missing. Targeted standing-gap focus Able only. Cell and Focus are distinct server selectors; each opens/focuses the affected SECTION. | Native `009`, `014`; full rows `012`, `017`; focus `011`, `016`; actual cell/focus URLs and GET 200 in `018-network-detail`. |
| Dated A | Baker Required 2024-10-04 → 2025-10-04: expired 365 days. Able Targeted 2025-10-19 → 2026-10-19: 15 days left, lapses 2026-10-20. Ready 2, expired 1, missing 1, lapse 1; 50% → 25%. Required risk 2/0; Targeted 0/1. | CSV `accept/p2-import.csv`, preview `027-preview.txt`, unchanged provider count 1 at `028`, real two-person POST 200 `033-network-state`, full provider rows `039`, visible reload `038`, dated report `042`. |
| Dated exact detail | Required Total missing Unassigned precedes expired Baker; Alpha × Targeted is only Able, warning/Yes. | Full rows `045`, `048`; `049-focus` shows SECTION, 1–1 of 1. |
| Seeded A | Ledgered 26-person seed, tag `bca355c4`, adds 26 Required plus Targeted for seed00: 29 people/31 pairs, Ready 2, expired 1, missing 28, lapse 1; rounded 6% → 3%. Required risk 28/0; Targeted 1/1. | `058-seed-training-pages` count26/first ID `6d241e8d-d3f5-4312-856b-ab389a8f9ae0`; `061-report-seeded.txt`; exact rows `065`, `082`. |
| Seeded Required paging | Total28; page1 temp00–24, page2 temp25, Unassigned, Baker. No duplication/omission across the two observed pages. | 25 actual row strings at `065`; 3 at `082`, count/range/focus `064`, `081`. |

The import created **only** the two recorded new completion IDs `7df5c11b-5c20-4fa4-a209-77269860fd5c` (Baker Required) and `f7637031-4d59-4dc7-a304-747a86f01528` (Able Targeted). The original `abc75aa0-d102-4d7b-a130-280cc9b242cd` remains unchanged in the full dated and restored rows. This is current import/transport evidence; the original completion mutation authorization matrix was not rerun.

Visible original/dates/seeded Focus facts agree with the source-owned model: original Required standing gap 25→75 and Targeted gap 25→50; dated Required standing gap 25→75 plus Alpha Targeted 50→100 in Alpha scope; seeded Required 3→94 and Targeted 3→10. These fixtures have two Focus cards. They support those literal values and scopes; they do not newly prove a maximum-three selection under four eligible candidates. That remains pinned source/earlier meaningful test coverage.

### Keyboard, loading and retry

- **Next, count28/page2:** `075` focuses enabled Next. Native Enter `076`; `077` shows Next remains active/enabled, `aria-busy=true`, “Loading page 2” and honest prior range 1–25. `078` confirms a held real GET200. Release `079`; `081` shows SECTION focus, actual rows26–28, Next disabled.
- **Previous back to page1:** `086` focuses enabled Previous; Enter `088`; `089` retains its focus and prior rows26–28 while busy. Release `090`; `092` shows SECTION focus and rows1–25.
- **No focus stealing:** Enter `098` holds page2; Shift+Tab `099` moves to the ordinary 25 radio. `100` and `103` show that same radio active before and after release, while rows change to26–28.
- **Page-change synthetic503:** `111` retains page2's three rows/range, Previous focus and an honest 503 alert (“Showing the page that loaded before”); `112` records the injected503. The failure is client-side injection, not a real backend outage/status in DevTools. Native Enter on Retry `118` focuses SECTION during the hold `119`, retains the old range while requesting page1, and after the real successful response `122` shows SECTION/rows1–25/no alert. `125-net` includes the final actual page1 GET200; no claim that the injected failure is a native-network503.
- **Initial synthetic503:** `130` shows SECTION, truthful alert and no range/data. After native Retry `136`, `137` shows SECTION/busy/loading; its five tbody elements are loading placeholders, not five fetched soldiers. `140`/`141` show the two actual Targeted rows and SECTION after release.
- Native Enter selecting100 yields 28 rows/no pager and preserves focus on100 (`157`); selecting25 restores 25/pager and25 focus (`161`). Horizon180 changes the URL/closes detail with ordinary button focus (`165`/`167`); back90 restores the empty query/`90 D` focus (`169`/`171`).
- At widths390/1024/1440, the actual `227-before-*` observations have Retry active; native Enter `228-*` leads to SECTION, exact two dated Required rows and no alert in `230-after-*`. This is focus/data evidence only, with no layout or clipping verdict. Viewport restoration is `232`.

**Limits:** live middle-page behavior is UNRUN (two-page fixture), same-count paging does not test the disconnected-pager case, and v3 does not repeat detail-selector races, late-response/scope guards or all query dimensions from v1. Their prior artifacts and complete source continuity retain their prior qualified meaning; v3 cannot retroactively repair missing v1 captures.

## Actual workbook ZIP/XML review

I independently read all seven real XLSX ZIP containers, workbook relationships, ordered sheet declarations, shared/inline string cells and every worksheet XML. The six report books have exactly **Summary / Forecast / Hot spots / Focus / Requirements** in that order. Values are literal cells, with no formula elements. Person's separate four-sheet export is retained. No app calculator or supplied `.decoded.json` result was used as expected truth.

| Actual workbook | Transport / bytes / SHA256 | Independently checked content |
|---|---|---|
| `accept/xlsx/dated-unfiltered-detail-open.xlsx` | Native page2 click `052`, GET200/MIME/disposition `054`, save `055`; 11,859; `1f08175e648bd728a8f7764727a2b58c402497765371711a267fead12061e55d` | 3 people/4pairs/2ready/1expired/1missing/1lapse/goal90,50→25/drop25; exactly3 affected rows although the open Alpha detail has1. |
| `accept/xlsx/trainingView-A.xlsx` | Native page3 `239`, GET200 `240`, save `241`; 11,858; `c01df29652553335a0940f573fc0bd76284d7bbae5d2eb796b5274ced2a5245c` | All five sheet cell values match dated A; native view-only admission/download supported. |
| `accept/xlsx/api-rosterScoped-default.xlsx` | Ordinary authenticated page4 GET `248`; 11,558; `8c1bd63236ed323a6758eeda805b2217d26bb3f07111be82ba46476dbfccb66e` | 1person/2pairs/2ready/1lapse,100→50; only Alpha+Total hotspots and Able Targeted affected row. |
| `accept/xlsx/api-rosterScoped-group-bravo.xlsx` | Ordinary page4 GET `249`; 11,223; `c88fd6da98f49fef963fedd3f6fffb6ef5e89c8d5557f2e57c78a6cfdc065206` | Catalog label Scope/Group Bravo retained, but0people/0pairs/allcounts0; percentage/drop cells absent, not 0% readiness; Requirements header only. |
| `accept/xlsx/api-trainingEmpty.xlsx` | Ordinary page5 GET `254`; 11,219; `45cf9da66d92f1b1e3336fe4971b1bdaabd30265efada7beddaf25245c19880b` | All five sheets,0people/0pairs, no affected rows; Total row0/blank percent, empty Focus text; visible disabled button is not a native download. |
| `accept/xlsx/trainingForeign-B.xlsx` | Native page7 `264`, save `265`, DevTools request142 GET B export200 `267`; 11,468; `d91de3865d3076c582a108a2c326899cfeede3d0872366ca0a784f5e1e7be9d0` | OrgB/1person/1pair/0ready/1missing/0lapse/0→0; Foreign+Total; Focus0→100; only Foreign Private Training/Foreign affected row. No A cell values. |
| `accept/xlsx/person-able.xlsx` | Native page8 Export records `279`, GET200 `282`, save `283`; 9,386; `5627a4ea5a35b42a95942c09548fd9d36a1a6f77ceba31a3d79c2037e641c00f` | Exactly Personnel Info / Training Records / Counseling Records / Availability History. Able SPC/68W/Medic/Alpha. Two actual Training Records with exact completion/expiration/notes; other two history sheets headers only. |

For the three API books I independently base64-decoded the corresponding raw receipt return and matched every byte against the packaged XLSX. All were200 with the expected XLSX MIME and report filename. This is ordinary read-request proof, not native download proof.

Every report Forecast has the today row plus13 week endpoints through2027-01-02. Dated A keeps2ready/50% onOct4,11,18; Oct25 has1ready/25% and exactly1 lapse in19–25Oct; remaining endpoints keep1ready/25% with0lapses. The scoped Alpha version is100→50 with the same one lapse; empty versions have0ready/blank percentage, no lapses; Foreign has0ready/0% and no lapses. All weekly cliff flags are No for these fixtures.

Dated Hot spots: Bravo and Unassigned are0→0; Alpha100→50; Total50→25. Required total33%/drop0, Targeted total100%/drop100. Dated Focus literal before/after values are25→75 for2 Required soldiers/2 requirements and Alpha50→100 for1/1. Requirements are, in order: Unassigned Required Not Done/No (empty group/dates); Baker Required Expired365d/2025-10-04/No; Able Targeted15d/2026-10-19/lapse2026-10-20/Yes. There are no original Able-current Required, optional, inapplicable, foreign or pagination-only omissions in the dated book.

This proves current full-filtered three-row export independent of a one-row active detail. It is a proportional transport/scope smoke, not a new >25-row export proof. Larger unpaginated v1 evidence stays bound to its older candidate through the separate source-continuity review.

## Access after the main merge and retained consumers

Native roles bind to isolated pages2–8 and context UUIDs in actor receipts and final structured `328-list-pages`: trainingConfigure2, trainingView3, rosterScoped4, trainingEmpty5, viewer6, trainingForeign7, rosterManager8. Actor helper `access:not-assessed` is not authorization proof by itself. Actual UI, valid authenticated requests and parsed bytes provide the following bounded proof.

| Actor | Actual observations / request results |
|---|---|
| trainingView A | `235-trainingView-report.txt` has3people50→25/risk2/0,0/1 and enabled export/print. `236-probe`: A summary/detail/export200, Required detail2/Baker+Unassigned; B summary/export404 “Organization not found”. Native A book matches all literal rows. |
| rosterScoped Alpha | `246-rosterScoped-report.txt` has1person/2ready/100→50/lapse1; Targeted risk0/1 precedes Required0/0. `247`: default A summary200/count1; Required detail200/total0; explicit Bravo filter summary/detail200/count0; Bravo row selector404 “Training report scope not found”; foreign group normalizes to owned Alpha scope/count1; B summary404. Actual default/Bravo books corroborate scope. The owned Bravo catalog label is not an outside soldier row. |
| trainingEmpty | `252-trainingEmpty-report.txt`:0soldiers/honest no-applicable state, export disabled. `253`:summary/detail0, explicit Alpha remains0. Actual authenticated export is five-sheet header-only Requirements; no native click/download is claimed. |
| viewer, no Training | `256-viewer-report.txt`:403 permission page. Valid A summary/detail/export requests at `257` are403 “requires Training can view”. The outer `__data.json` HTTP status is200; `258` preserves a report node `type:error,status:403`, not a200 briefing. |
| trainingForeign B | `261-foreign-report.txt`:B1person/0%/Foreign Private Training only. `262`:Bsummary/detail200/count1/Foreign; A summary/detail/export404; A type on B detail404; A group on B summary normalizes to B/count1. Actual native B book and page7 request142 in `267` are correctly B-bound, repairing v1's unavailable HTTP-status evidence in a fresh run. |

`accept/probe.sh` reads the full response text before summarizing byte length, known-name regex matches, first counts/top keys and short errors. The saved successful probes are **summaries, not full response-body archives**. They scan the whole body for the named fixture strings rather than clipping to4,000 characters, but absence of those strings is not universal field-by-field non-disclosure proof. The actual scoped/empty/foreign XLSX and UI reinforce the intended soldier scope. The short denied/error bodies fit in the recorded300-character error field. `258` contains node descriptors/lengths/error preview rather than the full Svelte payload; it supports node denial/known-name absence, not a blanket “no data of any kind” statement about the outer200response.

There are no malformed400 requests substituted for403/concealed404 authorization proof. No completion mutation-denial matrix, provider/RLS attack test, direct database policy proof, remote claim or every-feature authorization sweep is established.

Selected retained consumers are fresh:
- Training matrix reload reflects dated cells and final original state, including `038`, `270`, `324`.
- Page8 Personnel Able Training card:1due/Targeted15d; Baker card:1due/Requiredexpired365d. Actual snapshots `276-able-details.txt`, `296-baker-details.txt`.
- The distinct Person workbook preserves the two complete Training Records.
- `299-dashboard.txt` has1personexpired/Bravo(1),1trainingitemexpiringsoon and33%trainingcurrent/1expired/1expiring. Dashboard's currency excludes warning from current; its3person denominator differs from the report's4applicablepair readiness. The33% vs50% is expected, not a report regression.

**Unavailable lanes remain unavailable:** both Personnel snapshots show Availability, Critical Tasks and Rating Scheme “could not be loaded”, plus Missing ETS. Those flows did not pass. The prior source/actor contracts explain rosterManager's limited independent lanes; v3 does not diagnose every unavailable network path. No fresh Personnel reader without Training, Onboarding write journey, raw Organization export write journey, whole feature-map coverage, Organization/session race or many-type print is claimed. Historical limited v1 consumer observations and unchanged-source/test coverage retain only their original scope.

## Native print and the retained failure

Both saved PDFs have actual pre-capture invocation evidence, not a beforeprint0 rendering-only attempt. The print script sequence and index independently show arm→native Print brief click→state **before save**→structured list_pages→exact page2 full URL→save→restore. Context is trainingConfigure's isolated page2; URLs and candidate/session in the saved-control outputs agree with the dispatch. Actual file bytes/hash match those outputs.

| PDF | Metadata/text findings (no visual judgment) |
|---|---|
| `accept/pdf/seeded-25-row-detail-light.pdf` | 263,343 bytes; SHA256 `e06321ebad86b5c4db3ea6b84f751652f007738be47b8b319a17fab70c172d0c`. `177-d`:before1/after0 **before** `177-f` save.6pages:1–5landscape792×612;6portrait612×792 with zero nonblank extracted text. |
| `accept/pdf/empty-bravo-targeted-light.pdf` | 70,508 bytes; SHA256 `a90430ace8c9317720720bc3c8ffdb06a8756377136a3274c8696915184ea11d`. `199-d`:before1/after0 before `199-f` save.2pages:p1landscape792×612;p2portrait612×792 with zero nonblank extracted text. |

I read actual PDF metadata/text independently, not just the packaged `.info.txt`/`.txt`. The long PDF text has title/filters/29people/6→3/counts2,1,28,1; Forecast/goal90 and dated ticks; type risks28/0 and1/1; Focus3→94 and3→10; the detail range1–25of28. Pages4–5 have the25 loaded Required rows, temp00–18 then19–24. The unshown temp25/Unassigned/Baker are not silently printed as loaded rows. Short p1 has OrgA/1soldier/as-of4Oct, Bravo/Targeted/all other displayed filters and the honest no-applicable message. Trailing pages contain only the extraction page terminator. Text presence supports content facts; it does not establish positioning, contrast, clipping, raster blankness or semantic-color legibility.

**F1 — existing P1, unresolved at this live pin.** The short-brief requirement is exactly one landscape page, whereas actual v3 short output has2pages including a textless portrait2. Long output also gains a textless portrait6. These are falsifiable metadata/text failures consistent with the driver's visual P1, with severity retained from that accepted visual finding. I do not independently assert “0 nonwhite pixels” or determine a CSS root cause. Minimal next evidence: correction owner addresses the extra default-page content/flow, then a fresh pinned native invocation/save verifies the short count1/no trailing portrait and all dependent print states. Same old PDFs cannot verify a future fix.

`205-census-read`/`206-census-reread` explicitly say `src:beforeprint, print:false`. Screen ancestor heights2053/report373.5 do **not** measure print layout. CSSOM rules being loaded (`207`) do not establish their paged effect. `208-body-outside-app` records a static zero-height SECTION sibling after the app at screen top2053; identifying it as Sonner and blaming the portrait page remains a hypothesis, not proven causation. Print layout heights are **UNAVAILABLE**.

The 2+6 page files are both failures; their capture PASSs are not product PASSs. Dependent **dark empty, dated unfiltered light/dark, Alpha detail, failed-refresh alert,1920collapsed-sidebar forecast** are UNRUN under the stopping rule. Unchanged-page rendered print and many-type print remain UNRUN. No full visual acceptance is certified here.

Post-print native Clear filters `211` and `213-url` (“svgs:2”) demonstrate a usable full dated report after the empty document's print. `209-console` retains CSP/Vercel insights404/MIME/preload noise. This empty print had no chart, so its lack of LayerCake warnings does not qualify/clear the earlier chart-print warnings. The driver correctly keeps that limit.

## Original P2 and claim qualification

**F2 — existing source P2, OPEN at v3 pin.** My pinned `.verification/1504-independent-final-source-review-v1.md` F1 identifies `src/features/training/components/TrainingAffectedSoldiersSection.svelte:62–63` at0683484: focus restoration tests only `pager.disabled`; the shared pager disappears when totalPages becomes1; a delayed real detail result can shrink count≤25/clamp to page1/remove the previously focused enabled button, leaving BODY. Minimal correction was to include disconnected pager identity in the existing user-focus guard and prove both delayed-shrink and moved-focus-negative outcomes. V3 holds/release with count fixed28, so it cannot falsify this failure. No later fix, tests or artifact are accepted by this report. Root was notified of this before the later correction.

The driver's “One blocker”/“K1 PASS” is justified for the driver's ordinary stable-count lane, **not** as a complete source+artifact acceptance statement. Composed acceptance must retain both the existing print failure and source P2 until a distinct reviewed correction/fresh proof. Likewise:
- “Reverse consumers pass” is bounded to the available Training cards/matrix/Person workbook/Dashboard, not all unavailable independent lanes.
- “No briefing or names” in the viewer description means the error report node and recorded fixture-name scan; it should not be expanded to blanket empty outer `__data.json`.
- “Every control restored” is supported by22 restore receipts returning `restored:true`, relevant subsequent real requests/reloads and final destruction of the private profile. There is no independent reviewer browser interrogation.
- “All original rows/preferences restored” means the eight named A/B table captures and one named trainingConfigure preference/progress capture, not every database table/account/page in the product.
- Driver visual claims about acceptable content pages, no clipping, absence of app chrome, pixel blankness and responsive appearance remain the driver's claims. This nonvisual lane only verifies metadata/text/snapshots and receipt bindings.

No new actionable artifact contradiction beyond these qualified/open findings was found. The driver's report otherwise preserves the failed attempts, unavailable census, unrun dependency cases and scope honestly.

## Exact restoration and cleanup

I independently compared actual parsed JSON, every field and original/restored byte hashes; I also parsed the driver's `326-final-*` values and compared them to untouched root originals. **All nine comparisons agree**:

| Recorded scope | Original/restored full-file SHA256 (identical) |
|---|---|
| personnel_trainings A (1original row) | `48fdf7ac9cea6432620d7a2bf80a1dc534791542b8b0f0a5d16693ba75c58f1e` |
| personnel_trainings B (0) | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| training_types A (3) | `40a48dbf13b4c77b500a43e331fccf29a2df5552920a6265e2b12889acf79ea6` |
| training_types B (1) | `dc04ec6e7c9c4cad0dc4aa8993aac4df1ee5de459002ad679b0eba60b2c8f4cc` |
| training_views A (1) | `db676786ea13cb8421a316da4bcd0d647b9563e4cc64b77c7eb0a524ce743123` |
| training_views B (1) | `0f52e9188c2bae9b9e21f333af0ba66357e25f34f932575d229b292ed519a159` |
| organizations A (1) | `4fc6670b99498ecabba083a5095635ba05b7b1b1154edadfd71b548e04a38b32` |
| organizations B (1) | `a7d66187d434875ca1ad757b92fe6bbf60aee3384112efa530ea63011d53a047` |
| trainingConfigure A preferences/progress [] | `4601fda26402d1c1c7667988667095f0869b5f2a5f17255ca1e39ecf0714eff7` |

Visible delete affordances/confirmation snapshots and `310-state`/`320-state` preserve two actual DELETE200s. `312-rows` shows original Able Required plus only the still-unremoved Able Targeted; final `326` shows only the unchanged original. Seeds were journal-cleaned at `178`, then root `root-clean-seeds.json` returns cleaned/artifactHttpSessionsCleared; after-seeds doctor is still exact. Final `324` snapshot is original Training route/matrix. `003-original-prefs` vs `325-final-prefs` matches1905×2053/light/emptytheme/system/no sidebar cookie; theme/sidebar were not changed in v3. Viewport/horizon/filter restoration is separately observed, not inferred from providerpreferences[].

Driver `328-list-pages` deliberately leaves signed-in isolated pages2–8 for root's cleanup. Root `root-owned-cleanup.json` records PASS/cleaned; `root-owned-absence.json` binds the same session and exact owned supervisor/app/MCP/browser PID+starttime+command hashes, all four `exactOwnedAbsent:true`, no private-profile process IDs, worker directory absent and proof payloads still present. This is captured root closeout proof, **not my independent live process inspection**. It supports destroyed private-session/browser leftovers rather than claiming the driver logged out each page.

## Continuity and evidence references

The prior complete source review and older artifact reviews retain their own pins and limits:
- `.verification/1504-independent-cumulative-source-review-v1.md` SHA256 `c54fb7fc6588687f14e1af38c5b6e910de1a9e1b619b55ef9ec5470be036bdeb`;
- `.verification/1504-independent-final-attempt-v1-artifact-review.md` SHA256 `702092b2c8ded6d3a2fce5e4c43d33a6018c9710771dd57636157875662f8fe1`;
- `.verification/1504-independent-final-attempt-v2-review.md` SHA256 `8493d0819228c9c5d83faa2df0d34da334b2446084fdc5f7665ece05cfec1d2a`;
- `.verification/1504-independent-final-source-review-v1.md` SHA256 `a1419375caacc10b52abe51f0f911e215ba6395303b468c3942a3d1fa4ee2ae1`.

V1's overwritten capture names and foreign observer mismatch remain historical limits; v3's unique capture/B-native status does not reconstruct those lost captures. V1 privacy redaction-time versus final inventory counts remain separate; v3 has no redaction and the single final census reported here. V2 zero-beforeprint captures remain rendering-only; both v3 saved PDFs have their own pre-capturebefore1 proof. The earlier print-control publication correction retains its own source/test review; current native save receipts support its actual transport without a new security-race execution by this reviewer.

Selected exact artifact bindings (every other file remains bound by the complete verified inventory):

| Receipt/document | SHA256 |
|---|---|
| acceptance-report.md | `e6a4bc04c301bc63992d55ed189fd1b8ec8ff3b0de333598b6cf9607dea114de` |
| acceptance-brief.md | `ae6f8f80c1bd1007e7a900c9845b89d8b5d5c791ba02e686bfa5a3af24f2e618` |
| accept/expectations.md | `7a412b5e2f766258b7164228daf126884a7a8c93efb8810f8c0020ea49993282` |
| root-public-fixture.json | `60429224d5980ddacc0d420adc0d91f7694542963b99ff8dd7d6cddfc1b0ded2` |
| root-source-checkpoint.json | `b31684a1896829b4561515cd62e74a16bba534c8a30d269f6fab17253b4197f5` |
| gate-binding.json | `1234d8ffed7ddb7ef0113ed8e5cbd15253416403977d1c9d72e2a959f3c81237` |
| accept/receipts/077-focus-held-next.stdout | `bd2b54db509a06f2027fe6fdaf417b5e0bb3f579dffc033a7e6577206d9ea002` |
| accept/receipts/081-focus-after-next.stdout | `31f3ef6fbac472d50a43b7cfe5f73a17b5e3cf1ac02ce6b76537b15f91c9f604` |
| accept/receipts/100-focus-held-moved.stdout | `71e9d560919189f91adc2042e2eda30fee4e76bc8fce17df450eeb8709c9babd` |
| accept/receipts/103-focus-after-release.stdout | `f7430343a41202b25d9c0e3153bfcd609ec90dbdbd8f77727c00b8931f2dd5b5` |
| accept/receipts/111-focus-after-503.stdout | `0dfff04e9c015e54aaf0b69eabac309688b3957455014fa061152d131c35036a` |
| accept/receipts/119-focus-held-retry.stdout | `8146ba1dc8573692f846eaf36be6cc7022685e37702355f18b0c73dcc1eec120` |
| accept/receipts/122-focus-after-retry.stdout | `549106299855f0e4fc2ca18367afff74953a6d8bdbb41b50e5f614de2772ec29` |
| accept/receipts/177-f-print-save.stdout | `1484b5aa28f066511836b1df9d719eeda7bfbd13fa83e8be8467b8db06e43bec` |
| accept/receipts/199-f-print-save.stdout | `a6ec0aed9e1bcaa76d6bfeb9ce7ae2f8f369d3d3c4763933f15dbe80c3f3f619` |
| accept/receipts/205-census-read.stdout | `6310dfd270b9cf3133f57942a3ea83525d81f98ee6cbbdaba825996485157311` |
| accept/receipts/267-net.stdout | `5a5ea001c93e9b56fcdcbf6244c1a375200e067dc117f6aeefe0b802d7da0bba` |
| root-restoration-audit.json | `dddadce4d4db7ef555b12cf9b7df60fff40c81950aef07bb29e0a724715692b4` |
| root-owned-absence.json | `fb852f8ebc22c61cd28916bdce8ad1c59d1083e0b7c2672dbee691c64c45ca5e` |

Next acceptance remains the root's composed decision after distinct correction-source review, current required gates and fresh narrowed native/visual proof for the open P1/P2 and dependent print cases. This report supplies no merge/deployment/remote-database authority.

