import pathlib,subprocess,json
r=pathlib.Path(__file__).resolve().parent;A='f7083174-e6db-46c5-8fae-8af8d78f2909';B='9aadd391-c41f-4ea7-a880-09832eb2e234';staff='3f76847e-a93b-4cd0-82d0-9dc42460d2af';able='387c638f-8883-41d4-8218-e7620bf8eec9';baker='7f595f99-b983-4c26-abeb-b75685ca0b63';unassigned='2ec6f7f0-9052-4ab2-9fbb-e80a4f6f88a1';foreign='750e7c75-ab1e-4d4e-a2e7-6458da4f0ef1';foreignType='44a4be8a-5a63-4e86-bc5d-9c68cdcfd20d'
cases=[('view',5,A,staff,able),('manager-none',6,A,staff,able),('scoped-bravo',3,A,staff,baker),('scoped-unassigned',3,A,staff,unassigned),('scoped-foreign-person',3,A,staff,foreign),('empty',4,A,staff,able),('operator-foreign-org',14,B,foreignType,foreign)]
for name,page,org,t,p in cases:
 row={'date':'2026-11-22','assignmentTypeId':t,'assigneeId':p}
 for kind,body in [('single',row),('batch',{'records':[row]})]:
  proc=subprocess.run(['python3',str(r/'drive-v2.py'),'p04-denial-'+name+'-'+kind,'req',str(page),'POST',f'/org/{org}/api/daily-assignments'+('/batch' if kind=='batch' else ''),json.dumps(body)],capture_output=True,text=True);print(proc.stdout,proc.stderr)
  if proc.returncode:raise SystemExit(proc.returncode)
for name,page,records in [('mixed-forbidden',3,[{'date':'2026-11-23','assignmentTypeId':staff,'assigneeId':able},{'date':'2026-11-24','assignmentTypeId':staff,'assigneeId':baker}]),('mixed-invalid',14,[{'date':'2026-11-23','assignmentTypeId':staff,'assigneeId':able},{'date':'2026-11-24','assignmentTypeId':'00000000-0000-4000-8000-000000000001','assigneeId':able}])]:
 proc=subprocess.run(['python3',str(r/'drive-v2.py'),'p04-'+name,'req',str(page),'POST',f'/org/{A}/api/daily-assignments/batch',json.dumps({'records':records})],capture_output=True,text=True);print(proc.stdout,proc.stderr)
 if proc.returncode:raise SystemExit(proc.returncode)
