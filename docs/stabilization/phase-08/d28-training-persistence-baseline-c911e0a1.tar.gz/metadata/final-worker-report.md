# Ordinal2 terminal Training baseline report

Outcome: **incomplete baseline; one demonstrated product failure and three failed control obligations. Owned resources are closed.** The persistence cutover was not implemented. No full acceptance or independent review is claimed. This is a terminal result for ordinal2; ordinal1 remains CANCELLED. The parent recovery-r2 r1-* readbacks remain separate observations and are not final restoration proof.

## Binding

Checkout `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93`, branch `stabilization/1376-training-owned-persistence`; HEAD `c911e0a114e1425541fa91a7b66db04bd904dc22`, tree `e71edc8c01aeea49f727db8b5040b0f2e6956b1f`; candidate `590fe5b7e5806e50392c1fa95624098dd61381fe364c1ab83235a7ac3ad4c556`. The final hash comparison covers all5,144 frozen inputs and finds zero differences. Application, controls, fixtures and both maintained Training recipes were unchanged; parent’s three dirty Markdown ledgers stayed byte-exact.

Worker1 session `56e64578-66e6-4f8a-872d-0aa393320127`, Chromium152.0.7977.82, Node24.21.0, loopback origin `http://127.0.0.1:43285`, disposable project `t2t-verify-ca678d19e0ab4e58a7ed394c`. There was one owned successful session, continued through interruption/overlap, and no restart afterward. Three launch attempts/heavy builds were sequential: Node26 unsupported-adapter failure, Node24 long-TMPDIR Chromium singleton-socket failure, then Node24/private shortTMPDIR success. Both failed attempts were closed before the next attempt.

Fixture literal date2026-10-06/America/Anchorage. Ordinary captures before midnight show15days remaining/365days expired and horizonJan4. `day-rollover-observation.json` records the actual rollover: later matrix labels14days/366days and realasOf7Oct/horizonJan5. No clock emulation or fixture/date change. Relative labels from different dates are not conflated.

Raw evidence: `.verification/evidence/verify-trooptotask/d28-training-owned-baseline-c911e0a1/`. Source report: `source-readiness-caller-report.md`; current175path hash comparison/direct/reverse import census retained beside it. Accepted design remains exactly two ordinary ports, TrainingCatalogPersistence17methods and TrainingCompletionPersistence10methods. Current callers bind to integrated Personnel four ports: GroupPersistence.listCatalog and SelfPinPersistence.listNames in Training workspace; PersonnelTrainingRosterPort.listActiveForReports/findGroupIdsForWrites in reports/writes; admitted organizationPersonnel.findBySlug/findById in Personnel consumers. Rank catalog keeps its separate established adapter. Historical export callbacks require the settled four-field projection delivery adaptation; raw archive stays separate. There is no concrete incompatibility requiring redesign/third ordinary port.27of175historical paths changed, now explicitly refreshed against main; proposal is not current implementation.

## Actual family/case accounting

Each line below is one bounded reported obligation, often a multi-action scenario with its failure/retry pair. These are **not** counts of automated tests, requests, files or independent runs. Some metadata obligations reuse explicitly named current output observations. PASS is limited to the listed observed scope. FAIL includes the product defect and control attempts returning INCONCLUSIVE; UNRUN includes blocked/deferred/unsupported obligations and preserves partial actions without a completion claim. No accepted#1562 repair run or recovery-r2 readback is relabeled.

**64 reported obligation groups: 36 PASS, 4 FAIL (1 product, 3 controls), 24 UNRUN.**

| Family | PASS | FAIL | UNRUN |
| --- | ---: | ---: | ---: |
| 1. Original saved sets/bootstrap | 3 | 0 | 0 |
| 2. Catalog/View CRUD | 3 | 0 | 0 |
| 3. Completion matrix/Person editor | 4 | 1 | 1 |
| 4. Removal/approval | 4 | 0 | 1 |
| 5. Batch/retention | 5 | 0 | 0 |
| 6. Reports/filters/downloads | 4 | 1 | 3 |
| 7. Scope/multiple tabs/lifetime | 3 | 1 | 3 |
| 8. Reverse consumers | 6 | 0 | 3 |
| 9. Empty/pagination | 0 | 0 | 3 |
| 10. Dense print/data lifecycle | 0 | 0 | 5 |
| 11. Metadata/raw/projected output | 2 | 0 | 3 |
| 12. Restoration/closure | 2 | 1 | 2 |

### 1. Original saved sets/bootstrap

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 1.1 Original full A/B saved sets and actual reverse inputs | PASS | original-orgA/B-{training_types,training_views,personnel_trainings}; memberships/rank/Group/pin readbacks. 20/7/10 SQL keys; configure preference before its first selection omitted, separately UNRUN in12. |
| 1.2 Current bootstrap/first paint and reload | PASS | f01-report-first-paint-http; original native entry/reload/network captures. Retained completed ordinal1 artifacts; no replay, no latency claim. |
| 1.3 Original matrix/report, Focus View, Group/sort and full downloads | PASS | f01-focus-matrix.xlsx; f01-alpha-matrix.xlsx; original report captures. 3People/4requirements/1ready/3missing25%; Focus Targeted→Required, hidden Optional still exported. |

### 2. Catalog/View CRUD

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 2.1 Temporary Type create503/retry, targeted MOS/exclusion, edit/clear/cancel/delete | PASS | f02-type-*. Full20 saved keys, one stable ID; new sort_order3 precedes originals10/20/30. |
| 2.2 Temporary View create503/retry, edit/reorder503/retry, cancel/delete/reload | PASS | f02-view-*. Full7 saved keys; stable ID and ordered columns; actual draft/error retained. Completed earlier same-candidate Type/View captures are retained without replay. |
| 2.3 Seeded Required reference and original-field restoration | PASS | f02-seeded-reference-comparison.json; scoped exemption authority HTTP in5. Description and can_be_exempted visibly restored; original completion remains exact. No original Type updated_at exists. |

### 3. Completion matrix/Person editor

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 3.1 Optional completion create/edit/cancel/current503/retry/reload and full matrix | PASS | f03-optional-*; f03-optional-matrix.xlsx. Null dates, Notes/Certificate exact; Required denominator unchanged. Create response body unavailable after reload; not credited. |
| 3.2 Single expiration-only completion and orange/yellow/expired Person/matrix branches | PASS | f03-expiration-*. Null completion with explicit expiry; literal dates and full saved leaves. This is distinct from batch both-date behavior. |
| 3.3 Mixed expiration/exemption batch failure/retry, no exempt completion and matrix workbook | PASS | f05-mixed-comparison.json; f05-mixed-failure-comparison.json; actual expiry workbooks. Allowed global authority; Baker exemption array updated; Unassigned batch stamps both dates. These matrix/Person outputs do not prove Report denominator after exemption. |
| 3.4 Temporary required never-expiring completion/report/workbook/removal | PASS | f11-never-comparison.json; never-expiring captures. Both datesnull, no fabricated expiry; 7requirements/2ready29%; original sets restored. |
| 3.5 Person inline current save503 retains draft/error | FAIL | f04-person-edit-failed.json; f04-person-edit-failed-screen.png; wire/provider row/feedback captures. PRODUCT: form closes to saved card, draft lost, no current error; SQL unchanged. No repair or reopened rerun. |
| 3.6 Explicit retry of the failed retained Person inline draft | UNRUN | Same failed before/action/after evidence. Dependent draft disappeared; retry cannot be credited from a different editor. |

### 4. Removal/approval

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 4.1 Configure removal503 retains row/confirmation/error then retry removes | PASS | f04-configure-delete-*; f04-original-training-comparison.json. Synthetic pre-dispatch failure, not post-commit rollback. |
| 4.2 Person removal503 retains saved values/confirmation/error then retry removes | PASS | f04-person-remove-*; f04-original-training-comparison.json. Independent of failed inline Save. |
| 4.3 Operate DELETE202, submission503/retry201 and duplicate409 | PASS | f04-approval-*; immediate screenshots/native wires. Source retained until review; one exact requestc29e7cd9; quiet info seen in actual screenshots, not success/error recorder. |
| 4.4 Reviewer503/retry200 and approved-source disappearance/reload | PASS | f04-approval-comparison.json; f04-review-*. Exact reviewed_by/time; approved history retained until owned cleanup. No provider partial-effect claim. |
| 4.5 Approval retirement after held202 or dispatched approval response | UNRUN | Historical lower-boundary plan/current source binding only. No native delayed approval lifetime observation; parent-owned lower checks remain separate. |

### 5. Batch/retention

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 5.1 Invalid CSV preview, accessible correction and unselected third row | PASS | f05-dated-* preview/correction captures. Invalid type corrected to Optional; corrected row remains unselected. |
| 5.2 Dated two-row batch503 unchanged saved set, explicit retry Inserted2 | PASS | f05-dated-start-comparison.json; native batch wire/readbacks. BakerRequiredc9d68147 and AbleTargetedf1a47ae0; original current exact. |
| 5.3 Repeated native import Updated2 with IDs/dates/Certificate retention | PASS | f05-repeat-comparison.json. Omitted certificate key retains Baker URL; actual operation/DB timestamp provenance recorded, including5ms ordering difference. |
| 5.4 Alpha-scoped configure native Import and valid exemption authority denial | PASS | f05-alpha-config-and-restoration-comparison.json; f05-scoped-valid-exemption-authority-http.json. Import updates existing Able Targeted; scoped mixed exemption403 leaves complete sets exact. Wrong Date or Status header was corrected to Date / Status; input error preserved. |
| 5.5 Separately labeled empty/missing/foreign batch and500/501 admission probes | PASS | f05-batch-*-http.json; f07-full-probes-comparison.json. 400/404/indexed200errors and500 admitted error entries vs501400; not500native writes, transactions or SQL RLS proof. |

### 6. Reports/filters/downloads

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 6.1 Dated report controls/URL reload/cell/focus and exact ordinary/MOS workbooks | PASS | f06-workbook-comparison.json; f06-mos-workbook-comparison.json; actual matrix/report books. 4requirements/2ready/1expired/1missing/1lapse50today25horizon; all5sheets and literal rows read. MOS/role/type/view/group/rank/horizon/rowsBy driven. |
| 6.2 Current summary503 retains loaded Alpha and explicit Retry loads Bravo | PASS | f06-summary-*. Loaded controls/URL/numbers retained; current error visible; retry focus recorded. |
| 6.3 Current detail503/error/retry and actual affected-region focus | PASS | f06-detail-*; Focus selection captures. Required two rows, Targeted sole Able, proper selection and loaded focus; no moved-focus interval claim. |
| 6.4 API export503 no Blob, explicit retry complete5sheet workbook | PASS | f06-export-*-report.xlsx; f06-export-*. Native activation plus actual complete download/readbacks; not lazy-module failure proof. |
| 6.5 Native Offline emulation control | FAIL | f06-lazy-offline.json; f06-lazy-blocked-doctor.json. CONTROL INCONCLUSIVE: Network throttling is not supported when network blocking (allowlist/blocklist) is configured. Offline was not applied; no substitute. |
| 6.6 Offline lazy Excel import failure and recovery download | UNRUN | f06-lazy-offline.json. Blocked before export activation; normal view-only export is not this proof. |
| 6.7 Selected-radio no-op requests and export busy/repeated activation | UNRUN | No action dispatched. Remaining bounded selections blocked by terminal DevTools failure. |
| 6.8 Moved-focus held detail and observed Retry loading interval | UNRUN | No action dispatched. Existing final focus captures cannot prove these intervals; no fresh first-paint replay. |

### 7. Scope/multiple tabs/lifetime

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 7.1 Actual native role affordances/routes and valid HTTP visibility/write denials | PASS | f07-role captures; f07-catalog-access-comparison.json; f07-full-probes-comparison.json. View/operate/Alpha/Alpha-config/rosterScoped/empty/none/ForeignB. Foreign is Bconfigure; switch is Bview. Mutation-only GET405 mistakes receive no access credit; corrected Training page/report probes separately labeled. |
| 7.2 Alpha Training-operate/Personnel-none positive Optional save/reload/native removal | PASS | f07-rosterScoped-*; f05-alpha-config-and-restoration-comparison.json. Allowed-first mixed scope403 leaves witness/full sets exact; no grants promoted. |
| 7.3 Real same-context two-tab Aheld completion/Bvisible selector/response/reload/return/removal | PASS | f07-two-tab-comparison.json; binding/native list_pages/requests/screens. 18A and19B same isolatedContext. Acommitted real200, B exact before/after, no old-A record; A saved fields verified and temporaryf0e8697c removed visibly. Three screenshots actually viewed after closure. |
| 7.4 Native screenshot during retired-editor Back transition | FAIL | f07-retired-B-before-release-screen-capture.json. CONTROL INCONCLUSIVE -32001 Harness operation unavailable. Correct request page18/fullPage/filePath; no PNG. Followed by doctor DEVTOOLS_UNAVAILABLE; no unsupported control repair. |
| 7.5 Retired-editor release/immediate capture/Breadback/return/removal | UNRUN | f07-retired-original-A/B.json; f07-retired-A-committed.json; f07-retired-back.json; f07-retired-B-before-release.json. Partial real APOST200 committed42797616; nativeBack reachedBforeign-only. Release and later actions never dispatched because owned doctor blocked. No post-release destination pass. |
| 7.6 Held native batch lifetime | UNRUN | Actual frozen actor/control census. trainingSwitch has no Import and no documented ordinary Training pending-batch helper; no fake HTTP/native credit or grant change. |
| 7.7 Held report/detail A→B and held report sign-out gate | UNRUN | No action dispatched. Terminal native failure blocked all; existing separate role contexts and successful completion two-tab do not establish them. |

### 8. Reverse consumers

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 8.1 Actual Personnel Training cards and positive/negative full4column workbooks | PASS | f08-personnel-workbook-comparison.json; f08-able-records.xlsx; f08-baker-records.xlsx; f08-none-able-records.xlsx. rosterManager positive Trainingoperate/Personnelconfigure; manager Trainingnone workbook permitted but Training sheet empty. Actual GET export, no owner bypass. |
| 8.2 Dashboard retained currency projection | PASS | f08-dashboard-visible-screen.png; native snapshot/reload. 33%current,1expired/1expiring distinct from Report50%; actual Got it dismiss normal What’s New acknowledgment. Visible screenshot actually viewed. |
| 8.3 Onboarding selector/current-expired-missing existence starts, cancellation/history/template removal | PASS | f08-onboarding-existence-comparison.json; f08-onboarding-restoration-comparison.json. Unique temp template/step selected; actual3packets true/true/false, even Trainingnone actor. All3cancelled visibly; originals/templates/steps exact; cancelled histories retained until owned cleanup. Wrong global option index caught/read back and corrected before any starts. |
| 8.4 Whole Organization JSON actual native download/raw20/7/10 exact rows | PASS | f08-owner-json.json; f08-owner-raw-json-comparison.json; native wire/save. Exact all raw metadata/nulls/Aonly; full actual300617byte file; exportedAtUTC7Oct versus earlier UI6Oct retained. |
| 8.5 Whole Organization Excel complete selected readable/raw sheets and member denial | PASS | f08-owner-excel.xlsx; f08-owner-raw-workbook-comparison.json; member export denial HTTP. Raw headers20/7/10/arrays exact; readable6fields vs Person4; member403 separately signedHTTP. Two system export history rows retained until cleanup; no D24 rerun. |
| 8.6 Getting Started/Starter ordinary API existing/apply/skipped repeat and native source cleanup | PASS | f08-starter-repeat-saved-comparison.json; f08-starter-restoration-comparison.json; getting-started HTTP. APIcount3→5→3types and3→7→3steps; first creates7artifacts, repeat skips7/exactsavedrows. NewArrivalPacket and2types removed through native controls. No native Apply control exists. |
| 8.7 Native Starter Apply, raced-name and estimated-count-null boundaries | UNRUN | Current source mapping only. Native Apply unavailable; no stable-boundary raced/null execution authorized. Initial Starter denial has no immediate isolated provider readback; later aggregate restoration is narrower proof. |
| 8.8 Rank deletion Training reference denial/release | UNRUN | Current rank purpose-owner callback binding. Existing owner-deferred SDK/RPC proof not reopened; no new protected settings deletion. |
| 8.9 Admitted platform support/activation/type-name audit reverse boundaries | UNRUN | Current purpose-port/admission census. Parent owns meaningful lower-boundary checks; no added admin access or claimed independent execution. |

### 9. Empty/pagination

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 9.1 Zero-People report/disabled native export and signedHTTP5sheet empty file | UNRUN | No Reports/export action dispatched. Native empty matrix/HTTPsummary from7 exists; it does not establish required empty workbook/report path. |
| 9.2 training-pages26 seed, loaded25/Next/held/fail/retry/100 and full workbook | UNRUN | No seed or cohort action dispatched. No journal exists; planned script was never executed.29People/31requirements6% expected after dated pair remains expectation only. |
| 9.3 Literal PFC/SPC/MOS/Alpha cohort filters/reverse/full-set comparisons and barrier | UNRUN | No cohort exists. No cleanup-barrier, row count or pagination credit; no1001 native cohort invented. |

### 10. Dense print/data lifecycle

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 10.1 Fresh112People/24Types/14Groups/1902completions dense facts, detail pages and1990row complete workbook | UNRUN | No training-print seed/action dispatched. 2632/1272/642/730/630/630 are fixture expectations, not measurements. |
| 10.2 Fresh whole dense PDFs/allpages/light-dark/Letter-A4/background variants | UNRUN | No PDF exists in current raw scope. Historical #1550 artifacts not reused or reaccepted; no current print or page-inspection credit. |
| 10.3 Fresh Short336/124/68 and EmptyView112 distinct from zeroPeople, whole outputs | UNRUN | No action dispatched. No old changed-data workbook substitutes. |
| 10.4 Loaded held/failed summary/detail print, B-only print and sign-out scope | UNRUN | No action dispatched. No native hold-fail support claimed. |
| 10.5 Native print cycle/no-extra-fetch/keyboard/cancel, goal85/theme/emulation restoration | UNRUN | No print control/theme/goal edit dispatched. No invented screenshots, keyboard events or cancellation; no print hook to restore. Original goal90 not edited. |

### 11. Metadata/raw/projected output

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 11.1 Ordinary saved/public metadata mapping and raw/projected scope comparisons | PASS | metadata-observations-ordinary.json; original rows; Type/View native wires; f08raw JSON/Excel; Person/MOS books. Type/Completion preserve snake metadata; View camel creator/time+snake Org; no Type updated_at; IDs/arrays/flags/dates/cert/creator/time/source provenance read, not visible-ID claims. |
| 11.2 Literal undated/never-expiring and repeated certificate output leaves | PASS | f11-never-comparison.json; f05-repeat-comparison.json; actual matrix/report/raw books. Reuses exact current observations3/5/8 for this metadata obligation; not another native run. |
| 11.3 Report exemption denominator/cell/full workbook after expiration-only batch | UNRUN | Earlier matrix/Person expiry/exempt evidence only. Those temp variants were removed before this Report observation. Proposed bounded missing observation not run before terminal failure. |
| 11.4 Installed-SDK present-null/missing/read-only stripping/.single/count-null boundary | UNRUN | Historical contracts/current source mapping only. Native saved rows do not prove every omitted-input/SDK failure distinction; parent-owned lower checks. |
| 11.5 SDK1000+1/late-error completeness, actual SQL/RLS and nontransactional post-effect failures | UNRUN | Historical contracts/current source mapping only. No speculative tests or new native cohort; browser pre-dispatch503 proves neither rollback nor complete RLS/provider late-page semantics. |

### 12. Restoration/closure

| Case | Result | Actions/outcome, artifacts and limit |
| --- | --- | --- |
| 12.1 Exact final frozen inputs/source/parent ledgers preserved | PASS | f12-final-source-input-comparison.json; f12-closed-input-info.json. All 5,144 hashes unchanged, candidate590fe5 unchanged; three intentional parent Markdown hashes exact. No source/recipe differences. |
| 12.2 Actual owned cleanup terminalzero and independent resource absence comparisons | PASS | f12-owned-cleanup.json; f12-owned-absence-first.json; f12-resource-comparison.json; mount-order correction. App/MCP/browser/supervisor starts absent; owned Docker/project/listeners/TMPDIR/cache absent; original41containers7networks17volumes identity/stablefacts exact. |
| 12.3 Final owned doctor | FAIL | f12-final-doctor.json; f07-retired-shot-failed-doctor.json. CONTROL INCONCLUSIVE DEVTOOLS_UNAVAILABLE. Last earlier ownPASS is f07-scratch-stop-doctor; no final doctor PASS claim. |
| 12.4 Final documented native control restoration/UIrow removal/full original-temp-B comparisons | UNRUN | f12-interrupted-restoration-facts.json; f07-retired-*. Blocked by doctor; held network/feedback18 not explicitly restored. Provider/browser destruction is resource closure, not native restoration or row comparison. |
| 12.5 Complete original preference before/after restoration proof | UNRUN | Captured actor preference originals and actual defaults at earlier stages. Configure preread before firstFocus omitted; final allactor saved-preference comparison blocked. No privileged preference/timestamp write to manufacture proof. |

## Final originals, temporary rows and controls

Original A:3Types,1View,1CurrentCompletion; B:1Type,1View,0Completions. All were fully captured before mutation. `f04-original-training-comparison.json` proves an interim exact6-set restoration. Later Required description/can_be_exempted native restoration, temporary expiration/never-expiring removal, Onboarding/template/Starter cleanup and the completed two-tab comparison preserve original rows/metadata. These comparisons are interim evidence, not final restoration. Original View/Completion timestamps were never overwritten or restored through privileged writes. Original ranks, Groups, pins, memberships and goal90 were not changed. Final full membership/settings/pin/preferences readback is UNRUN. No original data was reset.

Last own full Training readback (`f07-retired-A-committed.json`):4Acompletions. Original78a760b7-7efd-46b0-8203-6371304a573e is byte-exact; UI-created dated BakerRequiredc9d68147-6f9a-4e4f-832f-99612c5cdcd0 and AbleTargetedf1a47ae0-5c37-499b-9bb4-bd3e2c2e917b remain, plus retired-editor Optional42797616-979f-46ea-b40b-e770a703eeb6. Its datesnull, Notes`D28 retired editor c911`, URL`https://example.test/training/retired-editor`; realPOST200 recorded by hold and committed readback. NativeBack reachedB, showing only Foreign Private Training/Foreign. The screenshot timed out; release/feedback-state/native wire/post-release Breadback/return/removal never ran. No row deletion or Bpost-release pass is inferred. Full original/temp rows are retained in `f12-interrupted-restoration-facts.json`.

All earlier UI-created temporary Type/View/completion/template/Starter sources were visibly removed and absence compared. Approved requestc29e7cd9-02fa-4a54-b723-af1b908c3298, three cancelled packet/progress histories and two DataExport lifecycle rows remained as permitted system effects until owned cleanup. Their full IDs/fields are in f04approval/f08history readbacks. Three cancelled packets include Ableb126db55-5d8d-4ad1-8c09-c926bf160d73 and Baker1b4ce9cd-e495-4a1b-b91d-57290d73204a; the Unassigned packet ID and all progress IDs are in `f08-onboarding-existence-comparison.json`/cancelled row sets. Their original packet/progress subset is exact. Deleting the temporary template leaves actual retained snapshot rows with null template links; that saved shape was preserved. Export lifecycle is outside this selected repair stage.

No helper seed was ever invoked. The private seeded/grant journal was absent; training-pages/training-print were not created; clean-seeds was not issued. There were no journaled cohort rows to compare/delete. `f12-own-control-receipt-inventory.json` records 177 own control receipts, with only network18/feedback18 still armed (ordinary service export requests are separately classified). Network/export/feedback controls from completed cases were explicitly restored in their receipts, including the completed two-tab network18/feedback19. Offline override clearing and observers were restored with own doctorPASS earlier. No print control, goal change or theme override was applied. Terminal networkhold18 and feedbackobserver18 remained armed because every documented helper first checks doctor; the final doctor failed before their release/restoration could dispatch. Owned browser/process/provider teardown removed that runtime and all synthetic rows. This is actual resource cleanup, **not** a claim of documented native restoration, final business-set comparison or clean-seeds.

## Failure and closure evidence

Product failure is the composed Person inline Save branch: `PersonTrainingEditor.saveTraining` awaits onSave then exits editing, while `TrainingModals` calls `TrainingPageContext.handleSaveTraining` whose Promise<void> ignores the store result. Native POST503 beforedispatch left SQL exact but closed the draft/noerror. Preserve the failed before/action/after/wire/readback and separately passing matrix-modal/removal results. Parent owns the focused repair and failed plus justified adjacent reruns.

Offline failed with DEVTOOLS_TOOL: network throttling unsupported while the frozen allowlist/blocklist is configured. No requested offline action ran. Terminal screenshot command page18/fullPage to an allowed new raw path returned INCONCLUSIVE/-32001 “Harness operation unavailable. Inspect private logs; do not approve the candidate.” All four owned processes still had their original start identities; login/provider/source were available, but doctor could not list pages. `f07-retired-shot-failed-doctor.json` and `f12-final-doctor.json` both return DEVTOOLS_UNAVAILABLE. No source/control/fixture correction or browser substitute was made. Required parent repair is native DevTools screenshot/page-liveness timeout recovery, plus compatible native Offline/network-policy controls; there is no final doctorPASS.

`f12-owned-cleanup.json`: actual cleanup command exited0/PASS/cleaned. `f12-owned-absence-first.json`: worker root absent; supervisor3267548/start174602962, app3277159/start174608768, MCP3277211/start174608834, browser3277223/start174608870 all absent; former app auth/login connection refused. `f12-owned-descendant-and-socket-absence.json` additionally records all30prior owned-group start identities absent, no remaining owned process-group members or browser/node worker-path matches. Initial socket baseline was TCP only; no unchanged full Unix inventory is claimed. `f12-resource-comparison.json` records owned container/project/network/volume/listener absence, including captured browser port, and removed only owned shortTMPDIR/cache directories. All original41container IDs,7network IDs and17volume names remain. Initial positional Docker Mounts comparison was false only from array order; `f12-resource-mount-order-correction.json` proves all original Id/Name/Created/mount leaves exact after sorting byDestination, and same original Docker PID/state/StartedAt. Initial false receipt preserved.2913original process-start identities remained,122transient original identities had naturally ended during hours of work; there is no blanket process-unchanged claim. Only recorded owned identities were cleanup targets. Preexisting process/socket facts are preserved in original and final resource snapshots. The three protected private worktrees remain untouched/clean.

## Artifact review and handoff

Actual native/signedHTTP/privileged synthetic setup-readbacks are labeled separately throughout. Wire captures redact Cookie, Set-Cookie, Authorization and apikey values as `[REDACTED]`; corrected page HTTP observations omit scripts explicitly as `[SCRIPT OMITTED]` rather than preserving auth-root metadata. Synthetic loopback origins/fixture Org IDs and example.test certificates are retained. Final text JWT/signed-URL pattern scan found no matches, and XML/rels scans of all 17 workbooks also found no matches; binary/visual review limits are recorded in `f12-artifact-review.json`. These scans are limited credential review, not a universal confidentiality certificate. No current PDF was produced. No screenshot is invented for the failed capture. Existing Type/View and first-paint captures were preserved without replay or overwrite.

Parent can review/package only now that the owned session is closed. Next concrete work: review this failure-bound baseline and current caller bindings; repair the Person inline result propagation and the two native control blockers; select the failed/adjacent reruns plus explicitly UNRUN remainder with new frozen ownership. Preserve completed applicable proof; do not use a new session/base as authority for a broad rerun. Parent still owns persistence implementation, meaningful lower SDK/RLS contracts, final required checks and sequential independent expanded acceptance. No commit, push, tracker/PR write, publication, merge, remote database access, final facade cleanup, D29/D30 or independent/model-diversity claim occurred.
