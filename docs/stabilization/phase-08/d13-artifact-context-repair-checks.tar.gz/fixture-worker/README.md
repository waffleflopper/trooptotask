# Personnel artifact context fixture preparation

Prepared only in the detached cache checkout at base `303f562af9f470eea69b1d60fdb844501822258e`. The two-file patch changes `scripts/verification/fixtures.mjs` and `.agents/skills/verify-trooptotask/helpers/control.mjs`; it has not been integrated into the active PR checkout.

`personnelContext` starts with organization-scoped Personnel configure in A and no other feature lanes. Existing actors, memberships, grants and Organization settings are unchanged. The temporary `seed personnel-artifact-context` creates one new B membership for this new actor, two active Persons with distinct IDs/names and one shared org-scoped slug, and active/independently archived witnesses for Leader Notes, Follow-ups, Counseling and Documents in each Organization. Follow-ups are open or archived; archived witnesses use August 1, 2026, independently of their active parents. Contributors are the context actor. Counseling mirrors title/summary into subject/notes. The seed returns complete synthetic membership/parent/child rows and file manifests, without credentials.

The eight file-bearing witnesses all prepare real PDFs with distinct synthetic labels/row IDs. Document paths are ORG/personnel/PERSON/documents/ROW-synthetic.pdf; counseling paths are ORG/counseling-records/PERSON/ROW-synthetic.pdf. The manifest computes byte sizes/SHA-256 before upload; none of these paths are metadata-only. These are privileged fixture uploads when the seed runs, and do not establish ordinary actor upload, authenticated Open, exact downloaded bytes or authorization.

## Dry source ownership/recovery analysis

1. Build all UUIDs, rows, PDF bytes and exact paths without provider effects.
2. Record the temporary B membership first, then scoped A/B parents, then each scoped child family. Attach all eight file paths exactly once to the A parent entry, following the existing retention fixture pattern.
3. Persist the complete cleanup manifest before the first insert. If persistence fails, no new membership/row/object insert has started.
4. Insert membership, parents and children in dependency order, then upload each known object. An insert/upload failure propagates through checked; the already persisted complete manifest retains ownership of attempted and not-yet-attempted IDs/paths and prior partial effects.
5. Existing reverse clean-seeds deletes recorded child IDs by their recorded Organization, then the B parent, then the A parent and all eight recorded files, and finally the temporary B membership. Only recorded IDs/paths are targeted. If cleanup fails, its existing state remains available for a later explicit cleanup; this is not atomic rollback.

Ordinary UI-created rows/files have server-generated IDs/paths beyond this seed manifest. Capture those actual IDs/paths and clean them through permitted native/archive-delete actions before seed cleanup; preserve file absence through artifact-files recorded-path readback. Parent deletion is not a claim of automatic Storage compensation.

## Verification and limits

Node 24.21.0 syntax checks for both files, focused ESLint, focused Prettier write/check, and git diff --check all passed; exact commands/exits are in worker-checks.json and raw worker logs. Root node_modules is symlinked for these checks only; no dependency installation, app/provider/native invocation or service launch occurred.

No existing helper test implementation changed: network/auth/browser behavior is untouched, and retained ownership tests cover separate retention fixture modules rather than this inline seed. New count/snapshot/shape assertions would mirror this fixture. The required affected proof is root's fresh owned setup, scoped provider rows/actual file hashes, positive native A/B navigation and permitted effects, original negative actors, exact cleanup and disposal. A forced interrupted setup with exact cleanup would add meaningful recovery coverage if that boundary needs further proof; it has not been run. There is no live setup, native, provider, SQL, migration, HTTP-status, concurrency or cap proof in this preparation packet.
