#!/usr/bin/env bash
# usage: shot.sh NAME PAGE [fullPage true|false] -> shots/NAME.png (refuses reuse)
E=.verification/evidence/verify-trooptotask/1504-final-v2/accept
[ -e $E/shots/$1.png ] && { echo "REFUSED shot $1 exists"; exit 1; }
$E/t.sh "shot-$1" "screenshot $1" take_screenshot "{\"pageId\":$2,\"fullPage\":${3:-true},\"filePath\":\"$E/shots/$1.png\"}"
