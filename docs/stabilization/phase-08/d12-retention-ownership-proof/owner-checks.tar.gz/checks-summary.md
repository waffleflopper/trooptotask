# D12 parent-retention owner worker checks

This worker changed seven application/test files in its exclusive checkout. No SQL/schema files, verification helpers, documentation, governance baselines, PRs, remote operations, app servers or database services were changed or started.

Tested base: `d75045002702015183074d0ff73e04dd6e991dfa` with exact staged patch `working-tree-final.patch`, SHA-256 `05a6f8df4fbca9ab50e3752262510372b1d266f01ed3d774679745d4628c7f44`. `candidate.json` records every changed file hash. The later commit records these same bytes; committing is not another runtime run.

## Behavioral scope

The public Personnel source discovers strict Organization-bound expired parents, completes both child manifests in 100-ID cohorts with complete 1,000-row pagination and stable ID order, performs one POST `delete_expired_personnel` RPC, then confirms every file-bearing positive-count cohort before removing files. It awaits both bucket removals before propagating an error. Zero counts and positive counts without file paths retain the previous no-removal/no-confirmation fast path.

The SDK tests use an 8,192-character synthetic provider URL limit and a 1,000-row response-page cap. Literal parent/child rows and retained file bytes establish cutoff/active/recent/foreign preservation, pre-cascade manifest capture, 1,001 parents, more than 1,000 file rows in both buckets, partial and zero deletion, late discovery/cohort/page failures, deletion and late-confirmation errors, invalid count rejection and both Storage outcomes. They establish offline owner/provider mapping and orchestration, not real SQL FK enforcement, Storage behavior, atomic commit proof, UI journeys, concurrency guarantees or durable file-removal retry.

The 10 former central parent tests and one duplicate parent-file case were replaced by 16 owner tests. Maintenance retains 16 meaningful tests for family orchestration, note-before-parent effects/counts, later-family/notification suppression on failure, cutoff settings, summaries and independent artifact families. Route tests retain existing communication delivery/failure protection and add both main/legacy consumer admission and actual owned-source binding; 14 route tests pass. No skips, check waivers or scan reductions were added. Exact full CI, live provider/native proof and migration acceptance remain the coordinator's separate gates.

## Checks

- `npm ci`: exit 0. Node v24.21.0/npm11.19.0; repository pins npm11.12.1. Existing install deprecation, engine, audit and install-script warnings remain in `npm-ci.log`; no dependencies were changed.
- Final focused tests: 3 files/46 tests PASS, `focused-tests-final-complete.log`.
- Final explicit-file Prettier write/check and ESLint: exit 0, recorded argv/results in `final-focused-commands.json`.
- Final `npm run check`: 0 errors/0 warnings; exact unreachable `127.0.0.1:9` and synthetic environment overrides/argv/results in `typecheck-final-command.json`.
- Governance: final exit 0 with 694 unresolved baseline findings, no new findings, unchanged admission/provider exception sets, in `governance-final.log`.
- Working/staged diff whitespace checks: exit 0.

The first governance attempt correctly rejected two edges introduced by importing the central mixed `StoragePort` type. That type import was removed and the factory now accepts its own narrow structural `remove` capability. The failed raw log is preserved as `governance-rejected-mixed-type-import.log`; the final source has no exception for this rejected edge. Initial typecheck logs predate that type-only correction; final focused tests, formatting/lint and typecheck cover the final patch bytes.

No per-run archive was created here. The coordinator will package these raw observations after integration and its owned verification cleanup.
