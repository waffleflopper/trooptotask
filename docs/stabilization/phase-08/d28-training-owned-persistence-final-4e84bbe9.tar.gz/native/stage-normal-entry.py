import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
rp=pathlib.Path(__file__).parent/'runtime.json';s=json.loads(rp.read_text())
d.within('annual-native-delete-confirm','alertdialog','Delete Training Type','button','Delete',2);d.wire('annual-native-delete-wire',2,'training-types');d.call('annual-deleted-sql',['rows','training_types','orgA','id',s['temporaryIds']['annual']],True)
d.act_prefix('expiry-type-select','button','D28 Ordinary Expiry 20261007 Date varies',2);d.act('expiry-type-delete-open','button','Delete Type',2);d.within('expiry-type-delete-confirm','alertdialog','Delete Training Type','button','Delete',2);d.wire('expiry-type-delete-wire',2,'training-types');d.call('expiry-type-deleted-sql',['rows','training_types','orgA','id',s['temporaryIds']['expiry']],True)
for org in ['orgA','orgB']:
 for table in ['training_types','training_views','personnel_trainings','personnel','groups','organizations']:d.call('before-pages-'+org+'-'+table,['rows',table,org],True)
def read(n):return json.loads(json.loads((d.E/(n+'.json')).read_text())['stdout'])
for org in ['orgA','orgB']:
 for table in ['training_types','training_views','personnel_trainings','personnel','groups','organizations']:assert read('original-'+org+'-'+table)['rows']==read('before-pages-'+org+'-'+table)['rows'],(org,table)
(d.E/'before-pages-original-comparison.json').write_text(json.dumps({'status':'PASS','all12FullOriginalRowsetsExact':True,'datedPairAbsent':True,'personCount':3,'typeCount':3,'completionCount':1,'temporaryTrainingTypesViewsCompletionsAbsent':True},indent=2))
d.call('pages-seed',['seed','training-pages'],True);d.call('pages-people-sql',['rows','personnel','orgA'],True);d.act('pages-matrix-return','link','Training',2,index=0);d.act('pages-reports-open','link','Reports',2);d.snap('pages-report-normal',2);d.shot('pages-report-normal',2)
