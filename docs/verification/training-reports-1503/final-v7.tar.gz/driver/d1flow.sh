#!/usr/bin/env bash
# usage: d1flow.sh W H THEME  -> steady / pending(hold) / error(fail) / Retry with native clicks; read-only d1 measurements; screenshots
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7; D=$E/driver/d.sh; cd $ROOT
W=$1; H=$2; TH=$3; L=d1-$TH-$W; mkdir -p $E/measure/d1 $E/png/d1 $E/snap/d1
V="node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1"
T() { local l=$1; shift; $D "$l" -- npm run --silent verify:app -- tool "$@" --worker 1; }
M() { args=$(jq -n --rawfile f "$E/driver/d1.js" --arg fp "$E/measure/d1/$1.json" '{pageId:2,function:$f,filePath:$fp}'); T "d1measure-$1" evaluate_script "$args" >/dev/null; T "d1shot-$1" take_screenshot "{\"pageId\":2,\"filePath\":\"$E/png/d1/$1.png\"}" >/dev/null; jq -c '{status,radios,alert,overlaps,offscreen,docOverflowX,toolbarRows,bl:.bottomLine[0:40]}' $E/measure/d1/$1.json; }
uid() { T "snap-$1" take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/d1/$1.txt\"}" >/dev/null; grep "$2" $E/snap/d1/$1.txt | head -1 | sed -E 's/.*uid=([0-9_]+).*/\1/'; }
O=http://127.0.0.1:42057/org/fd246961-a47d-4153-8599-98e413bf9cdb/training/reports
T "emulate-$L" emulate "{\"pageId\":2,\"viewport\":\"${W}x${H}x1\"}" >/dev/null
T "nav-$L" navigate_page "{\"pageId\":2,\"type\":\"url\",\"url\":\"$O?view=9abba8b1-3e91-4fe0-9d81-50346321846a&role=BriefingBoundaryc30522a4\"}" >/dev/null
M $L-1-steady
$D "arm-hold-$L" -- $V network arm-hold 2 training-reports | head -c 300; echo
u=$(uid $L-p 'radio "30 days"'); T "click30-$L" click "{\"pageId\":2,\"uid\":\"$u\"}" >/dev/null
M $L-2-pending
$D "state-hold-$L" -- $V network state 2 > /dev/null; $D "release-$L" -- $V network release 2 >/dev/null
T "wait30-$L" wait_for '{"pageId":2,"text":["NEXT 30 DAYS"],"timeout":10000}' >/dev/null
$D "restore-hold-$L" -- $V network restore 2 >/dev/null
M $L-3-after-pending
$D "arm-fail-$L" -- $V network arm-fail 2 training-reports >/dev/null
u=$(uid $L-e 'radio "60 days"'); T "click60-$L" click "{\"pageId\":2,\"uid\":\"$u\"}" >/dev/null
T "waiterr-$L" wait_for '{"pageId":2,"text":["Unable to update the briefing"],"timeout":10000}' >/dev/null
M $L-4-error
$D "state-fail-$L" -- $V network state 2 >/dev/null; $D "restore-fail-$L" -- $V network restore 2 >/dev/null
u=$(uid $L-r 'button "Retry"'); T "retry-$L" click "{\"pageId\":2,\"uid\":\"$u\"}" >/dev/null
T "wait60-$L" wait_for '{"pageId":2,"text":["NEXT 60 DAYS"],"timeout":10000}' >/dev/null
M $L-5-retried
