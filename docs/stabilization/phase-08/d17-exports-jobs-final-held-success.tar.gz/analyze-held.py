import json,pathlib,hashlib,subprocess
p=pathlib.Path(__file__).parent;load=lambda n:json.loads((p/(n+'.stdout')).read_text());snapshot=lambda n:load(n)['content'][0]['text']
fixture=load('fixture')['ids'];artifact=json.loads((p/'held-A.json').read_text());saved=load('held-save');network=load('held-network-state')
actorId=json.loads(pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/80ad0b6c7cddb4c6/worker-1/fixtures.json').read_text())['actors']['orgSettingsSwitch']['id'];(p/'public-actor-identity.json').write_text(json.dumps({'role':'orgSettingsSwitch','id':actorId},indent=2)+'\n')
assert artifact['organizationId']==fixture['orgA'];profile=load('before-organizations-orgA')['rows'];assert len(profile[0])==11 and artifact['organizationProfile']==profile
assert all(row['rowCount']==len(artifact['sections'][row['key']])for row in artifact['sectionInventory'])
assert all(fixture[k]not in json.dumps(artifact)for k in ['orgB','personForeign','groupForeign','onboardingForeignTemplate'])
assert network['held'] and len(network['calls'])==1 and network['calls'][0]['status']==200
assert saved['filename']==f"org-export-{fixture['orgA']}-{artifact['exportedAt'][:10]}.json"
assert saved['bytes']==(p/'held-A.json').stat().st_size and saved['sha256']==hashlib.sha256((p/'held-A.json').read_bytes()).hexdigest()
initial=load('held-A-lifecycle')['rows'];assert len(initial)==1 and initial[0]['status']=='completed' and initial[0]['requested_by']==actorId and initial[0]['file_size_bytes']==saved['bytes']
assert load('held-A-lifecycle-after')['rows']==initial==load('final-data_exports-orgA')['rows']
for n in ['before-data_exports-orgB','held-B-lifecycle-before','held-B-lifecycle-after','final-data_exports-orgB']:assert load(n)['rows']==[]
assert 'Generating' in snapshot('held-A-before-switch')
for n in ['held-B-before-release','held-B-after-release','failure-B-after']:
 s=snapshot(n);assert '/org/'+fixture['orgB']+'/settings/exports' in s and 'Verification Organization B' in s
 assert 'Generating' not in s and 'Export downloaded successfully.' not in s and 'Export failed. Please try again.' not in s
 for name in ['Export JSON','Export Excel']:
  matching=[line for line in s.splitlines()if 'button "'+name+'"' in line];assert len(matching)==1 and 'disabled' not in matching[0]
assert load('failure-network-state')['calls'][0]['status']==503 and load('failure-blob-state')['captured'] is False
assert 'Export failed. Please try again.' in snapshot('failure-A-after')
for org in ['orgA','orgB']:assert load('before-organizations-'+org)['rows']==load('final-organizations-'+org)['rows']
for n in ['held-network-restore','held-blob-restore','failure-network-restore','failure-blob-restore']:assert load(n)['restored'] is True
frozen=json.loads((p/'frozen-inputs.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==frozen['revision'];assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for name,v in frozen['files'].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==v['sha256'],name
out={'passed':True,'realHeldA200':True,'persistedBeforeRelease':initial[0],'visibleBIdleEnabledNoOldFeedbackBeforeAfterRelease':True,'intentionalOldADownload':saved,'profileAll11ExactlyMatched':True,'knownForeignIdsExcluded':True,'manifestCountsMatch':len(artifact['sectionInventory']),'bExportRows':0,'storedA503ErrorClearedOnVisibleBSwitch':True,'failureNoBlobOrLifecycleEffect':True,'originalAll11AAndBProfileFieldsUnchanged':True,'restoredAllHooks':True,'frozenTrackedInputsUnchanged':len(frozen['files']),'nativeRequestCount':2,'limits':'No native simultaneous two-hold A→B→A or delayed nonOK body/failure; separate12mounted lifetime cases own those boundaries. Synthetic503 occurs before provider, not provider fault. Ordinary A download finishing after navigation is intended.'}
(p/'held-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
