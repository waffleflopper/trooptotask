import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent.parent
evidence = root / ".verification/evidence/d17-retention-enumeration-baseline"
probe = "src/routes/api/cleanup-archived-records/organizationEnumeration.baseline.test.ts"
overrides = {
    "TMPDIR": "/home/waffleflops/.cache/t2t1365tmp",
    "PUBLIC_SUPABASE_URL": "http://127.0.0.1:9",
    "PUBLIC_SUPABASE_ANON_KEY": "synthetic-key",
    "npm_config_cache": str(root / ".verification/npm-cache"),
}
environment = {**os.environ, **overrides}
commands = []

def run(arguments, log, credited=False):
    result = subprocess.run(arguments, cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (evidence / log).write_text(result.stdout)
    commands.append({"argv": arguments, "environmentOverrides": overrides, "exitCode": result.returncode, "log": log, "credited": credited})
    print(result.stdout, end="")
    return result

format_result = run(["npm", "exec", "--", "prettier", "--write", probe, ".verification/vitest.exports-jobs-baseline.config.ts"], "probe-format.log")
if format_result.returncode:
    raise SystemExit(format_result.returncode)

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
(evidence / "base.txt").write_text(head + "\n")
(evidence / "tree.txt").write_text(subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True))
(evidence / "status-before.txt").write_text(subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=root, text=True))
(evidence / "tracked-before.diff").write_bytes(subprocess.check_output(["git", "diff", "--binary"], cwd=root))
untracked_diff = subprocess.run(["git", "diff", "--no-index", "--binary", "/dev/null", probe], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(evidence / "untracked-probe.diff").write_bytes(untracked_diff.stdout)
shutil.copyfile(root / probe, evidence / "organizationEnumeration.baseline.test.ts")
shutil.copyfile(root / ".verification/vitest.exports-jobs-baseline.config.ts", evidence / "vitest.config.ts")
shutil.copyfile(__file__, evidence / "run-retention-baseline.py")
source_paths = [
    "src/routes/api/cleanup-archived-records/+server.ts",
    "src/routes/api/cleanup-archived-personnel/+server.ts",
    "src/routes/api/cleanup-expired-onboardings/+server.ts",
    "src/lib/server/core/useCases/retentionSupport.ts",
    "src/lib/server/core/useCases/archiveRetention.ts",
    "src/features/onboarding/server/onboardingRetention.server.ts",
    "src/features/personnel/personnelArtifactRetention.server.ts",
    "src/features/personnel/personnelRetention.server.ts",
    "src/features/onboarding/server/onboardingRetentionProvider.server.ts",
    "src/lib/server/adapters/supabaseDataStore.ts",
    "src/lib/server/supabasePagination.server.ts",
    "supabase/config.toml",
    "vitest.config.ts",
    "svelte.config.js",
]
for path in source_paths:
    destination = evidence / "source" / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(subprocess.check_output(["git", "show", head + ":" + path], cwd=root))
versions = {"node": subprocess.check_output(["node", "--version"], cwd=root, text=True).strip(), "npm": subprocess.check_output(["npm", "--version"], cwd=root, text=True).strip()}
for package in ["@supabase/supabase-js", "vitest", "vite", "svelte", "@sveltejs/kit", "typescript", "prettier"]:
    versions[package] = json.loads((root / "node_modules" / package / "package.json").read_text())["version"]
record = {
    "classification": "Controlled installed-SDK dispatch baseline, not live cleanup, database or RLS evidence",
    "base": head,
    "worktree": str(root),
    "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd=root, text=True).strip(),
    "environmentOverrides": overrides,
    "versions": versions,
    "probeSha256": hashlib.sha256((root / probe).read_bytes()).hexdigest(),
    "lockfileSha256": hashlib.sha256((root / "package-lock.json").read_bytes()).hexdigest(),
    "productionDiffEmptyBeforeRun": (evidence / "tracked-before.diff").stat().st_size == 0,
    "commands": commands,
}
(evidence / "record.json").write_text(json.dumps(record, indent=2) + "\n")
sync = run(["npm", "exec", "--", "svelte-kit", "sync"], "sync.log")
if sync.returncode:
    (evidence / "record.json").write_text(json.dumps(record, indent=2) + "\n")
    raise SystemExit(sync.returncode)
result = run(["npm", "run", "test", "--", probe, "--config", ".verification/vitest.exports-jobs-baseline.config.ts", "--configLoader", "runner"], "test.log")
record["baselineExitCode"] = result.returncode
record["productionDiffEmptyAfterRun"] = not subprocess.check_output(["git", "diff", "--binary"], cwd=root)
(evidence / "status-after.txt").write_text(subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=root, text=True))
(evidence / "record.json").write_text(json.dumps(record, indent=2) + "\n")
raise SystemExit(result.returncode)
