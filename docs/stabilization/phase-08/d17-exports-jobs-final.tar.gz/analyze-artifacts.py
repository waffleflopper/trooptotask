from pathlib import Path
import json
p=Path(__file__).parent
def load(n):return json.loads((p/(n+'.stdout')).read_text())
def byid(rows):return sorted(rows,key=lambda r:r['id'])
j=json.loads((p/'owner.json').read_text());f=load('fixture');profile=load('before-organizations-orgA')['rows'];assert j['organizationProfile']==profile and len(profile[0])==11
for key,t in (('memberships','organization_memberships'),('invitations','organization_invitations'),('invitationEmailOutbox','organization_invitation_email_outbox'),('groups','groups'),('personnel','personnel'),('personnelOnboardings','personnel_onboardings'),('onboardingStepProgress','onboarding_step_progress')):assert byid(j[key])==byid(load('before-'+t+'-orgA')['rows']),key
assert len(j['invitationAccessRequestLinks'])==0
assert all(row['rowCount']==len(j['sections'][row['key']])for row in j['sectionInventory'])
assert all(f['ids'][k]not in json.dumps(j)for k in ('orgB','personForeign','groupForeign','onboardingForeignTemplate'))
w=json.loads((p/'owner-workbook-decoded.json').read_text());raw=next(s['rows']for s in w['sheets']if s['name']=='Raw - Organization Profile')
columns=('id','name','created_by','created_at','url_slug','archive_retention_months','suspended_at','critical_tasks_default_expiration_months','critical_tasks_expiring_soon_warning_days','loss_warning_window_days','personnel_document_storage_cap_bytes')
assert raw[1]==[profile[0][k]for k in columns]
inventory=load('owner-excel-inventory-corrected')['rows'];assert len(inventory)==38
expected=[('organizationProfile',1),('memberships',55),('invitations',0),('invitationEmailOutbox',0),('invitationAccessRequestLinks',0)]
assert [(r[4],r[5])for r in inventory[:5]]==expected
captures=[]
for form in ('json','excel'):
 c=load('owner-'+form+'-save');rows=load('owner-'+form+'-lifecycle')['rows'];match=[r for r in rows if r['file_size_bytes']==c['bytes']and r['requested_by']==profile[0]['created_by']];assert len(match)==1 and match[0]['status']=='completed';assert load('owner-'+form+'-network')['calls'][0]['status']==200;captures.append({'format':form,'file':c,'lifecycle':match[0]})
assert load('owner-failure-lifecycle')==load('owner-excel-lifecycle')
assert load('owner-failure-network')['calls'][0]['status']==503
assert not load('owner-failure-blob')['captured']
(p/'artifact-analysis.json').write_text(json.dumps({'status':'PASS','profile11AndFourRawSupportedTablesMatch':True,'selectedGroupsPersonnelPacketsProgressMatchPrivilegedRowsById':True,'manifestRowCountsMatchArtifactSections':len(j['sectionInventory']),'foreignKnownSentinelsExcluded':True,'workbookProfileExactAndRawFiveCounts':expected,'capturedArtifacts':captures,'provenanceLimit':'Zero ordinary visible artifact rows and source fixture expectation zero; no privileged provenance-table count/absence. Positive SDK/table/security tests separate.','failure503':'No Blob, exact unchanged completed export rowsets; synthetic preprovider client control, not provider fault.'},indent=2)+'\n')
print('Owner JSON/Excel all11/raw4/manifest/scope/lifecycle + synthetic503 no effects PASS')
