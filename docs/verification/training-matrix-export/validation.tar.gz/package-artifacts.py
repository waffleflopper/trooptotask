import hashlib
import json
from pathlib import Path
import tarfile
import tempfile

root = Path(__file__).resolve().parent
destination = Path.cwd() / 'docs/verification/training-matrix-export'
destination.mkdir(parents=True, exist_ok=True)
groups = {
    'baseline': list((root / 'baseline').rglob('*')),
    'final': list((root / 'final').rglob('*')),
    'validation': list((root / 'validation').rglob('*')) + list((root / 'initial-validation').rglob('*')) + [
        root / 'run-checks.py', root / 'verify-workbooks.mjs', root / 'candidate.patch',
        root / 'source-review.md', root / 'package-artifacts.py'
    ]
}

def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

results = []
for name, candidates in groups.items():
    files = sorted(file for file in candidates if file.is_file())
    payloads = {str(file.relative_to(root)): digest(file) for file in files}
    inventory = root / (name + '-inventory.json')
    inventory.write_text(json.dumps(payloads, indent=2) + '\n')
    archive = destination / (name + '.tar.gz')
    with tarfile.open(archive, 'w:gz') as stream:
        for file in files + [inventory]:
            stream.add(file, arcname=str(file.relative_to(root)), recursive=False)
    with tempfile.TemporaryDirectory(prefix='extracted-', dir=root) as temporary:
        extracted = Path(temporary)
        with tarfile.open(archive) as stream:
            stream.extractall(extracted, filter='data')
        observed = {str(file.relative_to(extracted)): digest(file) for file in extracted.rglob('*') if file.is_file()}
        saved_inventory = json.loads((extracted / inventory.name).read_text())
        assert observed.pop(inventory.name) == digest(inventory)
        assert observed == saved_inventory == payloads, name
    results.append({'archive': str(archive.relative_to(Path.cwd())), 'sha256': digest(archive), 'payload_files': len(files), 'extraction': 'PASS'})
(root / 'packaging.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
