# D18 export and remaining consumer plan

Read-only investigation at frozen `f952f0bb8d556b6214f8eae639f8111fa7aaf06c`, including main `318cd455` Audit integration. No tracked edits, tests, services, browser or database access. Worker 1 belongs to the coordinator. The controls below are instructions for future proof; none was executed here.

## Smallest native triggers

As existing `orgOwner`, use maintained `actor orgOwner settings/exports` navigation. The visible Settings link is **Exports** (`src/features/organization/SettingsShell.svelte:49`), leading to `/org/<canonical URL segment>/settings/exports`. In **Export → Full organization**, click **Export JSON**, save its actual artifact, restore controls, then independently click **Export Excel**. No picker, modal or confirmation exists. **Export Roster / Coming Soon** is disabled and unrelated (`settings/DataExportSettingsSection.svelte:48-73`). Both active buttons disable while one generates; success text is **Export downloaded successfully.**, failure permits retry.

For each format:

1. Capture independently specified same-A deletion-history witnesses before download; preserve pending/approved/denied/cancelled values and a B sentinel. Capture Audit's A set separately when checking the incoming seam.
2. Arm `network arm-observe PAGE export` (or `export-excel`) plus `export arm PAGE`, then click the visible button once. Capture native before/action/after, actual POST status, Content-Type and Content-Disposition. Use `export state PAGE` then `export save PAGE FILE`; FILE must be below `.verification/evidence/verify-trooptotask`, ending `.json` or `.xlsx`.
3. Parse saved JSON. Inspect Excel with `workbook FILE 'Raw - Deletion Requests'` and `workbook FILE 'Export Inventory'`; optionally inspect `Raw - Audit Logs`. Restore **both** `export restore PAGE` and `network restore PAGE` before the next format/navigation. Keep real downloaded bytes, size/hash and anchor filename.

The helper captures the actual Blob and appended download anchor (`.agents/skills/verify-trooptotask/helpers/control.mjs:1870-1945`); network helper separately captures status/headers (`helpers/network-control.mjs:69-71`). `export request PAGE orgA json|excel` is ordinary HTTP proof, intentionally discards success bytes and is not a native download (`control.mjs:1847-1868`). Workbook defaults to an unrelated sheet, so supply the exact name. Existing recipes: `features/organization-settings-destruction.md:45`, `features/deletion-requests.md:36`.

The Workspace POSTs `/org/<canonical UUID>/api/export` or `/org/<canonical UUID>/api/export-excel` without a body, even when navigation uses a slug (`settings/exports/SettingsDataExportWorkspace.svelte:24-28`). The page supplies `data.orgId` and keys workspace lifetime by that ID (`exports/+page.svelte:8`). Filename is `org-export-<UUID>-<export date>.json|xlsx`; JSON MIME is `application/json`; workbook MIME and attachment use `src/lib/utils/workbook.ts:92-102`. An intentionally requested A download may finish after leaving A; B must keep independent feedback/controls, but that A download alone is not contamination.

## Raw history contract

Manifest entry is `deletionRequests / Deletion Requests / deletion_requests / settings / Settings` (`src/lib/server/core/useCases/organizationDataExportManifest.ts:79`). Preserve full history in both `payload.deletionRequests` and `payload.sections.deletionRequests`, plus its inventory count (`organizationExport.ts:155-170`). Do not substitute the approval projection, filter to pending, join surviving resources, or replace saved requester values with current labels.

The schema defines these 13 fields (`supabase/migrations/20260413001158_remote_schema.sql:1937-1950`): `id`, `organization_id`, `requested_by`, `requested_by_email`, `resource_type`, `resource_id`, `resource_description`, nullable `resource_url`, `status`, nullable `reviewed_by`, `reviewed_at`, `denial_reason`, and `created_at`. Preserve exact saved IDs/strings/reason/URL, null meanings and timestamp precision; include all four statuses, missing-source and historical unsupported resource types. Settings' eight-field DTO (`settingsRows.server.ts:3-11`) is insufficient for export.

Existing generic reader selects `*` with ordinary RLS and complete paging (`supabaseDataStore.ts:206-237`); the owned raw reader must keep that completeness, not reuse a one-row summary. Compare by ID rather than incidental row order.

Excel uses **Raw - Deletion Requests**, with columns built from saved keys (`organizationExportWorkbook.ts:88-90,149-156`). Expected headers: **Id, Organization Id, Requested By, Requested By Email, Resource Type, Resource Id, Resource Description, Resource Url, Status, Reviewed By, Reviewed At, Denial Reason, Created At**. Empty sections have only **No records**, so use nonempty witnesses. Null is an empty Excel cell; timestamp strings remain strings. Compare the identified sheet/row, not a flattened whole workbook (`:182-197`).

## Preserve current Audit integration

`organizationExport.ts:95-97` routes `auditLogs` through public `listAuditExportRows`; `src/lib/audit/exportRetention.server.ts:9-10` returns saved raw values through the admitted ordinary store. Add the D18 reader alongside this branch, before the generic fallback (`organizationExport.ts:149`); retain all manifest sections and 12-query batches (`:74,91`). Audit export is saved raw history, distinct from masked page projections, including excluded auth actions and saved request metadata.

Artifact build precedes Audit emission (`organizationDataExportExecution.ts:39,46`): its own `export.created` or `export.excel_created` event is legitimately absent, while later Excel may include the earlier JSON event. Snapshot each format independently or explicitly account for those events. Lifecycle INSERT precedes build; completion/size is best effort afterward (`:35-44`, `dataExportLifecycle.ts:12-20,36-48`). The artifact can contain its processing snapshot; assess completed lifecycle by later readback.

Keep `organization.exportData` admission in both routes (`api/export/+server.ts:33`, `api/export-excel/+server.ts:35`), **member-manager-or-admin**, independent of review's **admin-or-owner** (`src/lib/access/policyEvaluator.ts:434-442`). An owned export reader must neither add reviewer-only admission nor bypass ordinary RLS. Native positive baseline should use owner/admin; synthetic delegated member-manager route tests do not establish its real database lifecycle INSERT success.

## Remaining delivery/read consumers

Coordinator groups, beyond feature engine and source adapters:

- Settings list/contracts: `settings/settingsApprovals.server.ts` + test, `settingsRows.server.ts`, `settingsSectionTypes.ts`, `approvals/+page.server.ts`. Replace list source/DTO with owner contracts while retaining accepted rail/controller behavior.
- Count/oldest: `settings/settingsShell.server.ts` + test (direct table count at13), `settings/+layout.server.ts`, `settings/members/+page.server.ts` (full history at27), `src/features/organization/membersSettings.server.ts` + test (injected rows at32, summary at248). Inject consumed count/oldest summary; retain sibling concurrency/visibility.
- Exports: `src/lib/server/core/useCases/organizationExport.ts` + test, both `api/export` and `api/export-excel` routes + tests. Bind the consumed owner raw reader per request; no workbook/manifest/UI rewrite needed merely for ownership.
- Commands: `api/deletion-requests` and `review` routes + tests. Review's current global Training construction (`review/+server.ts:48`) becomes request-bound source guard composition.
- Bulk creation: `src/lib/server/personnelArchiveBatchDelivery.ts` + test, `api/personnel/archive-batch` route/test. Migrate creation context; preserve409/per-ID results and cascade-failure acknowledgement limits.
- Web delivery: `src/lib/personnelArchiveRequestDelivery.ts` + test; Personnel list/detail route callbacks; Training `+page.svelte` (local transport at16); Evals `+page.svelte` (owner facade import at4). Move consumed submission to owner, remove global implementation/unused load+cancel. Shared store `ports.ts`/`createStore.svelte.ts` move generic DeleteResult away from deletion transport.
- Shared composition: `httpAdapter.ts`, server `core/ports.ts`, `inMemory.ts` and relevant tests remove broad counseling composition when review owns it. Preserve public Audit imports, added source label exports and removed generic Audit method.

## Meaningful verification

`organizationExport.test.ts` protects manifest/batching/retained values/isolation; both export route `server.test.ts` parse actual format artifacts and test policy/lifecycle. Current explicit saved-value cases cover Training/Rating/communications, with no full-field D18 history fixture. Extend those existing boundary cases with same-A pending/approved/denied/cancelled full rows and B sentinel: both JSON locations and exact Excel raw rows/headers. Owned provider tests separately establish complete paging, ordinary client and raw projection. Generic structured-cell serialization already has coverage (`organizationExportWorkbook.test.ts:104-117`); do not duplicate internals tests.

Retain `settings/exports/page.svelte.test.ts:52-209` for both button requests/busy state, retry, deferred Blob/error bodies and A/B/A lifetime. Native two-button artifact proof remains required. Watch for swallowed provider errors becoming empty success, sequentialized queries, first-page caps, missing terminal/source-absent history, imported approval/Audit projections, or accidentally restored generic Audit coupling. This report claims no runtime result or implementation.
