import json, sys, pathlib, re
transcript, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
calls, results = {}, {}
for line in transcript.read_text().splitlines():
    try: entry = json.loads(line)
    except json.JSONDecodeError: continue
    content = (entry.get('message') or {}).get('content')
    if not isinstance(content, list): continue
    for part in content:
        if part.get('type') == 'tool_use' and re.match(r'mcp__(t3-code__preview|paper__get)', part.get('name', '')):
            calls[part['id']] = {'tool': part['name'].split('__')[-1], 'input': part.get('input'), 'timestamp': entry.get('timestamp')}
        elif part.get('type') == 'tool_result' and part.get('tool_use_id') in calls:
            body = part.get('content')
            if isinstance(body, list):
                body = [b.get('text') if b.get('type') == 'text' else {'type': b.get('type'), 'omitted': 'image bytes'} for b in body]
            results[part['tool_use_id']] = {'is_error': part.get('is_error', False), 'content': body}
index = []
for n, (cid, call) in enumerate(calls.items(), 1):
    record = {**call, 'result': results.get(cid)}
    name = f'{n:04d}-{call["tool"]}.json'
    (out / name).write_text(json.dumps(record, indent=2))
    index.append({'file': name, 'tool': call['tool'], 'timestamp': call['timestamp'], 'error': record['result']['is_error'] if record['result'] else None})
(out.parent / 'raw-index.json').write_text(json.dumps(index, indent=2))
print(len(index), 'captures', sum(1 for i in index if i['error']), 'errors')
