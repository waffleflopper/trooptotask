# Independent final v5 artifact acceptance — #1504 / PR1511

## Verdict and authority

**The mandatory-selection correction is accepted by the archived native evidence at `a586bf50289e92d995d0c1a681f9178030a10f61`. Whole-issue acceptance is not clean: v5 F1 (report Retry focus) and F2 (stale selected-cell state) remain OPEN at that tested pin.** F3 is a retained minor print finding whose visual severity is Claude's delegated judgment. This report does not certify any later source correction or v6 native/PDF outcome.

This is an independent read-only audit of actual expanded archive bytes, structured native receipts, snapshots/evaluations, PDF metadata/text and XLSX XML. It is not a second browser execution, model diversity, or independent visual/layout judgment. No images were viewed; PNGs were hashed as bytes only. No services, tests, network, remote SQL, Git mutation, source/helper/recipe edit or nested delegation occurred. Writes are limited to this report and exclusive scratch `.verification/review-1504-final-v5-e8b17/`.

Poteto generic persona and t2t-engineer were applied under the parent's bounded authority. AGENTS, the repository verification/testing contracts, Poteto's full skill/prompt and relevant Prove It Works / Test Behavior Not Implementation leaves were read in the preceding bounded source round. The saved #1504/#1433 requirements and amendments were reread here: amendments govern, workbook Requirements cover the full filtered report, print uses native `window.print()` and hides controls, and URL state survives reload. No scope or lifecycle authority is inferred from those workflows.

The user boundary remains clean local reviews, push the same **DRAFT** PR and STOP. This review neither changes that boundary nor authorizes ready/monitor/integration or production migration work.

## Exact bindings and byte reconciliation

| Field | Audited value |
| --- | --- |
| Tested source / base | `a586bf50289e92d995d0c1a681f9178030a10f61` / `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Candidate | `6ec840d5d0cb5da2ccd7ce9d8658a1a6f32c965969c24af0672d36cee8404468` |
| Session / origin | `24967de1-ca66-456b-87dc-d17c39503eda` / `http://127.0.0.1:41021` |
| Actor / page | `trainingConfigure`, Organization A `0ae5d810-5492-4b17-a015-4ffb74b5b2f8`, page 2 |
| Browser | `/usr/bin/chromium`, Chromium 152.0.7977.82 Arch Linux, not provisioned |
| Archive | `docs/verification/training-reports-1504/final-attempt-v5.tar.gz` |
| Archive bytes / SHA256 | 1,755,326 / `3227b88d8b18171dc5b9416a729d2252484e854cfbe0bdab7bca481ab1356aaf` |
| Expanded tree | `.verification/packaged/1504/final-attempt-v5` |
| Archive-only commit | `a799b5a41f065f2ce626ea509a75428a64d63703` |

The archive inventory has **749 unique payloads**. Actual expansion has 750 regular files, consisting of those payloads plus `inventory.json`: zero missing, extra or hash-mismatched payloads. The tar has 750 regular file members and no special members; every actual member's bytes match the expanded file. This is independent byte verification, not reliance on the driver verdict or inventory's own claims.

The packaged `root-source-checkpoint.json` names 143 cumulative changed paths. Actual `git diff --name-only BASE TESTED_HEAD` matches its ordered census; every present checkpoint file hash matches the actual immutable Git blob, and all four deletion pins match absent blobs. The checkpoint source patch hash is independently reproduced as `11502bc5c50f16d464b5c3b6669c3a41c971aa7579e773802c00b0d5441b3f06` using its actual scoped serialization (`git diff --binary BASE HEAD -- src scripts supabase .agents/skills/verify-trooptotask`). The full binary diff has a different hash because it includes archive/document paths; that is not a source-pin discrepancy. `git diff a586..a799 --name-status` contains only the added v5 archive. `origin/main` was read again as the stated base.

The earlier complete cumulative source report remains byte-identical: `.verification/1504-independent-final-source-review-v2.md`, 65,587 bytes, SHA256 `a59d7e2f4cee65b43eae768f47fa3936a444529d2ae7f5d6337b8d4199ea342e`. Its 143-path census and 70 inherited-main access dependencies remain historical source reasoning at a586; this v5 audit adds native counterevidence F1/F2 rather than silently converting that earlier scoped source PASS into whole-issue acceptance. The v4 report is also unchanged: 29,516 bytes, SHA256 `645a720997f7622c412dadedb64ca5c88082cdbc6d788ed99c2180324278b0ec`.

The goal migration at the tested source remains **484 bytes**, SHA256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`, `supabase/migrations/20261004100618_training_readiness_goal.sql`. No SQL was executed. Remote application remains a separate release obligation.

## Receipt integrity and evidence classification

`driver/receipts.jsonl` has **311 unique receipts** and 311 actual whole-JSON stdout payloads. There are **310 exit 0 / one exit 2**, and every driver stderr is empty. The driver report's final phrase “all other 309” undercounts by one; the actual index is authoritative. The root launch/fixture/closeout lists contain 3/10/12 receipts respectively; all exit 0, all referenced stdout files exist and parse, and all referenced stderr files are empty.

The sole exit 2 is `145-sel`, a read-only `evaluate_script` whose `getComputedStyle` argument was not an Element. Its result is `INCONCLUSIVE / DEVTOOLS_TOOL`, not a successful product interaction. `147-dsel` repaired that observation and supplies the selected-cell evidence below. No failed or unsupported command was treated as proof of a successful user action.

Native action receipts contain actual `verify:app tool click`, `press_key`, `navigate_page` or `resize_page` calls. Read-only evaluations, snapshots and request lists are observations. Documented network/export/print helpers arm failures, hold responses, capture downloads or restore instrumentation; those commands are not native end-user actions. An exit 0 keypress establishes the observed effect only. ArrowRight/ArrowLeft here prove focus movement with unchanged checked/request state; they do not prove a change of report selection. The 311 receipts are not 311 native interactions.

All 64 before/after network observations associated with the audited action pairs report complete pagination (`hasNextPage=false`, `invalidPage=false`). “No new request” conclusions compare actual request IDs and Training route URLs in those complete native lists, not test mock shapes. Synthetic 503 injection is documented helper instrumentation, not a real failed remote/server request.

## Mandatory selection: independently accepted at a586

Every row below has one native activation between a before observation and its own after observation. All 12 retain exactly one checked option in each present group, the same canonical checked values, URL and range, and no new Training request. Each after state was inspected separately; two actions were not combined into one final assertion.

| Already active option | Pointer receipt | Space receipt | After each activation |
| --- | --- | --- | --- |
| 25 rows per page | `020-ps25-click` | `021-ps25-space` | 25 on / 100 off; Rows 1–2 of 2; focus 25 |
| 90 days | `022-h90-click` | `023-h90-space` | 90 on; detail still Rows 1–2 of 2; focus 90 |
| Group | `024-group-click` | `025-group-space` | Group on; detail still open; focus Group |
| 100 rows per page | `031-ps100-click` | `032-ps100-space` | 100 on / 25 off; Rows 1–2 of 2; focus 100 |
| MOS | `036-mos-click2` | `037-mos-space` | MOS and 30 on; URL `?horizon=30&rowsBy=mos`; focus MOS |
| 30 days | `038-h30-click2` | `039-h30-space` | 30 and MOS on; same URL; focus 30 |

The initial six repeat actions retain request IDs 134/139/143 only (Training load, Reports load, detail). The later active-100 repeats retain 144 as the last relevant ID; 30/MOS repeats retain 147. Unlike old v4 at 53ab, no active option becomes unchecked. This evidence accepts the mandatory-selection source correction; old v4 F1 remains a true historical failure at 53ab and is not rewritten.

Real changes also preserve narrow request behavior: `030` → detail request 144 with `pageSize=100`; `033` → detail 145 with default page size omitted; `034` → summary 146 `?horizon=30`, checked 30, detail closes; `035` → summary 147 `?horizon=30&rowsBy=mos`, checked MOS. Each is one new relevant GET with status 200. The 100/25 changes retain two detail rows, rather than changing the facts behind them.

Native reload `040` preserves 30/MOS and the exact query. `042-reloaded-state` and `043-reload-snap` show 30 and MOS checked, 30-day dates through 3 Nov and 11B/68W rows. The fetch/xhr request list has no `/api/training-reports` summary; the complete `044-reload-docreq` includes the successful report document request 148 at the exact bookmarked URL. Reload BODY focus is ordinary navigation context and is not used as F1 evidence.

The original fixture is literal: 3 soldiers; today 4 Oct 2026; 4 applicable requirements; Ready 1, expired 0, missing 3, lapses 0; **25%** today and horizon. Original Alpha is aggregate **50%**, with Required 100% and Targeted 0%; “Alpha 100/0” refers to per-type values, not its aggregate. The only original completion is Able's Required training (27 Sep 2026 through 27 Sep 2027); Required applies to all three people, Targeted only to Able, and Optional remains excluded. The initial Total Required detail is Baker and Unassigned, both Not Done, no expiration and no horizon lapse, range 1–2 of 2. SECTION focus after opening is actual native evidence.

### Held and failed choices

`051` arms a documented hold; native `052` chooses 180. While held, 180/MOS are checked, the old URL and briefing remain 30/MOS, and Updating briefing is true. `053-net-state-held` records one successful held GET. Native Tab `055` moves focus to Group. After release `057`, `058` shows canonical URL 180/MOS, 180 checked, no alert and focus still Group. This proves no response-driven focus steal in that case.

`061` arms one 503; native `063` chooses Duty role. `064-net-state` records one synthetic failed GET. Radios revert to loaded 180/MOS, URL remains 180/MOS, error states that the last loaded briefing is shown, and focus remains the attempted Duty role control. After restoring the hook, `067` pointer Retry succeeds as request 269 with 180/role and correct URL/checked state, but focus becomes BODY (F1). A second failure on Group, Shift+Tab to Retry, hook restoration and native Enter `075` succeeds as request 270 with 180/Group, but also ends on BODY (F1).

The analogous detail failure path is distinct: `082` opens Total Required under injected 503 with SECTION focus and canonical 180/Group/25 controls. After two native Tabs reach Retry (`086-focus-2-state`), native Enter `087` while the detail response is held moves focus to the stable labelled detail SECTION; after release `090` still has SECTION focus and Rows 1–2 of 2. Report-level Retry has no equivalent stable target at this tested pin.

## Open findings at the tested source

| Finding | Severity / disposition | Independent evidence and limits |
| --- | --- | --- |
| V5 F1: report Retry loses focus | P3, **OPEN at a586** | Native pointer `067-retry-action` and Enter `075-retry-enter-action`; both after-state observations show `focus.tag=BODY` after successful retry, with correct requests/URL/data. Enter before-state actually focuses Retry. This is actionable interaction/a11y counterevidence despite selection PASS. |
| V5 F2: stale cell selection when detail closes | P3, **OPEN at a586** | Native horizon change `142-h60-1440-action` succeeds; detail disappears. `147-dsel` still finds `TD data-selected="true"`, text `0`, while `detail=false`. Native snapshots remove ", selected" from the 11B Required button label. The selection state disagrees with the controlled detail state. Visual dashed-outline appearance is delegated Claude judgment, not independently viewed here. |
| V5 F3: short detail heading/table split | P3 minor, **retained at a586** | Actual four-page PDF text has the Affected soldiers eyebrow/heading/status/range on page 3 and the one-row Baker table alone on page 4. That page boundary is independently established. Whether it fits, is legible or merits a visual pass is Claude's delegated judgment. No later corrected PDF is certified. |
| N1: Tab stop can be unchecked | Observation; baseline **not established** | Initial 30 has tabIndex 0 while 90 is checked; after reload Group has tabIndex 0 while MOS is checked; native Tab `055` actually lands on Group. No independent base execution or baseline comparison establishes this as a new regression. |
| Console warning/error recurrence | Retained counterevidence; no clean-console claim | `130-console` has LayerCake zero/negative-width warning count 2 and negative `<rect>` width errors, plus local MIME/404/preload messages. Driver cannot attribute chart warnings to a particular navigation/print. Metadata/text do not prove chart geometry or absence of impact. |

For F1, actual immutable source confirms the lifecycle explanation: `TrainingReportsPage.svelte:344` calls `session.retry()` directly; `trainingBriefingSession.svelte.ts:80` changes the error request to loading, unmounting the `{#if ... error}` state containing Retry, and no report-level focus transfer exists. Detail Retry instead calls `retryDetail()` plus `focusDetail()`. This is an inference from source consistent with both native reproductions. The artifacts do not capture report Retry BODY focus during a held loading interval, so only the observed successful after-state is certified.

For F2, actual immutable source confirms a consumer/primitive mismatch: page lines 154–158 derive no selected cell when detail is idle and pass it at line 481; unchanged shared `operational-matrix/root.svelte:41–42` returns `selectedCell ?? internalSelectedCell`, preserving internal click memory when the controlled prop becomes undefined. The shared primitive bytes are unchanged versus main. This identifies the briefing consumer's current behavior without making a new broad shared-component regression claim. The stale state after a Focus-link scope and whether it prints without a detail were not exercised here.

Fix work occurring after a586 cannot close these findings in this report. A later source review can accept implementation reasoning; native Retry and selected-cell state, plus a newly captured PDF for F3, require evidence bound to that later pin.

## Actual workbook: values and full report scope

The saved file `training-report-30-mos.xlsx` is **11,428 bytes**, SHA256 `b1986bf8300ae4107ff91450851b01b76a1e6aae09ffcd106fdd1ef454299ac6`. Actual ZIP relationships, `workbook.xml`, shared strings and worksheet cells were parsed, not merely driver sheet summaries. It contains exactly these five ordered sheets: **Summary, Forecast, Hot spots, Focus, Requirements**. No formulas are present.

Summary states Organization A, 3 soldiers, 4 Oct 2026 through 3 Nov 2026, goal 90, 25→25, drop 0, Ready 1/applicable 4/expired 0/missing 3/lapse 0; all population/type filters are full report scope, Horizon 30 days and Rows by MOS. Forecast has today plus 11/18/25 Oct, 1 Nov and exact 3 Nov end; all ready 1/25%, zero lapses, final short bucket 2–3 Nov. Hot spots has 11B (1 soldier, Required 0, Targeted blank, 0→0), 68W (2, Required 50, Targeted 0, 33→33) and Total (3, Required 33, Targeted 0, 25→25). Focus has the two standing-gap templates with counts 2 and 1 and what-ifs 25→75 and 25→50. Values match the native dated 30/MOS briefing.

Requirements has **three** complete affected requirements: Able / Alpha / Targeted, Baker / Bravo / Required and Unassigned / no Group / Required. All are Not Done, blank expiry/lapse date and No horizon lapse. No current Able Required, Optional, inapplicable or foreign row appears. The active native 11B detail `103` has only Baker (Rows 1–1 of 1), so the workbook directly proves full filtered report scope independent of that narrowed detail.

The driver sent **two** actual native Export clicks (`106-click-export` and `106-click-export-native`, two seconds apart). The documented network observer records two successful GETs with the correct attachment filename and XLSX MIME, and one Blob is saved with matching bytes/hash. This supports successful exports from the action sequence; it does not establish one product action spontaneously duplicated a request, nor a one-click export request-count proof. Driver error is retained.

## Actual native print capture: metadata and text

The native `123` reopens the narrow 11B detail; `124-print-arm` has before=0/after=0; `125-click-print` actually clicks Print brief. **Before capture**, `126-print-state` has armed=true/before=1/after=0. Receipt times are sequential: arm 14:49:44, native click 14:49:53, pre-capture state 14:49:57, save 14:50:01 (UTC−08). `127-print-save` binds page 2, the exact 30/MOS URL, candidate/session and saved PDF hash. The hook is restored by `128`. This is a native print invocation followed by the documented capture, rather than a helper call being counted as clicking Print.

Actual `training-brief-30-mos.pdf` is **174,542 bytes**, SHA256 `dbc2175e4d7f0266aee06111a757298dcb387e353e9a558b1fe26368b35971c8`. Independent `pdfinfo` and per-page text extraction establish **four nonblank letter-landscape pages, each 792×612 pt**. Page text is:

1. Training Reports, Organization A / 3 soldiers / as of 4 Oct, full filter line (30 days, MOS), 25→25 by 3 Nov and counts 1/0/3/0.
2. 30-day forecast, Goal 90%, 25% start/end and Today 4 Oct / 1 Nov / 3 Nov labels; MOS hot spots 11B/68W/Total with expected values.
3. Type risks Required 2/0 and Targeted 1/0; both Focus templates/what-if values; narrow 11B Affected soldiers eyebrow, heading, status and Rows 1–1 of 1.
4. Table headers and Baker / Bravo / Required / Not Done / “-” expiration / No lapse.

The text has no Export Excel, Print brief, Rows per page, Retry, Navigation, Account, View-soldiers links, Notifications or toast label. The filter text legitimately includes Rows by MOS and the chart includes Next 30 days. This bounds text/control suppression; it does not independently establish clipping, colors, geometry, selected outlines, overall legibility or a clean visual printout. The four-page metadata excludes an extra blank fifth page, but pixel-only defects were not inspected. No system-dialog or physical-print outcome is established.

The driver dispatch receipt confirms `claudeAgent`, `claude-opus-5-5`, medium effort, `inheritHistory=false`. Its report states it visually inspected all four rendered pages and the 1440/390 screenshots. Those are delegated visual judgments. This audit separately verifies the native receipt chain and downloaded contents; it supplies no duplicate image judgment or independent execution.

## Restoration, ownership and privacy

There were no created UI rows or seeded cohorts in this v5 run. Original/restored root provider files for all four protected tables in both Organizations are independently **byte-identical and JSON-identical**. Driver `172-rows-*` also equals each original JSON object. Counts are A/B: completions 1/0; training types 3/1; training views 1/1; organizations 1/1. Driver preferences and root original/restored preference JSON all match, with empty preferences/progress.

| Table / Organization | Bytes | Original and restored SHA256 |
| --- | --- | --- |
| personnel_trainings / orgA | 592 | `4e5bc4fbd7576c779bd37b7abf2170c5d50699daad195846b9d5b05d1fccc4b7` |
| personnel_trainings / orgB | 91 | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| training_types / orgA | 2255 | `b4d79770f3c733dcd146b2f7b75b0ab6a668d3d11074ba533d7da317dd332c8c` |
| training_types / orgB | 792 | `8636b3d4648a2351a9f08db59987c7da8c70c3eac8a6a2e8c3764020efe0dd36` |
| training_views / orgA | 556 | `356b2ad8f67356240e1415dd27b8e47ed4f726a05decb7a0802f562319f15a9b` |
| training_views / orgB | 505 | `c6ce87b720e4e0a544588975e89d31011776c2e35748ac49efd452b21f6be619` |
| organizations / orgA | 656 | `ec00796ae07bc37a719052451cb3a9ba2285610de835e578dce7067f78b8233f` |
| organizations / orgB | 656 | `2833c60a8485c93d223efc75d9118562cb6177d6efb92c62419f64b4aba3081a` |

Preferences: 211 bytes, SHA256 `cd27ce7bd8fc3b01722a386c52d5868503365da2f627cfab2dcad6b1e7c59715`, equal original/restored and driver readback.

Native `160` restores 1905×2053, `162` restores default 90/Group and `/reports`, and `170` clicks the Training breadcrumb back to the original Training route. Read-only `163-w` shows the original two mode-watcher storage keys, mode system, empty theme, empty HTML class and no `__map*` globals. Theme/sidebar were not toggled; original observation shows light/system and no sidebar cookie. Documented network/export/print restore receipts `060/066/074/083/091/110/111/128` succeed. SvelteKit navigation session keys are disposable profile state; no stronger byte-equivalence of the entire browser profile is claimed.

Start, after-restoration and closeout root doctors and driver `000`/`180` all match the exact candidate, a586 revision, session, origin and Chromium version and report PASS. Root cleanup reports `phase=cleaned`. Captured root absence proof records:

| Owner | PID | Expected start | Recorded command SHA256 |
| --- | --- | --- | --- |
| Supervisor | 4119525 | 154662679 | `210dea5922d87d5ff915ed6eb494748ccfeb1d11f6682572a950f821ea85501c` |
| App | 4127886 | 154668514 | `bf984fc2c10d911a2a8515b63d1f22d404b6d29e1b3374124754a079ca8b0b4f` |
| MCP | 4127931 | 154668581 | `bc5c4c5df883c788b5b4a4aacfbc325d98db9a7c7e413f0e8b49167634bc832e` |
| Browser | 4127943 | 154668617 | `827476123339f3bad0c2c488190249c040bbe5ec5cfc442e1a330201c782f5b6` |

Each entry has `exactOwnedProcessAbsent=true`, `profileProcessIds=[]`, `privateWorkerDirectoryAbsent=true` and `proofPayloadsStillExist=true`. These are exact recorded cleanup facts inspected by this reviewer, not a new OS process execution or live cleanup inspection by this lane. A later run's existence cannot retroactively invalidate this closed session's historical proof.

All 750 expanded files were scanned as bytes for JWT-shaped secrets, concrete Bearer values, private-key headers, concrete access/refresh/client/service-role token assignments and `sb_secret_` keys; decoded actual PDF text and XLSX values were separately scanned. **Zero matches**. Structured readbacks contain synthetic fixture identifiers/rows, not auth tokens. This is a bounded privacy scan, not a guarantee against unknown encodings or pixel-only secrets; no image was viewed.

## Limits, retained counterevidence and disposition

This v5 round targets the selection correction and its nearby failure/reload/export/print paths. It does not rerun the full v1–v4 journey, many-type/dark/empty printing, seeded long paging, Onboarding and reverse consumers, Organization/session races, denied access/RLS, remote release or system printing. Prior complete source and v4 native/artifact reviews retain their exact tested pins and limits. Earlier checks are saved execution proof; this reviewer ran no tests.

Narrow viewport native controls continue to change the report: `142` chooses 60/MOS (request 398); `153` chooses Group at 390 (399); arrows `155/158` move focus without selection/request changes; `162` restores 90/Group (400). DOM sizes and screenshot existence are observed artifacts; overflow, visual control distinction, chart recovery and readability remain delegated visual judgments.

The selection defect is resolved by native evidence at a586. **F1 and F2 require correction and later-pin native evidence before clean whole-issue acceptance.** F3 retains the independently confirmed page split and delegated minor visual judgment pending a later PDF. N1 lacks a baseline regression proof; warnings stay in evidence and prohibit a clean-console claim. A future source commit, green unit tests or driver assertion cannot be substituted for those later native/PDF receipts.

## Evidence hashes and reproducible audit scratch

The inventory hash covers the per-payload mapping; the following selected files provide direct anchors. All paths below are relative to the expanded v5 tree unless prefixed `.verification/`.

| Evidence | Bytes | SHA256 |
| --- | --- | --- |
| `inventory.json` | 103256 | `2029d965c2eda556d56658077a34bc2640d179fae5ff1ede7fb29c0602e27a33` |
| `driver/receipts.jsonl` | 180142 | `dbc4f977132ff3a89095d8bf48b5928f074bd48f25df80cd55d01ad928a816a2` |
| `root-source-checkpoint.json` | 34647 | `821244f76c0b5bea3fbd6731c955b43ae3d554163e075ca7ab0fe7cf91e7eaa9` |
| `driver/067-retry-after-state.out` | 2542 | `6275789475181db9eb41d50aebb42e998d0531126bddb40be51e939bc6188930` |
| `driver/075-retry-enter-before-state.out` | 2634 | `2336979821507dbea918d65cfa6b6d5f6686d80a90356ef7cdc12365bbc64759` |
| `driver/075-retry-enter-after-state.out` | 2518 | `b6a2348f8966809d872d5333518a1022dfc8dd4c48df5347fc46697d7232b1f5` |
| `driver/147-dsel.out` | 370 | `bca48eebaeaeec13a23bc6d379479ece417921ff6696967a5d70bcb0f5b560b1` |
| `driver/142-h60-1440-after-snap.txt` | 9407 | `76373cca631a1b61b6b804bfe622b9ebc270a73e09b9885d5c3f7d36f7fc8a85` |
| `driver/126-print-state.out` | 49 | `788f46ceab7b3abbce6f7a313a2bfca72dd10b64abd34ba040036652bf4c43c9` |
| `driver/127-print-save.out` | 559 | `eb5e3a9642dfb5cd8d78c5c3632c44c3247f79c2dd4441d5a0eee161490e6d9c` |
| `root-restoration-audit.json` | 1218 | `2bcd962374029764ffa01558a42275a5990d458ce471aea1c7bd361d68f8f3ac` |
| `root-owned-absence.json` | 1119 | `c9ea308ff7d62148d795dea8a3ee8ab68569be1fa2184224781d8408b6f1b502` |
| `root-1504-final-acceptance-v5-report.md` | 18599 | `af18b796c1e9cf571d0401d88dda2c2c467cdbb923c9653ab5411c47ed5f1f90` |
| `.verification/1504-final-attempt-v5-closeout.json` | 564 | `2d137d1982ee8f8d4c5f1add9d9b52deafafd75c8c6f53a7082c86ab741544c4` |

Scratch contains actual inventory/tar reconciliation, all 311 parsed outputs and 83 parsed evaluation values, 32 per-action comparisons, 12 strict repeated-activation checks and 64 complete-network checks, decoded workbook/PDF content, restoration/privacy comparisons and immutable source-pin reconciliation. These are reviewer-created offline analyses of archived evidence, not fresh native execution. The report and scratch do not modify prior receipts or prior reports.
