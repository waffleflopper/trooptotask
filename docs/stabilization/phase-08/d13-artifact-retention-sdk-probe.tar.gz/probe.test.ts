import { createHash } from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { describe, expect, it } from 'vitest';
import { createSupabaseDataStore } from '$lib/server/adapters/supabaseDataStore';
import { createSupabaseStorageAdapter } from '$lib/server/adapters/supabaseStorage';
import { bindLeaderNoteDataSource } from '$lib/server/adapters/leaderNoteDataSource';
import { cleanupArchivedRecords } from '$lib/server/core/useCases/archiveRetention';
import type { NotificationDeliveryPort } from '$features/notifications/contracts';

const ORG_A = 'd130b000-0000-4000-8000-000000000001';
const ORG_B = 'd130b000-0000-4000-8000-000000000002';
const PARENT_A = 'd130a000-0000-4000-8000-000000000001';
const PARENT_B = 'd130a000-0000-4000-8000-000000000002';
const NOW = new Date('2026-10-01T12:00:00.000Z');
const EXPIRED = '2000-01-01T12:00:00.000Z';
const RECENT = '2026-09-30T12:00:00.000Z';
const EQUAL = '2023-10-01T12:00:00.000Z';
const URL_CEILING = 8192;
const REPRESENTATION_CAP = 1000;
const families = [
	{ table: 'personnel_follow_ups', key: 'personnel-follow-ups', index: 1 },
	{ table: 'counseling_records', key: 'counseling-records', index: 2, bucket: 'counseling-files' },
	{ table: 'personnel_documents', key: 'personnel-documents', index: 3, bucket: 'personnel-documents' },
	{ table: 'leader_notes', key: 'leader-notes', index: 4 }
] as const;
type Family = (typeof families)[number];
type Failure = 'delete' | 'confirmation' | 'storage';
interface Row {
	id: string;
	organization_id: string;
	personnel_id: string;
	archived_at: string | null;
	status?: string;
	completed_at?: string | null;
	file_path?: string;
}
interface Receipt {
	method: string;
	path: string;
	urlBytes: number;
	retryCount: number;
	query: [string, string][];
	requestIds: string[] | null;
	status?: number;
	matchedIds?: string[];
	returnedIds?: string[];
	removedIds?: string[];
	storagePaths?: string[];
	removedPaths?: string[];
	guard?: string;
}

function rowId(family: Family, index: number) {
	return `d130${family.index.toString(16).padStart(4, '0')}-0000-4000-8000-${index.toString(16).padStart(12, '0')}`;
}
function bucketFor(family: Family) {
	return 'bucket' in family ? family.bucket : null;
}
function rowFor(family: Family, index: number, org: string, archived: string | null): Row {
	const id = rowId(family, index);
	const parent = org === ORG_A ? PARENT_A : PARENT_B;
	return {
		id,
		organization_id: org,
		personnel_id: parent,
		archived_at: archived,
		...(family.table === 'personnel_follow_ups' ? { status: archived ? 'archived' : 'open' } : {}),
		...(bucketFor(family)
			? {
					file_path:
						family.table === 'personnel_documents'
							? `${org}/personnel/${parent}/documents/${id}-synthetic.pdf`
							: `${org}/counseling-records/${parent}/${id}-synthetic.pdf`
				}
			: {})
	};
}
function inIds(filter: string | null) {
	return filter?.startsWith('in.(') ? filter.slice(4, -1).split(',') : null;
}

// Only the actual SDK and adapters construct requests. This finite REST model
// checks serialization, orchestration and provider errors; it is not SQL/RLS.
function probe(family: Family, count: number, failure?: Failure) {
	const expired = Array.from({ length: count }, (_, index) => rowFor(family, index + 1, ORG_A, EXPIRED));
	const retained = [
		rowFor(family, 2001, ORG_A, null),
		rowFor(family, 2002, ORG_A, RECENT),
		rowFor(family, 2003, ORG_A, EQUAL),
		rowFor(family, 2004, ORG_B, null),
		rowFor(family, 2005, ORG_B, RECENT)
	];
	if (family.table === 'personnel_follow_ups')
		retained.push({ ...rowFor(family, 2006, ORG_A, null), status: 'completed', completed_at: RECENT });
	const state = {
		parents: [
			{ id: PARENT_A, organization_id: ORG_A, archived_at: null },
			{ id: PARENT_B, organization_id: ORG_B, archived_at: null }
		],
		rows: Object.fromEntries(
			[...families.map((item) => item.table), 'ict_tasks', 'assignment_types'].map((table) => [table, []])
		) as Record<string, Row[]>,
		files: new Map<string, Buffer>(),
		receipts: [] as Receipt[],
		parentCalls: [] as { org: string; cutoff: string }[],
		notifications: [] as Parameters<NotificationDeliveryPort['notifyAdmins']>[]
	};
	state.rows[family.table] = structuredClone([...expired, ...retained]);
	const bucket = bucketFor(family);
	if (bucket) {
		for (const row of [...expired, ...retained])
			state.files.set(`${bucket}:${row.file_path}`, Buffer.from(`synthetic bytes for ${row.id}`));
		state.files.set(`${bucket}:${ORG_A}/verification-retention/unrelated.pdf`, Buffer.from('unrelated retained bytes'));
	}
	// Small file faults also prove that earlier durable work survives, while the
	// later Note family and parent source never begin.
	const earlier = failure ? rowFor(families[0], 9001, ORG_A, EXPIRED) : null;
	const later = failure ? rowFor(families[3], 9001, ORG_A, EXPIRED) : null;
	if (earlier && later) {
		state.rows.personnel_follow_ups.push(earlier);
		state.rows.leader_notes.push(later);
	}
	const before = snapshot(state);
	const expectedFileKeys = bucket
		? [
				...retained.map((row) => `${bucket}:${row.file_path}`),
				`${bucket}:${ORG_A}/verification-retention/unrelated.pdf`
			].sort()
		: [];
	const client = createClient('http://127.0.0.1:9', 'synthetic-sdk-probe-key', {
		auth: { persistSession: false, autoRefreshToken: false },
		global: {
			fetch: async (input, init) => {
				const url = new URL(String(input));
				const method = init?.method ?? 'GET';
				const resource = url.pathname.split('/').at(-1)!;
				const receipt: Receipt = {
					method,
					path: url.pathname,
					urlBytes: Buffer.byteLength(url.href),
					retryCount: Number(new Headers(init?.headers).get('X-Retry-Count') ?? 0),
					query: [...url.searchParams],
					requestIds: inIds(url.searchParams.get('id'))
				};
				state.receipts.push(receipt); // Before the URL guard, including refused requests.
				const reject = (status: number, message: string) => {
					receipt.status = status;
					return Response.json({ message }, { status });
				};
				if (receipt.urlBytes > URL_CEILING) {
					receipt.guard = 'URI too long';
					return reject(414, 'URI too long');
				}
				if (url.pathname.startsWith('/storage/v1/object/')) {
					if (method !== 'DELETE') throw new Error('Unexpected synthetic Storage method');
					const { prefixes } = JSON.parse(String(init?.body)) as { prefixes: string[] };
					receipt.storagePaths = prefixes;
					if (failure === 'storage' && resource === bucket) return reject(503, 'storage unavailable');
					receipt.removedPaths = prefixes.filter((path) => state.files.delete(`${resource}:${path}`));
					receipt.status = 200;
					return Response.json(receipt.removedPaths.map((name) => ({ name })));
				}
				if (!url.pathname.startsWith('/rest/v1/') || !(resource in state.rows) || !['GET', 'DELETE'].includes(method))
					throw new Error(`Unexpected synthetic REST request: ${method} ${url.pathname}`);
				const params = url.searchParams;
				const rows = state.rows[resource].filter((row) =>
					[...params].every(([key, filter]) => {
						if (['select', 'offset', 'limit', 'order'].includes(key)) return true;
						if (key === 'organization_id') return filter === `eq.${row.organization_id}`;
						if (key === 'status') return filter === `eq.${row.status}`;
						if (key === 'id') return inIds(filter)?.includes(row.id) ?? filter === `eq.${row.id}`;
						if (key === 'archived_at') {
							if (filter === 'not.is.null') return row.archived_at !== null;
							if (filter.startsWith('lt.'))
								return row.archived_at !== null && Date.parse(row.archived_at) < Date.parse(filter.slice(3));
						}
						throw new Error(`Unsupported finite REST filter: ${key} ${filter}`);
					})
				);
				receipt.matchedIds = rows.map((row) => row.id);
				if (method === 'DELETE') {
					if (failure === 'delete' && resource === family.table) return reject(503, 'database delete unavailable');
					const removed = new Set(rows.map((row) => row.id));
					state.rows[resource] = state.rows[resource].filter((row) => !removed.has(row.id));
					receipt.removedIds = [...removed];
				} else if (failure === 'confirmation' && resource === family.table && receipt.requestIds)
					return reject(503, 'confirmation unavailable');
				if (params.get('order') === 'id.asc') rows.sort((a, b) => a.id.localeCompare(b.id));
				const offset = Number(params.get('offset') ?? 0);
				const limit = Math.min(REPRESENTATION_CAP, Number(params.get('limit') ?? REPRESENTATION_CAP));
				const returned = rows.slice(offset, offset + limit);
				receipt.returnedIds = returned.map((row) => row.id);
				receipt.status = 200;
				const fields = params
					.get('select')
					?.split(',')
					.map((field) => field.trim());
				return Response.json(
					returned.map((row) =>
						fields ? Object.fromEntries(fields.map((field) => [field, row[field as keyof Row]])) : row
					)
				);
			}
		}
	});
	const store = createSupabaseDataStore(client);
	const ports = {
		store,
		storage: createSupabaseStorageAdapter(client),
		leaderNotes: bindLeaderNoteDataSource(store),
		personnel: {
			async deleteExpired(org: string, cutoff: string) {
				state.parentCalls.push({ org, cutoff });
				return 0; // Explicitly no parent SQL/cascade proof in this probe.
			}
		},
		assignmentTypes: {
			async deleteExpiredUnreferenced() {
				throw new Error('No Assignment Type candidates are in this probe');
			}
		},
		notifications: {
			async notifyAdmins(...args: Parameters<NotificationDeliveryPort['notifyAdmins']>) {
				state.notifications.push(args);
			}
		}
	};
	return { family, count, failure, state, ports, before, expired, retained, expectedFileKeys, earlier, later };
}

function snapshot(state: {
	parents: { id: string; organization_id: string; archived_at: null }[];
	rows: Record<string, Row[]>;
	files: Map<string, Buffer>;
}) {
	return {
		parents: structuredClone(state.parents),
		rows: structuredClone(state.rows),
		files: [...state.files].map(([path, bytes]) => ({
			path,
			bytes: [...bytes],
			sha256: createHash('sha256').update(bytes).digest('hex')
		}))
	};
}
async function execute(run: ReturnType<typeof probe>) {
	let result;
	let error: string | null = null;
	try {
		result = await cleanupArchivedRecords(
			run.ports,
			[
				{ id: ORG_A, retentionMonths: 36 },
				{ id: ORG_B, retentionMonths: 36 }
			],
			{ now: NOW }
		);
	} catch (caught) {
		error = caught instanceof Error ? caught.message : String(caught);
	}
	// Full finite sets and public synthetic receipts are emitted without pretty-
	// printer truncation. SDK headers/credentials are deliberately omitted.
	process.stdout.write(
		'PROBE_RECEIPT=' +
			JSON.stringify({
				family: run.family.table,
				count: run.count,
				failure: run.failure ?? null,
				urlCeiling: URL_CEILING,
				representationCap: REPRESENTATION_CAP,
				before: run.before,
				after: snapshot(run.state),
				requests: run.state.receipts,
				parentCalls: run.state.parentCalls,
				notifications: run.state.notifications,
				result: result ?? null,
				error
			}) +
			'\n'
	);
	return { result, error };
}

describe('unchanged independent artifact retention through actual Supabase SDK adapters', () => {
	it.each(families)(
		'$table removes all 1,001 expired rows with bounded URLs, truthful counts and retained controls',
		async (family) => {
			const run = probe(family, 1001);
			const observed = await execute(run);
			expect.soft(observed.error).toBeNull();
			expect.soft(observed.result?.deletedCount).toBe(1001);
			expect.soft(observed.result?.families.find((item) => item.key === family.key)?.deletedCount).toBe(1001);
			expect.soft(run.state.rows[family.table]).toEqual(run.retained);
			expect.soft(run.state.parents).toEqual(run.before.parents);
			expect.soft([...run.state.files.keys()].sort()).toEqual(run.expectedFileKeys);
			for (const file of run.before.files.filter((file) => run.expectedFileKeys.includes(file.path)))
				expect.soft([...run.state.files.get(file.path)!]).toEqual(file.bytes);
			expect.soft(run.state.receipts.filter((receipt) => receipt.urlBytes > URL_CEILING)).toEqual([]);
			expect.soft(run.state.notifications).toHaveLength(1);
		}
	);

	for (const family of families.filter((item) => bucketFor(item))) {
		it.each(['delete', 'confirmation', 'storage'] as const)(
			`${family.table} %s failure reports rejection and stops later work with explicit partial effects`,
			async (failure) => {
				const run = probe(family, 1, failure);
				const observed = await execute(run);
				const expectedError = {
					delete: 'database delete unavailable',
					confirmation: 'confirmation unavailable',
					storage: 'Storage remove failed: storage unavailable'
				}[failure];
				expect(observed.error).toBe(expectedError);
				expect(observed.result).toBeUndefined();
				expect(run.state.rows[family.table]).toEqual(
					failure === 'delete' ? [...run.expired, ...run.retained] : run.retained
				);
				expect(snapshot(run.state).files).toEqual(run.before.files);
				expect(run.state.rows.personnel_follow_ups).toEqual([]);
				expect(run.state.rows.leader_notes).toEqual([run.later]);
				expect(run.state.receipts.some((receipt) => receipt.path.endsWith('/leader_notes'))).toBe(false);
				expect(run.state.parentCalls).toEqual([]);
				expect(run.state.notifications).toEqual([]);
				expect(run.state.parents).toEqual(run.before.parents);
				expect(run.state.receipts.every((receipt) => receipt.urlBytes <= URL_CEILING)).toBe(true);
			}
		);
	}
});
