import sys,pathlib,json,subprocess,datetime,concurrent.futures
r=pathlib.Path(__file__).resolve().parent
prefix=sys.argv[1];tables=sys.argv[2:] or json.loads((r/"original-table-selection.json").read_text())
def one(task):
 t,o=task;label=f"{prefix}-{t}-{o}";p=subprocess.run(["python3",str(r/"run.py"),label,"h","rows",t,o],capture_output=True,text=True)
 if p.returncode:raise RuntimeError(label+" "+p.stderr+p.stdout)
 a=json.loads((r/(label+".out")).read_text());b=json.loads((r/f"original-{t}-{o}.out").read_text());bm={x["id"]:x for x in b};am={x["id"]:x for x in a}
 return {"table":t,"organization":o,"originalCount":len(b),"actualCount":len(a),"missing":[x for k,x in bm.items() if k not in am],"changed":[{"before":x,"after":am[k]} for k,x in bm.items() if k in am and x!=am[k]],"added":[x for k,x in am.items() if k not in bm],"raw":label+".out"}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(one,[(t,o) for t in tables for o in ["orgA","orgB"]]))
(r/(prefix+"-comparison.json")).write_text(json.dumps({"timestamp":datetime.datetime.now(datetime.timezone.utc).isoformat(),"ordering":"Independent public provider reads overlap, at most three; each dispatch/completion journaled. Native driving and mutations remain sequential.","tables":results},indent=2)+"\n")
print(json.dumps([{k:x[k] for k in ["table","organization","originalCount","actualCount"]}|{"missing":len(x["missing"]),"changed":len(x["changed"]),"added":len(x["added"])} for x in results]))
