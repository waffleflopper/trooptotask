import pathlib,json,sys,re,datetime
r=pathlib.Path(__file__).resolve().parent
for label in sys.argv[1:]:
 raw=json.loads((r/(label+'.out')).read_text());txt='\n'.join(x.get('text','') for x in raw['content']);projection=json.loads(re.search(r'```json\n(.*?)\n```',txt,re.S).group(1));lines=[json.loads(line) for line in projection['body'].splitlines() if line];chunks={}
 def decode(flat):
  cache={}
  def resolve(index):
   if index<0:return {'negativeReference':index}
   if index in cache:return cache[index]
   node=flat[index]
   if isinstance(node,list):
    if node and node[0]=='Promise':return {'promiseId':resolve(node[1])}
    value=[];cache[index]=value;value.extend(resolve(x) for x in node);return value
   if isinstance(node,dict):
    value={};cache[index]=value;value.update({k:resolve(v) for k,v in node.items()});return value
   return node
  return resolve(0)
 for line in lines:
  if line['type']=='chunk':chunks[line['id']]= {'data':decode(line['data'])} if 'data' in line else {'error':decode(line['error'])}
 nodes=[]
 for node in lines[0]['nodes']:
  nodes.append(decode(node['data']) if node.get('type')=='data' else node)
 result={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input':label+'.out','transportStatus':projection['status'],'nodes':nodes,'chunks':chunks};(r/(label+'-decoded.json')).write_text(json.dumps(result,indent=2));print(label,projection['status'],len(nodes),len(chunks))
