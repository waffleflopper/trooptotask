import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
def loaded(n):return json.loads(json.loads((d.E/(n+'.json')).read_text())['stdout'])
def names(n,role):return [x.get('name') for x in d.walk(loaded(n)['structuredContent']['snapshot']) if x.get('role')==role]
a=names('group4-roster-a-settled','row');b=names('group4-roster-b-settled','row')
assert 'Open SPC MapLifecycle0c60fb11, Synthetic' in a
assert b==['Collapse Foreign','Open SPC Foreign, Synthetic']
bcatalog=names('group4-bowner-ranks-loaded','row');assert bcatalog==['Show details for SGT','Show details for SPC','Show details for PFC','Show details for VFY-ONLY-B']
p=d.result_value(loaded('group4-person-rank-dom'));assert [x['text'] for x in p]==['SGT','SPC','PFC','VFY-ACTIVE-A']
t=names('group4-training-targeting-loaded','checkbox');assert all(v in t for v in ['SGT','SPC','PFC','VFY-ACTIVE-A']);assert not any(v in t for v in ['VFY-RETIRED-A','VFY-ONLY-B'])
ict=d.result_value(loaded('group4-ict-rank-options'));assert ict==['All Ranks','SPC']
(d.E/'group4-assertions.json').write_text(json.dumps(dict(status='PASS',personnelActiveA=p,trainingChecks=t,ictPopulationFilter=ict,rosterA=a,rosterB=b,separateOwnerBCatalog=bcatalog,detailSwitch='403 concealment; not roster reset credit',nativeBViewerAddPerson='UNAVAILABLE',limitations=['B catalog comes from separate B owner context, not switch-cache catalog hydration','ICT Reports filters observed populated Personnel rank SPC; no absent custom catalog option credit']),indent=2))
rows=json.loads((d.E/'parent-restored-full.json').read_text())['rows']['orgA']
ids={'counseling-records':'1cc6594a-3be8-4f59-8214-65d8aa735200','documents':'e8d0d24e-32c1-463a-a740-a51fe69b7ef6','follow-ups':'d2665769-c09b-47d8-b5b1-31ac22df3c0a','leader-notes':'f03e159f-fc1d-4863-a8b4-383e8d2cecd8'}
files=[rows['counseling_records'],rows['personnel_documents']];paths=[next(r['file_path'] for r in rr if r['id']==ii) for rr,ii in zip(files,[ids['counseling-records'],ids['documents']])]
(d.E/'generated-cleanup-ledger.json').write_text(json.dumps(dict(person='4c98aad9-c812-40b0-935a-1646f2a468fb',nativeCreated=ids,paths=paths,sds=[r['id'] for r in rows['personnel_extended_info'] if r['personnel_id']=='4c98aad9-c812-40b0-935a-1646f2a468fb']),indent=2))
for family,rid in ids.items():
 body=d.E/('cleanup-'+family+'-body.json');body.write_text(json.dumps({'status':'archived'} if family=='follow-ups' else {'action':'archive'}))
 result=d.call('cleanup-'+family+'-archive',['artifact-http','orgOwner','orgA','4c98aad9-c812-40b0-935a-1646f2a468fb','PATCH',family+'/'+rid,str(body)],True)
 print(json.dumps(result),flush=True)
 result=d.call('cleanup-'+family+'-delete',['artifact-http','orgOwner','orgA','4c98aad9-c812-40b0-935a-1646f2a468fb','DELETE',family+'/'+rid],True)
 print(json.dumps(result),flush=True)
d.call('cleanup-stored-files',['artifact-files','orgA','4c98aad9-c812-40b0-935a-1646f2a468fb','counseling',paths[0],'document',paths[1]],True)
d.call('cleanup-seeds',['clean-seeds'],True)
