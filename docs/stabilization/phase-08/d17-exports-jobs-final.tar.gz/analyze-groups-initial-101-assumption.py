import json,pathlib
p=pathlib.Path(__file__).parent
load=lambda n:json.loads((p/(n+'.stdout')).read_text())
rowset=lambda n:{r['id']:r for r in load(n)['rows']}
created=load('groups-created')['rows'];renamed=load('groups-renamed')['rows'];assert len(created)==len(renamed)==1
assert created[0]['id']==renamed[0]['id'];assert created[0]['created_at']==renamed[0]['created_at']
assert renamed[0]['name']==created[0]['name']+' renamed'
assert load('groups-old-name')['count']==load('groups-removed')['count']==0
for org in ['orgA','orgB']:
 assert rowset('before-groups-'+org)==rowset('groups-final-groups-'+org)==rowset('groups-denials-groups-'+org)
assert rowset('groups-length-no-effect')==rowset('before-groups-orgA')
assert len(load('groups-duplicate-rows')['rows'])==3
s=lambda n:load(n)['content'][0]['text']
assert 'Add" disableable disabled' in s('groups-open')
assert 'Too big: expected string to have <=100 characters' in s('groups-length-after')
assert 'D17 Groups Final 0c3486' in s('groups-reopened')
assert 'D17 Groups Final 0c3486 renamed' in s('groups-renamed-reopen')
assert 'D17 Groups Final' not in s('groups-removal-reopen')
assert 'A Group with that name already exists.' in s('groups-duplicate-after')
assert 'Manage Groups' not in s('groups-viewer-snapshot')
raw=s('groups-viewer-denials');proof=json.loads(raw.split('```json\n')[1].split('\n```')[0]);assert [r['status'] for r in proof]==[403,404]
args=json.loads((p/'groups-length-draft.command.json').read_text())['argv'];payload=json.loads(args[args.index('fill')+1]);assert len(payload['value'])==101
out={'passed':True,'scope':'Ancillary next-deliverable Groups baseline, unchanged source','sameSavedId':created[0]['id'],'nativeCreateRenameRemoveReload':True,'emptyDisabled':True,'native101ValidationAndExplicitValidRetry':True,'duplicateNoEffects':True,'viewerOrdinaryPostStatuses':[403,404],'allOriginalGroupsExactlyUnchanged':True}
(p/'groups-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
