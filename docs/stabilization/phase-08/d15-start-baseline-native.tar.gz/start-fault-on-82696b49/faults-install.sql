SET statement_timeout='10s'; SET lock_timeout='3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_save() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $save$
BEGIN
 IF NEW.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND EXISTS(SELECT 1 FROM public.personnel_onboardings p
 WHERE p.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND p.personnel_id='8bc3e104-0802-40e5-8070-143bc851d602'::uuid AND p.id=NEW.onboarding_id) THEN
  RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned Start progress-save fault';
 END IF;
 RETURN NEW;
END;$save$;
CREATE FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_delete() RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $delete$
BEGIN RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned Start compensation-delete fault'; END;$delete$;
CREATE TRIGGER t2t_d15_start_a1abe29f_3d8748a1_save BEFORE INSERT ON public.onboarding_step_progress FOR EACH ROW EXECUTE FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_save();
CREATE TRIGGER t2t_d15_start_a1abe29f_3d8748a1_delete BEFORE DELETE ON public.personnel_onboardings FOR EACH ROW
 WHEN (OLD.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND OLD.personnel_id='8bc3e104-0802-40e5-8070-143bc851d602'::uuid) EXECUTE FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_delete();
COMMENT ON FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_save() IS '{"container_id": "d143b03ccba077994aacef1ce3c2d2af2483ca4c092c0ee163d59a7e2582f217", "organization_id": "b8f2540a-5573-41a5-8c7d-99477869a1cd", "personnel_id": "8bc3e104-0802-40e5-8070-143bc851d602", "project": "t2t-verify-65895d35ef1d467f83bfa26e", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "6509ba40d4d6312c864ebdfc94fbaf49864969e7deb2925be972b16a6f472af1", "session_id": "3d8748a1-120f-4e43-827b-a3586cd422db", "template_id": "b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5", "worker": "1"}';
COMMENT ON FUNCTION public.t2t_d15_start_a1abe29f_3d8748a1_delete() IS '{"container_id": "d143b03ccba077994aacef1ce3c2d2af2483ca4c092c0ee163d59a7e2582f217", "organization_id": "b8f2540a-5573-41a5-8c7d-99477869a1cd", "personnel_id": "8bc3e104-0802-40e5-8070-143bc851d602", "project": "t2t-verify-65895d35ef1d467f83bfa26e", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "6509ba40d4d6312c864ebdfc94fbaf49864969e7deb2925be972b16a6f472af1", "session_id": "3d8748a1-120f-4e43-827b-a3586cd422db", "template_id": "b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5", "worker": "1"}';
COMMENT ON TRIGGER t2t_d15_start_a1abe29f_3d8748a1_save ON public.onboarding_step_progress IS '{"container_id": "d143b03ccba077994aacef1ce3c2d2af2483ca4c092c0ee163d59a7e2582f217", "organization_id": "b8f2540a-5573-41a5-8c7d-99477869a1cd", "personnel_id": "8bc3e104-0802-40e5-8070-143bc851d602", "project": "t2t-verify-65895d35ef1d467f83bfa26e", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "6509ba40d4d6312c864ebdfc94fbaf49864969e7deb2925be972b16a6f472af1", "session_id": "3d8748a1-120f-4e43-827b-a3586cd422db", "template_id": "b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5", "worker": "1"}';
COMMENT ON TRIGGER t2t_d15_start_a1abe29f_3d8748a1_delete ON public.personnel_onboardings IS '{"container_id": "d143b03ccba077994aacef1ce3c2d2af2483ca4c092c0ee163d59a7e2582f217", "organization_id": "b8f2540a-5573-41a5-8c7d-99477869a1cd", "personnel_id": "8bc3e104-0802-40e5-8070-143bc851d602", "project": "t2t-verify-65895d35ef1d467f83bfa26e", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "6509ba40d4d6312c864ebdfc94fbaf49864969e7deb2925be972b16a6f472af1", "session_id": "3d8748a1-120f-4e43-827b-a3586cd422db", "template_id": "b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5", "worker": "1"}';
COMMIT;
SELECT json_build_object('installed',true,'sqlstate','P0001');
