SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('4ab4a79e-64be-4e8c-9556-3eecdaa45313'::uuid,'57fa3d0d-a43f-45b3-86f8-c5a87866503b'::uuid,'0460b50a-661f-43af-aa85-f654b903184a'::uuid,'2551836e-3e0f-4620-9fe7-7b0407721862'::uuid,'8b90ab68-cf2a-452e-b434-44a8ebbdd5e3'::uuid,'daa6c301-b11c-4e59-b5ed-ccc7872874b8'::uuid,'51bb3be5-3f5d-49b3-aefe-6f767ead0414'::uuid,'e9019011-f951-4377-a0a6-0225558f5258'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('a383510d-3e78-46f7-ba4f-9baded6da8c4'::uuid,'589024a0-d712-47f4-bdfb-5d4d6b5c9d08'::uuid,'6d48142c-df42-40bb-a663-db6fa5a56132'::uuid,'a967fef7-e9a4-420d-9097-e979fa7b6d7f'::uuid,'00b4b6ef-15d8-4ce8-bf0d-a1297f113f43'::uuid,'5d5288dd-e8f2-46d4-9045-d75aba1c7901'::uuid,'b2f6e4ea-6379-43f0-a0d2-66c304a35d93'::uuid,'082c5a51-cff7-47e5-bb8d-d9b3bb4d5067'::uuid)) s), '[]'::json));
