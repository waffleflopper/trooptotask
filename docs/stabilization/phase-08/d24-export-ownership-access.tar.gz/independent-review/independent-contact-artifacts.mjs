import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const require=createRequire('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/package.json');
const ExcelJS=require('exceljs');
const root=process.argv[2]??'/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/.verification/evidence/verify-trooptotask/d24-export-ownership-access';
const read=name=>JSON.parse(fs.readFileSync(`${root}/${name}`,'utf8'));
const before=read('extended-before-orgA.json');
const saved=read('extended-saved-orgA.json');
assert.equal(before.count,0);
assert.equal(saved.count,1);
assert.deepEqual(saved,read('extended-reloaded-orgA.json'));
assert.equal(read('extended-before-orgB.json').count,0);
const expected=saved.rows[0];
const json=read('owner-contact.json');
assert.equal(json.organizationId,expected.organization_id);
assert.equal(Object.keys(json.sections).length,38);
assert.equal(json.sectionInventory.length,38);
assert.deepEqual(json.personnelExtendedInfo,[expected]);
assert.deepEqual(json.sections.personnelExtendedInfo,[expected]);
const wb=new ExcelJS.Workbook();
await wb.xlsx.readFile(`${root}/owner-contact.xlsx`);
assert.equal(wb.worksheets.length,57);
const sheet=wb.getWorksheet('Raw - Personnel Extended Info');
assert.equal(sheet.rowCount,2);
const headers=sheet.getRow(1).values.slice(1).map(value=>value.toLowerCase().replaceAll(' ','_'));
const raw=Object.fromEntries(headers.map((key,index)=>[key,sheet.getRow(2).getCell(index+1).value]));
assert.deepEqual(new Set(headers),new Set(Object.keys(expected)));
for(const[key,value]of Object.entries(expected)){
 const actual=value!==null&&typeof value==='object'?JSON.parse(raw[key]):raw[key]??null;
 assert.deepEqual(actual,value,`raw.${key}`);
}
const readable=wb.getWorksheet('Personnel');
const readableHeaders=readable.getRow(1).values.slice(1);
const person=json.personnel.find(row=>row.id===expected.personnel_id);
assert(person);
const personRow=Array.from({length:readable.rowCount-1},(_,i)=>readable.getRow(i+2)).find(row=>row.getCell(readableHeaders.indexOf('Last Name')+1).value===person.last_name&&row.getCell(readableHeaders.indexOf('First Name')+1).value===person.first_name);
assert(personRow);
const projections={
 'Emergency Contact':expected.emergency_contact_name,
 'Emergency Phone':expected.emergency_contact_phone,
 Phone:expected.personal_phone,
 Email:expected.personal_email,
 Address:[expected.address_street,expected.address_city,expected.address_state,expected.address_zip].filter(Boolean).join(', '),
};
for(const[header,value]of Object.entries(projections))assert.equal(personRow.getCell(readableHeaders.indexOf(header)+1).value,value,header);
assert.equal(readable.rowCount-1,json.personnel.length);
for(let i=2;i<=readable.rowCount;i++)assert.equal(readable.getRow(i).getCell(readableHeaders.indexOf('Leader Notes')+1).value??'','');
const lifecycle=read('lifecycle-contact-reloaded.json');
assert.equal(lifecycle.count,2);
const owner=read('before-denials-orgA-audit_logs.json').rows.find(row=>row.action==='personnel.extended_info.updated'&&row.resource_id===expected.personnel_id).user_id;
const artifacts=[];
for(const[family,filename,mime]of[['json','owner-contact.json','application/json'],['xlsx','owner-contact.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']]){
 const bytes=fs.readFileSync(`${root}/${filename}`);
 const capture=read(`contact-${family}-capture-state.json`);
 const save=read(`contact-${family}-save.json`);
 const network=read(`contact-${family}-network-state.json`);
 assert.equal(capture.captured,true);
 assert.equal(capture.bytes,bytes.length);
 assert.equal(save.bytes,bytes.length);
 assert.equal(save.sha256,createHash('sha256').update(bytes).digest('hex'));
 assert.equal(capture.filename,save.filename);
 assert.equal(save.mimeType,mime);
 assert.equal(network.calls.length,1);
 assert.equal(network.calls[0].method,'POST');
 assert.equal(network.calls[0].status,200);
 assert.equal(network.calls[0].contentType,mime);
 assert(network.calls[0].contentDisposition.includes(save.filename));
 const row=lifecycle.rows.find(row=>row.file_size_bytes===bytes.length);
 assert(row);
 assert.equal(row.status,'completed');
 assert.equal(row.org_id,expected.organization_id);
 assert.equal(row.requested_by,owner);
 assert(row.completed_at);
 assert(Date.parse(row.completed_at)>=Date.parse(row.created_at));
 artifacts.push({filename,bytes:bytes.length,exportId:row.id,requester:row.requested_by});
}
for(const org of ['orgA','orgB']){
 const after=read(`extended-after-cleanup-${org}.json`);assert.equal(after.count,0);assert.deepEqual(after.rows,[]);
}
assert.deepEqual(read('start-doctor.json'),read('final-doctor.json'));assert.deepEqual(read('final-doctor.json'),read('post-seed-cleanup-doctor.json'));
assert.equal(read('seed-cleanup.json').cleaned,true);assert.equal(read('disposal.json').status,'PASS');
console.log(JSON.stringify({sourceRows:saved.count,rawSavedFieldsCompared:Object.keys(expected).length*2,readableContactFields:Object.keys(projections).length,blankLegacyNoteCells:json.personnel.length,cleanupExtendedRows:{orgA:0,orgB:0},doctorAndDisposal:'PASS',completedArtifacts:artifacts}));
