# 1503-baseline — Training Reports UNCHANGED baseline (#1503)
- Revision f3ac08fd73c88f8534b18fde29ba245ccba5ba07; candidate 308224f5d3aed82dcdc4a9a9ad8e3002a8324a62c081bd6cb7bb15b0636d81ec; session 960d7f71-980d-4b9c-aef1-003389d6f707; worker 1; origin http://127.0.0.1:42359
- Driver: T3 preview browser (child tab_4), UA "T3Code(Nightly)/0.0.46-nightly.20261003.2632 Chrome/152.0.7977.130 Electron/44.4.2". Worker's own Chromium 152.0.7977.82 (doctor) NOT used.
- Tools: node v24.21.0; helper control.mjs (fixture, rows, workbook, doctor). Network/export hooks = preview_evaluate re-implementations of helpers/network-control.mjs installNetworkControl and control.mjs export arm/restore (GET-only; body parsing omitted; `search` added to call records).
- Roles: trainingConfigure, trainingView, rosterScoped, trainingEmpty, viewer (no Training lane), trainingForeign (orgB). Credentials read privately from worker fixtures; none stored.
- Fixture dates: ui 2026-10-03; trainingCompleted 2026-09-26; trainingExpires 2027-09-26.
- No fixture/app writes. personnel_trainings orgA (1 row, 7e07ffe5, 2026-09-26/2027-09-26) and orgB (0) unchanged start→end.

| # | Outcome | Expected | Actual | Verdict | Evidence |
|---|---|---|---|---|---|
| 1 | Configure initial report | 25%, 1 Current/3 Not Done, 3 A people, Required 33 / Targeted 0, no Optional/foreign denominator, SSR + reload | Exact; SSR HTML 200 contains 25%/counts/names; reload identical. SSR HTML says "3 of 0 personnel" before hydration | PASS (minor SSR count note) | 01–03, rows-*.json |
| 2 | Filters | Alpha 50/Able; Bravo 0/Baker; 68W 33% (1/3); Medic 50/Able; SPC all 3 | Exact | PASS; URL/reload don't keep filters = planned change | 04–08, 04-08-filters.txt |
| 3 | Summary 503 | visible error, retry behavior recorded, hook restored | "Report page failed" alert, no Retry button, Alpha label over stale unfiltered 25%/3 data; reselect no-op; Clear→Alpha recovers | ISSUES (baseline stale-state/no in-place retry); hook restored | 09–11 |
| 4 | Export | full 3 A rows, 2027-09-26, no Foreign; Alpha/Required 1 Able row | Exact; 200 + filename training-report-2026-10-03.xlsx; hashes match Blob | PASS | training-report-*.xlsx, *.workbook.json, 12 |
| 5 | Access | view readable; rosterScoped Alpha/Able; empty no people; viewer denied page + 3 APIs; foreign B no A | All as expected; viewer APIs 403, page renders 403 with HTTP 200 doc; foreign A APIs 404 | PASS | 15–24 |
| 6 | Reports→matrix→Reports | works | works | PASS | 13–14 |
