# Capability redaction index

Root should redact only these tool-input values during supported raw recovery.

1. The first `preview_evaluate` on tab_5 after `stage` (about 23:17 AKDT). Its `expression` is the `location.replace(...)` call holding the one-use `/__t2t_1503_fill/<capability>` URL. The route was consumed and `private-navigate.json` is gone.
2. The next `preview_evaluate` on tab_5. Its `expression` is the `private-fill.json` body. That body holds no credential (it reads `window.name`), but its output confirms the credentials were filled. Redact it if policy treats the fill expression as capability-bearing.

The password, cookies and relay body were never printed, snapshotted or saved. No snapshot succeeded at any point.
