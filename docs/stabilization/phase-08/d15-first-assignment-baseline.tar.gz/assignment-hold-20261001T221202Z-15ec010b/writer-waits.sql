SET statement_timeout = '10s'; SET lock_timeout = '3s';
WITH RECURSIVE chain(root_pid, node_pid, path) AS (
 SELECT a.pid, a.pid, ARRAY[a.pid] FROM pg_stat_activity a
 WHERE a.datname = 'postgres' AND a.pid <> 1469 AND a.state = 'active' AND a.wait_event_type = 'Lock'
 AND a.query ~* 'insert[[:space:]]+into[[:space:]]+("?public"?[.])?"?onboarding_step_progress"?([[:space:]]|[(]|$)'
 AND a.query ~* 'on[[:space:]]+conflict'
 UNION ALL SELECT c.root_pid, b.pid, c.path || b.pid FROM chain c
 CROSS JOIN LATERAL unnest(pg_blocking_pids(c.node_pid)) AS b(pid)
 WHERE NOT b.pid = ANY(c.path) AND cardinality(c.path) < 12
), reached AS (SELECT root_pid, json_agg(path) AS paths FROM chain WHERE node_pid = 1469 GROUP BY root_pid)
SELECT json_build_object('holder_matches', EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid = 1469 AND backend_start = '2026-10-01 22:12:03.765317+00'::timestamptz AND application_name = 't2t-d15-hold-352a72c5b46b40e687790edc6b568c8d' AND usename = 'supabase_admin' AND datname = 'postgres'),
 'waiting', COALESCE((SELECT json_agg(json_build_object('pid', a.pid, 'backend_start', a.backend_start::text,
 'query_class', 'progress-upsert', 'state', a.state, 'wait_event_type', a.wait_event_type,
 'wait_event', a.wait_event, 'blocking_paths', r.paths) ORDER BY a.pid)
 FROM pg_stat_activity a JOIN reached r ON r.root_pid = a.pid), '[]'::json));
