# Training caller and removal census

`source-census.json` lists all 66 stage-changed paths and their current hashes. Seven old files are removed. `legacy-symbol-census.txt` records no surviving Entity, old generic Training store, or deleted catalog-read import in source. `port-caller-census.txt` and `purpose-table-census.txt` preserve the raw searches.

| Consumer | Current boundary |
| --- | --- |
| Type and View JSON routes and operations | Catalog create, patch, and delete method Picks |
| Completion JSON routes and operations | Completion resource, pair, create, patch, and delete Picks; existing Personnel write admission |
| Batch import | Catalog timing/import references and serial exemption recheck; Completion pair references and completed upsert |
| Workspace and reports/detail/workbook | Catalog listTypes/listViews and policy-checked Completion listCompletions; existing rank callback, Personnel, Group, pin, and Organization branches |
| Dashboard query and summary | Catalog listTypes and Completion listCompletions |
| Personnel detail readiness | Personnel/Group admission first, then Catalog types and Completion readiness facts |
| Personnel export delivery | Catalog labels and four Completion export facts mapped into Personnel's existing workbook keys |
| Getting Started | Catalog estimated count with id projection, range 0..0, and NULL count as zero |
| Starter configuration packs | Existing names, hasTypes, findTypeByName, and createType; ordinary captured request client; name-race reread retained |
| Rank settings/applicability | Catalog raw applies/excludes references; no premature NULL normalization |
| Onboarding references | Separately admitted lazy privileged provider with fixed Type fields; 500-row paging, 100-Person chunks, and four parallel batches preserved |
| Approved deletion | Existing separate authority and literal Training tables; Entity table constant dependency removed |
| Type-name audit and platform support count | Independent existing readers retained |
| Organization raw archive | Independent purpose reader retains complete select * for only the three approved Training tables |

Both ordinary factories capture the already admitted request Supabase instance and canonical Organization once. Calls accept domain inputs and return domain projections. No caller supplies Organization, table, select, filter language, universal Record, or generic result through either ordinary port. Generic shared facade and fixture internals remain for unrelated owners. Client store table names and archive manifests are retained product configuration, not ordinary server persistence seams.

Removed files are `trainingTypeEntity.server.ts`, `trainingViewEntity.server.ts`, `personnelTrainingEntity.server.ts`, its obsolete facade test, `trainingCatalogRead.server.ts`, its former test, and the obsolete generic Training export callback test. The catalog test becomes `trainingCatalogMemory.server.test.ts`. `index.server.ts` exports both factories and removes obsolete read helpers. The ordinary export helper is removed while the raw archive reader remains.

The only governance metadata additions register three exact private Training test-support files and the exact Training request-authority test under delivery ownership. No dependency allowance, broad scanner exemption, baseline waiver, or new Personnel-to-Training ownership cycle was added.
