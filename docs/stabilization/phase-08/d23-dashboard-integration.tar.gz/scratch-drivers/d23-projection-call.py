import json, subprocess, sys, os
from pathlib import Path
root=Path.cwd()
out=root/'.verification/evidence/verify-trooptotask'/os.environ.get('D23_RUN','d23-projections-before')
kind,name,argument,filename=sys.argv[1:]
if kind=='native':
 command=['mise','exec','node@24','--','npm','run','--silent','verify:app','--','tool',name,argument,'--worker','2']
else:
 command=['mise','exec','node@24','--','node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','2',name,*json.loads(argument)]
with (out/'actions.jsonl').open('a') as f:
 f.write(json.dumps({'kind':kind,'name':name,'arguments':json.loads(argument),'output':filename})+'\n')
result=subprocess.run(command,capture_output=True,text=True)
(out/filename).write_text(result.stdout)
if result.stderr:
 (out/(filename+'.stderr')).write_text(result.stderr)
try:
 value=json.loads(result.stdout)
 if kind=='native' and 'content' in value:
  for part in value['content']:
   if part.get('type')=='text':
    lines=part['text'].splitlines()
    cutoff=next((i for i,line in enumerate(lines) if 'dialog \"What' in line),None)
    if cutoff is not None: lines=lines[:cutoff+1]+lines[-3:]
    print('\n'.join(lines))
 elif kind=='helper' and name in ['seed','rows','fixture']:
  print(json.dumps({'saved':filename,'table':value.get('table'),'count':value.get('count'),'tag':value.get('tag')}))
 else: print(result.stdout)
except (ValueError,TypeError): print(result.stdout)
print(result.stderr,file=sys.stderr,end='')
sys.exit(result.returncode)
