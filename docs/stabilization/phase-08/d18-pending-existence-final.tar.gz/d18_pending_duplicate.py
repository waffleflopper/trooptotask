"""Fixed owned duplicate witness; never applies remote/schema/history changes."""
import json,sys,uuid,hashlib
from pathlib import Path
sys.path.insert(0,'.verification')
from d18_actual_review_wait import OwnedProof,require
from scripts.verification.environment import canonical_uuid
import d18_ui as v,d18_final as f,d18_native as n

proof=OwnedProof()
response=f.read('05-first-ordinary-submit')
require(response['status']==201,'Use the recorded ordinary 201 submission')
original=proof.admit_request(json.loads(response['body'])['id'])
require(original['resource_type']=='personnel','Use only the recorded temporary Personnel target')
require(original['requested_by']==canonical_uuid(proof.fixture['actors']['deletionRequester']['id']),'Use the ordinary requester witness')
clone=canonical_uuid(str(uuid.uuid4()))
receipt={'session':proof.worker['id'],'candidate':proof.worker['candidate'],'originalRequest':original['id'],'duplicateRequest':clone,'organization':original['organization_id'],'target':original['resource_id'],'ordinaryActor':original['requested_by'],'cleanup':'existing deletion-sources exact target cleanup'}
# Register before insertion. Target-bound existing seed cleanup covers interrupted writes.
(v.root/'06-duplicate-setup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
org=canonical_uuid(original['organization_id']);target=canonical_uuid(original['resource_id']);actor=canonical_uuid(original['requested_by']);rid=canonical_uuid(original['id'])
columns='organization_id,requested_by,requested_by_email,resource_type,resource_id,resource_description,resource_url,status,reviewed_by,reviewed_at,denial_reason,created_at'
proof.db._execute(f"""BEGIN;
INSERT INTO public.deletion_requests (id,{columns})
SELECT '{clone}'::uuid,{columns} FROM public.deletion_requests r
WHERE r.id='{rid}'::uuid AND r.organization_id='{org}'::uuid
AND r.requested_by='{actor}'::uuid AND r.resource_type='personnel'
AND r.resource_id='{target}'::uuid AND r.status='pending'
AND EXISTS (SELECT 1 FROM public.personnel p WHERE p.id=r.resource_id AND p.organization_id=r.organization_id AND p.archived_at IS NULL);
COMMIT;""")
rows=v.helper('07-two-own-pending-rows','rows','deletion_requests','orgA','resource_id',target)['rows']
require(len(rows)==2 and {r['id'] for r in rows}=={rid,clone},'Require exactly the two recorded own pending rows')
require(all(r['requested_by']==actor and r['status']=='pending' for r in rows),'Require own pending history')
before=json.loads(json.dumps(rows))
def creation_effects():
 return json.loads(proof.db._execute(f"SELECT json_build_object('auditIds',(SELECT coalesce(json_agg(id ORDER BY id),'[]'::json) FROM public.audit_logs WHERE org_id='{org}'::uuid AND action='deletion_request.created' AND details->>'subject_id'='{target}'),'notificationIds',(SELECT coalesce(json_agg(id ORDER BY id),'[]'::json) FROM public.notifications WHERE organization_id='{org}'::uuid AND type='deletion_request_pending'))"))
effects_before=creation_effects()
require(bool(effects_before['auditIds']) and bool(effects_before['notificationIds']),'Initial ordinary submission effects must have settled')
(v.root/'08-creation-effects-before.json').write_text(json.dumps(effects_before,indent=2)+'\n')
f.capture('08-before-duplicate-attempt')
f.file_capture('09-pdf-before-attempt','03-source-seed')
# Ordinary real app/Supabase requests; no service role is used here.
r=f.api('10-repeat-ordinary-submit',2,'submit',{'resourceType':'personnel','resourceId':target,'resourceDescription':'Repeat saved Person','resourceUrl':None})
require(r['status']==409,'Multiple visible pending rows must produce HTTP409')
v.helper('10-native-duplicate-observe','network','arm-observe','2','deletion-requests')
v.helper('10-native-duplicate-feedback','feedback','arm','2')
label=f.read('03-source-seed')['sources']['orgA']['label']
n.click('10-native-duplicate-open',2,'button "Archive SGT '+label+' personnel, Synthetic"')
n.click('10-native-duplicate-confirm',2,'button "Archive"',after='alertdialog')
trace=v.helper('10-native-duplicate-trace','network','state','2');require([call['status'] for call in trace['calls']]==[409],'Native duplicate submission must return real409')
v.helper('10-native-duplicate-feedback-result','feedback','state','2')
v.snap('10-native-duplicate-result',2);n.screenshot('10-native-duplicate-result',2)
v.helper('10-native-duplicate-network-restore','network','restore','2');v.helper('10-native-duplicate-feedback-restore','feedback','restore','2')
r=v.helper('11-repeat-ordinary-bulk' ,'personnel-archive-batch','2','orgA',json.dumps([target]));require(r['status']==200,'Bulk response must succeed')
body=json.loads(r['body']);require(body=={'archivedIds':[],'approvalRequestedIds':[target],'errors':[]},'Bulk must acknowledge already-pending target')
f.capture('12-after-duplicate-attempt');f.file_capture('13-pdf-after-attempt','03-source-seed')
for organization in ['orgA','orgB']:
 for table in f.TABLES:
  require(f.read('08-before-duplicate-attempt-'+organization+'-'+table)['rows']==f.read('12-after-duplicate-attempt-'+organization+'-'+table)['rows'],'Duplicate attempts changed a stored source/history projection')
 require(f.read('09-pdf-before-attempt-'+organization+'-files')==f.read('13-pdf-after-attempt-'+organization+'-files'),'Duplicate attempts changed actual PDF witnesses')
after=v.helper('14-two-own-pending-rows-unchanged','rows','deletion_requests','orgA','resource_id',target)['rows'];require(sorted(after,key=lambda x:x['id'])==sorted(before,key=lambda x:x['id']),'Saved duplicate history changed')
effects_after=creation_effects()
(v.root/'14-creation-effects-after.json').write_text(json.dumps(effects_after,indent=2)+'\n')
require(effects_after==effects_before,'Duplicate attempt emitted creation audit or notification')
# Current peer privacy is retained: another requester cannot see this pending history.
v.helper('15-peer-normal-login','actor','deletionPeer','personnel')
r=f.api('16-peer-hidden-pending-submit',3,'submit',{'resourceType':'personnel','resourceId':target,'resourceDescription':'Peer saved Person','resourceUrl':None});require(r['status']==201,'Concealed peer row must not become a new global uniqueness rule')
peer_id=canonical_uuid(json.loads(r['body'])['id'])
r=f.api('17-peer-visible-repeat',3,'submit',{'resourceType':'personnel','resourceId':target,'resourceDescription':'Peer saved Person','resourceUrl':None});require(r['status']==409,'Peer own pending repeat must still reject')
r=f.api('18-requester-visible-list',2,'list',{});require(r['status']==200 and {row['id'] for row in json.loads(r['body'])}=={rid,clone},'Requester must see only its two recorded rows')
r=f.api('18-peer-visible-list',3,'list',{});require(r['status']==200 and {row['id'] for row in json.loads(r['body'])}=={peer_id},'Peer must see only its recorded request')
(v.root/'19-observations.json').write_text(json.dumps({'status':'PASS','ownDuplicateSubmitStatus':409,'nativeDuplicateSubmitStatus':409,'ownDuplicateBulkStatus':200,'ownDuplicateBulkBody':body,'original20ProjectionSetsUnchanged':True,'bothActualPdfWitnessesUnchanged':True,'fullSavedTwoRequestRowsUnchanged':True,'creationAuditNotificationIdsUnchanged':True,'peerHiddenPendingSubmitStatus':201,'peerOwnRepeatStatus':409,'concurrentInsertAtomicityClaimed':False},indent=2)+'\n')
print('PASS fixed owned duplicate witness and ordinary visibility-scoped submission/bulk',flush=True)
