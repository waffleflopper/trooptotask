# D28 Rating feedback repair — closed native proof

The three selected late-response gates passed on the repaired frozen source. The owned worker has actually completed doctor and cleanup. This report concerns those gates and their affected active mutation/retry paths; it does not replace independent expanded acceptance or claim that every D28 area is complete.

## Exact source and closure

| Binding | Actual value |
| --- | --- |
| Checkout | `/home/waffleflops/.cache/t2t-1376-rating-owner` |
| HEAD | `3f3517facbc3fc7cba5df7fde686935f5d3fccf2` |
| Whole tree | `d966ed1e139725c1d14c10f11adca5ed62841f4b` |
| Candidate | `780dc629e1647f3de2766953e7db235e975d65960eeac7d036923c9c247f8870` |
| Inputs | All 5,092 executable/driving inputs individually byte hashed; no added, missing or changed inputs |
| Node | `v24.21.0`, explicit mise PATH and task TMP; commands used `login:false` |
| Worker/session | Worker 1 / `3aadde02-9824-4aca-8dc3-236365e12539` |
| Owned origin | `http://127.0.0.1:42185` |
| Browser | `/usr/bin/chromium`, Chromium `152.0.7977.82 Arch Linux` |
| Final closed record | `2026-10-06T07:26:23.651Z` |

The normal source merge preceded launch. Child and granted root whole trees were literally equal. `source-state-before.json` records the four root runtime SHA comparisons, all exact. The entire session remained frozen on this source. Root's later Calendar #1549 merge was not adopted here.

`launch.json`, `doctor-before.json`, and `doctor-final.json` are PASS with the same candidate/session. Launch and both doctor commands actually terminated with exit 0. `owned-cleanup.json` is PASS with `phase: cleaned`; that command actually terminated with exit 0 before `source-state-final-closed.json` was written. The private worker directory was absent afterward. `input-comparison-final-closed.json` recomputes all 5,092 original inputs and the candidate; HEAD/tree remain exact and the checkout is clean. Heavy build ownership was released immediately after launch and doctor. No additional build, restart, source edit or session was used.

All paths in the following scenario tables are relative to the unchanged raw directory:

`/home/waffleflops/.cache/t2t-1376-rating-owner/.verification/evidence/verify-trooptotask/d28-rating-feedback-repair`

## Roles, fixtures and actual native journeys

Native page 2 used `ratingSwitch`: A operate, B view only. A is `ca319b3f-a411-43dc-a2fc-79605fbdbb23`; B is `269887ea-2862-47b8-b8cf-1dfd779bc52b`. Page 3 used the ordinary synthetic `orgOwner` for visible cleanup. Browser contexts were isolated by the documented actor helper. Every departure used the native `navigate_page` `type: back` after normal visible B→A Evals navigation established history. Actual page URLs and snapshots establish B admission; no script navigation, storage simulation or stale A page was credited.

Rating seed `8c4937ae` supplied untouched original A9 and B1, preserved in `original-A9.json` and `original-B1.json`. Each provider row has all 20 original columns, including null identities and both timestamps. The UI-created witness `ab87a596-2899-4286-b8a0-43f475970f9b` was an OER/CR for `40ad9254-9b81-4181-b222-096f95631be7`, October 5–31, external MAJ Native Rater and COL Native Senior. It was created through the visible editor with real POST 200; native success, full20 provider readback and reload/reopen confirmed persistence. Its `created_at` remained `2026-10-06T07:02:26.915818+00:00` through both updates.

Only after the original B1 PUT gate was complete, the documented `deletion-sources` seed `2992f31e` created journaled A/B targets and their registered counseling files. A's Rating target was `0617f129-9423-4ad3-89d4-349cda31b238`; B's was `f71610eb-a87e-40e5-a252-463fece45635`. `deletion-original-A11.json` and `deletion-original-B2.json` retain their full originals. Later B snapshots truthfully show two rows: original Foreign plus the journaled B target. They are not presented as the original one-row B proof.

### Held successful PUT: PASS

The active save first received a scoped synthetic 503. Native feedback said `Failed to update rating entry`; the editor stayed open with `D28 current retry draft`, enabled retry controls and exact unchanged full20 provider data. After explicit restoration, one visible retry produced real PUT 200 and persisted that draft. See `active-save-*`, especially the failure PNG/native snapshot, failure provider row and retry wire/provider receipts.

The next visible edit submitted `D28 held repaired A delivery`. Real PUT request 246 returned 200 and the provider committed in A before browser delivery was held. `PUT-held.network-request`, `PUT-held.network-response`, `PUT-held-wire-business.json` and `PUT-committed-A-provider.json` bind the actual intent, all20 response/provider equality, stable ID/creation and update timestamp `2026-10-06T07:06:25.837197+00:00`. A busy native snapshot shows Saving with Save/Delete/Cancel unavailable; `PUT-held-A-network.json` records held response state.

Native Back admitted the canonical B Evals route before release, with one exact Foreign row and view-only affordances. `PUT-native-back.json`, `PUT-B-before-release.txt`, and `PUT-held-B-network.json` preserve admission and the still-held delivery. Release was followed by actual PNG first, full native snapshot second, then feedback readback: `PUT-B-immediate.png`, `.txt`, and `PUT-B-immediate-feedback.json`. The image was viewed; no stale toast, editor or acknowledgement was visible. The recorder had no success/error entries. Provider rows were full20 equal before release, after release, and after reload. `PUT-B-comparison.json` records that equality and the actual 200 delivery. Network and feedback were explicitly restored successfully before reload. A's already-committed change was real, not rolled back.

### Retired DELETE 202 before approval continuation: PASS

The journaled A target first received a scoped synthetic DELETE 503. `DELETE-current-*` preserves the useful error, unsaved `D28 current deletion retry draft`, retained editor/confirmation, exact full20 target and zero request rows. After restoration and a fresh observer, one visible retry returned real DELETE request 472 / 202 with literal `{"requiresApproval":true}`; the target remained unchanged and no approval request existed. The response was held. Busy editor/confirmation controls were disabled and native Escape did not dismiss the pending operation (`DELETE-held-confirm.json`, `DELETE-held-Escape.json`).

Native Back admitted actual B2 view-only before release. `DELETE-B-immediate.png` was captured and viewed before the accompanying snapshot/feedback readback. No stale toast, modal or acknowledgement appeared; success/error recorder entries were empty. The native request list contained no subsequent approval POST, and ordinary request readback remained zero after delivery. A target remained full20 exact through reload; B2 remained full20 exact before release, after release and reload. `DELETE-comparison.json` is PASS. Both hooks were explicitly restored successfully before reload.

### Already-dispatched approval POST across departure: PASS

On a fresh visible B→A journey, the target's real DELETE request 589 returned 202. The current approval submission was intercepted with scoped synthetic 503; no request reached the provider. `POST-current-*` preserves `Failed to submit deletion request.`, retained editor/confirmation, unsaved `D28 current approval retry draft`, exact full20 source and zero request rows. After explicit restoration and fresh feedback observation, the visible retry made real DELETE request 590 / 202, followed by actual approval POST request 591 / **201**. The actual route returned 201, not the earlier plan's guessed 200.

`POST-held.network-request` records the initiating A target, description and URL. `POST-held.network-response` and `POST-held-A-pending-request.json` match all13 actual request columns. The pending request was `469a0e03-4b7e-4985-82d3-f53d3f2af0ec`, created `2026-10-06T07:15:07.840688+00:00` by the ordinary ratingSwitch requester. The A Rating source stayed full20 unchanged. Busy UI and native Escape receipts precede actual native Back to canonical B2 while the POST response was still held.

After release, `POST-B-immediate.png` was captured first and viewed, followed by full native snapshot and recorder readback. No stale modal, toast or info acknowledgement was visible. This image/snapshot observation is necessary because the feedback recorder does not capture info acknowledgement calls. The recorder separately had zero success/error entries. `POST-after-release-A-pending-request.json` shows that A's already-persisted request remained pending and full13 exact. B2 rows remained full20 exact through release and reload. `POST-comparison.json` is PASS with actual POST201. Both hooks were explicitly restored successfully before reload. No cancellation or reversal of an already-dispatched A effect is claimed.

## Cleanup and all original rows

The original ordinary requester cancelled the pending request through the documented same-origin HTTP helper, actual DELETE 200 / `{"success":true}`. This is API proof, not a native cancellation UI claim. `request-cancel-ordinary-http.json` and `request-cancelled-provider.json` retain its effects. The full13 request changed only `status` to `cancelled`; terminal history remained present in `cancelled-history-before-seed-cleanup.json` until journal cleanup.

The owner visibly deleted only the new UI witness and journaled A target. Real native DELETE requests 123 and 124 returned 200, with captured request/response bodies. Native settlement, provider absence and reloaded owner Evals (`owner-cleanup-reloaded.txt/.png`) prove successful deletion; earlier failure feedback logs are not used as deletion-success evidence. Before deleting the UI witness, the owner's reopened editor displayed the already-committed A held-edit notes.

`original-and-witness-comparison-before-clean-seeds.json` records exact all20 A9 and original B1 equality, full20 unchanged B sentinel, both temporary Rating targets absent, no UI-witness requests, exact cancelled request history and unchanged registered A/B file size/hash. All network/feedback hooks on both pages were false. Each scenario's explicit restoration succeeded before reload; final disarmed readback is not substituted for those restoration receipts.

All seed-dependent comparisons finished before `clean-seeds`. `clean-seeds.json` actually returned `cleaned: true`, `artifactHttpSessionsCleared: true`, terminal exit 0. Subsequent readback found zero Rating rows in both Organizations, zero target request histories and the exact two registered files absent. Their registered record lists were empty. `seed-cleanup-comparison.json` is PASS. Registered files are provider preservation/cleanup witnesses, not new native counseling-upload acceptance. Final doctor and actual full owned cleanup followed these readbacks.

## Coverage boundaries and preserved imperfect attempts

- The first visible create save lacked a thru date and showed `Missing: thru date.`. Keyboard Report Type selection resulted in CR. The correction used the actual visible DatePicker October 31; no annual-fill behavior is claimed. All original native captures are retained.
- The create request was retrieved after reload. Its actual POST200 status and original request body are retained, but native request inspection reported `<Response body not available anymore>`. No create response-body observation is invented. Creation is instead supported by native success, provider full20 and reload/reopen.
- A date-grid tool result exceeded output capacity; parsing that truncated presentation failed. The original raw tool JSON was already saved and remains unchanged; the reader then projected text-only output. This was a capture-reader limit, not an app failure.
- The first pre-clean comparison attempted to parse hook-read files while their yielded commands were still completing and received unexpected-end JSON. No result file or PASS was produced by that attempt. All commands were then drained to terminal exit 0, and the completed comparison passed with its actual log. The early failed parse exists in tool history rather than a fabricated original raw receipt.
- The first final offline input comparison mistakenly included unrelated Markdown and `.env.example`, outside the original candidate/manifest filter. It failed before creating a final record. Applying the exact existing `core.candidate` filter produced all5,092 exact input hashes. This was an offline checker scope correction; no input changed. The failed tool presentation is retained in tool history, not falsely represented as a full raw log.
- Native 503 controls intercept one scoped request before dispatch. They establish current useful failure, retained drafts, pending state and explicit retry. They do not establish provider5xx atomicity, network rejection, or held stale-failure behavior. No unsupported Rating/approval hold-fail control was improvised.
- The new run proves active native creation, save failure/retry, deletion/approval failure/retry, direct owner DELETE200, and the three selected retired-success gates. Held create success/failure, direct-delete failure, same-Organization departure/unmount/refresh and A→B→fresh-A lifecycle matrices remain separately owned actual interaction-test evidence from the repair, not claimed as newly native-verified here.
- Dashboard What's New/navigation evidence remains the earlier closed current-parent checkpoint; no repetition or new Dashboard/Calendar acceptance is claimed. Original workbook/export, Dashboard/Personnel reverse-consumer and retained SQL proof remain the historical complete run's separately labeled evidence. This new run has no workbook. No speculative export repair or Calendar Bulk Remove acceptance is included.

The new run uses only documented repository native controls/helpers. There was no SQL, remote/existing-local database mutation, ad-hoc app-handler invocation, storage assignment, alternate browser, source edit or service adoption.

## Offline checks, exact bytes and restricted sharing

The unchanged closed raw run contains **278 payloads**, **5,323,038 expanded bytes**, **7 PNGs**, **0 workbooks**. The seven images are three immediate admitted-B captures, three current failure/draft captures, and final owner cleanup. Inventory, original native metadata and report/checker outputs are outside raw.

Output directory:
`/home/waffleflops/.cache/t2t-1376-rating-feedback-repair-output`

`check.mjs` was actually run with Node24 and exited 0. `check-result.json` records 278 assertions re-reading full20 originals, all three B before/after/reload comparisons, actual 200/202/201 business wire statuses/bodies, current503 errors and retained drafts/retry controls, captured A effects, exact full13 pending/cancelled history, witness absence, registered-file preservation/removal, hook restoration and closed source/input receipts. The checker accepts an expanded raw path as its first argument and performs no app/provider action. It checks PNG format; humans must independently inspect actual images and immediate observation order. It does not turn a zero feedback recorder into info acknowledgement coverage.

`raw-inventory.json` describes literal original bytes in this closed run. `inventory.mjs` exited 0 and `inventory-result.json` records its result. `historical-byte-audit.json` separately recomputes and preserves **all685 original historical payloads / 9,325,725 bytes** and **all167 original failed-checkpoint payloads / 6,111,096 bytes**. Byte identity does not change historical failures/unavailable status. The prior sanitized 167-payload view is a distinct output with four auth-root redactions; its size differs from the original private run.

Nine original native network metadata files are retained privately at:
`/home/waffleflops/.cache/t2t-1376-rating-feedback-private-native`

Do not publish that directory. Each raw `*-wire-business.json` is an explicit capture projection of `$.structuredContent.networkRequest`: only request/response headers are replaced by `[OMITTED HEADER PROJECTION]`, all other observed business leaves/statuses retained exactly. Original native `$.content` text also stays entirely private because it repeats headers. Captured request/response body files are unchanged literal tool bytes where available. The nine private metadata files are not part of the 278 raw payload count and no metadata-original byte-equality claim is made for their projected files.

`private-native-inventory.json` hashes the nine restricted originals. `private-auth-mapping.json` supplies exact original/projected filenames, original/projected SHA256, excluded field paths, retained literal business-leaf hash and equality, and status/method without authentication values. It also points to and retains the exact four prior auth-root path/workspace-leaf mappings from the failed checkpoint. No new full auth-root page-data capture was taken in this run. `privacy-scan.json` found no JWT pattern in new raw text payloads; this is a scoped scan, not a general secrets guarantee. No sanitized copy, archive, tracked package, adoption record, publication or commit was created by the worker.

The root coordinator owns packaging and full expanded independent acceptance. The closed raw originals, reports and restricted mapping are ready for that review.
