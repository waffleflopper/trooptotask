# D29 / #1377 final live verification — candidate 6ca044ee

- Revision: 6ca044ee67a8f39ee2f9334bea82363d5cec2b7a (detached, clean)
- Candidate digest: fc9a91d5dea8bc811521877c394aa60998ca372bc71130cc9065b88331d2fc92
- Origin: http://127.0.0.1:46185 (worker 1, session 2cc9cdb1-8e44-4215-a691-8a8841dbd11a)
- Browser: Chromium 152.0.7977.82 Arch Linux
- Fixture/browser date 2026-10-07; host offset -08:00. Start 22:05, driving done 22:40 (-08:00).
- Inputs: inputs/signed-scan.pdf (sha256 46119627…) and inputs/counseling.pdf (sha256 503e17e9…) are byte copies of the baseline synthetic inputs.

All paths are **live-verified** unless marked otherwise.

## 1. Account profile rank (viewer) — PASS
Same 28 options in the same order as baseline. Original names/rank were empty. Filled Synthetic/Viewer and saved SFC: "Profile updated". After reload, SFC was selected. The rank cannot be cleared, so the profile was left for worker disposal (sign-in.md step 6).

## 2. Evals type (ratingOperate) — PASS
1LT → OER (Officer), CW2 → WOER (Warrant Officer), SSG → NCOER (NCO). Each draft was cancelled with 0 dialogs left open. Organization A had 9 rows with the same IDs before and after; Officer, Warrant and NCO had 2, 1 and 2 rows, as in baseline.

## 3. Sign-in roster (rosterManager) — PASS
- Rank chips were the same as baseline. The Group chips were Bravo, Alpha, while baseline showed Alpha, Bravo. Both runs list the Group with the lower fixture UUID first, and no changed file touches Group loading, so this is fixture variance.
- Roster 5c1dac45… was created with POST 200. The PDF is 4284 B with the same text layout (baseline 4286 B, with a different title). The saved row has filter {ranks:[SPC],groups:[Alpha]}, sort rank, separated by Group, and Able's snapshot.
- Scan upload returned POST 200. It was stored at orgA/sign-in-rosters/<roster>/<uuid>-signed-scan.pdf in the private `counseling-files` bucket and persisted after reload. Open plus signed-download gave 3186 B whose SHA-256 matches the upload.
- Delete went through the confirmation; after reload the count was 3, there were 0 rows and roster-files was [].

## 4. Counseling (manager, personnel-lifecycle Person 6413397b…) — PASS (Open: UNRUN, no control)
A forced 503 showed "Unable to upload counseling PDF.", kept the draft and file, and saved no row or object. The retry returned 200 and created row 11ca1c2c…. Its file is at orgA/counseling-records/<person>/<uuid>-counseling.pdf in `counseling-files`, 3185 B with a matching SHA-256. The title was mirrored to subject and the summary to notes. The card persisted after reload. Archive then Delete from Archived removed the row, and the file is present:false.

## 6b. Archives export (orgOwner) — PASS
GET 200 downloaded SPC-MapDuplicateac9d7d9c-records.xlsx, 9314 B, with the same four sheets as baseline. After normalizing the seed tag, every sheet's content is identical to baseline.

## 5. Bulk import (calendarOperate) — PASS
The import showed "Person not found" and "End date must be on or after start date", with 0 of 2 rows selected. With duplicate-able seeded, the unranked Able row showed "Multiple people with this name — add Rank column to disambiguate". The valid row imported: batch POST 200 with 1 record, "Import complete", "1 status entry imported successfully." The row persisted after Done and reload. It was removed through the Remove tab ("1 exact match will be removed"); afterwards it had 0 rows and the seeded Able rows were retained.

## 6a. Organization export (orgOwner) — PASS
- JSON: POST 200 downloaded org-export-<orgA>-2026-10-08.json, application/json, 159600 B. It has 42 top-level keys in baseline order and 38 sections whose counts match baseline, and the inventory rowCounts match the arrays.
- Excel: POST 200 downloaded org-export-<orgA>-2026-10-08.xlsx, 67956 B. It has 57 sheets with names identical to baseline, and the 38 Export Inventory rows are identical to baseline.
- data_exports has 2 completed rows of 159600 and 67956 B, and the same after reload; Organization B has 0.

## 6c. Training report (trainingConfigure) — PASS
GET 200 downloaded training-report-2026-10-07.xlsx, 11767 B. The sheets are exactly Summary, Forecast, Hot spots, Focus and Requirements, and every sheet's cells are identical to baseline.

## 7. Calendar access — PASS
- Range reads all returned 200: Lane saw A, B and Unassigned; Scoped saw Alpha only; Empty saw none. No foreign IDs or private status appeared.
- On Able's Sep 15 cell the assignment badge order was "VSD VAD" vs baseline "VAD VSD". Both runs list the lower assignment-type fixture UUID first, and the changed Calendar files only change imports, so this is fixture variance.
- Writes returned 403/403 for view, manager, scoped→Baker, scoped→Unassigned and empty, and 404/404 for lane→B ("Organization not found"). Every response body is identical to baseline. No marker rows were saved; A has 6 rows and B has 1, the same notes as baseline.

## Cleanup
Every network, export and feedback control was restored after use. clean-seeds ran after cases 2, 6b and 5 (twice) and at the end. The roster, counseling and availability rows created through the UI were removed through visible controls. Final doctor PASS, then owned cleanup.
