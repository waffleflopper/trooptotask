import json, os, pathlib, subprocess, sys
root = pathlib.Path.cwd()
evidence = root / ".verification/evidence/verify-trooptotask/d27-policy-baseline"
env = dict(os.environ)
env["PATH"] = "/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:" + env["PATH"]
name, tool, raw = sys.argv[1:]
args = json.loads(raw)
if tool in ["take_snapshot", "take_screenshot", "evaluate_script"]:
    args["filePath"] = str(evidence / (name + (".png" if tool == "take_screenshot" else ".txt")))
result = subprocess.run(["node", "scripts/verification/cli.mjs", "tool", tool, json.dumps(args)], env=env, capture_output=True, text=True)
(evidence / (name + ".command.json")).write_text(json.dumps({"tool": tool, "args": args, "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr}, indent=2))
try:
    payload=json.loads(result.stdout)
    lines='\n'.join(x.get('text','') for x in payload.get('content',[]) if x.get('type')=='text').splitlines()
    print('\n'.join(lines[-30:]) or result.stdout[:1200])
except (ValueError,TypeError):
    print(result.stdout[:1200])
raise SystemExit(result.returncode)
