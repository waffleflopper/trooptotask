import json, sys, base64, hashlib, pathlib
t = pathlib.Path('/home/waffleflops/.claude/projects/-home-waffleflops--t3-worktrees-trooptotask-v1-maintenance-t3code-6ed7bc4e/cc2437a8-e64c-40dc-83e8-7d4bb47d8a27.jsonl')
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
for line in t.read_text().splitlines():
    try: e = json.loads(line)
    except Exception: continue
    c = (e.get('message') or {}).get('content')
    if not isinstance(c, list): continue
    for p in c:
        if p.get('type') != 'tool_result': continue
        body = p.get('content'); texts = [b.get('text','') for b in body] if isinstance(body, list) else [body or '']
        for tx in texts:
            if '"b64"' not in tx: continue
            try: v = json.loads(tx)['value']
            except Exception: continue
            for item in (v if isinstance(v, list) else [v]):
                d = item.get('dump'); label = item.get('label')
                if not d or not label: continue
                raw = base64.b64decode(d['b64']); h = hashlib.sha256(raw).hexdigest()
                assert h == d['sha256'] and len(raw) == d['size'], label
                (out / f'{label}.xlsx').write_bytes(raw); print(label, len(raw), h)
