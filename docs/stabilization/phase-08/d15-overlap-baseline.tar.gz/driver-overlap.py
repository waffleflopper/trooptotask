from drive import *
import time,hashlib

def save(name,value):write(E/(name+'.json'),json.dumps(value,indent=2)+'\n')
def ordinary(role,endpoint,body,tag,wait=True):
 file=E/(tag+'-body.json');write(file,json.dumps(body,indent=2)+'\n');command=['node','.verification/tmp/d15-packets/owned-onboarding-http.mjs',role,'orgA','PUT',endpoint,str(file.relative_to(ROOT))];save(tag+'-command',command)
 output=open(E/(tag+'.json'),'x');error=open(E/(tag+'-stderr.log'),'x');process=subprocess.Popen(command,stdout=output,stderr=error,text=True);output.close();error.close()
 if not wait:return process
 cleanup={'pid':process.pid,'forced':False}
 try:code=process.wait(timeout=70)
 finally:
  if process.poll() is None:
   process.terminate();cleanup['forced']=True
   try:process.wait(timeout=8)
   except subprocess.TimeoutExpired:process.kill();process.wait(timeout=8)
  cleanup['exit']=process.returncode;save(tag+'-child-cleanup',cleanup)
 assert not cleanup['forced'] and code==0,(E/(tag+'-stderr.log')).read_text()
 return json.loads((E/(tag+'.json')).read_text())
def run(mode):
 assert mode in ['notes','lifecycle'];seed=json.loads((E/(mode+'-legacy-seed.json')).read_text());fixture=json.loads((E/'fixture.json').read_text());packet=seed['packets'][0]['id'];step=next(r['id'] for r in seed['progress'] if r['step_name']=='Orientation')
 endpoint='onboarding-steps' if mode=='notes' else 'onboarding'
 before={}
 for org in ['orgA','orgB']:
  for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
   before[org,table]=control(['rows',table,org],mode+'-before-'+table+'-'+org)['rows']
 missing='00000000-0000-4000-8000-000000000001'
 assert not any(r['id']==missing for r in before['orgA','onboarding_step_progress' if mode=='notes' else 'personnel_onboardings']), 'Missing-target warmup UUID must actually be absent before writes'
 for role in ['onboardingOperate','onboardingConfigure']:
  warm={'action':'addNote','stepId':missing,'text':'D15 session warmup'} if mode=='notes' else {'id':missing,'status':'cancelled'}
  result=ordinary(role,endpoint,warm,mode+'-warm-'+role);assert result['status']==404,result
 bodies=[{'action':'addNote','stepId':step,'text':'D15 overlap note '+label+' '+seed['tag']} for label in ['A','B']] if mode=='notes' else [{'id':packet,'status':status} for status in ['cancelled','completed']]
 files=[]
 for label,body in zip(['A','B'],bodies):
  file=E/(mode+'-request-'+label+'.json');write(file,json.dumps(body,indent=2)+'\n');files.append(file)
 session=json.loads((E/'launch.json').read_text())['session'];command=['python3','.verification/tmp/d15-overlap/provider-hold.py',mode,'--session','/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1','--session-id',session,'--seed',str((E/(mode+'-legacy-seed.json')).absolute()),'--request-a',str(files[0].absolute()),'--request-b',str(files[1].absolute()),'--evidence',str(E.absolute()),'--max-hold-seconds','25'];save(mode+'-hold-command',command)
 output=open(E/(mode+'-hold.log'),'x');holder=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,text=True);output.close();requests=[]
 try:
  deadline=time.monotonic()+20
  while time.monotonic()<deadline:
   text=(E/(mode+'-hold.log')).read_text();lines=[json.loads(line) for line in text.splitlines() if line.startswith('{')];ready=[row for row in lines if row.get('status')=='HOLDING']
   if ready:save(mode+'-holder-ready',ready[-1]);break
   assert holder.poll() is None,text;time.sleep(.1)
  else:raise RuntimeError('Holder did not become ready; inconclusive')
  for role,label,body in zip(['onboardingOperate','onboardingConfigure'],['A','B'],bodies):requests.append(ordinary(role,endpoint,body,mode+'-response-'+label,False))
  code=holder.wait(timeout=45)
  exits=[request.wait(timeout=70) for request in requests];save(mode+'-process-exits',{'holder':code,'ordinaryRequests':exits});assert code==0 and exits==[0,0],text
 finally:
  cleanup=[]
  for label,process in [('holder',holder),*[(f'ordinary-{i}',child) for i,child in enumerate(requests)]]:
   record={'child':label,'pid':process.pid,'forced':False}
   try:
    if process.poll() is None:
     if label=='holder':process.terminate();record['forced']=True
     try:process.wait(timeout=15 if label=='holder' else 70)
     except subprocess.TimeoutExpired:
      process.terminate();record['forced']=True
      try:process.wait(timeout=8)
      except subprocess.TimeoutExpired:process.kill();process.wait(timeout=8)
    record['exit']=process.returncode
   except BaseException as error:record['cleanupError']=type(error).__name__
   cleanup.append(record)
  save(mode+'-child-cleanup',cleanup)
  assert all('exit' in r and not r.get('forced') and 'cleanupError' not in r for r in cleanup), 'Child failure/forced cleanup is INCONCLUSIVE; inspect every recorded exit and holder backend cleanup before seed cleanup'
 responses=[json.loads((E/(mode+'-response-'+label+'.json')).read_text()) for label in ['A','B']]
 parents=control(['rows','personnel_onboardings','orgA','id',packet],mode+'-after-parent')['rows'];progress=control(['rows','onboarding_step_progress','orgA','onboarding_id',packet],mode+'-after-progress')['rows'];assert len(parents)==1 and len(progress)==3
 if mode=='notes':
  current=next(r for r in progress if r['id']==step);texts=[n['text'] for n in current['notes']];retainedOriginal=all(n in current['notes'] for n in next(r for r in seed['progress'] if r['id']==step)['notes']);markers=[b['text'] for b in bodies]
  outcome={'result':'PASS' if [r['status'] for r in responses]==[200,200] and retainedOriginal and all(t in texts for t in markers) else 'FAIL','expected':'Two successful ordinary appends retain original notes and both attributed new markers','statuses':[r['status'] for r in responses],'originalRetained':retainedOriginal,'savedMarkers':[t for t in markers if t in texts],'missingMarkers':[t for t in markers if t not in texts],'savedNotes':current['notes'],'ordinaryActorIds':[fixture['actors'][role]['id'] for role in ['onboardingOperate','onboardingConfigure']]}
 else:
  statuses=[r['status'] for r in responses];parent=parents[0];winners=[i for i,status in enumerate(statuses) if status==200];winner_matches=len(winners)==1 and parent['status']==bodies[winners[0]]['status'];oneTerminal=(parent['status']=='cancelled' and parent['cancelled_at'] is not None and parent['completed_at'] is None) or (parent['status']=='completed' and parent['completed_at'] is not None and parent['cancelled_at'] is None)
  outcome={'result':'PASS' if len([s for s in statuses if s==200])==1 and all(s in [200,400,409] for s in statuses) and oneTerminal and winner_matches else 'FAIL','expected':'Only one transition from the same in-progress parent succeeds; the other receives a rejected state/conflict response (400/409); single matching terminal timestamp','statuses':statuses,'savedParent':parent,'singleTerminalTimestamp':oneTerminal,'savedStatusMatchesSuccessfulRequest':winner_matches}
 after={}
 for org in ['orgA','orgB']:
  for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
   after[org,table]=control(['rows',table,org],mode+'-after-'+table+'-'+org)['rows']
 comparisonIssues=[]
 for key,old in before.items():
  oldMap={r['id']:r for r in old};newMap={r['id']:r for r in after[key]};
  if oldMap.keys()!=newMap.keys():comparisonIssues.append({'table':list(key),'issue':'row identities changed'})
  target_id=step if mode=='notes' else packet;target_table='onboarding_step_progress' if mode=='notes' else 'personnel_onboardings'
  for record_id,row in oldMap.items():
   if record_id not in newMap:continue
   if key==('orgA',target_table) and record_id==target_id:
    allowed={'notes','updated_at'} if mode=='notes' else {'status','completed_at','cancelled_at'}
    
    if {k:v for k,v in row.items() if k not in allowed}!={k:v for k,v in newMap[record_id].items() if k not in allowed}:comparisonIssues.append({'table':list(key),'id':record_id,'issue':'unexpected target fields changed'})
   elif newMap[record_id]!=row:comparisonIssues.append({'table':list(key),'id':record_id,'issue':'untouched captured row changed'})
 outcome['otherFullPacketProgressAndSelectedTrainingAndUntouchedTargetFieldsUnchanged']=not comparisonIssues
 outcome['unexpectedRowChanges']=comparisonIssues
 if comparisonIssues:outcome['result']='FAIL'
 if mode=='notes':
  from datetime import datetime
  expected_count=len(next(r for r in seed['progress'] if r['id']==step)['notes'])+2
  attributed=[]
  for label,body,role in zip(['A','B'],bodies,['onboardingOperate','onboardingConfigure']):
   matches=[n for n in current['notes'] if n['text']==body['text']]
   valid=len(matches)==1 and matches[0].get('userId')==fixture['actors'][role]['id']
   if valid:
    try:valid=datetime.fromisoformat(matches[0]['timestamp'].replace('Z','+00:00')).tzinfo is not None
    except (ValueError,KeyError,TypeError):valid=False
   attributed.append({'label':label,'valid':valid})
  outcome['attribution']=attributed;outcome['expectedNoteCount']=expected_count;outcome['savedNoteCount']=len(current['notes'])
  if not all(x['valid'] for x in attributed) or len(current['notes'])!=expected_count:outcome['result']='FAIL'
 save(mode+'-outcome',outcome);print(json.dumps(outcome),flush=True)
if __name__=='__main__':
 mode=os.environ['D15_MODE']
 try:run(mode)
 except BaseException as error:
  save(mode+'-driver-inconclusive',{'result':'INCONCLUSIVE','reason':type(error).__name__,'message':str(error),'action':'Inspect holder/child cleanup and observed responses before reuse; root must finish exact owned cleanup'})
  raise
