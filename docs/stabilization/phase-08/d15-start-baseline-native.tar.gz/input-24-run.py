#!/usr/bin/env python3
"""Capture exact owned verification commands and actual outcomes."""
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path('.verification/evidence/verify-trooptotask/d15-start-baseline-native')
mode, label, *args = sys.argv[1:]
if mode not in ('verify', 'helper', 'provider') or not re.fullmatch(r'[a-z0-9]+(?:[.-][a-z0-9]+)*', label):
    raise SystemExit('Use verify/helper/provider and a unique plain capture label')
command = {
    'verify': ['npm', 'run', '--silent', 'verify:app', '--'],
    'helper': ['node', '.agents/skills/verify-trooptotask/helpers/control.mjs', '--worker', '1'],
    'provider': ['python3', '.agents/skills/verify-trooptotask/helpers/onboarding-start-provider.py']
}[mode] + args
with (root / (label + '-input.json')).open('x') as stream:
    json.dump({'argv': command}, stream, indent=2); stream.write('\n')
result = subprocess.run(command, capture_output=True, text=True)
for suffix, value in [('json', result.stdout), ('stderr', result.stderr)]:
    with (root / (label + '.' + suffix)).open('x') as stream:
        stream.write(value)
with (root / (label + '-exit.json')).open('x') as stream:
    json.dump({'exitCode': result.returncode}, stream)
print(result.stdout, end='')
print(result.stderr, end='', file=sys.stderr)
raise SystemExit(result.returncode)
