import json
from pathlib import Path
p = Path(__file__).parent
f = json.loads((p / "fixture.json").read_text())
checks = []
keys = ["availabilityAlpha", "availabilityBravo", "availabilityUnassigned", "availabilityForeign"]
def read(name):
    return json.loads((p / (name + ".json")).read_text())
def present(body, labels):
    return [k for k in labels if f["ids"][k] in body]
for role, expected in [("calendarScoped", ["availabilityAlpha"]), ("calendarEmpty", []), ("calendarView", keys[:3])]:
    x = read(role + "-range")
    assert x["status"] == 200 and present(x["body"], keys) == expected
    checks.append([role + " range", "PASS", expected])
for role, expected in [("viewer", ["personA", "personB", "personUnassigned"]), ("scoped", ["personA"]), ("manager", ["personA", "personB", "personUnassigned"])]:
    x = read(role + "-data")
    assert x["status"] == 200 and present(x["body"], ["personA", "personB", "personUnassigned", "personForeign"]) == expected
    checks.append([role + " roster", "PASS", expected])
n = 0
for name in ["calendarScoped-denied", "calendarEmpty-denied", "calendarView-denied", "manager-orgA-statusLeave-denied", "calendarLane-orgB-statusForeign-denied", "calendarLane-orgA-statusForeign-denied"]:
    for r in read(name)["out"]:
        assert r["status"] in [403, 404]
        n += 1
assert n == 16
checks.append(["single/batch denied writes", "PASS", n])
for name in ["lane-concurrent", "switch-concurrent"]:
    for pair in read(name)["pairs"]:
        for r in pair:
            expected = keys[:3] if r["orgId"] == f["ids"]["orgA"] else (["availabilityForeign"] if name == "switch-concurrent" else [])
            assert r["status"] == (200 if expected else 404) and present(r["body"], keys) == expected
    checks.append([name, "PASS", "both request orders"])
assert read("grant-denied")["status"] == 403
assert "Access Restricted" in (p / "grant-after.txt").read_text()
assert "SPC Able" not in (p / "grant-after.txt").read_text()
assert read("grant-restored-range")["status"] == 200
checks.append(["narrowed/reloaded/restored grant", "PASS", "403, settled restriction, restored200"])
anon = read("anonymous-protected")
assert anon["status"] == 200 and anon["redirected"] and anon["url"].endswith("/auth/login")
assert not present(anon["body"], keys)
checks.append(["signed-out protected request", "PASS", "redirected to sign-in without saved IDs"])
for org in ["A", "B"]:
    assert "D27-" not in json.dumps(read("availability-" + org + "-final-denials"))
checks.append(["A/B attempted marker absence", "PASS", "zero D27 markers"])
(p / "artifact-inspection.json").write_text(json.dumps(checks, indent=2) + "\n")
print(json.dumps(checks, indent=2))
