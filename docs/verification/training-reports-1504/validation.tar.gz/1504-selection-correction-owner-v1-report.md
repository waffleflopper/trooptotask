# #1504 selection correction (owner v1)

Base HEAD ea4482b531b7e4a967bcd96ba249eef075e4ef0c. Changes are uncommitted in the worktree for root to integrate.

## Defect

Bits UI 2.18.1 `ToggleGroup` type=single clears its value when someone activates the item that is already active. The shared wrapper `bind:value`s its own `$bindable` prop. The three Training controls passed a one-way `value` plus an `onValueChange` that ignored the empty string. Nothing bound the wrapper's prop to the parent, so it kept the locally written `''`. The canonical prop did not change, so the parent never pushed `'25'` back down. Both radios ended up `aria-checked="false"`.

## Reproduced controls

All three, at the component boundary with `fireEvent.click` on the accessible radio:

- Rows per page, 25 already checked. Red: `red.log`, line 324.
- Forecast horizon, 90 days already checked. Red: `red.log`, line 353.
- Rows by, Group already checked. Red on its own after the Horizon-only fix: `red-rows-by-after-horizon-fix.log`, line 354.

The first draft activated each control twice before asserting. That hid the defect, because the second click toggles the value back on. It also exposed a duplicate same-size detail request (2 fetch calls instead of 1). The final tests assert after every activation.

## Fix

Data shape: each control has one always-present canonical value. That is `detail.request.pageSize` (25 | 100), `selected.horizonDays` or `selected.rowsBy`. Empty has no domain meaning.

API: a Svelte 5 function binding on the existing wrapper's `$bindable value`, `bind:value={() => canonical, (value) => { if (value) commit(value) }}`. The wrapper's write goes to the setter. The setter ignores `''`, the getter keeps returning the canonical value, and the item stays checked. The change touches no shared component, adds no mirrored local state and no effect. Same-value, pending/failed shown-vs-attempted and URL/session ownership are unchanged, because the same `update`/`onPageSize` calls run on real changes.

Files:
- `src/features/training/components/TrainingAffectedSoldiersSection.svelte` binds Rows per page.
- `src/features/training/components/TrainingReportsPage.svelte` binds Horizon and Rows by.
- `src/features/training/components/TrainingReportsPage.test.ts` adds two behavior tests. (1) Re-activating 25 keeps 25 checked and 100 unchecked, sends no request and keeps `Rows 1–25 of 30`. Choosing 100 then requests `pageSize=100`, shows `Rows 1–30 of 30` and moves the checked state. (2) Re-activating 90 days and Group keeps both checked, with no fetch and no `replaceState`. Choosing 30 days and MOS then updates the report and the URL to `?horizon=30&rowsBy=mos` and moves the checked state.

## Checks

- `green.log`: all 7 Training component test files pass, 39 tests, including the existing focus, retry and delayed-shrink tests.
- `checks.log`: prettier and eslint pass on the touched files. Full svelte-check reports 0 errors and 0 warnings.
- `selection-correction.diff` is the actual diff.

## Not proven here

No browser was used. Root still owns native proof of repeated activation (pointer and Space) on all three controls, URL and focus after real changes, full gates, commit and publication. The Horizon and Rows by bindings drive export/print inputs, so the proportional export/print smoke applies.
