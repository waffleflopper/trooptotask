import pathlib,json,re,hashlib,stat,subprocess,datetime
c=pathlib.Path(__file__).parent;e=pathlib.Path.cwd()/'.verification/evidence/verify-trooptotask/d28-final-persistence-baseline-recovery-6f5bcb15-20261008'
values=set(json.loads((c/'known-owned-values.private.json').read_text())['values'])
jwt=re.compile(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+')
private=list((c/'private-command-output').glob('*.json'))
for p in private:
 raw=p.read_text();values.update(jwt.findall(raw))
 for m in re.finditer(r'(?im)^([ \-]*(?:cookie|set-cookie|authorization|apikey):)(.+)$',raw):
  v=m[2].strip()
  if len(v)>15:values.add(v)
files=[];textcount=0;known=[];jwts=[]
for p in sorted(e.rglob('*')):
 if not p.is_file():continue
 b=p.read_bytes();files.append(dict(path=str(p.relative_to(e)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
 try:s=b.decode('utf8')
 except UnicodeDecodeError:continue
 textcount+=1
 if any(v and v in s for v in values):known.append(str(p.relative_to(e)))
 if jwt.search(s):jwts.append(str(p.relative_to(e)))
assert not known and not jwts,'Public literal/JWT match; paths only in private pending receipt'
privates=[c/'known-owned-values.private.json',c/'preexisting-container-inspect.json',c/'postexisting-container-inspect.json',*c.glob('*-private-full.json'),*private]
assert all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in privates)
receipt=dict(status='PASS',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),publicFilesScanned=len(files),utf8TextFilesScanned=textcount,knownSensitiveLiteralCount=len(values),knownMatches=known,jwtPatternMatches=jwts,scope='Actual owned state sensitive literals captured before cleanup plus JWT literals from retained private tool output; public raw directory only. Does not establish universal transcript or unobserved-secret sanitation.',privateOriginalFilesChecked0600=len(privates),privateOriginalsExcludedFromPublic=True)
(e/'public-sanitation.json').write_text(json.dumps(receipt,indent=2)+'\n')
entry=json.loads((c/'entry-source-inventory.json').read_text());current=[dict(path=x['path'],bytes=len(pathlib.Path(x['path']).read_bytes()),sha256=hashlib.sha256(pathlib.Path(x['path']).read_bytes()).hexdigest()) for x in entry];assert current==entry
closure=json.loads((e/'actual-closure.json').read_text());assert closure['status']=='PASS' and closure['allRecordedNumericPIDPathsAbsent']
summary=dict(candidate='7d8da9bf96bb7af41c7f9d7e848aef87085d88c3b9daed35195923c9f912ac4d',revision='6f5bcb156e309a6f58a3b393b149c8da8dc67816',session='872b3fca-f69b-4771-bbd4-617362a1b7a8',sourceCount=len(entry),sourceEntryExitExact=True,gitStatus=subprocess.check_output(['git','status','--short'],text=True),nativeGroups3And4='PASS at stated scope',original27FullFieldsKeysTimestamps='PASS',initialControlFailuresPreserved=True,priorOct5DateFAILPreserved='Correctly observed Oct7 recovery save/readback/reload PASS; initial cause remains control uncertainty, not proven framework cause',appSourceChanges=0,controlChangesDuringRun=0,pendingCommands='NONE',ownedResources='CLOSED')
(e/'recovery-outcomes.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for p in sorted(e.rglob('*')):
 if p.is_file():b=p.read_bytes();files.append(dict(path=str(p.relative_to(e)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(c/'public-artifact-inventory.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps(dict(publicPayloads=len(files),textScanned=textcount,knownLiteralCount=len(values),private0600Files=len(privates),sourceCount=len(entry),closure='PASS')))
