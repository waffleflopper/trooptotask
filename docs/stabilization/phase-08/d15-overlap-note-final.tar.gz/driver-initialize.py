from drive import *
import hashlib
for action in ['doctor','tools']:
 command=['npm','run','--silent','verify:app','--',action,'--worker','1'];(E/(action+'-initial-command.json')).write_text(json.dumps(command,indent=2)+'\n');r=subprocess.run(command,text=True,capture_output=True);(E/(action+'-initial.json')).write_text(r.stdout);(E/(action+'-initial-stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stderr
control(['fixture'],'fixture')
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  control(['rows',table,org],'original-'+table+'-'+org)
control(['seed','onboarding-legacy'],'notes-legacy-seed')
print('Owned initialization and full original A/B rows captured; ledgered legacy cohort ready.',flush=True)
