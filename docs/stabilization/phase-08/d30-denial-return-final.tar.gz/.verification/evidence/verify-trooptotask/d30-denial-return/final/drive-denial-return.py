import json, os, re, subprocess
from pathlib import Path
root=Path.cwd(); out=root/'.verification/evidence/verify-trooptotask/d30-denial-return/final'
env=os.environ.copy();env['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+env['PATH']
for role,denied,link in [('ictViewer','personnel','ICTLs'),('calendarLane','training','Calendar'),('trainingView','calendar','Training')]:
 d=out/role;d.mkdir(parents=True,exist_ok=True)
 def call(args,name):
  p=subprocess.run(args,env=env,text=True,capture_output=True,timeout=120)
  (d/name).write_text(p.stdout+p.stderr)
  if p.returncode: raise RuntimeError(f'{role} {name}: exit {p.returncode}')
  return p.stdout
 def tool(name,args,receipt):
  return call(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args)],receipt)
 actor=json.loads(call(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1','actor',role,denied],'actor.json'))
 page=actor['pageId']
 def snapshot(name):
  path=d/name
  tool('take_snapshot',{'pageId':page,'filePath':str(path)},name+'.receipt.json')
  return path.read_text()
 def wait(text,name): tool('wait_for',{'pageId':page,'text':[text],'timeout':30000},name)
 def enter(name):
  snap=snapshot(name+'-before.txt')
  m=re.search(r'uid=(\S+) link "'+re.escape(link)+r'" ',snap)
  if not m: raise RuntimeError(f'No visible {link} link for {role}')
  tool('click',{'pageId':page,'uid':m[1]},name+'-action.json')
  wait('Able, Synthetic',name+'-wait.json')
  settled=snapshot(name+'-after.txt')
  if 'Baker, Synthetic' not in settled or 'Unassigned, Synthetic' not in settled: raise RuntimeError(f'Missing admitted rows for {role}')
  tool('take_screenshot',{'pageId':page,'filePath':str(d/(name+'.png'))},name+'-screenshot.json')
 wait('Access Restricted','initial-denial-wait.json')
 snapshot('initial-denied.txt')
 enter('first-allowed')
 tool('navigate_page',{'pageId':page,'type':'back'},'back-to-denied-action.json')
 wait('Access Restricted','returned-denial-wait.json')
 snap=snapshot('returned-denied.txt')
 if 'Able, Synthetic' in snap: raise RuntimeError(f'Roster exposed on denied {role}')
 tool('take_screenshot',{'pageId':page,'filePath':str(d/'returned-denied.png')},'returned-denied-screenshot.json')
 enter('second-allowed')
 print(role,'PASS',flush=True)
