from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

WORKTREE = Path('/home/waffleflops/.cache/t2t-1376-backup-readers')
ROOT = Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
EVIDENCE = WORKTREE / '.verification/evidence/backup-reader-owner'
assert Path.cwd().resolve() == WORKTREE
ENV = dict(os.environ)
ENV['PATH'] = '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + ENV['PATH']
TESTS = [
    'src/features/data-export/dataExportRead.server.test.ts',
    'src/features/rating-scheme/server/ratingSchemeExportRead.server.test.ts',
]
SOURCES = [
    'src/features/data-export/dataExportRead.server.ts',
    'src/features/rating-scheme/server/ratingSchemeRead.server.ts',
    'src/features/calendar/calendarExportRead.server.ts',
    'src/features/calendar/calendarExportRead.server.test.ts',
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

versions = {
    'node': subprocess.check_output(['node', '--version'], env=ENV, text=True).strip(),
    'npm': subprocess.check_output(['npm', '--version'], env=ENV, text=True).strip(),
    'vitest': json.loads((WORKTREE / 'node_modules/vitest/package.json').read_text())['version'],
    'python': subprocess.check_output(['python3', '--version'], text=True).strip(),
}
copy_records = []
for path in TESTS:
    raw = (ROOT / path).read_bytes()
    if path == TESTS[0]:
        assert b"owned[0] = { ...owned[0], status: 'completed', file_size_bytes: 2048 };" in raw
        assert b"owned[1] = { ...owned[1], status: 'processing', completed_at: null };" in raw
    else:
        assert b"status: 'completed'" in raw
        assert b"owned[1000] = { ...owned[1000], status: 'change-of-rater', workflow_status: 'with-rater' };" in raw
    (WORKTREE / path).write_bytes(raw)
    assert (WORKTREE / path).read_bytes() == raw
    copy_records.append({'path': path, 'source': str(ROOT / path), 'sha256': sha(raw), 'copied_verbatim': True})
original = {path: (WORKTREE / path).read_bytes() for path in SOURCES + TESTS}
metadata = {
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'worktree': str(WORKTREE),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'versions': versions,
    'root_tests_copied': copy_records,
    'frozen_sha256': {path: sha(data) for path, data in original.items()},
    'executions': [],
    'historical_logs': [],
    'limits': ['Offline SDK tests with synthetic fetch responses. No browser, database, service, publication, or root mutation.'],
}
for name in ['tenant-filter-fault.log', 'status-projection-fault.log', 'focused-tests-accepted.log', 'lint-accepted.log', 'format-check-accepted.log']:
    path = EVIDENCE / name
    assert path.is_file(), name
    raw = path.read_bytes()
    metadata['historical_logs'].append({'path': str(path), 'sha256': sha(raw), 'bytes': len(raw), 'provenance': 'Retained original execution log. Not rerun or edited for this follow-up.'})
metadata['historical_limits'] = 'Original raw logs do not embed command or source/test hashes. They are preserved unchanged. This follow-up embeds exact commands and restored hashes for the new Data Export and Rating witness runs.'

def run(label, tests, expected_exit):
    argv = ['npm', 'run', '--silent', 'test', '--'] + tests
    path = EVIDENCE / f'{label}.log'
    with path.open('w') as log:
        log.write(json.dumps({'command': argv, 'cwd': str(WORKTREE), 'versions': versions, 'input_sha256': {p: sha((WORKTREE / p).read_bytes()) for p in SOURCES + TESTS}}, indent=2) + '\n\n')
        log.flush()
        result = subprocess.run(argv, env=ENV, stdout=log, stderr=subprocess.STDOUT)
    raw = path.read_bytes()
    plain = re.sub(r'\x1b\[[0-9;]*m', '', raw.decode())
    summaries = [line.strip() for line in plain.splitlines() if re.match(r'\s*(Test Files|Tests)\s', line)]
    entry = {'label': label, 'command': argv, 'log': str(path), 'exit_code': result.returncode, 'summaries': summaries, 'sha256': sha(raw), 'bytes': len(raw)}
    metadata['executions'].append(entry)
    print(json.dumps(entry), flush=True)
    assert result.returncode == expected_exit, entry
    assert summaries, entry
    if expected_exit:
        assert 'retains saved' in plain, 'Red must include the retained archive contract failure'
    return entry

faults = [
    ('data-export-failed-only-red', SOURCES[0], ".eq('org_id', orgId)", ".eq('org_id', orgId).eq('status', 'failed')", TESTS[0], 'data-export-restored-green'),
    ('rating-completed-only-red', SOURCES[1], ".eq('organization_id', orgId)", ".eq('organization_id', orgId)\n\t\t\t\t\t.eq('status', 'completed')", TESTS[1], 'rating-restored-green'),
]
for label, source, needle, fault, test, green in faults:
    try:
        text = original[source].decode()
        assert text.count(needle) == 1
        (WORKTREE / source).write_text(text.replace(needle, fault))
        run(label, [test], 1)
    finally:
        (WORKTREE / source).write_bytes(original[source])
    assert (WORKTREE / source).read_bytes() == original[source]
    metadata.setdefault('restorations', []).append({'source': source, 'sha256': sha(original[source]), 'byte_equal': True})
    run(green, [test], 0)
run('corrected-owner-suites-green', [
    'src/features/calendar/calendarExportRead.server.test.ts',
    'src/features/calendar/statusTypeRead.server.test.ts',
    'src/features/calendar/assignmentTypeRead.server.test.ts',
    'src/features/calendar/availabilityRead.server.test.ts',
    'src/features/calendar/specialDayOperations.server.test.ts',
    'src/features/training/server/trainingExportRead.server.test.ts',
    'src/features/training/server/trainingArchiveExportRead.server.test.ts',
    'src/features/onboarding/server/onboardingExportRead.server.test.ts',
    'src/features/personnel/ordinaryExportRead.server.test.ts',
    'src/features/identity/organizationExportRead.server.test.ts',
    'src/features/critical-tasks/server/criticalTasksExportRead.server.test.ts',
    'src/features/dashboard/server/dashboardConfigExportRead.server.test.ts',
    'src/features/rating-scheme/server/ratingSchemeExportRead.server.test.ts',
    'src/features/rating-scheme/server/ratingSchemeRead.server.test.ts',
    'src/features/data-export/dataExportRead.server.test.ts',
    'src/features/data-export/dataExportLifecycle.server.test.ts',
    'src/lib/audit/exportRetention.server.test.ts',
], 0)
for path, raw in original.items():
    assert (WORKTREE / path).read_bytes() == raw, path
metadata['restored_sha256'] = {path: sha((WORKTREE / path).read_bytes()) for path in SOURCES + TESTS}
metadata['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest = EVIDENCE / 'offline-witness-followup.json'
manifest.write_text(json.dumps(metadata, indent=2) + '\n')
print('Manifest ' + str(manifest), flush=True)
