SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 1260 AND backend_start = '2026-10-01 18:51:43.367486+00'::timestamptz AND application_name = 't2t-d15-race-789045c2';
