import json, subprocess, sys
from pathlib import Path
run=Path(sys.argv[1]); page=sys.argv[2]
cases=[
('cap-11',{'personnelDocumentStorageCapMb':11}),
('round-before-range',{'archiveRetentionMonths':0.6,'lossWarningWindowDays':30.6,'personnelDocumentStorageCapMb':9.6}),
('combined',{'archiveRetentionMonths':24,'lossWarningWindowDays':90,'personnelDocumentStorageCapMb':11}),
('empty',{}),
('retention-string',{'archiveRetentionMonths':'36'}),
('warning-null',{'lossWarningWindowDays':None}),
('cap-boolean',{'personnelDocumentStorageCapMb':True}),
('retention-zero',{'archiveRetentionMonths':0}),
('warning-high',{'lossWarningWindowDays':366}),
('cap-low',{'personnelDocumentStorageCapMb':9}),
('cap-high',{'personnelDocumentStorageCapMb':1025}),
('retired-expiration',{'archiveRetentionMonths':36,'criticalTasksDefaultExpirationMonths':12}),
('retired-warning',{'lossWarningWindowDays':180,'criticalTasksExpiringSoonWarningDays':30}),
('cap-restore',{'personnelDocumentStorageCapMb':100})]
for label,body in cases:
 out=run/('api-'+label+'.json'); assert not out.exists()
 args=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1','settings-request',page,'orgA','organization/settings',json.dumps(body)]
 proc=subprocess.run(args,capture_output=True,text=True,timeout=60);out.write_text(proc.stdout)
 if proc.returncode: raise RuntimeError(proc.stderr+proc.stdout)
 obj=json.loads(proc.stdout);print(label,json.dumps(obj))
 rows=subprocess.run(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1','rows','organizations','orgA'],capture_output=True,text=True,timeout=60)
 (run/('api-'+label+'-row.json')).write_text(rows.stdout)
 if rows.returncode:raise RuntimeError(rows.stderr+rows.stdout)
