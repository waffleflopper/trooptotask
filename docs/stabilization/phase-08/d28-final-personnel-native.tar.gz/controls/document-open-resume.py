import current as x
import json
d=x.d;title=x.run['tag']+' document'
before=x.loaded('document-pages-before');ids={p['id'] for p in before['structuredContent']['pages']};r=d.snap('document-open-refreshed-before');ns=list(d.walk(r['structuredContent']['snapshot']));start=next(i for i,n in enumerate(ns) if n.get('role')=='heading' and n.get('name')==title);end=next((i for i in range(start+1,len(ns)) if ns[i].get('role')=='heading'),len(ns));buttons=[n for n in ns[start+1:end] if n.get('role')=='button' and n.get('name')=='Open'];assert len(buttons)==1
(d.E/'document-open-target.json').write_text(json.dumps({'heading':title,'documentId':json.loads((x.c/'document.json').read_text())['id'],'nativeOpenUID':buttons[0]['id']},indent=2));d.tool('document-open-native','click',{'pageId':2,'uid':buttons[0]['id']});d.get_wire('document-open-wire',2,'personnel/'+json.loads((x.c/'seed.json').read_text())['ids']['person']+'/documents/');after=d.tool('document-pages-after','list_pages',{});new=[p for p in after['structuredContent']['pages'] if p['id'] not in ids];assert len(new)==1;pdf=new[0]['id'];problem=None
try:
 d.snap('document-pdf-native',pdf);d.shot('document-pdf-open',pdf)
except Exception as error:
 problem=type(error).__name__; (d.E/'document-pdf-capture-failure.json').write_text(json.dumps({'status':'FAIL','errorType':problem,'scope':'native popup snapshot/PNG','action':'close exact owned new page and doctor'},indent=2))
finally:d.tool('document-pdf-close','close_page',{'pageId':pdf})
d.tool('document-pages-closed','list_pages',{});r=d.call('doctor-after-pdf',['doctor']);assert r['status']=='PASS' and r['candidate']==x.run['candidate']
if problem:raise RuntimeError('Native PDF capture unavailable; preserved '+problem)
d.act('follow-ups-nav','link','Follow-ups');r=d.snap('follow-ups-ready');print([(n.get('role'),n.get('name')) for n in d.walk(r['structuredContent']['snapshot']) if n.get('role') in ['button','textbox']][-24:])
