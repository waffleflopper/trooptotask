# #1504 independent Comment Sicko audit, v1

Yes... Ha ha ha... Yes!

Recommendation: delete **2 comments**. Keep **10 comments** under the literal exceptions, with evidence below. **0 MUST KILL targets. 0 added or changed suppressions.** No source comments were deleted by this audit; all application corrections remain with root.

This is the independently spawned generic-agent Comment Sicko fallback, using the parent's inherited model. It supplies independent comment/suppression review, not model diversity, independent execution, visual acceptance, or complete #1504 acceptance. The namespaced profile was unavailable through the native spawn interface. I read the portable Comment Sicko prompt, its owning `no-comments/SKILL.md`, repository `AGENTS.md`, and `t2t-engineer/SKILL.md`. A narrow local `how` trace supplied the foreign dependency proof; the parent's prohibition on nested agents kept that trace local.

## Reviewed bytes and boundary

The complete comment/suppression census used the committed diff from `3cc4ec4cd5ae3839c77fdb9da24ab71f29a9551b` to **`fedded058b7cd74d31cd54ffbb26f554467bee9b`**, restricted to `src/`, `scripts/verification/`, and `.agents/skills/verify-trooptotask/helpers/`. Line references below are at that exact checkpoint, not at the changing working tree. The SHA-256 of `git diff --no-ext-diff --unified=0 BASE CHECKPOINT --` those three roots was `ca754ff5c4c90a7c5e1fd481db7549214759fba6a965735591e9183cccb6ab15`.

The census covered 31 changed files, including three deletions. Twelve added or changed comments occur in eight retained files. I read those comments' code and relevant direct consumers. Existing unchanged comments, removed legacy comments, historical artifacts, prose documentation, merge conflict markers, and incoming main's independent AppShell changes are excluded. The review never used merge-conflicted working-tree source as its candidate. The workflow and implementation reports supplied context only; authoring-agent manual comment reviews did not establish exceptions.

The eight comment-bearing blobs are pinned here:

| File | Checkpoint Git blob |
| --- | --- |
| `scripts/verification/print-capture.mjs` | `27861ca045c2c7e8ed1aa4b3b6769be23341d0f8` |
| `src/app.css` | `3447e671b49a5495f4e3a9ebbeb5da57f601db70` |
| `src/features/training/read-model/trainingBriefingSession.svelte.ts` | `b5f79f67e13379b16b22940bff67c971e1c08c02` |
| `src/features/training/server/trainingReportsQuery.server.ts` | `974d6ee7b962afb543285d08b0fef303fd157e40` |
| `src/features/training/utils/briefingFilterLabels.ts` | `28ae27cac91503c0e1b9f30a898816026f826c26` |
| `src/features/training/utils/trainingBriefing.ts` | `a773ce455f9c4da2eb954c453c2af28f4ee33172` |
| `src/features/training/utils/trainingReportWorkbook.ts` | `dee9ed7515be84222fbeebae3f175e4c566d4884` |
| `src/lib/domain/readinessRollup.ts` | `2eac991b767b29756357d065b578a03ead482720` |

## DELETE

1. **`src/app.css:356`**

   ```css
   /* Paper is light in either app theme: the light :root tokens, on white. */
   ```

   This narrates the following intentional print declarations, including `color-scheme: light`, explicit foreground/background colors and the light token values. It identifies no external surprise, public API contract, legal requirement, suppression exception, or issue/RFC constraint. Delete the comment only. **No MUST KILL:** an explicit print-theme choice is not a demonstrated internal workaround. This disposition makes no renderer or visual-style judgment.

2. **`src/app.css:432`**

   ```css
   /* Error notices print as text; Retry is a screen action. */
   ```

   This narrates the adjacent `[data-slot='alert-action'] { display: none; }` print rule. No keep-list exception applies. Delete the comment only. **No MUST KILL:** hiding a screen action in print is intentional behavior, not a proven root defect. Layout and renderer acceptance remain exclusively with Claude.

## KEEP with exact exceptions

The public API exception below means an exported type/function or public class method consumed across its module boundary, with an actual caller-facing guarantee or precondition. Export syntax alone did not establish a keep; each retained doc comment states a concrete contract verified against code and consumers.

1. **`scripts/verification/print-capture.mjs:359` — external dependency/protocol surprise**

   ```js
   /* Disconnect also releases pending protocol operations. */
   ```

   Proven narrow meaning: Puppeteer disconnection rejects outstanding client-side protocol callbacks. The scoped `capturePrint` cleanup catches an `IO.close` failure at lines 355–360, then attempts session detachment and temporary-client disconnection at lines 361–365; the cleanup deadline also unconditionally initiates temporary-client disconnection at line 377. The daemon's `print-capture` dispatch reaches this function; the production default `connect` imports the installed bundled Puppeteer rather than the test fake.

   Narrow HOW trace of the installed dependency: `node_modules/chrome-devtools-mcp/build/src/third_party/index.js:84086` (`CdpBrowser.disconnect`) calls `#connection.dispose`; `Connection.dispose` at line 75623 invokes `#onClose` and closes the transport; `#onClose` at line 75609 clears connection callbacks and calls every CDP session's `onClosed`; session `onClosed` at line 75437 clears its callbacks; `CallbackRegistry.clear` at line 75300 rejects each pending callback with `TargetCloseError`. These are behavior owned by a foreign dependency, not an internal compatibility layer to reshape. Installed `chrome-devtools-mcp` version: `1.10.1`; bundled file SHA-256: `c988e0684584b75e87ae04b768c4f8ae7064401afe5187ec0d4878b2c6833f12`.

   **Limit:** this proves release of pending local protocol promises. It does not prove Chromium destroys the remote PDF IO stream after a failed `IO.close`. The comment does not claim that stronger behavior, and this audit supplies no live cleanup execution.

2. **`src/features/training/read-model/trainingBriefingSession.svelte.ts:23` — public API contract**

   ```ts
   /** `request` names the page last asked for; `detail` is the page on screen, kept for the same scope while another page loads or fails. */
   ```

   The exported `BriefingDetailState` distinguishes attempted request data from displayed response data for consuming components. `#loadDetail` at lines 130–157 retains only the displayed detail with the same scope and keeps that response through loading/error; `TrainingAffectedSoldiersSection.svelte:50–66,83–84` derives the displayed range/page from `detail.detail` and the pending message from `detail.request`. This states a consumer-facing state invariant beyond the fields' types. The retention is authorized behavior represented by the explicit request/detail model, not a workaround confession or MUST KILL target.

3. **`src/features/training/read-model/trainingBriefingSession.svelte.ts:112` — public API contract**

   ```ts
   /** Opens a cell or focus area at its first page, keeping the page size already chosen. */
   ```

   Public `TrainingBriefingSession.requestDetail` resets the scope to page 1 while retaining the selected page size at lines 113–115. The Reports page calls that public method for cell/focus scope activation. The method name alone does not specify those reset/persistence semantics; the doc comment does.

4. **`src/features/training/server/trainingReportsQuery.server.ts:163` — public API contract**

   ```ts
   /** The affected requirements behind one grid cell or focus area, re-derived from the same filters. */
   ```

   `fetchTrainingBriefingDetail` is exposed through `src/features/training/index.server.ts` and consumed by the detail route. Lines 168–177 load the report-filtered source, match the requested cell/focus and then paginate it. The comment defines which requirement population the public read operation returns and its relation to canonical filters; it does not prescribe an internal workaround.

5. **`src/features/training/server/trainingReportsQuery.server.ts:180` — public API contract**

   ```ts
   /** The displayed briefing as a workbook, with every affected requirement of the filtered page. */
   ```

   `generateTrainingReportWorkbookExport` is exposed through the feature server entry point and consumed by the export route. Lines 185–188 build report and complete affected requirements from one filtered source, without a detail scope or pagination. The comment defines report/export population parity and completeness for callers. Here “filtered page” means the report's filters, not a single paginated detail page.

6. **`src/features/training/utils/briefingFilterLabels.ts:24` — public API contract**

   ```ts
   /** Every facet of a displayed briefing's normalized filters, as the printout and workbook state them. */
   ```

   Exported `briefingFilterLabels` promises the complete normalized report-filter representation. Its returned array at lines 30–39 covers all eight input facets; `TrainingReportsPage.svelte:160` and `trainingReportWorkbook.ts:33` consume the same public output. The comment states completeness and the required normalized/displayed input relationship, rather than narrating a private transformation.

7. **`src/features/training/utils/trainingBriefing.ts:682` — public API contract**

   ```ts
   /** Every requirement the filtered briefing marks not ready today or lapsing in the horizon, in drill-down order. */
   ```

   Exported `affectedBriefingRequirements` returns the complete affected set at lines 683–687. It uses `isAffected` and `compareAffected`; `matchBriefingRequirements` uses those same boundaries/order at lines 705,711. The server workbook caller consumes this complete set at line 188. The contract distinguishes a full ordered export population from a scoped/paged drill-down, which the array return type does not encode.

8. **`src/features/training/utils/trainingReportWorkbook.ts:7` — public API contract**

   ```ts
   /** Every affected requirement of the filtered briefing, unpaginated, in drill-down order. */
   ```

   This is the precondition on exported `TrainingReportWorkbookInput.requirements`. An array type cannot state completeness, filter parity or order. The production caller satisfies it with `detailRows(source, affectedBriefingRequirements(source.briefingInput))`; `detailRows` preserves the list order and does not paginate it. The workbook writes the provided list in that order at lines 153–162.

9. **`src/features/training/utils/trainingReportWorkbook.ts:102` — public API contract**

   ```ts
   /** The displayed briefing as five native sheets; every label stays a text cell. */
   ```

   Exported `buildTrainingReportWorkbook` promises a five-sheet output and text treatment of labels. Lines 104–163 create Summary, Forecast, Hot spots, Focus and Requirements through the shared workbook boundary. Labels/names remain string row values; `WorkbookRow` excludes formula objects, and `addTableSheet` passes primitive values to ExcelJS. The scoped server test at lines 495–501 independently specifies formula-looking names as String cells. I read that test; I did not execute it. This is an output/safety contract, not a suppression or a reason to widen architecture.

10. **`src/lib/domain/readinessRollup.ts:1` — public API contract**

    ```ts
    /** Aggregates already-classified facts for Critical Tasks. Callers own classification, exclusions and latest-record selection. */
    ```

    This module-level doc comment establishes caller ownership of fact construction for the shared exported tally APIs. `ReadinessFact` accepts opaque state/join keys; aggregation counts supplied facts and supplied state sets rather than resolving latest records or domain classifications. The checkpoint's production consumers are `critical-tasks/utils/ictReadinessSnapshot.ts` and `ictReports.ts`. The changed header accurately removes Training as a consumer while retaining the public input contract. Older unchanged field/function comments were not independently adjudicated.

## Suppressions, MUST KILL and constraints

- **Suppressions:** zero added/changed `eslint-disable`, TypeScript ignore/expect-error/nocheck, Prettier ignore, Svelte ignore, coverage ignore, Biome ignore or Stylelint disable directives in the scoped diff. No suppression survives by assumption, and no new rule required lookup. CSS `!important` declarations are not lint or TypeScript suppressions.
- **MUST KILL:** none. The two DELETE comments narrate intentional code. The protocol comment's narrow claim is foreign and proven. The request/detail behavior is an explicit authorized state contract. No reviewed comment demonstrates an internal workaround root that should be renamed, extracted, retyped or rearchitected.
- **Constraint commands:** no added/changed “IMPORTANT”, “do not remove”, “do not change wording”, “talk to X”, “too risky” or “fine for now” comment. No approval-dependent constraint encoding was proposed or performed.
- **Open/unverified:** no browser/runtime execution by this audit; the Puppeteer proof is pinned installed-source proof on the reachable production path, not a live cleanup observation. Remote IO-stream disposal after a close failure remains unproven and is not asserted by the retained comment. No print-renderer judgment, tests, services, database actions, network/connector calls, Git writes, source/test/doc edits or external actions were performed.
- **Disposition accounting:** 12 reviewed comment blocks; 2 DELETE recommendations; 10 proven-exception KEEP recommendations; 0 actual deletions; 0 restored comments; 0 rejected-report reruns; no architect sketch or implementation correction needed from this audit.

## No-comment files and skips

The other 23 changed files have no added/changed comment or suppression requiring disposition: helper `control.mjs`, `print-observation.mjs`, `print-observation.test.mjs`; verification `daemon.mjs`, `print-capture.test.mjs`; Training components `TrainingAffectedSoldiersSection.svelte`, `TrainingFocusSection.svelte`, `TrainingReportsPage.svelte`, `TrainingReportsPage.test.ts`, `TrainingTypeRiskSection.svelte`; Training `contracts.ts`, `index.ts`; read-model `trainingBriefingSession.svelte.test.ts`; server `trainingReportsQuery.server.test.ts`; utility `reportCalculations.test.ts`, `reportCalculations.ts`, `trainingBriefing.test.ts`; shared `BannerStack.svelte`, `TopHeader.svelte`; route `api/training-reports/server.test.ts`; and deleted `trainingReportScreenModel.test.ts`, `trainingReportScreenModel.ts`, `trainingReportWorkbook.test.ts`. URLs in added test strings and WebSocket strings are literals, not comment tokens.

This audit's sole write is `.verification/1504-comment-sicko-v1.md`. Root owns acceptance, deletion of the two recommended CSS comments and any final-candidate accounting. Claude retains exclusive visual/layout ownership.
