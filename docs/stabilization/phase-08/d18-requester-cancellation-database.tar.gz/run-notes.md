# D18 cancellation isolated database proof

Tested source: `07ee3ab8da809b27a4138d008f5b82d96e2cb231`, base `89c67e58754c7edb58d2d65318a871a85cc78212`. Frozen changed-file hashes are in `frozen-inputs.sha256`.

Command: `env PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH python3 scripts/ci/database.py`. Exit 0; original complete output retained in `database.log`, exit in `exit-code.txt`. Supabase CLI 2.101.0, PostgreSQL 17.6, Node 24.21.0.

Fresh project `t2t-ci-db-xy6a_h5h` replays all 165 migrations through `20261003000100_cancel_own_deletion_request.sql`, seed disabled. Standard database suites include 34 cancellation and 24 actual bounded-lock concurrency assertions; retained SQL and provider probes pass. Populated project `t2t-ci-db-cga012fx` replays 141 pre-held migrations, captures before witnesses, then applies all 24 held migrations. The new after suite passes 10 assertions, including exact pre-existing request/source/file metadata preservation and ordinary cancellation. Both are guarded disposable projects with unused ports in 58000–64999, exact owned cleanup successful; no existing local or remote database was targeted. The existing per-owned-stack supautils setting adjustment remains unchanged.

Local CodeRabbit CLI 0.8.2 reviewed all 24 committed text paths of this source revision against the stated base with zero findings; original output retained separately. This is source review, not database or browser acceptance.

The original log contains public disposable-local PostgreSQL password `postgres` and synthetic provider data, not real database credentials; no output outcome is truncated or redacted. Archive scanning and independent acceptance are recorded in the owning receipt.
