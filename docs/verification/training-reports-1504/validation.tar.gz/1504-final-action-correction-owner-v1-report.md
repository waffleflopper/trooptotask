# #1504 final action correction (owner v1)

Base HEAD `2aa7a2ea2ae0774d56d6594747fc27b4e2a69bb9`. The changes are uncommitted in three owned files. Nothing was committed, pushed, or run in a browser.

## Data and control shape

- `TrainingReportsPage.svelte` has one focus seam. `focusSection(id)` awaits `tick()` and then focuses a stable `tabindex=-1` region.
- After this change, it serves five explicit actions:
  - `openDetail` and `retryDetail` focus `DETAIL_ID`. These are unchanged.
  - `retryBriefing` focuses `BRIEFING_ID`. This is unchanged.
  - `clearFilters` now focuses `BRIEFING_ID`. Both the toolbar and no-requirements-panel Clear buttons call it.
  - `retryExport` now focuses `BRIEFING_ID`. Only the export error alert's `onRetry` uses it.
- The ordinary Export Excel button still calls `exportExcel` directly. Its focus behavior is unchanged, since that button stays mounted and only changes its label and disabled state.
- Nothing new was added beyond that: no state, refs, effects, labels, response-time autofocus, or shared alert/ReportWorkspace changes.

## Actor census and red reproduction

I reproduced the bug at the component boundary in `TrainingReportsPage.test.ts` before writing the fix. `red.log` is the run against the HEAD component; the tests and fixture are the new ones.

| Actor | Why its focused control vanishes | Red at HEAD |
|---|---|---|
| Toolbar Clear filters | `session.select(defaults)` makes `hasNonDefault` false, which unmounts the button | Fails at `:295` waiting for focus on the briefing region. `clear.isConnected === false` passes first. |
| No-requirements panel Clear filters (N3) | Same handler and same unmount | Same failure at `:295` |
| Export error Retry | `exportExcel` sets `exportError = null` synchronously, which unmounts the alert and its Retry | Fails at `:317`. `retry.isConnected === false` passes first. The export Retry problem is no longer only inferred from source. |

Each Clear case finds its button inside its own container: the `group` "Training report actions" or the `region` "Training readiness briefing". My first draft used a fixture that never rendered the empty panel. Its "panel" red was really hitting the toolbar button. I fixed the fixture to `isOptional: true` on CPR, which gives no columns and `today.percent === null`, and re-ran red at HEAD.

Each new test asserts three things. The control disconnects, focus is on the briefing while the request is pending, and focus is still there after the response arrives (report table rendered, or the workbook downloaded with no alert). I added no separate no-steal test. The existing `leaves focus where the user moved it while a retried refresh is loading` test already covers the shared seam's no-steal behavior, and a copy would duplicate it.

Test changes:
- `reportFor(input, types = [CPR])` gains an optional `types` parameter for the empty fixture.
- An `it.each` covers the two Clear controls.
- One test covers export Retry.

## N2: redundant Focus-link `__data.json` preload

I traced the cause in the local SvelteKit 2.61.1 source:
- `app.html` sets `<body data-sveltekit-preload-data="hover">`.
- `preload()` in `client.js` skips only when `get_page_key(current.url) === get_page_key(url)`, where the page key is pathname plus search.
- `replaceState` in `client.js` (around line 2481) calls `history.replaceState` but does not update `current.url`.
- So once the session rewrites the query, the link's `a.href` (`#training-affected-soldiers` resolved against the document URL) carries the new search, while `current.url` keeps the old one.
- The keys differ, and hovering the link triggers `_preload_data`, which is the extra `reports/__data.json` request.

The fix is `data-sveltekit-preload-data="off"` on the Focus link Button. Button spreads `restProps` onto its `<a>`.
- `get_router_options` resolves `'off'` to `PRELOAD_PRIORITIES.off = -1`, and `'off'` is in `valid_link_options['preload-data']`.
- `preload_code` is unset in the ancestry, so it also resolves to `off`.
- `href`, `onclick` (preventDefault then onOpen), `aria-current`, and `aria-describedby` are unchanged.
- The app-wide hover default is unchanged.

There is no unit assertion for this, as briefed. An attribute check would not prove router behavior.

Unresolved hypothesis for root's fresh driver to confirm: hovering, then clicking, a Focus link after a filter change should produce no `reports/__data.json` request and exactly one `detail` request. The same router mismatch could affect any other same-page `href` on this route after `replaceState`. The census found no other anchor-href actors, so I left that alone.

## Checks (offline, owned files only)

- `prettier --check` and `eslint` on the 3 files passed (`format-lint.log`).
- `vitest run src/features/training`: 35 files and 396 tests passed (`training-unit.log`). The page file is 24/24 (`green.log`).
- `svelte-check --threshold error`: 0 errors and 0 warnings (`svelte-check.log`).
- Diffs are in `source.diff` and `full.diff`.

Root still owns the full gates: `verify:app`, build, the full suite, and lint warnings repo-wide.

## For root before the fresh native launch

- Update the recipe and acceptance expectations:
  - Toolbar Clear, empty-panel Clear, and export-error Retry should each land focus on the "Training readiness briefing" region (not BODY) during loading and after the response.
  - The normal Export button keeps focus on itself.
  - Focus-link hover or click after a filter change should make no `__data.json` request.
- To reproduce export Retry natively, you need to force the export endpoint to fail (for example a 5xx). No helper for this is defined here.
- If export Retry fails again, the alert remounts and announces through `role="alert"`, and focus stays on the briefing region. I treated that as acceptable. The other option, refocusing the new alert, would need response-time autofocus, which the brief excludes.
- N1 (Tab to the first unchecked baseline) and N4 (Print button wrapping at 390px) are untouched, as directed.
