import current as x,json
r=x.loaded('group4-roster-b');assert x.names(r,'row')==['Collapse Foreign','Open SPC Foreign, Synthetic'];assert 'Add Person' not in x.names(r,'button')
r=x.loaded('group4-b-owner-ranks');b=[n.removeprefix('Show details for ') for n in x.names(r,'button') if n.startswith('Show details for ')];assert b==['SGT','SPC','PFC','VFY-ONLY-B']
(x.d.E/'group4-assertions.json').write_text(json.dumps({'status':'PASS','personnelAActiveRanks':['SGT','SPC','PFC','VFY-ACTIVE-A'],'trainingTargetingActiveRanks':['SGT','SPC','PFC','VFY-ACTIVE-A'],'ictActualPopulationOptions':['All Ranks','SPC'],'canonicalRosterSwitch':{'from':'A','to':'B','rows':['Collapse Foreign','Open SPC Foreign, Synthetic'],'addPersonAbsent':True},'separateBOwnerNativeCatalog':b,'limitations':['Separate B owner catalog is not same-client switched picker hydration.','Native B viewer picker UNRUN: Add Person absent.','Public nine-field rank response and captured-client factory proof belong to parent lower-boundary evidence.']},indent=2))
r=json.loads((x.d.E/'parent-restored-full.json').read_text())['rows'];print(list(r));
for n in ['counseling','document','follow','note']:
 row=json.loads((x.c/(n+'.json')).read_text());matches=[a for v in r.values() for a in v if a.get('id')==row['id']];assert len(matches)==1;print(n,matches[0])
