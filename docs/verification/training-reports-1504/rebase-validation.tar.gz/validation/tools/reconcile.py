import json,subprocess
base='ee1ca2b275d71cd0b9a51367b58c4754a687a443'
old='f5221ecdcf0dde3be595bccdaaa8f898b7153ca3'
main='66a238a8fe9915f5dd3994a7d5d62f71c71f7de8'
def tree(ref):
 out=subprocess.check_output(['git','ls-tree','-rz',ref]).split(b'\0')
 return {x.split(b'\t',1)[1].decode():x.split(b'\t',1)[0].decode() for x in out if x}
b,p,m,c=map(tree,[base,old,main,'HEAD'])
pr={f for f in b.keys()|p.keys() if b.get(f)!=p.get(f)}
incoming={f for f in b.keys()|m.keys() if b.get(f)!=m.get(f)}
report={'base':base,'old':old,'main':main,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'prOnlyDrift':[f for f in sorted(pr-incoming) if p.get(f)!=c.get(f)],'mainOnlyDrift':[f for f in sorted(incoming-pr) if m.get(f)!=c.get(f)],'shared':sorted(pr&incoming),'unexpected':[f for f in sorted(b.keys()|p.keys()|m.keys()|c.keys()) if f not in pr|incoming and b.get(f)!=c.get(f)]}
print(json.dumps(report,indent=2))
