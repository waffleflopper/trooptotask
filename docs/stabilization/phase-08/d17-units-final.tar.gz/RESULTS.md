# D17 final Units retirement and retained Groups

Frozen source `9c5fed846f84696637699fded650d121c3a18768`, fingerprint `e4864a5504a5aff58156a3d15a5208459e5fcf3217b757cd579ccb29138251a7`, session `ab68bfb6-3cf5-464f-8452-266bcfbf5265`, origin `http://127.0.0.1:44325`. Final native supervisor/app use Node24.21.0, npm11.19.0, Chromium152.0.7977.82. No remote/preexisting database or worker2 is touched. Per-command JSON records preserve argv, time, cwd, nonsecret overrides and exit. Native-step files retain fresh before/action/after snapshots for each visible action.

## Preserved environment failure

00-launch uses the resumed shell's Node26.8.2 and fails at adapter-vercel after compilation; 00-failed-build.log preserves the actual error. 01-failed-doctor reports phase/ownership blocked. 04-failed-cleanup succeeds before a distinct official 05-launch-node24. Explicit installed Node24 PATH selection is an environment correction, with no application/configuration change or guard bypass. The copied runner documents that later pin; original attempt command records remain unchanged. The successful launch and both doctors identify the same final source/digest. Documentation edits do not alter its application/fixture/recipe inputs; archives are added only after disposal.

## Native retained Group observations

Normal manager login creates page2 at Personnel. Original Groups are A Alpha/Bravo and B Foreign. Initial Manage Groups Add is disabled while empty. Visible Add creates `c73772fa-bd02-4eee-a8f6-82e41e34e0c7` named D17 Final Group0147. Closing/reloading/reopening retains it. Visible Edit/Save changes only its name to D17 Final Group0147 renamed; exact provider fields and ID match. Another reload/reopen retains that name. Visible Remove opens the named confirmation; explicit Remove succeeds and reload/reopen excludes it. Actual strings with spaces are retained in the snapshots/row captures.

Duplicate Alpha produces the useful in-dialog error, retains the input and original rowset. An exact101-character Z draft produces the <=100 validation and remains entered. Explicit valid retry creates temporary `8e8ff65f-6f9a-4a1f-bf7b-ea1e85056945`; visible confirmed removal succeeds. Final reload/reopen shows only original Groups. Screenshots groups-created.png and groups-validation.png preserve real UI appearance. No client/provider fault control or inaccessible handler is invented.

Normal viewer login on page3 has no Manage Groups button. Valid ordinary POST A returns403, valid foreign B POST returns404, and both unique-name provider reads have zero rows. This authenticated HTTP proof is distinct from the missing UI affordance.

## Effective catalog and retired endpoint

owned-catalog.py pins this session, revision, fingerprint, supervisor identity and marked owned DB, obtains a fresh PASS doctor and runs only fixed BEGIN READ ONLY / ROLLBACK metadata. The effective164-migration catalog has Groups/Organizations with RLS and no Units relation. No migration or remote/catalog application is performed.

Normal orgOwner login reaches page4 General; its snapshot identifies Owner access. Native evaluation submits ordinary authenticated POST, PUT and DELETE to A's retired endpoint using the harmless recorded synthetic UUID/name. Each returns404, with full public bodies captured. Original A/B Group and eleven-field Organization rowsets before and after compare exactly (by IDs, not incidental order). Created/renamed IDs and temporary absence are reconstructed in OBSERVATION_CHECKS.json. Catalog/readback/HTTP proof is separate from native CRUD. External clients, hosted telemetry and hosted schema remain uninspected.

## Restoration and disposal

Only UI-created Groups were mutated, and both are removed. All captured original Group and Organization values match; no helper seed or response/download hook was armed. clean-seeds succeeds. Final doctor exactly matches start. Official cleanup succeeds. Fresh read-only inventory on the same verified local Docker socket proves all five original container IDs and exact-project current/stopped containers absent; all four PID/start identities are absent, all ten saved app/control/provider ports bind, and private worker metadata is absent at2026-10-03T01:57:21.038831Z. Evidence survives cleanup. This is local execution by root, not independent live execution; independent acceptance reviews the expanded artifacts separately.

## Sanitization

The three authenticated 404 HTML bodies serialize the requesting synthetic session. In58-units-requests.stdout, three access-token and three refresh-token occurrences are replaced with named redaction markers. Method, path, submitted body, status and all remaining response observations are preserved. The original is private and not published; sanitized payload hashes are inventoried.
