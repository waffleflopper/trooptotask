# D28 completion persistence comment review

Independent read-only Comment Sicko review. Generic portable-profile fallback. No nested workers, application edits, tests, services, database access, network calls or connectors. Only this report was written.

## Candidate and scope

Base commit `66a238a8fe9915f5dd3994a7d5d62f71c71f7de8`. Root HEAD `a53ed80438700da863bcba1eac1d2002511caa51`.
Full current text of 40 retained changed source/test files was scanned. Comment-bearing code was read in context. Deleted PersonnelIctCompletionEntity source/test files were checked through the diff. Renamed persistence test helper was checked under its current name. Working manifest `scripts/module-boundaries.json` was read, including `testSupportFiles`. The final working memory completion adapter uses local `CompletionMemoryStore` instead of the private Delivery DataStore import. Offline source driver `owner-offline/run-faults.py` was read but never run.

## Result

No added or changed comment text. The existing diff removes six comment ranges totaling eight source lines along with moved or deleted implementations. No restoration recommended.

Nine further deletion ranges totaling 15 source lines occur in affected Critical Tasks source/tests. All candidates predate this change. Eight ranges remove full narration comments. One removes the separate history-test narration line while preserving its preceding SQL constraint sentence.

MUST KILL flags `0`. No scoped correctness or safety suppression. No workaround requiring a shape change. No IMPORTANT, do-not-remove or similar claim requiring how/why escalation. No implementation should be reshaped solely for the narration candidates below.

## Deletion candidates

| File and current lines | Exact text | Reason |
| --- | --- | --- |
| `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.test.ts` line 242 | `Apply the requested order after changing only that incidental input order.` | Narrates rows.sort. Preserve line 241 about SQL equal-key ordering. |
| `src/features/critical-tasks/server/criticalTasksReadModel.server.test.ts` line 58 | `A full terminal page needs one empty read; the short page stops immediately.` | Narrates the cases and servedOffsets assertion. The owned pagination helper visibly stops on a short page. |
| `src/features/critical-tasks/server/criticalTasksReportsQuery.server.test.ts` lines 888-889 | `Each pair has 1001 distinct dates. The 150-task case leaves three` / `history windows; the 151-Person case fills four with 151151 rows.` | Fixture arithmetic is expressed by dates, personCount and taskCount. |
| Same reports test lines 906-907 | `Cache the immutable fixture selection per provider query, so paging` / `doesn't repeatedly scan/sort 150k stored captures inside this fake.` | Narrates selections Map and get/set. This intentional cache is obvious locally and is not flagged for removal or reshape. |
| Same reports test lines 952-953 | `All pairs are ready in January, expired in February, and restored` / `by their March capture; the old 2020–2022 dates cannot supply readiness.` | Fixture and explicit readinessTrend expectations express the behavior. |
| Same reports test line 1016 | `Distinct older dates obey the Person/task/date uniqueness constraint.` | Narrates date construction. Our data contract and fixture are not a foreign constraint exception. |
| Same reports test lines 1048-1049 | `A January 1 capture is ready in January, expired in February; the` / `March 15 capture restores readiness in March for this one-month task.` | Repeats dates, expiration_months and explicit expected trend. |
| `src/features/critical-tasks/server/ictCompletionsBatch.server.test.ts` lines 71-72 | `A finite request-line budget is independent of the lookup's chunk size.` / `Native owned-provider verification separately proves the real deployment.` | The fake enforces its budget. The second line narrates evidence elsewhere. This comment proves no exact vendor requirement for 8192 bytes. |
| `src/features/critical-tasks/server/ictCompletionsBatch.server.ts` lines 61-62 | `First pass resolves only valid personnel/task references so we can scope access checks` / `and the existing-completion lookup without loading unrelated completion history.` | preliminaryReview, matchedPersonnelIds, authorization loop and matchedPairs express the sequence. No reshape needed. |

## Kept exceptions and proof

- `src/features/critical-tasks/contracts.ts` line 6. Public API contract on exported CriticalTasksPageAccess. It distinguishes advisory UI affordances from server enforcement. The signature returns allowed/visible; server completion operations require policy decisions.
- `src/features/critical-tasks/server/personnelCriticalTasksReadiness.server.ts` line 19. Public function input precondition on loadAuthorizedPerson. loadCriticalTasksReadinessLane awaits this callback before owned reads. The Personnel route supplies loadPersonnelForLane with Critical Tasks readiness action and personnel_ict_completion resource.
- Same readiness file line 26. Public API contract on exported loadCriticalTasksReadinessLane, also exported through index.server.ts. It states which side performs admission. The callback sequence and owning reads support it.
- `src/lib/server/adapters/inMemory.ts` lines 2-13. Existing public test API documentation. createInMemoryDataStore exposes seed, filtering, sorting and paging. createScopedTestStores uses auth.scopeSet for group scoping. Context builders invoke criticalTasksReadModelFactory. Keep this intended contract. No related implementation is flagged.
- `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.test.ts` line 241. `SQL may return equal sort keys in a different order for each request.` External SQL ordering constraint modeled by the fake. There are 1001 same-date captures. The fake varies incidental order before applying requested keys. The provider supplies completed_at plus unique id ordering. Keep this sentence and remove only the separate following narration line.
- `src/features/critical-tasks/server/criticalTasksReportsQuery.server.test.ts` lines 1028-1029. External SQL ordering constraint modeled by the paged fake. The fake reverses incidental order then applies requested keys. The report provider orders by unique id, preventing omitted older captures and preserving the explicit January/March trend. This protects against an external constraint and is not a workaround in our provider.

Proof above is local source analysis. This review did not independently execute a live external provider.

## Suppression audit

Searched all 40 retained changed source/test files, working manifest and offline driver for eslint-disable and related eslint markers, ts-ignore, ts-expect-error, ts-nocheck, tslint, noinspection, type-ignore/noqa/pyright, coverage-ignore and prettier-ignore directives. Found `0`. No rule lookup was needed because no scoped suppression exists. Python tokenization confirms the offline driver has `0` comments. URL literals containing // are not comments.

## Skips

- `src/lib/server/adapters/inMemory.ts` line 285. Existing SQL LIKE conversion comment in global filtering, unrelated to completion binding changes.
- Same file line 1054. Private Organization settings reader comment, unrelated to completion work.
- Same file line 1268. Existing StoragePort upload comment, unrelated to completion work.
- `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts` line 73. Existing Personnel artifact orchestration comment, outside the changed Critical Tasks readiness binding.
- Deleted personnelIctCompletionEntity.server.ts and test have no retained source.
- Manifest entries for unchanged Task library synthetic support were checked as declaration context. They do not widen review to unrelated implementation.
- Root docs and archived evidence payloads. No prose expansion or artifact-content cleanup requested.

Reviewer deletion count `0`. No application edits. No rerun or architect sketch required. No encoding offer, encoding or unenforced constraint found.

## Read manifest

These hashes identify source/test text and additional scoped inputs when this report was saved.

| File | SHA-256 |
| --- | --- |
| `src/features/critical-tasks/contracts.ts` | `5433d9eb36d86354ac784c6aaeed26879f2726a9d6c99a9a08e1c282a4ed6c97` |
| `src/features/critical-tasks/index.server.ts` | `99a2bda32d0a23c24f85ad0252a76421f17a21c79a75ca365dc981bf055d6c9f` |
| `src/features/critical-tasks/server/criticalTaskCompletionPersistence.server.test.ts` | `2aa6d5bfca2ec0bf9bb8a4fb8db6114b06fc2951590d1380072b19f7cafe9e95` |
| `src/features/critical-tasks/server/criticalTaskCompletionPersistence.server.ts` | `0378e771d1579ccd3b5c32054d1707b881749257fb7cf9e35c37ce2726a090fa` |
| `src/features/critical-tasks/server/criticalTaskLibraryPersistence.server.test.ts` | `fd27f70b246ece5e9b4b610f0098d3d1d9bbd311569f449e8ee1e676c142d7f0` |
| `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.test.ts` | `917cd2a32ca3c342214c9b71c9702c92828eadda09e330b8731b98f393a8a394` |
| `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.ts` | `4a9e94b0bc70d1fbcfa969cd413e4cfab0289ac202fc0ba47b5f7db26e3e5f1f` |
| `src/features/critical-tasks/server/criticalTasksPersistence.test-support.server.ts` | `328b4fb715708c04dc6338f3f51803f21511ba04e1e99e9f598dedc2f4eeb27d` |
| `src/features/critical-tasks/server/criticalTasksReadModel.server.test.ts` | `fbf70a71c7b604cb4b0b855acc22c096cef764143e0f60526d4d73e5ad7cf18c` |
| `src/features/critical-tasks/server/criticalTasksReadModel.server.ts` | `14dee754401534343882bc3da698a092c85792cc265ea0c28f805a161b433879` |
| `src/features/critical-tasks/server/criticalTasksReadPorts.server.ts` | `e26b25580d4c3238668f9d57403c1a288881adec7f6ac23ceb41da94c59d1a98` |
| `src/features/critical-tasks/server/criticalTasksReportsQuery.server.test.ts` | `253005416ec1b22dd3db8e3731d94f50814338774fafa16393d85d5be0deece7` |
| `src/features/critical-tasks/server/criticalTasksReportsQuery.server.ts` | `e22b05b43c188aaad7f9047d58d8fe8795093d5476447ddd44be70ed28cbe07d` |
| `src/features/critical-tasks/server/criticalTasksWorkspaceQuery.server.test.ts` | `ced856f3f6e9d50bf3dca94c497c5ca7ba711decc02dc38e5823c5c4e25e1105` |
| `src/features/critical-tasks/server/ictCompletionsBatch.server.test.ts` | `7063a722647e37280d0c58a4854d3c326ef1ea091f826a491143d01aff8d7993` |
| `src/features/critical-tasks/server/ictCompletionsBatch.server.ts` | `3526afffd19ed9e7b4c2047d38f6fb5cad67bcd0095085a6550e8495f3080af9` |
| `src/features/critical-tasks/server/ictTaskOperations.server.test.ts` | `17ea6ef64aae00bf2b49c80a608b130ff55fbdfb22a74743a7c49a9f894dade0` |
| `src/features/critical-tasks/server/ictTasksBatch.server.test.ts` | `01d34a4eb3a1c188c10a80523c6e59c3da9653d64674a763fb478d60177920ac` |
| `src/features/critical-tasks/server/inMemoryCriticalTaskCompletion.server.ts` | `f0772a3a12f47dff6ffa2328f23b342bcd6dabd7a7aa16ac08f1aec4851a9020` |
| `src/features/critical-tasks/server/inMemoryCriticalTasksReadModel.server.test.ts` | `6c93cce623390de32aa5d3b6c607b3b034b8530cbde16c38e2322fb714a5e103` |
| `src/features/critical-tasks/server/inMemoryCriticalTasksReadModel.server.ts` | `807d28b3a27900dc9116c897c4121b06d01ab8c971b03fb07f83070e024ac7b1` |
| `src/features/critical-tasks/server/personnelCriticalTasksReadiness.server.test.ts` | `9878d8e52125e5a7f83a806391670c6ec8d73c8f90fd3725cc4dc36f0498e992` |
| `src/features/critical-tasks/server/personnelCriticalTasksReadiness.server.ts` | `9acf468d6d3b6ac9603e3611de06b7ede4561a4ff8fbd57767a153ebce29879c` |
| `src/features/critical-tasks/server/personnelIctCompletionMapping.server.test.ts` | `e61a3646edd47375c41740340bae527590541e267dee92cfa62d9d876d0270ee` |
| `src/features/critical-tasks/server/personnelIctCompletionMapping.server.ts` | `d9a1547fdd18a9b6b7c9d24c00ad863fc9fe1757a3526727cf63d464bd455c7c` |
| `src/features/critical-tasks/server/personnelIctCompletionOperations.server.test.ts` | `84cfe7055115a87c1409d9b2470aa06b3308e41f09b14b52bb67529c3cbbc201` |
| `src/features/critical-tasks/server/personnelIctCompletionOperations.server.ts` | `ed891cef53c643d14ebaa348096a164f80751b187487a9428f553ee294612927` |
| `src/features/critical-tasks/server/personnelIctCompletionPorts.server.ts` | `e96d644e58db63caa5a1462efd7faf16dc54e392bd13bd0f80924f5599876f04` |
| `src/lib/server/adapters/dashboardRequestContext.server.test.ts` | `58ea78a60490219e2e64edaa06444595524f904dacf2e9b87b3f69741b3616e1` |
| `src/lib/server/adapters/featureRequestContexts.server.ts` | `c370ba776e6c0c60bfc83474f82db5aba8a0bf8b2c33693296cc7bc627a6ad61` |
| `src/lib/server/adapters/inMemory.ts` | `8d0015f3afce327241424be1746a12af7b8bb5f30bf51cea9626d0f6c8a4d0f0` |
| `src/lib/server/adapters/personnelCriticalTasksRequestContext.server.test.ts` | `f3126029a0ea73e530706a1fa53345b8858c54ce03b1fc3e61f4a285d94cccd7` |
| `src/lib/server/adapters/requestContexts.server.ts` | `a6bdc39373d56a922cb64f566675ca8b39732ecf4711f7990bdc40f48752e936` |
| `src/routes/org/[orgId]/api/critical-tasks/matrix/export/server.test.ts` | `0f477d640dbc80394e91945830f6f774a2abefdf5a4b4fcfc2d6b725d645de0f` |
| `src/routes/org/[orgId]/api/critical-tasks/reports/export/server.test.ts` | `88d2e7642fc8e8fa14cf4c3b2df56d6be5444702684435ceff7db39f48af4aca` |
| `src/routes/org/[orgId]/api/critical-tasks/reports/summary/server.test.ts` | `a41cad7cdffbbd570f6608f5de5998f65eddb9974d5589e2ca7839a7790bdfd9` |
| `src/routes/org/[orgId]/api/personnel-ict-completions/batch/server.test.ts` | `79b8d8f8f1848e9865c09dbfa86e91eb4c50c4bcf24df1a1aabf286fde658486` |
| `src/routes/org/[orgId]/api/personnel-ict-completions/server.test.ts` | `4095f799742e95f19ddb17fc3f193c7ba483e3423b938d5b2a6eb1fc32f327c0` |
| `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts` | `2912af330648934458041c5ef448c5db75cb111d68cf3d2055d4ee53a31985ef` |
| `src/routes/org/[orgId]/personnel/[personnelSlug]/page.server.test.ts` | `547c878c0a014bce3d80f7d333cc5c4f34ed9d7ea1c21278fcb0870c59f2ba91` |
| `scripts/module-boundaries.json` | `e953329b739cd3095275a73029701923edeb49ed86a5770c9402b2db909490b5` |
| `.verification/evidence/verify-trooptotask/d28-critical-task-completion-final/owner-offline/run-faults.py` | `f86e0a0a6ede5481d664a9dbb7e945f03918e779595796b526e6cb8605d2360c` |
