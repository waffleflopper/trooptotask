import sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'd15-overlap'))
from drive import *
from overlap import ordinary

TABLES = ['personnel_onboardings', 'onboarding_step_progress', 'personnel_trainings']

class ObservedFailure(Exception):
    pass

def require(condition, observation):
    if not condition:
        raise ObservedFailure(observation)

def saved_rows(tag):
    return {(org, table): control(['rows', table, org], tag + '-' + table + '-' + org)['rows']
            for org in ['orgA', 'orgB'] for table in TABLES}

def compare_rows(before, after, packet=None):
    problems = []
    for key, rows in before.items():
        old = {row['id']: row for row in rows}
        new = {row['id']: row for row in after[key]}
        if old.keys() != new.keys():
            problems.append({'table': list(key), 'problem': 'Row identities changed'})
        for record_id, row in old.items():
            if record_id not in new:
                continue
            allowed = {'status', 'completed_at', 'cancelled_at'} if key == ('orgA', 'personnel_onboardings') and record_id == packet else set()
            if {k: v for k, v in row.items() if k not in allowed} != {k: v for k, v in new[record_id].items() if k not in allowed}:
                problems.append({'table': list(key), 'id': record_id, 'problem': 'Unexpected captured field changed'})
    return problems

def parent_rows(seed, tag):
    packet = seed['packets'][0]['id']
    parents = control(['rows', 'personnel_onboardings', 'orgA', 'id', packet], tag + '-parent')['rows']
    progress = control(['rows', 'onboarding_step_progress', 'orgA', 'onboarding_id', packet], tag + '-progress')['rows']
    assert len(parents) == 1 and len(progress) == 3
    return parents[0], progress

def terminal(parent, expected):
    require(parent['status'] == expected, parent)
    require(bool(parent['cancelled_at']) == (expected == 'cancelled'), parent)
    require(bool(parent['completed_at']) == (expected == 'completed'), parent)

def history(seed, expected, tag):
    receipt = E / 'lifecycle-native-history-actor.json'
    reused = receipt.exists()
    if reused:
        assert receipt.resolve() == receipt and receipt.is_file()
        actor = json.loads(receipt.read_text())
        fixture = json.loads((E / 'fixture.json').read_text())
        launch = json.loads((E / 'launch.json').read_text())
        assert actor['role'] == 'onboardingView' and actor['orgId'] == fixture['ids']['orgA']
        assert actor['origin'] == launch['origin'] and actor['path'] == '/org/' + fixture['ids']['orgA'] + '/onboarding/history'
        page = actor['pageId']
        assert isinstance(page, int) and page > 0
        write(E / (tag + '-reused-actor.json'), json.dumps({'pageId': page, 'receipt': receipt.name,
            'role': actor['role'], 'browserContext': actor['browserContext'], 'reason': 'Reload the already normally signed-in native History page; avoid redundant login attempts.'}, indent=2) + '\n')
    else:
        page = control(['actor', 'onboardingView', 'onboarding/history'], tag + '-actor')['pageId']
    summaries = []
    for iteration in ['first', 'reloaded']:
        prefix = tag + '-' + iteration
        if iteration == 'reloaded' or reused:
            native('navigate_page', {'pageId': page, 'type': 'reload'}, prefix + '-reload')
        snapshot = snap(page, prefix + '-before')
        matches = [line for line in snapshot.splitlines() if ' button ' in line and seed['person']['last_name'] in line]
        assert len(matches) == 1, matches
        summary = matches[0]
        text = summary.casefold()
        require(expected in text, summary)
        require(('completed ' in text) == (expected == 'completed'), summary)
        require(('cancelled ' in text) == (expected == 'cancelled'), summary)
        summaries.append(summary)
        if not re.search(r'\bexpanded\b', summary):
            click(page, re.search(r'uid=(\S+)', summary)[1], prefix + '-open')
        opened = snap(page, prefix + '-opened')
        require('Orientation' in opened and 'Paperwork' in opened and 'Historic task' in opened, opened)
        require('Reviewed' in opened, opened)
        screen(page, prefix)
    write(E / (tag + '-outcome.json'), json.dumps({'result': 'PASS', 'role': 'onboardingView', 'expected': expected,
        'scope': 'Native saved History summary has its matching terminal date and no opposite date, retained work and reload',
        'summaries': summaries, 'apiSetupIsSeparate': True}, indent=2) + '\n')

def button(snapshot, label, dialog=None):
    lines = snapshot.splitlines()
    if dialog:
        starts = [i for i, line in enumerate(lines) if 'alertdialog "' + dialog + '"' in line]
        assert len(starts) == 1, {'dialog': dialog, 'starts': starts, 'snapshot': snapshot}
        start = starts[0]
        indent = len(lines[start]) - len(lines[start].lstrip())
        end = next((i for i in range(start + 1, len(lines)) if len(lines[i]) - len(lines[i].lstrip()) <= indent), len(lines))
        lines = lines[start + 1:end]
    matches = [line for line in lines if 'button "' + label + '"' in line and 'disabled' not in line]
    assert len(matches) == 1, {'label': label, 'matches': matches, 'dialog': dialog}
    return re.search(r'uid=(\S+)', matches[0])[1]

def observe_done(page, tag):
    states = []
    for attempt in range(12):
        state = control(['network', 'state', str(page)], tag + '-network-state-' + str(attempt))
        states.append(state)
        if state.get('calls') and all(call['status'] is not None for call in state['calls']):
            require(len(state['calls']) == 1 and state['calls'][0]['method'] == 'PUT' and state['calls'][0]['status'] == 200, state)
            return state
        time.sleep(0.5)
    raise RuntimeError({'reason': 'Native request did not finish with one ordinary 200', 'states': states})

def native_transition(seed, expected, tag, actor_receipt=None):
    if actor_receipt is None:
        page = control(['actor', 'onboardingOperate', 'onboarding'], tag + '-actor')['pageId']
    else:
        assert actor_receipt == 'sequential-reopened-native-actor.json'
        receipt = E / actor_receipt
        assert receipt.resolve() == receipt and receipt.is_file()
        actor = json.loads(receipt.read_text())
        fixture = json.loads((E / 'fixture.json').read_text())
        launch = json.loads((E / 'launch.json').read_text())
        assert actor['role'] == 'onboardingOperate' and actor['orgId'] == fixture['ids']['orgA']
        assert actor['origin'] == launch['origin'] and actor['path'] == '/org/' + fixture['ids']['orgA'] + '/onboarding'
        page = actor['pageId']
        assert isinstance(page, int) and page > 0
        write(E / (tag + '-reused-actor.json'), json.dumps({'pageId': page, 'receipt': actor_receipt,
            'role': actor['role'], 'browserContext': actor['browserContext'], 'reason': 'Use the already normally signed-in and reloaded native packet page; avoid redundant login attempts without weakening ordinary admission.'}, indent=2) + '\n')
    control(['network', 'arm-observe', str(page), 'onboarding'], tag + '-network-arm')
    armed = True
    try:
        snapshot = snap(page, tag + '-card')
        line = [line for line in snapshot.splitlines() if ' button ' in line and seed['person']['last_name'] in line]
        assert len(line) == 1, line
        click(page, re.search(r'uid=(\S+)', line[0])[1], tag + '-open-detail')
        snapshot = snap(page, tag + '-detail')
        label, title, confirm = ('Cancel', 'Cancel Onboarding', 'Cancel Onboarding') if expected == 'cancelled' else ('Mark Complete', 'Complete Onboarding', 'Mark Complete')
        click(page, button(snapshot, label), tag + '-open-confirmation')
        snapshot = snap(page, tag + '-confirmation')
        assert 'alertdialog "' + title + '"' in snapshot, snapshot
        if expected == 'completed':
            require(re.search(r'1 step.*incomplete', snapshot), snapshot)
        screen(page, tag + '-confirmation')
        # First dismiss the real confirmation and establish no request/no saved effect.
        before = parent_rows(seed, tag + '-before-dismiss')
        click(page, button(snapshot, 'Cancel', title), tag + '-dismiss')
        state = control(['network', 'state', str(page)], tag + '-dismiss-network-state')
        require(state['calls'] == [], state)
        require(parent_rows(seed, tag + '-after-dismiss') == before, 'Dismissed confirmation changed saved parent/progress')
        snapshot = snap(page, tag + '-detail-again')
        click(page, button(snapshot, label), tag + '-reopen-confirmation')
        snapshot = snap(page, tag + '-confirmation-again')
        click(page, button(snapshot, confirm, title), tag + '-confirm')
        network = observe_done(page, tag)
        snapshot = snap(page, tag + '-after')
        screen(page, tag + '-after')
        parent, progress = parent_rows(seed, tag + '-saved')
        terminal(parent, expected)
        require(progress == before[1], 'Saved step work/notes/timestamps changed')
        restored = control(['network', 'restore', str(page)], tag + '-network-restore')
        assert restored['restored'] is True, restored
        absent = control(['network', 'state', str(page)], tag + '-network-absent')
        assert absent == {'armed': False, 'calls': [], 'held': False}, absent
        armed = False
        native('navigate_page', {'pageId': page, 'type': 'reload'}, tag + '-active-page-reload')
        snapshot = snap(page, tag + '-active-page-reloaded')
        require(seed['person']['last_name'] not in snapshot, snapshot)
        screen(page, tag + '-active-page-reloaded')
        write(E / (tag + '-outcome.json'), json.dumps({'result': 'PASS', 'expected': expected, 'nativeRequest': network,
            'parent': parent, 'confirmationDismissalNoRequestOrSavedChange': True,
            'progressWorkNotesAndTimestampsRetained': True, 'activeCardAbsentAfterReload': True}, indent=2) + '\n')
        return parent
    finally:
        if armed:
            restored = control(['network', 'restore', str(page)], tag + '-error-network-restore')
            assert restored['restored'] is True, restored
            absent = control(['network', 'state', str(page)], tag + '-error-network-absent')
            assert absent == {'armed': False, 'calls': [], 'held': False}, absent
