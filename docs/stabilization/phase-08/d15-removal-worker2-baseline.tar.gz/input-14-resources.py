"""Read-only exact worker-2 resources before/after supported owned cleanup."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import urlsplit
from drive import ROOT, E, save


def main(mode):
    spec = importlib.util.spec_from_file_location("owned_environment", ROOT / "scripts/verification/environment.py")
    environment = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(environment)
    expected = (Path.home() / ".local/state/trooptotask-verification"
                / hashlib.sha256(str(ROOT).encode()).hexdigest()[:16] / "worker-2")
    calls = []
    if mode == "before":
        environment.private_session(expected)
        state, workdir, clean = environment.owned(expected)
        assert state["repository"] == str(ROOT)
        worker = json.loads((expected / "session.json").read_text())
        assert worker["repository"] == str(ROOT) and worker["worker"] == "2" and worker["phase"] == "running"
        status = environment.status(expected)
        assert status["status"] == "PASS" and status["project"] == state["project"]
        records = environment.containers(state, workdir, clean)
        public = {"worker": "2", "repository": str(ROOT), "sessionDirectory": str(expected), "sessionId": worker["id"],
                  "project": state["project"], "DOCKER_HOST": clean["DOCKER_HOST"], "status": status,
                  "configSha256": state["config_sha256"], "candidate": worker["candidate"],
                  "containers": [{"id": row["Id"], "name": row["Name"].lstrip("/"),
                                  "supabaseProject": row["Config"]["Labels"]["com.supabase.cli.project"],
                                  "composeProject": row["Config"]["Labels"]["com.docker.compose.project"]} for row in records]}
    else:
        public = json.loads((E / "resources-before.json").read_text())
        assert public["worker"] == "2" and public["repository"] == str(ROOT) and public["sessionDirectory"] == str(expected)
        assert not expected.exists() and json.loads((E / "owned-disposal-stdout.json").read_text())["status"] == "PASS"
        clean = environment.load_database(ROOT).clean_environment()
        for key in ("DOCKER_CONTEXT", "DOCKER_TLS_VERIFY", "DOCKER_CERT_PATH"):
            clean.pop(key, None)
        endpoint = urlsplit(public["DOCKER_HOST"])
        assert endpoint.scheme == "unix" and not endpoint.netloc and endpoint.path.startswith("/")
        clean["DOCKER_HOST"] = public["DOCKER_HOST"]

    def docker(arguments):
        result = subprocess.run(["docker", *arguments], cwd=ROOT, env=clean, capture_output=True, text=True, timeout=30)
        calls.append({"command": ["docker", *arguments], "exitCode": result.returncode,
                      "stdout": result.stdout, "stderr": result.stderr})
        save("resources-" + mode + "-command-" + str(len(calls)).zfill(2) + ".json", calls[-1])
        assert result.returncode == 0, "Inventory unavailable, never infer absence"
        return result.stdout.splitlines()

    project = public["project"]
    assert re.fullmatch(r"t2t-verify-[0-9a-f]{24}", project)
    containers = docker(["ps", "--all", "--no-trunc", "--filter", "name=t2t-verify-", "--format", "{{.ID}} {{.Names}}"])
    volumes = docker(["volume", "ls", "--filter", "name=t2t-verify-", "--format", "{{.Name}}"])
    networks = docker(["network", "ls", "--no-trunc", "--filter", "name=t2t-verify-", "--format", "{{.ID}} {{.Name}}"])
    exact_containers = [line for line in containers if line.split(" ", 1)[1].endswith("_" + project)]
    exact_volumes = [name for name in volumes if name.endswith("_" + project)]
    exact_networks = [line for line in networks if line.split(" ", 1)[1].endswith("_" + project)]
    if mode == "before":
        assert {line.split(" ", 1)[0] for line in exact_containers} == {row["id"] for row in public["containers"]}
        assert len(exact_containers) == 5 and len(exact_volumes) == 2 and len(exact_networks) == 1
        public.update(volumeNames=exact_volumes,
                      networks=[{"id": line.split(" ", 1)[0], "name": line.split(" ", 1)[1]} for line in exact_networks])
    else:
        all_ids = docker(["ps", "--all", "--no-trunc", "--format", "{{.ID}}"])
        all_volumes = docker(["volume", "ls", "--format", "{{.Name}}"])
        all_network_ids = docker(["network", "ls", "--no-trunc", "--format", "{{.ID}}"])
        remaining_ids = [row["id"] for row in public["containers"] if row["id"] in all_ids]
        remaining_volumes = [name for name in public["volumeNames"] if name in all_volumes]
        remaining_networks = [row["id"] for row in public["networks"] if row["id"] in all_network_ids]
        public = {"worker": "2", "repository": str(ROOT), "project": project,
                  "privateDirectoryAbsent": not expected.exists(), "exactContainerIdMatches": remaining_ids,
                  "exactVolumeNameMatches": remaining_volumes, "exactNetworkIdMatches": remaining_networks,
                  "exactProjectContainerMatches": exact_containers, "exactProjectVolumeMatches": exact_volumes,
                  "exactProjectNetworkMatches": exact_networks}
        absent = not any((remaining_ids, remaining_volumes, remaining_networks, exact_containers, exact_volumes, exact_networks))
        public["status"] = "PASS" if absent else "FAIL"
    suffix = re.compile(r"(?:^|_)t2t-verify-[0-9a-f]{24}$")
    public.update({"dockerCommands": calls, "capturedUtc": datetime.now(timezone.utc).isoformat(),
                   "namespaceFilterDefinition": {"nativeFilter": "name=t2t-verify-; superset of permitted projects",
                     "suffixRegex": suffix.pattern, "containersAndNetworks": "second field after full ID",
                     "volumes": "complete returned name", "exactResourceAbsence": "all full IDs/names, irrespective of renamed project"},
                   "allVerificationNamespace": {"containers": [line for line in containers if suffix.search(line.split(" ", 1)[1])],
                     "volumes": [name for name in volumes if suffix.search(name)],
                     "networks": [line for line in networks if suffix.search(line.split(" ", 1)[1])]},
                   "otherOwnedWorkersMayStillBeRunning": True})
    save("resources-" + mode + ".json", public)
    status = public["status"]["status"] if isinstance(public["status"], dict) else public["status"]
    assert status == "PASS", "Exact owned resources remain"
    print(json.dumps({"mode": mode, "worker": "2", "project": project, "status": "PASS"}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("before", "after"))
    main(parser.parse_args().mode)
