SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('unused',NOT EXISTS(SELECT 1 FROM pg_stat_activity WHERE application_name='t2t-d15-removal-67ea4e789df0467085a15fae95983ac4'));
