import json,subprocess,hashlib
from pathlib import Path
from flow import call,tool,snapshot,shot,base
from http import ack,PERSON
TABLES=['personnel','personnel_extended_info','groups','organization_rank_catalog','leader_notes','counseling_records','personnel_documents','personnel_follow_ups','personnel_trainings','personnel_ict_completions','availability_entries','rating_scheme_entries']
seed=json.loads((base/'seed-lifecycle.json').read_text());page=json.loads((base/'owner-page.json').read_text())['pageId'];checks=[]
for key in ['person','duplicateBravo']:
 assert ack('tail-ack-clear-'+key,page,person=seed['ids'][key],value=False)['status']==200
call('tail-network-state','control','network','state',str(page));call('tail-network-restore','control','network','restore',str(page));call('tail-feedback-restore','control','feedback','restore',str(page))
for org in ['orgA','orgB']:
 for t in TABLES:
  a=call('before-cleanup-'+org+'-'+t,'control','rows',t,org)['rows'];b=json.loads((base/('before-'+org+'-'+t+'.json')).read_text())['rows'];index={r['id']:r for r in a}
  for r in b:assert index[r['id']]==r,(org,t,r['id'])
  checks.append({'phase':'before-cleanup','organization':org,'table':t,'originalRowCount':len(b),'allOriginalRowsLiteralExact':True})
initialPerson=next(r for r in json.loads((base/'early-empty-denied-before-orgA-personnel.json').read_text())['rows'] if r['id']==PERSON)
currentPerson=next(r for r in json.loads((base/'before-cleanup-orgA-personnel.json').read_text())['rows'] if r['id']==PERSON);assert initialPerson==currentPerson
records=call('successful-audit-records','control','rows','audit_logs','orgA')['rows'];actions={r['action'] for r in records if r.get('resource_id')==PERSON}
required={'personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared'};assert required<=actions
(base/'audit-and-original-row-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'dedicatedPersonAllFieldsLiteralExact':True,'successfulActions':sorted(required),'failureDeniedLimits':'Actual same-row503/deniedcases separatelycompare successaudit rows; no partial-provider failure claim.'},indent=2)+'\n')
call('final-doctor-before-seed-cleanup','app','doctor');cleanup=call('clean-recorded-seeds','control','clean-seeds')
for org in ['orgA','orgB']:
 for t in TABLES:
  a=call('after-cleanup-'+org+'-'+t,'control','rows',t,org)['rows'];b=json.loads((base/('before-'+org+'-'+t+'.json')).read_text())['rows'];assert a==b,(org,t)
  assert not(set(seed['ids'].values())&{r['id'] for r in a})
  checks.append({'phase':'after-cleanup','organization':org,'table':t,'originalRowCount':len(b),'wholeCollectionLiteralExact':True,'seedIDsAbsent':True})
(base/'all-cleanup-row-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'seedIDs':seed['ids'],'SDSRowsAfterCleanup':[],'boundary':'Actual maintainedprovider readbacks and legitimate parentcascade of server-createdSDS rows; no manualDB reset/repair.'},indent=2)+'\n')
tool('tail-native-roster-reload','navigate_page',{'pageId':page,'type':'reload'});s=snapshot('tail-native-original-roster',page);shot('tail-native-original-roster',page);assert seed['name'] not in s and 'Able, Synthetic' in s and 'Baker, Synthetic' in s
call('final-doctor-after-seed-cleanup','app','doctor')
info=json.loads((base/'info.json').read_text());state=json.loads((Path(info['session'])/'session.json').read_text());public={k:{x:v for x,v in state.get(k,{}).items() if x in ['pid','start','state']} for k in ['supervisor','appProcess','mcpProcess','browserProcess']};(base/'owned-processes-before-disposal.json').write_text(json.dumps(public,indent=2)+'\n')
call('owned-cleanup','app','cleanup')
