#!/usr/bin/env python3
"""Owned disposable note-append SQL verification; never target an existing stack."""
import argparse, hashlib, importlib.util, json, os, shutil, signal, subprocess, tempfile, tomllib
from functools import partial
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
PROOF=ROOT/'.verification/tmp/note-sql'
SPEC=importlib.util.spec_from_file_location('database',ROOT/'scripts/ci/database.py')
db=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(db)
MIGRATION='20261002000100_atomic_onboarding_note_append.sql'
TESTS=('onboarding_note_append.sql','onboarding_note_append_concurrency.sql')
def hashes():
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in ('supabase/migrations','supabase/tests','supabase/migration-tests')
        for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
def main():
    mode=argparse.ArgumentParser(); mode.add_argument('mode',choices=('focused','fresh','upgrade'))
    args=mode.parse_args()
    before=hashes()
    record={'mode':args.mode,'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'input_hashes':before,'outcome':'RUNNING'}
    record['proof_input_hashes']={name:hashlib.sha256((PROOF/name).read_bytes()).hexdigest()
        for name in ('note_sql_validation.py','upgrade-before.sql','upgrade-after.sql')}
    path=PROOF/(args.mode+'-receipt.json')
    source=tomllib.loads((ROOT/'supabase/config.toml').read_text())
    held=db.reserve_ports(len(list(db.port_fields(source))))
    project=Path(tempfile.mkdtemp(prefix='t2t-note-'+args.mode+'-'))
    project_id=project.name; container='supabase_db_'+project_id
    execute=partial(db.run,environment=db.local_docker_environment(ROOT))
    started=False
    try:
        ports=[sock.getsockname()[1] for sock in held]
        config=db.prepare_project(ROOT,project,project_id,ports)
        assert config['db']['seed']=={'enabled':False,'sql_paths':[]}
        record.update(project_id=project_id,working_directory=str(project),
            ports={'.'.join(f):p for f,p in zip(db.port_fields(config),ports)},seed=config['db']['seed'])
        migrations=sorted((project/'supabase/migrations').glob('*.sql'))
        record['migration_range']=[migrations[0].name,migrations[-1].name]
        record['migration_count']=len(migrations)
        if args.mode=='upgrade': (project/'supabase/migrations'/MIGRATION).unlink()
        if args.mode!='fresh':
            for p in (project/'supabase/tests').glob('*.sql'):
                if p.name not in TESTS:p.unlink()
        print(json.dumps({k:v for k,v in record.items() if k!='input_hashes'}),flush=True)
        path.write_text(json.dumps(record,indent=2)+'\n')
        execute(['supabase','--version'],project)
        for s in held:s.close()
        started=True
        execute(['supabase','start','--exclude',db.EXCLUDED_SERVICES],project,quiet=True)
        psql=['docker','exec','-e','PGPASSWORD=postgres',container,'psql','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
        psql_i=[*psql[:2],'-i',*psql[2:]]
        record['postgres_version']=execute([*psql,'-Atc','SHOW server_version;'],project,quiet=True).stdout.strip()
        execute([*psql,'-c',"ALTER SYSTEM SET supautils.hint_roles = '';",'-c','SELECT pg_reload_conf();'],project)
        if args.mode=='upgrade':
            fixture=(PROOF/'upgrade-before.sql').read_text()
            execute(psql_i,project,input_text=fixture)
            shutil.copy2(ROOT/'supabase/migrations'/MIGRATION,project/'supabase/migrations'/MIGRATION)
            execute(['supabase','migration','up','--local','--yes'],project)
            shutil.copy2(PROOF/'upgrade-after.sql',project/'supabase/migration-tests/note-upgrade-after.sql')
            execute(['supabase','test','db','supabase/migration-tests/note-upgrade-after.sql'],project)
        execute(['npm','run','db:test'],project)
        record['outcome']='PASS'
    except BaseException as exc:
        record['outcome']='FAIL'; record['error_type']=type(exc).__name__
        raise
    finally:
        for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,signal.SIG_IGN)
        for s in held:s.close()
        if started:
            execute(['supabase','stop','--project-id',project_id,'--no-backup'],project)
        environment=db.local_docker_environment(ROOT)
        resources={}
        for kind,command in [('containers',['docker','ps','-aq','--filter','label=com.supabase.cli.project='+project_id]),
            ('volumes',['docker','volume','ls','-q','--filter','label=com.supabase.cli.project='+project_id]),
            ('networks',['docker','network','ls','-q','--filter','label=com.supabase.cli.project='+project_id])]:
            resources[kind]=execute(command,project,quiet=True).stdout.splitlines()
        record['remaining_resources']=resources
        record['inputs_unchanged']=before==hashes()
        record['cleanup_pass']=all(not v for v in resources.values())
        path.write_text(json.dumps(record,indent=2)+'\n')
        if record['cleanup_pass']:shutil.rmtree(project)
        assert record['inputs_unchanged'],'SQL executable inputs changed during verification'
        assert record['cleanup_pass'],'Owned disposable resources remain'
        print(json.dumps({k:v for k,v in record.items() if k!='input_hashes'}),flush=True)
if __name__=='__main__':
    def interrupted(signum,frame):raise SystemExit(128+signum)
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupted)
    main()
