import argparse
import hashlib
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--worker', required=True)
assert parser.parse_args().worker == '2'
p = Path(__file__).parent
s = Path('/home/waffleflops/.local/state/trooptotask-verification/31e5451ba9081864/worker-2')
secrets = set()
def collect(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if re.search(r'password|token|secret|(?:^|_)key$', key, re.I) and isinstance(item, str) and len(item) >= 8:
                secrets.add(item)
            collect(item)
    elif isinstance(value, list):
        for item in value:
            collect(item)
for name in ['session.json', 'provider.json', 'fixtures.json', 'environment.json', 'launcher.json']:
    collect(json.loads((s / name).read_text()))
jwt = re.compile(r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+')
provenance = []
def sanitize(data):
    counts = []
    for value in sorted(secrets, key=len, reverse=True):
        occurrences = data.count(value)
        if occurrences:
            counts.append({'credentialSHA256': hashlib.sha256(value.encode()).hexdigest(), 'occurrences': occurrences})
            data = data.replace(value, '[REDACTED_DISPOSABLE_CREDENTIAL]')
    data, count = jwt.subn('[REDACTED_DISPOSABLE_JWT]', data)
    if count:
        counts.append({'kind': 'JWT', 'occurrences': count})
    return data, counts
for name in ['app.log', 'build.log', 'supervisor.log']:
    original = (s / name).read_bytes()
    data, counts = sanitize(original.decode())
    target = p / ('owned-' + name)
    target.write_text(data)
    provenance.append({'source': str(s / name), 'target': target.name, 'originalSHA256': hashlib.sha256(original).hexdigest(), 'publishedSHA256': hashlib.sha256(target.read_bytes()).hexdigest(), 'redactions': counts})
raw_matches = []
for path in sorted(p.iterdir()):
    if path.is_file() and path.suffix != '.png':
        try:
            original = path.read_bytes()
            data, counts = sanitize(original.decode())
        except UnicodeDecodeError:
            continue
        if counts:
            path.write_text(data)
            raw_matches.append({'path': path.name, 'originalSHA256': hashlib.sha256(original).hexdigest(), 'publishedSHA256': hashlib.sha256(path.read_bytes()).hexdigest(), 'redactions': counts})
result = {'status': 'PASS', 'worker': 2, 'scope': 'Known disposable private credential values and JWT syntax checked across all current final-run text captures; only credential values redacted. Private provider/session/environment/fixtures contents are never copied. Product rows/statuses/bodies preserved.', 'ownedLogs': provenance, 'rawCaptureRedactions': raw_matches, 'originalCredentialValuesRetainedInArtifact': False}
(p / 'credential-provenance.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
