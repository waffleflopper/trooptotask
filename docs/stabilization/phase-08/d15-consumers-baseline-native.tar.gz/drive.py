from pathlib import Path
import subprocess, json, re, os
ROOT=Path(__file__).resolve().parents[3]
assert Path.cwd()==ROOT, 'Run only from this exact checkout'
os.environ['TMPDIR']='/home/waffleflops/.cache/t2t-d15-tmp'
name=os.environ['D15_EVIDENCE']
assert re.fullmatch(r'd15-consumers-[a-z0-9-]+',name), 'Explicit safe consumer evidence name required'
E=ROOT/'.verification/evidence/verify-trooptotask'/name
E.mkdir(parents=True,exist_ok=True)
assert E.resolve()==E and E.stat().st_uid==os.getuid(), 'Owned non-symlink evidence directory required'
def write(file,text):
    assert file.parent==E and not file.exists(), 'Refuse evidence overwrite'
    with file.open('x') as output:output.write(text)

def native(name,args,tag):
    write(E/(tag+'-input.json'),json.dumps({'tool':name,'arguments':args},indent=2)+'\n')
    r=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args),'--worker','1'],text=True,capture_output=True)
    write(E/(tag+'.json'),r.stdout)
    write(E/(tag+'-stderr.log'),r.stderr)
    if r.returncode:raise RuntimeError(r.stderr or r.stdout)
    obj=json.loads(r.stdout)
    if obj.get('isError'):raise RuntimeError(r.stdout)
    return '\n'.join(c.get('text','') for c in obj.get('content',[]) if c['type']=='text')
def snap(page,tag):
    assert not (E/(tag+'.txt')).exists()
    native('take_snapshot',{'pageId':page,'filePath':str(E.relative_to(ROOT)/(tag+'.txt'))},tag)
    return (E/(tag+'.txt')).read_text()
def click(page,uid,tag):return native('click',{'pageId':page,'uid':uid,'includeSnapshot':True},tag)
def key(page,key,tag):return native('press_key',{'pageId':page,'key':key,'includeSnapshot':True},tag)
def fill(page,uid,value,tag):return native('fill',{'pageId':page,'uid':uid,'value':value,'includeSnapshot':True},tag)
def screen(page,tag):
    assert not (E/(tag+'.png')).exists()
    return native('take_screenshot',{'pageId':page,'filePath':str(E.relative_to(ROOT)/(tag+'.png'))},tag+'-screen')
def control(args,tag):
    write(E/(tag+'-helper-input.json'),json.dumps({'worker':1,'arguments':args},indent=2)+'\n')
    r=subprocess.run(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args],text=True,capture_output=True)
    write(E/(tag+'.json'),r.stdout)
    write(E/(tag+'-stderr.log'),r.stderr)
    if r.returncode:raise RuntimeError(r.stderr or r.stdout)
    return json.loads(r.stdout)
def uid(text,description):
    matches=[line for line in text.splitlines() if description.casefold() in line.casefold()]
    if len(matches)!=1:raise ValueError({'description':description,'matches':matches})
    return re.search(r'uid=(\S+)',matches[0])[1]
