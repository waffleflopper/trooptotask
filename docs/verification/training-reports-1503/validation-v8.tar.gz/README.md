# Training Reports 1503 current validation

This packet preserves the actual seven required-check results, complete logs, production build, isolated fresh and populated SQL output, exact current source patch, cumulative source-review checkpoint, migration chain and review reports. It contains no private browser profile, provider runtime, authentication file or active service.

The tested revision is c09b67376abc3936e1b141407c6759b362fe5c6a over main6555c3c884801e46bd0fc78a94d698c30ec76d88, with source patch32708d9529e3554a1c560101db922fb5588f017e7a10e9afdc6db3384049ff07. The complete cumulative binary patch was captured at the prefinal source-review checkpoint. Its six binary archives are historical1501/1502 artifacts. The later census also includes nine separately archived1503 browser attempts. Final acceptance prose and the final independent expanded audit are added afterward and do not constitute a fresh live execution.

Current browser proof lives in final-integration-v8.tar.gz. Broader same-chart proof lives in final-v7.tar.gz. Earlier failure and unavailable archives retain their own outcomes. The visual artifact judgment corrects Paper-placement and common-zero-drift claims; fallback font remains a canvas prediction, not a live render. Native browser coverage, read-only measured sweeps, HTTP/provider checks and artifact judgment remain distinct.

1503-v7-paper-actual.jpg was decoded from the successful Paper screenshot tool response at supported position116 in final-v7, nodeUF-1, scale2, file01M3HXNN6A4S0FTNQ88XS9YJ9X. Its79116bytes hash2ec30abcc787e4762594718dd65826fcf2594091760f87187c73ed4108d45269 matches that inline response. The fresh artifact judge timed out on three later Paper reads and instead viewed the separately archived earlier v5 capture. Root decoded bytes without making a visual judgment.

Current validation uses Node24.21.0, npm11.19.0, four test workers, Supabase CLI2.101.0 and Postgres17.6. Synthetic build-only provider values and origin overrides are recorded in runtime.json. Browser launches used the owned verify:app environment. Both SQL projects and both owned browser workers were cleaned before packaging. No remote database, existing development database reset, migration deployment or PR merge occurred.

Manual deslop fallback was used because no installed deslop skill was found. The complete independent source review covers domain, admission, data ownership, request lifetime, direct and reverse consumers, current tests and the narrow migration integration. Earlier incidental-copy assertions and narrating comments were removed. The maintained browser recipe and current contracts remain source files.

The final acceptance record and independent-acceptance.md own the final documentation checks, final census and expanded current artifact verdict. This immutable packet does not invent those later results.
