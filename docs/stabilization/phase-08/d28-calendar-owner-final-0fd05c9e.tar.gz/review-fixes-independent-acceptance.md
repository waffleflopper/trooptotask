# Independent acceptance: D28 / #1376 Calendar review repair

Standards: GO. Spec: GO. No consequential findings. This accepts the frozen ten-path review repair as source and artifact work. It is not independent native execution, final integrated CI, production-build evidence, or release acceptance.

## Binding and scope

Reviewed worktree: `/home/waffleflops/.cache/t2t-1376-calendar-review-fixes`.
HEAD: `0fd05c9e4f32035e0b9f960ac42c64a31c47fcb4`.
Patch: `/home/waffleflops/.cache/t2t-1376-calendar-review-fixes.patch`.
SHA-256: `b38ac183842f78a11eec53cb8225d76fec39d32465be5054957044180c3bf0ef`.

I independently recomputed the patch hash and compared its bytes with `git diff --binary --full-index`. They match. The ten changed-file hashes match the ledger. The index is empty. All 299 protected ledger entries match both their recorded SHA-256 and their HEAD blob. I inspected the complete actual diff, relevant source and tests, retained R1/R6 contracts, testing policy, prior independent source reviews, and raw verification logs. Unchanged ownership and consumer-migration source uses the accepted `eb806f2a` review plus the `0fd05c9e` orphan-removal follow-up. This is one proportional delta review, not a second full Calendar review.

No browser, app, build, test suite, database, GitHub or connector was started or contacted. No original checkout, worker, service, or private owner worktree was modified. The only write is this isolated report. No nested agents were used.

## Standards and specification assessment

### Pagination

All ten pager query variants append ascending unique `id` ordering before offset ranges:

- Assignment range, day references and slot references: `calendarAssignmentReader.server.ts:19,37,63`.
- Availability overlap and Personnel history: `calendarAvailabilityPersistence.server.ts:67,86`.
- Status catalog, status labels, assignment catalog, assignment targets and special days: `calendarCatalogPersistence.server.ts:29,43,88,105,166`.

The installed postgrest-js implementation at `PostgrestTransformBuilder.ts:337-343` appends each order clause. It does not replace the earlier one. Status/assignment `sort_order asc`, ranged special-day `date asc`, overlap `end_date asc` when requested, and history `start_date desc` remain primary. The schema gives each affected table an `id` primary key. Projection does not need to select the ordering column; the day and slot reference projections remain narrow.

Organization predicates, captured ordinary credentials, scope intersections, inclusive date predicates, exact slot-pair filtering, chunk bounds, mappings and page-error propagation are unchanged. No privilege escalation, metadata loss or mutation expansion was introduced. The existing cross-chunk overlap merge preserves its end-date primary sort. It need not impose a global ID order across different chunks to make each offset traversal complete. The repair guarantees stable traversal for a stable row set; it does not claim snapshot consistency under concurrent row changes.

### Malformed set input

`dailyAssignmentOperations.server.ts:57-60` uses safeParse and the existing status-bearing fail helper. The failure occurs before Calendar assignment policy, reference reads, replacement and audit. Valid-input semantics are unchanged. `httpAdapter.ts:66-70,226-227` converts that status-bearing error into HTTP 400. The ordinary POST route still performs its existing admission and dispatch.

The new operation regression at `dailyAssignmentOperations.server.test.ts:15-34` proves an invalid numeric assignee produces 400, preserves the saved slot exactly and produces no audit event. This is the cheapest stable seam for the specified failure. Nearby valid, denied, day, batch and route coverage remains. It does not claim that every invalid POST dispatches to the set operation. The unchanged schema still accepts date strings without date-shape validation. The separately deferred malformed-date batch 500 observation (#1557) is not repaired or relabeled by this patch.

### Cleanup expectations

`reports-history.md:31` now agrees with the accepted terminal behavior. Before destructive catalog deletion/federal reset, the verifier must record selected catalog IDs, linked availability/assignment IDs and the original federal set. Afterward it must account for those declared removals and independently expected replacement holidays, preserve every other original row and all Organization B rows, and require temporary IDs to be absent. It forbids recreating consumed IDs to manufacture equality. Complete original A/B equality still applies when the terminal destructive actions did not run.

This is a correction to the comparator, not new destructive authority or weaker data preservation. The existing owned-persistence record already identifies the five consumed original synthetic rows and the 148 unaffected originals. The recipe does not itself establish an actual final cleanup result; that must come from the worker's readbacks and terminal cleanup evidence.

### Tests and provider fixture

The provider continues to use the real installed Supabase SDK with a synthetic, intercepted fetch. Origin, ordinary credentials, predicates, projections, state mutations and failure behavior remain observable. The fixture change at `calendarProvider.ts:56,95-107` models different physical order on later pages and lexicographic comparison of multiple supplied order fields before slicing. It is a controlled provider condition that can disagree with production query construction.

New dense fixtures assert complete independently arranged 1,001-ID multisets. They detect both missing and duplicated rows and survive a behavior-preserving switch from offset pagination to another complete traversal. They do not freeze URL order strings or copy a production calculation into expectations. Assignment range/day/slot, overlap with and without end-date ordering, history, and five catalog variants are exercised. Assignment targets remain bounded to 100 distinct IDs per query; existing target tests cover exact admission, foreign exclusion, finite URL size and late-chunk failure.

The older numeric insertion-order tail assertions were replaced by complete retained-ID comparisons, with metadata checks retained. Two existing small assignment fact arrays were reordered to reflect the explicit ID order; no values, scope exclusions, Cartesian-neighbor assertions or late-failure checks were removed. Primary ordering remains covered by existing reverse-sort status fixtures, differing history dates, end-date overlap/chunk tests, and differing special-day dates, alongside direct source inspection. No skip, waiver, weakened guard, allowlist or scan-path reduction was introduced.

## Actual verification artifacts

I read the raw logs rather than treating passing counts as the behavior specification. I did not rerun passing checks.

- `...-red.log`: 8 expected failures and 41 passes. Paging failures show duplicated first IDs and missing final IDs; malformed input exposes a raw ZodError without status 400.
- `...-green-first.log`: 5 old insertion-order assertions fail and 82 tests pass. The new regressions pass. The actual failures match the later narrow assertion adaptations.
- `...-green.log`: 8 selected suites, 87 tests pass, 1.74 seconds. Selection includes the four changed suites, day/batch/preservation and the ordinary route suite.
- `...-check.log`: 10 missing public-environment declaration errors in six unchanged files, no warnings. This remains a failed environment observation.
- `...-check-env.log`: zero errors and zero warnings. The report declares compile-only nonsecret URL/key placeholders; this is type-check evidence, not provider connectivity.
- `...-governance.log`: 157 retained findings, no regression, ordinary/admin allowlists 3/5 and zero feature permission couplings.
- `...-format-lint.log`: all ten paths formatted, nine TypeScript paths linted, recipe links/anchors and whitespace pass at exit 0. Recorded Node/npm versions are 24.21.0/11.19.0.

No full-suite or build result is claimed for this isolated patch. Exact integrated-candidate CI must supply the complete required sequence, including production build, before final candidate acceptance/merge. The selected local evidence supports these repairs without requiring another unchanged local full-suite run.

## Proof applicability and remaining gates

Older native evidence can continue to support the unchanged visible interactions, policy/admission, Organization/Group isolation, valid-slot replacement, projections, metadata and exports because this delta changes no routes, request composition, UI, permission rules, DTO mapping, write shape, atomic replacement, removal or SQL. Its only read change supplies a deterministic tie order while retaining each primary sort and filter. Native fixtures below the page boundary cannot establish the dense-page regression; the new installed-SDK tests provide that changed-boundary proof. Older observations remain bound to their original revision and must not be described as live execution of this patch.

The permanent remover, narrow DELETE route/test, complete availability batch, pagination helper and all tracked Supabase/verify-app files are protected and byte-identical. Their matching separate removal/SQL evidence remains applicable. The test helper and changed test files need their current selected test results; old test counts are not reused for them. The invalid-input 400 is established by the current operation regression and the unchanged HTTP status adapter, not an older native happy path.

The cleanup recipe is an expectation correction for existing terminal actions. At the active session's checkpoint, reconcile the actual before/after rows against declared removals/replacement holidays, retain the frozen driving version, and record the instruction-only difference. A comparator mistake alone does not require repeating all 114 native cases. Any genuinely failed or unavailable native behavior, final clean-seeds readback, final doctor/owned cleanup and final artifact packaging remain the coordinator's current evidence obligations. Current-candidate CI and the hosted review follow-through also remain separate gates. This review does not claim those gates are complete or authorize integrating into the still-active frozen session.

The optional single-Person request optimization stays deferred as #1559. #1557 and the existing owner-deferred observations remain visible. #1376 remains open for Personnel/Groups four ports, Training, Onboarding, residual settings, final facade removal and integrated acceptance.

## Scoped comment/suppression audit

Read-only audit used the supplied Comment Sicko keep-list against all nine changed TypeScript files and the actual added lines. Added narrative comments: 0. Added or widened lint/type suppressions: 0. Recommended comment deletions: 0. MUST KILL flags: 0. No code edits were made. Unchanged out-of-scope comments and suppressions were not re-audited. Markdown verification instructions are the intended contract prose, not code comments.

No missing evidence blocks this scoped source/artifact GO. Final native packaging and exact-head CI remain outside this review and cannot receive acceptance credit from it.
