import sys,json,uuid
sys.path.insert(0,'.verification');import d18_ui as v,d18_final as f
paths=[]
ids=set()
for name in ['04-source-seed','61-wait-source-seed','62-storage-source-seed','150-fresh-counsel-wait-seed']:
 for sources in f.read(name)['sources'].values():
  ids.update(value for key,value in sources.items() if key!='label')
ids.update(f.read('87-lifecycle-seed')['ids'].values())
assert len(ids)==64 and all(str(uuid.UUID(value))==value for value in ids)
seeds=['04-source-seed','61-wait-source-seed','62-storage-source-seed','150-fresh-counsel-wait-seed']
for i,name in enumerate(seeds):
 seed=f.read(name)
 for org in ['orgA','orgB']:
  parent=seed['sources'][org]['parent'];expected=next(x['path'] for x in seed['files'] if '/'+parent+'/' in x['path']);r=f.read(f'240-after-cleanup-cohort-{i+1}-{org}-files')
  assert r['personnelId']==parent and r['organization']==org
  assert len(r['files'])==1 and r['files'][0]['path']==expected and r['files'][0]['present'] is False,r
  assert all(rows==[] for rows in r['tables'].values()),r
  paths.append(expected)
assert len(set(paths))==8
for org in ['orgA','orgB']:
 for table in f.TABLES:
  sort=lambda xs:sorted(xs,key=lambda x:x['id'])
  after=f.read(f'239-after-cleanup-{org}-{table}')['rows']
  assert sort(f.read(f'original-{org}-{table}')['rows'])==sort(after),(org,table)
  assert not any(r.get('id') in ids or r.get('resource_id') in ids for r in after),(org,table)
initial=f.read('01-launch');final=f.read('242-final-doctor');disposed=f.read('243-owned-disposal')
assert initial==final,(initial,final);assert disposed['status']=='PASS',disposed
result={'observation':'PASS','recordedTemporarySourceArtifactIds':64,'actualRecordedPdfPathsAbsent':paths,'exactFileCardinality':8,'allFileBearingTableProjectionsEmpty':True,'originalRowSetsExactlyEqual':20,'sameFrozenFinalDoctor':True,'ownedDisposal':'PASS','driverCorrection':'Executed cleanup wrapper checked an undefined exists key and counted eight source labels alongside 64 UUIDs. This offline comparison reads each preserved actual artifact-files present:false result, exact recorded path/cardinality, empty table projections, original values, final doctor and disposal; no new live claim or mutation.'}
(v.root/'244-exact-cleanup-validation.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS 8 exact recorded actual PDF paths, 20 original row sets, frozen doctor and disposal')
