import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/.verification/evidence/verify-trooptotask/d24-export-ownership-access')

def read(name):
    return json.loads((root / name).read_text())

ids = read('fixture.json')['ids']
tables = ['data_exports', 'personnel', 'personnel_extended_info', 'personnel_onboardings', 'onboarding_step_progress', 'audit_logs', 'notifications']
unchanged = 0
for org in ['orgA', 'orgB']:
    for table in tables:
        before = read(f'before-denials-{org}-{table}.json')
        after = read(f'after-denials-{org}-{table}.json')
        assert before['count'] == len(before['rows'])
        assert after['count'] == len(after['rows'])
        if (org, table) == ('orgA', 'audit_logs'):
            originals = {row['id']: row for row in before['rows']}
            final = {row['id']: row for row in after['rows']}
            assert len(final) == len(after['rows'])
            for key, row in originals.items():
                assert final[key] == row
            added = [row for row in after['rows'] if row['id'] not in originals]
        else:
            assert before == after, (org, table)
            unchanged += 1

assert unchanged == 13
assert len(added) == 6
users = collections.Counter(row['user_id'] for row in added)
assert len(users) == 3 and set(users.values()) == {2}
assert read('owner-contact.json')['memberships']
member = next(row for row in read('owner-contact.json')['memberships'] if row['id'] == ids['orgMemberMembership'])
assert users[member['user_id']] == 2
for row in added:
    assert row['org_id'] == ids['orgA']
    assert row['action'] == 'policy.denied'
    assert row['resource_type'] == 'organization.exportData'
    assert row['resource_id'] is None
    assert row['severity'] == 'warning'
    assert row['details'] == {
        'policyAction': '[redacted]',
        'reasonCode': '[redacted]',
        'resource': '[redacted]',
        'matchedScope': '[redacted]',
        'redacted_fields': ['policyAction', 'reasonCode', 'resource', 'matchedScope'],
    }
    assert row['timestamp']
    assert row['ip_address'] == '127.0.0.1'
    assert 'HeadlessChrome/152.0.0.0' in row['user_agent']

requests = []
for role in ['orgMember', 'viewer', 'scoped']:
    actor = read(f'{role}-actor.json')
    assert actor['role'] == role
    assert actor['access'] == 'denied'
    assert actor['orgId'] == ids['orgA']
    assert 'Error 403 - Troop to Task' in (root / f'{role}-denied.txt').read_text()
    for family, route in [('json', 'export'), ('excel', 'export-excel')]:
        name = f'{role}-denied-{family}.json'
        result = read(name)
        assert result['request'] == {'method': 'POST', 'path': f'/org/{ids["orgA"]}/api/{route}'}
        assert result['status'] == 403
        assert json.loads(result['body']) == {'message': 'You do not have permission to perform this action'}
        assert result['contentType'] == 'application/json'
        assert result['contentDisposition'] is None
        requests.append({'file': name, 'status': result['status']})

for name, org, route in [('foreign-denied-json.json', 'orgA', 'export'), ('owner-foreign-orgB-denied.json', 'orgB', 'export-excel')]:
    result = read(name)
    assert result['request'] == {'method': 'POST', 'path': f'/org/{ids[org]}/api/{route}'}
    assert result['status'] == 404
    assert json.loads(result['body']) == {'message': 'Organization not found'}
    assert result['contentType'] == 'application/json'
    assert result['contentDisposition'] is None
    requests.append({'file': name, 'status': result['status']})

print(json.dumps({'requests': requests, 'unchangedCollections': unchanged, 'unchangedOriginalAuditRows': len(originals), 'addedPolicyDenialWarnings': len(added), 'newLifecycleRows': 0, 'newAdministratorNotifications': 0, 'newSuccessExportAudit': 0, 'denialWarningsPerUser': dict(users)}, indent=2))
