# Storage removal cap correction

Independent acceptance and completed source review identified the missing Storage bound before any owned live launch. Supabase documents a limit of 1,000 objects per remove call: https://supabase.com/docs/guides/storage/management/delete-objects (line 79, checked 2026-10-01).

The REST model now independently rejects more than 1,000 requested prefixes. The unchanged pre-fix source failed both 1,001-row file-family successes with Storage removal accepts at most 1000 prefixes; the other two families passed. This actual red output and the exact pre-fix source/test bytes are preserved separately. The correction adds a private 1,000-path bound and sequential awaited removals, after every DB deletion and confirmation already finishes. No shared adapter or other application behavior changed.

Final focused result: 2 files / 27 tests passed (11 owner tests plus unchanged 16 parent tests), ESLint and Prettier passed. A new later Storage failure selects the final known expired path as its trigger: earlier object removals persist, all expired metadata is gone, failed bytes and every sentinel/unrelated byte remain exact, and replay returns zero without rediscovering the orphan file. The existing first-Storage-failure case remains. Tests do not assert private batch counts.

All prior raw logs, hashes and README remain unchanged; new worker-storage-cap files describe only this correction. The original baseline SDK packet remains untouched. These SDK/fetch tests remain synthetic REST/Storage boundary proof; live SQL/RLS, provider and native verification remain root-owned. No services, browser, SQL, migrations, Git operations or other source files were changed by this owner correction.
