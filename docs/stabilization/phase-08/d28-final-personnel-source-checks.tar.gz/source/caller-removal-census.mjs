import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { readFileSync } from 'node:fs';
const { scanRepository } = await import(pathToFileURL(path.join(process.cwd(), 'scripts/module-imports.ts')).href);
const graph = scanRepository(process.cwd());
const runtime = graph.edges.filter(e => e.classification === 'local' && e.to && !e.typeOnly && e.kind !== 'import-type');
const entries = graph.sourcePaths.filter(p => /^src\/routes\/(?:.*\/)?\+(page|layout|server|error)(\.server)?\.(svelte|[jt]s)$/.test(p) || /^src\/hooks(\.server|\.client)?\.[jt]s$/.test(p));
const reachable = new Set(entries), todo = [...entries];
for (let p; p = todo.pop();) for (const e of runtime.filter(e => e.from === p)) if (!reachable.has(e.to)) { reachable.add(e.to); todo.push(e.to); }
const fixturePaths = graph.sourcePaths.filter(p => /\/test-support\/|(?:inMemory|test-support|testHelper|TestContexts)/.test(p));
const fixtureRuntimeReachable = fixturePaths.filter(p => reachable.has(p));
const retired = /\b(?:DataStore|FindOptions|FindResult|GroupScopeRule|WritePorts|createRequestDataContext|createRequestWriteContext|personnelInFilter|createScopedDataStore|createSupabaseDataStore)\b|(?:scopedDataStore|supabaseDataStore|server\/core\/ports|adapters\/scopeRules)/;
const genericRuntimeReachable = [...reachable].filter(p => retired.test(readFileSync(p, 'utf8')));
const genericOtherSources = graph.sourcePaths.filter(p => !reachable.has(p) && retired.test(readFileSync(p, 'utf8')));
const fixtureDirectImports = graph.edges.filter(e => e.to && fixturePaths.includes(e.to));
console.log(JSON.stringify({ sourcePaths: graph.sourcePaths.length, entrypoints: entries.length, runtimeReachable: reachable.size, graphFailures: graph.failures, fixtureRuntimeReachable, genericRuntimeReachable, genericOtherSources, fixtureDirectImports, entryPaths: entries, runtimeReachablePaths: [...reachable].sort() }, null, 2));
if (fixtureRuntimeReachable.length || genericRuntimeReachable.length || graph.failures.length) process.exit(1);
