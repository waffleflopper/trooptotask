#!/usr/bin/env bash
# usage: shot.sh NAME [fullPage true|false] (uses $P) -> shots/NAME.png
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
[ -e $E/shots/$1.png ] && { echo "REFUSED shot $1 exists"; exit 1; }
MAXOUT=300 $E/t.sh "shot-$1" "screenshot $1" take_screenshot "{\"pageId\":$P,\"fullPage\":${2:-true},\"filePath\":\"$E/shots/$1.png\"}"
