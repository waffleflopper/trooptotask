from pathlib import Path
import json
p=Path(__file__).parent
def load(n):return json.loads((p/(n+'.stdout')).read_text())
actors=json.loads((p/'public-actor-identities.json').read_text())
assert load('denials-before-A')==load('denials-after-A')
assert load('denials-before-B')==load('denials-after-B')
for n,status in (('admin-api-json',200),('admin-api-excel',200),('member-api-json',403),('member-api-excel',403),('foreign-api-json',404),('foreign-api-excel',404)):assert load(n)['status']==status
j=json.loads((p/'admin.json').read_text());f=load('fixture');assert j['organizationProfile']==load('before-organizations-orgA')['rows']
assert all(f['ids'][k]not in json.dumps(j)for k in ('orgB','personForeign','groupForeign','onboardingForeignTemplate'))
c=load('admin-native-save');match=[r for r in load('admin-native-lifecycle')['rows']if r['file_size_bytes']==c['bytes']and r['requested_by']==actors['orgAdmin']['id']];assert len(match)==1 and match[0]['status']=='completed'
for table in ('personnel_onboardings','onboarding_step_progress'):
 for org in ('orgA','orgB'):assert load('before-'+table+'-'+org)==load('denials-'+table+'-'+org)
assert load('owner-retry-network')['calls'][0]['status']==200
(p/'admission-analysis.json').write_text(json.dumps({'status':'PASS','adminBothOrdinaryApiFormats':200,'memberBothFormats':403,'foreignBothFormats':404,'denialExportPacketProgressRowsExactUnchanged':True,'nativeAdminJSON':{'artifact':c,'completedLifecycle':match[0],'profile11ExactAndKnownForeignSentinelsExcluded':True},'ownerExplicitRetry':load('owner-retry-save'),'limits':'Direct admitted/denied ordinary API calls are separate from native owner/admin saved artifacts. Member-manager focused route positive cases separate, not live here.'},indent=2)+'\n')
print('Native owner retry/adminJSON and direct API authority/no-effect readbacks PASS')
