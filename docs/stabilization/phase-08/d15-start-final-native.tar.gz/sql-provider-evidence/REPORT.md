# Atomic Start SQL handoff — issue #1363

The six owned source files are committed at `b7f113fac352b9209ebce57c04ce4ff3601088ed`, based on `f9293780eba9d38ebad471444c9e6837fb8970db`. The tracked worktree is clean. Root reports integration at `6e5697a1`; this worker's checks used its isolated worktree, not root's application or browser. No push, PR, remote database, existing local database, or native session was used by this worker.

The fresh repository campaign, staged populated upgrade, focused SQL/provider checks, and supplementary raw populated-upgrade readback passed. All five owned disposable projects were stopped without backups, their directories removed, and their exact containers, networks and volumes verified absent. The initial supplementary readback failed in the ignored reporting driver before applying the new migration; its original driver, input record, complete failure log, exit 1, original result and cleanup are retained separately.

## Source and migration

`source-manifest.json` records every owned path, size and SHA256. `source.patch` is the complete base-to-commit patch; `tested-source/` contains exact copies of all six committed files.

- `supabase/migrations/20261002001100_atomic_onboarding_start.sql`
- `supabase/tests/onboarding_atomic_start.sql`
- `supabase/migration-tests/onboarding_start_before.sql`
- `supabase/migration-tests/onboarding_start_after.sql`
- `scripts/ci/onboarding_start_provider_probe.mjs`
- `scripts/ci/database.py`

Migration SHA256: `6e42557dd75d95a852c57dce9933064e560efe5d991664953dc525b3e270767b`.

The ordinary authenticated RPC takes Organization, Person, configured template, date and seven-field prepared steps. It returns the actual saved parent and ordered actual saved progress. The parent and every prepared child share one transaction; a failed child or deferred commit check removes all new writes. It uses invoker permissions, an empty search path, current Onboarding admission and Person scope, and repeats that admission after actual parent and child foreign-key waits. It does not explicitly acquire new Person/catalog locks. Only `authenticated` has effective execution permission; PUBLIC, anon and service_role do not. The migration notifies PostgREST to refresh its schema. No existing rows, policies, tables or indexes are rewritten. The current named active-packet unique index remains unchanged.

The existing application owns configured-template preparation, date validation, complete prepared-definition selection and targeted Training-presence calculation, including expired records. The RPC validates the seven-field shape and selected same-Organization definition references, forces fresh IDs/defaults, and preserves the prepared snapshot without new catalog equality or complete-set checks. Existing empty templates admit `[]`. This does not certify arbitrary RPC callers' Training facts or catalog completeness, solve catalog-edit races, or provide retry identity after a committed response is lost.

## Executed checks

Commands, combined stdout/stderr files, exit codes and capture limits are recorded in `execution-records.json`. The normal repository runner deliberately suppresses credential-bearing Supabase startup/status output; those bytes were not retained or independently reviewed. All remaining command output is retained in full. The initial focused and full campaigns ran on base f929 plus the final six source files before committing. Their exact frozen bytes match the committed manifest. The supplementary runs record the committed head directly.

| Run | Actual result | Principal evidence |
| --- | --- | --- |
| `python3 .verification/tmp/start-sql/focused.py` | PASS: fresh 163 migrations; 43 SQL assertions; 13 ordinary provider scenarios/16 RPC requests | `focused-1.log`, `focused-project-result.json`, `focused-observations.json`; 263 selected inputs unchanged |
| `python3 .verification/tmp/start-sql/campaign.py` → `python3 scripts/ci/database.py` | PASS: fresh 53 suites/1417 assertions; four migration regressions/67 assertions; staged 18 suites/282 assertions; seven provider invocations | `campaign-1.log`, `campaign-summary.json`, both full Start provider captures; all 4789 original inputs unchanged |
| Supplementary populated readback, attempt 1 | FAIL: PostgreSQL boolean `t` was incorrectly parsed as JSON before applying the migration; exact cleanup PASS | `raw-upgrade-1.log`, `raw-upgrade-driver-attempt-1.py`, `raw-upgrade-attempt-1-inputs.json`, original result and separate truthful disposition |
| Supplementary populated readback, attempt 2 | PASS: 162 previous migrations → 163; 45 original full rows unchanged; 11 after-contract assertions; 13 ordinary provider scenarios/16 requests | `raw-upgrade-2.log`, `raw-upgrade-driver-attempt-2.py`, uniquely named attempt-2 captures and result; all 4789 original inputs unchanged |

Full fresh range: `20260413001158_remote_schema.sql` through `20261002001100_atomic_onboarding_start.sql`. Full staged replay first applies 141 migrations through `20261002000100_atomic_onboarding_note_append.sql`, populates all incoming fixtures, then applies all 22 held migrations. The incoming D17 Organization Storage contracts, other SQL suites, four regressions and five prior provider invocations remain registered and passed. Start adds the fresh and staged provider invocations. The supplementary populated capture applies the previous 162-migration chain through `20261002001000_organization_storage_cleanup.sql`, populates the Start before fixture, then applies only the new migration.

`recomputed-proof.json` rechecks actual TAP counts, all four full saved-row captures, function attributes/grants, source hashes and all four retained Start provider runs from raw artifacts. It is a read-only recomputation, not another live run.

The populated upgrade's 45 original rows comprise Person 11, memberships 9, templates 4, definitions 9, Training types 3, Training records 1, parents 4 and progress 4. `raw-upgrade-attempt-2-before-rows.json`, `fixture-rows.json`, `after-rows.json` and `after-contracts-rows.json` (all with the attempt-2 prefix) are deeply equal, with every saved field and exact row set retained. They include completed/cancelled history, an active legacy packet, null/deleted definition history, an inactive unknown paperwork stage, original note attributes and an expired Training record. The metadata capture records actual invoker/volatile/empty-search-path attributes, argument names, effective grants and the unchanged active-index definition. These are eight explicitly selected fixture tables, not a claim of a whole-database data dump.

Static checks were separately captured in `static-checks.json` and individual stdout/stderr files: Node syntax, scoped ESLint, scoped Prettier, eight database-runner unit tests and complete owned-diff whitespace all passed. Local actual tools were Node 24.21.0, npm 11.19.0, Python 3.14.7, Supabase CLI 2.101.0, PostgreSQL 17.6, pg_prove image `public.ecr.aws/supabase/pg_prove:3.36`, Docker client/server 29.7.2 and x86_64. This is local disposable SQL/provider proof; exact-head full application checks, native proof and ARM64 hosted CI belong to root and are not credited here.

## Meaningful behavior observed

The ordinary provider uses real GoTrue password sign-in and authenticated Supabase clients. Administrative reads and fixture setup target only its private disposable project. Each overlap is demonstrated by actual recursive `pg_blocking_pids` paths to a no-write holder on an exact fixture Person or Training type; elapsed time alone is not treated as evidence of a wait.

- Two same-Person Starts produce one complete three-step winner and the exact named `personnel_onboardings_active_idx` conflict, without an orphan packet. A failed first contender is witnessed after its parent and earlier child exist inside its transaction; rollback lets the waiting second contender create a complete packet.
- A different-Person Start finishes while the first is still held. Capability revocation and moving the Person outside the caller's Group both deny after observed parent-FK waits and, separately, after observed child-FK waits. The denial message is the explicit fresh admission check. Full committed parent/progress/Training state is unchanged; only the intended external membership/Person change happens and is restored.
- A real deferred constraint trigger observes the complete new packet and fails at commit. No new parent/progress is saved. Restoring that exact fault allows a complete retry. Existing empty-template Start succeeds with a parent and zero children.
- Raw responses match actual saved fields and stable ordering. Prepared snapshots may differ from current catalog metadata. Notes start empty, all steps active, checkbox/paperwork completion false, paperwork starts at its first prepared stage, Training completion follows supplied prepared facts, and terminal parent fields stay null.
- SQL coverage additionally verifies effective grants, Org Operate and Group Operate/Configure without borrowed Personnel/Training capabilities, archived Person admission, Org-scoped unassigned admission, Group/empty/unassigned/foreign denials, unavailable template/definition/Training references, malformed snapshots, extra fields, duplicate IDs, defaults, terminal-history admission, partial insertion rollback and genuine retry.

Raw PostgREST statuses are intentionally distinct from application-provider mappings: in these actual probes P0002 is raw 500, 22023/23514 are raw 400, 42501 is raw 403 and the named 23505 is raw 409. The separate application provider maps P0002 to 404 and unexpected 22023/23514 failures to application 500; this worker does not claim application HTTP or native acceptance from raw RPC outcomes.

## Ownership and disposal

All projects used independently reserved ports outside development stacks, disabled seed execution, guarded local Unix Docker, and unique temporary directories. `campaign-projects.json` and the respective focused/supplementary result records retain complete port maps.

| Project | API / DB | Disposition |
| --- | --- | --- |
| `t2t-ci-db-start-focus-6p7k5dn6` | 60691 / 61918 | PASS, removed |
| `t2t-ci-db-q70bo41f` | 60059 / 59495 | full fresh PASS, removed |
| `t2t-ci-db-e7mdxu12` | 61774 / 60362 | full staged PASS, removed |
| `t2t-ci-db-start-upgrade-vt_q2vqp` | 61639 / 59395 | reporting attempt FAIL, removed |
| `t2t-ci-db-start-upgrade-dwx875da` | 63300 / 59031 | supplementary upgrade PASS, removed |

Every provider cleans its exact fixture faults, GoTrue users and fixture Organizations/rows; the entire private project is then stopped with `--no-backup`. `final-exact-disposal.json` independently repeats read-only directory and exact-name container/network/volume absence for all five projects. No retained runtime exception or shared service is required.

This completes the bounded SQL/provider seam. It does not complete issue #1363 or credit root's pending native, independent whole-source, hosted CI and bot review gates. This deliverable contains a migration: Robert's manual database application gate remains for the concrete reviewed PR after those gates are complete.
