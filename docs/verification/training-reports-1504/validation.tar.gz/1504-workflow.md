# #1504 execution frame

The falsifiable outcome is exact cell/focus requirement drill-down with 25/100 pagination and retry, at most three model-generated focus areas with matching what-if figures, a five-sheet workbook matching the same canonical report filters, and a native printed brief with those filters and no app controls. Unused legacy report paths must be absent and retained Training, Personnel and Dashboard consumers must remain correct. Required application checks, production build, independently reviewed expanded browser artifacts and a fresh Claude visual acceptance are gates.

The work has seven coupled deliverables: lower briefing sections, paginated detail lifetime, five-sheet export, print, legacy removal, recipes/contracts, and acceptance. This is a several-hour slice with roughly 15–25 application/test/document files, subject to the actual consumer census. No new database change is planned. Existing #1501 migration remains a release prerequisite; no database action or merge is authorized.

Throughput checkpoint:

1. Blockers are the current model/consumer census, actual Paper/shared UI grounding and an affected pre-change browser baseline. The native print capture capability must be established before final proof.
2. Two read-only grounding streams have exclusive ignored evidence paths. They do not write source or drive the browser. Subsequent visual implementation is one coupled Claude owner, followed by an independent review/driver. Root launches and cleans each owned browser.
3. Source/shared types are edited by one implementation owner. Only one driver uses worker 1 at a time. Root controls integration, formatting, executable-input freeze, full checks, artifact packaging and publication. No concurrent shared-service tests or file writes.
4. The smallest safe decomposition is grounding/baseline, connected page/detail/export/print migration, then independent final acceptance. A new architecture bakeoff is skipped because the canonical TrainingBriefing model, source loader, stable scope keys and shared workbook boundary already settle the organizing shape.

Use Model the Domain to preserve the report-owned input and explicit detail request state. Use the Laziness Protocol to retain required shared status/filter helpers and delete legacy consumers in the same migration. Use Build the Lever only for a demonstrated missing narrow print-capture control. Prove It Works requires actual native actions, real workbook bytes, and print artifacts from the owned production candidate; source inspection or an archive hash cannot replace them.

Keep baseline, failed/unavailable, and final observations separate. The same draft PR #1511 receives the authorized slice after verification. No merge, deployment, database reset or historical evidence cleanup is included.

Robert's latest instruction supersedes the earlier ready-and-monitor authorization. Finish local acceptance and independent review, preserve the required evidence, push the final changes to the same draft PR #1511, and stop. Keep the PR draft. Do not start CI or bot monitoring. Do not rebase unless necessary to push the completed changes. Changes from phase 8 stabilization remain a later integration task; do not proactively integrate current main. No merge or deployment is authorized.

The final scoped source and expanded v7 artifact review accept local handoff at `8cdd5310` against integrated `ee1ca2b2`. Current-main governance remains blocked. Final documentation and artifact successors require integrity review before the authorized draft push. Prove It Works preserves actual native receipts and workbook/PDF bytes, verifies fresh expanded inventories, and distinguishes these checks from current-main semantic acceptance.
