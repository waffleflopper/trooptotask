# Issue 1501 final observations

Production app at http://127.0.0.1:44825. Revision 4d1f1dec6f96b6892245522fa3dfefd5cf4c7fae plus the source changes. Candidate b1f29a4ec4f8769735c3642790fcb529007d95bb85c24fa21ce67fef32c74136. Node 24.21.0, npm 11.19.0, Chromium 152.0.7977.82, Supabase CLI 2.101.0. Owned worker 1. Doctor accepted and doctor before cleanup both PASS with the same digest. Owned cleanup PASS. No executable or driving-input edits during this accepted drive.

## Native Policies actions

orgOwner / page 2 opened Policies. Retention 36, warning 180, goal 90. Goal help matches issue1501. Filled0,101,blank,90.5 in sequence. Each showed an invalid spinbutton whose description contains the whole number error; goal Save disabled and Unsaved changes. Filled85, clicked goal Save, reloaded; goal 85/Saved, other cards unchanged. Screenshot policies-goal 85.png.

Armed a one-shot before provider admission  503 and feedback observer. Filled80, clicked Save. Failed-to-save toast, draft 80/Unsaved, enabled and focused Save. Readback remained85. Restored network control, pressed Enter on focused Save. Goal 80/Saved and success toast. Filled90, saved and restored feedback observer. Invalid screenshot reentered90.5 and captured field error, then restored draft90 without a write. This is client failure recovery, not a provider-transaction failure.

orgAdmin / page 4 opened goal 90. Native fill86/Save/reload showed86/Saved. Native fill90/Save restored the original goal. orgMember / page 5 opened Policies and saw permission denial, no editable controls. Direct ordinary authenticated member POST returned 403. Owner POST to foreign OrganizationB returned 404. Both Organizations and neighboring saved fields remained exact after denial/restoration.

Separate ordinary API negative probes for0,101,90.5,null and string90 each returned 400. These are API validation proof, not native input actions. SQL independently covers admitted bounds1/100 and admin/owner/member/foreign RLS. Component tests cover pending edits, target disposal and linked validation errors; those additional timing paths were not independently executed in this browser run.

## Native Training reports

trainingConfigure / page 3 initial report 25%,1 Current,0 Expiring,0 Expired,3 Not Done. Native Import first used an incorrect Date or Status header; preview refused the missing Date / Status column and disabled Import. Nothing was written. Back and corrected the header to Date / Status. Baker Required completion2024-10-03 and Able Targeted completion2025-10-18 were both selected valid rows. Native Import returned Inserted 2, Updated 0, Exempted 0, Errors 0.

Done, Reports, reload. Report 50% across 3 people,1 Current,1 Expiring,1 Expired,1 Not Done. Required 33%, Targeted 100%, Alpha 100%, Bravo 0%, Unassigned 0%. This independently corresponds to2 ready / 4 applicable. Native Alpha click yielded100% across 1 person and 1 of 3 personnel. Pure tests separately prove yellow and orange ready, expired/missing nonready and exempt/N/A/optional exclusions. Yellow-boundary live execution was not added.

Native report Export produced training-report.xlsx with the three saved A rows and no foreign row. Workbook inspection shows Able current2027-09-26,Targeted15dleft2026-10-18, Baker expired2025-10-03,Unassigned NotDone and applicable N/A cells. Status labels remain distinct from readiness.

## Organization export consumer

Owner used native Settings Exports buttons for JSON and Excel independently. Exact observed200 responses and actual downloaded bytes/filenames/hashes are retained. organization.json has twelve Organization-profile fields including training_readiness_goal_percent 90. Raw - Organization Profile sheet has twelve fields and numeric 90. Raw profile values match readback; no neighboring policy changed. Export lifecycle rows are retained separately. No claim that unrelated export sections or full-map features were reverified.

## Restoration and review

Restored goal 90 through native saves. Deleted only the two newly imported records using each native Edit/Delete/confirmation dialog. Reload showed initial missing cells; ID-based/readback inventory retains only the original current Training row. Restored all network, feedback and export hooks, ran clean-seeds, final doctor and owned cleanup. Evidence survived cleanup.

Claude Opus5.5 medium reviewed actual desktop light screenshots and companion snapshots, not independent live execution. Clean visual/accessibility verdict. Dark/narrow layouts and spinner appearance were not captured. Independent Codex review covered source and later expanded evidence separately.

Startup files launch.json, launch-final.json, restart.json, doctor.json, doctor-final.json, owner-actor.json and pre-review-cleanup.json precede accepted proof and are superseded. In particular doctor.json=STALE_CANDIDATE and doctor-final.json=OWNERSHIP while restart was running. restart-accepted.json and doctor-accepted.json begin accepted proof; doctor-before-cleanup.json closes it. These earlier attempts are not passing evidence.

No remote database was accessed or changed. Verification used audited owned disposable local lifecycle scripts and synthetic fixtures. Remote application of the new migration remains a release obligation.

