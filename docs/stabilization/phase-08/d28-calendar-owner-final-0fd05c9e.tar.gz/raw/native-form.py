import sys,pathlib,json,subprocess,re
r=pathlib.Path(__file__).resolve().parent
label,page,fields=sys.argv[1:];page=int(page);fields=json.loads(fields)
def run(label,name,arg):
 p=subprocess.run(["python3",str(r/"run.py"),label,"v","tool",name,json.dumps(arg)],capture_output=True,text=True)
 if p.returncode:print(p.stdout,p.stderr);raise SystemExit(p.returncode)
 return json.loads((r/(label+".out")).read_text())
s=run(label+"-before","take_snapshot",{"pageId":page});text="\n".join(x.get("text","") for x in s["content"]);elements=[]
for target,value in fields:
 lines=[x for x in text.splitlines() if target in x and re.search(r"uid=[0-9_]+",x)];assert len(lines)==1,(target,lines)
 elements.append({"uid":re.search(r"uid=([0-9_]+)",lines[0]).group(1),"value":value})
out=run(label,"fill_form",{"pageId":page,"elements":elements,"includeSnapshot":True});print("\n".join(x.get("text","") for x in out["content"]))
