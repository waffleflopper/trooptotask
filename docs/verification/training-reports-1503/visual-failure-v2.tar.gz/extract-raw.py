"""Extract raw T3 preview tool calls/results and captured Blob bytes from this
acceptance session transcript into the 1503-final evidence directory."""
import base64
import hashlib
import json
import pathlib
import sys

transcript = pathlib.Path(sys.argv[1])
evidence = pathlib.Path(sys.argv[2])
redactions = [line.strip() for line in pathlib.Path(sys.argv[3]).read_text().splitlines() if line.strip()]
raw = evidence / 'raw'
raw.mkdir(parents=True, exist_ok=True)
downloads = evidence / 'downloads'
downloads.mkdir(parents=True, exist_ok=True)


def redact(text):
    for secret in redactions:
        text = text.replace(secret, '[REDACTED-JWT-TAIL]')
    return text


uses, results = {}, {}
for line in transcript.read_text().splitlines():
    entry = json.loads(line)
    content = entry.get('message', {}).get('content')
    if not isinstance(content, list):
        continue
    for block in content:
        if block.get('type') == 'tool_use' and block.get('name', '').startswith('mcp__t3-code__preview'):
            uses[block['id']] = {'timestamp': entry.get('timestamp'), 'tool': block['name'], 'input': block['input']}
        elif block.get('type') == 'tool_result' and block.get('tool_use_id') in uses:
            results[block['tool_use_id']] = {'timestamp': entry.get('timestamp'), 'content': block.get('content')}

index = []
for number, (use_id, use) in enumerate(uses.items(), start=1):
    result = results.get(use_id)
    record = {'n': number, 'toolUseId': use_id, 'call': use, 'result': result}
    name = f"{number:04d}-{use['tool'].removeprefix('mcp__t3-code__')}.json"
    body = redact(json.dumps(record, indent=1, ensure_ascii=False))
    (raw / name).write_text(body)
    index.append({'file': f'raw/{name}', 'n': number, 'tool': use['tool'], 'calledAt': use['timestamp'],
                  'resultAt': result and result['timestamp']})
    blocks = result['content'] if result and isinstance(result['content'], list) else [{'type': 'text', 'text': result['content']}] if result else []
    for block in blocks:
        if block.get('type') != 'text':
            continue
        try:
            value = json.loads(block['text']).get('value')
        except (ValueError, AttributeError):
            continue
        if not isinstance(value, dict) or 'blobs' not in value or 'exportName' not in value:
            continue
        for position, blob in enumerate(value['blobs'], start=1):
            data = base64.b64decode(blob['b64'])
            digest = hashlib.sha256(data).hexdigest()
            target = downloads / f"{value['exportName']}-{position}.xlsx"
            target.write_bytes(data)
            index.append({'download': str(target.relative_to(evidence)), 'sourceRaw': f'raw/{name}',
                          'bytes': len(data), 'sha256': digest, 'browserSha256': blob['sha256'],
                          'match': digest == blob['sha256'], 'filename': blob['filename'], 'type': blob['type']})

(evidence / 'raw-index.json').write_text(json.dumps(index, indent=1))
print(json.dumps([item for item in index if 'download' in item], indent=1))
print(f'{len(uses)} preview calls, {len(results)} results')
