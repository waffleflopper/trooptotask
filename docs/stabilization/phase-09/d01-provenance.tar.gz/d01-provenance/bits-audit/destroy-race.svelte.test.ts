// @vitest-environment happy-dom
import { flushSync, tick } from 'svelte';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render } from '@testing-library/svelte';
import Harness from './Harness.svelte';

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function run(kind: 'popover' | 'menu' | 'alert', act: () => Promise<void> | void, delay: number) {
	const warns: string[] = [];
	const spy = (...a: unknown[]) => warns.push(a.map(String).join(' '));
	const w = vi.spyOn(console, 'warn').mockImplementation(spy);
	const e = vi.spyOn(console, 'error').mockImplementation(spy);
	try {
		const r = render(Harness, { kind, show: true });
		await tick();
		await sleep(30);
		await act();
		await r.rerender({ kind, show: false });
		flushSync();
		await tick();
		await sleep(delay);
		return warns.filter((m) => m.includes('derived_inert'));
	} finally {
		w.mockRestore();
		e.mockRestore();
	}
}

describe('destroy races (derived_inert)', () => {
	afterEach(cleanup);

	it('dismissible layer: unmount right after open (registration timer)', async () => {
		const r = vi.spyOn(console, 'warn');
		r.mockRestore();
		const warns: string[] = [];
		const w = vi.spyOn(console, 'warn').mockImplementation((...a) => warns.push(a.map(String).join(' ')));
		const view = render(Harness, { kind: 'popover', show: true });
		await view.rerender({ kind: 'popover', show: false }); // immediately, before afterSleep(1)
		await sleep(40);
		w.mockRestore();
		expect(warns.filter((m) => m.includes('derived_inert'))).toEqual([]);
	});

	it('dismissible layer: focusin outside then unmount before tick', async () => {
		const out = await run('popover', () => {
			document.getElementById('outside')!.dispatchEvent(new FocusEvent('focusin', { bubbles: true }));
		}, 40);
		expect(out).toEqual([]);
	});

	it('menu: item focus/blur then unmount before tick', async () => {
		const out = await run('menu', async () => {
			await fireEvent.keyDown(document, { key: 'ArrowDown' });
			const item = document.getElementById('item1')!;
			item.focus();
			item.blur();
		}, 40);
		expect(out).toEqual([]);
	});

	it('menu: keyboard content focus then unmount before tick', async () => {
		const out = await run('menu', async () => {
			await fireEvent.keyDown(document, { key: 'ArrowDown' });
			(document.querySelector('[role="menu"]') as HTMLElement).focus();
		}, 40);
		expect(out).toEqual([]);
	});

	it('alert dialog: unmount before delayed autofocus (afterSleep 0)', async () => {
		const warns: string[] = [];
		const w = vi.spyOn(console, 'warn').mockImplementation((...a) => warns.push(a.map(String).join(' ')));
		const view = render(Harness, { kind: 'alert', show: true });
		await view.rerender({ kind: 'alert', show: false });
		await sleep(60);
		w.mockRestore();
		expect(warns.filter((m) => m.includes('derived_inert'))).toEqual([]);
	});
});
