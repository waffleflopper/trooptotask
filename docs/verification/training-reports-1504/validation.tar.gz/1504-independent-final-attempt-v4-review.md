# Independent expanded final-attempt-v4 artifact audit for #1504 / PR1511

Bounded nonvisual artifact PASS for packaging, corrected print page metadata/content, the disconnected-pager positive/negative cases, dated workbook scope and exact recorded restoration at **53ab7cc9997746e243817fb4a283d99b0d3a0825**. **F1 remains OPEN at that live pin**. Activating the checked 25 radio leaves both page-size choices unchecked. The source correction is independently accepted at a586 in the companion source report, with fresh v5 native evidence pending. This audit does not close #1504 or certify final current-candidate acceptance.

## Bound authority and independence

AGENTS.md, t2t-engineer, DoD, TESTING.md, operating rules and supplied Poteto generic persona/Prove It Works/Test Behavior, Not Implementation leaves govern this lane. Prove It Works changed the method to actual expanded bytes, structured native receipts, real PDF metadata/text and actual XLSX ZIP/XML instead of driver summary or decoded helper output. Test Behavior, Not Implementation changed the comparison to independent fixture counts, row identities, canonical selection, request effects and focus outcomes. The parent restricts this lane to source/artifact review and its two named outputs plus exclusive scratch.

No browser, services, tests, gates, network, SQL, Git mutation, source/docs modification, external write or subdelegation occurred. Offline read/parsing used actual filesystem and pinned Git data. The inherited parent model supplies independent acceptance reasoning, not model diversity. Artifact review is not independent execution. No images or rendered PDFs were viewed or judged. Claude's image/layout/legibility/color judgment stays explicitly delegated.

## Exact source, runtime and durable package

| Binding | Actual value |
| --- | --- |
| V4 tested source | `53ab7cc9997746e243817fb4a283d99b0d3a0825` |
| V4 intended base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Candidate | `cda447f1b0c72e03fde477fcc68d99ef14b52f0e28afafbea842240256c29e90` |
| Session | `626b9a39-ff2e-479b-9be6-897f1a3b2a1b` |
| Origin / environment | `http://127.0.0.1:34603`, worker 1, production-mode owned synthetic verification environment |
| Browser | `/usr/bin/chromium`, Chromium 152.0.7977.82 Arch Linux |
| Actor / native page | trainingConfigure in Organization A, page 2 |
| Archive | `docs/verification/training-reports-1504/final-attempt-v4.tar.gz` |
| Archive bytes / SHA256 | 7392445 / `81af91ee6e2fec495d5426d71e35f0c61e2dfae1a32e5e07c5b1949ae3220d98` |
| Expanded tree actually read | `.verification/packaged/1504/final-attempt-v4/` |

I independently parsed the inventory and all archive member bytes. There are **1156 unique payloads**, plus inventory.json. Expanded file set exactly equals that inventory plus itself, every SHA256 agrees, every tar payload equals the actual expanded file, and no special archive entries exist. Native receipts have unique names and survive cleanup. Actual root-source-checkpoint's 142 recorded file/deletion pins match Git blobs at 53ab, including absent states. Later archive/selection commits are not falsely assigned to this run.

Archive integrity is packaging proof, not application behavior. The expanded observations are separately assessed below. The complete current source census and byte continuity through a586 are in `.verification/1504-independent-final-source-review-v2.md`. V3/v2/v1 findings and limits stay at their original pins unless this attempt covers the same failed path.

I read actual root-launch/info/doctor-start/doctor-closeout, native tools, fixture rows, source checkpoint, correction continuity, gate binding, restoration, owned cleanup and owned absence receipts, and `.verification/1504-final-attempt-v4-closeout.json`. Launch, start doctor, driver final doctor358 and root closeout doctor agree on revision/candidate/session/origin. Root's cleanup receipt is PASS and its exact owned identity absence record is read as captured historical evidence, not my live process inspection.

## Receipt accounting and action limits

I parsed **460 distinct index records and all 460 stdout JSON results**, with no parse failure. Index records have **456 exit0 / 4 exit2**. The underlying stderr and actual relevant results/snapshots were inspected. A shell wrapper prints an exit summary and always exits0; the durable index's recorded inner exit code is the action result used here.

The four failed commands are preserved and separately repaired. `088-click-clear` has a two-UID argument; waits089/091 consequently fail. The resulting093 PDF is truly an empty Bravo+Targeted dark repeat. Corrected94–100 creates the actual unfiltered dark-r1. `338-click-confirm` has empty UID;339 reports no DELETE calls, so that is not a deletion. The repaired visible confirmation344–350 yields DELETE200 and restored rows.

Native tool actions and read-only evaluate_script observations remain distinct. Programmatic observations read DOM/response state; they do not drive app handlers. Native command exit0 does not by itself prove an end-user effect. Alt+T293 occurs after expiry and does not focus notifications; Alt+T300 with the modal open also leaves focus on Save. Those are attempts, not successful shortcut outcomes. The repaired modal-closed306–307 establishes the limited successful path. Expected negative tool rejections in inherited evidence likewise are rejection proof, not successful user work.

## Independent literal expectations and actual data

The root's original synthetic People/types/completions were read directly. Required applies to Able, Baker and Unassigned. Targeted applies only to Able. Optional is excluded. There are four required applicable pairs. Original Able Required is current; the other three pairs are missing. Expected readiness is **1/4 = 25%**, Ready1, expired0, missing3, lapses0, horizon25%. Actual007 snapshot agrees. Original Required Total is33%, Targeted0%. **Alpha's aggregate is50%**, with Required100% and Targeted0%. Driver shorthand "Alpha100/0" means those two type cells, not aggregate100→0.

Actual native Reports navigation005 and network008/013 support the initial server-loaded report without a duplicate report-summary fetch in the observed list. Original Total Required cell009 produces Baker/Unassigned and SECTION focus011. Original Targeted Focus014 produces only Able, SECTION focus016, and a Focus-key URL/request in018. These selectors are distinct and use the server model; no URL record-ID list is involved.

Native CSV import uses the actual two-row p2-import.csv and valid preview026. Before import027 leaves provider count1. Actual032 records POST200 for both Person IDs, and full038 provider rows preserve the original completion plus exactly two created rows.

| Dated requirement | Actual completion / expiration | Independently expected effect |
| --- | --- | --- |
| Baker Required, ID a6436f5f-acb5-4c17-9f69-ecbd5c919c57 | 2024-10-04 / 2025-10-04 | Expired365d on fixture date2026-10-04. Not ready; no future lapse. |
| Able Targeted, ID3cebfc94-d159-4493-ae7a-d2c03ee8c6d3 | 2025-10-19 / 2026-10-19 | Warning/orange15d left, ready now; first expired day2026-10-20 is within horizon. |
| Original Able Required, ID8e94ca6f-1b40-44e1-987f-25dd96a9e460 | 2026-09-27 / 2027-09-27 | Ready and remains ready through2027-01-02. Every original field/timestamp unchanged. |

Dated expected values are2/4 =50% today and1/4 =25% at horizon, expired1/missing1/lapse1. Actual041 snapshot agrees. Required risk2/0 precedes Targeted0/1. Required Total detail orders Unassigned missing before Baker expired; actual047 narrow Alpha Targeted detail is only Able,15d left, Oct19, Yes. Alpha aggregate is100→50; Targeted cell is100→0/drop100. The three affected full-scope requirements are Unassigned Required, Baker Required and Able Targeted.

Three helper-seeded cohorts have actual receipts163/200/228, counts26 and distinct tags c984f780 /5096298a /d9b04329. This is documented synthetic fixture setup, not a concurrent real user or Organization/session race. Each adds26 Required plus one extra applicable Targeted pair. Thus29 people/31pairs, Ready2, expired1, missing28, lapse1, rounded6→3. Required affected total28, with25 first-page seed rows and page2 seed25/Unassigned/Baker. The actual seeded snapshots/detail rows and long PDF agree. No duplicate/omitted row is implied from merely counting tbody nodes; actual row identities/order were read.

These fixtures produce two Focus areas. Dated full scope has Required standing gap25→75 and Alpha row drop50→100. Seeded full scope has Required3→94 and Targeted3→10. They support literal model values and drill-down scopes, not a fresh four-candidate maximum-three/overlap proof. That remains meaningful unchanged source/test coverage at its earlier pins.

## Disconnected pager, normal paging and real native Retry

| Path | Actual native action and read observation | Bounded conclusion |
| --- | --- | --- |
| Shrink positive, cohort1 |182 shows enabled Next, Rows1–25 of28.183 journal-clean removes seeds without reload.188 native Enter with held response.189 shows Next active, busy, Loading page2, honest old range.191 release;193 SECTION, Rows1–2, no pager.198 actual request page=2 has200 and body page1/totalPages1/totalRows2/pageSize25 with Unassigned/Baker. | Prior source-derived disconnected-pager failure is covered at53ab. |
| Shrink no-steal, cohort2 |213 Enter while held;214 Shift+Tab and216 ArrowRight move focus to100 without selection.217/218 show that radio active with old data.220 release;222 retains100 focus, two rows/no pager.227 real page=2 body is clamped1/1/2. | Recovery does not steal focus from the user's moved control. It does not establish checked-state correctness; F1 is visible separately. |
| Ordinary boundary Next, cohort3 |242 native Enter;243 held old first page;244 release;246 SECTION, Rows26–28 of28, Next disabled.247 actual three rows are seed25, Unassigned, Baker. | Ordinary last-page recovery retains exact data identity. Middle-page behavior is not newly exercised by a two-page fixture. |
| Previous synthetic503 |252 native Enter under an injected fail.254 keeps Previous active, old Rows26–28 and honest error/Retry.255 records injected503. | Client failure preserves last loaded page/range; not a real backend outage or native-network503 claim. |
| Retry |260 native Enter on Retry while held;261 SECTION focus, Loading page1 and old Rows26–28.262 Tab moves to25 radio;263 and266 preserve that radio after release with Rows1–25.268 native network list has final page1 GET200. | Explicit Retry focus and user-moved-focus preservation are established in this owned synthetic path. |

No independent reviewer browser execution occurred. Structured focus/range/response facts cannot certify responsive layout, clipping or screen-reader speech. V4 does not newly cover every late-response/scope/session race or all original filters. Existing source and earlier observations remain qualified.

## Actual downloaded workbook ZIP/XML

I independently read the actual11859-byte `accept/xlsx/dated-unfiltered-detail-open.xlsx`, SHA256 `ddc606068653569c82bf4ff76d193fd9649d32640160ccc8417a43b906570a11`. I parsed workbook.xml, relationships, shared strings, every cell of all five worksheets and formula elements. No supplied decoded JSON or app calculator was the expected oracle. Native export action051 plus053 real GET200/MIME/disposition and054 save bind the downloaded bytes. The active Alpha×Targeted detail has one row, while this all-filtered export has three.

| Ordered sheet | Actual literal facts |
| --- | --- |
| Summary | OrgA,3 people, as-of2026-10-04/horizon2027-01-02/goal90,50→25/drop25, ready2/applicable4/expired1/missing1/lapse1; full all-default filters. |
| Forecast | Today plus13 weekly endpoints.2ready/50% onOct4,11,18.1ready/25% fromOct25 throughJan2. Only19–25Oct bucket has1lapse; others0. Last bucket28Dec–2Jan is short/exact. Cliff flags No. |
| Hot spots | Bravo0→0, Unassigned0→0, Alpha100→50, Total50→25. Required total33%/drop0, Targeted total100%/drop100. Blank inapplicable cells are not0% requirements. |
| Focus | Required standing gap25→75 with2 soldiers/2requirements; Alpha Targeted row drop50→100 with1/1. Literal templates and what-if values agree with independently derived counts. |
| Requirements | Exactly Unassigned Required Not Done, then Baker Required Expired365d/2025-10-04, then Able Targeted15d/2026-10-19/lapse2026-10-20/Yes. No optional, N/A, foreign, current-Able-Required or active-detail narrowing. |

There are no formulas. Export's full-filtered scope, ordered five sheets and literal values agree with the same displayed dated briefing. This is a three-row native transport/scope smoke, not fresh >25 unpaginated export or separate Person export/access-role proof. Earlier v3/v1 books keep their independent actual-byte audits and exact old candidates.

## Native print invocation and actual PDFs

For all ten cases I read arm, pre-print snapshot, native Print brief click, **observer state before save**, structured list_pages, save and restore receipts. Each click has no tool error, page2 has one exact matching full URL, pre-save beforeprint is1/afterprint0, and state occurs before capture. Save's candidate/session and actual bytes/hash agree. PDF capture itself can emit events, so only the pre-capture event supports native invocation.

I ran offline pdfinfo and pdftotext on the real files, separately checking every page's size and extracted text. These are artifact reads, not browser/test execution. All **26 pages are792×612 landscape** and every page has nonblank extracted content. No portrait/textless surplus page remains. This supports correction of the prior measurable page-count failure. It does not independently assert raster blankness, clipping, color/contrast, layout or paper legibility.

| Actual PDF | Native prefix | Pages | Bytes / SHA256 |
| --- | --- | --- | --- |
| `active-toast-dated-light.pdf` | `317` | 3 | 173154 / `67ab2bc5d58e859a53c8f91f69b0ab3473075bef35a15d596750eedb984c1a77` |
| `alpha-detail-open-light.pdf` | `120` | 3 | 177720 / `d5e21cd2e12077f72fae90f5a558d739508f75c21903f78d25f6624e46014cb5` |
| `dated-unfiltered-dark-r1.pdf` | `100` | 3 | 173147 / `af52fc4142a9bc934ae4b21910357952783065480b67647612577fb551690d70` |
| `dated-unfiltered-dark.pdf` | `093` | 1 | 70094 / `82b254687869d39a883f7e7112f6cb030267a5b45dff4db450b5707531e8c1e4` |
| `dated-unfiltered-light.pdf` | `107` | 3 | 173154 / `eb44c8c15c84eaa9c779c48d720befb0bb01de13c2a85040efb7b1e71be00bf9` |
| `empty-bravo-targeted-dark.pdf` | `086` | 1 | 70094 / `71ddee3d48746f8d34ef402f1a74e3798208a0a9602acd11d187896ff49fbfbc` |
| `empty-bravo-targeted-light.pdf` | `077` | 1 | 70094 / `eef45bc283bc06dbc175c802a1a6c1bfdfee5a7cae5107b080fcda78dbd29c3d` |
| `failed-refresh-alpha-light.pdf` | `134` | 3 | 171388 / `b046a32dca82708e6942635d33e3e34c6d525ea2e3141f5be4daed69cc2557df` |
| `seeded-25-row-detail-light.pdf` | `171` | 5 | 262902 / `7e3c013674716e35e395f646eb98e2bd2dbfc94a6e30df0ab3a6eed1f28c9eab` |
| `wide-1920-collapsed-light.pdf` | `147` | 3 | 173397 / `fc24ff8a74b945c1a95bdfa8a1216468709919c2acce1a42da4d095dcb391579` |

The empty light/dark cases contain the OrgA1soldier title and Bravo/Targeted/90/Group filter line plus the honest no-applicable message, exactly one page each. `dated-unfiltered-dark.pdf` is also that empty state, confirmed by its actual filter URL and text; it is not unfiltered dark proof. `dated-unfiltered-dark-r1.pdf` is the repaired actual unfiltered3-page dark case. No failed capture was overwritten or renamed into success.

Unfiltered light, repaired dark, wide-collapsed and active-toast cases contain50→25, counts2/1/1/1, forecast goal90/endpoints, total/grid values, risks2/0 and0/1, and the two Focus what-ifs. Alpha-open-detail prints100→50 and the one loaded Able Targeted affected row/range1–1. Failed-refresh prints the actual503 alert with displayed Alpha filter/100→50 facts and no Retry. It does not silently print attempted Bravo as the shown data. Long seeded print contains29people/6→3/2,1,28,1, range1–25 of28 and **exact seed rows00–24**, over five pages; seed25/Unassigned/Baker are not falsely included as loaded rows.

All actual PDF text lacks action/chrome/toast labels such as Export Excel, Print brief, Retry, Clear filters, Rows per page and Synthetic request failure. Required filter text legitimately retains Rows by. Before active-toast capture,317-b snapshot contains two visible Synthetic request failure toasts;318 still reports two afterwards. Actual active-toast PDF text contains neither. Image/raster omission is Claude's separate visual assessment, not independently judged here.

`.verification/1504-final-acceptance-v4-report.md` and packaged acceptance-report contain Claude's page-by-page visual PASS at53ab for the short/light/dark/long/narrow/error/wide/toast variants. I inspected the report's actual text, but did not view its screenshots or PDF renders. The report calls F1 minor/non-blocking; this independent composed acceptance retains it OPEN at the old live pin. Delegated visual PASS does not imply whole current-candidate acceptance.

## Toaster keyboard and chart recovery limits

The real failed-save journey is a native edit/save with an injected personnel-trainings POST503.290 observes the actual contents wrapper, Notifications live region, toast list and visible error. Draft retention is preserved; Cancel discards the draft. Actual313 full provider rows keep original completion8e94ca6f, null notes and exact updated_at unchanged.

First Alt+T293 is a no-op after toast expiry. Alt+T300 occurs with a toast but open modal;301 leaves Save active. After the bounded close-modal repair,306 Alt+T and307 actual focus show OL[data-sonner-toaster], tabindex−1, inside Notifications and the wrapper, with dialogOpen false and two toast texts. This establishes only modal-closed keyboard operation. Modal-open shortcut is UNESTABLISHED; the focus-trap explanation remains supported inference rather than proof of every modal interaction.

Actual101 console after the1905 expanded repaired dark print includes LayerCake zero/negative-width warnings and negative rect-width errors. They remain present.148/172 wide/long consoles have only the recorded CSP/Vercel404/MIME/preload noise.149/153/157 show subsequent rendered chart state and native horizon180 then90, URLs and26→13 bars, with no negative widths in those specific observations. I use these as bounded recovery/state observations, not geometry tests or visual judgment. Claude observed no PDF impact. No clean-console claim or verified warning cause is made.

Sidebar collapse fails to survive reload in139–142;143 recreates collapse for the actual wide print. This behavior is outside #1504 and its relevant source is unchanged. It is not silently accepted as fixed.

## Exact recorded restoration and owned cleanup

I compared every parsed field and full-file bytes for original/restored **personnel_trainings, training_types, training_views and organizations, each A/B**. All eight root pairs are byte-identical; all eight actual driver357-final values equal those same originals. trainingConfigure preferences/progress[] match exactly both root and driver, for nine comparisons. This is the recorded scope, not every product table/account.

| Restored root scope | Equal full-file SHA256 |
| --- | --- |
| `personnel_trainings` / `orgA` | `7dbfdc21716b19561152b1646f443fb2ff9e7803f240d3a4e19099a9f704fdbe` |
| `personnel_trainings` / `orgB` | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| `training_types` / `orgA` | `c52a9fe7c0e07723baa4ff276910b570c96b347a930a7bb40080797d94c20395` |
| `training_types` / `orgB` | `171ad2aae6b0cc68d168fd6ba21caabb46c08c7c417cd701aa2e6f21ff800e51` |
| `training_views` / `orgA` | `7160c5fb7b15114b96922181f8f076da97b257e6a29a5df6038e1eca97996a72` |
| `training_views` / `orgB` | `40d91aacf7beeddde8aae3ab189feca514d1b34f5d4c668ba31446560713ddc3` |
| `organizations` / `orgA` | `366a57c5413aff1c96c521deef777182a3e918ff69cd3fd81b7767a60a8da070` |
| `organizations` / `orgB` | `61101e8566c5e91ba17aac6d14f14e0f634410d220f86267c115e5854c73ede5` |
| trainingConfigure preferences/progress | `05712c2d9bea88219ad88746bcebcd9350b110d37f69c8093f80b21bee05fb0d` |

Visible imported-record deletion329/350 records two DELETE200 outcomes; failed338/339 does not. Final matrix354 returns to the original. Cohorts are cleaned at183/210/276 and root clean-seeds confirms cleaned/artifactHttpSessionsCleared. Exact original IDs, date values, notes/certificates and timestamps are retained. Final356 controls report network unarmed/calls empty/heldfalse; export uncaptured; print unarmed/before0/after0; feedback unarmed/entries empty.

Browser state is not byte-identical. Original003 has no theme key/sidebar cookie or SvelteKit session keys. Final355 has new localStorage theme=light, sidebar:state=true and snapshot/scroll keys, while viewport1905×2053/light/system/expanded and cleared filters/horizon90 are restored by native controls. Root audit explicitly records the additions. The private profile is subsequently destroyed; no exact browser-key restoration claim is made.

Final doctor358 and root closeout doctor bind the original revision/candidate/session. Actual root-owned-cleanup records PASS/cleaned. root-owned-absence binds supervisor3671416, app3686212, MCP3686260 and browser3686339 by each PID/start/full-command hash, exact-owned absence true, no private-profile processes, absent private worker directory and preserved payloads. I read these captured receipts; I did not interrogate currently running processes. Later newly launched v5 resources are outside this historical cleanup claim.

## Privacy and preserved limits

I scanned all1157 expanded files, actual extracted PDF text and decoded workbook cell XML for JWT/bearer/private-key and concrete access/refresh token-value patterns. No remaining candidate was found. Native request headers show cookie redacted. Public fixture and provider rows contain synthetic values; the package contains no new unredacted token values in the inspected scope. This is a concrete pattern/content audit, not a universal secret absence guarantee or visual-image privacy judgment.

V4 does not repeat the full role/isolation matrix or retained Personnel/Dashboard/Person-export consumers. Their prior source and v3 actual artifacts keep their own pins, qualifications and unavailable independent lanes. Full Onboarding/raw Organization write flows, full feature map, Organization/session timing races, many-type print, unchanged-page rendered print, modal-open Alt+T, current hosted CI/review and remote/RLS/release checks remain UNRUN here. No malformed400 substitutes for403/404 admission; no saved artifact infers unexecuted database enforcement.

The unchanged484-byte goal SQL and its separately operated remote release obligation remain explicit in the companion source report. No SQL was executed or authorized remotely. Native print events/rendered PDF evidence do not establish a system dialog, physical printer or deployment.

## Findings and final disposition

| Finding | Severity / actual pin | Disposition |
| --- | --- | --- |
| Active25 radio becomes unchecked | P2 consequential accessible-state defect at53ab | OPEN in v4.234 snapshot checked,235 real native click,236 neither checked;237 keeps25-row range;238 has no extra request. Same defect is reproduced for all three controls at the component boundary. Source correction accepted only at a586; fresh native v5 repeated pointer/Space and dependent reload/export/print smoke pending. |
| Previous disconnected pager focus loss | Old P2 at0683 | V4 actual clamped request/response, SECTION recovery and moved100 no-steal cover the exact edge at53ab. Closed for the tested slice, with source continuity through a586. |
| Surplus portrait/textless print page | Prior accepted print failure | Actual v4 short1/long5 landscape metadata/content plus delegated visual PASS cover the affected prior short/long/variant paths at53ab. No current-selection smoke substituted. |
| LayerCake/negative rect print warnings | Preserved observed limitation | Cause unresolved; delegated no-observed-impact and specific recovery proof only. No clean console or independent visual clearance. |
| Mislabeled PDF and failed/no-op actions | Evidence qualification | Preserved exact failures; repaired actual dark-r1 and deletion exist. Qualified actions are not counted as successful user effects. |

No additional actionable data, workbook-scope, source-delta or packaging defect was found in this bounded artifact audit. Final source acceptance and final live evidence are separate. Pending v5 evidence is not a fabricated source bug, and passing unit checks do not close the old live F1.

## Selected actual observation hashes

The inventory binds all1156 payloads. These additional bindings make the decisive actual observations easy to locate after extraction.

| Expanded relative path | Bytes | SHA256 |
| --- | --- | --- |
| `inventory.json` | 166210 | `8da1845d2bca596f402ac7dc3bcd0e71c88c72f09fb156ba721c048c783088c6` |
| `root-source-checkpoint.json` | 34400 | `3cc19411e75eb9ca0bc22c1317b62404fe095959f6448ccf1740385a099325b2` |
| `root-doctor-closeout.json` | 391 | `22537fc2b1d3391f68417a68afcf827f8be926b189271161b658cfeb8dcb585d` |
| `root-restoration-audit.json` | 1299 | `f53404dcf6dcae3e35e63df8fd8c873f08a2a19ca0c97b637f5aaa123b197ab9` |
| `root-owned-cleanup.json` | 160 | `43b8a7db6331e3cd3333eaaf11a20b57f351b4ec57e2a5dba872a5686bfa5b05` |
| `root-owned-absence.json` | 1119 | `f8cc5cdd67689566dbdc7601061bc631faaf64af86e5220ca933d1ea4a2c0baf` |
| `accept/receipts/index.jsonl` | 220648 | `378bf8bf83a6354146e376711951efe64d2d58d710c8ac2553af84b89fbe67ee` |
| `accept/snaps/007-report-original.txt` | 9996 | `47dd5aba6393e3f455808652592cf587890a86dcc6e4271575f251066d9af376` |
| `accept/snaps/041-report-dated.txt` | 10217 | `68d9ef2d40900ff7221574fb7da0355866655f0817c9763ba3d270904bad5be4` |
| `accept/snaps/234-before-25-click.txt` | 19389 | `33e7ddc4399f018705e41651aea898ff06d063d55dbfef167c44a736bfb9a84f` |
| `accept/snaps/236-after-25-click.txt` | 19381 | `8029425fe3504cfd59dcad87a2b8b3af5bd560064220cce2048002080a394b3f` |
| `accept/receipts/198-get-request.stdout` | 5426 | `cca78292b6003c14ab745fb695835e8e20ae734e91d967ddb8e03464005811b3` |
| `accept/receipts/227-get-request.stdout` | 5426 | `ddc2d76575378e1a684f331adf55089749c7edf9da0cbfe27b5e5b73b55bd042` |
| `accept/receipts/193-focus-after.stdout` | 1491 | `7aecf75a099748e0f6fe97c5e6bca30d86dc411326d74c49c9a043c0da14d49c` |
| `accept/receipts/222-focus-after.stdout` | 1415 | `4182fedf323b227e0a35da538fd8d95d6120e00ca91bae72ea72a5064365ea9e` |
| `accept/receipts/254-after-503.stdout` | 1701 | `cebe05a2028a2bf0e54ed7581c84d110248f083eb8122fd98513e5bd62e57b7d` |
| `accept/receipts/261-held.stdout` | 1597 | `d5edfadedeb99fc66074a9f0973202706777ecabdc0fe5601d281afdd8cbe80a` |
| `accept/receipts/266-after.stdout` | 1489 | `f325381a99316c88206be4f5e1de75ea15bcc2bd875ecf95124fc480a22c1491` |
| `accept/receipts/307-active.stdout` | 747 | `79b1b25221a6a20bd4a349be224724af2f47e202104a8946a88abb243062d3d8` |
| `accept/snaps/317-b-pre-print.txt` | 10510 | `7d33cd10864afdf7eee94f8b4fe404c2bc189ca46ed11fecb5e4992b5408ce2e` |
| `accept/receipts/318-toasts.stdout` | 219 | `9a5817ed12e05cecbd0262da2a91790bd6e9a89926d670b40826a34f7b196ace` |
| `accept/receipts/101-console-after-dark-print.stdout` | 7644 | `414b5888952a15c0688104ae35cfbeed25e0234522362e18ea16f4b5e58eaead` |
| `accept/receipts/358-doctor-final.stdout` | 390 | `44445e4c135ef94e9ec689893556ad02484a6323016eebdc3eb5eff312795d18` |

All ten actual pre-capture state receipts have beforeprint1.

| Native prefix | Pre-capture receipt SHA256 | Actual save receipt SHA256 |
| --- | --- | --- |
| `077` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `99fefd024a43a3e07fc713072fdac412b81185f388b4d2c62204964bc0cb9483` |
| `086` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `098ca9d7a80e3b56d44c7c1e4d5ca590463ac2de4566bbbd6dbaf7df5b089b62` |
| `093` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `2b61cef25a0b4130e5efc9c18ec02cf697c43604d00cd4d333082c7675866c8c` |
| `100` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `a236175bdf958f26f76e22ad4387cf6f7a5c992f2a0c66d303b1626730f58fc2` |
| `107` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `8b484e76db2c091fb03f2b91ec194f33f816693a156fb5d6693adb6227e8a390` |
| `120` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `7dacd897a1c74567a9db54d3eb77cfb6a2c4219d19ec9cfaf0f66a0b344162db` |
| `134` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `77fefb733a5043efd17d842282fa35e7ae987cd964dc5f71e89671bd0fc1a702` |
| `147` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `7efacf1b44abbf07f00c55a0bb65aeb2fbdbbb1e49a273f37769ddf4571141e2` |
| `171` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `2a6046fcb108b7b35789943ac7e437fc6bc17ca5eacf43553e381fc758bf9f24` |
| `317` | `8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661` | `5a9bdd4e022f0da123da08ef1862745fafea5872de7e43990f362814e1fe0b5a` |
