#!/usr/bin/env bash
# usage: pdfr.sh NAME -> page sizes + render each page to pdfpages/NAME-N.png
E=.verification/evidence/verify-trooptotask/1504-final-v4/accept
n=$1
pdfinfo -f 1 -l 99 $E/pdf/$n.pdf 2>/dev/null | grep -E '^Pages|Page +[0-9]+ size' > $E/pdfpages/$n.info.txt
cat $E/pdfpages/$n.info.txt
pdftoppm -r ${RES:-70} -png $E/pdf/$n.pdf $E/pdfpages/$n
pdftotext -layout $E/pdf/$n.pdf $E/pdfpages/$n.txt
ls $E/pdfpages/ | grep "^$n-"
