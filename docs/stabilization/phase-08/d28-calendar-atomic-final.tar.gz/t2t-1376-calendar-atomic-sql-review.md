# D28 Calendar atomic removal SQL review

GO for the five SQL/staging paths at frozen root commit `8d225c0a318758e0d89fad10f42737ac94805277`, compared with main `4d5f8bfb5723752788f96c1666e2c12d50b47682`. Zero actionable findings. This independent read-only review did not implement these paths, query any database, run services/builds, drive an app, or alter source. The clean root HEAD was checked again after reading the full diff, full new SQL files, affected staging mechanism, existing capability/RLS helpers, and the complete local database log.

The migration at `supabase/migrations/20261006000100_atomic_calendar_availability_removal.sql:3` adds one permanent Calendar operation. It changes no retained table, saved row, constraint, or RLS policy. SECURITY INVOKER with an empty search path at lines 6–7 keeps ordinary caller permissions. Lines 12–17 require an actual authenticated user, a non-null Organization and current Calendar OPERATE membership. The existing `public.member_access_has_capability` helper at `supabase/migrations/20260502000100_remove_legacy_authorization_from_rls_helpers.sql:35` reads the membership row for `auth.uid()`, rather than trusting an earlier capability claim. That helper's established SECURITY DEFINER implementation reads membership; it does not make this new DELETE privileged.

Lines 19–24 reject null arrays, empty arrays, more than 500 raw IDs and null elements before mutation. The raw cardinality check also rejects 501 copies of one ID. UUID typing rejects malformed IDs before the DELETE. Lines 26–29 perform one Organization-filtered DELETE and return its actual ROW_COUNT. Duplicate IDs count once, replay counts zero, and one statement rolls back all selected effects if an error occurs. There is no retry, fallback, chunked mutation or partial-success acknowledgement.

The invoker operation preserves the existing visible-subset contract. The retained DELETE policy at `supabase/migrations/20260413001158_remote_schema.sql:3962` and SELECT policy at line 4126 use the Calendar row helpers. Their latest definitions at `supabase/migrations/20260926000600_calendar_unassigned_scope.sql:24` and line 38 enforce Calendar capability, same-Organization Person references, and current strict Group scope. Hidden, out-of-scope, unassigned-for-Group-scope, foreign and missing IDs do not become privileged deletions. A permitted visible subset may be deleted and counted. Empty Group scope has zero effects. The fresh SQL tests actually exercise that behavior with a Calendar-only member whose Personnel capability is NONE.

Lines 33–36 revoke execution from PUBLIC, anon and service_role and grant it to authenticated. Tests inspect effective privileges and PUBLIC ACL entries and also attempt anon/service_role execution using a claimed owner identity. Schema-cache notification at line 38 makes the new function discoverable after commit. No existing mutation permission is widened.

The new fresh contract in `supabase/tests/calendar_availability_atomic_removal.sql` proves catalog security and grants at lines 5–22, denied/empty-scope full-row preservation at lines 71–109, real mixed-subset deletion and replay at lines 111–131, capability removal, changed Group scope and removed membership at lines 133–164, invalid raw inputs and actual 500-row deletion/replay at lines 167–208, and forced statement-error rollback with complete remaining row values at lines 210–230. These are real database effects, rather than arranged adapter response assertions. The synthetic failure is an AFTER DELETE statement trigger, so the rollback check covers an error after selected row deletions have occurred.

The populated-upgrade fixture at `supabase/migration-tests/calendar_availability_removal_before.sql:2` refuses to run if the function or migration ledger already exists. It commits two ordinary Calendar-only actors in separate Organizations, historical availability dates/notes/nulls and Person/Group/status references before the held migration is applied. Lines 38–54 snapshot all fields of eight affected domain/reference rows and fail if the fixture is incomplete. The after contract at `supabase/migration-tests/calendar_availability_removal_after.sql:5` confirms migration recording, exact preservation of all eight rows, grants, foreign-Organization denial, real admitted deletion with duplicate/foreign/missing IDs, replay and exact preservation of the other seven rows. This is sufficient for this additive function-only migration. It does not claim a complete independent snapshot of every auth, Organization or membership row; the full retained upgrade suite supplies broader contracts.

The three `scripts/ci/database.py` changes at lines 65, 90 and 117 register the held migration, preceding fixture and after contract. The existing mechanism at lines 566–588 runs fixtures before restoring held migrations, applies them with local `migration up`, then runs the after contracts. Commands default to failure checking at line 451 and propagate nonzero status at lines 490–495. The review found no new staging bypass or weakening of assertions.

Actual execution evidence is `/home/waffleflops/.cache/t2t-1376-calendar-atomic-db-local.log`, 5,852 lines, 682,010 bytes, SHA-256 `e97b8cdfa5327bb508a4401d2870a0af390ec0c7f81d9a7055d489254e25d1cc`.

| Recorded proof | Observed result |
| --- | --- |
| Fresh disposable replay | 170 migrations, including the new migration |
| Retained fresh SQL | 63 suites, 1,717 assertions, all PASS |
| New Calendar fresh contract | 33 assertions PASS, log lines 140–144 |
| Retained migration regressions | 6 suites, 121 assertions, all PASS |
| Populated staged upgrade | 141 base migrations followed by held migrations |
| Retained populated contracts | 25 suites, 401 assertions, all PASS |
| New Calendar populated contract | 10 assertions PASS, log lines 3233–3249 |
| Fresh retained provider probes | Recorded success at line 1982 |
| Populated retained provider probes | Recorded success at line 5845 |
| Fresh project `t2t-ci-db-fgayvnwv` | Stopped and cleaned, lines 1983–1989 |
| Populated project `t2t-ci-db-fgp4pddb` | Stopped and cleaned, lines 5846–5852 |

No TAP `not ok` or non-PASS result occurs in the log. The logged Calendar Group conversion errors at lines 553, 556 and 559 belong to the retained deliberate rejection regression, which subsequently passes. They remain in the raw evidence. The installed Supabase CLI update notice remains visible. The existing disposable-only supautils denial-hint workaround is unchanged and leaves grants, RLS and SQLSTATE assertions in place.

The recorded provider probes exercise their retained GoTrue/PostgREST contracts. They do not themselves prove the new Calendar availability RPC's HTTP serialization or final native user flow. This review therefore grants SQL/source GO and makes no final native acceptance claim. The parent owns session `1bdf7346`; it was not touched. Final native evidence, exact-head CI, completed bot reviews and the authorized migration handoff remain separate gates. Robert's manual remote database operation is still required before merge. No remote database access or migration was performed by this reviewer.

Comment Sicko scope was all newly added SQL and the three changed Python hunks. Added comments 0, removed comments 0, added suppressions 0, flags 0, kept new comments 0, reviewer deletions 0. Existing Python and retained helper comments outside changed hunks were read for context but were not flagged.

Exact reviewed file bindings follow.

| Path | Bytes | SHA-256 |
| --- | --- | --- |
| `supabase/migrations/20261006000100_atomic_calendar_availability_removal.sql` | 1135 | `f78cbc200ff1b561b6236782a49cdb05a18c767b3c6246c63bc80fab5553aa49` |
| `supabase/tests/calendar_availability_atomic_removal.sql` | 16777 | `c687475ac74c15ec66d68a00242b89188126cec8675a560eba9f3dc8d63ceb01` |
| `supabase/migration-tests/calendar_availability_removal_before.sql` | 3746 | `fb231bac2571e3750214bf69e28496831ef785fcb15540f6b794ff2d7c808dba` |
| `supabase/migration-tests/calendar_availability_removal_after.sql` | 2752 | `e3252de8afa7923007c3c2724b136d67141804d973adeeb24163f6d656c5ce65` |
| `scripts/ci/database.py` | 32856 | `7c4cee1044047aa9e50acc015a4164239efa141e4f07811607b7c57f6e3acfcc` |
