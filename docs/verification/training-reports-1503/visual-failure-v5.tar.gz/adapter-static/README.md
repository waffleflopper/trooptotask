# Owned Mac transport for issue 1503

Scratch transport, fixed to this checkout's already-running verification worker 1. It never builds, launches a worker/provider/browser, proxies a provider, changes app files or supplies a session. Root must freeze the candidate and driving inputs and launch/doctor the normal production worker first. Use Node 24 with the established PATH/TMPDIR. Apply the repository's verification skill and the installed tailscale-preview skill; this adapter does not replace them.

```bash
node .verification/mac-preview-1503/command.mjs help
node .verification/mac-preview-1503/command.mjs start
node .verification/mac-preview-1503/command.mjs check
node .verification/mac-preview-1503/command.mjs stage
node .verification/mac-preview-1503/command.mjs stop
node --test .verification/mac-preview-1503/transport.test.mjs
```

`start` stays in the foreground. Keep its terminal/process handle. It admits only the owned running worker, requires its authenticated doctor, candidate/source/output hashes and exact supervisor/app identities, privately reads only the app's required environment values, then calls the existing helper's `info`, `cert` and `run tls` commands. The helper runs one native HTTPS Vite sidecar and owns temporary private TCP forwarding. It leaves other preview allocations and Serve rules alone. The sidecar reads the existing production output; no build or second server-source preload runs.

The helper's `env`→Python shebang handoff is admitted only during bounded startup capture, at the original PID/start with exact installed interpreter/script/arguments. Before/after proc metadata prevents that legitimate exec from being mistaken for replacement. The saved running identity is the final Python command. An initial `spawned-helper.json` permits equally strict cleanup if final capture fails; a replaced or unexpected process remains BLOCKED. Startup failures disclose only an uppercase code in `startup-failure.json` and the private helper log, never the thrown message, stack or environment. Preserve a fully stopped failed run outside its original session directory before root's bounded retry; no automatic retry/archive behavior exists.

When ready, `start` prints a sanitized PASS receipt with the explicit external HTTPS origin. Navigate that URL in the T3 Mac browser. T3's environment-port target does not establish forwarding under Connect. The ordinary worker doctor still reports its loopback primary origin; its unused private Chromium version is not the Mac browser version.

`check` is the required sidecar checkpoint alongside ordinary doctor. It verifies the current candidate, copied source, output and adapter bytes, original identities, exact sidecar/helper processes, private Serve port state and a certificate-verified public login response carrying this run's public session ID. Run before browser proof, at meaningful checkpoints and before cleanup. Each receipt is written to this session's ignored `runs/<session-id>/checkpoint.json`. Hashing occurs at checkpoints rather than on every HTTP request. Source/build/instruction inputs must remain frozen throughout the live drive.

The receipt includes repository, worker/session, candidate/revision, primary/external origins, source/output/adapter digests, cookie namespace, original/sidecar/helper/starter/forwarding identities, local/public ports, and explicit `browserProviderRoute:false` / `sourceControlPreload:false` limits. The forwarding identity is captured from the owned helper's actual child list and exact Serve arguments, with an unchanged marker required afterward. Raw runtime files stay private; only reviewed sanitized receipts belong in evidence.

Cookie names are changed mechanically at the HTTP boundary. Incoming requests admit only this session's namespaced cookies and translate their names for the unchanged app. Normal app-issued Set-Cookie names gain that namespace; values and attributes, chunks and deletion remain unchanged. No browser cookie store is read/cleared, no foreign cookie is admitted and no session is generated or injected. This is a documented transport difference: app authentication uses normal visible forms, while original production cookie names are not freshly exercised on the common Mac hostname. A new T3 tab is not documented to isolate cookie stores. Browser storage is isolated by the distinct public port; restore only this run's altered storage/theme.

The Vite plugin uses `enforce:'pre'` and installs the cookie middleware in `configurePreviewServer`. The installed Vite executes that hook before its preview post-hooks; installed SvelteKit returns its SSR handler as a post-hook. Thus cookie translation surrounds the ordinary SvelteKit request/response header boundary. Native preview HTTPS preserves HTTPS request scheme and incoming Host; the middleware also rejects a different Host/port, different Origin or non-TLS request. Origin/CSRF checks, secure cookie behavior and certificate verification remain enabled.

## Private credential fill

If literal tool typing would expose the synthetic password, `stage` stages a two-minute one-use carrier for **orgOwner only** and returns only a sanitized receipt. It writes `private-navigate.json` and `private-fill.json` in that session's private run directory. There is no arbitrary role/file/admin/provider route.

1. Navigate the owned Mac tab to the external origin's visible `/auth/login` page.
2. Call `stage`. Read `private-navigate.json` in memory, without printing it or saving its expression in public evidence, and use its expression through T3 evaluate. The one-use capability route accepts only a same-origin navigation referred by `/auth/login`. Its response briefly carries the private synthetic credentials in `window.name` and returns to the normal form. Never snapshot/capture that relay body or private capability URL.
3. Read `private-fill.json` in memory and evaluate it on that same origin's login form. It clears `window.name` before parsing, fills only the visible email/password inputs, and reports booleans. It never submits, calls auth, invokes app handlers or creates cookies.
4. Snapshot the visible form safely, then click **Sign In natively**. Preserve a sanitized fill receipt and the native submit/redirect observations. Exclude capability-bearing tool arguments from public captures and record the redaction explicitly. Clear `window.name` again at cleanup.

The fixture file's original hash and ownership are checked before delivering the carrier. The route is consumed atomically and its capability file is removed; shutdown also removes pending carrier/expression files. Passwords are never written to disk, arguments, stdout or evidence. Do not package the private run directory or helper log.

## Liveness and cleanup

A 1.5-second guard checks the exact worker ID/phase and original app/supervisor plus starter/helper identities. Ownership loss, replaced PID, worker cleanup or starter death closes Vite, removes a pending carrier and exits. The existing helper then removes its own foreground forwarding. There is no persistent Serve configuration, Funnel, reset, origin rewrite or insecure TLS mode.

The driver must restore goal/theme/hooks, remove its transient carrier, sign out visibly and preserve final observations. Root runs doctor plus `check`, performs journal-bound seed cleanup and exact original-row comparisons, then runs `stop` before ordinary worker cleanup. `stop` signals only recorded matching processes and proves the sidecar/helper are gone, the specific Serve port is absent and the loopback listener is closed. It never removes a replacement listener or foreign mapping; remaining resources produce BLOCKED for inspection. Receipts survive cleanup. If startup or a signal interrupts the run, retain receipts and run the same owned `stop`; do not reset Serve.

Every owned cleanup attempt runs even if an earlier attempt fails. A BLOCKED command receipt preserves `startupCode` when applicable and the safe `cleanupCodes`; thrown messages, stacks and private values are excluded. Startup releases its lease only after all cleanup attempts succeed. An uncertain process remains BLOCKED with its lease retained for root's inspection.

The adapter does not expose the provider. This is sufficient for issue 1503's server-owned sign-in, Training reports/detail, Settings and Excel export paths. Browser-direct signed Storage links and primary-app server-source failure controls are outside this sidecar proof. Browser helpers tied to launcher DevTools/page IDs do not drive the Mac tab; nonbrowser fixture/rows/journal controls remain valid. The assigned visual driver must establish normal native login/submission, HTTPS reachability and issue 1503 behavior before acceptance.
