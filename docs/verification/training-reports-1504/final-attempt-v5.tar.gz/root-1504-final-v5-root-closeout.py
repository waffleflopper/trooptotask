from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path.cwd()
evidence = root / '.verification/evidence/verify-trooptotask/1504-final-v5'
runtime = json.loads((root / '.verification/1504-final-v5-runtime.json').read_text())
session = Path('/home/waffleflops/.local/state/trooptotask-verification/c025ecff30540993/worker-1')
private = json.loads((session / 'session.json').read_text())
assert private['id'] == runtime['session']
owners = {key: private.get(key) for key in ['supervisor', 'appProcess', 'mcpProcess', 'browserProcess']}
environment = os.environ.copy()
environment.update({'PATH': '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + environment['PATH'], 'TMPDIR': '/home/waffleflops/.cache/t2t-1502-tmp', 'NODE_DISABLE_COMPILE_CACHE': '1'})
receipts = []
def run(name, command):
    started = time.time()
    result = subprocess.run(command, env=environment, capture_output=True, text=True)
    (evidence / f'root-{name}.json').write_text(result.stdout)
    (evidence / f'root-{name}.stderr').write_text(result.stderr)
    receipts.append({'command': command, 'exitCode': result.returncode, 'seconds': round(time.time() - started, 3), 'stdout': f'root-{name}.json', 'stderr': f'root-{name}.stderr'})
    (evidence / 'root-closeout-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    assert result.returncode == 0, f'{name} failed; saved stdout/stderr'
    return json.loads(result.stdout)
v = ['npm', 'run', '--silent', 'verify:app', '--']
control = ['node', '.agents/skills/verify-trooptotask/helpers/control.mjs', '--worker', '1']
try:
    doctor = run('doctor-closeout', [*v, 'doctor', '--worker', '1'])
    assert doctor['status'] == 'PASS' and doctor['candidate'] == runtime['candidate'] and doctor['session'] == runtime['session']
    comparisons = []
    for table in ['personnel_trainings', 'training_types', 'training_views', 'organizations']:
        for org in ['orgA', 'orgB']:
            restored = run(f'{table}-{org}-restored', [*control, 'rows', table, org])
            original = json.loads((evidence / f'root-{table}-{org}-original.json').read_text())
            assert original == restored, f'{table}/{org} not restored'
            comparisons.append({'table': table, 'org': org, 'allFieldsEqual': True})
    restored = run('trainingConfigure-preferences-restored', [*control, 'preferences', 'trainingConfigure', 'orgA'])
    assert restored == json.loads((evidence / 'root-trainingConfigure-preferences-original.json').read_text())
    (evidence / 'root-restoration-audit.json').write_text(json.dumps({'status': 'PASS', 'proof': 'root exact owned provider readback; no rows created or seeded in this run', 'comparisons': comparisons, 'trainingConfigureProviderPreferencesEqual': True, 'browserKeyLimits': ['theme and sidebar were not toggled; native driver recorded unchanged original localStorage and removed all hooks', 'SvelteKit navigation session keys are disposable profile state'], 'uiCreatedCompletionsRemoved': []}, indent=2) + '\n')
    doctor = run('doctor-after-restoration', [*v, 'doctor', '--worker', '1'])
    assert doctor['status'] == 'PASS' and doctor['candidate'] == runtime['candidate'] and doctor['session'] == runtime['session']
finally:
    cleanup = run('owned-cleanup', [*v, 'cleanup', '--worker', '1'])
    assert cleanup['status'] == 'PASS' and cleanup['phase'] == 'cleaned'
observed = []
for key, owner in owners.items():
    assert owner is not None, key
    proc = Path('/proc') / str(owner['pid'])
    try:
        stat = (proc / 'stat').read_text()
        parts = stat[stat.rfind(')') + 2:].split()
        command = (proc / 'cmdline').read_bytes().decode()
        same = parts[19] == str(owner['start']) and command == owner['command'] and parts[0] != 'Z'
    except (FileNotFoundError, ProcessLookupError):
        same = False
    assert not same, key
    observed.append({'owner': key, 'pid': owner['pid'], 'expectedStart': owner['start'], 'commandSha256': hashlib.sha256(owner['command'].encode()).hexdigest(), 'exactOwnedProcessAbsent': True})
profile = f'--user-data-dir={session / "chrome-profile"}'.encode()
remaining = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        if profile in (proc / 'cmdline').read_bytes().split(b'\0'):
            remaining.append(int(proc.name))
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        continue
assert not remaining
assert not session.exists()
(evidence / 'root-owned-absence.json').write_text(json.dumps({'status': 'PASS', 'session': runtime['session'], 'processes': observed, 'profileProcessIds': remaining, 'privateWorkerDirectoryAbsent': not session.exists(), 'proofPayloadsStillExist': (evidence / 'driver/receipts.jsonl').is_file()}, indent=2) + '\n')
runtime['phase'] = 'final-v5-cleaned-briefing-focus-cell-state-pending'
(root / '.verification/1504-final-v5-runtime.json').write_text(json.dumps(runtime, indent=2) + '\n')
print('Root restoration, doctor, owned cleanup and exact process absence PASS; mandatory selections accepted by Claude; briefing Retry focus, stale cell selection and print fragmentation findings retained.')
