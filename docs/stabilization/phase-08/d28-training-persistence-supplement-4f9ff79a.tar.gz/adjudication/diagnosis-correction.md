Correction of the preceding stage's Dense page-five observation.

The Dense continuation header failure was an observation error. The saved PDF and original rasters contain the complete Organization and section title, including page five. No application defect is established, so the proposed CSS repair and native rerun were cancelled under root's amended artifact-only scope. This stage is terminal; source/browser ownership is released to root.

The previous final-report.md and its FAIL remain untouched as historical observations. This separate correction supersedes only its missing-header finding and resulting proposed print-repair requirement. It does not erase the original control FAILs, historical UNRUN limits, or imply a general print acceptance across untested variants.

The original native execution remains bound to revision c911e0a114e1425541fa91a7b66db04bd904dc22, candidate 4f9ff79af367c644b43bd2b5a4dd172dab4c44027e4b7300577ebc43ea25c797, session c86d4eb9-2d3f-4fd8-9e5d-fa92a2c8e38a, actor trainingConfigure, organization 7248cf6f-c163-4b1d-82fb-dd9480398c81, literal UI date 2026-10-07 and Chromium 152.0.7977.82. Dense fixture tag 9c9d041f, saved view 2a1e75bf-1e6e-4d63-b4c2-d3bafeb96cf0 used PFC/MOS68V/90days, 112 People and 24 Types. This stage does not create a new app execution binding.

The preserved five-page Letter landscape/background-on dense-letter-on.pdf has SHA256 d5c2f24243be02dd3507119e51020379daa29e40f7198ea8e92502a18958b5e2. Fresh Poppler full-page rasters at scale-to 1200 match all five original PNGs byte for byte. The original 253 payloads all match their inventory hashes. artifact-adjudication.json records every full-raster and crop hash, source artifact path and review.

All five full pages were viewed at original detail. Page one retains its complete briefing context and overview. Pages two and three show Organization, Training type by group, Groups 1–7 of 14 and the complete context. Pages four and five show Organization, Training type by group, continued, Groups 8–14 of 14 and the complete context. Both continuation pages retain their final type, total row, N/A values and margins. Page-five fresh-header-5.png independently makes the full title visible at original detail; its SHA256 is f0f866a290f7d7654527113375e66f4cb48b010d06a44fd68e73a6b2cfc00232. Header-crop OCR corroborates organization and title, with imperfect context recognition; OCR is not used to claim exact numbers. Page-five pdftotext is separately retained.

The earlier default tool image presentation/interpretation showed a conflicting appearance. Actual original-detail pixels and fresh identical rasters reject the missing-header claim. The precise presentation pipeline cause is not proven. No Chromium-version cause, repeated-thead painting defect or nested-flex root cause is established. The existing shared RunningHeader and its Matrix/Detail callers were traced but left unchanged.

| Selected obligation | Outcome and scope |
| --- | --- |
| Preserved Dense PDF, including all-page continuation/header observation | PASS on original native artifact binding; this corrects prior 10.2 missing-header FAIL. |
| Existing PDF/PNG and prior-report integrity | PASS; all 253 old payload hashes unchanged. |
| Fresh saved-PDF rendering and original-detail review | PASS; all five full rasters identical, all five page/header reviews complete. |
| Proposed CSS repair and native Dense/100-row appendix rerun | UNRUN, superseded before edits/launch by artifact-only scope; no confirmed product break warrants them. |
| New paper/theme/Short/Empty PDF sweep | UNRUN; unchanged #1550 source/input evidence remains at its original binding in historical-print-source-binding.json. |
| Ordinary paging, workbooks, filters, empty distinctions, scope switch, metadata and lower checks | Reused at the preceding stage's original binding; no affected executable input changed. |
| Offline/lazy-module and original deferred edges | Prior FAIL/UNRUN preserved; this correction adds no proof for them. |

No tracked source, fixture, control, recipe, ledger or archive changed. No app, browser, provider, production build or heavy test was started. Touched-file lint/format and new lower tests are inapplicable because no executable input was edited. The prior focused six-suite 73-PASS result remains in lower-checks.log at its original binding. Root's Person repair, original 36 PASS, #1562 lifetime proof and accepted #1550 variants remain distinct original bindings described in the previous report. This worker claims no independent acceptance, commits or packaging.

closure-recheck.json is a fresh read-only recheck against the exact prior owned process/start/group/port/container receipt: PASS, 15 process identities absent, nine recorded ports absent, five owned containers absent, worker-1 directory absent; 41 preexisting containers retain identity/mount/PID/start fields, seven networks and 17 volumes unchanged. This stage owns no newly launched resources. The previous exact full-field restoration, supported cleanup, final doctor and all-50-listener comparison remain preserved. No database or control restoration was needed in this artifact-only stage.

All new evidence is under /home/waffleflops/.cache/t2t-1376-training-print-header-20261007 and .verification/evidence/verify-trooptotask/d28-training-print-header-20261007. raw-inventory.json binds the new receipt and render files. No archives were added. There is no unresolved print-repair gap established by this observation; root may proceed with the settled ordinary persistence implementation and later exact-head CI/review.
