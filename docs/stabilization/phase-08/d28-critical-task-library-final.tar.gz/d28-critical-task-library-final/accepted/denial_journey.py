import json
import native_driver as n
ids=json.load(open(n.ROOT/'fixture.json'))['ids'];origin=json.load(open(n.ROOT/'launch.json'))['origin']
for role,label in [('ictViewer','viewer'),('ictScoped','scoped'),('ictEmpty','empty'),('rosterManager','training-only'),('ictForeign','foreign')]:
    actor=n.control(['actor',role,'critical-tasks'],label+'-entry');n.PAGE=actor['pageId']
    n.snap(label+'-matrix')
    requests=json.load(open(n.ROOT/(label+'-denials-requests.json')))
    responses=n.http(requests,label+'-denials')
    assert all(r['status']==(404 if label=='foreign' else 403) for r in responses)
    if label=='foreign':
        n.click('Task Library','foreign-library-open',role='link');n.snap('foreign-library')
    else:
        n.navigate(origin+'/org/'+ids['orgA']+'/critical-tasks/library',label+'-library-guarded')
    print(n.tool('close_page',{'pageId':n.PAGE},label+'-close'))
n.control(['rows','ict_tasks','orgA'],'tasks-A-after-denials')
n.control(['rows','ict_tasks','orgB'],'tasks-B-after-denials')
n.control(['rows','ict_tasks','orgA','task_code','VERIFY-D28-DENIED-FINAL'],'denied-task-absence')
n.control(['rows','personnel_ict_completions','orgA'],'completions-after-denials')
n.control(['rows','organizations','orgA'],'defaults-final')
print('DENIAL JOURNEY COMPLETE',flush=True)
