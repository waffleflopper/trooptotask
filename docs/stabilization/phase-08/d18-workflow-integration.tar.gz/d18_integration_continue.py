import sys,json
sys.path.insert(0,'.verification');import d18_ui as v,d18_native as n,d18_final as f
seed=f.read('04-source-seed');src=seed['sources']['orgA'];life=f.read('05-lifecycle-seed')
n.click('10-native-source-confirm',2,'button "Archive"',after='alertdialog');v.snap('11-source-submitted',2);r=v.helper('12-source-submission-transport','network','state','2');assert r['calls'][-1]['status']==201
v.helper('13-source-control-restore','network','restore','2');r=n.rows('14-source-request','deletion_requests','orgA','resource_id',src['personnel']);assert r['count']==1 and r['rows'][0]['status']=='pending'
r=f.api('15-type-request',2,'submit',{'resourceType':'training_type','resourceId':src['training_type'],'resourceDescription':'Integrated Type retry','resourceUrl':None});assert r['status']==201;request=json.loads(r['body']);f.reload('16-reviewer-reload',3)
v.helper('17-actual-check-arm','deletion-review-failure','arm',request['id']);v.helper('18-actual-check-state','deletion-review-failure','state');v.helper('19-review-observe','network','arm-observe','3','deletion-requests/review')
n.review_click('20-native-type-check-failure',3,'Integrated Type retry','Approve');v.snap('21-native-type-failed',3);trace=v.helper('22-real-status-write-failure','network','state','3');assert trace['calls'][-1]['status']==500
failed=n.rows('23-type-request-pending','deletion_requests','orgA','id',request['id']);assert failed['rows']==[request];assert n.rows('24-type-source-removed','training_types','orgA','id',src['training_type'])['rows']==[]
v.helper('25-actual-check-restore','deletion-review-failure','restore');v.helper('26-actual-check-clear','deletion-review-failure','state')
n.review_click('27-native-same-type-retry',3,'Integrated Type retry','Approve');v.snap('28-native-type-retry-accepted',3);trace=v.helper('29-real-same-request-retry','network','state','3');assert [r['status'] for r in trace['calls']]==[500,200]
a=n.rows('30-type-request-approved','deletion_requests','orgA','id',request['id'])['rows'][0];assert a['status']=='approved' and all(a[k]==val for k,val in request.items() if k not in {'status','reviewed_by','reviewed_at','denial_reason'});v.helper('31-review-control-restore','network','restore','3')
before=n.rows('32-bulk-rows-before','personnel','orgA')['rows'];v.helper('33-bulk-fail-arm','network','arm-fail','4','personnel/archive-batch');n.click('34-bulk-mode',4,'button "Archive"');n.click('35-bulk-one-selection',4,'checkbox "Select SPC '+life['name']+', Synthetic"')
for prefix,expected in [('36-503',503),('41-rejection',None),('46-explicit-retry',200)]:
 n.click(prefix+'-confirm-open',4,'button "Confirm Archive"');n.click(prefix+'-confirm-submit',4,'button "Archive"',after='alertdialog');snap=v.snap(prefix+'-visible',4);trace=v.helper(prefix+'-transport','network','state','4');assert len(trace['calls'])==1 and trace['calls'][0]['ids']==[life['ids']['person']]
 if expected is not None:assert trace['calls'][0]['status']==expected,trace
 if expected!=200:
  assert '1 selected' in snap and 'checkbox "Select SPC '+life['name']+', Synthetic" checked' in snap,snap
  assert n.rows(prefix+'-unchanged-provider','personnel','orgA')['rows']==before
 v.helper(prefix+'-restore','network','restore','4')
 if prefix=='36-503':v.helper('40-bulk-reject-arm','network','arm-reject','4','personnel/archive-batch')
 if prefix=='41-rejection':v.helper('45-bulk-real-observe','network','arm-observe','4','personnel/archive-batch')
assert n.rows('51-bulk-person-archived','personnel','orgA','id',life['ids']['person'])['rows'][0]['archived_at']
r=v.helper('52-lifecycle-pending-ordinary-http','personnel-archive-batch','5','orgA',json.dumps([life['ids']['duplicateAlpha'],life['ids']['duplicateBravo']]));assert r['status']==200,r
rows=n.rows('53-pending-lifecycle-request-readback','deletion_requests','orgA')['rows'];assert len([r for r in rows if r['resource_id'] in {life['ids']['duplicateAlpha'],life['ids']['duplicateBravo']} and r['status']=='pending'])==2
f.file_capture('54-source-pdf-before-cleanup')
print('PASS integration native201/sharedCHECK500-sameRetry200/bulk503-reject-explicit200/ordinarytwo-lifecyclepending cleanup witnesses',flush=True)
