#!/bin/bash
# net.sh NAME PAGE -> fetch/xhr request list, prints training-reports/__data lines
D=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v6/driver
MAXOUT=0 $D/r.sh "$1" npm run --silent verify:app -- tool list_network_requests "{\"pageId\":$2,\"resourceTypes\":[\"fetch\",\"xhr\"],\"pageSize\":200}" --worker 1
grep -oE 'reqid=[0-9]+ [A-Z]+ [^ ]*(training-reports|__data)[^ ]* \[[^]]*\]' $D/$1.out | sed -E 's#https?://[^/]+##' | tail -${TAILN:-6}
