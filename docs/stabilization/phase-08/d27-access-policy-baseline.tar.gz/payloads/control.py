import json, os, pathlib, subprocess, sys
root = pathlib.Path.cwd()
evidence = root / ".verification/evidence/verify-trooptotask/d27-policy-baseline"
env = dict(os.environ)
env["PATH"] = "/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:" + env["PATH"]
name, *args = sys.argv[1:]
result = subprocess.run(["node", ".agents/skills/verify-trooptotask/helpers/control.mjs", *args], env=env, capture_output=True, text=True)
(evidence / (name + ".control.json")).write_text(json.dumps({"args": args, "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr}, indent=2))
print(result.stdout[:5500]); print(result.stderr[:500])
raise SystemExit(result.returncode)
