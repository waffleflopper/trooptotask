# Remaining ordinary Training baseline

Exit condition is selected required checks satisfied or a concrete repeated unavailable dependency, all owned resources closed, exact final report present. One worker, one owned app and one build are permitted. No publication, commits, ledgers, archives, application persistence, remote database or existing local database writes.

Read the Principles index in full. Sequence Work into Verifiable Units changes execution to pagination, dense outputs, lower boundaries and closure in order. Prove It Works requires actual downloaded rows, PDF pages, requests and process absence rather than proxy claims. Unslop governs notes.

Autonomous-run steps are retained. 1 State the exit condition above. 2 Use the active parent thread and tool completion as wake mechanism; no background watcher is required for local sequential work. 3 Make only minimal justified control corrections and verify each unit; skip commits because the parent owns them. 4 Diagnose concrete discoveries within the bounded task. 5 Keep this scratch decision trail and raw evidence. 6 Stop after required checks and real closure.

Throughput checkpoint. Group compatible read-only actions in one session, preserve all cohorts until dependent comparisons finish, reuse current original PASS and accepted print variants, and collect only remaining required ordinary persistence evidence. There is no full 64-case replay or local full DoD duplication.

Select 9.1 zero-People Reports and disabled export with separately labeled authenticated empty workbook; 9.2 26-Person detail paging, held/fail/retry/100 and full workbook; 9.3 PFC/SPC/MOS/Alpha literal filters and saved-set cleanup barrier. Fresh original fixture facts determine arithmetic; the prior dated pair is restored and is not silently recreated.

Select 10.1 Dense 112-Person/24-Type native report query, detail and 1990-row workbook; representative 10.2 whole Dense Letter/on PDF with every page inspected; 10.3 Short and Empty view distinct from zero People; 10.4 loaded held/failed detail and A-to-B source admission; 10.5 native button print invocation and no extra report/detail fetch. Reuse accepted #1550 CSS/theme/paper variants only after binding unchanged print source and matching fixture generation. Other historical variants stay UNRUN.

Select lower-boundary 11.4 present/null/missing metadata and installed SDK behavior, and relevant 11.5 1000+1 and late page error completeness. Existing no-native Starter Apply and deferred rank edges remain explicit. Reuse original 36 PASS at c911e0a1/candidate590fe5b7 and focused Person save at candidate93ab5146 with their original inputs. Accepted #1562 editor lifetime is reused and not replayed.

Offline control remains FAIL because installed McpPage.emulate rejects networkConditions with allowedUrlPattern. Preserve origin guards. Lazy-module delivery is separate from ordinary server persistence. Review existing lazy module lower-boundary checks before deciding if native exact-chunk control is required. No speculative rare-edge matrix.

Freeze source, recipes and controls before launch. Restore all armed hooks, clean only journaled synthetic cohorts after comparisons, compare original full rows, final doctor, supported cleanup and actual process/group/port/container/directory absence. Root packages afterward and owns independent acceptance.
