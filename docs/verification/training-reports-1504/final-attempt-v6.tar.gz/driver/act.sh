#!/bin/bash
# act.sh NAME PAGE TOOL JSON -> before state/net, native action, after state/net
D=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v6/driver
n=$1; p=$2; tool=$3; j=$4
echo "== before"; $D/st.sh $n-before-state $p | cut -c1-1500; TAILN=3 $D/net.sh $n-before-net $p
echo "== action $tool $j"; MAXOUT=400 $D/r.sh $n-action npm run --silent verify:app -- tool $tool "$j" --worker 1 | head -c 400; echo
echo "== after"; $D/st.sh $n-after-state $p; TAILN=${TAILN:-4} $D/net.sh $n-after-net $p
