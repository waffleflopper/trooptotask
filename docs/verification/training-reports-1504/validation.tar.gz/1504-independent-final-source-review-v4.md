# Independent final source review v4

**Scoped owned-source/spec/consumer acceptance: PASS** at `8cdd5310cba49fb2782ccd9da0af39ea8b9c5106` against integrated base `ee1ca2b275d71cd0b9a51367b58c4754a687a443`, continuing the complete source review at `77b55954cd1545814e1581e9d54e254d43c9c14b`. No new actionable source objection was found in the authorized four executable/test/recipe deltas and the archive addition. **Overall current-main candidate acceptance: BLOCKED** against `49cacc665891b7e0edf95c6bb97993b8ca9837a2`: governance exits 1 because the branch is behind current main; its incoming Phase 8 integration is explicitly deferred. **Fresh native closure: PENDING** for Clear filters, export-error Retry, and Focus no-preload behavior. This source report does not accept future native v7 or certify the whole issue clean.

Authority was read-only Git and offline files/parsing/hashing, with this report and exclusive scratch as the sole writes. No app/test/browser/service execution, image/layout judgment, network, Git/source/recipe mutation, remote SQL or nested delegation occurred. Poteto generic persona and relevant Prove It Works/Test Behavior Not Implementation principles were applied with t2t-engineer, AGENTS, Testing, Definition of Done and retained contracts. Persona does not enlarge authority. This inherited-model source acceptance is not independent execution or model diversity; actual owner test logs and Claude native artifacts are separately identified below.

## Exact scope and complete census reconciliation

| Comparison | Actual census | Status | Acceptance scope |
| --- | --- | --- | --- |
| Integrated ee1 → prior source77 | 145 paths, 52A / 89M / 4D; 22 archives | Prior complete source-v3 accepted | Actual prior byte pins rechecked, not silently assumed |
| Integrated ee1 → reviewed 8cdd | 146 paths, 53A / 89M / 4D; 23 archives | Scoped source/spec/consumers accepted | 123 non-archive paths including all four deletions; archives assessed as bytes |
| Source77 → 8cdd | Five paths: 4M + 1A archive | Every executable/test/doc delta independently reviewed | Two Svelte components, one test, one recipe, v6 archive |
| Current main49 → 8cdd | 390 rename-aware entries: 60A / 308M / 15D / 7R | **Current-main candidate blocked** | 397 endpoint paths under `--no-renames`: 67A / 308M / 22D; 25 archives |
| Integrated ee1 → current main49 | 256 rename-aware entries: 11A / 231M / 7D / 7R | Deferred incoming integration | 263 distinct endpoint paths: 18A / 231M / 14D; bytes/census only |

All 145 prior source-v3 census entries reproduce their actual integrated-base and source77 blob/deletion hashes with zero mismatches. Of those, 141 retain identical HEAD state; four change in this round (recipe, Focus component, Page component and Page test). The only newly added cumulative path is v6 archive. Working bytes for all 146 integrated-scope entries match the reviewed 8cdd pin, including absent deleted files. Read-only `git status --short` is empty at the audited checkpoint; read-only delta `git diff --check` passes. These checks did not modify Git.

All 70 inherited access/main dependency paths from source-v3 reproduce their base and prior pins and remain byte-identical source77 → 8cdd. They remain a separate dependency census, not extra owned PR changes. All 20 explicitly selected shared/UI/model dependencies also reproduce actual blobs and working bytes. The full 146 path/status/base/prior/head byte+SHA256 census, all 70 dependencies, and all actual current-main endpoints and rename-aware entries are preserved in the exclusive scratch. Report appendix below enumerates every owned path and exact HEAD/deletion disposition.

Current-main `49cacc` is not an ancestor of 8cdd. Their actual merge base is integrated `ee1ca2b275d71cd0b9a51367b58c4754a687a443`. Main contains `db0a378a` (explicit request contexts, #1528) followed by `49cacc66` (D27 acceptance, #1530). Twelve incoming endpoint paths overlap the owned census; 251 actual current-main-diff endpoint paths are incoming-only. Seven relocations appear reversed in main→branch diff, producing 390 Git rename-aware entries rather than 397 distinct old/new endpoints. Incoming count is actual 256 rename-aware / 263 endpoint paths, not an assumed 264 shorthand. This mechanical census is not a semantic review or migration of those incoming changes. No complete current-main review is claimed: preserving the old integrated source cannot certify authorization/context semantics or governance after an unperformed integration.

The source/recipe delta is exactly 19,115 bytes, SHA256 `0fdb4a6375a7b24ae9c6745c6a5b25302e72ffe9e3d0050198ce7fe9b465950d` for actual `git diff 77b559 8cdd -- src .agents/skills/verify-trooptotask`. Owner `source.diff` and `full.diff` exactly equal actual committed component/test deltas after only normalizing Git i/w versus a/b prefixes and omitting index header lines. No semantic edit is hidden in that normalization. Actual full hash is pinned above; archive-only 2aa7 did not change any runtime source.

## Requirements and prior acceptance preserved

I re-read actual `.verification/1504-issue.json` (3,874 bytes, SHA256 `f76a770a21d264bcacb6131e3c35e65c06f03c5c321a6fd55983b3dfabf2d5c3`) and `.verification/1433-for-1504.json` (25,791 bytes, SHA256 `0fb86901e245748799c0b7d3aaba8117ac9d823ea67c8dcbc08386453a076536`), including the green → amber → red amendments and slice precedence. Focus remains deterministic, keyed/scoped and at most three model-selected areas; all sections use the same canonical filters; the five-sheet workbook covers the full affected requirements; visible detail remains 25/100; native print hides controls and prints filters; shared TrainingStatusCell/filterPersonnel/currency semantics and separate Dashboard/Personnel currency behavior remain retained. This delta adds no new product/model rule, type, free text, AI, permission, provider query or export contract.

The complete cumulative source-v2 and source-v3 reviews cover auth/provider boundaries, query/data volume, deterministic model, old-code deletion and direct/reverse consumers under integrated ee1. Their actual pins were reconciled, not adopted by assertion. The source-v3 report is 24,751 bytes, SHA256 `03e2eb2a4cf5f28430386053f7572351ca1e7e3358767dc25f23928053c901d8`. Its 70 dependency pins and complete 145 owned pins match actual Git objects. The v6 artifact report is 29,672 bytes, SHA256 `7857fda334a112b671456a5a8458107fdf37a7a66eada9b59bf8b3ede8a894b3`; it independently audited the actual native package at source77. It accepted report Retry (F1), controlled deselection (F2), and the short detail PDF content boundary (F3), with visual judgment delegated to Claude.

## Per-path delta review

| Changed path | Actual behavior / evidence / disposition |
| --- | --- |
| `TrainingReportsPage.svelte` | `clearFilters()` retains the existing canonical `session.select(DEFAULT_TRAINING_BRIEFING_INPUT)` and then calls existing `focusSection(BRIEFING_ID)`. Both real Clear buttons use this handler. New explicit `retryExport()` starts existing `exportExcel()` and calls the same focus helper; only export error alert `onRetry` is rewired. Ordinary Export Excel still calls exportExcel directly. **Source accepted**, native closure pending. |
| `TrainingFocusSection.svelte` | Adds supported `data-sveltekit-preload-data="off"` to the existing Button anchor. Existing href, preventDefault/onOpen, label, `aria-current`, `aria-describedby` and print-hidden class remain exact. **Source accepted**, actual native no-preload proof pending. |
| `TrainingReportsPage.test.ts` | Makes fixture types optional; independently specified pending/after-response focus cases for toolbar Clear, no-requirements-panel Clear and export-error Retry. Corrected panel fixture uses Optional CPR. Actual red/green reviewed. **Behavioral tests accepted**; they do not certify native browser/network/download behavior. |
| Training completions/reports feature recipe | Adds explicit stable-region expectations for both Clear controls and export Retry, retains ordinary Export behavior, and requires no report page-data preload on Focus hover/activation after filter change plus exactly one scoped detail request. Aligns affected live acceptance with the actual correction. **Recipe accepted**; wording is an expectation, not live proof. |
| `final-attempt-v6.tar.gz` | Actual 3,621,597 bytes SHA256 `b829e3a7c14995246df148fc0e487e9baad07c715cdadf137b8abc764f51f644`. Archive-only commit2aa7. Expanded actual 944 payload hash/set audit separately completed. Bytes/package evidence accepted; not an executable source delta or future native v7. |

Actual before/after byte pins for every delta follow.

| Path | Prior bytes / SHA256 | Reviewed bytes / SHA256 |
| --- | --- | --- |
| `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | 32102 / `fb3924708ca3c5a91cce6518db8265d458d6e50455584c05ab18ad8ff8ca0712` | 32448 / `f69a183328c3b7798b4c982117666d24c6c79cf4fe981d789e709fd0428cda4d` |
| `docs/verification/training-reports-1504/final-attempt-v6.tar.gz` | absent | 3621597 / `b829e3a7c14995246df148fc0e487e9baad07c715cdadf137b8abc764f51f644` |
| `src/features/training/components/TrainingFocusSection.svelte` | 2236 / `49ead5898bcbb10cdbd8d7e4f6e88191b0144a0557f44a55989beb4d1aa73ead` | 2278 / `0ef6bbdf9c2f88a7f02404746ff92414cf857adc1cfa2d01602854559f1f6344` |
| `src/features/training/components/TrainingReportsPage.svelte` | 23651 / `bc112bec56ffe4c7be6a05a0f230d2c3bdc7c62aa4e0f1d36529ad8519b43d4d` | 23777 / `585bbb4a50709a368766bae09a11e50aa302e69ef0ccdf53af15b81d0e5e8d06` |
| `src/features/training/components/TrainingReportsPage.test.ts` | 26068 / `08fc5ebfb02bedf95f36d9efa485c2a8969692ae9ecd65784eec20653a2b1c7c` | 28556 / `c8a1ef97b598ba803e73aead1341fcb30f7c2da75ba489476fd9d9fa2932e1d5` |

## Focus lifecycle and direct/reverse consumers

The existing focus helper awaits only a Svelte `tick()` and focuses a stable DOM region by its page-specific ID. `ReportWorkspace.Root` forwards id/tabindex/aria attributes to a real section; the briefing section is persistently mounted around normal, no-training-types and no-applicable-requirements states. It is labelled `Training readiness briefing` with tabindex -1. Both Clear controls and export Retry intentionally disappear during their action; the existing labelled region provides a durable destination. Clear selection and export error clearing occur before tick, so the transfer follows the DOM update that removes the activated control.

There is no new state, ref, mirror, effect, shared primitive, event listener or response-time autofocus. `focusSection` itself is unchanged. Existing `retryBriefing`, `openDetail`, `retryDetail` remain unchanged. New Clear and export Retry invoke focus once at action time; summary/export response handlers do not focus anything. If the user moves focus after the tick transfer while a request is held, a later response has no new code path to steal it. Export retry failure remounts the existing role=alert while focus remains on the region; it does not force focus to the newly announced alert. Native failure/no-steal verification for new actions is still pending, even though the existing report Retry seam already has behavioral and v6 native proof.

Normal Export Excel remains mounted, updates label/disabled state and uses its existing fetch/downloadBlob path, without the new retry focus helper. No new fetch, request retry, export query, filename/MIME, abort behavior, data subset, chart redraw or preference write is introduced by the focus additions. `session.select(defaults)` still follows the existing one-summary transition and closes detail; the focus call adds no I/O. Export retry starts one existing fetch and moves focus without awaiting the network response. No global alert or ReportWorkspace API is broadened for a local event concern.

Direct consumers: TrainingReportsPage is exported through training/index and rendered by the one reports route; TrainingFocusSection has exactly one runtime consumer, TrainingReportsPage. Existing Button renders href as an anchor and spreads restProps onto it, so the SvelteKit attribute reaches the actual `<a>`. All other Button/shared workspace users retain their bytes. The DOM IDs are stable and single-instance within this route, avoiding an ambiguous shared ref or a changed API.

Reverse consumer census still has five OperationalMatrix.Root call sites: TrainingReports supplies derived cell identity or explicit null; TrainingMatrix, IctMatrix and IctReadinessMatrixTable omit selectedCell and preserve their remembered internal selection; test harness supplies its identity. Shared root/context/cell/types and all those consumer implementations are byte-identical to source77. Null still means controlled none; omitted undefined preserves internal memory; context's normalized identity-or-undefined type is unchanged. The v6 real TrainingMatrix cell-open/Cancel/no-write proof is retained at source77, not re-executed here. No new ICT live execution is claimed.

The report Session, API/server/query/parser/model/export/workbook/migration and all inherited access dependencies remain unchanged from the reviewed integrated source. Therefore this bounded action correction does not add a new auth/performance/data/model contract concern under ee1. This statement does not certify incoming explicit-context main integration, which remains blocked and deferred.

## Supported local SvelteKit preload correction

I independently read installed primary runtime source, not a third-party summary: local `@sveltejs/kit` package version is 2.61.1. `src/app.html` sets body `data-sveltekit-preload-data="hover"`. In local client.js, `get_page_key(url)` uses pathname plus search; preload's same-page skip compares current router URL key with resolved anchor URL key. Its shallow `replaceState()` writes browser history and page state without assigning `current.url`. The report Session updates its query through that API. Thus a same-page `#training-affected-soldiers` anchor after a shallow filter update can resolve against the new document query while the router's current URL retains the old query. This supports the explanation for v6's actual redundant `reports/__data.json` GET on Focus interaction; it is a source explanation, not a separately observed standalone hover experiment.

Local utils.js includes `'off'` in valid preload-data values, resolves the closest element's explicit option before inherited body options, and maps it via `PRELOAD_PRIORITIES.off = -1`. Hover/tap priorities 2/1 cannot satisfy `priority <= -1`, so that anchor opts out of `_preload_data`. Preload-code has no explicit ancestor option and defaults to off in the inspected app. The fix uses an established HTML/SvelteKit control at the exact anchor; it does not alter global preload defaults, rewrite router state, add wrapper code, replace the anchor, or bypass native click behavior. The existing prevented-default onOpen callback still calls requestDetail with one scoped focus key, no record IDs in the page URL. Anchor semantics and accessibility labels/current state remain intact.

An attribute-only unit assertion would mirror implementation without proving actual routing. Omitting it is appropriate; fresh native hover/activation and request receipts must establish the intended zero-page-data/one-detail result. Current v6 request IDs148/149 remain historical failure evidence at source77 and are not relabelled successful by this source fix.

## Test behavior and actual owner proof

The two Clear cases scope their queries by accessible container: `group` Training report actions versus `region` Training readiness briefing. This makes the tested actor explicit even when both controls share the text. The no-requirements fixture retains a configured CPR type in filter options but sets its domain `isOptional:true`, so the model has no readiness columns/percentage and renders the intended no-applicable panel. The owner's first draft did not render that panel and selected the toolbar control; it was corrected before the preserved decisive red run. The fixture correction is acknowledged, not silently treated as a first-draft reproduction.

Each Clear case focuses the actual button, triggers the native-component click seam, asserts `isConnected:false`, expects the independently specified stable region while a controlled request remains unresolved, and then resolves the request and verifies real report table plus continued focus. Export Retry starts a failed actual component fetch response, finds alert Retry, focuses and activates it, asserts exactly two fetches total (failed initial plus retry), asserts Retry disconnected, observes region focus while pending, then resolves a Blob response and checks restored Export label, alert gone and region focus. These are meaningful disappearing-control and focus outcomes; they do not freeze CSS/geometry/internal variable names. Stubbed Blob/URL download is a cheap component boundary, not evidence of real workbook contents or native download.

Actual corrected `red.log` has 24 total page tests: 3 failed / 21 passed. All three new cases fail at `document.activeElement` expected stable region versus actual BODY; their preceding disconnected-control assertions passed. Toolbar/panel fail at line295 and export retry at line317. Thus the source-inferred export Retry bug is now independently reproduced at the component boundary, still not natively proven by v6. Actual `green.log` has all24 passing. Training suite has35 files/396 tests passing. Svelte check has0 errors/0 warnings; touched formatting/lint reports pass. These are actual owner logs read and hashed; I did not execute them.

The existing separate report Retry moved-focus test covers absence of response-time focus stealing at the shared focus seam. The new actions add no response focus call, so copying that implementation-level test twice would duplicate coverage. New-action browser evidence still must cover held focus and moved focus as selected by the driver. No new unit assertion pretends to prove SvelteKit preload networking or print pixels.

Owner component/test source and full diffs exactly reproduce committed current source after Git-header normalization. Page bytes are exactly source77 after reversing only clearFilters' added focus call, added retryExport handler and alert callback replacement; Focus bytes are exactly source77 after removing only the opt-out attribute. This independently confirms unchanged DOM/markup/layout/print behavior rather than relying on owner's prose.

## Actual v8 gates and governance block

All seven required entries exist in actual `.verification/1504-v8-required-checks.json`; six exit0 and governance exits1. These are root-recorded checks, not reviewer execution.

| Required command | Exit | Actual evidence |
| --- | ---: | --- |
| `npm run format` | 0 | `.verification/1504-v8-format.log` |
| `npm run format:check` | 0 | `.verification/1504-v8-format-check.log` |
| `npm run lint` | 0 | `.verification/1504-v8-lint.log` |
| `npm run governance:check` | 1 | `.verification/1504-v8-governance-check.log` |
| `npm run check` | 0 | `.verification/1504-v8-check.log` |
| `npm run test -- --maxWorkers=4` | 0 | `.verification/1504-v8-test.log` |
| `npm run build` | 0 | `.verification/1504-v8-build.log` |

Actual full test log reports 689 files / 6,892 tests PASS. Its `fatal: bad revision '1234567890abcdef'` is the retained negative fixture in `scripts/ci/changes.test.ts`, not a failed test hidden by a summary. Check has zero errors/warnings. Lint has15 warnings and0 errors, including retained SvelteMap warnings outside this correction. Build completes with retained optional `@opentelemetry/api` dependency-location warning. Warnings are not a clean-console claim or fabricated failure.

Governance actual log is exact: `Module boundary comparison unavailable: Branch is behind origin/main (49cacc665891b7e0edf95c6bb97993b8ca9837a2); integrate current default content before checking`. This is a real unavailable comparison / failed gate, not PASS. User explicitly deferred Phase8 integration and rebase except push-required work; no merge/rebase/ref rewind, check bypass, scan reduction, exception or guard change was performed. Current-main candidate acceptance is blocked, even if owned source/tests and local build are clean. The Definition of Done says full validation is candidate acceptance rather than permission to push and permits an authorized push/review handoff with validation pending when reported honestly; it does not permit accepting/merging an unvalidated candidate. The boundary remains same DRAFT PR, authorized push and stop; no ready/hosted review request/monitor/integration is inferred from this source acceptance.

## Print, matrix and durable evidence continuity

Actual Page DOM is unchanged after subtracting only authorized event handler/callback changes; actual Focus DOM is unchanged after subtracting only the preload attribute. No print stylesheet, CSS/class, pagination limit, chart primitive, no-data wrapper, detail marker or print event changed. The existing `data-print-section` marker on AffectedSoldiers remains byte-identical. App CSS, detail component, report workspace root/section/state, forecast chart and matrix root/context/cell/types exactly match source77. The accepted v6 four native PDFs/15 landscape pages remain evidence at their actual tested source77 pin; no print re-run is demanded solely to exercise these non-layout action/anchor changes, and no future PDF is certified. Pixel layout judgments remain Claude's delegated review.

The v6 archive is unchanged with exact expected hash and actual expanded payload audit. Its report Retry, cell closure and short PDF content repairs remain accepted at source77, while old-pin N2 redundant preload and N3 empty Clear BODY remain honest historical findings. Active selection all-six pointer/Space acceptance at a586 from v5 and extra ten native repetitions in v6 remain historical proof; no newly changed mandatory selection binding exists here. N1 unchecked-first roving Tab remains a baseline-unestablished note; N4 legible Print wrap remains a usable visual note. Neither is promoted into an actionable new source defect.

## Findings and dispositions

| Finding | Severity | Actual evidence | Disposition |
| --- | --- | --- | --- |
| v6 N3 disappearing Clear filters focus | P3 at source77 | v6 native panel action→BODY; corrected component red for both buttons | **Source fix accepted at 8cdd; native closure pending v7**. Both Clear handlers use existing stable region. |
| Export-error Retry disappearance | P3 at source77 | Source inference plus actual corrected red→BODY with Retry disconnected | **Source fix accepted at 8cdd; native closure pending v7**. Explicit retry wrapper avoids changing ordinary Export. |
| v6 N2 Focus extra page-data | P4 at source77 | Native two GETs; independently read local supported preload trace | **Source fix accepted at 8cdd; native no-preload/one-detail proof pending v7**. |
| Current-main governance / Phase8 integration | Acceptance blocker, external/integration state | Actual governance exit1; actual main49 not ancestor; complete census recorded | **Overall candidate acceptance BLOCKED**. Deferred integration is not an owned-source bug and is not silently treated green. |
| New source bugs in bounded delta | None found | All four executable/test/recipe deltas and consumers independently reviewed | Scoped owned source clean under integrated ee1. |
| N1 / N4 notes | Non-actionable limits here | Baseline not established / delegated usable visual wrapping | Retained, unchanged; no scope-expanding fix demanded. |

The unchanged goal migration `supabase/migrations/20261004100618_training_readiness_goal.sql` is 484 bytes SHA256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`; remote application is a separately authorized release obligation. No SQL was executed by this review. No clean whole-issue, current-main, native-v7, ready or merge verdict is issued.

## Complete owned path census at reviewed 8cdd

The table includes archives as bytes and all deletions. `same` means actual HEAD state equals prior source77; `delta` means reviewed in this round. Actual base/prior/current byte sizes and SHA256 are preserved in `census.json`; a deleted path retains its actual base/prior provenance there.

| Status | Path | Continuity | Reviewed bytes / SHA256 |
| --- | --- | --- | --- |
| M | `.agents/skills/verify-trooptotask/SKILL.md` | same | 55189 / `471508b5d66002281f1ef45d068c3ba5b936b2e3be08deaba1d6d0ff3ffaaf0a` |
| M | `.agents/skills/verify-trooptotask/features/critical-tasks-completions-readiness.md` | same | 16679 / `5d4834c8e763b412e951ca9ea617c0b120515612a274522c89ad6ec05e779ebc` |
| M | `.agents/skills/verify-trooptotask/features/organization-settings-destruction.md` | same | 32945 / `8305c969f67490db2998a29051159b27afb7541a15628c997fd12f9bf88d3c94` |
| M | `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | delta | 32448 / `f69a183328c3b7798b4c982117666d24c6c79cf4fe981d789e709fd0428cda4d` |
| M | `.agents/skills/verify-trooptotask/helpers/control.mjs` | same | 90530 / `d426c720af9eed040bbd4827352303e471c576792cf5adfecdd7f02a46af1bda` |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.mjs` | same | 1053 / `05885ab449dc9b15805f159896234890762e2b25770c9e708b675e09a5db0489` |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.test.mjs` | same | 1743 / `e9a3c9bb5c9ce486d200beae84e7b1a05f4cfa6dd867cc5d891d904c53b2b509` |
| M | `.agents/skills/verify-trooptotask/helpers/settings-request.mjs` | same | 2102 / `3542f8b4e90a8204f42ca1d1e790e732b81a15325bd26d0c49a0ddb46b311956` |
| M | `CONTEXT.md` | same | 11259 / `4637eb30bff5deb8a4b8e52e368787254bd4ac81849349af22fd4d984681534d` |
| M | `docs/architecture/ARCHITECTURE.md` | same | 16127 / `7e1869c0118b6c907ca6ce715c1107c84f1effec13b8570bfcd39f1642c923f7` |
| M | `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` | same | 81037 / `9ec1b5604af14618c4c8026a9f07cc45e17d405db964dc116c8bfc18e82e8455` |
| M | `docs/architecture/CURRENT_OWNERSHIP.md` | same | 107351 / `693e719e5f5ba57f3a24e12e801099dc4ea07cd8c1c71d35dab06e563bad78cd` |
| M | `docs/architecture/MODULE_CONVENTIONS.md` | same | 41230 / `dc323e853c6a32339fb9ca3d6be155c553f8f953ecd8ff277d7203043d67c6bb` |
| M | `docs/component-catalog.md` | same | 86370 / `270034c569133007691d6a0a3fc9327630b73cbd38a059bf03665ddf40ae954f` |
| M | `docs/domain/retained-feature-rules.md` | same | 8048 / `d83fde06bb80a92c854c64ba6c4718980ce406e7236b6e28c10541db9fdfc99c` |
| A | `docs/verification/training-reports-1501/acceptance.md` | same | 11784 / `06b6904e31ed613c9e832826bc5d02bfadfd68241404132e1bcb18688692644a` |
| A | `docs/verification/training-reports-1501/baseline.tar.gz` | same | 281614 / `0b2f279ddc5b7f22b849cfdb35d6617e9a09c3bca82b369077c7530d6a9a631a` |
| A | `docs/verification/training-reports-1501/final.tar.gz` | same | 537699 / `72ebffdbd185f85f7af876c428c5f127d94320cc09729d83411bec34a9b2ff4a` |
| A | `docs/verification/training-reports-1501/validation.tar.gz` | same | 235881 / `73af61b577db8e4d8144baaaa1d5842fb9afcef89c4c3b1fc7439de7cd727df6` |
| A | `docs/verification/training-reports-1502/acceptance.md` | same | 12101 / `a20f2a7430722f08c336079316cd58705f02306e1760bb76e3533bd2da246049` |
| A | `docs/verification/training-reports-1502/baseline.tar.gz` | same | 182877 / `3f5eed79100b3747453564f95b366eaf66e3c48c7ab1fd72384ddce456c3da2f` |
| A | `docs/verification/training-reports-1502/final.tar.gz` | same | 857125 / `7587454d049dcd8397598fb5537d36410df82e2689524cd1d0d4dd5f43f12626` |
| A | `docs/verification/training-reports-1502/validation.tar.gz` | same | 94200 / `ccc30126735e7e9801314261127e293ae7b336aef96473a4270a9825b13e0df2` |
| A | `docs/verification/training-reports-1503/acceptance.md` | same | 13175 / `afe547eb816c30295b5e4ae21b70a3717a10fa08ede3487ca92e74372b387d8f` |
| A | `docs/verification/training-reports-1503/baseline.tar.gz` | same | 1704184 / `fa83957d99b581bbb93df8b4337f139d827d8df9dfb3e5a8524c099248dee4c9` |
| A | `docs/verification/training-reports-1503/final-integration-v8.tar.gz` | same | 4770012 / `0469994bbce1b9e38229573a55c2f8b704f0f5831783232156b3528a98d4836b` |
| A | `docs/verification/training-reports-1503/final-v7.tar.gz` | same | 16701741 / `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200` |
| A | `docs/verification/training-reports-1503/independent-acceptance.md` | same | 57300 / `cd3e54b63594d997c49af701ebaf306841d95f2b253f7813e6d65b417444dd24` |
| A | `docs/verification/training-reports-1503/validation-v8.tar.gz` | same | 3038956 / `c59b77f146140d46f2879a83e9d3bbf3f97470a7abd9574b4a9e56319995402e` |
| A | `docs/verification/training-reports-1503/visual-failure-v2.tar.gz` | same | 4546927 / `506cdc2433025c1beebec1c8c9cb8e5d779db718498280f604cfd0281c266a5f` |
| A | `docs/verification/training-reports-1503/visual-failure-v3.tar.gz` | same | 3567677 / `973f3cb2fd148afc95784530a38e902a1f0eb16fee3630a3478f4a2c88410299` |
| A | `docs/verification/training-reports-1503/visual-failure-v4.tar.gz` | same | 2911869 / `bf1a94039ba6d48bb56a38ec4c5f1c3221a1746a3d70834221849a45a5403bc7` |
| A | `docs/verification/training-reports-1503/visual-failure-v5.tar.gz` | same | 1696296 / `f316ce2e80ac8f038530c2cf1093b0ac834483face74caa9fb24566dca018d8b` |
| A | `docs/verification/training-reports-1503/visual-failure.tar.gz` | same | 6591417 / `04d94812ab5c1543f3fe783f64dc9a981bae1b9bcdb02cdd15e39130ea3d0925` |
| A | `docs/verification/training-reports-1503/visual-unavailable-v6.tar.gz` | same | 254498 / `8e44e2ba1a5005c74b977816ac1c0e6478fa13e3f2e3e162f99855dcc1ae6ff5` |
| A | `docs/verification/training-reports-1504/baseline-v1.tar.gz` | same | 3741607 / `a29ca4b5220fdd1c500a59a674669bcce310130598a27d3bca419f03e11a3896` |
| A | `docs/verification/training-reports-1504/final-attempt-v1.tar.gz` | same | 8194402 / `0347ab3ccd6e78bc303fe65c8171126e9b0b98d4e9bf108b9cdd4ad33ab85104` |
| A | `docs/verification/training-reports-1504/final-attempt-v2.tar.gz` | same | 4659392 / `a7eebee6b56f22187bc73da4b00b07f75f74bae655bd3e65d39b9ba2c72a7c05` |
| A | `docs/verification/training-reports-1504/final-attempt-v3.tar.gz` | same | 5452614 / `0231f92582ce913d59ff37e09cfd9a5316a33b6dbe5f4f734e8abb68f44791cc` |
| A | `docs/verification/training-reports-1504/final-attempt-v4.tar.gz` | same | 7392445 / `81af91ee6e2fec495d5426d71e35f0c61e2dfae1a32e5e07c5b1949ae3220d98` |
| A | `docs/verification/training-reports-1504/final-attempt-v5.tar.gz` | same | 1755326 / `3227b88d8b18171dc5b9416a729d2252484e854cfbe0bdab7bca481ab1356aaf` |
| A | `docs/verification/training-reports-1504/final-attempt-v6.tar.gz` | delta | 3621597 / `b829e3a7c14995246df148fc0e487e9baad07c715cdadf137b8abc764f51f644` |
| M | `scripts/ci/database.py` | same | 32698 / `67189f0a4470552476e2b1899a564222f753e66e4c4a556eb4efeece5caab5d1` |
| M | `scripts/module-boundaries.json` | same | 15700 / `5da0bbe281179860751db7d0f41dce3e044dc514f0e94d5dfeb22ac04abcfe45` |
| M | `scripts/verification/daemon.mjs` | same | 12825 / `ce95182391fda1948594697e8d96bf60e44d7fae04f89f87b143aa4f63fc3bcf` |
| A | `scripts/verification/print-capture.mjs` | same | 14213 / `820e041e5dcab48d98f119cc66dc12cd6710a1291960e99fdce9634412ce7f73` |
| A | `scripts/verification/print-capture.test.mjs` | same | 16744 / `2073c15b6ccd1e454178616dac3b045ddf1a45b0c6452604a06bc54a84770a3c` |
| M | `src/app.css` | same | 14610 / `8536b4f70d589435a87181e445ab5a4d5e607e8351d855b049eade028b7683a8` |
| M | `src/features/app-shell/components/AppShellHeader.svelte` | same | 25591 / `26bd934d4a9a592ed42c9caf165cd8ae4c00b9df410c1dd12dadbff1117ad4f6` |
| M | `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts` | same | 26235 / `5e982bd1a4f547405009c22444b291259f64744b929007ac4eb5901a79a21a8a` |
| M | `src/features/organization/PoliciesSettingsPage.svelte` | same | 3806 / `6387821b225c4dc09f17961d45991d1c7f0b6d9ec0117514f4cf99b57adf9a33` |
| M | `src/features/organization/PoliciesSettingsSection.svelte` | same | 5926 / `0a3013074eafa30fc05cc77bafecaec607d0b494e9412904f0e411a588565c4e` |
| M | `src/features/organization/policiesSettings.ts` | same | 1433 / `cb71f5ee1514d916ad50adaa0dc88158f15bd2de4eeb27a1256a93e60e37fa1d` |
| M | `src/features/organization/policiesSettingsState.svelte.test.ts` | same | 995 / `24fdf5cbddc67e146412104144f4298837e1e7b3f86a5a2094590c6c53aef778` |
| M | `src/features/organization/policiesSettingsState.svelte.ts` | same | 3836 / `e6d6a86506216a2bebb312b7b8b872ff9b5bbf638072f3937f8311e9b123295e` |
| M | `src/features/organization/policiesSettingsTypes.ts` | same | 835 / `12c2b6158b1febe38fb9be7bdc335ca71c74b0d4626a7ccbf39d5328a0b81531` |
| M | `src/features/organization/policy.server.test.ts` | same | 7060 / `0aeb4a5034df40434f32b0bcebc878a944496317c82f96cd14f69841329abb43` |
| M | `src/features/organization/policy.server.ts` | same | 3715 / `f91bbeae6ba9cd95f2f96d6ed1e674130770bb510e03bc08495ae8b9d1129147` |
| M | `src/features/organization/policyConstraints.ts` | same | 438 / `3277ff269a8b8fa5abc28d1823306d665771c77ccbf5d3b194a733c47b5c459c` |
| M | `src/features/organization/policyProvider.server.test.ts` | same | 5262 / `b5fb2466ea43355975c8eedf995c5360a6930b0b952d5fecd482e3fdd1dc3751` |
| M | `src/features/organization/rawExport.server.test.ts` | same | 6645 / `fcf0e931ef9285590c8ff77750e033a0631fa2956cbad5cf5498e7ceab63e1cb` |
| M | `src/features/organization/rawExport.server.ts` | same | 1537 / `24d2c7e8f32f9ff7203ada500cb3fc73ecad4f2cde67d768dbd10364b33980f1` |
| M | `src/features/organization/settingsProvider.server.test.ts` | same | 6480 / `b23aa3607a1042ae080dba4e77efb2a0b5f24392f79d3cefe7d50394d2cce91b` |
| M | `src/features/organization/settingsProvider.server.ts` | same | 3494 / `db5e7cf7a33b2071d222475a3700547b61dbc45da9d7936fbc84250778536c92` |
| M | `src/features/organization/settingsTypes.ts` | same | 1907 / `d8122efeaac05752409487c67d598639c9ecf7382578d19b7c5849ab0d01e92b` |
| A | `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | same | 5910 / `b279c8b2482ff74495785067e66270b977dcba000e93651d14bbe2ad14a7e443` |
| A | `src/features/training/components/TrainingFocusSection.svelte` | delta | 2278 / `0ef6bbdf9c2f88a7f02404746ff92414cf857adc1cfa2d01602854559f1f6344` |
| M | `src/features/training/components/TrainingReportsPage.svelte` | delta | 23777 / `585bbb4a50709a368766bae09a11e50aa302e69ef0ccdf53af15b81d0e5e8d06` |
| M | `src/features/training/components/TrainingReportsPage.test.ts` | delta | 28556 / `c8a1ef97b598ba803e73aead1341fcb30f7c2da75ba489476fd9d9fa2932e1d5` |
| A | `src/features/training/components/TrainingTypeRiskSection.svelte` | same | 2759 / `33dee409eaeed3bc5d8ecabcff388b86ec79a7c4aa0af443e65cf322c2590d56` |
| M | `src/features/training/contracts.ts` | same | 7148 / `7a9d7f410e94e218b4dc0fe61c7dc2f863e8e4dce53f0381962454617097c821` |
| M | `src/features/training/index.server.ts` | same | 1808 / `40b0946bff46984dc7d44f986d35498ead42dbfee78c4c628ca692c87922ab14` |
| M | `src/features/training/index.ts` | same | 1944 / `3c493ea7b65d8478564a8f2c80b5f347f41fb4f0909cc76e626811de113c4ebb` |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.test.ts` | same | 10297 / `9c89254c232bb20c83b75a809b7f6b5821f00666b168ee1bb5f209d884feeb8c` |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.ts` | same | 6735 / `cec6544443d09a1a5d61a06b0b0a6bb1bf5db48fff7a25a0dac36e3ea239105d` |
| D | `src/features/training/read-model/trainingReportScreenModel.test.ts` | same | deleted (absent) |
| D | `src/features/training/read-model/trainingReportScreenModel.ts` | same | deleted (absent) |
| M | `src/features/training/server/trainingReportsQuery.server.test.ts` | same | 16694 / `a255269cc00b9589b8ee66545d2dde546f8262e3f3459ac6cf3015db5e6c4c92` |
| M | `src/features/training/server/trainingReportsQuery.server.ts` | same | 7878 / `79b6574e127b89ddad76ed7a0a05dfac26ef2a81ce550d537eab4f0ded05449a` |
| A | `src/features/training/utils/briefingFilterLabels.ts` | same | 1621 / `884489a6cc909c9438bcfc7db9c349f8f704a9f2a527fca8ede9065ce9917b7c` |
| A | `src/features/training/utils/briefingReportInput.test.ts` | same | 2551 / `5aac480a55e0e96837ad4782e56cebbecb9b5b257188bbeb1b430ec59b52084f` |
| A | `src/features/training/utils/briefingReportInput.ts` | same | 3530 / `5b3c49540eb8591151213eaa2be50506a7dc60b78b17dfbc4e7df7a6e6226e9b` |
| M | `src/features/training/utils/reportCalculations.test.ts` | same | 2714 / `74916a25f2e7c32a85b90892a465bfa384891625bbeecc55e7baf54bba792dc2` |
| M | `src/features/training/utils/reportCalculations.ts` | same | 949 / `2839a3c388902c378985251eb859f8b34447b0236c2f54648b4f6da6310ecef6` |
| A | `src/features/training/utils/trainingBriefing.test.ts` | same | 42695 / `51954b8c21e2e394e7d4007ccc32747e862986d38f65cfaeca5158cd6ad1e184` |
| A | `src/features/training/utils/trainingBriefing.ts` | same | 26284 / `fb6bf3af5c5fd4e4287c8a159fda126eb6fe3247853c02544effc08eb33c6863` |
| A | `src/features/training/utils/trainingBriefing.types.ts` | same | 5125 / `2b6a3b651e78c99f7110c6ffa6a51b51467fc16b79c69311ba2eda30150f94af` |
| D | `src/features/training/utils/trainingReportWorkbook.test.ts` | same | deleted (absent) |
| M | `src/features/training/utils/trainingReportWorkbook.ts` | same | 6047 / `84ee4e8af3721dce0e1e6fcc981b700ec8684148f6e07a53cb2eb1170ab9a2ff` |
| M | `src/features/training/utils/trainingStatus.test.ts` | same | 13373 / `a7f081e6ea5d1878f309bf7b39bbf76ad2ff2acd644646942b9a3174500e39f3` |
| M | `src/features/training/utils/trainingStatus.ts` | same | 7205 / `ef0ae1f4efdf721a80bf83107c077567bc39369779d87d47f73cba13e92b8cd6` |
| M | `src/lib/components/BannerStack.svelte` | same | 772 / `9c1f03e3aa25a60e9d8ee5704523a973a4030ed4a34a6308d295ea84f798cc63` |
| M | `src/lib/components/ui/operational-matrix/root.svelte` | same | 2456 / `975d2518edd5cdbe57f9f441f8031246cc1c9a954ba1faea59f8fabf4de191ed` |
| M | `src/lib/components/ui/readiness-band/ReadinessBand.test.ts` | same | 2477 / `8cfbe81c63d4678cafb43a25a253424e55409c5b3b29ddc891292853e30afe75` |
| M | `src/lib/components/ui/readiness-band/index.ts` | same | 503 / `fbc42884b8a9e0edb6c4a57ca8c8fa6805a9724233587c8d6546e109f127a35e` |
| M | `src/lib/components/ui/readiness-band/readiness-band-cell.svelte` | same | 4300 / `0d18beafb2e765306a34296cd7c7f03ac8632aabd6062541cd58cb3d5bc56e8e` |
| M | `src/lib/components/ui/readiness-band/readiness-band-legend.svelte` | same | 1532 / `5fe61e364f174547d6c47b6baae963d41b583584d77da2155076f228aff4b3a2` |
| M | `src/lib/components/ui/readiness-band/readiness-band-swatch.svelte` | same | 2743 / `44df84a36ea4f58199c46ee5b63428c70e535da0cc49bd0104bf32851b7b2205` |
| M | `src/lib/components/ui/readiness-band/types.ts` | same | 1462 / `ad94ec16e0145657a4169005940e55f467668334dda4c9b8f688f52a3280bc42` |
| A | `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | same | 10377 / `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` |
| M | `src/lib/components/ui/report-chart/index.ts` | same | 352 / `1092440911915989fcd94b431998761d4f1d9659417fea254a72087be3b69230` |
| M | `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | same | 2752 / `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` |
| A | `src/lib/components/ui/toggle-group/index.ts` | same | 159 / `5ad8938622bce94f5d3611adbe7e13da8f5cd176f56d3eadeb6a8c8eaa334103` |
| A | `src/lib/components/ui/toggle-group/toggle-group-item.svelte` | same | 958 / `cbde5673054945e9ca4e5d6a588ab9dacffabf38fd4e4d05d3f966165cc82b27` |
| A | `src/lib/components/ui/toggle-group/toggle-group.svelte` | same | 1115 / `1a8ffb1f16373ccc2ad720aaa90e9e44012ba572875d0a544b184f7df868b900` |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-actions.svelte` | same | 5146 / `9edbf5d1eb0a05358266386e856f4e0990cf6b3f3291b70ffd24ca399a179af3` |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-select.svelte` | same | 1004 / `d533efc217a5e4e710dbe354f293c8728c13b8db721a90252b632fff631682cb` |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar.svelte` | same | 2149 / `9c5e79b4f5adc62580aaa6f619f8a823f93e22158a4265ef0ad8bf30a73e6d96` |
| M | `src/lib/domain/readinessRollup.ts` | same | 6983 / `737669f8b54d8df5422b0107f6d76e8fbb8fe107980e379e6f95db6cdf985058` |
| M | `src/lib/server/adapters/inMemory.ts` | same | 50952 / `59789a5fd371ad5d525ebced9e5152ead8156f571f5d7a6c27772255a990625a` |
| M | `src/routes/+layout.svelte` | same | 899 / `1a3a1b741a20359d17dce0b55245feab1810ae8bcbfe8cf0be1eba706849f7c3` |
| M | `src/routes/org/[orgId]/api/organization/settings/server.test.ts` | same | 1685 / `8f23cf37ededa97e0b0d061177d33dab3e12c651e8ae1505a83581ae01838f47` |
| M | `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.test.ts` | same | 36536 / `d693459f995e8ae7f9124c6d5ef92b5ab3b7f9b3b69221cfdef3f7fba49bec1b` |
| M | `src/routes/org/[orgId]/api/training-reports/+server.ts` | same | 852 / `a4c0df9f571653953281b2acf849ffacdc5eac128c398ac46fd4b1e215bb3467` |
| M | `src/routes/org/[orgId]/api/training-reports/detail/+server.ts` | same | 987 / `06bd97fe5143520927805bb32d55189dc49e3475a867a9d65ca32a45a1de1324` |
| M | `src/routes/org/[orgId]/api/training-reports/export/+server.ts` | same | 928 / `87411f0be57744195b120f322c5a56f6c3a2b3e0286ab34ed93d2f731d230f87` |
| D | `src/routes/org/[orgId]/api/training-reports/export/server.test.ts` | same | deleted (absent) |
| M | `src/routes/org/[orgId]/api/training-reports/reportInput.ts` | same | 1981 / `009576da7f537c6f19f46d534af1049a42a0cc449e777ed4ce545dfab6c0e87d` |
| M | `src/routes/org/[orgId]/api/training-reports/server.test.ts` | same | 6284 / `d7be28cccb4ce0296dda348a8022af6bc0a8ba2d84de78f64a29dbd351efc2de` |
| M | `src/routes/org/[orgId]/settings/policies/page.svelte.test.ts` | same | 9908 / `de92036ae278aa3b98946d85eb37982d58f6e0f21f29a5f3ec532eb83f588866` |
| M | `src/routes/org/[orgId]/training/+layout.server.ts` | same | 1115 / `21cf76fda470075596c65ff58bc6a8a446daf495e77f166bd96b7f55d7411f87` |
| A | `src/routes/org/[orgId]/training/layout.server.test.ts` | same | 2326 / `8190ea86c9c49900ded8bdc57b1020d19f212906fbe5f97b74a0bc000ca575f3` |
| M | `src/routes/org/[orgId]/training/reports/+page.server.ts` | same | 1489 / `e7e6d2836201e64b50178082b5d355b1b4131006de77bb59ce1791a2345c1d2d` |
| M | `src/routes/org/[orgId]/training/reports/+page.svelte` | same | 402 / `50375452496d62329f492c92d10a38d037105a517a61cb61e525ed66c9529eb1` |
| A | `src/routes/org/[orgId]/training/reports/page.server.test.ts` | same | 2718 / `aeb04d05b65435943fac1d3cbb0c0912bd61ceae8fc684d89a5efa4511c6e947` |
| M | `src/routes/org/[orgId]/training/reports/training-reports-page.svelte.test.ts` | same | 1948 / `7b9fdf08b9557ffeccb6d5d366dbc13ff439a23f374d53a1b6da28cacde8331a` |
| M | `supabase/migration-tests/account_preferences_scope_before.sql` | same | 5912 / `140eeeb708d3413fe84042bcf0b9cadf917f29c582c929f08be1d211bf170ce5` |
| M | `supabase/migration-tests/calendar_unassigned_populated_after.sql` | same | 4398 / `188f6f22c4f4e64041e4432191df15c0448283dd43a787aefa53f2e5a8d6e24e` |
| M | `supabase/migration-tests/critical_task_archive_retention_before.sql` | same | 5499 / `5784480a5ec4ce29e5a0184e199c4d3dccb7a0e11851f7ad48f710efac55d2e4` |
| M | `supabase/migration-tests/critical_tasks_populated_after.sql` | same | 3614 / `7bba26199cf6657413f432eeaec45cbc923d13d05bf4c178904320da0d320b8a` |
| M | `supabase/migration-tests/deletion_request_cancellation_before.sql` | same | 11329 / `be3d5381caa3c55c1a6173b82340156ebc8988fcac860cb4f82740e4fb446c5c` |
| M | `supabase/migration-tests/organization_file_upload_before.sql` | same | 3489 / `ba66b3617a2d6a92ca00d2950fd9b30ae7872eb65e0293cc015a4ba21a3a139e` |
| M | `supabase/migration-tests/organization_file_upload_contract.sql` | same | 12531 / `b577e25a5d1534a29dd2bacd10a646c48cd762c98cff943ceaed30dcdfe48619` |
| M | `supabase/migration-tests/organization_storage_cleanup_before.sql` | same | 8682 / `d84ef0838e68cccda4cf04770bc77fec34b2d8675d08cf9e57b8be7a24dc206e` |
| M | `supabase/migration-tests/organization_storage_cleanup_contract.sql` | same | 17845 / `c95a5f1b12952f5feb4bc80b782f4ecab72f48aefaa961891e4a9305ff088ba6` |
| M | `supabase/migration-tests/personnel_counseling_file_populated_after.sql` | same | 6202 / `ee8a49873cfe8dc1e376265dfc0c949cc12458208e9431c4f52f7eee7dc5a36b` |
| M | `supabase/migration-tests/personnel_extended_info_populated_after.sql` | same | 3190 / `b29adbc1a5b198b9b1254264c549bfc67cb8d217d723cf04729919e4a4e122fd` |
| M | `supabase/migration-tests/personnel_unassigned_populated_after.sql` | same | 3111 / `86cd11035201bd536e6cf9a06d2da4e2ad7dfbb6e37b247773885671e8f4e7b7` |
| M | `supabase/migration-tests/platform_membership_before.sql` | same | 2961 / `af77afdf7345a31344e2575148f74f52cc725e9bb3bad2ffa2124c46ba3559ea` |
| M | `supabase/migration-tests/rating_scheme_populated_after.sql` | same | 3964 / `67c70b777b71c46cd22a3d2cc9ac997971b14ca01dc80eca02ea8328957229b4` |
| A | `supabase/migration-tests/training_readiness_goal_after.sql` | same | 456 / `9e7ad7b21cf73d8c5924d60cefc16b4e22d6a48a1db5ad1e50d6f8c8f417adc4` |
| A | `supabase/migration-tests/training_readiness_goal_before.sql` | same | 2281 / `00a1fdc4afb86a4e2dcd9930c303aed95f1fb807f00013d333e80c648e36104e` |
| A | `supabase/migration-tests/training_readiness_goal_contract.sql` | same | 4107 / `129eb2e3bfd28381b4fb20b815a7d8ba21a78a54112f53ac39f16ec6f0a8742e` |
| A | `supabase/migration-tests/training_readiness_goal_fresh.sql` | same | 200 / `fce1306b65521fcb23d94a6f0511d94ea4b32d3eb4bcbd467c63a2ed54fa947c` |
| M | `supabase/migration-tests/training_record_populated_after.sql` | same | 3284 / `627c5f6bb7c4334d92d5d9962b1d1278c6dc1aaffec4779b76ef7ecd62df0869` |
| A | `supabase/migrations/20261004100618_training_readiness_goal.sql` | same | 484 / `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962` |

## Selected unchanged dependency pins

All below are actual source77 = 8cdd blob hashes and match working bytes; the complete inherited access census of70 is separately preserved in `census.json`.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `src/app.css` | 14610 | `8536b4f70d589435a87181e445ab5a4d5e607e8351d855b049eade028b7683a8` |
| `src/app.html` | 1201 | `f24a686265cca5cf2eeba816e7667a6d664d2ddd888147b2d86a2cf2606a0b7f` |
| `src/features/critical-tasks/components/IctMatrix.svelte` | 15559 | `4d4fbc1417f856edf2ccf23770a5ae6c19d30a5471a0982c9a88e6877851d272` |
| `src/features/critical-tasks/components/IctReadinessMatrixTable.svelte` | 5933 | `70ae5a9f40d6024196271cb0226dfb1895f778a61d4fddf4b8bb45ad464b63da` |
| `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | 5910 | `b279c8b2482ff74495785067e66270b977dcba000e93651d14bbe2ad14a7e443` |
| `src/features/training/components/TrainingMatrix.svelte` | 11398 | `c36e04aca73ddd84fdf6d464f1d7c33f699de15e8b51f55af85344a59b34731b` |
| `src/features/training/read-model/trainingBriefingSession.svelte.ts` | 6735 | `cec6544443d09a1a5d61a06b0b0a6bb1bf5db48fff7a25a0dac36e3ea239105d` |
| `src/features/training/utils/trainingBriefing.ts` | 26284 | `fb6bf3af5c5fd4e4287c8a159fda126eb6fe3247853c02544effc08eb33c6863` |
| `src/lib/components/ui/button/button.svelte` | 3844 | `82dcaad7df84064398e90eb2171beb42406983d3aab0b1876ee49e997f123d86` |
| `src/lib/components/ui/operational-matrix/OperationalMatrix.test.ts` | 3098 | `ef04b68487c938864a367ce1d06cdcc9b1f2218af63611c748bbc2122923f19d` |
| `src/lib/components/ui/operational-matrix/OperationalMatrixTest.svelte` | 3394 | `68e363482aa4702b40ab7c0825a77efcb4fd7450bf33e06f2e5843f6aab894f2` |
| `src/lib/components/ui/operational-matrix/cell.svelte` | 2150 | `ccc90d5025d3055ff5dea862cea5e75671c3f47b0cf43d105f773d5e035f38cd` |
| `src/lib/components/ui/operational-matrix/context.ts` | 1153 | `27752ce1c597b8d3068f5f64c6ba5627d7ffd50b824c283af6ea65fb43332d51` |
| `src/lib/components/ui/operational-matrix/root.svelte` | 2456 | `975d2518edd5cdbe57f9f441f8031246cc1c9a954ba1faea59f8fabf4de191ed` |
| `src/lib/components/ui/operational-matrix/types.ts` | 939 | `e62d5f9fa1d311f4f8d1297ad0e546b9052a579e9b5ab652487afe44409db70d` |
| `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | 10377 | `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` |
| `src/lib/components/ui/report-workspace/report-workspace-root.svelte` | 546 | `cc224212cbf54cca16dc68a79f6ef180bde77e64e1b09a8bbf7d6bb8a2db4101` |
| `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | 2752 | `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` |
| `src/lib/components/ui/report-workspace/report-workspace-state.svelte` | 1885 | `a978880a5b04ee73ea9ce8588d8199dc9189320ee708a38ada2aa291597f2490` |
| `src/lib/utils/workbook.ts` | 4679 | `e6c0a7944bb2a63bdc258c974dd2e7fc7bd05182e25ce4aa62d14a93b5fb5ef9` |

## Audit scratch and actual proof hashes

Exclusive `.verification/review-1504-final-source-v4-e8b17/` contains complete `census.json`, `current-main-census.json` (390 rename-aware entries /397 endpoint pins plus full incoming census), `consumers.json`, `owner-diff-reconciliation.json` and `evidence-reconciliation.json`. Incoming paths are explicitly dispositioned as deferred integration/census bytes only; their semantic acceptance was not attempted. There was no source/test/service execution by this reviewer.

| Evidence | Bytes | SHA256 |
| --- | ---: | --- |
| `.verification/1504-final-action-correction-owner-v1-report.md` | 6053 | `92e96565978e9b9ca664cd15fc8b4893452eb95ed4d1b68503f0081dd648b17f` |
| `.verification/1504-final-action-correction-owner-v1/red.log` | 150866 | `7385a0e332c941abb4031e91b03b03ac60384e7934826fa0830251b7ed8290e4` |
| `.verification/1504-final-action-correction-owner-v1/green.log` | 262 | `f67a1646db60dfc4073394632cc73ef6cc20d5f0edc38908aa8c095b11713bae` |
| `.verification/1504-final-action-correction-owner-v1/training-unit.log` | 269 | `d1712c3779e9c867425b2e03a5d4e4dbd350f3adcd5e5a12f6b9cfb1fc65544e` |
| `.verification/1504-final-action-correction-owner-v1/svelte-check.log` | 174 | `7e7a1fedcf2582ff44e5ad037614580b75b20c417356ccc38602c11a5e2db56a` |
| `.verification/1504-final-action-correction-owner-v1/format-lint.log` | 66 | `17aa973d3f004560237d9a95171210b0671deff23d61628eecf7322ff5938f20` |
| `.verification/1504-final-action-correction-owner-v1/source.diff` | 1658 | `bea3b40794d040140a29f0534a8b33a01221cfd18fd446ba0a48398293a1a3f6` |
| `.verification/1504-final-action-correction-owner-v1/full.diff` | 5606 | `92086360606cb143d9338383c1fd21d5ede1e2ee383da78fbbd0f26d77724695` |
| `.verification/1504-v8-required-checks.json` | 1191 | `7cd030c2bed9bdf2bc819260d07333f7720cde70f7da4c887075df200bdc8331` |
| `.verification/1504-issue.json` | 3874 | `f76a770a21d264bcacb6131e3c35e65c06f03c5c321a6fd55983b3dfabf2d5c3` |
| `.verification/1433-for-1504.json` | 25791 | `0fb86901e245748799c0b7d3aaba8117ac9d823ea67c8dcbc08386453a076536` |
| `.verification/1504-independent-final-source-review-v3.md` | 24751 | `03e2eb2a4cf5f28430386053f7572351ca1e7e3358767dc25f23928053c901d8` |
| `.verification/1504-independent-final-attempt-v6-review.md` | 29672 | `7857fda334a112b671456a5a8458107fdf37a7a66eada9b59bf8b3ede8a894b3` |
| `.verification/1504-v8-format.log` | 164050 | `97f67ee1de2b5a918ab2167c03fce3526b525e9adb5916c6d6f8ec389985de3a` |
| `.verification/1504-v8-format-check.log` | 122 | `1f2feae27efb734868160931992e538ea6cfc998bc593fdba1ee04875e3e0c15` |
| `.verification/1504-v8-lint.log` | 3629 | `a4864f93caaa1c41c520fb657ee8fd02a509b34f5e10722c086d65c01369997d` |
| `.verification/1504-v8-governance-check.log` | 268 | `258e81534f60b0021ac634bf63df02eb50b1364a110ee04b9d914afc21692cba` |
| `.verification/1504-v8-check.log` | 273 | `f8ae14b6c8ccf1cb89ee4a5d9d74406bdbe4708b1c5853325f456d8bcad1f770` |
| `.verification/1504-v8-test.log` | 370 | `b8c758a023985e378540a8754b4c86f246f6ecca528474401cd581b1329314ea` |
| `.verification/1504-v8-build.log` | 139052 | `15bac1ecb78a5fd2a46881498a120071915a17f8aa77e54b2b832754cbe73774` |
| `node_modules/@sveltejs/kit/package.json` | 4288 | `fd1cebd12a0799e99e54beaf05f1408ba20a0c84db8d9ce25f59c0c70520f61b` |
| `node_modules/@sveltejs/kit/src/runtime/client/client.js` | 98967 | `c28bc4827bba0abfc7169bfea903e032dfa540d186b16c8a1b4f9cb2c52dbb16` |
| `node_modules/@sveltejs/kit/src/runtime/client/utils.js` | 8933 | `385cfe2a44fbbc071027830fe3a44e0cb44b4c8f73108c9bd09f097ff9958320` |
| `node_modules/@sveltejs/kit/src/runtime/client/constants.js` | 427 | `451ada25d94f51a0d2fa99e8dd48e656d83fadb8690aec83469f80ae0331466c` |
| `.verification/review-1504-final-source-v4-e8b17/census.json` | 122522 | `db687f25d8e7c2d1144865d5397a8227190316c7004d023c280169a0e4f0c115` |
| `.verification/review-1504-final-source-v4-e8b17/consumers.json` | 7946 | `4f28082fe442fdf3b6527b7722dd03d3a5c19d0d0cd505ce0d20794631a0cb47` |
| `.verification/review-1504-final-source-v4-e8b17/current-main-census.json` | 392887 | `75aa960be0fb9d0c6d75b79bfcdc109c0a66574042602dcaeb76263d5a2edd97` |
| `.verification/review-1504-final-source-v4-e8b17/evidence-reconciliation.json` | 6234 | `4977d9b7e341641b9aea45d33f4425245a8c6ac40fd2135b33691b4714ad9588` |
| `.verification/review-1504-final-source-v4-e8b17/owner-diff-reconciliation.json` | 158 | `1200c8c3f5c5927808b3f651b157d288b6a3b8df9c3da796b6c95e4ad6f9320c` |
