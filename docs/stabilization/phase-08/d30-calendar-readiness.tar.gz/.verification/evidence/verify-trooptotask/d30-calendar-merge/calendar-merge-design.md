# Calendar delayed hydration design review

Read-only review of the current uncommitted changes and `.verification/evidence/verify-trooptotask/d30-calendar-merge/coderabbit.txt`. No source changes, services, browser driving, tests or database actions were performed.

## Finding

The finding is valid. The new callbacks in `src/features/calendar/calendarWorkspaceHydration.svelte.ts:139` and `:159` accept every changed `loadVersion` when the current organization matches. They therefore distinguish neither an authoritative replacement from a range extension nor an overlapping refresh from a disjoint range.

`mergeLoadItems` at `:84–95` calls `mergeById(existing, incoming)`, so the delayed incoming bootstrap wins ID conflicts. `mergeCalendarAssignments` at `:98–121` removes all current rows in the bootstrap window before appending the old snapshot, so it can undo an assignment replacement or deletion even when the replacement has a different ID. Simply reversing ID precedence cannot preserve absent-row deletions or the date-plus-assignment-type slot contract.

## Actual callers and concrete timelines

1. `CalendarRangeCoordinator.svelte.ts:91–95` requests `getCalendarRangeGaps`, and `calendarRange.ts:42–73` excludes the bootstrap date window. Thus ordinary navigation does not request overlapping **dates** for availability or assignments. Its rows can still overlap: availability is an interval, so an entry spanning October through December can appear in both queries with the same ID. A December response can supply a newer version, and the delayed October bootstrap can overwrite it. Also, `calendarWorkspaceDelivery.server.ts:95–100` supplies a multi-year special-day catalog; December navigation overlaps that catalog even when it is disjoint from the initial assignment date window.
2. `BulkStatusPage.svelte:103–113` accepts an arbitrary date window and calls `mergeCalendarRangeIntoStores` for all three Calendar stores. `BulkStatusRemove.svelte:107–145` calls it before displaying deletion matches. Timeline: an October bootstrap is pending; Bulk Status queries October 15 and receives a newer assignment/new special-day value or an empty result following deletion; the range writes first; delayed bootstrap writes old rows afterward. This path is reachable without hypothetical callers because Bulk Status renders once the outer workspace resolves, rather than waiting for every inner stream.
3. `CalendarPageContext.svelte.ts:331–351` reconciles selected dates after an uncertain availability mutation. It filters every old row intersecting each date, then loads the returned rows. Empty results deliberately represent deletion. Timeline: a bootstrap stream contains availability A; reconciliation for October 15 returns no A and removes it; late bootstrap appends A again. The Calendar modal calls reconciliation after uncertain submission/removal at `AvailabilityModal.svelte:197` and `:235`.
4. A range write calls `load` on all three stores at `calendarRangeLoader.ts:59–61`. Core `createStore.svelte.ts:133–143` increments `loadVersion` and sets `loading=false`. Thus an early December response also releases all three initial loading flags. `CalendarPageContext.svelte.ts:126–133` derives readiness from those flags, and `CalendarPageView.svelte:123` hides all Calendar controls while hydrating. The premature release permits mutations while the bootstrap is still pending.

## Recommended smallest model after live-flow evidence

Gate the Calendar layout's children until the entire owned Calendar workspace hydration succeeds. Restore the generic hydrator's strict `loadVersion` guard by removing `canMergeIntoCurrentStore`. This is smaller than a separate readiness API or range/mutation tracking.

The coordinator is instantiated in a child page. Bulk Status operations, availability reconciliation and assignment editing all originate from child components. Delaying their construction until the bootstrap settles means none can commit a competing range or mutation while initial streams remain pending. The order is bootstrap application, child construction, then range/operation responses. Existing authoritative range filtering already handles newer same-ID data, absent-row deletions and different-ID assignment-slot replacements.

Parent-provided live observations support this model: initial and reentry Calendar views hide all controls until `ctx.isHydrating` clears; `viewMode` is local rather than persisted; the suspected reentry gap request was an earlier settled request. Those observations were not independently executed by this reviewer. Source also shows `CalendarPageContext.svelte.ts:126–133` derives hydration from all initial store loading flags, and `CalendarPageView.svelte:123` renders a loading skeleton instead of Calendar controls while that flag is true.

Implementation can stay in `src/routes/org/[orgId]/calendar/+layout.svelte`, using the existing `hydrateStreamedWorkspace` callback and local pending/error/restricted state. A new readiness context, range journal or store API is unnecessary. Calendar subpages that currently appear after only the outer envelope settles become correctly gated. Main Calendar already waits for the inner streams visibly, so its effective user experience stays close to the current loading behavior.

## Lifecycle requirements

1. Begin pending before children can mount, including an immediately resolved outer envelope whose inner arrays are deferred. Initial pending should be true. Ensure a replacement workspace envelope is recognized as pending immediately, rather than briefly exposing children with the new data while the parent effect has not yet run. An envelope-identity check in the render readiness condition is a small way to make this explicit.
2. Set ready only after successful allowed hydration. A restricted result should set the restricted state and clear stores, and render the existing restricted view. A rejected bootstrap should leave the child gate closed and render the existing error. Avoid unconditional `finally` releasing the gate, which can briefly construct children before the observer's asynchronous rejection callback commits the error.
3. On teardown or envelope replacement, cancel the observer and call the owned Calendar hydrator's `reset()` so already-started old descriptor promises cannot apply later. `hydrateStreamedWorkspace` cleanup currently only cancels observation; it does not cancel hydration already underway. A local cancellation boolean also prevents an old successful callback from reopening the new gate.
4. Cancellation must reset pending descriptor ownership before the next hydration starts. Restriction already calls `reset` before clearing stores, which preserves the revoke/reopen protection.
5. Organization/access changes should destroy old children while the gate closes. Keep the existing coordinator request serial, Bulk Status mounted `active`, and reconciliation organization/access checks. They protect child requests already in flight at the time the layout transitions.
6. Treat pending, ready, restricted and failed as distinct outcomes. Missing Calendar data should follow the layout's documented empty-data behavior, rather than remaining pending forever.

`calendarWorkspaceHydrator` is used in production only by this layout. A layout-owned `createCalendarWorkspaceHydrator()` instance may make cleanup ownership clearer, but the existing singleton plus explicit reset can work because only one Calendar layout owns it at a time. Neither choice requires importing the hydrator into stores or `calendarRangeLoader`, so dependency cycles and lower-level test coupling are avoided.

## Why this covers the finding

- October bootstrap pending, then December navigation: navigation cannot start until the bootstrap has applied. Its later range load extends the hydrated stores, so October is retained.
- October bootstrap pending, then Bulk Status overlapping October: Bulk Status cannot load or mutate until bootstrap success. Its authoritative range result applies later and wins. Empty availability/special-day results stay deleted, and assignment replacement filters the old date window before adding the new rows.
- Uncertain availability write: the modal cannot be opened before bootstrap readiness. A subsequent reconciliation replaces affected dates after bootstrap completion, so the bootstrap cannot resurrect deleted rows.
- Clear/restrict during bootstrap: generic `loadVersion` rejection and explicit hydrator reset still suppress old streams. Child gating cannot turn a same-org clear into an allowed merge.

## Tradeoff versus a range-commit barrier

A commit barrier can start range requests concurrently with the bootstrap and apply responses afterward. It requires a shared readiness token, cancellation handling across three callers and gating Bulk Add/import as well as range writes. That complexity is unnecessary if users cannot initiate those operations during bootstrap loading.

Layout gating delays child automatic gap requests until bootstrap completion, so it can introduce a request-start waterfall if a child actually needs a different window at mount. The current initial buffer, cookie anchor, local view mode and parent-provided native observations show no relevant early gap request for the verified current flow. Prefer the simpler layout gate. If a verified path later needs an automatic out-of-buffer range while bootstrap streams remain pending, a targeted commit barrier can be added for that demonstrated path.

Do not adopt a per-row/tombstone/range ownership system for this repair. Those models are useful only if partial-bootstrap editing or concurrent range application is an explicit product requirement.

## Focused verification

Prove at the layout lifecycle boundary that children are absent while any initial stream remains unresolved, including immediate outer data with deferred inner arrays; children become available after all successful hydration; denied and rejected results never construct the child workspace; replacing/unmounting the layout cancels old hydration so its late resolution cannot reopen children or repopulate stores; revoke-to-allow and A-to-B-to-A use fresh ownership. A child using the real coordinator/range helper can prove initial bootstrap application precedes its range application and retains both ranges. Existing authoritative range tests should continue proving empty-result deletion and assignment date-window replacement. Bulk Status should appear only after hydration readiness. Keep existing generic clear/replacement tests unchanged.

No local execution was performed. These are source-backed reachability findings and a proposed implementation model; the live-flow evidence came from the coordinator and is identified above.
