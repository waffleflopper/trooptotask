# Read and verify this archive

Archive name: `d30-final-ac14c29d.tar.gz`.
The archive SHA-256 is published beside the archive and in the worker handoff.

Extract into a fresh scratch directory, then run these commands from that directory:

```bash
tar -xzf /tmp/d30/evidence/d30-final-ac14c29d.tar.gz
python3 .verification/evidence/verify-trooptotask/d30-final-ac14/VERIFY-ARCHIVE.py
```

The script compares the complete expanded payload file set and each file's SHA-256 with `INVENTORY.sha256`. It excludes only the inventory itself. Inventory entries preserve the original repository-relative evidence paths. Hash verification proves packaging integrity; inspect RUN-NOTE.md, snapshots, screenshots, native actions, console/network captures and exact provider readbacks to assess behavior.

The final doctor and owned cleanup completed before these packaging files were added. Candidate revision/digest and the recovered Node prerequisite are recorded in RUN-NOTE.md. No tracked source was edited or committed.
