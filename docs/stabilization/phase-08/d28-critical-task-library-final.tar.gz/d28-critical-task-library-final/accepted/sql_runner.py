from pathlib import Path
import json,subprocess,os,re,hashlib,tomllib
r=Path(__file__).resolve().parent
private=Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
ledger=json.load(open(private/'environment.json'));state=json.load(open(private/'session.json'))
assert ledger['phase']=='running' and state['phase']=='running'
assert state['id']==json.load(open(r/'launch.json'))['session']
assert ledger['repository']==str(Path.cwd().resolve())
assert ledger['session']==str(private)
assert re.fullmatch(r't2t-verify-[0-9a-f]{24}',ledger['project'])
assert ledger['docker_host'].startswith('unix://')
workdir=private/'provider';config=workdir/'supabase/config.toml'
assert hashlib.sha256(config.read_bytes()).hexdigest()==ledger['config_sha256']
assert tomllib.loads(config.read_text())['project_id']==ledger['project']
fmt='{"id":{{json .Id}},"name":{{json .Name}},"project":{{json (index .Config.Labels "com.supabase.cli.project")}},"running":{{json .State.Running}}}'
result=subprocess.run(['docker','--host',ledger['docker_host'],'inspect','--format',fmt,'supabase_db_'+ledger['project']],capture_output=True,text=True,check=True)
db=json.loads(result.stdout);assert db['id'] in ledger['container_ids'] and db['project']==ledger['project'] and db['running']
files=['critical_tasks_library_configuration.sql','critical_tasks_lane_read_scope.sql','critical_tasks_task_reference_integrity.sql','critical_tasks_rls_isolation.sql']
paths=[workdir/'supabase/tests'/file for file in files]
for path in paths:
 text=path.read_text()
 assert re.search(r'\bbegin\s*;',text,re.I) and re.search(r'\brollback\s*;',text,re.I)
 assert path.read_bytes()==(Path.cwd()/'supabase/tests'/path.name).read_bytes()
env=os.environ.copy();env['DOCKER_HOST']=ledger['docker_host']
command=['/home/waffleflops/.local/bin/supabase','test','db','--local','--workdir',str(workdir),*[str(path) for path in paths]]
result=subprocess.run(command,capture_output=True,text=True,env=env)
(r/'critical-tasks-sql.log').write_text(result.stdout+result.stderr)
receipt={'session':state['id'],'candidate':state['candidate'],'revision':state['revision'],'project':ledger['project'],'dockerHost':ledger['docker_host'],'db':db,'workdir':str(workdir),'command':command,'files':{file:hashlib.sha256(path.read_bytes()).hexdigest() for file,path in zip(files,paths)},'exit':result.returncode,'rollbackBound':True,'cliVersion':subprocess.check_output(['/home/waffleflops/.local/bin/supabase','--version'],text=True).strip()}
(r/'critical-tasks-sql-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print(result.stdout+result.stderr)
result.check_returncode()
