() => { const a = document.activeElement; const cs = getComputedStyle(a); const cell = a.querySelector('[data-slot=readiness-band-cell]'); const ccs = cell && getComputedStyle(cell);
  const b = a.getBoundingClientRect(); a.scrollIntoView({block:'center'});
  return { label: a.getAttribute('aria-label'), focusVisible: a.matches(':focus-visible'), outline: `${cs.outlineStyle} ${cs.outlineWidth} ${cs.outlineColor} off ${cs.outlineOffset}`, boxShadow: cs.boxShadow, tier: cell?.dataset.tier, cellShadow: ccs?.boxShadow, cellOutline: ccs && `${ccs.outlineStyle} ${ccs.outlineWidth}` }; }
