import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile


root = Path.cwd()
scratch = root / '.verification'
stage = scratch / '1504-validation-stage'
tested = '8cdd5310cba49fb2782ccd9da0af39ea8b9c5106'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == tested
subprocess.run(['git', 'diff', '--exit-code', tested], check=True)
source_report = scratch / '1504-independent-final-attempt-v7-review.md'
assert hashlib.sha256(source_report.read_bytes()).hexdigest() == '4d76a862c71b0f84e65eb7a4e719d7e93d241902917895703cc15f5fbe80c3db'

with (scratch / '1504-decisions.tsv').open('a') as output:
    output.write('2026-10-04\tComposed scoped handoff acceptance\tNativev7 and independent expandedv7 review ACCEPTED at8cdd versus integratedee1, with retained normalExportBODY/noninteractiveoutline/N1/printconsole limits. All732payloads/210receipts/tenreadbacks/cleanup/privacy accepted. NoPDFv7; actualv6 print proof composed. Sixv8 checks6892tests/buildPASS; current-main governance remainsBLOCKED49/latest9b6 incoming semantic integration deferred. Final evidence-only packaging/integrity review precedes authorized sameDRAFT normalpush-stop, without rebase or monitoring.\n')
with (scratch / '1504-workflow.md').open('a') as output:
    output.write('\nThe final scoped source and expanded v7 artifact review accept local handoff at `8cdd5310` against integrated `ee1ca2b2`. Current-main governance remains blocked. Final documentation and artifact successors require integrity review before the authorized draft push. Prove It Works preserves actual native receipts and workbook/PDF bytes, verifies fresh expanded inventories, and distinguishes these checks from current-main semantic acceptance.\n')

binding_path = scratch / '1504-final-handoff-binding.json'
binding = json.loads(binding_path.read_text())
binding['scopedAcceptance'] = 'ACCEPTED by complete owned source and composed expanded v7 artifact review at8cdd versus integratedee1; retained limits explicit'
binding['independentV7ReportSha256'] = hashlib.sha256(source_report.read_bytes()).hexdigest()
binding['evidenceOnlySuccessorPaths'] = [
    'docs/verification/training-reports-1504/final-attempt-v7.tar.gz',
    'docs/verification/training-reports-1504/validation.tar.gz',
    'docs/verification/training-reports-1504/acceptance.md',
    'docs/verification/training-reports-1504/independent-acceptance.md',
]
binding['successorIntegrityReview'] = 'pending; executable source remains8cdd'
binding_path.write_text(json.dumps(binding, indent=2) + '\n')

facts = []
evidence_dir = root / 'docs/verification/training-reports-1504'
for archive in sorted(evidence_dir.glob('*.tar.gz')):
    assert archive.name != 'validation.tar.gz'
    with tarfile.open(archive, 'r:gz') as stream:
        inventory = json.load(stream.extractfile('inventory.json'))
        assert len(inventory) == len({entry['path'] for entry in inventory})
        assert {m.name for m in stream.getmembers()} == {'inventory.json'} | {entry['path'] for entry in inventory}
        assert all(m.isfile() for m in stream.getmembers())
        for entry in inventory:
            assert hashlib.sha256(stream.extractfile(entry['path']).read()).hexdigest() == entry['sha256']
    facts.append({'archive': str(archive.relative_to(root)), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payloads': len(inventory), 'allPayloadHashes': 'PASS'})
(scratch / '1504-final-run-archive-facts.json').write_text(json.dumps(facts, indent=2) + '\n')

planned_path = scratch / '1504-validation-planned-files.json'
planned = json.loads(planned_path.read_text())
additional = [
    '1504-independent-final-attempt-v7-review.md',
    '1504-final-handoff-binding.json',
    '1504-final-run-archive-facts.json',
    '1504-package-final-validation.py',
    'package-1504.py',
    '1504-v8-checks.py',
]
additional = [name for name in additional if (scratch / name).is_file()]
review_dir = scratch / 'review-1504-final-v7-e8b17'
additional.extend(path.relative_to(scratch).as_posix() for path in sorted(review_dir.glob('*.json')))
planned['files'] = sorted(set(planned['files']) | set(additional))
planned['state'] = 'scoped local source and composed v7 artifact ACCEPTED; current-main governance BLOCKED; final successor integrity pending'
planned_path.write_text(json.dumps(planned, indent=2) + '\n')
for name in planned['files']:
    source = scratch / name
    assert source.is_file(), name
    destination = stage / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
shutil.copyfile(planned_path, stage / planned_path.name)
assert not (stage / 'inventory.json').exists()
subprocess.run(['python3', str(scratch / 'package-1504.py'), str(stage), str(evidence_dir / 'validation.tar.gz'), str(scratch / 'packaged/1504/validation')], check=True)
print(json.dumps({'stageFiles': len([p for p in stage.rglob('*') if p.is_file()]), 'nativeArchiveCount': len(facts), 'testedSource': tested, 'applicationDiff': 'none'}))
