SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.personnel_onboardings
WHERE organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND id = '70b322e2-66af-4c1f-afde-cef1b59ebfb3'::uuid AND personnel_id = '775b67f0-847d-4b0f-a26e-bbd0db9112b2'::uuid AND template_id IS NULL AND status = 'in_progress' AND completed_at IS NULL AND cancelled_at IS NULL
FOR UPDATE;
SELECT json_build_object('event', 'ready');
