import json
import native_driver as n
ids=json.load(open(n.ROOT/'fixture.json'))['ids']
actor=n.control(['actor','ictForeign','critical-tasks'],'foreign-completion-entry');n.PAGE=actor['pageId']
n.snap('foreign-completion-matrix')
before=n.control(['rows','personnel_ict_completions','orgB'],'foreign-completions-before')
payload={'completedAt':'2026-10-05','validationMethod':'Demonstration','notes':'D28 foreign task reference must not persist'}
a={'method':'POST','path':'/org/'+ids['orgA']+'/api/personnel-ict-completions','submitted':dict(payload,personnelId=ids['personA'],ictTaskId=ids['ictTaskGeneral'])}
b={'method':'POST','path':'/org/'+ids['orgB']+'/api/personnel-ict-completions','submitted':dict(payload,personnelId=ids['personForeign'],ictTaskId=ids['ictTaskAlpha'])}
responses=n.http([a,b],'foreign-completion-guards');assert responses[0]['status']==404;assert responses[1]['status']==400 and 'Critical task not found' in responses[1]['body']
after=n.control(['rows','personnel_ict_completions','orgB'],'foreign-completions-after');assert after['rows']==before['rows']
print(n.tool('close_page',{'pageId':n.PAGE},'foreign-completion-close'))
actor=n.control(['actor','orgOwner','personnel'],'owner-entry');n.PAGE=actor['pageId']
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['Able, Synthetic'],'timeout':10000},'owner-personnel-ready'))
n.snap('owner-personnel');n.click_row('Open SPC Able, Synthetic','Details','owner-personnel-detail-open')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['2 of 2 applicable ICT tasks ready. No tasks need attention.'],'timeout':10000},'owner-personnel-detail-ready'))
n.snap('owner-personnel-detail');n.reload('owner-personnel-detail-reload')
print(n.tool('wait_for',{'pageId':n.PAGE,'text':['2 of 2 applicable ICT tasks ready. No tasks need attention.'],'timeout':10000},'owner-personnel-detail-reloaded-ready'))
n.snap('owner-personnel-detail-settled')
print(n.tool('take_screenshot',{'pageId':n.PAGE,'filePath':str(n.ROOT/'owner-personnel-readiness.png')},'owner-personnel-readiness-shot'))
print('OWNER DETAIL COMPLETE',flush=True)
