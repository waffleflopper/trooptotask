D01 source/API audit. No app worker, browser journey or database was launched.

Application/source revision 49480d1d2d616504d72ecc72c5e469f45bfb3d21. The app tree equals accepted main 8072a9efbfb3438da415ac6681eeee8666b44860.
Registry comparison huntabyte/shadcn-svelte tag shadcn-svelte@1.2.7, revision 4de0a05f149a3f9f4fb10016dea3ea62b4e9b760. Upstream registry JSON is unmodified. Upstream/local directories contain formatted source copies. comparison.json records file-set and byte differences, not a machine acceptance gate. data-table is a project composition over stock registry helpers. initial.json records the mechanical registry match before that source/API classification.
The 63 directories classify as 7 stock, 33 adapted and 23 project compositions. ConfirmDialog is another project composition. OverflowMenu.types.ts is a standalone retained type contract.
Normalization resolves $UTILS$, $UI$, $HOOKS$, $LIB$, $COMPONENTS$ to components.json aliases. Icon templates remain differences. Prettier 3.8.3 with prettier-plugin-svelte 4.0.1 and the repository configuration formats both copies. The comparison normalization was driven under Node 26.8.2/npm 12.0.2; the source graph and focused dependency reproductions used Node 24.21.0. All installed package versions match package-lock.json.

Reproduction of source comparison:
1. Read the immutable registry JSON at https://raw.githubusercontent.com/huntabyte/shadcn-svelte/4de0a05f149a3f9f4fb10016dea3ea62b4e9b760/docs/static/registry/styles/nova/FAMILY.json for each matching family. Preserve non-matching families as local project source. Expand files[].target in disposable scratch output, substitute the configured aliases and run npm exec prettier -- --ignore-path /dev/null --write on only those upstream and local scratch copies.
2. Compare the union of .svelte/.ts paths, excluding test files and test-only fixtures. Preserve each unified diff. File-set differences matter, including public parts absent locally.
3. Use the repository's scripts/module-imports.ts scanRepository with installed TypeScript and Svelte parsers. Filter type-only and test/fixture edges from the value graph. Run strongly connected component detection on the complete local production graph, then report any cycle intersecting src/lib/components/ui. Preserve resolved incoming consumers per family. source-graph.json reports 2275 parsed source modules, 0 parse failures and 0 UI value cycles. This is source evidence, not a UI pass.
4. Run node scripts/check-governance.mjs. governance.txt reports 0 module-boundary findings and a passing governance check.

Bits audit:
The published pristine 2.19.5 package SHA-512 integrity is sha512-TEwkLSYElE5SE0fIdcItiFPfyg9vrR67N1Mt6VvZCqZo24dwTA1MpGVV3WeyIg7rfVAaZ0So8a0/dcnPngCoew==.
Upstream HEAD at audit fd10616a873a8e6e3652e31dcc88c5c2f155a9e2 is the 2.19.5 release revision. Capture directories preserve only the five compared dependency files plus licenses, package metadata and exploratory tests. These exploratory tests are not additions to the app's retained test suite and do not complete upgrade acceptance.

Reproduce in three separate disposable copies of the identified repository src and Svelte/Vitest configuration, without .env files. Install the exact lockfile dependencies in scratch and independently replace only node_modules/bits-ui with installed-patched 2.18.1, pristine 2.19.5, or pristine 2.19.5 plus patch-three.mjs. Do not mutate the worktree's node_modules or run its postinstall against a different version. Copy Harness.svelte and destroy-race.svelte.test.ts to src/probe; copy presence.svelte.test.ts to src/tests. Synchronize SvelteKit in each scratch project. No provider or browser service is needed.

Actual coordinator focused commands in each prepared scratch variant:
node node_modules/vitest/vitest.mjs run src/lib/components/ui/range-calendar/range-calendar.test.ts src/probe/destroy-race.svelte.test.ts src/presence.svelte.test.ts --reporter=verbose
The final nonexistent presence filter selected no presence test. The output confirms 10 tests in two files, so presence was separately run with its correct path rather than credited to this command.
node node_modules/vitest/vitest.mjs run src/tests/presence.svelte.test.ts --reporter=verbose
PATH selected Node 24.21.0 for both commands.

Observed results:
patched 2.18.1, exit 0, 10/10 range/teardown cases and exit 0, 1/1 presence case.
pristine 2.19.5, exit 1, 3 failures/7 passes in range/teardown and exit 1, presence failure. Two range cases and AlertDialog fail, while both DismissibleLayer and both menu probes pass.
2.19.5 with only range-calendar, presence and AlertDialog transformations, exit 0, 10/10 range/teardown and exit 0, 1/1 presence.
The expected callback count is zero after owner teardown. Native focus/touch behavior and a production app upgrade were not run. Timings in test output are not product performance measurements.

Captures contain public registry/source, local UI source, non-secret version metadata and offline test output. No credentials, signed URLs, provider data or personal browser state were captured. No redactions were needed. Scratch pathnames are environment identifiers, not durable dependencies. The archive inventory/hash verifies expanded payload integrity, not application behavior.
