import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const require=createRequire('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/package.json');
const ExcelJS=require('exceljs');
const root=process.argv[2]??'/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/.verification/evidence/verify-trooptotask/d24-export-ownership-reconciliation';
const read=name=>JSON.parse(fs.readFileSync(`${root}/${name}`,'utf8'));
const keys=['organizationProfile','memberships','invitations','invitationEmailOutbox','invitationAccessRequestLinks','organizationRankCatalog','dashboardConfigs','deletionRequests','gettingStartedProgress','notifications','userOrgPreferences','userPinnedGroups','auditLogs','dataExports','betaFeedback','groups','personnel','personnelExtendedInfo','counselingRecords','leaderNotes','personnelFollowUps','personnelDocuments','signInRosters','statusTypes','availabilityEntries','assignmentTypes','dailyAssignments','specialDays','trainingTypes','personnelTrainings','trainingViews','ictTasks','personnelIctCompletions','onboardingTemplates','onboardingTemplateSteps','personnelOnboardings','onboardingStepProgress','ratingSchemeEntries'];
const fixture=read('fixture.json');
const memberships=read('memberships-a.json').rows;
const owner=memberships.find(row=>row.id===fixture.ids.orgOwnerMembership);
const admin=memberships.find(row=>row.id===fixture.ids.orgAdminMembership);
assert(owner&&admin);assert.equal(owner.role,'owner');assert.equal(admin.role,'admin');
assert.equal(owner.organization_id,fixture.ids.orgA);assert.equal(admin.organization_id,fixture.ids.orgA);
const saved=read('feedback-stored.json');
assert.equal(saved.count,1);assert.equal(Object.keys(saved.rows[0]).length,15);
assert.deepEqual(saved,read('feedback-reloaded.json'));assert.deepEqual(saved,read('feedback-final.json'));
assert.equal(read('feedback-before.json').count,0);
assert.deepEqual(read('feedback-b-before.json'),read('feedback-b-final.json'));
assert.equal(read('feedback-b-final.json').count,0);
const feedback=saved.rows[0];assert.equal(feedback.user_id,owner.user_id);assert.equal(feedback.organization_id,fixture.ids.orgA);
assert.equal(feedback.message,'D24 full saved Feedback export after the merged Platform content cutover.');
const lifecycle=read('lifecycle-final.json');assert.equal(lifecycle.count,3);assert.equal(lifecycle.rows.length,3);
assert.equal(read('lifecycle-b-final.json').count,0);assert.deepEqual(read('lifecycle-b-final.json').rows,[]);
assert.deepEqual(new Set(read('lifecycle-owner-reloaded.json').rows.map(row=>row.id)),new Set(lifecycle.rows.filter(row=>row.requested_by===owner.user_id).map(row=>row.id)));
for(const row of read('lifecycle-owner-reloaded.json').rows)assert.deepEqual(row,lifecycle.rows.find(final=>final.id===row.id));
const headerKey=value=>String(value).toLowerCase().replaceAll(' ','_');
const rowsFromSheet=sheet=>{
 const headers=sheet.getRow(1).values.slice(1).map(headerKey);
 return Array.from({length:Math.max(0,sheet.rowCount-1)},(_,i)=>Object.fromEntries(headers.map((key,j)=>[key,sheet.getRow(i+2).getCell(j+1).value??null])));
};
let feedbackSavedFields=0;let lifecycleSavedFields=0;let jsonMirrors=0;let workbookInventories=0;let blankLegacyNotes=0;const results=[];
const ownerJson=read('owner.json');
const expectedHistory=own=>lifecycle.rows.filter(row=>Date.parse(row.created_at)<=Date.parse(own.created_at)).map(row=>row.id===own.id?{...row,status:'processing',file_size_bytes:null,completed_at:null}:row);
for(const[filename,prefix,requester]of[['owner.json','owner-json',owner.user_id],['owner.xlsx','owner-xlsx',owner.user_id],['admin.json','admin',admin.user_id]]){
 const bytes=fs.readFileSync(`${root}/${filename}`);const save=read(`${prefix}-save.json`);const capture=read(`${prefix}-capture-state.json`);const network=read(`${prefix}-network-state.json`);
 const workbook=filename.endsWith('.xlsx');const mime=workbook?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'application/json';
 assert.equal(capture.captured,true);assert.equal(capture.bytes,bytes.length);assert.equal(save.bytes,bytes.length);
 assert.equal(save.sha256,createHash('sha256').update(bytes).digest('hex'));
 assert.equal(capture.filename,save.filename);assert.equal(capture.mimeType,mime);assert.equal(save.mimeType,mime);
 assert.equal(network.calls.length,1);assert.equal(network.calls[0].method,'POST');assert.equal(network.calls[0].status,200);assert.equal(network.calls[0].contentType,mime);assert(network.calls[0].contentDisposition.includes(save.filename));
 assert.equal(read(`${prefix}-capture-restore.json`).restored,true);assert.equal(read(`${prefix}-network-restore.json`).restored,true);
 const own=lifecycle.rows.find(row=>row.file_size_bytes===bytes.length);assert(own);assert.equal(own.requested_by,requester);assert.equal(own.org_id,fixture.ids.orgA);assert.equal(own.status,'completed');assert(own.completed_at);assert(Date.parse(own.completed_at)>=Date.parse(own.created_at));
 let rawFeedback;let rawHistory;
 if(workbook){
  const wb=new ExcelJS.Workbook();await wb.xlsx.readFile(`${root}/${filename}`);assert.equal(wb.worksheets.length,57);
  const inventory=rowsFromSheet(wb.getWorksheet('Export Inventory'));assert.equal(inventory.length,38);assert.deepEqual(new Set(inventory.map(row=>row.json_key)),new Set(keys));
  for(const[index,key]of keys.entries()){
   const item=inventory.find(row=>row.json_key===key);const prior=ownerJson.sectionInventory.find(row=>row.key===key);
   assert.equal(item.raw_table,prior.table);assert.equal(item.section,prior.title);assert.equal(item.area,prior.area);assert.equal(item.area_key,prior.areaKey);
   const sheet=wb.worksheets[index+19];assert(sheet.name.startsWith('Raw - '));assert.equal(item.rows,sheet.rowCount-1);workbookInventories++;
  }
  rawFeedback=rowsFromSheet(wb.getWorksheet('Raw - Beta Feedback'));rawHistory=rowsFromSheet(wb.getWorksheet('Raw - Data Export Records'));
  const personSheet=wb.getWorksheet('Personnel');const notes=personSheet.getRow(1).values.indexOf('Leader Notes');assert(notes>0);
  for(let i=2;i<=personSheet.rowCount;i++){assert.equal(personSheet.getRow(i).getCell(notes).value??'','');blankLegacyNotes++;}
 }else{
  const json=read(filename);assert.equal(json.organizationId,fixture.ids.orgA);assert(json.exportedAt);assert.deepEqual(new Set(Object.keys(json.sections)),new Set(keys));assert.equal(json.sectionInventory.length,38);assert.deepEqual(new Set(json.sectionInventory.map(row=>row.key)),new Set(keys));
  for(const key of keys){assert.deepEqual(json[key],json.sections[key]);assert.equal(json.sectionInventory.find(row=>row.key===key).rowCount,json.sections[key].length);jsonMirrors++;}
  rawFeedback=json.betaFeedback;rawHistory=json.dataExports;
 }
 if(requester===owner.user_id){assert.equal(rawFeedback.length,1);assert.deepEqual(new Set(Object.keys(rawFeedback[0])),new Set(Object.keys(feedback)));for(const[key,value]of Object.entries(feedback)){assert.deepEqual(rawFeedback[0][key],value);feedbackSavedFields++;}}
 else assert.deepEqual(rawFeedback,[]);
 const history=expectedHistory(own);assert.deepEqual(new Set(rawHistory.map(row=>row.id)),new Set(history.map(row=>row.id)));
 assert.equal(rawHistory.length,history.length);
 for(const row of rawHistory){const expected=history.find(saved=>saved.id===row.id);assert.deepEqual(row,expected);lifecycleSavedFields+=Object.keys(expected).length;}
 results.push({filename,bytes:bytes.length,requester,exportId:own.id,httpStatus:network.calls[0].status,feedbackRows:rawFeedback.length,historyRows:rawHistory.length});
}
const completion={doctor:read('final-doctor.json').status,postCleanupDoctor:read('post-cleanup-doctor.json').status,seedsCleaned:read('clean-seeds.json').cleaned,disposal:read('disposal.json').status};
assert.deepEqual(read('start-doctor.json'),read('final-doctor.json'));assert.deepEqual(read('final-doctor.json'),read('post-cleanup-doctor.json'));
assert.equal(completion.doctor,'PASS');assert.equal(completion.postCleanupDoctor,'PASS');assert.equal(completion.seedsCleaned,true);assert.equal(completion.disposal,'PASS');
console.log(JSON.stringify({head:read('start-doctor.json').revision,digest:read('start-doctor.json').candidate,session:read('start-doctor.json').session,feedbackSavedFieldsCompared:feedbackSavedFields,lifecycleSavedFieldsCompared:lifecycleSavedFields,jsonMirrorsChecked:jsonMirrors,workbookInventoriesChecked:workbookInventories,blankLegacyNoteCells:blankLegacyNotes,adminPeerFeedbackExcluded:true,foreignFeedbackUnchanged:true,foreignLifecycleRows:0,completion,results},null,2));
