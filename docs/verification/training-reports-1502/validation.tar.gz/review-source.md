# Independent source review

Reviewer /root/review_1502 used the parent Codex model and effort, with a bounded read-only prompt and no inherited conversation. This is independent source review, not model diversity or independent browser execution.

No functional mismatch was found against issue1502 and amended1433. Focused offline briefing/status/report tests passed (118 tests). Review covered direct consumers, exact bands/drop/cliff/focus thresholds, population scoring, union overlap, scope re-derivation, valid-empty/invalid-null behavior and unchanged scalar filters. Frozen populated inputs remained unchanged in a narrow probe.

P2 concentratedRows scanned each not-ready type requirement once for each row. Distinct raw duty roles created quadratic work. The reviewer measured20types/2048people all missing at360–422ms per call after warmup. This was an unusual accepted input, not measured user latency. Parent replaced the scan with a single Map count pass. Parent's reproducible same-runtime projected before/final probe measured411.16ms/40.37ms median, with full distributions saved separately.

P3 test recommendations separated fractional row readiness ties and wave biggest-hit denominators. Parent added literal Alpha170/201 versus Zulu169/200 ordering, frozen-input/valid-scope checks, and Bravo2/2 CPR versus Alpha5/8 with unrelated Bravo requirements. Current source already behaved correctly; new tests protect those contracts.

The fresh no-comments pass identified seven private narration comments. Parent removed them and renamed LAPSE_IN_BUCKET to EXPIRATION_FOR_LAPSE_BUCKET because its values are expiration dates. Public model/helper/filter contract documentation remains. No suppressions added.

Wave month uses most common lapse month, earliest ties. Biggest-hit wave row uses the horizon loss among dominant types. Review found those defensible where parent wording is implicit; retained-feature-rules records them.

At this review boundary the final source fixes, full gate/build and final live captures had not yet been independently accepted. Expanded-artifact acceptance is a separate later verdict.
