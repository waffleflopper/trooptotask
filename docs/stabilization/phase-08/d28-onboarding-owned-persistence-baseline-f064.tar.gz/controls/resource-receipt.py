import json,pathlib,subprocess,re,sys,os
os.umask(0o077)
s=pathlib.Path(__file__).parent;r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-onboarding-ordinary-baseline-f064-20261007');session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
def containers():
 ids=subprocess.check_output(['docker','ps','-aq'],text=True).split();return json.loads(subprocess.check_output(['docker','inspect',*ids],text=True)) if ids else []
def sig(c):return dict(Id=c['Id'],Name=c['Name'],Created=c['Created'],Config=c['Config'],HostConfig=c['HostConfig'],Mounts=sorted(c['Mounts'],key=lambda m:m['Destination']),Pid=c['State']['Pid'],StartedAt=c['State']['StartedAt'],Networks=c['NetworkSettings']['Networks'])
if sys.argv[1]=='preflight':
 assert not session.exists(), 'Worker1 directory must be absent before launch'
 assert not (s/'preexisting-container-inspect.json').exists(), 'Preflight receipt already exists'
 cs=containers();(s/'preexisting-container-inspect.json').write_text(json.dumps(cs,indent=2))
 (s/'pre-listeners.txt').write_text(subprocess.check_output(['ss','-ltnp'],text=True))
 for kind,cmd in [('networks',['docker','network','ls','--no-trunc','--format','{{json .}}']),('volumes',['docker','volume','ls','--format','{{json .}}'])]:
  (s/('pre-'+kind+'.jsonl')).write_text(subprocess.check_output(cmd,text=True))
 processes=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   raw=(p/'stat').read_text();z=raw.rsplit(')',1)[1].split();processes.append(dict(pid=int(p.name),name=raw.split('(',1)[1].rsplit(')',1)[0],group=int(z[2]),start=z[19]))
  except OSError:pass
 (s/'pre-process-identities.json').write_text(json.dumps(processes,indent=2))
 print(json.dumps({'containers':len(cs),'networks':len((s/'pre-networks.jsonl').read_text().splitlines()),'volumes':len((s/'pre-volumes.jsonl').read_text().splitlines()),'workerDirectoryAbsent':True,'privateCapture':str(s/'preexisting-container-inspect.json')}))
elif sys.argv[1]=='before':
 x=json.loads((session/'session.json').read_text());out={k:x[k] for k in ['id','candidate','revision','origin','supervisor','appProcess','mcpProcess','browserProcess','controlPort']}
 groups={v['group'] for v in out.values() if isinstance(v,dict) and 'group' in v};out['ownedGroupMembers']=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   z=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(z[2]) in groups:out['ownedGroupMembers'].append(dict(pid=int(p.name),group=int(z[2]),start=z[19]))
  except OSError:pass
 out['ports']=sorted(set(map(int,re.findall(r'^port\s*=\s*(\d+)',(session/'provider/supabase/config.toml').read_text(),re.M)))|{int(x['origin'].rsplit(':',1)[1]),x['controlPort'],int((session/'chrome-profile/DevToolsActivePort').read_text().splitlines()[0])})
 pre={c['Id'] for c in json.loads((s/'preexisting-container-inspect.json').read_text())};out['ownedContainers']=[dict(Id=c['Id'],Name=c['Name'],Pid=c['State']['Pid'],StartedAt=c['State']['StartedAt'],Mounts=sorted(c['Mounts'],key=lambda m:m['Destination'])) for c in containers() if c['Id'] not in pre]
 (r/'precleanup-owned-resources.json').write_text(json.dumps(out,indent=2));print('Owned identities captured',len(out['ownedGroupMembers']),len(out['ports']),len(out['ownedContainers']))
else:
 out=json.loads((r/'precleanup-owned-resources.json').read_text());fails=[]
 for p in out['ownedGroupMembers']:
  try:
   z=(pathlib.Path('/proc')/str(p['pid'])/'stat').read_text().rsplit(')',1)[1].split()
   if z[19]==p['start'] and z[0]!='Z':fails.append({'remainingProcess':p})
  except OSError:pass
 ss=subprocess.check_output(['ss','-ltnp'],text=True);(s/'post-listeners.txt').write_text(ss)
 for port in out['ports']:
  if re.search(':'+str(port)+r'\s',ss):fails.append({'remainingPort':port})
 cs=containers();now={c['Id']:c for c in cs};pre=json.loads((s/'preexisting-container-inspect.json').read_text());(s/'postexisting-container-inspect.json').write_text(json.dumps(cs,indent=2))
 for c in pre:
  if c['Id'] not in now or sig(c)!=sig(now[c['Id']]):fails.append({'changedPreexistingIdentityConfigHostConfigSortedMounts':c['Id']})
 for c in out['ownedContainers']:
  if c['Id'] in now:fails.append({'remainingOwnedContainer':c['Id']})
 for kind,cmd in [('networks',['docker','network','ls','--no-trunc','--format','{{json .}}']),('volumes',['docker','volume','ls','--format','{{json .}}'])]:
  a=[json.loads(l) for l in (s/('pre-'+kind+'.jsonl')).read_text().splitlines()];b=[json.loads(l) for l in subprocess.check_output(cmd,text=True).splitlines()]
  if sorted(a,key=str)!=sorted(b,key=str):fails.append({'changedResourceSet':kind})
 if session.exists():fails.append({'remainingDirectory':str(session)})
 def endpoints(t):return sorted({z.split()[3] for z in t.splitlines()[1:] if len(z.split())>3})
 before=endpoints((s/'pre-listeners.txt').read_text());after=endpoints(ss);external={'status':'PASS' if before==after else 'FAIL','added':sorted(set(after)-set(before)),'removed':sorted(set(before)-set(after))};(r/'whole-machine-listener-comparison.json').write_text(json.dumps(external,indent=2))
 receipt={'status':'PASS' if not fails else 'FAIL','failures':fails,'ownedProcesses':len(out['ownedGroupMembers']),'ownedPorts':out['ports'],'ownedContainers':len(out['ownedContainers']),'preexistingContainers':len(pre),'preexistingNetworks':len((s/'pre-networks.jsonl').read_text().splitlines()),'preexistingVolumes':len((s/'pre-volumes.jsonl').read_text().splitlines()),'directoryAbsent':not session.exists(),'wholeMachineTCP':external};(r/'actual-closure.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
