#!/usr/bin/env bash
# usage: v.sh NAME DESC args...   (control helper)
E=.verification/evidence/verify-trooptotask/1504-final-v1/accept
n=$1; d=$2; shift 2
exec $E/r.sh "$n" "$d" -- node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1 "$@"
