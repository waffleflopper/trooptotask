# Issue 1503 main migration integration

The unreleased Training goal migration is now `20261004000200_training_readiness_goal.sql`. Its SQL bytes are unchanged. Main's `20261004000100_scope_getting_started_progress.sql` retains its filename, SQL and ledger provenance. This removes the numeric collision introduced by main integration without rewriting either migration's behavior or historical receipts.

## Exact scope

- Renamed `supabase/migrations/20261004000100_training_readiness_goal.sql` to `supabase/migrations/20261004000200_training_readiness_goal.sql`.
- `scripts/ci/database.py`: replaced the held Training filename; the final held pair is the main progress-scope migration followed by the renamed goal migration. Other staging order and lifecycle code are unchanged.
- `supabase/migration-tests/training_readiness_goal_before.sql` and `training_readiness_goal_after.sql`: updated only the goal ledger version to `20261004000200`.
- `supabase/migration-tests/account_preferences_scope_before.sql`: excluded only `training_readiness_goal_percent` from the Organization branch of its current-row view.
- `docs/verification/training-reports-1501/acceptance.md` and `training-reports-1502/acceptance.md`: updated only current release obligations to the renamed file and explained the collision/unchanged SQL. Earlier claims, archive names/hashes and tested-version records remain intact.

No app, UI, helper, transport adapter, recipe, lever, CI test or historical archive changed. No staging, commit, push, build, publication, worker, browser, DB or Serve operation was performed by this agent.

Training migration SHA-256 before and after: `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`. Main scope migration SHA-256 remains `5a8684150e0bdd61666d497adc8cbeecd108ddd20ac4476f567cd4c7440b9977`. Both were byte-compared with their committed HEAD contents.

## Preserved-row integration

The newly merged account-preferences fixture captures full Organization JSON in an immutable `account_preferences_before_rows` table before staged migrations run. Its current-row view is evaluated after upgrade. Adding the Training goal field would otherwise add a JSON key only to the after view, breaking both saved-row comparisons despite unchanged historical data.

The correction follows the existing narrow Organization projection pattern. It excludes exactly the new goal field, preserves every old field/identity/timestamp, keeps the saved table captured before migration, and leaves all fourteen account-preferences after assertions byte-for-byte unchanged. It does not rebuild the expected snapshot from post-migration rows or broadly discard unknown future fields. Main's scope baseline and after ledger assertions still refer to `20261004000100`.

The separate unchanged Training goal contract independently checks default 90 on existing Organizations, smallint/NOT NULL/range, allowed owner/admin writes, denied member/foreign writes and neighboring values. Its baseline/ledger checks now identify version `20261004000200`. Goal exclusions in older contracts remain qualified by that separate proof; no historical row assertion or schema/auth guard was removed.

## Actual no-service checks

These checks cover source and runner behavior, not executed SQL:

The inspected HEAD is `3c0b6f2a9cb4e923ba86d0dda2a698c5e255a04c` with these local integration changes. Check tools were Python 3.14.7, Node 24.21.0 and npm 11.19.0. Final status showed the rename staged and the six other changed integration files unstaged; this agent performed no staging command and preserved the observed index state for root.

| Check                                                                   | Result                                                                                                                                                                                                        |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `python3 -B -m unittest discover -s scripts/ci -p test_database.py`     | 14 tests passed in 10.070 seconds, exit 0. Docker/Supabase are fake or mocked; only test-owned temporary files/processes/sockets are used.                                                                    |
| Python in-memory `compile` plus standard-library module-definition load | Runner syntax passed; entry point was not invoked.                                                                                                                                                            |
| Migration/fixture/contract reference and numeric-version inspection     | 168 distinct migration versions; all 27 held filenames, 21 fixture files and 23 populated contract files exist.                                                                                               |
| Byte comparisons with `git show HEAD:<path>`                            | Renamed Training SQL and main scope SQL unchanged; Training fixture changes are only version literals; account-preferences fixture change is exactly one projection; all fourteen after assertions unchanged. |
| Acceptance prefix comparison                                            | Content before each release-obligations section is unchanged.                                                                                                                                                 |
| Explicit touched-Markdown Prettier write/check                          | Passed, exit 0.                                                                                                                                                                                               |
| Local links and whitespace                                              | Existing touched acceptance local link targets exist, no links/anchors changed; `git diff --check` passed.                                                                                                    |

No new test was added merely to freeze filenames or prose. The retained runner tests exercise disposable isolation, denied remote endpoints, process cancellation, staged migration failure and scoped cleanup without Docker. The source checks inspect this concrete rename and preserved assertions.

## Root-owned database handoff

After root freezes the integrated source and final candidate, run from the checkout:

```bash
python3 -B scripts/ci/database.py
```

The public entry point performs both fresh replay and populated upgrade; it has no `--staged-upgrade` option. Do not run `npm run db:test` from this checkout against the existing local project. The runner copies that command into each disposable context and executes it there.

The exact existing lifecycle is:

1. Resolve and pin a local Docker Unix socket; create a unique `t2t-ci-db-*` project/directory outside the checkout. Copy only migrations/tests/migration-tests/templates and a rewritten configuration. Disable seeds with `enabled=false, sql_paths=[]`; reserve distinct unused ports in `58000..64999`, outside protected existing stacks. Print the actual project, ports and versions.
2. Fresh project: `supabase start --exclude studio,imgproxy,realtime,storage-api,edge-runtime,logflare,vector,postgres-meta,mailpit,supavisor` replays all 168 migrations, from `20260413001158_remote_schema.sql` through `20261004000200_training_readiness_goal.sql`. Run copied `npm run db:test`, the retained six extra migration regressions (including `training_readiness_goal_fresh.sql`) and retained provider probes. Preserve actual results and cleanup.
3. Separate populated project: remove the 27 declared held files only from its copied tree before startup, replay the 141-migration audited predecessor, then load all 21 committed before fixtures. The predecessor remains through `20261002000100_atomic_onboarding_note_append.sql`. Both scope and goal migrations must be absent from the captured baselines; saved old-row tables must exist before applying either.
4. Restore those 27 exact source files to the disposable copied tree and run `supabase migration up --local --yes --include-all`. The distinct final versions apply scope `20261004000100` before goal `20261004000200`; `--include-all` also admits older held migrations below already applied predecessor versions. Run all 23 retained populated contracts plus retained provider probes. Require both ledger versions exactly once, before-baseline witnesses, main progress-scope permission/metadata assertions, saved old-field equality and separate goal-field checks.
5. The existing runner shuts down only its own project with `supabase stop --project-id <its-project> --no-backup` and removes its copied directory. Record CLI/Postgres versions, allocations, migration ranges, both run results and actual owned cleanup. If root uses the Actions receipt mode, use only that job's exact receipt/finalizer path documented in the workflow.

Both database executions, final full application validation/build and fresh affected app proof remain root-owned and unperformed by this bounded agent. Source/unit success is not database acceptance. No remote or existing local DB was accessed, reset or migrated. No writes remain pending after this report.
