#!/usr/bin/env bash
E=.verification/evidence/verify-trooptotask/1504-final-v2/accept
F='() => Array.from(document.querySelectorAll("#training-affected-soldiers tbody tr")).map(r=>Array.from(r.cells).map(c=>c.textContent.trim()).slice(1,5).join("|"))'
J=$(python3 -c 'import json,sys;print(json.dumps({"pageId":2,"function":sys.argv[1]}))' "$F")
MAXOUT=9000 $E/t.sh "$1" "$2" evaluate_script "$J" | grep -o 'returned:.*' | head -1 | sed 's/\\n/ /g; s/\\"/"/g'
