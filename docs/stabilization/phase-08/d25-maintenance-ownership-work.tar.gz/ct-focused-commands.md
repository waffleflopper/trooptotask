CT owned provider checks on the working candidate from `988efcc03259c92157716c1cd6a77b7dba8a8b20`.

Runtime selection for all three checks used `env PATH="/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH"`.

Commands:

```sh
npm test -- src/features/critical-tasks/server/criticalTaskRetention.server.test.ts
./node_modules/.bin/eslint src/features/critical-tasks/server/criticalTaskRetention.server.ts src/features/critical-tasks/server/criticalTaskRetention.server.test.ts src/features/critical-tasks/index.server.ts
./node_modules/.bin/prettier --check src/features/critical-tasks/server/criticalTaskRetention.server.ts src/features/critical-tasks/server/criticalTaskRetention.server.test.ts src/features/critical-tasks/index.server.ts
git diff --check
```

The provider suite passes 8 tests using the real Supabase SDK and a synthetic REST boundary. It validates POST protocol, scalar count handling, supplied scope/cutoff, replay response and provider rejection. It does not establish database eligibility, locks, transaction rollback, grants or RLS.

Both new SQL suites are prepared but unrun. No database, migration application, browser or service operation occurred during these checks. The parent must freeze the complete checkout and assign an owned disposable project before SQL execution.
