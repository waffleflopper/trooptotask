import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--worker', required=True)
args = parser.parse_args()
assert args.worker == '2'
p = Path(__file__).parent
person = 'ecc94f51-af41-4f82-93c9-ce87e72e1b2f'
org = '1f22381a-0878-408f-a8c2-e596025e02f5'
group = '6c83a764-7934-4cc4-b0a0-2e13a7683c1a'
canonical = 'maplifecycle47f1e22d-synthetic'
tables = ['personnel', 'personnel_extended_info', 'leader_notes', 'counseling_records', 'personnel_documents', 'personnel_follow_ups', 'personnel_trainings', 'personnel_ict_completions', 'availability_entries', 'rating_scheme_entries']
checks = []

def capture(label):
    return json.loads((p / (label + '.stdout')).read_text())

def rows(label):
    value = capture(label)
    assert value['count'] == len(value['rows']), label
    return sorted(value['rows'], key=lambda row: row['id'])

def projection(label):
    content = capture(label)['content']
    text = '\n'.join(item['text'] for item in content if item['type'] == 'text')
    return json.loads(text.split('```json\n', 1)[1].split('\n```', 1)[0])

def text(label):
    return '\n'.join(item['text'] for item in capture(label)['content'] if item['type'] == 'text')

def match(label, expected):
    actual = rows(label)
    assert len(actual) == 1, label
    for field, value in expected.items():
        assert actual[0][field] == value, (label, field, actual[0][field], value)
    return actual[0]

before = match('loss-before-person', {'id': person, 'ets': None, 'deros': None, 'archived_at': None})
for label, ets, deros in [('loss-first-person', '2027-06-01', '2026-10-16'), ('loss-second-person', None, '2026-10-08'), ('loss-restored-person', None, None)]:
    value = match(label, {'id': person, 'organization_id': org, 'group_id': group, 'slug': canonical, 'ets': ets, 'deros': deros})
    assert {k: v for k, v in value.items() if k not in {'ets', 'deros', 'slug'}} == {k: v for k, v in before.items() if k not in {'ets', 'deros', 'slug'}}, label
checks.append('Both native date edits persisted expected dates; original identity/fields retained, first alias canonicalized, later date-only edits kept canonical slug, final dates null')
assert 'No loss risk' in text('loss-first-fresh-after-reload')
assert 'Missing ETS' in text('loss-second-detail-reloaded')
for prefix, date in [('loss-first', 'Oct 16'), ('loss-second', 'Oct 8')]:
    personnel_label = prefix + ('-personnel-entry-corrected' if prefix == 'loss-first' else '-personnel-snapshot')
    calendar_label = prefix + ('-calendar-entry' if prefix == 'loss-first' else '-calendar-snapshot')
    home_label = prefix + ('-home-fresh' if prefix == 'loss-first' else '-home-snapshot')
    assert 'PCS' in text(personnel_label) and 'MapLifecycle47f1e22d' in text(personnel_label)
    assert 'MapLifecycle47f1e22d, Synthetic PCS' in text(calendar_label)
    assert 'SPC MapLifecycle47f1e22d' in text(home_label) and date in text(home_label)
checks.append('Native detail ETS-only contrasts versus Personnel/Calendar PCS and compact Dashboard exact Person/date')

sds = match('sds-saved-row', {'organization_id': org, 'personnel_id': person, 'blood_type': 'O+', 'basd': '2014-06-01', 'date_of_rank': '2023-10-01', 'marital_status': 'Married', 'number_of_dependents': 2, 'children': [{'age': 7, 'name': 'Avery'}, {'age': None, 'name': 'Jordan'}], 'civilian_education': 'AS Respiratory Therapy', 'military_education': ['BLC', 'Medic Sustainment'], 'emergency_contact_name': 'Sam Synthetic', 'emergency_contact_relationship': 'Sibling', 'emergency_contact_phone': '555-0104', 'spouse_name': 'Pat Synthetic', 'spouse_phone': '555-0103', 'vehicle_make_model': 'Subaru Synthetic', 'vehicle_plate': 'VFY472', 'vehicle_color': 'Gray', 'personal_email': 'final47f1e22d@example.test', 'personal_phone': '555-0102', 'address_street': '123 Verification Way', 'address_city': 'Fairbanks', 'address_state': 'AK', 'address_zip': '99701', 'award_tracking_acknowledged_at': None})
assert len(sds) == 28 and sds['created_at'] == sds['updated_at']
assert sds['id'] == '7b1deddf-a4e6-4cce-b9dd-b379db43a481'
for label in ['sds-reopened', 'scope-manager-sds-reopen', 'scope-alpha-sds-reopen']:
    value = text(label)
    for expected in ['O+', 'Married', '555-0102', 'final47f1e22d@example.test', 'Fairbanks', 'AK', '99701', '2014-06-01', '2023-10-01', 'Pat Synthetic', '555-0103', 'Avery, 7', 'Jordan', 'Gray', 'Subaru Synthetic', 'VFY472', 'AS Respiratory Therapy', 'BLC', 'Medic Sustainment', 'Sam Synthetic', 'Sibling', '555-0104']:
        assert expected in value, (label, expected)
checks.append('Full28-field SDS row, all22 saved/reopened submitted fields and cancelled permission-allowed reads')

parent_before = next(r for r in rows('archive-before-personnel') if r['id'] == person)
parent_after = next(r for r in rows('archive-after-personnel') if r['id'] == person)
timestamp = parent_after['archived_at']
assert timestamp == '2026-10-01T12:03:08.075+00:00'
assert {**parent_before, 'archived_at': timestamp} == parent_after
event_ids = {'leader_notes': '58fd7035-6b7b-4b72-b93b-521f051d06c0', 'counseling_records': 'd14b158e-1a95-4124-a33e-67e3b34bd9eb', 'personnel_documents': '75bd401b-2199-42b4-a2c7-dd1a47936f55', 'personnel_follow_ups': '63bd8a2d-21cf-4e98-a199-b988f4a588e5'}
for table in tables:
    previous = rows('archive-before-' + table)
    archived = rows('archive-after-' + table)
    restored = rows('restore-after-' + table)
    assert [r['id'] for r in previous] == [r['id'] for r in archived] == [r['id'] for r in restored], table
    for original, current, final in zip(previous, archived, restored):
        event = table == 'personnel' and original['id'] == person or original['id'] == event_ids.get(table)
        if event:
            expected = {**original, 'archived_at': timestamp}
            if table == 'personnel_follow_ups':
                expected['status'] = 'archived'
            if 'updated_at' in original:
                assert original['updated_at'] <= current['updated_at'] <= final['updated_at']
                expected['updated_at'] = current['updated_at']
            assert expected == current, (table, original['id'], 'archive')
            restored_expected = dict(original)
            if 'updated_at' in original:
                restored_expected['updated_at'] = final['updated_at']
            assert restored_expected == final, (table, original['id'], 'restore')
        else:
            assert original == current == final, (table, original['id'], 'independent survivor')
checks.append('Ten complete A families preserve IDs/fields; active event artifacts use exact parent timestamp and restore; independently archived/completed history and SDS/Training/ICT/Calendar/Rating stay unchanged except legitimate event updated_at')
for label, archived_at in [('archive-active-header-projection', None), ('archive-header-public-projection', timestamp), ('restore-header-public-projection', None)]:
    value = projection(label)
    assert value['status'] == 200 and not value['errors']
    assert value['headers'] == [{'id': person, 'slug': canonical, 'rank': 'SPC', 'lastName': 'MapLifecycle47f1e22d', 'firstName': 'Synthetic', 'groupId': group, 'groupName': 'Alpha', 'mos': '68W', 'clinicRole': 'Medic', 'ets': None, 'deros': None, 'archivedAt': archived_at}], label
for expected in ['Present', '1 due', '50%', 'Not assigned', 'Missing ETS']:
    assert expected in text('archive-canonical-detail-reloaded'), expected
checks.append('Observed canonical archived-parent URL reload, literal same Header/PersonID/slug/archivedAt and five settled lanes; visible Restore')
for prefix in ['tab-', 'scope-alpha-']:
    for name in ['follow-ups', 'counselings', 'documents', 'notes', 'archived']:
        label = prefix + name + ('-public-projection' if prefix == 'tab-' else '-projection')
        # Initial owner tab filenames carry the same explicit projection suffix recorded in this run.
        if not (p / (label + '.stdout')).exists():
            label = prefix + name + '-projection'
        value = projection(label)
        assert value['status'] == 200 and not value['errors']
        assert value['headers'][0]['id'] == person and person in value['personnelIds'], label
checks.append('Owner and Alpha-scoped five inherited artifact tabs resolve same parent ID/Header')

assert not rows('import-before-row') and not rows('import-preview-no-write') and not rows('import-cleanup-absence')
imported = match('import-saved-row', {'id': 'c09ed893-c575-40f0-b931-5ad11df5d794', 'organization_id': org, 'rank': 'SPC', 'last_name': 'FinalImport47f1e22d', 'first_name': 'Synthetic', 'mos': '68W', 'clinic_role': 'Medic', 'group_id': group, 'ets': '2027-02-28', 'deros': None, 'slug': 'finalimport47f1e22d-synthetic', 'archived_at': None})
assert 'ETS must be a valid YYYY-MM-DD date' in text('import-rank-blur') and 'disableable disabled' in text('import-rank-blur')
assert '1 of 1 selected' in text('import-date-blur') and 'Ready to import.' in text('import-date-blur')
import_header = projection('import-header-public-projection')['headers'][0]
assert import_header['id'] == imported['id'] and import_header['ets'] == imported['ets'] and import_header['groupId'] == group
checks.append('Public native Import invalid/correction/no-preview-write/POST save/exact persisted reload; UI-created Person visibly archived/permanently deleted and absent')
assert text('scope-manager-detail-settled').count('StaticText "Unavailable"') == 4
for tab in ['dashboard', 'follow-ups', 'counselings', 'documents', 'notes', 'archived']:
    label = 'scope-bravo-' + tab
    assert 'heading "404"' in text(label + '-snapshot')
    value = projection(label + '-projection')
    assert value['status'] == 200 and not value['headers'] and not value['personnelIds']
for label in ['scope-empty', 'scope-foreign-person', 'scope-foreign-org']:
    assert 'heading "404"' in text(label + '-snapshot')
    value = projection(label + '-projection')
    assert not value['headers'] and not value['personnelIds'], label
assert 'heading "403"' in text('scope-operate-snapshot')
assert projection('scope-operate-projection')['headers'][0]['id'] == person
for organization in ['orgA', 'orgB']:
    for table in tables:
        assert rows('scope-before-' + organization + '-' + table) == rows('scope-after-' + organization + '-' + table), (organization, table)
checks.append('Native scope concealment: Bravo/empty/foreign404, operate-only dashboard403; actual HTML/page-data200 distinguished, operate Header public under its separate permission; exact20 before/after A/B families no effect')
result = {'status': 'PASS', 'worker': 2, 'revision': 'a200c7b8936b2abcb4105cbebd4ad7789e8e6413', 'candidateDigest': '68e180a5b122ad08dd2115f90803b808e1c521874a8e7084157c94e730b1a0d2', 'checks': checks}
(p / 'literal-observation-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
