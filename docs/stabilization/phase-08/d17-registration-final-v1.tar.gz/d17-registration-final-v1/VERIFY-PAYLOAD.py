from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1])
inventory=json.loads((root/'inventory.json').read_text())
expected={entry['filename']:entry for entry in inventory['payload']}
assert len(expected)==len(inventory['payload']), 'Duplicate inventory entries'
assert all(not p.is_symlink() for p in root.rglob('*')), 'Symlink in payload'
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='inventory.json'}
assert actual==set(expected), {'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))}
for filename,entry in expected.items():
    data=(root/filename).read_bytes()
    assert len(data)==entry['bytes'], filename+' length mismatch'
    assert hashlib.sha256(data).hexdigest()==entry['sha256'], filename+' hash mismatch'
assert sum(entry['bytes'] for entry in expected.values())==inventory['payload_bytes']
print('PASS: exact payload set and every expanded byte; '+str(len(expected))+' payload files')
