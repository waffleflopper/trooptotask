# Source acceptance for PR #1511

PASS for the rebase reconciliation, server request composition, authorization, provider contracts, reverse consumers, and consolidated report-export tests at `02631eb368fd88e8c4d4c2c19031268f4358c575`.

This is independent source acceptance. It does not establish native browser behavior, database enforcement, complete test success, or readiness to merge. The reviewer used read-only source and git inspection. The only written artifact is this report. No services, verification runners, database calls, source edits, or commits were performed by this reviewer.

## Candidate and census

The reviewed pins are:

| Input | Commit |
| --- | --- |
| Old PR base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Old PR head | `f5221ecdcf0dde3be595bccdaaa8f898b7153ca3` |
| New main | `66a238a8fe9915f5dd3994a7d5d62f71c71f7de8` |
| Final reviewed source | `02631eb368fd88e8c4d4c2c19031268f4358c575` |

Independent git tree comparison agrees with [reconciliation-final.json](reconciliation-final.json). [range-diff.txt](range-diff.txt) records the replay and conflict adaptations. The final successor commits were inspected separately.

| Census | Paths |
| --- | ---: |
| Old PR changes against its base | 150 |
| New main changes against the old base | 446 |
| Combined changed-path inventory | 578 |
| Paths changed by both inputs | 18 |
| PR-only paths | 132 |
| PR-only paths with identical old and final git objects or identical absence | 132 |
| Main-only paths | 428 |
| Main-only paths with identical main and final git objects or identical absence | 427 |
| Intended main-only adaptation | 1 |
| Unexpected paths outside the input inventory | 0 |
| Final PR changes against new main | 150 |

The final PR contains 80 `src` paths, 36 documentation paths, 20 Supabase paths, eight `.agents` paths, five script paths, and `CONTEXT.md`. Its changed-path partition is 132 PR-only paths, 17 shared paths, and one main-only path.

The sole main-only adaptation is `src/lib/server/adapters/featureRequestContexts.server.ts`. Sixteen shared paths combine both inputs. `docs/architecture/ARCHITECTURE.md` matches new main. Its Access-owned grant and request-composition description supersedes the old PR's smaller terminology repair. The deleted `api/training-reports/export/server.test.ts` matches the old PR's deliberate deletion, with retained behavior covered below.

These counts use `git diff --name-only BASE OLD`, `git diff --name-only BASE MAIN`, and `git diff --name-only MAIN CANDIDATE`. Preservation compares object IDs from `git ls-tree -r OLD`, `git ls-tree -r MAIN`, and `git ls-tree -r CANDIDATE`, treating absence as a distinct value. These are content comparisons, not timestamp or agent-report comparisons.

## Request, policy, and CRUD preservation

Main's `src/lib/server/adapters/requestContexts.server.ts:103-158` remains unchanged. It requires the admitted actor, resolves route slugs to canonical Organization IDs, loads Organization-owned membership facts, projects `OrganizationAccessGrant`, and binds ordinary request persistence. Membership reuse remains in Access's `requestMembershipCache.server.ts`. Cache keys include user and Organization, and failed loads evict only their own promise.

Main's `httpAdapter.ts:113-208` remains unchanged. Route configs declare their selected context. `handleUseCaseRequest` authorizes and validates before invoking the lazy context selector. Loads preserve policy-first selection, deferred errors, and HTTP status handling. The rebase adapts the PR's report routes and test callbacks to that interface.

The deleted universal `UseCaseContext`, broad query-port types, old permission-context builder, generic `entityHandlers`, and generic CRUD use cases remain removed. The PR does not restore these mechanisms or their old callers. Retained feature commands keep their owner-held policy and persistence contracts. Main's narrower request builders and owner-held provider operations remain the basis for report integration.

`featureRequestContexts.server.ts:61-77` now keeps two consumed contexts. `createRequestTrainingRosterContext` supports completion and matrix operations. `createRequestTrainingBriefingContext` supplies the briefing's grant, audit, scoped store, Personnel Training roster, and ordinary-client Organization settings reader. Its return type follows `Parameters<typeof fetchTrainingBriefingReport>[0]`. It does not acquire an admin client or read the provider during construction.

All three Training report API configs and the report page select the briefing context under `training.viewRecords`. The page dependency uses the actual briefing function's context type. The report's parallel source reads remain parallel. Its parent Training layout retains the PR's Reports-path skip, so initial report rendering does not also load and hydrate the matrix.

The Personnel-owned Training roster still authorizes the Training purpose before acquiring its privileged client. `trainingRoster.server.ts` and `scopedRosterQuery.server.ts` retain Organization, Group, active-Personnel, empty-scope, and complete-pagination guards. Training report access remains independent of Personnel lane access. Catalog and completion reads retain the ordinary request store.

Organization goal updates retain `organization.updateSettings`, mutation authorization, and the Organization-owned write port. Goal values require integers from 1 through 100. The provider verifies the acknowledged Organization and submitted fields before success and audit. The migration adds the default-90, non-null goal and range constraint without changing authorization policies. Source review does not replace the required isolated migration and RLS checks.

## Providers and reverse consumers

`src/features/training/index.server.ts` preserves main's `createSupabaseTrainingExportReader`, `createSupabaseTrainingTypeNamesReader`, and `listPersonnelTrainingExportRows` exports. Only the report query exports change to the PR's briefing functions. No obsolete archive or name-lookup API returns.

Training Organization archives retain their owner-held ordinary-client reader. It restricts tables and Organization, traverses complete provider pages, rejects unrelated tables before access, and fails without partial history on a later-page error. Main's Organization export request context and `organizationDataExportDelivery.server.ts` remain intact. They retain owner-held archive readers, ordinary lifecycle persistence, self-owned Notifications, ordinary Feedback and invitation-provenance restrictions, and the separately admitted sensitive Personnel reader.

The in-memory merge preserves main's explicit reader types, archive readers, export lifecycle, and roster export collaborators. It adds the PR's Organization goal read and write mappings and `findTrainingBriefingContext`. The Organization export delivery test adds the new profile field without reverting main's provider composition.

The retained reverse consumers are:

- Settings Logs. Governance admission precedes Training label resolution through the Organization-bound name reader.
- Organization JSON and Excel backups. Their raw Training tables and Organization profile goal survive owner-held archive composition.
- Single-Person export. Its retained Training record reader and type labels remain exported.
- Training matrix and completions. Their separate roster context and deferred matrix load remain present.
- Personnel readiness, Dashboard Training projections, and Onboarding references. The PR-only source files match the old accepted PR, and main-only consumers match new main.

No additional request waterfall or eager provider query was introduced by the rebase integration. This is a source finding, not a measured performance result.

## Export-test preservation

The deleted export test previously checked policy configuration, a generated workbook row, MIME type, attachment filename, `Cache-Control: private, no-store`, and `Vary: Cookie`.

The consolidated `src/routes/org/[orgId]/api/training-reports/server.test.ts:133-158` checks the real generated workbook for a filtered population, its Summary filter, MIME type, attachment filename, no-store, and Cookie variation. Commit `02631eb3` restores the previously omitted `Vary: Cookie` assertion. Its only difference from reviewed `073de1e1` is that assertion.

The same route test rejects summary, detail, and export access without Training view and checks the policy-denial audit. `trainingReportsQuery.server.test.ts:338-502` checks literal five-sheet contents, filtered scope, complete affected requirements beyond one detail page, independence from the open drill-down, and formula-like names remaining text. These tests exercise resulting behavior. The old pivot-style `Training Report` worksheet expectations belong to the replaced report and need not return.

The restored Training layout test imports current `../appShell.test-support`. No PR-only source or test file remains unintentionally omitted.

## MFA failure and proposed test-only successor

[test-final.log](test-final.log) records one failed test file, 706 passed files, one failed test, and 7,107 passed tests. The failure is `mfaGate.server.test.ts`'s `rejects forged, tampered, and expired flow markers`. It receives `recovery` for the final-character mutation where the test expects `null`. This log is failed verification evidence, not a passing full-test receipt.

Both `src/features/identity/mfaGate.server.ts` and its test are unchanged between new main and candidate `02631eb3`. Production `readAuthSessionMarker` compares decoded base64url HMAC bytes using `timingSafeEqual`, checks length, and retains user, session, version, flow, and expiry validation.

SHA-256 signatures contain 32 bytes. Their unpadded base64url spelling has 43 characters, with two unused bits in the final character. Canonical final `w` and substituted `x` differ only in those unused bits. The test's `${value.slice(0, -1)}x` can therefore preserve the complete decoded MAC instead of tampering with it. The failure is consistent with this source-level mechanism. The reviewer did not read a secret or execute a cryptographic reproduction.

PASS, conditional on the exact proposed test-only successor. Split the issued marker into payload and signature. Change the first signature character to `signature[0] === 'A' ? 'B' : 'A'` and retain the remaining characters. The first character carries six signature bits, so this mutation guarantees different decoded bytes and preserves a valid, same-length encoding. Keep both unsigned-marker cases, the exact `null` rejection assertion, and the expiry assertion unchanged. Keep production authentication source unchanged.

This repairs the negative fixture rather than weakening the security gate. The successor is not part of reviewed candidate `02631eb3`. The parent must confirm the exact successor diff and rerun the affected test and required final checks before claiming that failure resolved.

## Review limits and comment audit

The reviewer inspected the changed-path inventory, content reconciliation, shared conflict resolutions, direct and reverse server consumers, report-export test replacement, final assertion successor, and MFA failure source. This report does not claim a fresh execution audit of every unchanged old-PR UI implementation or independent native acceptance. Actual browser, print, export-artifact, provider, migration, and final check receipts remain separate parent-owned evidence.

The narrow no-comments audit found no new rebase-integration comments or lint or TypeScript suppressions to flag. Touched source files none. Comment deletions zero. MUST KILL flags none. Existing PR comments were outside the authorized cleanup scope.

Boundary Discipline shaped acceptance of the Organization reader at request composition. Prove It Works shaped the independent git-object comparisons and the separation of source acceptance from runtime proof. Fix Root Causes shaped the MFA recommendation to repair the tampering stimulus while retaining production verification. No model-diversity or independent-execution claim is made.
