# D28 Calendar Bulk Remove canonical identity repair

The route repair and affected lower-level checks pass. Fresh production UI proof remains pending the root's shared build-slot grant. Calendar's broader persistence baseline remains ISSUES until that proof completes. No three-port refactor, commit, push, migration, or PR was made.

## Source and smallest repair

Root normally merged current main into the isolated Calendar checkout at `0cf40595f46de301b503acad533d32d2515c0410`. Its complete tree `0e2b1b5d1403e8573af7040ec3bf7e6c8fac200c` equals current main `c2ca46279e45e44072b86bbe1eeadea1a6ab832d`. Old `6adc` proof and all original raw bytes remain separate.

The existing bulk input shape requires canonical `orgId`, optional `orgName`, and the materialized Calendar workspace. It must receive identity from the admitted shell. URL aliases are navigation segments, not request UUIDs. This repair changes only two projections in `src/routes/org/[orgId]/calendar/bulk/+page.svelte`, using `data.shell.org.id` and `data.shell.org.name`. The nearest Assignment Planner route already uses this shape. Calendar and Reports use the same canonical shell identity. A census of Calendar route legacy identity reads found only the repaired bulk projection. BulkStatusPage's active-instance and current-organization response guards remain byte-identical.

The new `src/routes/org/[orgId]/calendar/bulk/page.svelte.test.ts` renders the actual route with streamed shell/workspace data, a canonical UUID and a separate friendly route alias, and no legacy root identity fields. It drives the real Remove checkbox and review button. The real range loader and merge receive a literal saved Training entry from January 14 through 16 for a January 15 review. It requires the canonical request URL, a single whole-entry partial-overlap warning, the saved Person and complete dates, and the confirmation control. The DatePicker, RosterPicker, Remove component, and bulk route remain real.

The route test uses the public Calendar hydration exports and the existing delivery-owned shell fixture. It adds no private imports, test-support file, manifest allowance, or new abstraction. Its ordinary fetch fake is a boundary dependency, not a mocked production classifier. This protection is distinct from the existing BulkStatusPage test, which directly supplies a correct orgId and never exercises the route projection. A behavior-preserving internal rearrangement can keep this contract passing.

## Actual RED and GREEN

All commands ran in `/home/waffleflops/.cache/t2t-1376-calendar-persistence-owner`, with login false and Node 24.21.0 supplied through PATH.

The initial preparation run failed before importing the test because the app-navigation fake lacked `invalidateAll`. It executed zero tests and has no reproduction credit. Its original log remains `/home/waffleflops/.cache/t2t-1376-calendar-bulk-remove-route-red.log`. After supplying that imported export, the actual unchanged route failed to show its partial-overlap review. That completed one-test failure is preserved in `t2t-1376-calendar-bulk-remove-route-red-confirmed.log`.

The final unchanged-source RED moved the canonical identity assertion before the visible result assertion. The command was `npm run test -- 'src/routes/org/[orgId]/calendar/bulk/page.svelte.test.ts'`. The original route remained unchanged. Terminal exit was 1. Its exact failing URL comparison is preserved in `t2t-1376-calendar-bulk-remove-route-red-identity.log`:

```text
- "/org/d9b34493-79a0-4284-985d-b54903409955/api/calendar-range?rangeStart=2026-01-15&rangeEnd=2026-01-15",
+ "/org/undefined/api/calendar-range?rangeStart=2026-01-15&rangeEnd=2026-01-15",
 Test Files  1 failed (1)
      Tests  1 failed (1)
```

The exact pre-fix new-test patch is preserved in `t2t-1376-calendar-bulk-remove-route-red.patch`. The `git diff --no-index /dev/null TEST` command exits 1 because it found the expected new-file difference. That exit is not a failing test.

After only the two-field route fix, the identical one-test command exited 0. `t2t-1376-calendar-bulk-remove-route-green.log` retains:

```text
 Test Files  1 passed (1)
      Tests  1 passed (1)
```

Prettier then formatted only the new test import. The route remained otherwise unchanged.

## Affected checks and imperfect attempts

The selected files are the new bulk route test, `BulkStatusPage.test.ts`, `BulkStatusRemove.svelte.test.ts`, `calendarRangeLoader.test.ts`, `calendarWorkspaceHydration.svelte.test.ts`, the Calendar layout test, and the sibling Assignment route test. They protect real review behavior, range merging, retired/switching instance rejection, workspace hydration, and the canonical sibling behavior. The initial seven-file attempt hit `Unknown system error -122` on temporary transform writes before four suites imported. Three suites and eight tests passed. Terminal exit was 1. `t2t-1376-calendar-bulk-remove-focused.log` preserves the failure. No omitted suite receives passing assertion credit.

A single bounded rerun used the existing exclusively owned mode-0700 `/home/waffleflops/.cache/t2t-c-tmp` through TMPDIR and `--maxWorkers=1`, with all seven files and assertions unchanged. The command was:

```text
npm run test -- --maxWorkers=1 'src/routes/org/[orgId]/calendar/bulk/page.svelte.test.ts' src/features/calendar/components/BulkStatusPage.test.ts src/features/calendar/components/BulkStatusRemove.svelte.test.ts src/features/calendar/utils/calendarRangeLoader.test.ts src/features/calendar/calendarWorkspaceHydration.svelte.test.ts 'src/routes/org/[orgId]/calendar/layout.svelte.test.ts' 'src/routes/org/[orgId]/calendar/assignments/page.svelte.test.ts'
```

Terminal exit was 0. `t2t-1376-calendar-bulk-remove-focused-owned-tmp.log` retains:

```text
 Test Files  7 passed (7)
      Tests  19 passed (19)
```

No shared temporary content was deleted. Narrow `npm exec -- eslint ROUTE TEST` and `npm exec -- prettier --check ROUTE TEST` exited 0. Their outputs remain in `t2t-1376-calendar-bulk-remove-eslint.log` and `t2t-1376-calendar-bulk-remove-format.log`. `git diff --check` exited 0.

The official Svelte autofixer inspected the changed route and returned zero issues and seven suggestions. Every suggestion concerns its unchanged async $effect state/bootstrap machinery. The asynchronous observed-promise delivery and cancellation pattern is shared with the sibling Assignment route. The identity repair does not alter it. These optional pre-existing suggestions do not justify broadening this bug fix. Independent No Comments review remains with root's final acceptance. The new test has only its required Vitest environment directive, with no explanatory comments.

## Pending native acceptance and throughput

The prior captured native 404 establishes the failing application behavior separately from this lower-level regression. Fresh same-route UI proof must show canonical real range status 200, actual whole-entry review, Back with complete saved rows unchanged, confirmed temporary overlap removal and reload, original March/Baker and B preservation, matched failure and restored-hook retry, scoped/empty/view gates, and held-response Organization lifetime. Use worker 2 and only the repository native toolkit after root grants the build slot and freezes final executable/driving inputs. The old `history.back()` evaluation is accurately qualified in the recovery addendum; use schema-supported native navigation in the new run.

Throughput checkpoint:

- This isolated route and test are the Calendar worker's only tracked writes. Rating continues in its separate checkout.
- The longest pending work is one production build followed by native Calendar proof. Root owns the shared heavy slot.
- One owned TMPDIR rerun resolved the observed transform quota failure without changing selected behavior or deleting shared files.
- Root integrates recipes and final records before the new frozen proof, then owns full required checks, independent acceptance, commits, publication, and authorized merge.

Fix Root Causes selected canonical shell identity at the failing route boundary. Laziness Protocol kept the production repair to two existing fields. Test Behavior, Not Implementation requires the literal canonical request and actual saved overlap review. Sequence Work into Verifiable Units preserved RED before the fix and GREEN afterward, while the persistence cutover stays behind passing affected UI proof. No new architecture or nested design fan-out is needed for the project's established projection. No new live pass, provider authorization, SQL/RLS, rollback, model diversity, or complete D28 acceptance is claimed.
