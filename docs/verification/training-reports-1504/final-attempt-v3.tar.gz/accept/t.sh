#!/usr/bin/env bash
# usage: t.sh NAME DESC TOOL JSON   (native tool)
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
exec $E/r.sh "$1" "$2" -- npm run --silent verify:app -- tool "$3" "$4" --worker 1
