"""Worker-2 command/body recorder; invoke only after coordinator launch go."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
assert Path.cwd().resolve() == ROOT, "Use this exact checkout"
os.environ["TMPDIR"] = "/home/waffleflops/.cache/t2t-d15-tmp"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
RUN = os.environ["D15_EVIDENCE"]
assert re.fullmatch(r"d15-removal-worker2-(baseline|final)(-[a-z0-9]+)?", RUN)
E = ROOT / ".verification/evidence/verify-trooptotask" / RUN
assert E.resolve() == E
E.mkdir(parents=True, exist_ok=True, mode=0o700)
assert E.stat().st_uid == os.getuid()


def save(name, value):
    assert re.fullmatch(r"[A-Za-z0-9_.-]+", name)
    descriptor = os.open(E / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "w") as output:
        output.write(value if isinstance(value, str) else json.dumps(value, indent=2) + "\n")
    return E / name


def execute(command, tag, body_only=False, timeout=200):
    save(tag + "-input.json", {"command": command, "worker": "2", "cwd": str(ROOT),
         "TMPDIR": os.environ["TMPDIR"], "at": datetime.now(timezone.utc).isoformat()})
    try:
        result = subprocess.run(command, cwd=ROOT, env=os.environ.copy(), text=True,
                                capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired as error:
        stdout = error.stdout or b""
        stderr = error.stderr or b""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        save(tag + "-timeout.json", {"timeoutSeconds": timeout, "outcome": "INCONCLUSIVE",
             "partialStdoutSha256": hashlib.sha256(stdout.encode()).hexdigest(),
             "partialStderrSha256": hashlib.sha256(stderr.encode()).hexdigest()})
        if not body_only:
            save(tag + "-partial-stdout.json", stdout)
            save(tag + "-partial-stderr.log", stderr)
        raise
    if body_only:
        # get_network_request tool text includes headers; retain business files,
        # return status and an output hash, never its credential-bearing text.
        try:
            parsed = json.loads(result.stdout)
            is_error = bool(parsed.get("isError"))
        except json.JSONDecodeError:
            is_error = True
        save(tag + "-result.json", {"exitCode": result.returncode, "isError": is_error,
             "toolOutputSha256": hashlib.sha256(result.stdout.encode()).hexdigest(),
             "toolStderrSha256": hashlib.sha256(result.stderr.encode()).hexdigest(),
             "bodyFilesMustBeInspectedSeparately": True})
        assert result.returncode == 0 and not is_error, "Body capture unavailable; preserve gap"
        return None
    save(tag + "-stdout.json", result.stdout)
    save(tag + "-stderr.log", result.stderr)
    assert result.returncode == 0, "Command failed; preserved stdout/stderr"
    value = json.loads(result.stdout)
    assert not value.get("isError") and value.get("status") not in ("BLOCKED", "INCONCLUSIVE", "FAIL"), "Owned command unavailable"
    return value


def app(command, tag):
    assert command in ("info", "launch", "doctor", "tools", "cleanup")
    return execute(["npm", "run", "--silent", "verify:app", "--", command, "--worker", "2"], tag,
                   timeout=1200 if command == "launch" else 200)


def control(arguments, tag):
    assert arguments[0] in ("fixture", "actor", "rows", "seed", "clean-seeds", "network", "feedback",
                           "onboarding-request", "onboarding-request-state", "onboarding-request-restore")
    return execute(["node", ".agents/skills/verify-trooptotask/helpers/control.mjs", "--worker", "2", *arguments], tag)


def native(name, arguments, tag):
    assert name != "evaluate_script", "Native interaction only; owned controls supply any admitted evaluation"
    body_only = name == "get_network_request"
    for key in ("filePath", "requestFilePath", "responseFilePath"):
        if key in arguments:
            path = ROOT / arguments[key]
            assert path.resolve() == path and path.parent == E and not path.exists()
    return execute(["npm", "run", "--silent", "verify:app", "--", "tool", name,
                    json.dumps(arguments), "--worker", "2"], tag, body_only=body_only)


def snapshot(page, tag):
    native("take_snapshot", {"pageId": page, "filePath": str((E / (tag + ".txt")).relative_to(ROOT))}, tag)
    return (E / (tag + ".txt")).read_text()


def screenshot(page, tag):
    native("take_screenshot", {"pageId": page, "filePath": str((E / (tag + ".png")).relative_to(ROOT))}, tag + "-screen")


def fresh_uid(page, role, label, tag, prefix=False):
    text = snapshot(page, tag)
    expression = re.compile(r"uid=(\S+) " + re.escape(role) + r' "([^"\n]+)"')
    matches = [(match[0], match[1]) for match in expression.findall(text)
               if match[1] == label or prefix and match[1].startswith(label)]
    assert len(matches) == 1, "Control missing or ambiguous; inspect fresh snapshot, never guess"
    return matches[0][0]


def click(page, role, label, tag, prefix=False):
    value = fresh_uid(page, role, label, tag + "-before", prefix)
    native("click", {"pageId": page, "uid": value, "includeSnapshot": True}, tag + "-click")


def fill(page, label, value, tag):
    target = fresh_uid(page, "textbox", label, tag + "-before")
    native("fill", {"pageId": page, "uid": target, "value": value, "includeSnapshot": True}, tag + "-fill")


def reload(page, tag):
    native("navigate_page", {"pageId": page, "type": "reload"}, tag + "-reload")
    return snapshot(page, tag + "-after")


def rows(table, organization, tag, field=None, value=None):
    arguments = ["rows", table, organization]
    if field:
        arguments += [field, value]
    return control(arguments, tag)["rows"]


def original_rows(tag):
    # Eight business rowsets, plus four catalog rowsets protecting native clones.
    result = {organization: {table: rows(table, organization, tag + "-" + organization + "-" + table)
              for table in ("personnel", "personnel_trainings", "personnel_onboardings", "onboarding_step_progress",
                            "onboarding_templates", "onboarding_template_steps")}
              for organization in ("orgA", "orgB")}
    save(tag + "-rowsets.json", result)
    return result


def provider(mode, seed, tag, prepared=None, bodies=None):
    doctor = app("doctor", tag + "-doctor")
    command = ["python3", ".agents/skills/verify-trooptotask/helpers/onboarding-removal-provider.py", mode,
               "--worker", "2", "--session-id", doctor["session"], "--seed", str(seed), "--evidence", str(E)]
    if prepared:
        command += ["--prepared", str(prepared)]
    if bodies:
        command += ["--reconcile-body", str(bodies[0]), "--delete-body", str(bodies[1])]
    return execute(command, tag)


def freeze(expected_revision):
    assert re.fullmatch(r"[0-9a-f]{40}", expected_revision)
    revision = subprocess.run(["git", "rev-parse", "HEAD"], check=True, capture_output=True, text=True).stdout.strip()
    status = subprocess.run(["git", "status", "--porcelain"], check=True, capture_output=True, text=True).stdout
    assert revision == expected_revision and status == "", "Freeze only exact clean coordinator preparation"
    paths = [".agents/skills/verify-trooptotask/" + suffix for suffix in (
        "SKILL.md", "features/README.md", "features/onboarding-packets.md", "features/onboarding-templates.md",
        "helpers/control.mjs", "helpers/network-control.mjs", "helpers/feedback-control.mjs",
        "helpers/onboarding-fixtures.mjs", "helpers/onboarding-request.mjs", "helpers/onboarding-removal-provider.py",
        "helpers/onboarding-removal-provider.test.py")]
    paths += ["scripts/verification/" + name for name in ("environment.py", "core.mjs", "daemon.mjs", "fixtures.mjs")]
    paths += [str(path.relative_to(ROOT)) for path in Path(__file__).parent.glob("*.py")]
    paths += [str(Path(__file__).with_name("PLAN.md").relative_to(ROOT))]
    records = []
    for index, name in enumerate(sorted(paths)):
        data = (ROOT / name).read_bytes()
        target = "input-" + str(index).zfill(2) + "-" + Path(name).name
        with (E / target).open("xb") as output:
            output.write(data)
        records.append({"source": name, "copy": target, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
    digest = subprocess.run(["node", "--input-type=module", "-e",
              "import {candidate} from './scripts/verification/core.mjs'; console.log(await candidate());"],
              check=True, capture_output=True, text=True).stdout.strip()
    save("frozen-inputs.json", {"revision": revision, "candidate": digest, "gitStatus": status, "worker": "2",
         "launchNotYetRun": True, "inputs": records, "at": datetime.now(timezone.utc).isoformat()})
    return digest


if __name__ == "__main__":
    mode, tag, *arguments = sys.argv[1:]
    if mode == "app":
        result = app(arguments[0], tag)
    elif mode == "control":
        result = control(arguments, tag)
    elif mode == "tool":
        result = native(arguments[0], json.loads(arguments[1]), tag)
    elif mode == "freeze":
        result = {"candidate": freeze(arguments[0])}
    elif mode == "originals":
        result = original_rows(tag)
    else:
        raise SystemExit("Unsupported recorder mode")
    print(json.dumps(result))
