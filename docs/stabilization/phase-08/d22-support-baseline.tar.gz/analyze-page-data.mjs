import fs from 'node:fs';
import { unflatten } from 'devalue';

const root = '.verification/evidence/verify-trooptotask/d22-baseline';
const output = [];
for (const name of fs.readdirSync(root).filter((name) => /^(admission-.*|audit-.*)-data\.json$/.test(name))) {
  const result = JSON.parse(fs.readFileSync(`${root}/${name}`, 'utf8'));
  const line = result.content.flatMap((item) => item.text?.split('\n') ?? []).find((line) => line.startsWith('[{"path":') || line.startsWith('{"path":'));
  if (!line) throw new Error(`No script result in ${name}`);
  const value = JSON.parse(line);
  for (const response of Array.isArray(value) ? value : [value]) {
    const body = JSON.parse(response.body);
    const nodes = (body.nodes ?? []).filter(Boolean).map((node) => node.data ? unflatten(node.data) : node);
    const page = nodes.at(-1);
    output.push({artifact:name,path:response.path,status:response.status,envelope:{type:body.type,location:body.location},nodes:nodes.map((node,index) => index === 0 && node.session ? {session:'[REDACTED]'} : node),pageKeys:Object.keys(page ?? {}),logCount:page?.logs?.length,recentActivityKeys:page?.recentActivity?.map((row) => Object.keys(row))});
  }
}
fs.writeFileSync(`${root}/page-data-analysis.json`, JSON.stringify(output,null,2)+'\n');
for (const item of output) console.log(JSON.stringify({artifact:item.artifact,path:item.path,status:item.status,pageKeys:item.pageKeys,logCount:item.logCount,errors:item.nodes.filter((node) => node.type === 'error' || node.type === 'redirect'),recentActivityKeys:item.recentActivityKeys?.slice(0,1)}));
