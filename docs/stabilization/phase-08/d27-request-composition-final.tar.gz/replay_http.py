import json, pathlib, subprocess, sys
run = pathlib.Path(__file__).parent
previous = run.parent / "d27-policy-final"
name, prior, page = sys.argv[1:]
def control(folder, name):
 return json.loads(json.loads((folder / (name + ".control.json")).read_text())["stdout"])
old = json.loads((previous / "fixture.json").read_text())["ids"]
new = control(run, "fixture")["ids"]
old.update(json.loads((previous / "fixture.json").read_text())["notificationUsers"])
new.update(control(run, "fixture")["notificationUsers"])
old.update(control(previous, "rating-seed")["ids"])
new.update(control(run, "rating-seed")["ids"])
record = json.loads((previous / (prior + ".command.json")).read_text())
function = record["args"]["function"]
for key, value in old.items():
 if key in new: function = function.replace(value, new[key])
function = function.replace("D27 final", "D27 composition")
subprocess.run([sys.executable, str(run / "capture.py"), name, "evaluate_script", json.dumps({"pageId": int(page), "function": function})], check=True)
output = json.loads((run / (name + ".json")).read_text())
if isinstance(output, list): print(json.dumps([{k: v for k, v in row.items() if k != "body"} | {"body": str(row.get("body", ""))[:200]} for row in output], indent=2))
else: print(json.dumps(output, indent=2)[:1500])
