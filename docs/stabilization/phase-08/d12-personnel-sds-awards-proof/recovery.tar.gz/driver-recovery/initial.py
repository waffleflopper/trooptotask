import json,re
from flow import call,tool,snapshot,click,shot,base
from sds import FIELDS,EXPECTED,fill_values,PERSON
base.mkdir(parents=True,exist_ok=True)
seed=json.loads((base/'seed-lifecycle.json').read_text())
actor=call('owner-login','control','actor','orgOwner','personnel');page=actor['pageId']
(base/'owner-page.json').write_text(json.dumps({'pageId':page},indent=2)+'\n')
s=snapshot('owner-roster-before',page);shot('owner-roster-before',page)
name='Open SPC '+seed['name']+', Synthetic'
m=re.search(r'row '+re.escape(json.dumps(name))+r'\n([\s\S]*?)(?=\n        uid=|\n  uid=)',s)
if not m:raise RuntimeError('Actual seeded row missing: '+name)
uid=re.search(r'uid=([^ ]+) button "Details"',m[1]).group(1)
tool('owner-detail-open','click',{'pageId':page,'uid':uid})
s=snapshot('owner-detail-before',page);shot('owner-detail-before',page)
assert seed['name'] in s and 'More info' in s
click('sds-cancel-open',page,'More info');snapshot('sds-cancel-initial',page);shot('sds-cancel-initial',page)
fill_values('sds-cancel-fill',page,{'Blood type':'AB-'})
click('sds-cancel-submit',page,'Cancel')
assert call('sds-after-cancel','control','rows','personnel_extended_info','orgA','personnel_id',PERSON)['rows']==[]
click('sds-save-open',page,'More info');fill_values('sds-literal-fill',page,FIELDS)
snapshot('sds-literal-filled',page);shot('sds-literal-filled',page)
call('sds-save-fail-arm','control','network','arm-fail',str(page),'personnel/'+PERSON+'/extended-info')
call('sds-fail-feedback-arm','control','feedback','arm',str(page))
click('sds-save-fail-submit',page,'Save')
s=snapshot('sds-save-fail-after',page);shot('sds-save-fail-after',page)
net=call('sds-save-fail-network','control','network','state',str(page))
call('sds-fail-feedback','control','feedback','state',str(page));call('sds-fail-feedback-restore','control','feedback','restore',str(page))
assert 'Soldier Data Sheet' in s and 'Synthetic' in s
assert call('sds-after-failed-save','control','rows','personnel_extended_info','orgA','personnel_id',PERSON)['rows']==[]
call('sds-save-fail-restore','control','network','restore',str(page))
call('sds-retry-feedback-arm','control','feedback','arm',str(page))
click('sds-save-retry-submit',page,'Save');snapshot('sds-save-retry-after',page);shot('sds-save-retry-after',page)
call('sds-retry-feedback','control','feedback','state',str(page));call('sds-retry-feedback-restore','control','feedback','restore',str(page))
rows=call('sds-after-retry','control','rows','personnel_extended_info','orgA','personnel_id',PERSON)['rows'];assert len(rows)==1
row=rows[0]
for k,v in EXPECTED.items():assert row[k]==v,(k,row[k],v)
assert row['personnel_id']==PERSON and row['award_tracking_acknowledged_at'] is None
(base/'sds-literal-check.json').write_text(json.dumps({'result':'PASS','expected':EXPECTED,'observed':row,'boundary':'Actual native UI actions and real disposable provider28-column readback'},indent=2)+'\n')
tool('sds-reload','navigate_page',{'pageId':page,'type':'reload'});snapshot('sds-reloaded-detail',page)
click('sds-reloaded-open',page,'More info');snapshot('sds-reloaded-form',page);shot('sds-reloaded-form',page)
click('sds-reloaded-close',page,'Cancel')
