# 1503 v7 expanded evidence audit

The frozen v7 package passes this bounded nonvisual integrity and provenance audit. Its actual records support the observed owned-browser filter, SSR, pending/error/Retry, cell-detail, successful export, native sign-out, restoration and cleanup paths described below. They do not establish unrun paths or acceptance of the later integrated candidate. The independent driver's scoped PASS and the separate visual artifact judgment remain attributed judgments; this audit makes no visual judgment and does not declare #1503 complete.

This reviewer used the project t2t-engineer evidence distinctions. Only textual/JSON records and binary hashes/XML were inspected. No image was displayed, no Paper or browser tool was called, and no app, service, database, test, source, recipe, adapter, index, staging or publication action was performed. The only write is this report. Same-provider artifact reading is neither independent live execution nor model diversity.

## Frozen package and candidate

| Binding | Exact value |
| --- | --- |
| Archive | `docs/verification/training-reports-1503/final-v7.tar.gz` |
| Archive SHA-256 | `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200` |
| Archive bytes | 16,701,741 |
| Expanded root | `.verification/packaged/1503/final-v7/` |
| Payload census | 9,516 inventoried payloads, 33,318,219 bytes; 9,517 regular files including `inventory.json` |
| Inventory SHA-256 | `0a3d72393c44b77ce9cf266c31134c5be103fa0e4d48bc1a3166fc0bba4c30ff` |
| Candidate | `7159b96787d5d6d603762d3a54db05ed260b50fd849911e59ffee80c70cbc055` |
| Recorded HEAD | `3c0b6f2a9cb4e923ba86d0dda2a698c5e255a04c` |
| Recorded base | `0fa2960956572a8f5dea2de2ab5c8d4893178589` |
| Source/scripts/SQL patch SHA-256 | `eab7bf70b31c2715772984ada6fe1721e72b86957541dcdcce4e5ec2a4c992bd` |
| Session | `983bff0a-f8a3-44ad-92dc-7d9ea3f5839f` |
| Worker/origin | worker 1, `http://127.0.0.1:42057` |
| Browser | `/usr/bin/chromium`, Chromium 152.0.7977.82 Arch Linux, `provisioned: false` |
| Actor/context | `orgOwner`, page 2, `map-orgOwner-2ebcb606-e8a2-4e02-8436-aefa8dd30fac` |
| Source/build digests | `c2e4fac59503ca4c3f8aac01e7977fddc1e42dcc943d36bd502ba57c1394e4f6` / `80084e9df1984074473a701a3faf4a4dc4936bc0a9a0fada5fa8a7550129be31` |
| Seed script SHA-256 | `1fc8ad6f95d6360cb8a25469609d8126af1084e995158590566021aa232a4051` |
| Binding JSON SHA-256 | `a22c624d676587d7b4971d83ed94147c0b201e78ba6336f6e5f34fd832067b44` |

Every manifest path is unique. The expanded file set equals the manifest plus its inventory. Every payload hash passed. Every tar member's bytes and size match the corresponding expanded file, including the inventory. No symlink, hardlink, device, traversal or extra regular member was found. These checks read compressed or binary bytes without rendering images. There are 782 PNGs and one XLSX; the remaining 8,733 payloads decode as UTF-8. Excluding the credential-scan receipt itself gives the root scan's recorded 8,732 UTF-8 files. Its five-pattern zero-match PASS is a saved root result; the manifest proves that receipt's bytes, not the completeness of any credential detector. Root added no capability redactions. The driver's defensive sanitization and the native request tool's header redaction remain explicit below.

Robert explicitly authorized the owned `verify:app` browser after the unavailable v6 host round. This records a Linux owned synthetic Chromium/DevTools session. It is not Mac, private HTTPS, personal Chrome, integrated browser, or T3 native-browser execution. The actual CLI interval is 2026-10-04 00:08:18–01:54:42 AKDT. The recorded seed/report date is 4 October throughout. No observed midnight transition is claimed.

## Supported raw provenance and executable levers

The package contains 25 actual dynamic-tool envelopes and 124 separately labelled durable command texts from the supported 304-item T3 activity stream. All 149 indexed records passed path, byte-length, UTF-16-length and SHA-256 checks. `supported-raw-index.json` SHA-256 is `6252125b2ec354b7d4ccfb4b8c2e9346f92c3a4b173d86cc1980b36f0238a564`. Its 68 truncated records have 88 recovered tail parts; the recovery note additionally identifies the recovered first-user dispatch, making 69 recovered truncated tool/command/prompt records. `ORIGINAL-DISPATCH.md` SHA-256 is `7100a92cf8a772d095616927712c77c063d83d43323c6b1a9b105dcb6512ff58`.

All 25 dynamic records parse with actual `toolName`, `input`, `output`: 21 `Read`, one `ToolSearch`, and three Paper calls. The 124 durable command texts are command/output records, not reconstructed full tool envelopes. Four preserve explicit shell exit-1 errors at positions 25, 82, 256 and 258; the other 120 contain structured stdout/stderr output. Command-read stdout may omit the source file's terminal newline: position 20's chart text matches the chart content after accounting for that single LF. The archived `SOURCE.patch` is the authoritative exact byte binding, rather than a hash of the durable `cat` output string.

The 2,570 CLI invocations are a separate layer. Every receipt JSON parses with `id`, `start`, `end`, `exit`, and exact `argv`, and has corresponding stdout and stderr files. These are process records produced by `driver/d.sh`, not T3 preview envelopes. Its sequential wrapper captures output, preserves exit status and then defensively replaces auth-token/cookie/password/access-token/refresh-token/authorization values matching its regex. Consequently the durable process output is complete **sanitized** output; no claim is made to unsanitized credentials or header bytes. Request-header values also receive the native tool's own redaction.

The receipt census is 776 `evaluate_script`, 771 `take_screenshot`, 736 `navigate_page`, 70 `take_snapshot`, 53 native clicks, 44 emulations, 34 text waits, seven fills, five request lists, four native key presses, two window resizes, two request-body reads, one console list and 65 helpers/other invocations. Every measurement, snapshot and screenshot is bound by the same inventory, but the census alone does not prove its narrative interpretation.

The archived driver files were inspected for their role and side effects. `sweep.sh` reaches states through URL navigation, emulation and measurement, then creates labelled derived image crops with `magick`. It is not 684 native filter clicks or 684 independent visual judgments. The first 390px crops are preserved in `png/sweep-bad390/`; the author redid capture with a taller viewport after discovering the nested scroll container. `measure.js` reads DOM/SVG/font data and sampled paths; `analyze.py` summarizes that data. These calculations cannot substitute for a raster/legibility judgment. `d1.js` reads controls, radio selection and status/alert text, but its `bottomLine` lookup produced no recorded field in the 30 D1 measurements. `focus.js` calls `scrollIntoView` after native focus actions before reading the active element, so that diagnostic has a scroll side effect; it is not strictly a pure read. Neither script performs app-data writes. The later removal of the synthetic `theme` local-storage key is a separately recorded restoration action. Fallback evidence is canvas font metrics, not a rendered fallback-font run.

The 684 measured sweep states have this metadata census: goals 85 and 95 each 216; goals 1 and 100 each 126. Light widths 1440/1024/390 each have 144; dark widths 1440/390 each 90 and dark 1024 has 72. This is a measured-state inventory, not a visual PASS by this reviewer.

## Actual nonvisual actions and results

The relevant controls, request records, actual response bytes, readback data and corresponding durable command outputs were inspected rather than relying solely on the author's report.

| Path | Actual records and supported result | Limit |
| --- | --- | --- |
| Owned admission | Doctor, actor helper receipt 0003, authenticated initial AX snapshot and consistent page/context bindings | Actor helper used owned synthetic admission; this round has no foreign/scoped actor comparison |
| Organization goal | Native Settings/Policies navigation, seven fills/save actions with provider readbacks; successful sequence 90 → 85 → 95 → 100 → 1 → 100 → 90 | The unsuccessful 390px goal-95 attempt retained goal 85 until a later successful retry |
| View and duty role | Native view-menu click/option selection; duty-role selection with Space and Escape; URL readbacks preserve view/role | Broader sweep states are reached by native URL navigation |
| Initial SSR | Plain reload 0026/list 0027: document GET 200 and notification count GET 200, with no initial summary GET in that navigation | Scoped request-list observation, not a claim of no network activity anywhere |
| Filtered SSR | Filtered reload 2508/list 2509 restores view, role, 180-day horizon and Duty role rows with document/notification requests and no initial summary GET | Actual request list is navigation-scoped |
| Summary change | View selection followed by URL readback and summary GET 200 | Shows the selected change's request, not a general request-budget benchmark |
| Pending/release/503/Retry | Six native flows across two themes and three widths; actual held GET 200, release, synthetic GET 503 and native Retry records | Client-controlled held/503 response, not a real provider/server outage or stale-reply race |
| Cell detail | Native cell click 2512, request/body reads 2516/2517 and saved 8,156-byte `http/detail-cell-response.network-response` | One orgOwner cell/page; no foreign-actor/record-scope isolation proof |
| Keyboard | Native Tab/Space/Escape, active-element and `:focus-visible` data | Visual ring/contrast judgment belongs to Claude; `focus.js` scroll side effect is disclosed; no screen-reader execution |
| Successful export | Native Export Excel click 2521, GET 200 observation, Blob receipt 2524, byte save 2525 and workbook read 2528 | No export-failure path; actual export cache headers were not captured |
| Native sign-out | Account menu 2562, Sign Out 2564, actual landing URL, protected Reports navigation to `/auth/login`, login DOM readback 2567 | Observed owned-context logout and protected-route redirect, not global proof about every session |

The 30 D1 JSON states cover steady, pending, released, error and retried for each width/theme combination. The pending state selects 30 days and says `Updating briefing` while retaining the prior displayed report URL; release updates the URL to 30. After attempted 60 days returns 503, the selected control/URL stay at 30 with an error/Retry alert. Native Retry produces selected 60 and a 60-day URL with the alert cleared. This supports control/report consistency and recovery despite the independent uppercase text waits failing. It does not establish a live stale-reply race or a real server fault.

The detail body has cell scope `BriefingBoundaryc30522a4`, type `c1fa81e8-b1ea-4e3c-b6b1-3dfd43a31ed5`, 25 total rows, page 1, page size 25 and one page. Its literal status values are 15 `not-completed` and 10 `warning-orange`, with exactly ten `lapsesInHorizon`. Its rows contain person/type/name/group/status/date fields and no completion-record IDs. The normal report page URL carries selected report filters rather than completion IDs. The actual detail response header list records status 200, `Cache-Control: private, no-store` and `Vary: Cookie`. A truncated request-list URL was resolved by the full request read. The detail file's tool-selected `.network-response` suffix explains the failed later `.json` reads; the successful actual body remains archived.

The one current-navigation console list contains eight messages: a CSP evaluation issue, two Vercel 404s, two MIME script refusals, two analytics logs and a preload warning. No hydration-error message is present in that list. This does not independently establish a clean complete-run console or assign every issue's origin. Earlier navigations are not comprehensively covered by that one list.

## Actual workbook and math

The workbook bytes are independently decoded here with ZIP/XML readers, without running the app or a spreadsheet UI. It is 12,252 bytes, SHA-256 `eeefca8276f9d04c878b6950d2aecf136149d21beae55bce28239e88c9cce548`. The native response observation records GET 200, spreadsheet MIME and literal `Content-Disposition: attachment; filename="training-report-2026-10-04.xlsx"`. The Blob receipt names the same file, MIME and byte count; the saved workbook has the same byte hash. `root-workbook-audit.json` is a separate offline root audit of these same bytes, not another live export.

There is exactly one sheet, `Training Report`, 101 rows including the header, and 17 columns: five identity columns followed by the exact 12 selected-view type IDs in their recorded order. All 100 data-row names equal the complete seeded Personnel name set; every row has the dedicated role and Alpha group. There are no original Able/Baker or foreign-Organization rows, and the separate thirteenth final-bucket type is excluded from the selected-view columns.

The literal cell census is 613 `Current (2027-10-05)`, 139 `10d left (2026-10-14)`, 261 `Not Done` and 187 `N/A`. Thus 752 ready + 261 not done = 1,013 applicable, with 1,200 type cells including N/A. The seed's mixed report independently expects 752/1,013 today, 613/1,013 after 139 lapses, giving displayed 74 → 61. Its rounding witness is 11/13 (display 85), distinct from an exact 85% goal threshold. The 85 → 75 ten-point witness, 85 → 76 nine-point witness and 100 → 50 cliff are separate expected cases. The final-bucket witness expires 2 November and lapses 3 November, 30 days after the 4 October as-of date. These fixture/model checks explain the observed report numbers; privileged fixture insertion does not prove ordinary write authorization.

## Failures, recovery and visual-judgment attribution

All 19 nonzero CLI exits are retained, each exit 2:

- 0054: a trial screenshot target under `/tmp` was rejected.
- 0826, 0828, 0829, 0831, 0833, 0834: six failures within one 390px Policies/goal navigation attempt, with empty UID clicks/fill and waits. Later normal navigation, fill/save and provider readback establish goal 95; the failed attempt itself is not promoted to PASS.
- 2348, 2362, 2376, 2390, 2404, 2418, 2434, 2448, 2462, 2476, 2490, 2504: twelve uppercase/mixed-case text waits timed out. Subsequent actual controls, URL and AX/measurement captures support loaded/retried outcomes; the waits still failed.

The durable shell layer has four separate exit-1 failures: position 25 reads a nonexistent early receipt; 82 lacks PIL for a derived crop; 256 and 258 expect a `.json` detail-body filename that the native request tool saved with `.network-response`. The supported `Read` at position 83 also fails because the PIL crop was never created. Later receipt discovery, `magick` crops and the actual saved detail body provide the relevant recovery. These are separate from the 19 CLI failures. Superseded 390px crops and diagnostic montage crop limits stay visible. The author's grouped failure narrative is retained unchanged; `ROOT-QUALIFICATIONS.md` supplies the corrected count.

`DRIVER-REPORT.md` SHA-256 is `641cfca1493847f4846f258ad859e4e02428ecbdbbd53ad98e535c92bea0a5ac`. The driver reports scoped PASS, with two visual notes. This audit has not judged their screenshots, geometry, fonts, association, Paper relationship or focus appearance.

The separate fresh Claude artifact judgment is `.verification/1503-v7-visual-artifact-judgment.md`, SHA-256 `db82cec3ab92ac17734354cc65d55bb5bee20ebcfbce8f3bc40c042fd1e60033`. It is external to this frozen archive. It calls both visual notes nonblocking advisory polish and attributes its D3/D4 screenshot validation. It is artifact review by the same model family as the driver, not live execution/model diversity. Its viewed sample is limited; it does not claim to personally judge all 684 images. Its later fresh Paper calls timed out and it used a saved earlier v5 capture for its stated Paper comparison.

That later unavailability must not be conflated with the **successful v7 driver** Paper records: supported positions 114–116 return guide, tree and screenshot output. Position 116's actual input is file `01M3HXNN6A4S0FTNQ88XS9YJ9X`, node `UF-1`, scale 2. Its image block has `source.type: base64`; it includes the full 79,116 JPEG bytes, independently decoded and hashed without display as `2ec30abcc787e4762594718dd65826fcf2594091760f87187c73ed4108d45269`. The external tool-result path is an additional textual reference; it does not mean the bytes are absent from the archived JSON. There is no separate JPEG payload in the inventory. Neither tool success nor this byte check proves visual equivalence.

Preserve two errata identified by the visual judge without editing the original report/archive: the claim that Paper never shows the displaced-start-label state is rejected by that judge; the common-case zero-drift claim is overstated. A nonvisual census of the saved metadata confirms drift greater than 0.5px in 352/684 start labels and 342/684 end labels. That is a numerical census, not this reviewer's visual assessment. The author’s “for Robert's call” wording creates no routine-placement approval gate; the independent visual disposition is nonblocking.

## Restoration, seed absence and cleanup

All four original/restored Organization and Training capture pairs are byte-identical and JSON-equal, including the complete captured rows and both goals restored to 90:

| Capture pair | SHA-256 of both original/restored bytes |
| --- | --- |
| Organization A | `4e31488b8e5196e9a52acbb5ec935da0c0d73f0a9dbce77801c9e957073dbba2` |
| Organization B | `08b154d898fee30ceb08fce49076a9174bd294f5a65efa4129eb77f8864b1831` |
| Training A | `4b78cebfbf4c246e1a90b38084514fbfd2152235e9422d34a935407993cc10f7` |
| Training B | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |

Root's full table captures are stronger than the driver's original-ID-only Training A check. The seed setup's exact IDs equal the readback IDs, without duplicates, for 100 Personnel, 13 Training Types, one Training View and 852 Training records. All 966 exact IDs have empty after-cleanup readback arrays with the same candidate/session. `root-seed-absence.json` SHA-256 is `c60c496ccae556b03cf4dcb2f9e7c26bbfe07ea397edbdd6ec7f9e807a6ff1c2`. This is journal-bound seed absence, not a database reset or a claim that unrelated rows were deleted.

The actual restoration sequence, checks and cleanup output are preserved in `ROOT-CLOSEOUT.sh`, `root-closeout.log`, full readbacks, doctor receipts, `root-owned-cleanup.json` and `root-owned-absence.json`. Doctor after seed cleanup is PASS for the exact old candidate/session; cleanup is PASS with `phase: cleaned`. The absence receipt is structured root filesystem evidence of the exact worker directory being absent for this session, with `externalAdapterStarted: false`; its SHA-256 is `a3029931f3cb02fcdd1d337fea82ddf75f15b052144273367023a3c9cf71dde0`. This round has no external adapter to stop and makes no new H1/H2 or private-carrier claim. The driver additionally restored the originally absent theme key, mode-watcher state, viewport 1905×2053/DPR1, emulation and network/export controls; the relevant actual before/after records match. Root performed cleanup after the driver left the owned worker for comparisons.

## Source continuity and later main seam

At the start of this audit, before root integrated newer main, the actual source/scripts/SQL diff was independently rehashed to `eab7…92bd` with HEAD `3c0b6f2a…` and base `0fa296…`. The frozen archive preserves that exact 246,248-byte patch and the complete prior 101-text-path nonvisual review (`PRIOR-NONVISUAL-SOURCE-REVIEW.md`, SHA-256 `4ead50efef86dfb2a8decd6b4b69b0bda1e51f525efbd0a572ef30f33db23529`). The chart remains SHA-256 `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831`. The source verdict and root's full checks/build/actual fresh+populated SQL replay are accepted as that exact old chain, not newly executed here. The prior report records 684 files/6,766 tests, types zero errors/warnings, the historical lint/governance qualifications, production build, documentation checks, and actual isolated fresh 168 migrations/1,756 reported pgTAP plus populated 141 predecessors/27 held migrations/21 fixtures/23 contracts/372 reported pgTAP with retained provider probes and owned cleanup. Static fixture tests were not substituted for SQL execution.

The bounded main comparison `0fa296…6555c3c884801e46bd0fc78a94d698c30ec76d88` found a consequential integration seam, not merely ref drift. Main #1521 introduces `20261004000200_critical_task_archive_retention.sql`, colliding with the frozen own `20261004000200_training_readiness_goal.sql`. Its new Critical Tasks before/after ledger also compares complete Organization JSON rows: adding the goal requires the narrow new-key projection in the current view and separate new-field assertions, preserving immutable old snapshots. Therefore the merged migration ordering/populated preservation proof cannot inherit the old replay unchanged. Main #1522 changes ordinary Identity preference ports and shared first-paint shell readers, but the inspected overlap showed no direct Training report admission/API/math change or additional Training request. This is a bounded dependency review, not a full security acceptance of those main commits.

Root subsequently integrated main and assigned the migration/ledger/release-doc repair. Those postmerge bytes, their gates and affected browser proof are a **separate current-candidate acceptance lane**. This report does not judge the in-progress integration, certify current hosted mergeability or relabel v7 to the new HEAD/base. A later current-source report must bind the actual final cumulative diff, unique migration version, fixture ordering, old-row assertions, release paragraphs, full checks and fresh/populated replay. The frozen v7 archive remains immutable historical proof for its own recorded candidate.

## Retained limits and verdict

- V3 authorization, stale-race and real server-fault observations remain older-candidate supplementary proof, not fresh v7 execution or proof of each newer retained consumer.
- V3 D3 and v4/v5 chart failures remain failed historical runs. V5 D4 failed at goal 95; its D3 pass does not erase D4. V5 private HTTPS had a 403 HTTP/2 authority mismatch and the driver deviated to the original Linux localhost/cookies; no Mac/HTTPS/namespaced isolation claim is promoted. Its worker-directory absence was a root observation without a saved separate receipt.
- V6 remains UNAVAILABLE with requested native outcomes UNRUN. Its counter named `loginPosts` counted resource URLs including a static login asset rather than POST methods; no authenticated session was observed, which is narrower than proving no session could exist. Saved Oct 3 driver/root times preceded midnight; the child's midnight statement was a future rerun warning. V7's actual native sign-out is new evidence and does not rewrite v6 history.
- V7 does not freshly run scoped/foreign actors, a live stale-reply race, export failure, real server/provider faults, actual screen reader, live fallback font, Mac/HTTPS/T3-native-browser, or every unchanged consumer. Measurement/raster/model distinctions, 19 CLI failures, four separate shell failures, one missing derived-image Read, console scope and tool redactions remain material qualifications.
- No unreleased migration has been applied to remote production or an existing development database by this audit. The release/migration gate and root's later integrated-chain proof remain separate.

**Verdict:** frozen-package integrity PASS; observed nonvisual browser/workbook/restoration/cleanup provenance supports the driver's scoped result; no additional nonvisual blocker in these frozen records. The concrete later-main migration collision/ledger seam requires its separately owned integration and current proof. Visual acceptance is attributed to the independent Claude lanes, and neither this audit nor the archived scoped PASS completes #1503.
