import json, sys, datetime, os
d = os.path.join(os.path.dirname(__file__), '..', 'raw')
entry = json.loads(sys.stdin.read())
entry.setdefault('loggedAt', datetime.datetime.now(datetime.timezone.utc).isoformat())
with open(os.path.join(d, 'tool-log.jsonl'), 'a') as f:
    f.write(json.dumps(entry) + '\n')
print('logged', entry.get('tool'))
