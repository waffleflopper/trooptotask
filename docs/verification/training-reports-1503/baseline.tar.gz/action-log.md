# 1503-baseline action log (UNCHANGED baseline, HEAD f3ac08fd)
Driver: T3 preview browser tab_4 (child tab opened by this sub-agent via preview_open; root tab unavailable: preview_status available=false). Normal login form for every actor; no native Chromium/helper actor/Playwright/cookie injection/API sign-in.
All times UTC 2026-10-03.
- 22:10 doctor PASS worker1 (doctor.json); fixture -> fixture.json (public IDs/dates only)
- 22:10:54 sign in trainingConfigure (form) -> /org/<orgA>; navigate /training; matrix captured (01)
- 22:11 click Reports link -> report captured (02); read-only HTML GET (SSR proof) ; full reload -> second read (03)
- rows personnel_trainings orgA/Able/orgB (helper) -> rows-*.json
- arm observe hook training-reports; Filter by group Alpha (04), Bravo (05); reload (hook dropped; filter not restored)
- MOS 68W (06); Clear; duty role Medic (07); Clear; rank SPC (08)
- Clear; arm fail(1) training-reports; group Alpha -> 503 + "Report page failed" (09); restore hook; reselect Alpha = no-op (10); Clear filters -> Alpha recovered (11)
- Clear; arm export capture + observe training-reports/export; Export -> training-report-full.xlsx; Alpha + Required type -> Export -> training-report-alpha-required.xlsx (12); restore both hooks; reload confirms no hooks
- breadcrumb Training -> matrix (13); Reports link -> report (14)
- Account menu > Sign Out; sign in trainingView (15,16) + read-only GET probes
- Sign Out; sign in rosterScoped (17,18) + read-only GET probes + in-page export parse
- Sign Out; sign in trainingEmpty (19,20) + read-only GET probes
- Sign Out; sign in viewer; direct /training/reports -> 403 page (21) + read-only GET probes
- Sign Out; trainingForeign sign-in hit auth rate limit (POST /auth/* 10 per 15 min fixed window; "Too many requests. Please wait and try again."); waited for window reset; retried once.
- 22:26:27 rate-limit window reset; trainingForeign sign-in succeeded on single retry (22-24)
- final rows readback: orgA/orgB personnel_trainings identical to start (ROWS-UNCHANGED); final doctor PASS (doctor-final.json); no hooks on final page (__mapNetwork/__mapExport absent, createObjectURL native)
- Left signed in as trainingForeign in tab_4; root owns cleanup.
