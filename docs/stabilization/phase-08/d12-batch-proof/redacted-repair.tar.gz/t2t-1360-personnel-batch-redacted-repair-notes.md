# D12 #1360 redacted bulk slug repair worker handoff

Base: f58d9891409427afea52183da6ee1e65e622860b. Branch stabilization/1360-personnel-batch-redacted. Worktree /tmp/t2t-1360-personnel-batch-redacted. Baseline-only commit77f8ca72a4949d27b95cc1dc3315b2842ba0d35c; corrective source/tests commit7513f0c5d1b0303aebd0af2f39066c766e41b689. Five authorized paths only;387 insertions/24 deletions against base. No shared source/contracts/docs/fixtures/control edits, migration, services, database/browser or publication.

## Behavior and source boundaries

personnelBatch.server.ts retains existing policy/rank/Group/date/500-row validation and ordinary request-store reads/writes. Valid rows now retain original submitted index. Planned URLs are assigned once and all remain reserved, along with visible, acknowledged and rejected URLs. Detailed code23505/exact named index/current-Organization/submitted candidate fast path remains bounded at3 whole-bulk attempts; only its known colliding row advances. Initial arbitrary/uncertain/malformed/foreign/unsubmitted/wrong-code or wrong-index failures retain throw behavior.

personnelSlug.server.ts adds owner-private isRedactedPersonnelSlugConstraintError. It accepts only exactcode23505, quoted personnel_org_slug_key in provider message, and DETAIL undefined/null/empty. It does not weaken the existing detailed candidate extractor or single-record helper.

For a confirmed redacted failed bulk statement, recovery splits halves sequentially. Successful halves remain bulk; only confirmed named-constraint failures can split again. Once a singleton rejection attributes its own URL, it counts as isolated candidate attempt1, then atmost2 additional numeric candidates are tried. Ordinary store only: no admin reads, repeated rank/Group/policy/catalog/slug reads, random URL suffix, per-row healthy waterfall or provider seam expansion.

Once recovery begins, acknowledged inserted subsets stay in returned results. Unknown/uncertain failures return safe original-index unconfirmed errors for that entire attempted subset, do not split/retry it, and continue independent subsets. A failed response may follow persistence; no false no-effect promise is made. Confirmed singleton exhaustion reports that row was not created. Successful audit count includes acknowledged rows only; no created audit is emitted when none are acknowledged.

## Independent lower-level proof

The provider fake separately persists rows, validates each statement atomically before writes, filters reads to Alpha and returns fresh copies. Bravo canonical URL remains hidden but globally unique. Expected saved URL/ID/Group behavior is independent of production construction. Named redacted metadata uses null/undefined/empty; actual native absent DETAIL remains inferred: root a760 log establishes the named constraint, not rawDETAIL.

Baseline production unchanged at77f8ca72:8failed/44passed,3files. All8redacted cases throw original named conflict. Original detailed handling, arbitrary-error denial and nullable adapter transport pass. Full log /tmp/t2t-1360-personnel-batch-redacted-baseline.txt; baseline requirement/runtime notes -baseline-notes.md.

Final5files/111tests PASS: owned batch, slug, single-record operations (shared helper reverse consumer), date backfill and real Supabase adapter mocked transport. New checks cover hidden collision in both positions, redacted representations, original invalid-index offset, singleton exhaustion retaining unrelated acknowledgement, planned duplicate-name URL reservations, singleton lost response after persistence followed by independent success, and multi-row lost response after earlier acknowledgements without splitting/retry. All previous successful/validation/security checks remain except corrected missingDETAIL rejection expectation. Initial arbitrary batch failures remain one attempt with original error/no acknowledged creation. HTTP concealment remains the root's delivery-owned test; no provider-to-delivery import edge introduced.

Healthy500 valid rows stillone provider insert. Predeclared offline request budget:500valid rows/onehidden conflict/available next suffix <=24. Actual measured fake provider calls20, subset sizes[500,250,125,125,62,63,31,32,16,16,8,8,4,4,2,2,1,1,1,250]. Complete synthetic attempted-batch capture /tmp/t2t-1360-personnel-batch-redacted-write-calls.json and -write-count.txt. Temporary test-only capture line was removed; no assertion/budget or production behavior changed. Diagnostic run -write-budget-final.txt reports1pass/29 filtered tests, not suite skips. Full111test run covers every test. Failed attribution/sub-batch probes are additional to isolated candidate attempts. Dense worst-case500conflicting rows can reach1999calls, plus up to2 preceding detailed fast-path probes;24is not a blanket maximum. This proves bounded request behavior at an offline operation seam, not measured network/provider latency or a production benchmark.

## Checks and limits

Node24.21.0/npm11.19.0/Vitest4.1.8. Same unreachable synthetic environment used sequentially: PUBLIC_SUPABASE_URL=http://127.0.0.1:1 PUBLIC_SUPABASE_ANON_KEY=offline-anon-key. Dependencies installed offline,0vulnerabilities; package engine npm11.12.1 yields installer warning for11.19.0. No credentials.

- Final focused npm test with batch/slug/single-record/date-backfill/adapter paths:exit0,5files111tests. Log -focused-final-2.txt. Earlier successful -focused-final.txt retained.
- Initial npm run check:exit1,one test-table it.each tuple inference error; -types.txt retained. Corrected only outer readonly tuple annotation, retaining every denial case. Sequential tests then types rerun:exit0,0errors/0warnings; -types-final.txt.
- Final npm run governance:check:exit0,713remaining findings/no regression, unchanged allowlists/scan coverage; -governance-final.txt.
- Focused npm exec eslint on all5changed paths:exit0; -eslint-final.txt.
- Prettier write/check all5changed paths and git diff --check:PASS; -format-final.txt. No skips, weakened assertions, raised budget, waiver or bypass.

Root owns integration, fresh affected native final (including true hidden Bravo collision, scoped CSV denial/correction and persistence), complete candidate CI/build, proportional bot review and independent /reconcile_phase8 acceptance. This worker does not claim those gates passed. D12 #1360 remains open, lifecycle/detail/bootstrap/reverse export/switch/approval ownership and whole-issue acceptance remain. D15 entity ownership untouched.
