import contextlib,hashlib,importlib.util,io,json,pathlib,socket,subprocess
repo=pathlib.Path.cwd();run=repo/'.verification/evidence/verify-trooptotask/d17-policy-baseline-b6a1';d=json.load(open(run/'owned-before-cleanup.json'));p=pathlib.Path.home()/'.local/state/trooptotask-verification'/hashlib.sha256(str(repo).encode()).hexdigest()[:16]/'worker-1'
assert json.load(open(run/'cleanup.json'))['status']=='PASS' and not p.exists()
spec=importlib.util.spec_from_file_location('owned_database',repo/'scripts/ci/database.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with contextlib.redirect_stdout(io.StringIO()): env=m.local_docker_environment(repo)
r=subprocess.run(['docker','ps','--all','--filter','label=com.supabase.cli.project='+d['project'],'--format','{{.ID}}'],capture_output=True,text=True,cwd=repo,env=env,timeout=15)
assert r.returncode==0,'Local readonly container inventory failed; private output withheld'
processes=[]
for item in d['processes']:
 q=pathlib.Path('/proc')/str(item['pid'])/'stat';same=False
 if q.exists():
  s=q.read_text();same=s[s.rfind(')')+2:].split()[19]==str(item['start'])
 processes.append({**item,'original_process_present':same})
ports=[]
for port in [int(d['origin'].rsplit(':',1)[1]),d['controlPort']]:
 try:
  with socket.create_connection(('127.0.0.1',port),timeout=2):reachable=True
 except OSError:reachable=False
 ports.append({'port':port,'reachable':reachable})
out={'session':d['session'],'candidate':d['candidate'],'project':d['project'],'official_cleanup':'PASS; original owned cleanup checks its marked daemon before removing session metadata','session_directory_absent':not p.exists(),'fresh_readonly_docker_socket':env['DOCKER_HOST'],'owned_label_containers':r.stdout.split(),'processes':processes,'ports':ports,'evidence_files_present':len([f for f in run.rglob('*') if f.is_file()])}
(run/'owned-disposal.json').write_text(json.dumps(out,indent=2));print(json.dumps(out));assert not r.stdout.strip() and not any(x['original_process_present'] for x in processes) and not any(x['reachable'] for x in ports)
other=repo/'.verification/evidence/verify-trooptotask/d17-units-baseline-b6a1'
for name in ['doctor-final.json','owned-before-cleanup.json','clean-seeds.json','cleanup.json','owned-disposal.json']:(other/name).write_bytes((run/name).read_bytes())
