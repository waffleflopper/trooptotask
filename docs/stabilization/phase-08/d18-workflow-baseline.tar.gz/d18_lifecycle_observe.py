import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/d18-workflow-baseline')
def rows(prefix,table):return {r['id']:r for r in json.loads((p/(prefix+table+'.json')).read_text())['rows']}
b=rows('72-bulk-before-','personnel');a=rows('102-configure-after-','personnel')
targets={'c0e07071-5315-44de-8a29-c99478428034','66d70eee-90ce-4573-8802-acf284387b54'}
event=a['c0e07071-5315-44de-8a29-c99478428034']['archived_at'];assert event
assert set(a)==set(b)
for i,r in b.items():assert a[i]==({**r,'archived_at':event} if i in targets else r),(i,a[i],r)
active={'leader_notes':{'ff2a32b3-97dd-4955-88d4-7ebd6c98e558'},'counseling_records':{'1b3d57d8-dc67-4a22-9f66-f8b28a0d7575'},'personnel_documents':{'f27d4bbf-99b9-459c-89a0-b516c5f01e5e'},'personnel_follow_ups':{'c3061240-3250-49f1-bb85-aed85b2cd7c6'},'personnel_trainings':set(),'personnel_ict_completions':set()}
for t,ids in active.items():
 b=rows('72-bulk-before-',t);a=rows('102-configure-after-',t);assert set(a)==set(b)
 for i,r in b.items():
  if i not in ids:assert a[i]==r,(t,i)
  else:
   allowed={'archived_at'}|({'updated_at'} if t!='leader_notes' else set())|({'status'} if t=='personnel_follow_ups' else set())
   assert a[i]['archived_at']==event
   if t=='personnel_follow_ups':assert a[i]['status']=='archived' and a[i]['completed_at'] is None
   assert all(a[i][k]==val for k,val in r.items() if k not in allowed),(t,i)
result={'observation':'PASS','firstArchiveEvent':event,'archivedParentIds':sorted(targets),'activeArtifactsArchived':{t:sorted(ids) for t,ids in active.items()},'preserved':'every other captured full row, including older archives, completed follow-up, original Able control, Training and Critical Tasks'}
(p/'102a-configure-lifecycle-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
