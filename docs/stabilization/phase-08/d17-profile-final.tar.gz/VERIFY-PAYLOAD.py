from pathlib import Path, PurePosixPath
import hashlib, json, sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
inventory = json.loads((root / 'INVENTORY.json').read_text())
entries = inventory['payloads']
expected = {entry['path'] for entry in entries} | {'INVENTORY.json'}
actual = {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
assert len(entries) == len(expected) - 1
assert actual == expected, {'missing': sorted(expected - actual), 'extra': sorted(actual - expected)}
assert not any(path.is_symlink() for path in root.rglob('*'))
for entry in entries:
    path = PurePosixPath(entry['path'])
    assert not path.is_absolute() and '..' not in path.parts and '.' not in path.parts
    assert str(path) == entry['path'] and '\\' not in entry['path']
    data = (root / entry['path']).read_bytes()
    assert len(data) == entry['bytes'], entry['path']
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
assert len(entries) == inventory['payload_count']
assert sum(entry['bytes'] for entry in entries) == inventory['payload_bytes']
print(json.dumps({'status': 'PASS', 'payload_count': len(entries), 'payload_bytes': inventory['payload_bytes'], 'inventory_excludes_only_itself': True}))
