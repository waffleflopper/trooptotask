from pathlib import Path
import hashlib
import json
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
inventory = json.loads((root / 'INVENTORY.json').read_text())
entries = inventory['files']
expected = {entry['filename'] for entry in entries} | {'INVENTORY.json'}
actual = {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
assert actual == expected, {'missing': sorted(expected - actual), 'extra': sorted(actual - expected)}
assert not any(path.is_symlink() for path in root.rglob('*')), 'Unexpected symlink'
for entry in entries:
    data = (root / entry['filename']).read_bytes()
    assert len(data) == entry['bytes'], f"Byte length mismatch: {entry['filename']}"
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], f"SHA-256 mismatch: {entry['filename']}"
assert len(entries) == inventory['payload_file_count']
assert sum(entry['bytes'] for entry in entries) == inventory['payload_bytes']
print(json.dumps({'status': 'PASS', 'payload_file_count': len(entries), 'payload_bytes': inventory['payload_bytes'], 'inventory_excludes_only_itself': True}))
