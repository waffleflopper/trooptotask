# D30 shared-store baseline

Candidate: 5f221a1cf0abe101af7e12a3eea4b3cdd688f3e6 with the three documentation corrections visible in the coordinator's worktree. Fingerprint 3428ad72f28398ea4799e3db87eab5947c4162bf015a49230123a91ed104a193. Owned worker 1; Chromium 152.0.7977.82; supported launch Node 24.21.0.

The first launch selected Node 26.8.2 and failed at adapter-vercel's unsupported-runtime check. Its launch/cleanup receipts remain; it supplied no live proof. The supported launch and both doctors pass, then owned cleanup passes.

Native normal-sign-in ictViewer starts in Critical Tasks, showing Able (50%), Baker (0%) and Unassigned (0%). Direct navigation to denied Personnel establishes a history entry. The visible ICTLs link, native Back to denied Personnel, and visible ICTLs link again settle with all three admitted rows. This live path PASSES on unchanged application source; its fresh workspace loads do not reproduce the same-key cache failure. Denied Personnel renders Access Restricted.

The separate state-level regression patch deliberately reuses Calendar's admitted snapshot after Training, Critical Tasks or Personnel clears its shared stores. All three cases FAIL with expected ['p1'] and actual []. The captured test patch and RED receipt retain that failing oracle. The test was removed before native doctor/drive; it does not change application behavior or get credited as native execution. No UI mutations, seed changes, grant changes, network controls, remote database access or full manual sweep occurs.
