import current as x
import json
d=x.d;seed=json.loads((x.c/'seed.json').read_text());person=seed['ids']['person']
for value in [True,False]:(d.E/('award-'+str(value).lower()+'.json')).write_text(json.dumps({'acknowledged':value}))
body=str(d.E/'award-true.json')
r=d.call('award-scoped-true',['artifact-http','personnelScoped','orgA',person,'POST','award-tracking',body],True);assert r['status']==200
x.full('award-set-full')
d.act('sds-phone-clear-open','button','More info');r=d.snap('sds-phone-clear-form');dialogs=[n for n in d.walk(r['structuredContent']['snapshot']) if n.get('role')=='dialog' and n.get('name')=='Soldier Data Sheet'];assert len(dialogs)==1;ns=list(d.walk(dialogs[0]));pos=next(i for i,n in enumerate(ns) if n.get('role')=='StaticText' and n.get('name')=='Personal phone');n=next(n for n in ns[pos+1:] if n.get('role')=='textbox')
d.tool('sds-phone-focus','click',{'pageId':2,'uid':n['id']});d.tool('sds-phone-selectall','press_key',{'pageId':2,'key':'Control+A'});d.tool('sds-phone-backspace','press_key',{'pageId':2,'key':'Backspace'});d.tool('sds-phone-blur','press_key',{'pageId':2,'key':'Tab'});d.snap('sds-phone-cleared-draft');d.act('sds-phone-save','button','Save');d.wire('sds-phone-save-wire',2,'personnel');x.full('sds-phone-cleared-full')
d.tool('sds-phone-reload','navigate_page',{'pageId':2,'type':'reload'});d.act('sds-phone-reopen','button','More info');d.snap('sds-phone-cleared-reopened');d.shot('sds-phone-cleared');d.act('sds-phone-close','button','Cancel')
r=d.call('award-scoped-true-replay',['artifact-http','personnelScoped','orgA',person,'POST','award-tracking',body],True);assert r['status']==200;x.full('award-replayed-full')
r=d.call('award-scoped-false',['artifact-http','personnelScoped','orgA',person,'POST','award-tracking',str(d.E/'award-false.json')],True);assert r['status']==200;x.full('award-cleared-full')
for actor,expected in [('viewer',403),('personnelForeign',404)]:
 r=d.call('award-'+actor+'-denial',['artifact-http',actor,'orgA',person,'POST','award-tracking',body],True);print(actor,r['status']);assert r['status']==expected;x.full('award-'+actor+'-unchanged-full')
