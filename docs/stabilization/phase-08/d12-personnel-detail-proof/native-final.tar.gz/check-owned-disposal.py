import argparse
import hashlib
import json
import shutil
import socket
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--worker', required=True)
assert parser.parse_args().worker == '2'
p = Path(__file__).parent
allocation = json.loads((p / 'public-provider-allocation.json').read_text())
targets = json.loads((p / 'owned-disposal-targets.json').read_text())
identities = json.loads((p / 'owned-process-identities.json').read_text())
commands = []
def command(argv):
    result = subprocess.run(argv, text=True, capture_output=True)
    commands.append({'argv': argv, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    return result
project = allocation['project']
result = command(['docker', 'ps', '-a', '--filter', 'name=' + project, '--format', '{{.ID}} {{.Names}}'])
assert result.returncode == 0 and not result.stdout.strip(), result.stdout
for item in targets['containers']:
    result = command(['docker', 'container', 'inspect', '--format', '{{.Id}}', item['id']])
    assert result.returncode != 0 and 'no such' in result.stderr.lower(), item['id']
volumes = sorted({volume['name'] for item in targets['containers'] for volume in item['volumes'] if volume['type'] == 'volume'})
for name in volumes:
    result = command(['docker', 'volume', 'inspect', '--format', '{{.Name}}', name])
    assert result.returncode != 0 and 'no such' in result.stderr.lower(), name
result = command(['docker', 'volume', 'ls', '--filter', 'name=' + project, '--format', '{{.Name}}'])
assert result.returncode == 0 and not result.stdout.strip(), result.stdout
ports = {**allocation['ports'], 'app': 35249, 'control': 33763}
port_checks = []
for name, number in ports.items():
    with socket.socket() as connection:
        connection.settimeout(0.5)
        code = connection.connect_ex(('127.0.0.1', int(number)))
    assert code != 0, (name, number)
    port_checks.append({'name': name, 'port': number, 'connectExit': code, 'listenerAbsent': True})
process_checks = []
for name, identity in identities['processes'].items():
    proc = Path('/proc') / str(identity['pid'])
    if not proc.exists():
        process_checks.append({'name': name, 'pid': identity['pid'], 'status': 'absent', 'ownedProcessAlive': False})
        continue
    stat = (proc / 'stat').read_text().rsplit(') ', 1)[1].split()
    start = stat[19]
    state = stat[0]
    digest = hashlib.sha256((proc / 'cmdline').read_bytes()).hexdigest()
    same = start == identity['start'] and digest == identity['commandSHA256']
    assert not same or state == 'Z', (name, identity['pid'])
    process_checks.append({'name': name, 'pid': identity['pid'], 'status': 'zombie' if state == 'Z' else 'reused identity', 'observedStart': start, 'observedCommandSHA256': digest, 'ownedProcessAlive': False})
private = Path(identities['privateSessionPath'])
assert not private.exists(), str(private)
scratch = Path('/home/waffleflops/.cache/d12f-c09rr52s')
assert scratch.is_dir()
marker = scratch / '.owned-personnel-detail-final'
assert marker.read_text().strip() == 'a200c7b8936b2abcb4105cbebd4ad7789e8e6413'
shutil.rmtree(scratch)
assert not scratch.exists()
result = {'status': 'PASS', 'worker': 2, 'project': project, 'recordedContainersAbsent': len(targets['containers']), 'recordedVolumesAbsent': volumes, 'noProjectContainersOrVolumes': True, 'ports': port_checks, 'processes': process_checks, 'privateSessionAbsent': str(private), 'exclusiveTMPDIR': {'path': str(scratch), 'ownershipMarkerVerified': True, 'removed': True, 'absent': True}, 'commands': commands}
(p / 'independent-owned-disposal.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
