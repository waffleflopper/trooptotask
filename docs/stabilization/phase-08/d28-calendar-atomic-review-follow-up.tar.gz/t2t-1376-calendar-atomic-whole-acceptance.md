# D28 #1376 Calendar atomic bulk removal: independent whole acceptance

Verdict. **Standards HOLD** on one medium documentation-contract finding. **Spec GO** for the local source and expanded proof. Seven further findings are low or informational and do not block. The decision-trail audit raises seven flags. Two of them need Robert's attention.

This GO covers local source and expanded evidence only. It is not CI, hosted review, migration, release or #1376 completion. This is an artifact review. I executed no app, browser, build, test, service or database. I made no remote writes, source edits, git mutations or external messages.

## Reviewed identity

| Item | Value |
| --- | --- |
| Frozen review base | `4d5f8bfb5723752788f96c1666e2c12d50b47682` (merge of #1552; tree `a35ee1ba` equals accepted `fd7e9b98`) |
| Frozen packaged head | `20dd750285d15e14bef7bf4376e57a602df14048` |
| Application/native source head | `8d225c0a318758e0d89fad10f42737ac94805277` |
| Physical diff | 24 files. 22 are text and 2 are archives. 836 insertions, 28 deletions |
| Source to packaged delta | 5 files. EVIDENCE, TODO, Personnel record, the new acceptance record and the final archive. All 18 source/SQL/control/recipe files and the baseline archive are byte-identical at both heads |
| Head drift observed during review | The worktree and PR #1553 now point at `c1ae34e2af8cd7103a9d25b8f778d8ed8f5ef8f7`. It changes only `d28-calendar-atomic-bulk-removal.md` (3 insertions, 2 deletions). I reviewed that delta separately below |
| Reviewer | Claude Opus 5.5, model ID `claude-opus-5-5[1m]`. The effort setting is not observable from inside the session |

### File bindings at `20dd7502`

All hashes are SHA-256 of `git show 20dd7502:<path>` bytes. "Same" means identical at `8d225c0a`.

| Bytes | SHA-256 | At 8d225c0a | Path |
| ---: | --- | --- | --- |
| 9804 | `b16b0668228bb5b11e5d46453ecc1d3c970e4973015a753bcce29d7bc233a4b3` | same | `.agents/skills/verify-trooptotask/features/bulk-status.md` |
| 5301 | `08c1f295013230ff0fec493f25f94d2a745236336c280022640a03ee24d234c0` | same | `.agents/skills/verify-trooptotask/helpers/network-control.mjs` |
| 17579 | `b84525c50eb9ab4394976a3abf16923a4afb9ec7f36c73d5e8fc6d7c9ff330ed` | same | `.agents/skills/verify-trooptotask/helpers/network-control.test.mjs` |
| 650308 | `e8c93e5602755ae53fdb77245059bff46fd3517f2e8984b29f6cb08f4b9587f8` | changed | `docs/stabilization/EVIDENCE.md` |
| 203693 | `47d21fa83149177e5a54f60089b0482c12d140329591d131d585112fb3a85dd5` | changed | `docs/stabilization/TODO.md` |
| 414388 | `b2e48adf96dc89a921658c2f9a1e8e38840691556a3c132a391afb125df1d1a2` | same | `docs/stabilization/phase-08/d28-calendar-atomic-baseline.tar.gz` |
| 14095 | `085c2cd4832eb0b60ab0adf280fbf1412beed501a1acdebb0f44c0992437af82` | absent | `docs/stabilization/phase-08/d28-calendar-atomic-bulk-removal.md` |
| 1178541 | `35d169eb699f531052fd1c901b25198961395d9365dfc329115dd9bcf818e70c` | absent | `docs/stabilization/phase-08/d28-calendar-atomic-final.tar.gz` |
| 22976 | `6bdea7d103d3a7c581f6d61da41f5552f74d29c4cf9c7378a292d7b41dc9efd8` | changed | `docs/stabilization/phase-08/d28-personnel-ui-repair.md` |
| 32856 | `7c4cee1044047aa9e50acc015a4164239efa141e4f07811607b7c57f6e3acfcc` | same | `scripts/ci/database.py` |
| 2911 | `25c1787dc8f3254672f63c9a321ce4e3dbbcfcc3b5488ab9cb5f7d88e4b8d592` | same | `src/features/calendar/availabilityBatch.server.ts` |
| 4778 | `7c23e7dbf7bbef12e381df980b3d6738548f43c3b56085f2eb7417f15f925440` | same | `src/features/calendar/availabilityRemovalPersistence.server.test.ts` |
| 1595 | `78140ac88f43793fe50648b8d8874ea7d24cc06e6b4c510b07fcd0d896782a63` | same | `src/features/calendar/availabilityRemovalPersistence.server.ts` |
| 2242 | `d8ee3ec5356e6599aed00df1a3025008162ad3696a371f4c6f72cabc72d1f8e7` | same | `src/features/calendar/contracts.ts` |
| 2653 | `b4098df5b0315553c927a7e3baa0b68e5f66b9d8d35657f93102e6f1b7dea684` | same | `src/features/calendar/index.server.ts` |
| 56028 | `09bd930fe8e2bebc2881c3133ab7627606f9b19a6f93a47f289ad8c35db94f9c` | same | `src/lib/server/adapters/inMemory.ts` |
| 24793 | `b69ef882666773025c808c082160a877d65e2f91f676380962432df808d0fab0` | same | `src/lib/server/adapters/requestContexts.server.ts` |
| 4154 | `b1be3eeb41fe40cb3ff67da0a13b5369b7d5c48ae44aee94c54384bb17777a22` | same | `src/lib/server/core/useCases/calendarPolicy.ts` |
| 1272 | `643729b97c2ad18c0e97e02eea4de369bc56cd3e5062ccd9a393280637d12f72` | same | `src/routes/org/[orgId]/api/availability/batch/+server.ts` |
| 4529 | `cd59950c8d03678e3a45b83b82a20e8b2487d99f1d78fe18bcff93b1afd95d1b` | same | `src/routes/org/[orgId]/api/availability/batch/server.test.ts` |
| 2752 | `e3252de8afa7923007c3c2724b136d67141804d973adeeb24163f6d656c5ce65` | same | `supabase/migration-tests/calendar_availability_removal_after.sql` |
| 3746 | `fb231bac2571e3750214bf69e28496831ef785fcb15540f6b794ff2d7c808dba` | same | `supabase/migration-tests/calendar_availability_removal_before.sql` |
| 1135 | `f78cbc200ff1b561b6236782a49cdb05a18c767b3c6246c63bc80fab5553aa49` | same | `supabase/migrations/20261006000100_atomic_calendar_availability_removal.sql` |
| 16777 | `c687475ac74c15ec66d68a00242b89188126cec8675a560eba9f3dc8d63ceb01` | same | `supabase/tests/calendar_availability_atomic_removal.sql` |

All 13 app bindings in the packaged app review and all 5 bindings in the packaged SQL review match these bytes. That includes the corrected test file `7c23e7db…`.

### Other inputs read

| Input | SHA-256 |
| --- | --- |
| `/home/waffleflops/.cache/t2t-1376-current-decisions.tsv` (12 lines) | `8dfed6fddd0b7e88e1fd97b823266e820452f513ef10ae4f58f3dd66e72af3bb` |
| `/home/waffleflops/.cache/t2t-1376-rating-main-integration-state.json` | `d2bb0ac22dbe74aad8850f3be0457cd55e0dbea3a684509716aebbfb3fb9fcb5` |
| `/home/waffleflops/.cache/t2t-1376-current-calendar-investigation.md` | `a59ba0c91561d01fef06a805f7fbf3cc29244a239ea30d44e36ce477b7ec044c` |
| `/home/waffleflops/.cache/t2t-1376-calendar-atomic-scope.md` | `2a54ee50a990d3ab59fbbe12b01d309a15e371b3ff12528a544f5aa7c1bf82a3` |

## Source versus execution boundary

| Claim class | How it is established here |
| --- | --- |
| Source design, consumers, SQL semantics, test quality | Read independently in full by this reviewer |
| Archive integrity and expanded native/SQL observations | Re-extracted and recomputed by this reviewer's own scripts against raw payloads |
| Focused 526 tests, corrected 15 tests, 28 control checks, lint, governance 159/0, production build | Parent-reported only. No raw logs for these are packaged. Typecheck 0/0 and `prettier --write .` with zero changed files are packaged |
| Native app behavior | The parent's frozen live runs. I judged the packaged raw outputs. I did not drive anything |
| SQL behavior | The parent's disposable `scripts/ci/database.py` run. I parsed the full packaged log |
| Exact-head CI, hosted CodeRabbit, remote migration | Not established. CI run 37519606054 was in progress at `c1ae34e2` per the parent's cached PR JSON. Hosted CodeRabbit was pending |

## Archive verification

Each archive was extracted into a fresh `mktemp -d` directory. My verifier lives in a separate directory and runs with `python3 -I`.

| Archive | SHA-256 | Inventory schema | Payloads verified | Inventory SHA-256 | Notes |
| --- | --- | --- | --- | --- | --- |
| Baseline | `b2e48adf…df1d1a2` | `files[].path` | 88 of 88. Set exact, sizes exact, hashes exact | `65279894…6b406144` | No symlinks. No absolute or `..` members. 1 PNG |
| Final | `35d169eb…cf818e70c` | `entries[].file`, `redactions: []` | 225 of 225. Set exact, sizes exact, hashes exact | `10974370…a70efe04` | No symlinks. 3 PNGs |

Scratch paths are `/tmp/d28rev-base.Qp0g`, `/tmp/d28rev-final.JRTj` and `/tmp/d28rev-scripts.A7jk`. They are outside every worktree.

Credential scan of both expanded trees found no JWT-shaped strings, no `anon_key`/`service_role_key`/`sb_secret_`/`sb_publishable_`/`jwt_secret`, and no auth cookies or bearer values. The only hits are tool-description text and the public disposable `PGPASSWORD=postgres` default.

## Expanded observations, independently recomputed

### Baseline, current main `4d5f8bfb`

| Check | Recomputed from raw payloads |
| --- | --- |
| Environment | Digest `40ed3d99…`, session `c5997a6e`, origin `127.0.0.1:34747`, Chromium 152.0.7977.82, actor `calendarOperate` |
| Add | One POST, 500 records, HTTP 200. 500 distinct Person IDs. They equal the new rows' Person IDs. Seed `firstId` sentinel excluded |
| Saved cohort | A went from 6 to 506. Exactly 500 new rows, one note, one date, one status. All 6 original rows unchanged |
| Review | `501 selected`, `500 exact matches will be removed` |
| DELETE body | `delete-body.network-request` holds `{"ids":[…]}` with 500 IDs, all distinct, exactly equal to the 500 new row IDs |
| DELETE outcome | `failed-requests.json` shows `DELETE …/availability/batch [500]`. `delete-response` is `{"message":"Internal server error"}`. The confirm snapshot shows the toast "Failed to remove status entries" |
| No effects | `before-delete-A == after-delete-A` (506 rows, full JSON). B is 1 row and unchanged |
| Observer defect | `delete-network.json` reports `count: 0, ids: []` with status 500. The saved body independently contradicts it. This matches the prose claim |
| Restoration | `initial-A == restored-A` (6) and `initial-B == restored-B` (1) |
| Failed attempts | `failed-build-cause.txt` names Node v26.8.2 and the adapter rejection. Launch BLOCKED `PROCESS_FAILED`. Doctor BLOCKED `OWNERSHIP` with exit 2. Cleanup BLOCKED `SUPERVISOR_ALIVE` with exit 2. Then cleanup PASS, doctor-ready PASS, final doctor PASS, cleanup PASS |
| PNG `failed-500.png` | Viewed. Shows the retained 501-selected/500-match review. The toast has expired, as the record says |
| URI cause | Not captured in this baseline. The record correctly labels it a source inference and a separate private observation |

### Final, frozen `8d225c0a`

| Check | Recomputed from raw payloads |
| --- | --- |
| Environment | Digest `38b8b1fd…`, session `1bdf7346`, origin `127.0.0.1:34417`. Launch, doctor-ready and final-doctor all match revision and digest |
| Originals | Availability A 6 and B 1. Personnel A 3 and B 1 |
| Add | One POST, 500 records, HTTP 200. Person IDs equal the new rows. Sentinel excluded. A goes to 506 with all originals intact |
| Review and Back | Review shows 501 selected and 500 matches. Back shows `501 of 504 selected`. `after-back-A == before-delete-A`, and B is unchanged |
| Synthetic failure | Fail mode returns 503 inside the page wrapper before calling the real fetch (`network-control.mjs:99-107`). `failed-network`: one DELETE, 500 IDs equal to the saved set, status 503. Snapshot keeps the 500-match review with Confirm focused and the toast. `failed-A == before-delete-A` |
| Explicit retry | Hook restored, observer armed. The same `Confirm Removal` control (uid `17_10`) is clicked. `delete-network`: one DELETE, 500 distinct IDs exactly equal to the saved set, HTTP 200. `retry-complete` toast reads "Removed 500 status entries" |
| Effects | `deleted-A == original A` and `reload-A == original A`, full JSON. B is unchanged in every capture |
| Cohort retained | `retained-personnel-A` has 504 rows. That is 3 originals plus 501 cohort, including the sentinel |
| Reload | Repeat review shows "No matching status entries were found" |
| Scoped (`calendarScoped`, Group Alpha) | One added row. One DELETE with exactly that ID, HTTP 200. Toast "Removed 1 status entry". `scoped-after-A == original A` |
| Calendar-only (`calendarLane`, Personnel `none` per `scripts/verification/fixtures.mjs:117`) | 3 rows added. One DELETE with exactly those 3 IDs, HTTP 200. Toast "Removed 3 status entries". `final-A == original A` |
| Viewer | Snapshot heading "Access restricted." No mutation controls. The record correctly makes no native 403 claim |
| Empty Group scope | `0 of 0 selected`, "No personnel available", Review & Confirm disabled |
| Cleanup | `restored-personnel-A/B` equal the originals. Clean-seeds PASS, final doctor PASS, cleanup PASS. `closure.json` reports worker directory absent and port closed at 19:25:27Z |
| PNGs | `failed-retry.png` shows the 500-match review and the failure toast. `success-500.png` shows a reset selection with `0 of 504 selected`, toast expired. `reload-empty.png` shows the empty review. All match the record |

### Disposable SQL log

The packaged `database-validation.log` has 5,852 lines and SHA-256 `e97b8cdf…25d1cc`. That equals the binding in the SQL review.

| Claim | Recomputed |
| --- | --- |
| Fresh replay | 170 migrations, ending at `20261006000100` |
| Fresh SQL suites | 63 files, 1,717 assertions, all `ok` |
| New fresh contract | `calendar_availability_atomic_removal.sql`, 33 assertions |
| Fresh migration regressions | 6 files, 121 assertions |
| Populated upgrade | 141 base migrations, then held migrations including `20261006000100` (log line 2602) |
| Populated contracts | 25 files, 401 assertions. The new after-contract has 10 |
| Failures | Zero `not ok` lines and zero non-PASS `Result:` lines. The three `Calendar Group conversion blocked` errors belong to a retained deliberate-rejection regression that then passes |
| Probes and closure | Both projects report provider probes passing, then "Cleaned up disposable project" |
| `--receipt` attempt | Packaged log shows `Database validation failed: 'GITHUB_RUN_ID'` before any project starts. No receipt was fabricated |

## Source review

Data shape. The new seam is a two-method port, `findPersonnelIds(ids) → string[]` and `deleteIds(ids) → number`. It is captured over one ordinary client and the canonical Organization.

- **Root cause covered.** Base `rawStore.findMany` and base `deleteManyByIds` each encoded all IDs into one PostgREST URL (`supabaseDataStore.ts:316-325`). The repair replaces both. Reads are deduplicated, chunked by 100, and run concurrently. Mutation is one RPC POST body.
- **Behavior preserved.** Base `rawStore` was already `createSupabaseDataStore(request.supabase)`, so it was RLS-bound (`requestContexts.server.ts:129`). The new reference read uses that same ordinary client. Hidden-row semantics therefore do not change. The raw 500 cap still runs before dedup (`availabilityBatch.server.ts:79-85`). Policy still runs before mutation. The audit still records the provider's actual count. The `{deleted}` response still feeds the unchanged client `removeBatch` (`stores/availability.svelte.ts:101-108`).
- **Error mapping.** It follows the `dailyAssignmentPersistence.server.ts` precedent. `42501` maps to 403, `22023` to 400, and anything else to a concealed 500 (`httpAdapter.ts:61-74`). Malformed acknowledgments are rejected before audit.
- **Route context.** The DELETE context is narrow: auth, audit, the existing admin roster port, and the removal port. POST is unchanged.
- **SQL function.** It follows `20260928000100`. It is SECURITY INVOKER with `search_path=''`. It requires a non-null `auth.uid()` and current OPERATE (owner and admin pass through `member_access_has_capability`). It validates cardinality and nulls on the raw array, runs one Organization-filtered DELETE under retained RLS, and returns ROW_COUNT. It revokes from PUBLIC, anon and service_role and grants to authenticated. It changes no tables, rows or policies.
- **Tests.** Route tests run real admission against in-memory rows. Provider tests use the installed SDK against a fake transport. SQL tests prove grants, every denial lane, current capability and scope changes, removed membership, malformed input, 500 delete and replay, and AFTER DELETE statement rollback with full-row equality. These detect real regressions.

## Findings

### F1. Medium (Standards, blocks this axis). Release and authz records omit the new migration and RPC

The repository's release ledger and the authorization/provider-boundary doc do not mention `20261006000100_atomic_calendar_availability_removal.sql` or `delete_availability_entries`. A repo-wide search finds the migration only in `d28-calendar-atomic-bulk-removal.md:19,95`.

- `docs/stabilization/TODO.md:3` says RELEASE owns operator obligations. Every comparable recent migration deliverable has a RELEASE section with the file path and SHA-256 for Robert's ordered manual operation. Examples are `RELEASE.md:333`, `:343`, `:359`, `:391`, `:407`, `:425` and `:435`.
- The DoD's "Required When Architecture Or Authz Changes" section requires updating `AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` when provider ownership or authz changes. The analogous atomic Calendar replacement RPC is documented at `AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md:68`. This PR adds a new authenticated execution grant and moves Calendar deletion off the generic store, so it needs the same treatment.
- The acceptance record states the gate at line 94 but does not bind the migration hash.

Failure scenario. Robert follows RELEASE.md for his manual operation. He finds no entry and no hash for `20261006000100`. The schema-before-app ordering then depends on his finding a phase-08 receipt instead of the owning ledger.

Action, docs only. Add a `## Phase 08 D28 atomic Calendar availability removal` section to RELEASE.md. Include the path, SHA-256 `f78cbc200ff1b561b6236782a49cdb05a18c767b3c6246c63bc80fab5553aa49`, the predecessor `20261004100618`, schema-before-app ordering, the Vercel note (F7), and the fact that the old app is compatible. Add a bullet next to `AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md:66-68` for the invoker RPC, its authenticated-only grant and the Calendar-owned port. No native rerun is needed.

### F2. Low. Provider test fixes read geometry that mirrors the implementation constant

At `availabilityRemovalPersistence.server.test.ts:31`, the fake returns 414 when a read carries more than 100 IDs. That threshold copies the adapter's chunk constant instead of an independent URL-length limit. Lines 53-57 then assert exactly five GETs of exactly 100 IDs.

Failure scenario. A behavior-preserving refactor to 50-ID or URL-length-based chunks fails this test, which is the change-detector pattern in TESTING.md. A refactor whose 100-ID requests still produce an over-long URL against a real server would pass.

Recommended rewrite. Make the fake reject by encoded URL length, using a stated server limit such as 8 KiB. Assert that every GET is under that limit, that the union of read IDs equals the deduplicated input, that all GETs precede exactly one POST, and keep the literal body assertion. Not blocking. The record's line 15 currently states "five reads of at most 100" as permanent contract. If Robert wants that geometry to be contract, keep the test and drop this finding.

### F3. Low. `DataStore.deleteManyByIds` now has no production caller

`git grep` at `c1ae34e2` finds only definitions and bindings: `ports.ts:63`, `supabaseDataStore.ts:316`, `scopedDataStore.ts:166` and `inMemory.ts:469`. The in-memory removal port at `inMemory.ts:650` and `persistenceContract.test.ts:90` are the only users. The Supabase implementation keeps the long-URL `IN` shape that caused this defect.

Action. Delete it now, along with its contract test and the in-memory binding, which can call the raw store's filter delete directly. Alternatively, name it explicitly in the record's remaining "final generic facade removal" so it cannot be reused before that wave. Non-blocking because the record defers facade removal.

### F4. Low. Baseline Personnel cleanup claim lacks a Personnel readback

Record line 29 says all 501 temporary People are removed by journaled cleanup. The baseline archive contains no `personnel` row capture. It has only `clean-seeds.json` (`cleaned: true`) and the availability `restored-A/B` captures. The final run does capture `restored-personnel-A/B`.

Action. Reword to "clean-seeds reports the journaled cohort cleaned, and availability A6/B1 match the originals". Do not claim row-level Personnel absence for the baseline.

### F5. Low. "Projection declared in baseline metadata" is not inside the baseline package

Record line 67 says the header projection is declared in baseline metadata. The baseline inventory has only `files`. `observations.json` has no projection or redaction field, and no baseline payload mentions one. The projection is visible only as `delete-request-safe.txt`, which holds the URL and status.

Action. State that the acceptance record is the declaration, and name the projected file.

### F6. Low. Node `24.21.0` appears only in prose

Record lines 25 and 33 state Node `24.21.0`. Neither archive contains it. Only the Node v26.8.2 failure text is packaged. The DoD asks for tool versions to be recorded, and the record does that. This is only weaker than the Chromium version, which doctor output does capture. Optional fix: name the source of the version.

### F7. Low, needs update. Vercel deployment is now observed, not hypothetical

Record line 96 says Vercel Git settings were not inspected. The parent's cached PR state shows a Vercel `SUCCESS` deployment for PR #1553 at both `20dd7502` and `c1ae34e2`. A preview of the new application, which requires the unmigrated function, is already deployed. The preview's database target is unknown.

Failure scenario. Suppose the preview points at the hosted database. Bulk Remove there fails with a concealed 500 and no data effect until the migration is applied. Production behaves the same way if merge deploys before the migration.

Action. Update line 96 and the new RELEASE section to record the observed preview deployment.

### F8. Informational. Journal provenance gaps

- In final `commands.jsonl`, `scoped-before` (line 59) is recorded before `actor-scoped` (line 60). Yet `scoped-before.json` is a snapshot of page 3 that `actor-scoped` created, with uids `28_*` that `scoped-fill` later uses. The journal's line order is therefore not strictly chronological.
- The baseline `commands.jsonl` omits both launch commands. Their outputs are preserved as separate files.

Neither changes an observed outcome. Treat journal order as approximate.

### Reviewed and found sound

- The `c1ae34e2` delta switches the extraction instructions to `mktemp -d` and passes the same directory to the verifier. It is correct. The hyphenation dismissal is reasonable.
- The recipe at `bulk-status.md` step 6 matches the run actually executed.
- The network-control change and its test are meaningful.
- The packaged app review correctly removed the three arranged-scalar tests.

## Verdicts

**Standards HOLD.** F1 must be fixed. It is docs only and needs no rerun. F2 through F8 are non-blocking.

**Spec GO.** Every scope requirement is met with observed evidence:

- Both long-URL sites are repaired.
- The port has two methods, with no generic expansion, fallback or chunked mutation.
- The body RPC is atomic and returns actual counts.
- Group admission, the raw cap and audit are preserved.
- The unchanged-main HTTP 500 is reproduced with no effects.
- The fresh 501/500 cohort shows Back, synthetic 503, explicit retry, actual 500 deletion, reload, unrelated rows and full restoration.
- Scoped and Calendar-only paths are exercised.
- SQL denial, scope, malformed input, replay, 500 and rollback are proven, along with fresh replay and populated upgrade.
- The grouping rationale holds. A prerequisite repair before the 85-file private cutover is justified by the schema-before-app dependency.

Gates still open: exact-head CI at `c1ae34e2`, completed hosted CodeRabbit, and Robert's manual migration before merge. The preserved worktrees are clean and unchanged: Calendar `67fa5713`, Personnel `52a8a036`, Training `7d6c0a5c`. #1376's remainder is unaffected. That remainder is Calendar phases 8-10, Personnel's four ports, Training's 8 failing cases and 12 unrun native families, Onboarding, residual settings, and final facade removal. D29 and D30 remain out of scope. No credit is given elsewhere.

## Decision-trail audit

Supported digest: this task prompt, `currentWork` and its source commits, the packaged app and SQL reviews, and the initial investigation. I did not scrape any private host store.

| # | Flag | Class |
| --- | --- | --- |
| T1 | The freeze row's typed 19:10Z and the first correction's 11:06:22-08:00 are both superseded append-only. The last correction's `11:06:26-08:00` equals `git log -1 --format=%cI 8d225c0a` exactly | Resolved bookkeeping |
| T2 | Four rows share write time `19:03:15.4702xx`. Four more pairs are batch-written (`19:25:27.787842`, `19:31:18.2143`). Timestamps are logging times, not event times, so chronology inside a batch rests on row order | Bookkeeping |
| T3 | Authority for this deliverable and for publishing PR #1553 is not traceable in the digest. `currentWork.lastContinuationAt` is `13:01:16Z`, which predates #1552's completion. `personnelUiRepair.stoppingPoint` reads "ONE next deliverable merged, then stop with fresh-thread prompt". Only the new doc prose (`TODO.md`, `EVIDENCE.md`, `d28-personnel-ui-repair.md:105`) asserts that Robert later authorized successive PRs until closure. This prompt authorizes bounded independent reviews only | **Needs Robert.** The parent should cite the continuation, or Robert should confirm it. Bookkeeping fix: record the continuation timestamp in `currentWork` |
| T4 | Stale authoritative-adjacent fields. `currentWork.publication` says "No current open worked PR" while `calendarAtomicRemoval.pr` is OPEN and watching. `calendarAtomicRemoval.stage` says "unpublished". `updatedAt` 19:11Z lags `latestTimestamp` 19:34Z | Bookkeeping |
| T5 | Head drift. Review pinned at `20dd7502`, PR and worktree now at `c1ae34e2`. `CLIProse.correctionReview` is "running", so the delta has no CLI review yet. I reviewed it manually and found it correct | Bookkeeping |
| T6 | A Vercel preview of the migration-dependent app is already deployed (F7). The merge gate remains schema-before-app | **Robert awareness.** No new action beyond the existing manual-migration-before-merge gate |
| T7 | The trail has no rows for the SQL worker delegation and patch application, the three-test removal, the source and docs CodeRabbit CLI runs, or the #1552 merge reconciliation. The freeze row mentions the SQL worker and app GO only in passing | Weak coverage, bookkeeping |

The investigation's recommendations, written at 18:49Z, match the implemented design point for point. The trail's selection rationale is supported. The optional authenticated-HTTP proof the investigation mentions for 501 rejection, mixed counts and direct denial was replaced by route tests and SQL tests. That substitution is acceptable under TESTING.md, but it is not native or HTTP evidence.

## Principles applied

- **Prove It Works.** I recomputed every row, ID, count and network outcome from raw payloads with scripts, and viewed all four PNGs, rather than adopting the record's tables. This is what exposed the observer `count: 0` contradiction, the absent baseline Personnel readback (F4) and the missing projection declaration (F5).
- **Test Behavior, Not Implementation.** This drove F2. The fake's 414 threshold copies the production constant.
- **Migrate Callers Then Delete Legacy APIs.** This drove F3, because the generic delete is now callerless.

Attention. Reviewed by Claude Opus 5.5 (`claude-opus-5-5[1m]`) as a different model family from the parent (gpt-6.1-sol). This was an artifact review with no independent execution.

Flags requiring Robert: T3 (confirm the continuation authority) and T6 (preview already deployed, so migrate before merge). Bookkeeping flags: T1 (resolved), T2, T4, T5 and T7. Actionable before merge: F1. Recommended: F2 through F7.
