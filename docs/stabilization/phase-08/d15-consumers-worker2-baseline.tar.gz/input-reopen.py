#!/usr/bin/env python3
"""One ordinary supported reopening request from the reused Onboarding actor page."""
import json,os,subprocess,sys
from pathlib import Path
page,tag=sys.argv[1:3];page=int(page)
run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');b=Path('.verification/evidence/verify-trooptotask')/run
seed=json.loads((b/'consumer-seed-stdout.json').read_text());fixture=json.loads((b/'fixture-stdout.json').read_text());target=next(p for p in seed['packets'] if p['key']=='alphaActive')
assert target['organization_id']==fixture['ids']['orgA'] and target['personnel_id']==seed['people'][0]['id']
body={'id':target['id'],'status':'in_progress'};path='/org/'+target['organization_id']+'/api/onboarding'
source='async () => {const path='+json.dumps(path)+';const body='+json.dumps(body)+';const r=await fetch(path,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),redirect:"manual"});return {observation:"ordinary authenticated API; no native reopen control",method:"PUT",path,submitted:body,status:r.status,body:await r.json()};}'
subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','tool',tag,'evaluate_script',json.dumps({'pageId':page,'function':source,'waitForStableDom':False})],check=True)
