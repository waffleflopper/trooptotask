Packaging follows final doctor and owned cleanup. Public synthetic Organization/Person/contributor IDs, row fields and artifact paths remain visible. Binary PDF/screenshots and non-redacted payload bytes are exact. JWT/signed-query/Bearer token values alone are sanitized, without changing observations. Failed launches and malformed commands retain their explicit outcomes; archives do not establish a fresh live run.

{
  "redactions": [
    {
      "path": "pages-current-B-Open.json",
      "originalSha256": "fc4e9e23a24e00044a64062d8c1de75cd288bec54fcb0ffc3237a7e8ffb49890",
      "sanitizedSha256": "098c8d15a59d2a1ef25b83fe11b22d46f3bd36ba713ba41156b3e1502e886cd9",
      "jwt": 1,
      "queryToken": 0,
      "bearer": 0
    }
  ]
}
