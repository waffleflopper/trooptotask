# v4 expectations (written before driving; grounded on root-public-fixture.json + root-*-original.json literal rows)

Identity: HEAD 53ab7cc9, worker 1, candidate cda447f1...c29e90, origin http://127.0.0.1:34603, session 626b9a39-ff2e-479b-9be6-897f1a3b2a1b.
Fixture day dates.ui 2026-10-04; 90-day horizon ends 2027-01-02.

Org A People: Able (personA 0c2c88b1, Alpha, 68W, Medic), Baker (personB 2354de51, Bravo, 11B, NCO), Unassigned (3f3bc216, 68W, NCO).
Types A: Required dc2cac91 (applies all), Targeted 04180432 (MOS 68W, excludes NCO -> Able only), Optional defde5ac (is_optional).
Original personnel_trainings A: only 8e94ca6f Able Required 2026-09-27 -> 2027-09-27. B: none.
=> 4 applicable pairs (Req x3, Tgt Able). Ready 1 -> 25%. expired 0, not recorded 3, lapse 0. Horizon 25%.

Dated import (CSV): Baker Required completed 2024-10-04 (trainingExpiredCompleted) -> expires 2025-10-04; Able Targeted 2025-10-19 -> 2026-10-19 (15 days, inside 30d orange window, inside horizon).
=> Ready 2 (Able Req, Able Tgt) -> 50% today; Able Tgt lapses by horizon -> 1/4 = 25%. expired 1 (Baker Req), not recorded 1 (Unassigned Req), lapse 1.
Type risk: Required not ready 2 / by horizon 0; Targeted 0 / 1.
Required Total detail: Unassigned Not Done, then Baker expired 2025-10-04. Alpha x Targeted: Able, 15d left, 2026-10-19, Yes.
Workbook (unfiltered, narrow detail open): 5 sheets Summary/Forecast/Hot spots/Focus/Requirements; Requirements exactly 3 rows: Unassigned Req Not Done; Baker Req expired 2025-10-04; Able Tgt 2026-10-19 Yes.

seed training-pages (26 Alpha/PFC: #1 68W/Medic, 25x 11B/NCO), after dated import:
People 29; applicable = 29 Req + Tgt(Able, seed#1) = 31. Ready 2 -> 6% (2/31=6.45); horizon 1/31 = 3%. expired 1, not recorded 28 (Unassigned Req, 26 seed Req, seed#1 Tgt), lapse 1.
Required Total affected = 26 seed + Unassigned + Baker = 28 -> Rows 1-25 of 28, page 2 = 26-28.
Edge (5): after clean-seeds with page 1 shown, Next -> request page=2; server clamps -> page 1, totalPages 1, totalRows 2 (Unassigned, Baker); pager removed.

Empty Bravo + Targeted filter: Baker is NCO -> Targeted N/A -> no applicable requirements; 1 soldier.
Print: exactly one landscape page for empty; no trailing portrait/blank page; no chrome/toasts.
