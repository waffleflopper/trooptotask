#!/usr/bin/env python3
"""Offline check of only the parser function; never import/run the provider probe."""

import ast
import json
from pathlib import Path


directory = Path(__file__).resolve().parent
repository = directory.parents[2]
source = (directory / "provider-proof.py").read_text()
tree = ast.parse(source)
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "decode_json_values")
namespace = {"json": json}
exec(compile(ast.Module(body=[function], type_ignores=[]), "<isolated JSON parser>", "exec"), namespace)
decode = namespace["decode_json_values"]

capture = repository / ".verification/evidence/verify-trooptotask/d15-retention-admission/provider-probes/fault-on-20261001T184244Z-5d20b549/before.outputs.jsonl"
record = json.loads(capture.read_text().splitlines()[0])
assert record["exit"] == 0
stdout = record["stdout"]
assert len(stdout.strip().splitlines()) > 1, "The saved provider row must contain embedded newlines."
expected = json.loads(stdout)
assert len(expected["packets"]) == 8 and len(expected["progress"]) == 8
assert decode(stdout) == [expected]
assert decode(stdout + "\n\t" + '{"second":true}\n') == [expected, {"second": True}]
for invalid in (stdout + "\nnot-json\n", stdout.rstrip() + "{}", '{"truncated":'):
    try:
        decode(invalid)
    except json.JSONDecodeError:
        continue
    raise AssertionError("Non-JSON, adjacent values, or truncated output was accepted.")
print("PASS: saved multiline provider snapshot (8 packets/8 progress), sequential values, invalid-output rejection.")
