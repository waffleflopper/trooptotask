#!/usr/bin/env bash
# crop.sh SRC NAME VIEWPORT_WIDTH LEFT TOP W H  (viewport CSS px region)
set -euo pipefail
src=$1 name=$2 vw=$3 left=$4 top=$5 w=$6 h=$7
dir=$(dirname "$0")/../png
cp "$src" "$dir/$name.png"
iw=$(magick identify -format "%w" "$src")
geom=$(python3 -c "s=$iw/$vw; print(f'{round($w*s)}x{round($h*s)}+{max(0,round($left*s))}+{max(0,round($top*s))}')")
magick "$src" -crop "$geom" +repage -filter point -resize 600% "$dir/${name}-zoom.png"
echo "$dir/${name}-zoom.png geom=$geom"
