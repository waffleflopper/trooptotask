import test from 'node:test';
import assert from 'node:assert/strict';
import {
	incomingCookies,
	outgoingCookies,
	cookieMiddleware,
	assertLive,
	guardTurn,
	servePortState,
	capturePreviewHelper,
	reconcileSpawnedHelper,
	safeStartupCode,
	finishOwnedCleanup,
	TransportError
} from './transport.mjs';

const origin = 'https://owned.example.ts.net:18009';
const prefix = 't2t_verify_example_';
function exchange(overrides = {}) {
	const req = { socket: { encrypted: true }, headers: { host: 'owned.example.ts.net:18009' }, ...overrides };
	const headers = {};
	const res = {
		status: 200,
		ended: false,
		setHeader(name, value) {
			headers[name.toLowerCase()] = value;
			return this;
		},
		writeHead(status) {
			this.status = status;
			return this;
		},
		end() {
			this.ended = true;
			return this;
		}
	};
	return { req, res, headers };
}

test('foreign cookies are omitted while own session chunks and embedded equals retain their values', () => {
	assert.equal(
		incomingCookies(
			'sb-127-auth-token=foreign; theme=dark; ' +
				't2t_verify_example_sb-127-auth-token.0=first==; t2t_verify_other_sb-127-auth-token=other; ' +
				't2t_verify_example_sb-127-auth-token.1=second; t2t_verify_example_=invalid',
			prefix
		),
		'sb-127-auth-token.0=first==; sb-127-auth-token.1=second'
	);
	assert.equal(incomingCookies('sb-127-auth-token=foreign', prefix), '');
});

test('normal Set-Cookie values, scope, security attributes and expiry deletes only gain this namespace', () => {
	const cookies = [
		'sb-127-auth-token.0=synthetic==; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=3600',
		'sb-127-auth-token.1=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly',
		'ttt_pending_auth_flow=synthetic-marker; Path=/; Secure; HttpOnly; SameSite=Strict'
	];
	assert.deepEqual(outgoingCookies(cookies, prefix), [
		't2t_verify_example_sb-127-auth-token.0=synthetic==; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=3600',
		't2t_verify_example_sb-127-auth-token.1=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly',
		't2t_verify_example_ttt_pending_auth_flow=synthetic-marker; Path=/; Secure; HttpOnly; SameSite=Strict'
	]);
	assert.equal(
		outgoingCookies('t2t_verify_example_ttt_pending_auth_flow=x; HttpOnly', prefix),
		't2t_verify_example_ttt_pending_auth_flow=x; HttpOnly'
	);
});

test('middleware wraps the ordinary response header boundary and does not alter native form Origin', () => {
	const { req, res, headers } = exchange({
		headers: {
			host: 'owned.example.ts.net:18009',
			origin,
			cookie: 'sb-127-auth-token=foreign; t2t_verify_example_sb-127-auth-token=issued'
		}
	});
	let reachedApp = false;
	cookieMiddleware({ origin, prefix, sessionId: 'public-session' })(req, res, () => {
		reachedApp = true;
		assert.equal(req.headers.cookie, 'sb-127-auth-token=issued');
		assert.equal(req.headers.origin, origin);
		res.setHeader('Set-Cookie', ['sb-127-auth-token=issued-new; Secure; HttpOnly; Path=/']);
		res.setHeader('Content-Type', 'text/html');
	});
	assert.equal(reachedApp, true);
	assert.deepEqual(headers['set-cookie'], [
		't2t_verify_example_sb-127-auth-token=issued-new; Secure; HttpOnly; Path=/'
	]);
	assert.equal(headers['content-type'], 'text/html');
	assert.equal(headers['x-t2t-1503-session'], 'public-session');
});

test('wrong host, host port, non-TLS, Origin or lost owner cannot reach the app or issue cookies', () => {
	for (const [overrides, alive] of [
		[{ headers: { host: 'foreign.example.ts.net:18009' } }, true],
		[{ headers: { host: 'owned.example.ts.net:18010' } }, true],
		[{ headers: { host: 'owned.example.ts.net:18009', origin: 'https://foreign.example' } }, true],
		[{ socket: { encrypted: false } }, true],
		[{}, false]
	]) {
		const { req, res, headers } = exchange(overrides);
		cookieMiddleware({ origin, prefix, alive: () => alive })(req, res, () =>
			assert.fail('Foreign request reached app')
		);
		assert.equal(res.status, alive ? 403 : 503);
		assert.equal(res.ended, true);
		assert.equal(headers['set-cookie'], undefined);
	}
});

const processFixture = (pid) => ({ pid, state: 'S', start: 'fake-start-' + pid, command: 'fake-owned-' + pid });
function ownedFakes() {
	const binding = {
		repository: '/fake/checkout',
		worker: '1',
		sessionId: 'fake-session',
		candidate: 'fake-candidate',
		artifact: 'fake-artifact',
		sourceDigest: 'fake-source',
		buildDigest: 'fake-build',
		origin: 'http://127.0.0.1:41234',
		supervisor: processFixture(9101),
		appProcess: processFixture(9102),
		starter: processFixture(9103),
		helper: processFixture(9104)
	};
	const state = { ...binding, id: binding.sessionId, phase: 'running' };
	const identities = Object.fromEntries(
		['supervisor', 'appProcess', 'starter', 'helper'].map((key) => [binding[key].pid, binding[key]])
	);
	return {
		binding,
		state,
		identities,
		dependencies: { readState: async () => state, identity: async (pid) => identities[pid] ?? null }
	};
}
test('live ownership requires the original worker, candidate, phase and every bound process', async () => {
	const good = ownedFakes();
	await assertLive(good.binding, good.dependencies);
	for (const alter of [
		(f) => {
			f.state.repository = '/fake/other';
		},
		(f) => {
			f.state.id = 'different-session';
		},
		(f) => {
			f.state.phase = 'cleaned';
		},
		(f) => {
			f.state.candidate = 'new-candidate';
		},
		(f) => {
			f.state.buildDigest = 'new-build';
		},
		(f) => {
			f.identities[9101] = null;
		},
		(f) => {
			f.identities[9102] = { ...f.identities[9102], start: 'replacement' };
		},
		(f) => {
			f.identities[9103] = null;
		},
		(f) => {
			f.identities[9104] = { ...f.identities[9104], state: 'Z' };
		}
	]) {
		const fakes = ownedFakes();
		alter(fakes);
		await assert.rejects(assertLive(fakes.binding, fakes.dependencies));
	}
});
test('guard preserves a live owner and closes transport when the original app disappears', async () => {
	const fakes = ownedFakes();
	let closed = false;
	assert.equal(
		await guardTurn(
			fakes.binding,
			async () => {
				closed = true;
			},
			fakes.dependencies
		),
		true
	);
	assert.equal(closed, false);
	fakes.identities[9102] = null;
	assert.equal(
		await guardTurn(
			fakes.binding,
			async () => {
				closed = true;
			},
			fakes.dependencies
		),
		false
	);
	assert.equal(closed, true);
});
test('Serve check selects the owned port through foreground nesting and leaves another preview irrelevant', () => {
	assert.deepEqual(
		servePortState(
			{
				Foreground: {
					own: { TCP: { 18009: { TCPForward: '127.0.0.1:19009' } } },
					other: { TCP: { 18010: { TCPForward: '127.0.0.1:19010' } } }
				}
			},
			18009
		),
		{ present: true, funnel: false }
	);
	assert.deepEqual(servePortState({ TCP: { 18010: {} } }, 18009), { present: false, funnel: false });
	assert.deepEqual(
		servePortState(
			{
				Services: {
					own: {
						Web: { 'owned.example.ts.net:18009': {} },
						AllowFunnel: { 'owned.example.ts.net:18009': true }
					}
				}
			},
			18009
		),
		{ present: true, funnel: true }
	);
});

const helperLaunch = {
	launcher: '/fake/bin/tailscale-preview',
	script: '/fake/preview.py',
	envExecutable: '/usr/bin/env',
	pythonExecutable: '/fake/bin/python3.14',
	args: ['--project', '/fake/app', 'run', 'tls', '--', '/fake/node', '/fake/sidecar', '/fake/binding']
};
function helperProcess(transient, changes = {}) {
	return {
		...processFixture(9105),
		command:
			[...(transient ? ['/usr/bin/env', 'python3'] : ['python3']), helperLaunch.launcher, ...helperLaunch.args].join(
				'\0'
			) + '\0',
		executable: transient ? helperLaunch.envExecutable : helperLaunch.pythonExecutable,
		...changes
	};
}
function helperDependencies(sequence, program) {
	let index = 0,
		current;
	const stopped = [];
	return {
		stopped,
		identity: async () => {
			current = sequence[Math.min(index++, sequence.length - 1)];
			return current;
		},
		executable: async () => program ?? current.executable,
		script: async () => helperLaunch.script,
		pause: async () => {},
		stop: async (identity) => {
			stopped.push(identity);
		}
	};
}
test('helper capture waits for env to exec the exact Python script and args at the original PID/start', async () => {
	const env = helperProcess(true),
		python = helperProcess(false);
	const dependencies = helperDependencies([env, env, python, python]);
	assert.equal((await capturePreviewHelper(env, helperLaunch, dependencies)).command, python.command);
});
test('helper capture retries a legitimate env-to-Python transition between cmdline and executable reads', async () => {
	const env = helperProcess(true),
		python = helperProcess(false);
	const dependencies = helperDependencies([env, python, python, python], helperLaunch.pythonExecutable);
	assert.equal((await capturePreviewHelper(env, helperLaunch, dependencies)).command, python.command);
});
test('helper capture rejects replaced PID/start and unexpected executable, script or arguments', async () => {
	const captured = helperProcess(true);
	for (const current of [
		helperProcess(false, { pid: 9999 }),
		helperProcess(false, { start: 'replacement' }),
		helperProcess(false, { executable: '/fake/unexpected-interpreter' }),
		helperProcess(false, { command: ['python3', '/fake/other-script', ...helperLaunch.args].join('\0') + '\0' }),
		helperProcess(false, {
			command: ['python3', helperLaunch.launcher, ...helperLaunch.args, '--bg'].join('\0') + '\0'
		})
	])
		await assert.rejects(capturePreviewHelper(captured, helperLaunch, helperDependencies([current, current])));
});
test('failed capture cleanup can signal only the original validated child after its permitted exec transition', async () => {
	const env = helperProcess(true),
		python = helperProcess(false);
	const allowed = helperDependencies([env, python, python, python], helperLaunch.pythonExecutable);
	await reconcileSpawnedHelper(env, helperLaunch, allowed);
	assert.deepEqual(allowed.stopped, [python]);
	for (const invalid of [
		helperProcess(false, { start: 'replacement' }),
		helperProcess(false, { executable: '/fake/unexpected-interpreter' })
	]) {
		const denied = helperDependencies([invalid, invalid]);
		await assert.rejects(reconcileSpawnedHelper(env, helperLaunch, denied));
		assert.deepEqual(denied.stopped, []);
	}
});
test('startup disclosure returns only safe error codes and never thrown message, body or stack', () => {
	assert.equal(safeStartupCode(new TransportError('HELPER_SCRIPT_CHANGED')), 'HELPER_SCRIPT_CHANGED');
	assert.equal(safeStartupCode({ code: 'ENOENT', message: 'private body', stack: 'private stack' }), 'ENOENT');
	assert.equal(
		safeStartupCode({ code: 'private-value', message: 'private body', stack: 'private stack' }),
		'START_BLOCKED'
	);
	assert.equal(safeStartupCode('private thrown value'), 'START_BLOCKED');
});
test('owned cleanup attempts every stop, preserves startup and cleanup codes, and retains an uncertain lease', async () => {
	const attempted = [];
	const operations = [
		async () => {
			attempted.push('forwarding');
			throw new TransportError('PROCESS_REPLACED');
		},
		async () => {
			attempted.push('helper');
			throw { code: 'EACCES', message: 'private message', stack: 'private stack' };
		},
		async () => attempted.push('sidecar')
	];
	await assert.rejects(
		finishOwnedCleanup('HELPER_START_UNSETTLED', operations, async () => attempted.push('release')),
		(error) => {
			assert.equal(error.code, 'HELPER_START_UNSETTLED');
			assert.equal(error.startupCode, 'HELPER_START_UNSETTLED');
			assert.deepEqual(error.cleanupCodes, ['PROCESS_REPLACED', 'EACCES']);
			assert.equal(JSON.stringify(error).includes('private'), false);
			return true;
		}
	);
	assert.deepEqual(attempted, ['forwarding', 'helper', 'sidecar']);
	await assert.rejects(finishOwnedCleanup(null, operations), { code: 'CLEANUP_INCOMPLETE' });
	let released = false;
	await assert.rejects(
		finishOwnedCleanup('HELPER_START_FAILED', [], async () => {
			released = true;
		}),
		{ code: 'HELPER_START_FAILED', cleanupCodes: [] }
	);
	assert.equal(released, true);
});
