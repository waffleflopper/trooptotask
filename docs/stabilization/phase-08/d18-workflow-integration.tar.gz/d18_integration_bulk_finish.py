import sys,json,re
sys.path.insert(0,'.verification');import d18_ui as v,d18_native as n,d18_final as f
life=f.read('05-lifecycle-seed');before=f.read('32-bulk-rows-before')['rows'];snap=(v.root/'36-503-visible.txt').read_text();assert re.search(r'StaticText "1 of \d+ selected"',snap) and 'checkbox "Select SPC '+life['name']+', Synthetic" checked' in snap
assert n.rows('39-503-unchanged-provider','personnel','orgA')['rows']==before;v.helper('39-503-control-restore','network','restore','4');v.helper('40-bulk-reject-arm','network','arm-reject','4','personnel/archive-batch')
for prefix,expected in [('41-rejection',None),('46-explicit-retry',200)]:
 n.click(prefix+'-confirm-open',4,'button "Confirm Archive"');n.click(prefix+'-confirm-submit',4,'button "Archive"',after='alertdialog');snap=v.snap(prefix+'-visible',4);trace=v.helper(prefix+'-transport','network','state','4');assert len(trace['calls'])==1 and trace['calls'][0]['ids']==[life['ids']['person']]
 if expected is not None:assert trace['calls'][0]['status']==expected,trace
 if expected!=200:
  assert re.search(r'StaticText "1 of \d+ selected"',snap) and 'checkbox "Select SPC '+life['name']+', Synthetic" checked' in snap,snap
  assert n.rows(prefix+'-unchanged-provider','personnel','orgA')['rows']==before
 v.helper(prefix+'-restore','network','restore','4')
 if prefix=='41-rejection':v.helper('45-bulk-real-observe','network','arm-observe','4','personnel/archive-batch')
assert n.rows('51-bulk-person-archived','personnel','orgA','id',life['ids']['person'])['rows'][0]['archived_at']
r=v.helper('52-lifecycle-pending-ordinary-http','personnel-archive-batch','5','orgA',json.dumps([life['ids']['duplicateAlpha'],life['ids']['duplicateBravo']]));assert r['status']==200,r
rows=n.rows('53-pending-lifecycle-request-readback','deletion_requests','orgA')['rows'];assert len([r for r in rows if r['resource_id'] in {life['ids']['duplicateAlpha'],life['ids']['duplicateBravo']} and r['status']=='pending'])==2
f.file_capture('54-source-pdf-before-cleanup');n.screenshot('55-native-manager-result',4);n.screenshot('56-native-reviewer-result',3)
print('PASS integration native201/sharedCHECK500-sameRetry200/bulk503-rejection-explicit200/ordinarytwo-lifecyclepending cleanup witnesses',flush=True)
