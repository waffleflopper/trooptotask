#!/bin/bash
D=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v6/driver
J=$(python3 -c "import json,sys;print(json.dumps({'pageId':int(sys.argv[1]),'function':open(sys.argv[2]).read().strip()}))" "$2" "$D/${3:-state.js}")
MAXOUT=0 $D/r.sh "$1" npm run --silent verify:app -- tool evaluate_script "$J" --worker 1
python3 - "$D/$1.out" <<'PY'
import json,sys,re
try:
  m=json.load(open(sys.argv[1]))["structuredContent"]["message"]; s=re.search(r"```json\n(.*)\n```",m,re.S); print(s.group(1) if s else m[:2000])
except Exception as e: print("PARSE", e, open(sys.argv[1]).read()[:1500])
PY
