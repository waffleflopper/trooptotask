import hashlib,json,os,subprocess
from pathlib import Path
repo=Path.cwd();proof=repo/'.verification/tmp/start-sql'
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard']).split(b'\0');files=sorted({repo/os.fsdecode(p) for p in paths if p and (repo/os.fsdecode(p)).is_file()})
def hashes():return {str(p.relative_to(repo)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
frozen=hashes();(proof/'campaign-inputs-before.json').write_text(json.dumps(frozen,indent=2)+'\n')
result=subprocess.run(['python3','scripts/ci/database.py'],cwd=repo)
after=hashes();(proof/'campaign-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');outcome={'exit_code':result.returncode,'input_count':len(frozen),'all_original_inputs_unchanged':frozen==after,'source_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()};(proof/'campaign-result.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True);assert frozen==after
raise SystemExit(result.returncode)
