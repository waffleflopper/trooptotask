# Independent acceptance — D28 / #1376 current-main Calendar baseline r2

**Standards: GO. Spec: GO**, for the closed unchanged-main baseline evidence with two owner-deferred ISSUE exceptions. This is a read-only artifact review by Claude Opus 5.5. It is not independent live execution and earns no cutover, final-candidate or native credit.

The two owner deferrals are P03-14 (#1554) and P05-13 (#1555). They remain ISSUE: observed failures, not passes or desired behavior. They do not block this baseline because Robert accepted them in `currentWork.currentPriorityDecision`, recorded 22:45:02Z with the latest clarification at 22:49:08Z. That deferral covers only these two rare edges. It is not a waiver of any privacy, scope or data contract.

## Bindings rechecked

- Root `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93` is on HEAD `2024a521d93716cfca452c9c0f919923883d0db5`, tree `74d6d0fab41d05d3ef553384b537ca80a3629ce7`, with a clean status (rechecked now).
- `final-doctor.out` reports PASS with:
  - candidate `97e90a3a…ddf5f`
  - origin `http://127.0.0.1:37063`
  - session `e7aea237-a98c-4bee-b027-a5a195d3c2d3`
  - revision `2024a521`
- `freeze-comparison.json`: all seven keys are true.
- The three protected private worktrees are clean at their required heads (rechecked now): Calendar `67fa5713`, Personnel `52a8a036` and Training `7d6c0a5c`.
- Ports 37063 and 33341 refuse connections now. The TMPDIR `/tmp/t2c-c9mqzeu2` is absent.
- I recomputed `inventory.json` independently. Its 5,331 payloads and 135,526,000 bytes match the files on disk exactly, every SHA-256 matches, and the only uninventoried file is `inventory.json` itself.
- The privacy scan found no JWT-shaped values, no token-bearing `access_token`/`refresh_token` values and no auth cookies. The `service_role` matches are migration filenames only.
- `selected-cases.json` and `case-ledger.json` list the same 116 IDs and titles in the same order.

## Case accounting

All 116 selected cases are accounted for: 114 PASS, 2 ISSUE (P03-14, P05-13), 0 UNRUN. The failed R1 run (all 116 UNRUN, directory `d28-calendar-main-baseline-2024a521`) stays separate and earns nothing here.

Proof from the current run that I independently rechecked:

- **Original rows and terminal effects (P10, final).**
  - I diffed the 76 original A/B table sets (153 rows) against each stage: preterminal, after Status deletion, after Assignment deletion, after federal reset.
  - Preterminal: no original row is missing or changed. Additions are only audit, notification and export rows.
  - Status deletion removed exactly status type `ea93747a` and its linked availability row `31af3880`.
  - Assignment deletion removed exactly assignment type `78455c53` and its linked slot `7ec3ab0c`.
  - Federal reset removed exactly the custom federal row `bfa45a6b` and added 44 rows.
  - Every other original row is literally retained, and memberships are unchanged (64 in A, 21 in B).
  - No consumed ID reappears, so no same-ID restoration was manufactured.
  - No non-P10 journey was dispatched after P10 began at 23:06.
- **Notifications and audit.** Each deletion produced 5 notifications. The recipients exactly match A's 4 admins plus 1 owner; the acting member is not among them. Each deletion and the reset produced exactly one audit row (`status_type.deleted`, `assignment_type.deleted`, `special_day.federal_holidays_reset`).
- **Federal holidays.** I derived the 44 observed holidays for 2025–2028 myself (`date` arithmetic plus Saturday→Friday and Sunday→Monday rules) and they equal the saved federal rows exactly. Two consequences:
  - The custom closure `3ad32568` is retained literally.
  - B's special days are unchanged.

  The native reloaded list shows Jul 3 and May 25. The three native warning screenshots show the expected text.
- **Dashboard (P08).** The server-source controls are genuinely isolated per table:
  - The `availability_entries` and `daily_assignments` holds were real provider reads (GET 200, `synthetic:false`).
  - The fail-hard runs were marked synthetic 500s.
  - The error shell keeps navigation usable and shows Retry Dashboard. `dashboard.md:42` allows an eager source to reject the workspace.
  - The full Overview screenshot matches the recipe's worked example independently: 3/4 strength, Able plus Bravo duties, 2 expired, 1 expiring, 2 overdue, 1 warning, the Nov 5 loss, and Able onboarding at 67%.
  - With A held, the B screenshot shows only B facts.
  - P02 interleaving did not write anything until after P08's last observation (21:12:55) and P08 clean-seeds (21:17:19).
- **Calendar/Planner (P09).**
  - The held A save request/response pair is exact.
  - The persisted-before-delivery comparison shows one A row only, with B unchanged.
  - The feedback observer stayed armed on the same window (`armed: !!window.__mapFeedback`). It recorded empty entries before and after release.
  - The observer is sensitive: it captured toasts on page 14 in P05.
  - After narrowing, the in-page request returned 403 with the permission message. The reload then settled on Access Restricted, as the screenshot shows.
  - After the grant was restored, March "Historical retained" appeared again.
- **Bulk 500 (P05-16).**
  - The native DELETE body has 500 unique IDs and the response is `{"deleted":500}`.
  - All A/B rows are identical across saved, after-Back and after-503.
  - The removal deleted exactly those 500 IDs, which are the entire cohort. The 6 originals are retained literally and B is unchanged.
- **Reports and Personnel artifacts (P06/P07).** I parsed the XLSX XML myself.
  - Status Days: Able Leave 4, Baker Training 4 plus Retiring 1, Unassigned 1.
  - Forecast: 31 rows covering Oct 6–Nov 5, with Baker unavailable on Oct 6, 7 and 14.
  - Tempo: consistent with a 91-day window ending Oct 6 (Baker Training 3, which correctly excludes Oct 7).
  - Coverage matches the plan: Able Staff 1 + Archived 1 = 2, Baker Retiring 1, Unassigned 0.
  - Readiness: Bravo at 0/1 on Oct 5–7.
  - Personnel history: Baker shows 3 descending rows, Able shows 2, and manager-none is header-only.
  - `owner-a.json`: the five Calendar raw tables contain exactly the original IDs, literally.
  - The P07-12 and P07-07 failures are backed by the 500 bodies (`p07-failed-http-1`, `p07-person-failure-http-2`), the synthetic source-control state, no captured blob, and a `failed` data_exports row with null size.
- **Spot checks (P02/P04).** P02 saved a null note. P04 hidden Bravo slot: native POST 409 with the generic message, then a no-effects comparison and authorized cleanup.

P01, P03 and the remaining P02/P04/P05 rows were only sampled, through their raw outputs and the worker's comparisons. I found no contradiction.

## Consequential findings

None block this baseline.

## Narrow actionable findings (non-blocking)

1. **The ledger is not traceable per case for P01, P06 and P07.**
   - Path: `case-ledger.json`. Cases P01-01..13, P06-01..06 and P07-01..13 share phase-level boilerplate reasons and a single `p01-`/`p06-`/`p07-` prefix.
   - Example: P07-01 (manager header-only) carries a reason about synthetic failure with no artifact.
   - Action: when packaging, map each case to its specific raw outputs and comparisons. Do not change any status.
2. **Grant narrowing on Calendar has no navigation leg (P09-07).**
   - The run satisfies `access-context.md:27` (fresh-grant: denied ordinary range plus reload) and the plan's §9.
   - It did not observe the "navigation" half of `.agents/skills/verify-trooptotask/features/calendar-assignments.md:36` ("settled Access Restricted page on navigation and reload").
   - The in-page 403 was a direct HTTP fetch, not native UI.
   - Action: label P09-07 as reload plus HTTP. Have the final candidate add a visible in-app navigation into Calendar after revocation. Its expected result is known from the recipe; it will have no baseline pair.
3. **A derived bytecode file sits inside the raw evidence.**
   - Path: `__pycache__/resource-closure-reader.cpython-314.pyc`, which is in the inventory.
   - It shows a reader was imported non-isolated from the evidence directory. It is harmless to the outcomes.
   - Action: exclude or explicitly declare it when packaging. Do not edit the raw run.
4. **The final full-set capture came before the final clean-seeds, with no readback after it.**
   - `p10-full-after-federal-*` (23:18–23:19) precedes `final-clean-seeds` (23:20:26). The owned journal was empty afterwards (`final-owned-journal-empty.json`, 23:20:29).
   - The prior capture already showed seeds absent and memberships exact, so the effect was very likely a no-op. However, no full readback after clean-seeds exists.
   - Action: state this ordering in packaging. No rerun is needed.

## Informational limits

These are accepted as honest and none undermines a selected outcome.

- **Missing response bodies.** Two `p03-closure-preserved-http-{0,1}` response bodies are missing, and catalog bodies captured after reloads are incomplete. P03 relies on provider rows plus the UI, which suffices for effects. The candidate cannot compare those response shapes against the baseline.
- **Zero-byte captures.** Six zero-byte captures are the HTTP 200 attachment requests (reqids 102, 192, 140, 383, 392). The real workbooks and JSON files are retained and were checked. The failure responses are separate captures with non-empty bodies.
- **Feedback timing.** The feedback observer deduplicates and has no timestamps. Empty-entry proof stands; no toast timing is claimed.
- **Journal ordering.** The journal is ordered per wrapper only. The two overlapping P02 dispatches (21:15:00/21:15:03) were a read-only click and a script, with no write effect.
- **Redacted 404 capture.** The mistaken 404 HTML (`p07-empty-person-export.out`) is a redacted projection with its original SHA recorded. It is not admission proof and nothing depends on it.
- **v1 holiday comparator.** The mistaken v1 comparator is preserved and was never used. v2 matches my own derivation.
- **Archived Person.** No archived Person with availability exists in any cohort. The planned scope-ID reader keeps archived admitted IDs; current main's `scopedDataStore` does too. That behavior has no native baseline comparator here and relies on the planned lower-level scope-ID suite.
- **Pagination.** Personnel scope-ID pagination above 1,000 rows and a Calendar 1,001-row read are not native-proven. They remain an optional, root-decided extension under the plan.
- **P05-13 scope.** At 501 people, scoped marked facts and exclusions are unavailable. That falls within the deferral; #1555 covers "cannot load the requested range". Ordinary-scale Alpha exclusions pass in P01-02 and P01-08.
- **Not done or claimed.** No new SQL, CI, remote parity or concurrency/rollback proof. No complete raw bodies.

## Applicability to the planned three-port cutover

This baseline covers every direct and reverse consumer area in `/home/waffleflops/.cache/t2t-1376-calendar-owner-next-integration-map.md`:

- catalog POST/PUT/DELETE plus Settings (P03)
- availability reads and writes, including single and bulk POST creation (P01, P02, P05, P09)
- the narrow remover kept on DELETE, with 1..500 admission (P05-03..07, P05-14..16)
- the assignment reader in Planner, day modal, batch and Quick Fill (P04)
- the Status Days API and Reports (P06)
- Dashboard deferred sources (P08)
- the Personnel layout and record page, plus the record export (P07-01..07)
- the complete Organization JSON/Excel export (P07-08..13)
- the scope-ID callback at ordinary scale, including the explicit empty case (P01-02/03/09)
- the terminal linked deletion and federal reset (P10)

It is sufficient as the unchanged-main comparator under `t2t-engineer` "Establish the affected baseline".

## Required new final-candidate verification

- Run a fresh owned worker and fixture on the integrated candidate. P10 consumed five originals, so this session cannot be reused.
- Repeat P01–P10 affected behaviors against these literal baseline outcomes, with destructive actions last.
- Add the Calendar-navigation leg after grant revocation (finding 2).
- Record P03-14 and P05-13 exactly as observed, whether still ISSUE or changed. Do not reclassify them without evidence.
- Run the map's lower-level suites, including at least one complete factory test with the installed SDK and the real permanent remover.
- Run the scope-ID tests for pagination, empty and archived cases.
- Run governance and removal searches, the full DoD and build, exact-head CI, CodeRabbit, and independent acceptance of the complete diff plus the expanded packaged evidence.
- Package this run once as a sanitized `.tar.gz` with its inventory, per the DoD's packaging section.
