import current as x,json,hashlib,pathlib,subprocess
before=json.loads((x.d.E/'original-preseed-full.json').read_text())['rows'];after=json.loads((x.d.E/'restored-original-full.json').read_text())['rows'];changes=[]
for org,tables in before.items():
 for table,rows in tables.items():
  if table=='audit_logs':continue
  if sorted(rows,key=lambda a:a['id'])!=sorted(after[org][table],key=lambda a:a['id']):changes.append({'organization':org,'table':table})
assert not changes,changes
f=json.loads((x.d.E/'cleanup-created-file-absence.json').read_text())['stdout'];print('fileabsence',f)
audit=[{'organization':org,'before':len(before[org]['audit_logs']),'after':len(after[org]['audit_logs'])} for org in before]
(x.d.E/'original-full-field-comparison.json').write_text(json.dumps({'status':'PASS','businessRows':sum(len(v) for ts in before.values() for t,v in ts.items() if t!='audit_logs'),'allOriginalRowsAndKeysAndFieldsAndTimestampsExact':True,'noAdditionalBusinessRows':True,'changedBusinessTables':changes,'auditedEffectsRetainedUntilDisposal':audit,'criticalTaskOutsideFixedReader':'Maintained personnel-lifecycle seed journal and clean-seeds exact-id accounting; no arbitrary SQL query.'},indent=2))
freeze=json.loads(pathlib.Path('/home/waffleflops/.cache/t2t-1376-final-personnel-implementation-ad0cea51-20261008/final-native-freeze.json').read_text());mismatch=[]
for a in freeze['inputs']:
 p=pathlib.Path(a['path']);b=p.read_bytes() if p.exists() else b''
 if len(b)!=a['bytes'] or hashlib.sha256(b).hexdigest()!=a['sha256']:mismatch.append(a['path'])
control=json.loads((x.c/'control-entry-inventory.json').read_text());cm=[]
for a in control:
 b=(x.c/a['path']).read_bytes()
 if len(b)!=a['bytes'] or hashlib.sha256(b).hexdigest()!=a['sha256']:cm.append(a['path'])
assert not mismatch and not cm,(mismatch,cm)
(x.d.E/'final-input-control-match.json').write_text(json.dumps({'status':'PASS','candidate':freeze['candidate'],'revision':freeze['revision'],'inputs':len(freeze['inputs']),'inputMismatches':mismatch,'copiedControlMismatches':cm,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2))
x.d.call('doctor-final',['doctor'])
