# D13 Server artifact ownership preparation

Frozen isolated worktree: `/home/waffleflops/.cache/t2t-d13-server-cut`.
Base: `de683c2d419c29fd8eaabd7fac8804b32360189c` (includes main D15 #1470 and integrated context repair).
Patch: `d13-server-artifacts-ownership.patch`, 239,058 bytes, SHA-256 `f5eba392c350098830c8da6db66cc39f504ebe34f8b2a53a185be6ff52b90fd1`.
Exact source/governance footprint: 60 paths: 31 modified, 15 added, 14 deleted. Root owns documentation, recipe/map, fixture/helper, TODO/EVIDENCE and all live acceptance. Nothing was integrated into the root worktree; no commits, pushes, PR/GitHub mutations, SQL/migrations, database/provider services or browser actions occurred.
`changed-paths.json` supplies the complete path set and final source hashes. `client-type-only-provenance.json` confirms all nine accepted client/test/workspace changes erase to identical source after removing type imports and whitespace. `handoff-integrity.json` and `patch-application-check.log` record a fresh base-file-set application check in `patch-check-from-base`.

## Complete owner cut

- `personnelArtifactContext.server.ts:6` holds the three storage-shaped Server rows; `:46` exposes only currently consumed request collaborators. Its purpose-aware authorization cache (`:68`) preserves the same request/Org/Person cache and rejected Promises; read admission and write admission stay independent. No new global UseCaseContext property, lifecycle registry, generic query port, factory or compatibility export.
- Context persistence exposes only `findPersonnelGroup`, `listCounselingRecords`, `listDocuments`, `listFollowUps`, and `findDocument`. Other collaborators are the existing Person-bound writer, Organization contributor labels, Organization document cap setting and request-scoped document signed URL. The internal admission/writer/label helpers are not exported by the public index.
- `httpAdapter.ts:142` binds actual request collaborators. Dashboard constructs ONE context for its three family streams. Each collection/item/download handler and the four other page loaders use that binder; Archived also receives the unchanged accepted Note context. Existing route parser/policy and payload behavior remain unchanged.
- Owned operations are `personnelCounselingRecords.server.ts` (list/create/archive/restore/delete); `personnelDocuments.server.ts` (those five plus signed URL); `personnelFollowUps.server.ts` (list/create/status/update/archive/restore/delete); `personnelArchivedArtifacts.server.ts` (four-family archived aggregation and saved-event ordering).
- `personnelArtifact.types.ts` is the single canonical portable DTO/status/Archived union leaf, publicly exported through contracts. Private detail types import it for PageData/streams; they do not re-export the removed DTO declarations. Storage rows remain Server-only. Existing accepted Note DTO/input/cursor operations are unchanged.
- `OrganizationPersonnelDocumentSettingsReader` and `loadPersonnelDocumentStorageCapBytes` are the narrow public Organization Server collaborator. Request delivery reads the admitted Organization's setting and preserves nullish 100 MiB default, configured zero and errors. It adds no independent settings-edit or admin capability requirement.
- Only the two existing owned retention modules' bucket imports change; parent RPC and four-family retention logic remain unchanged.

## Preserved contracts and consequential edge cases

Sensitive GET/list/Open requires configure; mutations require operate, plus the admitted Person's Group. Missing parent remains404 before artifact read; scoped or mismatched artifact remains404. A denied sensitive read does not deny an otherwise admitted operate write. Privileged writer construction remains behind both owned admission and the existing writer's independent Person/Org/operate check. Signed URL uses request Storage and expires300 seconds; it never upgrades to writer/admin Storage.

Full-list pagination remains the existing scoped store's complete 1,000-row paging, and caller limits retain their current meaning. Counseling order is conducted-date/created timestamp descending; Documents created timestamp descending; Follow-up order retains status, archive timestamp when archived, then created timestamp. No new snapshot/order guarantee.

Counseling retains PDF MIME/size/signature checks and 10 MiB bound (its existing oversized selection response is400). Documents retain PDF/JPEG/PNG/HEIC/HEIF MIME/signature checks, 10 MiB response413, existing filename/title derivation, per-Person active-byte cap and unchanged database concurrency constraint. HEIC brand semantics are preserved, not tightened. Canonical file paths are unchanged; metadata-only fixture paths do not broaden supported production paths.

File create remains upload then insert, with file compensation on insert failure, then success audit and display hydration. Compensation failure may replace the original failure, as before. Individual binary deletion remains row then file then audit; a Storage failure leaves the prior row deletion visible and emits no success audit. Organization-approved counseling deletion is deliberately different: Storage before the unchanged atomic request/record RPC and expected-file-path condition. No D18 race/approval redesign or rollback guarantee.

Binary repeat archive409; binary restore succeeds even when already active. Follow-up repeat archive succeeds and refreshes stored archived_at/updated_at; edit/reopen of archived409, explicit restore requires archived409 otherwise, and restore clears completed/archive timestamps. Stored event timestamps and raw snake-case export values/IDs/paths stay separate from display DTOs/labels.

Counseling mapper retains legacy subject/notes, missing timestamp from conducted date, fileless status/filename and Leader-upload fallback. Organization member label priority/UUID filtering/raw fallback remain the accepted collaborator behavior. Archived aggregation still includes Notes and sorts Follow-up by archivedAt, falling back to updatedAt; the other families use archivedAt then createdAt.

## Direct/reverse consumer disposition

Direct edits: seven JSON routes, five server page loaders, HTTP binder; download route test's operation binding and Follow-up route test's portable import. All actual collection POST schemas, item route-ID overwrite/mismatch handling, status/edit discrimination, sanitized unexpected failures and success payloads are preserved. No URL/visible action changes.

Already-owned reverse consumers need no new compatibility seam or source edits: `artifactWrites.server.ts:57`, `personnelArchiveCascade.server.ts:57/:80`, `personnelLifecycle.server.ts`, `personnelExport.server.ts:39`, `organizationExport.server.ts:27`, `governanceDeletion.server.ts:11`, `archiveRetention.ts`, `deletionRequests.ts`, Organization raw/export manifest and export route. Existing SQL/RLS/group-scope provider adapters remain owned support, not the removed lifecycle registry.

Person export remains the narrower Counseling/Training/Availability workbook; it does NOT gain Document/Follow-up/Note sheets. Organization export retains all five raw Personnel source sections including active/archive history and stored contributor identities, and Organization export/reviewer authority stays independent of Personnel configure. DataExport orchestration/formatting is D24; job admission/dispatch is D25.

Parent cascade preserves follow-up→counseling→document→Note order and50-update batches; only open Follow-ups and active binaries/Notes archive. Restore selects the exact saved parent timestamp, preserving completed/prior historical items. It remains nontransactional, with no new concurrent-restore or mutation-time guarantee. Parent retention RPC is unchanged.

Deletion: five former global module/test pairs (Counseling, Documents, Follow-ups, generic lifecycle, Archived) plus dead Counsel entity/mapping/test and barrel:14 files. The barrel had only Counsel exports after D15 and zero consumers; Onboarding's owned Server entity is untouched. Only actual deleted file/mixed-barrel registrations are removed from module-boundaries; new delivery test is correctly owned. Generic entity/CRUD infrastructure and scanner coverage are untouched.

## Actual lower-level observations

Installed tools: Node24.21.0, npm11.19.0, Vitest4.1.8, Supabase SDK2.106.1 (matches package lock). Dependency files unchanged; root node_modules is linked, no credentials or environment files copied. Type checks use only `PUBLIC_SUPABASE_URL=http://verification.invalid`, `PUBLIC_SUPABASE_ANON_KEY=synthetic-key` and task TMPDIR in HOME cache.

- Final combined focused run:36 suites/381 cases PASS (`final-focused-green.log`), plus the existing Organization label collaborator suite/1 case PASS separately (`organization-label-collaborator-green.log`). Named paths are in `final-focused-paths.json` and raw commands/logs.
- Final types0 errors/0 warnings PASS (`final-types.log`). Touched formatting/lint/diff checks PASS; governance519 inherited findings PASS compared with main57a5da85 (`governance-green.log`). No added allowances, exemptions, couplings or reduced scanning. Remaining10 Personnel findings are broader roster/orgContext/ScopeEnforcement/CriticalTasks-test debt, not artifact CRUD/Archived.
- Unchanged-base SDK reproduction: each family read1,000+1 artifacts then serialized ONE39,196-byte contributor URL; finite model returned414 at its8,192-byte ceiling. `contributor-baseline-red-controlled.log`:4 failed/1 passed. This is actual SDK serialization with intercepted fetch, not live PostgREST/SQL/RLS.
- Final SDK: each family returns exact1,001 IDs and first/last display labels; artifact offsets0/1000;11 member requests with10×100 IDs plus1; maximum URL4,057 bytes; all modeled statuses200. `sdk-*.json` and `contributor-sdk-green-receipts.log` preserve observed summaries. SDK tests also propagate a later artifact page failure and later label failure, and exercise admitted-Org cap0/null/failure with no denied upload/row effects. The mocked unavailable-page response uses400 to avoid SDK retry timing; it is not a claim that real outages return400.
- Controlled unbounded-label fault:4 failures/4 passes in8 tests, exact HTTP binder bytes restored. Controlled cache-removal fault:2 failures/6 passes in8 tests, exact context source restored. Logs/restoration hashes are retained. No fault remains in the patch.
- Initial empty-env type run had10 missing-public-env errors, resolved using synthetic overrides. Initial later-page503 fault timed out on SDK retries, corrected to deterministic400 for failure propagation. One intermediate parallel Vitest run emitted an ENOENT generated SvelteKit proxy warning but passed; the final single-process focused run is clean. An over-broad cache-only import consolidation touched63 incidental paths, then restored every one byte-for-byte from base; none enters the patch. Initial governance identified/disposed private test→Delivery imports and type cycles through canonical leaves and the existing private Note test-helper pattern, without waivers. Earlier attempted JSON edit left a trailing comma; fixed before passing governance.

The SDK finite fixture is localized in one delivery test (~190 lines), not a copied parent-retention harness or new abstraction. Existing25 family/Archived cases moved with the owner. The eight generic-registry cases are disposed: registration/predicate/clauses were artificial; their retained policy/cache/404/lifecycle/order behavior is protected by owned-family/context checks and actual SDK delivery. The uncalled entity declaration/mapping tests retire with their dead owner; its applicable fileless legacy mapping is now exercised through the actual Counseling list.

## Coordinator acceptance still required

No native/browser, live authenticated endpoint, SQL/RLS/concurrency, real Storage, migration replay, complete repository suite, production build, CI, CodeRabbit or independent acceptance was run by this worker. Existing1471/1472 durable baseline receipts are applicable only to the unchanged behaviors they observed; these preparation checks do not replace fresh final cutover proof. The source cap precheck does not prove the database's concurrent cap constraint.

For final cutover repeat ordinary actor read/write/Group/Org/mismatch and binary file/signedURL obligations with existing helper, native all-family create/retry/archive/restore/delete/Open where present, and unaffected parent/real-file/export proof selected by root. Preserve unsupported native counseling Open and positive-B fixture limitations; don't invent missing UI. Reuse the existing SQL/RLS/cap/approval contracts in owned disposable verification if selected; do not create a migration or touch remote data. Keep D18 file approval race/RELEASE, D24 export workflow and D25 admission semantics separate.

Root documentation/map updates must describe the completed owner operations/cache/portable shapes and 100-ID label reads, remove CURRENT_OWNERSHIP's obsolete central contributor-helper link at120, replace MODULE_CONVENTIONS74 / DRIFT_LEDGER43 shared-helper claims, and repair MODULE_CONVENTIONS93's already-stale `personnelOwnedArchiveSpecs()` name to the unchanged current owned parent coordinator. The recipe's retained lower-check list should name the moved owned tests/context/SDK coverage; actual browser paths/control endpoints stay unchanged. TODO/EVIDENCE must distinguish prior baseline, this lower preparation and later live/CI acceptance. Typical total review scope is60 source/governance plus root's ~6 prose/map paths and packaged run(s), not an implementation quota.

## Exact source/governance paths

- `M` `scripts/module-boundaries.json`
- `M` `src/features/organization/index.server.ts`
- `A` `src/features/organization/personnelDocumentSettings.server.test.ts`
- `A` `src/features/organization/personnelDocumentSettings.server.ts`
- `M` `src/features/personnel/components/PersonnelArchivedArtifactsPageView.svelte`
- `M` `src/features/personnel/components/PersonnelCounselingsPageView.svelte`
- `M` `src/features/personnel/components/PersonnelDetailPageView.svelte.test.ts`
- `M` `src/features/personnel/components/PersonnelDocumentsPageView.svelte`
- `M` `src/features/personnel/components/PersonnelFollowUpsPageView.svelte`
- `M` `src/features/personnel/contracts.ts`
- `M` `src/features/personnel/index.server.ts`
- `M` `src/features/personnel/personnel-detail.types.ts`
- `A` `src/features/personnel/personnelArchivedArtifacts.server.test.ts`
- `A` `src/features/personnel/personnelArchivedArtifacts.server.ts`
- `A` `src/features/personnel/personnelArtifact.types.ts`
- `A` `src/features/personnel/personnelArtifactContext.server.test.ts`
- `A` `src/features/personnel/personnelArtifactContext.server.ts`
- `M` `src/features/personnel/personnelArtifactRetention.server.ts`
- `A` `src/features/personnel/personnelArtifacts.testHelper.ts`
- `A` `src/features/personnel/personnelCounselingRecords.server.test.ts`
- `A` `src/features/personnel/personnelCounselingRecords.server.ts`
- `A` `src/features/personnel/personnelDocuments.server.test.ts`
- `A` `src/features/personnel/personnelDocuments.server.ts`
- `A` `src/features/personnel/personnelFollowUps.server.test.ts`
- `A` `src/features/personnel/personnelFollowUps.server.ts`
- `M` `src/features/personnel/personnelRetention.server.ts`
- `M` `src/features/personnel/workspace/personnelArtifactDraftSpecs.ts`
- `M` `src/features/personnel/workspace/personnelDetailWorkspace.svelte.test.ts`
- `M` `src/features/personnel/workspace/personnelDetailWorkspace.svelte.ts`
- `M` `src/lib/server/adapters/httpAdapter.ts`
- `A` `src/lib/server/adapters/personnelArtifacts.test.ts`
- `D` `src/lib/server/core/useCases/personnelArchivedArtifacts.test.ts`
- `D` `src/lib/server/core/useCases/personnelArchivedArtifacts.ts`
- `D` `src/lib/server/core/useCases/personnelArtifactLifecycle.test.ts`
- `D` `src/lib/server/core/useCases/personnelArtifactLifecycle.ts`
- `D` `src/lib/server/core/useCases/personnelCounselingRecords.test.ts`
- `D` `src/lib/server/core/useCases/personnelCounselingRecords.ts`
- `D` `src/lib/server/core/useCases/personnelDocuments.test.ts`
- `D` `src/lib/server/core/useCases/personnelDocuments.ts`
- `D` `src/lib/server/core/useCases/personnelFollowUps.test.ts`
- `D` `src/lib/server/core/useCases/personnelFollowUps.ts`
- `D` `src/lib/server/counselingRecordMapping.test.ts`
- `D` `src/lib/server/entities/counselingRecord.test.ts`
- `D` `src/lib/server/entities/counselingRecord.ts`
- `D` `src/lib/server/entities/index.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/counseling-records/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/counseling-records/[recordId]/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/documents/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/documents/[documentId]/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/documents/[documentId]/download/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/documents/[documentId]/download/server.test.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/follow-ups/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/follow-ups/[followUpId]/+server.ts`
- `M` `src/routes/org/[orgId]/api/personnel/[id]/follow-ups/server.test.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/archived/+page.server.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/artifact-subpages.svelte.test.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/counselings/+page.server.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/documents/+page.server.ts`
- `M` `src/routes/org/[orgId]/personnel/[personnelSlug]/follow-ups/+page.server.ts`
