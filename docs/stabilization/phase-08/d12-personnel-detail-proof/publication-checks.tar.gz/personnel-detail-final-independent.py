"""Read archived observations only; no app/service/DB calls. Independent ordinary analysis."""
import json, re, hashlib
from pathlib import Path
from collections import Counter
P=Path('/home/waffleflops/.cache/t2t-1360-retention-ownership/.verification/detail-final-independent-eb4s204b/native-final')
OUT=P.parent.parent/'personnel-detail-final-independent.json'
checks=[]
def check(category,label,ok,detail=None):
    checks.append({'category':category,'label':label,'pass':bool(ok),**({'detail':detail} if detail is not None else {})})
def raw(label):return json.loads((P/(label+'.stdout')).read_text())
def text(label):return '\n'.join(c['text'] for c in raw(label).get('content',[]) if c['type']=='text')
def public(label):return json.loads(text(label).split('```json\n')[1].split('\n```')[0])
def rows(label):
    d=raw(label)
    assert d['count']==len(d['rows']),label
    return sorted(d['rows'],key=lambda x:x['id'])
def one(label):
    r=rows(label);assert len(r)==1,label
    return r[0]
PID='ecc94f51-af41-4f82-93c9-ce87e72e1b2f'
ORG='1f22381a-0878-408f-a8c2-e596025e02f5'
GROUP='6c83a764-7934-4cc4-b0a0-2e13a7683c1a'
SLUG='maplifecycle47f1e22d-synthetic'
URL='http://127.0.0.1:35249/org/'+ORG+'/personnel/'+SLUG
TABLES=['personnel','personnel_extended_info','leader_notes','counseling_records','personnel_documents','personnel_follow_ups','personnel_trainings','personnel_ict_completions','availability_entries','rating_scheme_entries']
SDS_VALUES={'blood_type':'O+','basd':'2014-06-01','date_of_rank':'2023-10-01','marital_status':'Married','number_of_dependents':2,'children':[{'name':'Avery','age':7},{'name':'Jordan','age':None}],'civilian_education':'AS Respiratory Therapy','military_education':['BLC','Medic Sustainment'],'emergency_contact_name':'Sam Synthetic','emergency_contact_relationship':'Sibling','emergency_contact_phone':'555-0104','spouse_name':'Pat Synthetic','spouse_phone':'555-0103','vehicle_make_model':'Subaru Synthetic','vehicle_plate':'VFY472','vehicle_color':'Gray','personal_email':'final47f1e22d@example.test','personal_phone':'555-0102','address_street':'123 Verification Way','address_city':'Fairbanks','address_state':'AK','address_zip':'99701'}
check('SDS','initial absence',rows('sds-before-row')==[])
sds=one('sds-saved-row')
for key,value in SDS_VALUES.items():check('SDS','saved '+key,sds[key]==value)
check('SDS','new identity, exact28 fields, own Org/parent and untouched sibling acknowledgement',len(sds)==28 and sds['id']=='7b1deddf-a4e6-4cce-b9dd-b379db43a481' and sds['organization_id']==ORG and sds['personnel_id']==PID and sds['award_tracking_acknowledged_at'] is None)
check('SDS','insert creation timestamp equals update timestamp',sds['created_at']==sds['updated_at'])
# Native reopened values, rather than a provider read alone.
TOKENS=['O+','Married','555-0102','final47f1e22d@example.test','123 Verification Way','Fairbanks','AK','99701','2014-06-01','2023-10-01','Pat Synthetic','555-0103','Avery, 7','Jordan','Gray','Subaru Synthetic','VFY472','AS Respiratory Therapy','BLC','Medic Sustainment','Sam Synthetic','Sibling','555-0104','value="2"']
for label in ['sds-reopened','scope-manager-sds-reopen','scope-alpha-sds-reopen']:
    txt=text(label)
    for token in TOKENS:check('SDS native read',label+' '+token,token in txt)
for label,method in [('sds-request-status','PUT'),('archive-parent-status','DELETE'),('restore-parent-status','PATCH'),('import-submit-status','POST'),('import-cleanup-permanent-status','DELETE')]:
    c=raw(label)['calls'];check('HTTP effects',label,len(c)==1 and c[0]['method']==method and c[0]['status']==200 and not raw(label)['held'])
# Full event-vs-independent-history rows; compare all fields, not only counts/archived_at.
EVENT={'personnel':PID,'leader_notes':'58fd7035-6b7b-4b72-b93b-521f051d06c0','counseling_records':'d14b158e-1a95-4124-a33e-67e3b34bd9eb','personnel_documents':'75bd401b-2199-42b4-a2c7-dd1a47936f55','personnel_follow_ups':'63bd8a2d-21cf-4e98-a199-b988f4a588e5'}
T='2026-10-01T12:03:08.075+00:00'
row_comparisons=0
for table in TABLES:
    b,a,r=[rows(prefix+table) for prefix in ['archive-before-','archive-after-','restore-after-']]
    check('archive/restore','full identity set '+table,[x['id'] for x in b]==[x['id'] for x in a]==[x['id'] for x in r])
    for old,arch,rest in zip(b,a,r):
        expected=dict(old);expected_restore=dict(old)
        if old['id']==EVENT.get(table):
            expected['archived_at']=T
            if table=='personnel_follow_ups':expected['status']='archived'
            if 'updated_at' in old:
                check('archive/restore','monotonic event timestamp '+table+' '+old['id'],old['updated_at']<=arch['updated_at']<=rest['updated_at'])
                expected['updated_at']=arch['updated_at'];expected_restore['updated_at']=rest['updated_at']
        check('archive/restore','literal archive '+table+' '+old['id'],arch==expected)
        check('archive/restore','literal restore '+table+' '+old['id'],rest==expected_restore)
        row_comparisons+=2
HEADER={'id':PID,'slug':SLUG,'rank':'SPC','lastName':'MapLifecycle47f1e22d','firstName':'Synthetic','groupId':GROUP,'groupName':'Alpha','mos':'68W','clinicRole':'Medic','ets':None,'deros':None,'archivedAt':None}
for label,t in [('archive-active-header-projection',None),('archive-header-public-projection',T),('restore-header-public-projection',None),('scope-manager-header-projection',None),('scope-alpha-header-projection',None)]:
    d=public(label);check('Header',label,d['headers']==[{**HEADER,'archivedAt':t}] and d['status']==200 and d['errors']==[])
check('Header','archived reload at exact previously active canonicalURL', 'RootWebArea "SPC MapLifecycle47f1e22d, Synthetic - Personnel" url="'+URL+'"' in text('archive-canonical-detail-reloaded'))
for token in ['Present','1 due','50%','Not assigned','Missing ETS']:
    check('Header','archived settled lane '+token,'StaticText "'+token+'"' in text('archive-canonical-detail-reloaded'))
check('Header','visible Restore exercised', 'button "Restore"' in text('restore-parent-visible'))
for stem,suffix in [('tab-','-public-id'),('scope-alpha-','-projection')]:
    for lane in ['follow-ups','counselings','documents','notes','archived']:
        d=public(stem+lane+suffix)
        check('tabs','same parent/header '+stem+lane,d['headers']==[{**HEADER,'slug':'map-lifecycle-47f1e22d-person' if stem=='tab-' else SLUG}] and d['personnelIds'] and set(d['personnelIds'])=={PID} and d['status']==200 and d['errors']==[])
# Exact supported loss fields and preserved parent, distinct detail-vs-global decisions.
parent=one('loss-before-person')
for label,ets,deros in [('loss-first-person','2027-06-01','2026-10-16'),('loss-second-person',None,'2026-10-08'),('loss-restored-person',None,None)]:
    value=one(label)
    check('loss persisted',label,value=={**parent,'ets':ets,'deros':deros,'slug':SLUG})
check('loss detail','ETS+243 -> No loss risk despite DEROS+15','StaticText "No loss risk"' in text('loss-first-fresh-after-reload') and 'ETS Jun 1, 2027 is 243 days away.' in text('loss-first-fresh-after-reload'))
check('loss detail','NULL ETS -> Missing ETS despite DEROS+7','StaticText "Missing ETS"' in text('loss-second-detail-reloaded') and 'No ETS date is set' in text('loss-second-detail-reloaded'))
for prefix,personnel,calendar,home,date in [('loss-first','loss-first-personnel-entry-corrected','loss-first-calendar-entry','loss-first-home-fresh','Oct 16'),('loss-second','loss-second-personnel-snapshot','loss-second-calendar-snapshot','loss-second-home-snapshot','Oct 8')]:
    pt=text(personnel);ct=text(calendar);ht=text(home)
    # Personnel row binds the PCS indication to exact identity, not another Soldier.
    target=[l for l in pt.splitlines() if 'row "Open SPC MapLifecycle47f1e22d, Synthetic' in l]
    start=pt.index(target[0]); following=pt[start:].splitlines(); indent=len(following[0])-len(following[0].lstrip()); stop=next((i for i,l in enumerate(following[1:],1) if l.strip() and len(l)-len(l.lstrip())<=indent),len(following)); target_block='\n'.join(following[:stop])
    check('loss global',prefix+' Personnel same row PCS',len(target)==1 and 'StaticText \"PCS\"' in target_block)
    check('loss global',prefix+' Calendar same Person PCS','MapLifecycle47f1e22d, Synthetic PCS' in ct)
    # Dashboard is a compact identity+date, not an asserted native day count.
    check('loss global',prefix+' Dashboard compact exact Person/date','SPC MapLifecycle47f1e22d' in ht and 'StaticText "'+date+'"' in ht)
# Import state remains blocked for the still-invalid date after the rank correction.
for label in ['import-before-row','import-preview-no-write','import-cleanup-absence']:check('Import',label+' no persisted row',not rows(label))
check('Import','initial invalid Rank and ETS blocked','NOTARANK' in text('import-invalid-fresh') and '2027-02-30' in text('import-invalid-fresh') and 'button "Import checked rows" disableable disabled' in text('import-invalid-fresh'))
check('Import','rank corrected while invalid ETS still blocks', 'textbox "Row 2 Rank" value="SPC"' in text('import-rank-blur') and 'ETS must be a valid YYYY-MM-DD date' in text('import-rank-blur') and 'button "Import checked rows" disableable disabled' in text('import-rank-blur'))
check('Import','correct date/select/ready/enabled','textbox "Row 2 ETS" value="2027-02-28"' in text('import-date-blur') and '1 of 1 selected' in text('import-date-blur') and 'Ready to import.' in text('import-date-blur') and 'button "Import checked rows" disableable disabled' not in text('import-date-blur'))
imp=one('import-saved-row')
IMPEXP={'id':'c09ed893-c575-40f0-b931-5ad11df5d794','organization_id':ORG,'rank':'SPC','last_name':'FinalImport47f1e22d','first_name':'Synthetic','mos':'68W','clinic_role':'Medic','group_id':GROUP,'ets':'2027-02-28','deros':None,'slug':'finalimport47f1e22d-synthetic','archived_at':None}
for key,value in IMPEXP.items():check('Import','saved '+key,imp[key]==value)
ih=public('import-header-public-projection')
check('Import','same persisted ID/Org/group/date on reload',ih['status']==200 and not ih['errors'] and ih['headers']==[{**HEADER,'id':imp['id'],'slug':imp['slug'],'lastName':imp['last_name'],'ets':imp['ets']}])
check('Import','native reload saved fields', 'RootWebArea "SPC FinalImport47f1e22d, Synthetic - Personnel"' in text('import-detail-reloaded') and 'Feb 28, 2027' in text('import-detail-reloaded'))
check('Import','typed permanent confirmation visible','FinalImport47f1e22d' in text('import-cleanup-confirm-name') and 'textbox \"Type the name to confirm\" focusable focused value=\"SPC FinalImport47f1e22d, Synthetic\"' in text('import-cleanup-confirm-name') and 'button \"Permanently Delete\"' in text('import-cleanup-confirm-name'))
# Configure vs operate and group/Org concealment are different permissions.
for label in ['scope-manager-detail-settled','scope-alpha-sds-fresh']:
    tx=text(label)
    check('scope',label+' independently denied four foreign lanes with available owned loss',tx.count('StaticText "Unavailable"')==4 and 'StaticText "Missing ETS"' in tx)
for lane in ['dashboard','follow-ups','counselings','documents','notes','archived']:
    d=public('scope-bravo-'+lane+'-projection')
    check('scope','Bravo native404 '+lane,'heading "404"' in text('scope-bravo-'+lane+'-snapshot'))
    check('scope','Bravo streamed denied no identity '+lane,d['status']==200 and d['headers']==[] and d['personnelIds']==[] and any('not found' in e['message'] for e in d['errors']))
for label in ['scope-empty','scope-foreign-person','scope-foreign-org']:
    d=public(label+'-projection');check('scope',label+' native404/no public identity','heading "404"' in text(label+'-snapshot') and d['headers']==[] and d['personnelIds']==[])
d=public('scope-operate-projection')
check('scope','operate Header allowed, dashboardconfigure403','heading "403"' in text('scope-operate-snapshot') and d['status']==200 and d['headers']==[HEADER] and d['personnelIds']==[] and any('can manage' in e['message'] for e in d['errors']))
for org in ['orgA','orgB']:
    for table in TABLES:
        check('scope no effect',org+' '+table,rows('scope-before-'+org+'-'+table)==rows('scope-after-'+org+'-'+table))
        check('restore original',org+' '+table,rows('original-'+org+'-'+table)==rows('final-'+org+'-'+table))
check('restore original','originalA3/B1',len(rows('final-orgA-personnel'))==3 and len(rows('final-orgB-personnel'))==1)
seed=json.loads((P/'recorded-seed-inventory.json').read_text())
for entry in seed['seeded']:
    remaining={r['id'] for r in rows('final-'+entry.get('organization','orgA')+'-'+entry['table'])}
    for ident in entry['ids']:check('seed absence',entry['table']+' '+ident,ident not in remaining)
check('seed absence','new SDS and UI import absent', sds['id'] not in {r['id'] for r in rows('final-orgA-personnel_extended_info')} and imp['id'] not in {r['id'] for r in rows('final-orgA-personnel')})
# Separate run identity/resource observations from product behavior counts.
for label in ['doctor-initial','checkpoint-doctor','final-pre-seed-cleanup-doctor','final-post-seed-cleanup-doctor']:
    d=raw(label);check('run provenance',label,d['status']=='PASS' and d['revision']=='a200c7b8936b2abcb4105cbebd4ad7789e8e6413' and d['candidate']=='68e180a5b122ad08dd2115f90803b808e1c521874a8e7084157c94e730b1a0d2' and d['origin']=='http://127.0.0.1:35249' and d['session']=='e973ca7c-928b-405d-bc4c-5be8051985f9')
check('run provenance','owned clean-seeds and cleanup reports',raw('final-clean-seeds')['cleaned'] is True and raw('final-owned-cleanup')['status']=='PASS')
d=json.loads((P/'independent-owned-disposal.json').read_text());a=json.loads((P/'public-provider-allocation.json').read_text());t=json.loads((P/'owned-disposal-targets.json').read_text());ids=json.loads((P/'owned-process-identities.json').read_text())
check('disposal records','same exact project/container IDs',d['project']==a['project']==t['project'] and set(a['container_ids'])=={c['id'] for c in t['containers']})
for c in t['containers']:
    proof=[cmd for cmd in d['commands'] if cmd['argv'][:3]==['docker','container','inspect'] and cmd['argv'][-1]==c['id']]
    check('disposal records','container '+c['id'],len(proof)==1 and proof[0]['exit']!=0 and 'no such container' in proof[0]['stderr'].lower())
volumes={m['name'] for c in t['containers'] for m in c['volumes'] if m['type']=='volume'}
for v in volumes:
    proof=[cmd for cmd in d['commands'] if cmd['argv'][:3]==['docker','volume','inspect'] and cmd['argv'][-1]==v]
    check('disposal records','volume '+v,len(proof)==1 and proof[0]['exit']!=0 and 'no such volume' in proof[0]['stderr'].lower())
for cmd in [x for x in d['commands'] if x['argv'][:2]==['docker','ps'] or x['argv'][:3]==['docker','volume','ls']]:check('disposal records','project filtered empty '+str(cmd['argv']),cmd['exit']==0 and cmd['stdout'].strip()=='')
expected_ports={**a['ports'],'app':35249,'control':33763}
check('disposal records','exact ports set',{v['name']:v['port'] for v in d['ports']}==expected_ports)
for port in d['ports']:check('disposal records','refused '+port['name'],port['connectExit']!=0)
for proc in d['processes']:check('disposal records','recorded PID '+proc['name'],proc['pid']==ids['processes'][proc['name']]['pid'] and proc['status']=='absent' and proc['ownedProcessAlive'] is False)
check('disposal records','exact private session and marked exclusiveTMPDIR',d['privateSessionAbsent']==ids['privateSessionPath']==a['session'] and d['exclusiveTMPDIR']=={'path':'/home/waffleflops/.cache/d12f-c09rr52s','ownershipMarkerVerified':True,'removed':True,'absent':True})
# Failed guarded follow-up exits on the first absent-volume inspect, before rm.
check('retained failure','volume guard stopped before mutation',json.loads((P/'owned-volume-residue-cleanup-command.json').read_text())['exit']==1 and 'line 19' in (P/'owned-volume-residue-cleanup.stderr').read_text() and 'assert r.returncode == 0' in (P/'owned-volume-residue-cleanup.stderr').read_text() and not (P/'owned-volume-residue-cleanup.json').exists())
for label in ['loss-first-personnel-entry','loss-first-home-entry','literal-observation-check','independent-owned-disposal','independent-owned-disposal-after-volume-cleanup']:
    c=json.loads((P/(label+'-command.json')).read_text());check('retained failure',label+' preserved failed original',c['exit']!=0)
counts=Counter(x['category'] for x in checks)
nonproduct={'run provenance','disposal records','retained failure'}
result={'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL','source':'a200c7b8936b2abcb4105cbebd4ad7789e8e6413','base':'e674edcf0204e9a4e2e15a19d747cdd33c33a47c','artifactRoot':str(P),'totalOrdinaryComparisons':len(checks),'productObservationComparisons':sum(v for k,v in counts.items() if k not in nonproduct),'provenanceDisposalFailureComparisons':sum(v for k,v in counts.items() if k in nonproduct),'categoryCounts':dict(counts),'fullEventRowComparisons':row_comparisons,'all28PNGVisuallyInspected':True,'limits':['Artifact review only; no independent live execution or model diversity','No native acknowledgement toggle/badge, injected server lane outage, latest Rating-choice or performance claim','Exact180-day public projection belongs to accepted original baseline/default byte applicability, not fresh final window read','Metadata-only documents do not prove Storage bytes','TMPDIR allocation/removal proves no inode-exhaustion product cause','Full publication diff/DoD-CI/bots/authorized merge remain gates'],'checks':checks}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
print('FAILED',json.dumps([x for x in checks if not x['pass']],indent=2))
