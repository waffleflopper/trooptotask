"""Read only exact owned worker identities before launch disposal and after cleanup."""
import importlib.util,json,os,re,subprocess,sys
from pathlib import Path
run=os.environ.get('D15_CLOSING_RUN','');mode=sys.argv[1]
if run not in ('baseline','final') or mode not in ('before','after'):raise ValueError('Explicit run/mode')
root=Path.cwd();e=root/'.verification/evidence/verify-trooptotask'/f'd15-closing-verification-{run}-native'
spec=importlib.util.spec_from_file_location('owned',root/'scripts/verification/environment.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def require(value,message):
 if not value:raise ValueError(message)
commands=[]
def docker(args,env):
 r=subprocess.run(['docker',*args],env=env,text=True,capture_output=True)
 commands.append({'argv':['docker',*args],'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 return r
if mode=='before':
 session=Path(json.loads((e/'info.json').read_text())['session']);m.private_session(session);state,workdir,env=m.owned(session)
 require(state['repository']==str(root) and session.name=='worker-1','Foreign worker')
 owned=json.loads((session/'session.json').read_text());require(owned['phase']=='running','Worker not running')
 records=m.containers(state,workdir,env);require(bool(records),'No provider')
 volumes=docker(['volume','ls','--filter',f'name={state["project"]}','--format','{{.Name}}'],env);require(volumes.returncode==0,'Volume inventory failed')
 networks=docker(['network','ls','--filter',f'name={state["project"]}','--no-trunc','--format','{{.ID}} {{.Name}}'],env);require(networks.returncode==0,'Network inventory failed')
 volumes=[n for n in volumes.stdout.splitlines() if n.endswith('_'+state['project'])]
 networks=[{'id':line.split(' ',1)[0],'name':line.split(' ',1)[1]} for line in networks.stdout.splitlines() if line.split(' ',1)[1].endswith('_'+state['project'])]
 result={'project':state['project'],'sessionDirectory':str(session),'dockerHost':env['DOCKER_HOST'],'worker':1,'supervisor':owned['supervisor'],'containers':[{'id':r['Id'],'name':r['Name'].lstrip('/')} for r in records],'volumes':volumes,'networks':networks,'status':'PASS'}
else:
 before=json.loads((e/'resources-before.json').read_text());session=Path(before['sessionDirectory']);require(not session.exists(),'Private directory remains')
 env=m.load_database(root).clean_environment()
 for key in ('DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(key,None)
 require(before['dockerHost'].startswith('unix:///'),'Nonlocal Docker endpoint');env['DOCKER_HOST']=before['dockerHost']
 for c in before['containers']:
  r=docker(['container','inspect',c['id']],env);require(r.returncode==1 and 'No such container' in r.stderr,'Container absence not established')
 for name in before['volumes']:
  r=docker(['volume','inspect',name],env);require(r.returncode==1 and 'no such volume' in r.stderr.lower(),'Volume absence not established')
 for n in before['networks']:
  r=docker(['network','inspect',n['id']],env);require(r.returncode==1 and 'not found' in r.stderr.lower(),'Network absence not established')
 identity=before['supervisor'];proc=Path('/proc')/str(identity['pid'])
 same=False
 if proc.exists():
  stat=(proc/'stat').read_text();same=stat[stat.rfind(')')+2:].split()[19]==identity['start'] and (proc/'cmdline').read_text()==identity['command']
 require(not same,'Original supervisor remains')
 result={'project':before['project'],'worker':1,'status':'PASS','privateDirectoryAbsent':True,'originalSupervisorIdentityAbsent':True,'containerIds':[c['id'] for c in before['containers']],'volumeNames':before['volumes'],'networkIds':[n['id'] for n in before['networks']]}
result['dockerCommands']=commands
with (e/f'resources-{mode}.json').open('x') as f:json.dump(result,f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ('supervisor','dockerCommands')}))
