import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import ExcelJS from 'exceljs';

const root = path.dirname(new URL(import.meta.url).pathname);
const fixture = JSON.parse(await fs.readFile(path.join(root, 'final/fixture.json'), 'utf8'));
const headers = ['Name', 'Rank', 'Group', 'Verification Required Training', 'Verification Targeted Training', 'Verification Optional Training (completion only)'];
const able = ['Able, Synthetic', 'SPC', 'Alpha', fixture.dates.trainingCompleted, 'missing', 'not required'];
const baker = ['Baker, Synthetic', 'SPC', 'Bravo', 'missing', 'not required', 'not required'];
const unassigned = ['Unassigned, Synthetic', 'SPC', 'Unassigned', 'missing', 'not required', 'not required'];

async function matrix(name, expectedRows) {
	const workbook = new ExcelJS.Workbook();
	await workbook.xlsx.readFile(path.join(root, 'final', name));
	assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Training Matrix']);
	const sheet = workbook.getWorksheet('Training Matrix');
	assert.deepEqual(sheet.getRow(1).values.slice(1), headers);
	assert.deepEqual(sheet.getRows(2, sheet.rowCount - 1).map((row) => row.values.slice(1)), expectedRows);
}

await matrix('matrix-default.xlsx', [able, baker, unassigned]);
await matrix('matrix-focus.xlsx', [able, baker, unassigned]);
await matrix('matrix-alpha.xlsx', [able]);
await matrix('matrix-scoped.xlsx', [able]);
for (const name of ['baseline/report.xlsx', 'final/report.xlsx']) {
	const workbook = new ExcelJS.Workbook();
	await workbook.xlsx.readFile(path.join(root, name));
	assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Summary', 'Forecast', 'Hot spots', 'Focus', 'Requirements']);
	const summary = new Map(workbook.getWorksheet('Summary').getRows(2, 24).map((row) => [row.getCell(1).value, row.getCell(2).value]));
	assert.equal(summary.get('Soldiers'), 3);
	assert.equal(summary.get('Ready today (%)'), 25);
	assert.equal(summary.get('Applicable requirements'), 4);
}
console.log('PASS. Downloaded matrix rows, all-column exports, Group scope, and report workbooks match independent fixture expectations.');
