# D29 / #1377 live baseline — unchanged app at 1466dac0

- Revision: 1466dac0c287d7853bdb8af2953893653adbf305 (detached, clean)
- Candidate digest: ca6c4827b8aa4c12b27aba6bf87287c45b10111a8016a1b5522fa812f45970e5
- Origin: http://127.0.0.1:46191 (worker 1, session 827a314f-1652-4458-990b-600627c6fd9b)
- Browser: Chromium 152.0.7977.82 Arch Linux
- Fixture date (ui): 2026-10-07; host local offset -08:00
- Started ~2026-10-07T21:24-08:00; driving finished ~2026-10-07T22:00-08:00

All paths below are **live-verified** unless marked otherwise.

## 1. Account profile rank (viewer)
- Rank select: `Select rank` + 28 options in exact order PV1, PV2, PFC, SPC, CPL, SGT, SSG, SFC, MSG, 1SG, SGM, CSM, WO1, CW2, CW3, CW4, CW5, 2LT, 1LT, CPT, MAJ, LTC, COL, BG, MG, LTG, GEN, CIV. Helper text: "This account-level rank uses the registration rank list and is not connected to any Organization rank catalog."
- Original: first/last name empty, rank empty. Filled Synthetic/Viewer, chose SFC, Save Profile -> inline "Profile updated"; reload shows SFC.
- Restore: original rank did not exist; choosing "Select rank" is blocked by native validation ("Please select an item in the list."). Viewer profile remains Synthetic/Viewer/SFC until worker disposal. Recipe requires restoration only when a rank existed.

## 2. Evals type by rank (ratingOperate)
- Officer (1LT) -> "OER (Officer)"; Warrant (CW2) -> "WOER (Warrant Officer)"; NCO (SSG) -> "NCOER (NCO)". Cancel each; rated_person rows unchanged (2/1/2); A total 9.

## 3. Sign-in roster (rosterManager)
- Rank filter chips offered: All Officers, All Warrant, All Enlisted (default pressed), Civilians, SGT, SPC, PFC, VFY-ACTIVE-A.
- Created "D29 Baseline Roster 1466dac0" (SPC, Alpha, By rank, Separate by group), id 8f486f4f-d2f8-442c-a5bb-6a0e8c0c8f71. Generated PDF 4286 B, filename null in Blob capture (no download anchor name), sha256 b144a7a0...; text: title, Date: October 7, 2026, #/Rank/Name/Signature, Alpha, 1 SPC Able, Synthetic. POST 200.
- Scan upload POST 200; signed_file_path cc5d252e-.../sign-in-rosters/8f486f4f-.../b35d6cc2-...-signed-scan.pdf (bucket counseling-files per opened URL host path). Persisted after reload. signed-download 3186 B sha256 46119627... == uploaded input; roster-files same.
- Deleted through visible Delete -> confirm; after reload 3 total, row count 0, roster-files [].

## 4. Counseling PDF (manager, seeded MapLifecycle02e1c79d person 5bd53ad4-...)
- arm-fail collection POST -> 503, "Unable to upload counseling PDF.", draft/title/summary/file retained, still 2 counseling rows.
- Retry POST 200 -> row 8337b8ef-c289-4e7f-b254-cb70e29005c8, file_path cc5d252e-.../counseling-records/5bd53ad4-.../fd77404f-...-counseling.pdf, bucket counseling-files, 3185 B, sha256 503e17e9... == input. Form cleared after success. Card persisted after reload. No Open/download control on counseling card (documented recipe behavior).
- Cleanup: Archive -> Archived tab -> Delete; row absent, recorded file present:false.

## 5. Bulk status import (calendarOperate)
- Missing row: "Person not found"; reversed dates: "End date must be on or after start date"; 0 of 2 selected; 0 rows for both notes.
- duplicate-able seed: "Multiple people with this name — add Rank column to disambiguate"; 0 rows. clean-seeds.
- Valid import: 1 of 1 selected, Next -> "Import complete", "1 status entry imported successfully."; batch POST 200 count 1; row 4888a032-... Able/Leave/2026-10-14; persisted after Done+reload.
- Removed via Remove tab (Leave, Able, Oct 14; "1 exact match will be removed") -> 0 rows; seeded Able rows retained.

## 6a. Organization export (orgOwner)
- JSON POST 200, org-export-<orgA>-2026-10-08.json, application/json, 159582 B, sha256 c7449bd0...; top-level keys recorded in json-inspect.txt; 38 sections.
- Excel POST 200, org-export-<orgA>-2026-10-08.xlsx, 67981 B, sha256 28de5eb4...; 57 sheets; Export Inventory 38 rows.
- data_exports: 2 completed rows, sizes 159582 / 67981, same after reload; B 0. No toast captured by feedback observer for either download.

## 6b. Archives export (orgOwner, personnel-lifecycle archivedDuplicate 09ec242f-...)
- GET 200; Blob filename SPC-MapDuplicate02e1c79d-records.xlsx, 9314 B, sha256 87bb7150...; server Content-Disposition filename SPC_MapDuplicate02e1c79d_Synthetic-export-2026-10-08.xlsx (client name differs, recorded).
- Sheets: Personnel Info, Training Records, Counseling Records, Availability History. Personnel Info matches provider row (SPC, MapDuplicate02e1c79d, Synthetic, 68W, Medic, Alpha, blank ETS/DEROS, Archived At 2026-08-01T12:00:00+00:00).

## 6c. Training report (trainingConfigure)
- GET 200 training-report-2026-10-07.xlsx, 11767 B, sha256 74ff0a84...; sheets exactly Summary, Forecast, Hot spots, Focus, Requirements. Summary 25% ready, Ready 1, expired 0, not recorded 3, lapse 0, goal 90; Requirements 3 Not Done rows.

## 7. Calendar access
- Range 2026-09-14..16, all 200: calendarLane Alpha/Bravo/Unassigned IDs present; calendarScoped Alpha only; calendarEmpty none; foreign IDs/status absent for all. Visible September pages match.
- Writes (single+batch): calendarView->Able 403/403; manager->Able 403/403; calendarScoped->Baker 403/403; ->Unassigned 403/403; calendarEmpty->Able 403/403; calendarLane->B Foreign 404/404 "Organization not found". Zero marker rows in A and B. A availability IDs/fields identical to pre-case export; B count 1.

## Cleanup
- All export/network/feedback controls restored after each use; clean-seeds after cases 2, 6b, 5 (x2) and final; UI-created roster, counseling and availability row removed visibly.
