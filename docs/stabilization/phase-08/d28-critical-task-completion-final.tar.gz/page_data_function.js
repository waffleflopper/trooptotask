async () => {
  const url = location.pathname.replace(/\/$/, '') + '/__data.json';
  const response = await fetch(url);
  const raw = await response.text();
  const credentialNames = ['access_token', 'refresh_token', 'provider_token', 'provider_refresh_token', 'accessToken', 'refreshToken'];
  let redactedSlots = 0;
  const records = raw.split('\n').filter(Boolean).map(line => JSON.parse(line));
  const scrubTable = table => {
    for (const value of table) {
      if (!value || Array.isArray(value) || typeof value !== 'object') continue;
      for (const key of credentialNames) {
        if (!(key in value)) continue;
        const index = value[key];
        if (Number.isInteger(index) && index >= 0 && index < table.length) table[index] = '[REDACTED credential]';
        else value[key] = '[REDACTED credential]';
        redactedSlots++;
      }
    }
    for (let index = 0; index < table.length; index++) {
      if (typeof table[index] === 'string') table[index] = table[index].replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, '[REDACTED JWT]');
    }
  };
  for (const record of records) {
    if (Array.isArray(record.data)) scrubTable(record.data);
    for (const node of record.nodes ?? []) if (Array.isArray(node?.data)) scrubTable(node.data);
  }
  return { path: url, status: response.status, redactedSlots, records };
}
