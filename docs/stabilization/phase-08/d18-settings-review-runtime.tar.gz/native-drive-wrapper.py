import sys
sys.path.insert(0,'.verification');import d18_ui as v

def uid(line): return line.split('uid=')[1].split()[0]
def click(name,label,resource=None):
 s=v.snap(name+'-before',4)
 if resource:
  s=s.split('StaticText "'+resource+'"',1)[1]
  s=s.split('StaticText "Final review ',1)[0]
 lines=[l for l in s.splitlines() if label in l]
 assert lines,(name,label,s)
 return v.tool(name,'click',pageId=4,uid=uid(lines[0]))
def fill(name,value):
 s=v.snap(name+'-before',4)
 line=next(l for l in s.splitlines() if 'textbox "Denial reason"' in l)
 return v.tool(name,'fill',pageId=4,uid=uid(line),value=value)
