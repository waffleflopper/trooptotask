# Independent source review of the #1504 print-control correction

The original P2 publication finding is resolved in the pinned correction. I found no concrete residual source defect in this bounded round. This accepts the source correction; native browser runtime support remains **UNRUN**, and this report does not accept the complete #1504 application or its printed appearance.

I performed independent read-only source review. I did not run tests, gates, a browser, services, database operations, connectors, or nested workers. The test results below are root's evidence, inspected as logs rather than independently executed. No model-diversity, live-execution, visual, or rendered-PDF claim is made.

## Candidate and scope

The original reviewed control was committed at `bf7640d735200b48ccd44bea0b994b1789d30cf9`. During this round the correction became committed in `fedded058b7cd74d31cd54ffbb26f554467bee9b`. I inspected the actual two-file diff from the original commit, the surrounding capture/publication/cleanup code, and the added tests. The following byte hashes were checked again after the commit; they match the correction receipt and the source inspected earlier in this round. No formatter change altered these reviewed bytes.

| File | SHA-256 |
| --- | --- |
| `scripts/verification/print-capture.mjs` | `820e041e5dcab48d98f119cc66dc12cd6710a1291960e99fdce9634412ce7f73` |
| `scripts/verification/print-capture.test.mjs` | `2073c15b6ccd1e454178616dac3b045ddf1a45b0c6452604a06bc54a84770a3c` |
| `.agents/skills/verify-trooptotask/SKILL.md` | `7b8c727ed99c1b14c7274a388b261d09db5cc065e30f9ad55e7b6ea5065b2869` |
| `.agents/skills/verify-trooptotask/helpers/control.mjs` | `d426c720af9eed040bbd4827352303e471c576792cf5adfecdd7f02a46af1bda` |
| `.agents/skills/verify-trooptotask/helpers/print-observation.mjs` | `05885ab449dc9b15805f159896234890762e2b25770c9e708b675e09a5db0489` |
| `.agents/skills/verify-trooptotask/helpers/print-observation.test.mjs` | `e9a3c9bb5c9ce486d200beae84e7b1a05f4cfa6dd867cc5d891d904c53b2b509` |
| `scripts/verification/daemon.mjs` | `c28b1e68f74fb4481fe80c09f2d31bdd35f59026e36ece87e68bbd6619f72510` |

The semantic scope is one publication repair and two regression tests. The other five control files are byte-identical to the original reviewed candidate. Their direct/reverse daemon, core, native browser, and helper consumers and installed native MCP transport/schema conclusions remain those documented in [the v1 source report](1504-independent-print-control-review-v1.md). Application changes in the containing commit and T3 Claude's print CSS/component work are outside this lane.

I used the original control brief, grounding, implementation claims, and v1 finding, then checked the actual correction against `.verification/1504-print-publication-correction.json`, the red reproduction log, and the final green log. This report is the only file written in this round.

## Resolution of the P2 publication race

The original failure was a PASS receipt for the old lexical output path after the output directory was renamed/recreated during the awaited final document observation. The pinned descriptor still referenced the moved directory, so the accepted PDF could be missing from the returned path and located outside the admitted evidence root.

The correction addresses both the known timing window and publication settlement:

1. `print-capture.mjs:309` retains the open directory descriptor's device/inode. The local check at line 310 compares the current lexical parent's canonical path/device/inode with that pinned identity.
2. The final `checkDocument()` is awaited at line 319. Parent validation now follows it at line 320, before linking. Relocation during that awaited observation therefore rejects before publication.
3. The no-overwrite hard link is awaited at line 323. Parent validation runs again at line 324. Relocation while the link settles rejects with `succeeded` still false.
4. Lines 325–328 inspect the actual requested final path with `lstat`, require a regular file, and compare its device/inode with the operation's temporary file. Acceptance at line 330 follows those checks and the deadline check. An unrelated replacement file or final-path symlink cannot satisfy the accepted-file identity check.

Failure cleanup at lines 345–354 still operates through the pinned descriptor. It removes the unaccepted published link only when its device/inode matches the operation-owned partial file, then removes the partial and closes the directory handle. It does not unlink the replacement directory's lexical target. If an unrelated target already exists in the pinned directory, hard-link creation fails without overwriting it, and the cleanup identity comparison prevents removing it.

This is the minimal correction requested in v1: validation after the asynchronous document boundary, validation after link settlement, final-path identity before success, and cleanup confined to owned artifacts. The original P2 is **resolved**.

## Regression evidence and test adequacy

The test at `print-capture.test.mjs:287` performs a real directory rename/recreation during the final document observation, after a real partial file exists. The document response remains unchanged. It requires a `PRINT_PATH` rejection, an empty moved directory, and exact literal witness bytes retained in the replacement directory. It also checks temporary-client disconnection and removal of page listeners.

The test at `print-capture.test.mjs:313` wraps the filesystem adapter at link settlement. It first performs the real hard link, then moves/recreates the directory and writes a literal replacement PDF at the returned lexical target. Capture must reject, remove its partial and unaccepted linked PDF from the moved pinned directory, and preserve the replacement PDF's exact bytes. This exercises actual filesystem effects at a controlled boundary; it does not merely assert that a validator was called.

Root's `.verification/1504-print-publication-red.log` contains 15 tests with one failure: the first new case reports `Missing expected rejection.` against the original implementation. Root's `.verification/1504-print-publication-final-green.log` contains 16 passing tests, including both new cases. The receipt pins the same two corrected source hashes shown above. These establish a meaningful reported red/green regression for the accepted finding. I inspected the logs and source; I did not independently execute the suite.

The existing tests continue to cover literal output bytes/hash and retained preexisting bytes, target admission and ownership failures, oversized/incomplete streams, late read settlement after timeout, changed documents after partial creation, and observer event behavior. No geometry, incidental copy, source-scanner, or implementation-mirroring assertion was added. Controlled protocol fixtures still cannot establish actual Chromium rendering or native-client continuity.

## Full control boundaries retained

| Requirement | Scoped source conclusion |
| --- | --- |
| Ownership and private transport | The repair does not change recorded PID/start/full-command checks, exact private profile, canonical profile identity, derived loopback endpoint, or socket-listener ownership. Caller-supplied endpoints remain excluded. |
| Native page mapping and document identity | Structured native page records still require the requested safe integer ID and exactly one exact full URL. The temporary client independently requires one live exact-URL page. URL, complete ready state, time origin, closure, main-frame navigation, and repeated uniqueness checks remain in place. |
| Narrow capture inputs | Only page ID, exact admitted report URL, and evidence PDF path are accepted beyond the command. Protocol/script/media/format inputs remain fixed internally. No persistent print/media emulation is introduced. |
| Stream and deadline | Protocol/font work remains bounded by the single capture clock; stream size remains capped at 20 MiB with PDF header/EOF checks. Late protocol settlement cannot resume the main continuation and publish after rejection. |
| Filesystem effects | Static traversal, symlink parents, existing output, exclusive mode-0600 partial creation, no-overwrite linking, and pinned cleanup remain. The repaired acceptance now checks both current parent and actual final file identity. |
| Native resource preservation | Capture still closes its stream, detaches its temporary CDP session, and disconnects its temporary client. It does not close the native page/browser or signal its processes. Late connection/session settlement handlers remain unchanged. |
| Print observer and daemon | The observer remains fixed private beforeprint/afterprint listeners, without assigning or invoking `window.print`. The native click/event evidence must precede PDF capture. Authenticated serialized daemon admission, current-candidate checks, and sanitized INCONCLUSIVE failure reporting remain unchanged. |

The installed `chrome-devtools-mcp` 1.10.1 source inspected in v1 supports the proposed `chromeArg` array and actual port-versus-pipe launch selection, `structuredContent.pages` native ID records, fixed evaluation response parsing, and temporary detachment/disconnection behavior. The correction changes none of these integration assumptions. These remain static source support conclusions, not runtime proof.

## Delayed settlement, cleanup, and remaining evidence

Publication awaits `fs.link` directly. A delayed link cannot publish in a detached continuation after capture has already completed: once it settles, parent/final-file validation and the clock check occur before `succeeded`. If the deadline elapsed, the operation remains unaccepted and its pinned owned link/partial are eligible for failure cleanup. The added post-link relocation test exercises cleanup after actual link creation.

Filesystem metadata/link/unlink operations are not independently timeboxed or cancellable. As already stated in v1, the protocol deadline and two-second protocol-cleanup race do not prove a complete wall-clock bound for a hung local filesystem. Filesystem cleanup is awaited before protocol cleanup. The new tests do not inject a hung filesystem or prove every native late-settlement resource effect. I found no new concrete regression in these unchanged limitations, and do not treat a hypothetical indefinitely stalled filesystem as evidence that the resolved directory-publication finding remains open.

Runtime support remains **UNRUN**. Root still owns fresh native port-transport launch and profile/listener verification, actual native page-ID/full-URL routing, accepted/rejected live capture cases, native controls after temporary-client detachment, and pre-capture Print brief click/event evidence. A known print-only/screen-only text fixture can prove actual print rendering. T3 Claude owns app appearance and CSS/PDF visual acceptance. Root's full gates and any later live verification are outside this report's execution claims.

The clean verdict is limited to the pinned print-control source and its publication correction. It adds no merge, deployment, remote-database, or release authority. It does not supersede application acceptance or independent visual review.
