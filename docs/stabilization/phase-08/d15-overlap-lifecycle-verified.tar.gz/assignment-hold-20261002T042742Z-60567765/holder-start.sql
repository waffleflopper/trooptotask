SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.personnel_onboardings
WHERE organization_id = 'a4507cd3-e62c-4471-8ed8-effe4abacf5a'::uuid AND id = 'bf401b95-b8d8-4c5c-8e41-fa6d61f14ca8'::uuid AND personnel_id = '64960f87-4330-464e-b414-5d189be8ca6d'::uuid AND template_id IS NULL AND status = 'in_progress' AND completed_at IS NULL AND cancelled_at IS NULL
FOR UPDATE;
SELECT json_build_object('event', 'ready');
