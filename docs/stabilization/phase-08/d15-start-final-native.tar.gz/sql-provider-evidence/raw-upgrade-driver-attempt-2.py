import hashlib,importlib.util,json,shutil,subprocess,tempfile,tomllib
from pathlib import Path
repo=Path.cwd();proof=repo/'.verification/tmp/start-sql'
spec=importlib.util.spec_from_file_location('db',repo/'scripts/ci/database.py');db=importlib.util.module_from_spec(spec);spec.loader.exec_module(db)
source_manifest=json.loads((proof/'source-manifest.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==source_manifest['head']
def frozen():return {f['path']:hashlib.sha256((repo/f['path']).read_bytes()).hexdigest() for f in source_manifest['files']}
before_hashes=frozen();source=tomllib.loads((repo/'supabase/config.toml').read_text());reserved=db.reserve_ports(len(list(db.port_fields(source))));work=Path(tempfile.mkdtemp(prefix='t2t-ci-db-start-upgrade-'));project=work.name;container='supabase_db_'+project;runner='supabase_pgprove_'+project;env=db.local_docker_environment(repo);started=False;runner_started=False
metadata={'project_id':project,'directory':str(work),'container':container,'source_base':source_manifest['base'],'source_head':head,'source_hashes':before_hashes,'result':'IN_PROGRESS'}
try:
 ports=[s.getsockname()[1] for s in reserved];cfg=db.prepare_project(repo,work,project,ports);metadata['ports']={'.'.join(f):p for f,p in zip(db.port_fields(cfg),ports)};metadata['seed']=cfg['db']['seed']
 name='20261002001100_atomic_onboarding_start.sql';(work/'supabase/migrations'/name).unlink();m=sorted((work/'supabase/migrations').glob('*.sql'));metadata['initial_chain']={'count':len(m),'first':m[0].name,'last':m[-1].name};assert len(m)==162;print(json.dumps(metadata),flush=True)
 def execute(command,**kwargs):return db.run(command,work,environment=env,**kwargs)
 execute(['supabase','--version'])
 for s in reserved:s.close()
 started=True;execute(['supabase','start','--exclude',db.EXCLUDED_SERVICES],quiet=True)
 psql=['docker','exec','-e','PGPASSWORD=postgres',container,'psql','-X','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
 execute([*psql,'-c','SHOW server_version;','-c',"ALTER SYSTEM SET supautils.hint_roles = '';",'-c','SELECT pg_reload_conf();'])
 execute([*psql[:2],'-i',*psql[2:]],input_text=(repo/'supabase/migration-tests/onboarding_start_before.sql').read_text())
 tables=['personnel','organization_memberships','onboarding_templates','onboarding_template_steps','training_types','personnel_trainings','personnel_onboardings','onboarding_step_progress'];rows=' UNION ALL '.join("SELECT '%s'::text table_name,%s row_id,to_jsonb(p) row_data FROM public.%s p WHERE organization_id IN ('d1508000-0000-4000-8000-000000000101','d1508000-0000-4000-8000-000000000102')"%(t,"organization_id::text||'/'||user_id::text" if t=='organization_memberships' else 'id::text',t) for t in tables)
 def capture(query,path):
  result=execute([*psql,'-qAt','-c',query],quiet=True);value=json.loads(result.stdout);(proof/path).write_text(json.dumps(value,indent=2)+'\n');return value
 assert capture("SELECT to_jsonb(to_regprocedure('public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)') IS NULL)",'raw-upgrade-function-absent.json') is True
 row_query="SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY table_name,row_id),'[]') FROM ("+rows+") s"
 before=capture(row_query,'raw-upgrade-before-rows.json');stored=capture("SELECT jsonb_agg(to_jsonb(s) ORDER BY table_name,row_id) FROM upgrade_fixture.onboarding_start_before s",'raw-upgrade-fixture-rows.json');assert before==stored and len(before)==45
 shutil.copy2(repo/'supabase/migrations'/name,work/'supabase/migrations'/name);execute(['supabase','migration','up','--local','--yes','--include-all'])
 after=capture(row_query,'raw-upgrade-after-rows.json');assert after==before
 metadata['populated_rows']=len(before);metadata['every_field_and_row_set_unchanged']=after==before
 capture("SELECT jsonb_build_object('name',p.oid::regprocedure::text,'volatility',p.provolatile,'security_definer',p.prosecdef,'settings',p.proconfig,'argnames',p.proargnames,'authenticated_execute',has_function_privilege('authenticated',p.oid,'EXECUTE'),'anon_execute',has_function_privilege('anon',p.oid,'EXECUTE'),'service_role_execute',has_function_privilege('service_role',p.oid,'EXECUTE'),'public_grant',EXISTS(SELECT 1 FROM aclexplode(p.proacl) a WHERE a.grantee=0),'active_index',pg_get_indexdef('public.personnel_onboardings_active_idx'::regclass)) FROM pg_proc p WHERE p.oid='public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)'::regprocedure",'raw-upgrade-function-metadata.json')
 runner_started=True;execute(['docker','run','--rm','--name',runner,'--network','supabase_network_'+project,'--mount',f'type=bind,src={work / "supabase"},dst=/tests,readonly','-e','PGHOST=db','-e','PGPORT=5432','-e','PGUSER=postgres','-e','PGPASSWORD=postgres','-e','PGDATABASE=postgres',db.PG_PROVE_IMAGE,'pg_prove','--verbose','/tests/migration-tests/onboarding_start_after.sql'])
 provider=db._provider_environment(repo,work,lambda command,workdir,**kwargs:db.run(command,workdir,environment=env,**kwargs));db.run(['node',str(repo/'scripts/ci/onboarding_start_provider_probe.mjs')],work,environment=provider)
 final=capture(row_query,'raw-upgrade-after-contracts-rows.json');assert final==before
 metadata['result']='PASS';metadata['final_chain_count']=163
except BaseException as error:
 metadata['result']='FAIL';metadata['error_kind']=type(error).__name__;metadata['error']=str(error);raise
finally:
 for s in reserved:s.close()
 if runner_started:db.run(['docker','rm','--force',runner],work,environment=env,quiet=True,check=False)
 if started:db.run(['supabase','stop','--project-id',project,'--no-backup'],work,environment=env)
 shutil.rmtree(work)
 remaining={kind:[n for n in subprocess.check_output(command,env=env,text=True).splitlines() if n.endswith('_'+project) or n==project] for kind,command in [('containers',['docker','ps','-a','--format','{{.Names}}']),('networks',['docker','network','ls','--format','{{.Name}}']),('volumes',['docker','volume','ls','--format','{{.Name}}'])]}
 metadata['cleanup']={'directory_absent':not work.exists(),'remaining_owned_resources':remaining};metadata['inputs_unchanged']=before_hashes==frozen();(proof/'raw-upgrade-result.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata),flush=True);assert metadata['inputs_unchanged'] and not any(remaining.values()) and not work.exists()
