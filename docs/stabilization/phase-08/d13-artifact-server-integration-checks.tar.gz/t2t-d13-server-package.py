from pathlib import Path
import hashlib,json,tarfile,tempfile,re

base=Path.cwd()
evidence=base/'.verification/evidence/verify-trooptotask'
output=base/'docs/stabilization/phase-08'
scratch=Path(tempfile.mkdtemp(prefix='d13-server-package-',dir=evidence))
reports=[]
sha=lambda data:hashlib.sha256(data).hexdigest()
for name in ['integration-checks','final-native']:
 source=evidence/('d13-artifact-server-'+name)
 staged=scratch/(name+'-staged');expanded=scratch/(name+'-expanded')
 staged.mkdir();expanded.mkdir()
 originals={};redactions=[]
 for f in sorted(source.rglob('*')):
  if f.is_symlink():raise RuntimeError('Symlink forbidden: '+str(f))
  if not f.is_file():continue
  rel=str(f.relative_to(source));dest=staged/rel
  dest.parent.mkdir(parents=True,exist_ok=True)
  data=f.read_bytes();originals[rel]=sha(data)
  if f.suffix.lower() not in ['.pdf','.png','.xlsx','.gz']:
   try:s=data.decode('utf-8')
   except UnicodeDecodeError:raise RuntimeError('Unexpected non-text: '+rel)
   s,n1=re.subn(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b','[REDACTED]',s)
   s,n2=re.subn(r'([?&#](?:amp;)?(?:token|access_token|refresh_token|signature|x-amz-signature|x-amz-credential)=)(?!\[REDACTED\])[^&#\s"\'<>]+',r'\1[REDACTED]',s,flags=re.I)
   s,n3=re.subn(r'(authorization[\"\s:]*Bearer\s+)[^\s"\'<>]+',r'\1[REDACTED]',s,flags=re.I)
   if n1+n2+n3:
    data=s.encode();redactions.append({'path':rel,'originalSha256':originals[rel],'sanitizedSha256':sha(data),'jwt':n1,'queryToken':n2,'bearer':n3})
   if re.search(r'"(?:password|authorization|cookie|service_role_key|api_key)"\s*:\s*"(?!\[REDACTED\]|"|synthetic|unused)[^"\n]{8,}"',s,re.I):
    raise RuntimeError('Review suspected secret field: '+rel)
  dest.write_bytes(data)
 (staged/'PACKAGING_REDACTIONS.md').write_text('Packaging follows final doctor and owned cleanup. Public synthetic Organization/Person/contributor IDs, complete row fields and recorded file paths remain visible. Binary inputs, PDF downloads and screenshots are exact. Only token values are sanitized; all other original payload bytes are unchanged. Historical failed or inconclusive attempts remain explicit. Packaging is not a fresh live run or independent live execution.\n\n'+json.dumps({'redactions':redactions},indent=2)+'\n')
 payloads={str(f.relative_to(staged)):sha(f.read_bytes()) for f in sorted(staged.rglob('*')) if f.is_file()}
 (staged/'ARTIFACT_SHA256SUMS').write_text(''.join(h+'  '+p+'\n' for p,h in payloads.items()))
 archive=output/('d13-artifact-server-'+name+'.tar.gz')
 if archive.exists():raise RuntimeError('Refuse overwrite: '+str(archive))
 with tarfile.open(archive,'w:gz') as t:
  for f in sorted(staged.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(staged)),recursive=False)
 with tarfile.open(archive) as t:t.extractall(expanded,filter='data')
 actual={str(f.relative_to(expanded)):sha(f.read_bytes()) for f in expanded.rglob('*') if f.is_file() and f.name!='ARTIFACT_SHA256SUMS'}
 assert actual==payloads
 altered={x['path'] for x in redactions}
 for p,h in originals.items():
  if p not in altered:assert actual[p]==h
 report={'archive':str(archive.relative_to(base)),'sha256':sha(archive.read_bytes()),'originalFiles':len(originals),'payloadFiles':len(payloads),'payloadBytes':sum(f.stat().st_size for f in staged.rglob('*') if f.is_file() and f.name!='ARTIFACT_SHA256SUMS'),'png':sum(p.endswith('.png') for p in payloads),'redactedFiles':len(altered),'tokenRedactions':sum(x['jwt']+x['queryToken']+x['bearer'] for x in redactions),'redactions':redactions,'exactExpandedSetsHashes':True,'otherOriginalBytesExact':True,'expanded':str(expanded.relative_to(base))}
 reports.append(report)
(scratch/'packaging-verification.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps({'scratch':str(scratch.relative_to(base)),'archives':reports},indent=2))
