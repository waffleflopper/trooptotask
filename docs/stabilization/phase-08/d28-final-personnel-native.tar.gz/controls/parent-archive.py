import current as x
import json
d=x.d;seed=json.loads((x.c/'seed.json').read_text());person=seed['ids']['person'];before=json.loads((d.E/'before-parent-archive-full.json').read_text())['rows']
d.within('parent-archive-confirm','alertdialog','Archive Personnel','button','Archive');d.wire('parent-archive-wire',2,'personnel');after=x.full('parent-archived-full');row=next(r for r in after['orgA']['personnel'] if r['id']==person);event=row['archived_at'];assert event is not None
active=[];history=[]
for table in ['counseling_records','personnel_documents','personnel_follow_ups','leader_notes']:
 for old in before['orgA'][table]:
  new=next(r for r in after['orgA'][table] if r['id']==old['id'])
  if old['personnel_id']==person and old['archived_at'] is None and (table!='personnel_follow_ups' or old['status']=='open'):
   assert new['archived_at']==event;active.append(old['id']);ignore=['archived_at','updated_at']+(['status'] if table=='personnel_follow_ups' else []);assert {k:v for k,v in old.items() if k not in ignore}=={k:v for k,v in new.items() if k not in ignore};
   if table=='personnel_follow_ups':assert new['status']=='archived'
  else:assert new==old;history.append(old['id'])
assert len(active)==8
for org,ts in before.items():
 for table,rs in ts.items():
  if org=='orgA' and table in ['personnel','audit_logs','counseling_records','personnel_documents','personnel_follow_ups','leader_notes']:continue
  assert rs==after[org][table],(org,table)
(x.c/'parent-event.json').write_text(json.dumps({'event':event,'activeIDs':active,'historicalAndSiblingIDs':history},indent=2));d.snap('parent-archived-native');d.act('parent-settings-nav','link','Organization Settings');d.act_prefix('parent-archives-nav','link','Archives');r=d.snap('parent-archives-ready');d.shot('parent-archives');print([(n.get('role'),n.get('name')) for n in d.walk(r['structuredContent']['snapshot']) if n.get('role') in ['row','button','heading']][-30:])
