#!/usr/bin/env bash
# usage: goal.sh VALUE  (page 2 on Organization Settings > Policies); native fill + Save via fresh snapshot UIDs, then privileged readback
source "$(dirname "$0")/t.sh"; v=$1
S goal$v-0; uid=$(grep -m1 'spinbutton "Training readiness goal' $SNAP | sed -E 's/^ *uid=([0-9_]+).*/\1/')
T goal$v-fill fill "{\"pageId\":2,\"uid\":\"$uid\",\"value\":\"$v\"}" | grep -o 'Successfully[^"\\]*'
S goal$v-1; save=$(sed -n '/region "Training Readiness"/,/spinbutton/p' $SNAP | grep -m1 'button "Save"' | sed -E 's/^ *uid=([0-9_]+).*/\1/')
[ -n "$save" ] || save=$(grep -B4 "spinbutton \"Training readiness goal" $SNAP | grep -m1 'button "Save"' | sed -E 's/^ *uid=([0-9_]+).*/\1/')
echo "save uid=$save"; T goal$v-save click "{\"pageId\":2,\"uid\":\"$save\"}" | grep -o 'Successfully[^"\\]*'
sleep 3
S goal$v-2; grep -B2 -A6 'Training readiness goal' $SNAP | head -12
P goal$v
H goal$v-readback rows organizations orgA | grep training_readiness_goal_percent
