# Issue 1501 delegation

The parent coordinated requirements, integration, native browser proof and publication. One exclusive implementation delegate used T3 delegate_task with claudeAgent / claude-opus-5-5 / medium and focused context. No conversation inheritance, database access, services or publication was assigned. The delegate left changes uncommitted. The parent reviewed the actual diff.

## Implementation report

I've implemented all of #1501 on `t3code/triage-1433` and left everything uncommitted. No database, service or browser was touched, and the SQL tests have not been run.

## Behavior changes

**Readiness rule.** Training readiness now counts current, expiring-soon (yellow) and expiring (orange) records as ready. Expired and not-recorded records are not ready. Exempt, not-required and optional types stay out of the count.
- On the current reports page, the post-import fixture goes from 25% to 50%: Alpha 100%, Targeted 100%, Required 33%. Before the import it stays at 25%.
- The readiness-rollup header now says Training and Critical Tasks share the ready rule.
- One extra change you should check: the report's "worst types" list used to count warning states as non-compliant. I changed it to count only expired and not-recorded, so a fully ready type no longer appears there. The current page doesn't display this list, but the API returns it.
- The Dashboard training-current stat and the Personnel readiness lane are unchanged, and their test suites still pass.

**Goal setting.** Settings → Policies has a new third card, `Training Readiness`, with the approved label and help text.
- It saves on its own, like the other two cards.
- The installed Svelte is 5.55.8, and it turns a blank number input into `null`. So the draft is typed `number | null`, and the field is valid only for a whole number from 1 to 100.
- When invalid, the input is marked invalid, the error ("Must be a whole number between 1 and 100.") is linked to it, and Save stays disabled. It uses the shared Field components.
- A failed save keeps the draft. An edit made while a save is pending stays unsaved. Switching Organization still resets the card. The two existing cards are unchanged.

**Server and export.** The server rejects 0, 101, 90.5, `null` and `"90"` with a 400 and writes nothing. The other two fields still round decimals as before. The database reader returns a plain number, and the default of 90 is applied where the Policies data is built. The SDK and in-memory adapters read and write the field, and the save must be confirmed by the database before success. The Organization profile export now includes the goal.

**Migration.** `20261004000100_training_readiness_goal.sql` adds a smallint column, not null, default 90, with a check for 1–100.
- Four SQL test files in `supabase/migration-tests/` follow the existing pattern: `_before` (test data), `_contract`, `_after` and `_fresh`.
- They check that existing rows keep their IDs and values, that existing Organizations read 90, and that 0, 101 and null are rejected while 1 and 100 are accepted.
- They also check access: a member can read but not change the goal, an owner of another Organization can neither read nor change it, and an admin and owner can change it.
- `scripts/ci/database.py` registers these four files: the migration and the before/after files in the staged-upgrade lists, and the fresh file in the fresh-replay list.

## Changed files
- **App:** `src/features/training/utils/reportCalculations.ts`, `src/lib/domain/readinessRollup.ts`, `src/lib/server/adapters/inMemory.ts`, and in `src/features/organization/`: `policyConstraints.ts`, `policiesSettingsTypes.ts`, `policiesSettings.ts`, `policiesSettingsState.svelte.ts`, `PoliciesSettingsSection.svelte`, `PoliciesSettingsPage.svelte`, `settingsTypes.ts`, `settingsProvider.server.ts`, `policy.server.ts` and `rawExport.server.ts`.
- **Tests:**
  - In `src/features/organization/`: `policy.server.test.ts`, `policyProvider.server.test.ts`, `settingsProvider.server.test.ts`, `rawExport.server.test.ts` and `policiesSettingsState.svelte.test.ts`.
  - The Policies page test and the settings API route test.
  - `reportCalculations.test.ts`, `trainingReportsQuery.server.test.ts` and `organizationExport.test.ts`.
- **Docs and verification:**
  - `CONTEXT.md` (Readiness, Readiness goal, Lapse).
  - `docs/domain/retained-feature-rules.md` (new rule, "CSV" → "Excel (xlsx)").
  - Three recipes in `.agents/skills/verify-trooptotask/features/`: `training-completions-reports.md`, `organization-settings-destruction.md` (new goal journey, denial, twelve export fields) and a one-line fix in `critical-tasks-completions-readiness.md`.
  - The verify skill's `SKILL.md`, plus the helpers `settings-request.mjs` (field allowlist) and `control.mjs` (database readback).

## Checks run (Node 24.21.0)
- **Tests:** 142 files and 1,540 tests passed, covering organization, training, the readiness domain, export, the settings and policies routes, the training-report routes, Dashboard and Personnel.
- **Static checks:** `npm run check` reported 0 errors and 0 warnings. ESLint and Prettier `--check` passed on the changed files only.
- **Svelte autofixer:** no issues on either component.
- **Helpers:** the verify helper node tests passed (13 of 13), and `database.py` compiles.
- **Fault checks:** removing the error link from the input fails the new accessibility test, and dropping the whole-number check fails the server tests. Both files were restored afterwards.

## Gaps and things you need to know
- **/tmp is out of inodes** (387 free). Most of it is `/tmp/node-compile-cache` and several `/tmp/t2t-1360-*` and `/tmp/t2t-1362-*` folders. I didn't delete anything because I don't own those. I ran with `TMPDIR` pointed at a scratch folder under `~/.cache`, which I've since removed. Your database script and app verification will likely need the same workaround.
- **SQL tests are unexecuted.** Two pgTAP calls have no precedent in this repo: `col_default_is` against a smallint default of `'90'`, and the final `results_eq` against a `VALUES` list. If either misbehaves on the first run, that's the first place to look.
- **The settings-request helper has no new unit test.** The allowlist addition is exercised only by the recipe's direct-request steps.
- **Still yours to do:** the live Settings → Policies and Training reports runs, the fresh and populated-upgrade database runs, merging main, the full test sequence and the build.

## Visual acceptance

**Verdict: the visuals are clean.** I found no actionable visual or accessibility defects in the 1501 first slice.

This was artifact review only. I compared the source diff of the working tree against `4d1f1dec` (HEAD is still the base, so the candidate is uncommitted), the three final screenshots, the two baseline screenshots, and the four companion snapshots. I didn't run the app independently.

## What I checked

- **Saved goal of 85 (`1501-final/policies-goal85.png`, `goal85-reloaded.txt`):**
  - The third card is independent. It has its own heading "Training Readiness", its own Saved badge and its own disabled Save button.
  - It reuses the sibling cards' styling: border, separator and `font-heading` title.
  - The label "Training readiness goal (%)" and the help text "Used for goal lines and heat-map bands on Training Reports." match the spec exactly.
  - The spinbutton exposes min 1, max 100, value 85, and the help text is its accessible description.
  - Against `baseline-expanded/policies.png`, the Retention and Loss Warning cards are unchanged in pixels and markup.
- **Invalid value 90.5 (`policies-invalid.png`, `fraction-screenshot-state.txt:72-80`):**
  - The label, field border and value turn red, and the badge reads "Unsaved changes".
  - Save is reported as `disabled`.
  - The input has `invalid="true"`, and `aria-describedby` links both the help text and the error.
  - The error comes from the shared `Field.Error` component and renders as an assertive alert.
  - The sibling cards stay Saved and disabled.
- **Source (`PoliciesSettingsSection.svelte`):**
  - It uses the shared `Field.Root/Label/Control/Description/Error` components with `data-invalid`, and the section is linked to its heading via `aria-labelledby`.
  - The sibling markup is left alone.
  - The save handler guards against invalid input, saves already in progress, and the page closing mid-save.
- **Training Report (`report-dated.png` against `baseline-expanded/report-dated.png`):**
  - The layout is identical.
  - The headline is 50% (was 25%), Targeted is 100 (was 0), Required stays at 33, and Alpha is 100% (was 50%).
  - The expiring 10/2026 cell keeps its orange styling. Compliance sorting moves Targeted below Required, which is the existing "sorted by lowest compliance" behaviour.
  - `report-dated.txt` confirms 50%, and `report-alpha.txt` shows the 100% figures after filtering to Alpha.
- **Freshness:** all four screenshots and snapshots were taken at 11:48–11:56 local, after `doctor-accepted.json` passed at 11:45:55 for candidate `b1f29a4e…`.

**Limits:** I only saw desktop width in light theme. I didn't check dark mode, narrow layouts, keyboard focus order, or the Saving… spinner state. The report screenshot doesn't show the Alpha-filtered view itself; that rests on the text snapshot.

## Audit-trail flags (`.verification/1501-decisions.tsv`)

1. **Row 4 (database), stale result:** it says "full replay rerunning". `1501-validation/database-final.log` (11:44) and `database-upgrade-final.log` (11:41) both record failures, the upgrade log with 3 `not ok` at lines 903, 935 and 965. The pass only appears in `database-accepted.log` at 11:49:30, which was written after the decisions file (11:46:36). Update row 4 to cite `database-accepted.log` and its pass, and keep the two failed logs labelled as superseded.
2. **The test and build pass is on an older tree:** `gate.log` (6384 tests, 11:35) and `build.log` (11:40) both predate later edits:
   - `reportCalculations.ts`, `CONTEXT.md`, `AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` and `organization-settings-destruction.md` were edited at 11:44:19.
   - The migration-test SQL files were edited at 11:40–11:42.

   The `reportCalculations.ts` change appears to be the comment fix, but "full 6384 tests and build pass" isn't proven for the exact final tree. Re-run the gate and build, or state that limit.
3. **Misleading file names:** in `1501-final/`, `doctor-final.json` says `BLOCKED/OWNERSHIP` and `doctor.json` says `INCONCLUSIVE`. Only `doctor-accepted.json` passes. A reader would expect "final" to be the accepted one, so mark these as superseded.
4. **Missing rows:** these steps from the brief have no checkpoint:
   - the baseline taken before implementation (`packaged/1501/baseline-expanded/`)
   - the single exclusive Claude implementation writer
   - the main fast-forward (main is now an ancestor of HEAD)
   - the additive CI-list conflict resolution
   - the earlier nonvisual review and its three prose fixes
   - this visual acceptance
5. **Timestamps:** all five rows share `2026-10-03T19:46:36Z`. That matches the stated "retrospective, logged-at" convention, but nothing in the file says so. Add a note or column so the times aren't read as action times.
6. **Not yet recorded as evidence:** final packaging isn't finished. I found no artifact showing that no live or remote migration happened, so for now that rests on the brief alone.

