# #1504 final v6 native acceptance: Retry focus, stale selection and short-detail print

Driver: Claude Opus 5.5 test sub-agent, worker 1, no nested agents. This bounded native round checks the `77b55954` fixes for v5 findings F1, F2 and F3. It also covers the affected matrix, no-data, print, selection, export and detail-Retry continuity. It does not certify whole-issue #1504 acceptance. Root owns independent acceptance, cleanup and packaging.

## Binding

| Field | Value |
| --- | --- |
| Head / base | `77b55954cd1545814e1581e9d54e254d43c9c14b` / `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Candidate | `c568cd28014146aa637a0d818d83a2a2738ed0894a9b998d8c067dc8678868e9` |
| Origin / session | `http://127.0.0.1:36135` / `764a2288-b285-46b9-a6e2-5e0b1d8b9770` |
| Browser | Chromium 152.0.7977.82 Arch Linux, `/usr/bin/chromium`, not provisioned |
| Actors | `trainingConfigure` on page 2. `trainingEmpty` on page 3. Both in Organization A `52d9f8b7…`. |
| Doctor | `000-doctor` PASS and `275-doctor-final` PASS. Both match the binding exactly. |
| Evidence | `.verification/evidence/verify-trooptotask/1504-final-v6/driver/` holds 849 files and `receipts.jsonl` with 399 uniquely named receipts. The run directory also holds four PDFs, one workbook and `pdf-pages/`. |

Fixture literals come from root's `root-public-fixture.json`. Today is 2026-10-04 and `trainingExpires` is 2027-09-27. The 90-, 60- and 30-day horizons end on 2 Jan, 3 Dec and 3 Nov.

Labels used here. **Native** means a DevTools click, press_key, resize or navigate. **Observation** means read-only `evaluate_script` (`state.js`, `matrix.js`), `take_snapshot` or `list_network_requests` for fetch/xhr. **Helper** means a documented `control.mjs` network, export, print, seed or rows command. Each action has `NNN-before-*`, `NNN-action` and `NNN-after-*` receipts.

## Verdicts

| # | Path | Verdict |
| --- | --- | --- |
| 1 | Baseline facts, 11B selection, horizon close (F2), Focus link, already-selected re-activation, reload | **PASS** |
| 2 | Report Rows-by 503, then held Retry by click and by Enter, and the no-steal case (F1) | **PASS** |
| 3 | No-data state (`trainingEmpty`) at 1440 and 390, plus native empty PDF | **PASS** with notes N3 and N4 |
| 4 | Short 30/MOS 11B one-row PDF (F3), post-print interaction, console | **PASS** |
| 5 | `training-pages` cohort facts, plus native 25-row and 100-row-per-page PDFs | **PASS** |
| 6 | Next/Previous boundary, detail 503 Enter Retry, 100 re-activation, five-sheet Excel, Training matrix consumer | **PASS** |
| 7 | Restoration, clean-seeds, A/B readbacks, preferences, final doctor | **PASS** |

## 1. Baseline, selection and re-activation

- `006` native click on Reports. The request list (`008-reports-net`) shows only `training/__data.json` and `reports/__data.json`, with no `/api/training-reports` summary request.
- Snapshot `009`: "3 soldiers · as of 4 Oct 2026". The Bottom line reads 25% → 25% by 2 Jan, Ready 1, expired 0, not recorded 3 and lapse 0. That gives 4 applicable requirements with 1 ready. Alpha is 50% (Required 100, Targeted 0), and Bravo and Unassigned are 0%. Required Total is 33% and Targeted Total is 0%. The default selection is 90 days and Group.
- `010` native click 30 days gives request 143 `?horizon=30`. `012` native click MOS gives request 144 `?horizon=30&rowsBy=mos`.
- `014` native click "11B, Verification Required Training". One request (145) ran: `detail?horizon=30&rowsBy=mos&scope=cell&row=11B&type=398234da…` [200]. Focus moved to `SECTION#training-affected-soldiers`. The TD has `data-selected=true` and the accessible name ends in ", selected". Status reads "1 requirement not ready or lapsing by 3 Nov". The range is Rows 1–1 of 1, and the only row is SPC Baker, Bravo, Not Done. I inspected screenshot `016-11b-open.png`. It shows the dashed outline on that cell only.
- **F2 closed.** `017` native click 60 days gave request 146 and closed the detail. `cellSel` and `ariaSel` are both empty, and focus stays on the 60-day radio. In screenshot `018-h60-closed.png` the 11B cell has no outline.
- `020` reopened 11B (request 147, selected outline and name). `022` native click "View 2 soldiers" gave request 149 `scope=focus&focus=gap%3A398234da…`. The detail shows Baker and Unassigned (Rows 1–2 of 2), and the link carries `aria-current`. No cell has `data-selected` or a selected name. Screenshot `024-focus-detail.png` confirms there is no outline on 11B.
- Already-selected re-activation, one native action per assertion (`030`–`035`): click 25, Space 25, click 60, Space 60, click MOS, Space MOS. After each action the same option stays checked, no group is left empty, focus is on the activated radio, the URL is unchanged and no request follows 149.
- `036` click 100 gives one request (150, `&pageSize=100`). `037` re-click and `038` Space on 100 keep it checked with no request. `039` click 30 gives request 151, and the URL becomes `?horizon=30&rowsBy=mos`.
- `040` native reload kept the URL and the 30/MOS checked state. The request list (`040-reload-after-net`) has only the notification-count fetch and no `training-reports` request, so the reloaded briefing was painted by the server.

## 2. Report Retry focus (F1)

Hook state receipts: `054`, `060`, `073`, `077`, `093`, `098`.

| Stage | Receipt | Focus | aria-busy | Checked Rows by | URL | Request |
| --- | --- | --- | --- | --- | --- | --- |
| 503 on native click Group | `053` | Group radio | false | MOS (canonical) | `?horizon=30&rowsBy=mos` | helper: one GET 503 |
| Held, after native **click** Retry | `059` | `SECTION#training-briefing` | **true** | Group (attempt) | `?horizon=30&rowsBy=mos` (loaded) | 273 `?horizon=30`, held |
| Second held read | `063-release-before-state` | briefing | true | Group | unchanged | held |
| After release | `064` | **briefing** | false | Group | `?horizon=30` | 273 only |
| 503 on native click MOS | `071` | MOS radio | false | Group | `?horizon=30` | one 503 |
| Held, after Shift+Tab to Retry and native **Enter** | `076` | **briefing** | **true** | MOS | `?horizon=30` | 274 `?horizon=30&rowsBy=mos`, held |
| After release | `079` | **briefing** | false | MOS | `?horizon=30&rowsBy=mos` | 274 only |
| 503, Shift+Tab, held Enter Retry | `091`, `092`, `096` | briefing | true | Group | `?horizon=30&rowsBy=mos` | 275, held |
| Native Tab while held | `097` | Group radio | true | Group | unchanged | held |
| After release | `100` | **Group radio (not stolen)** | false | Group | `?horizon=30` | 275 only |

The briefing kept the previously loaded report (MOS grid, "BY 3 NOV") while each request was held (`062-held-snap`). After the first release the grid shows Group rows (Bravo, Unassigned, Alpha) (`065`). Each Retry issued exactly one request. While held, the snapshot names the region "Training readiness briefing" with `busy` and `focused`, and the visible "Updating briefing" status shows. Screenshots: `055-fail.png` and `061-retry-held.png`.

## 3. No-data state

- `111` `actor trainingEmpty training/reports` opened page 3. The request list shows only `reports/__data.json`. Snapshot `114`: "0 soldiers". The `Training readiness briefing` region holds only "No applicable requirements." and "No soldier is required to hold the configured training." Export Excel is `disabled`. The briefing shows no percentage, count or chart.
- 1440×900 (`115`). `116` native click 60 days gives request 133 `?horizon=60` [200] with focus on the radio. I inspected `117-empty-1440.png`. It shows a single centered empty panel with an in-panel Clear filters, the header Export disabled and Print enabled.
- 390×844 (`118`). Document, body and viewport widths are all 390, so nothing overflows. In `120-empty-390-h60.png` the empty state is legible and the controls wrap. `121` native click on the in-panel Clear filters gives request 134 `/api/training-reports` [200], URL `/reports`, 90 checked and the panel without its button (`122-empty-390-cleared.png`). Focus fell to BODY (note N3).
- Empty PDF. `123` resize to 1905×2053, then `124` native reload. `126` print arm (0/0). `127` native click Print brief. `128` state before 1, after 0, saved before capture. `129` save of the exact URL `/org/…/training/reports` produced `training-brief-empty.pdf`: 70133 bytes, SHA-256 `b78725a881cc4b2557dd683a0a19c6c2a0b0848db716ab26def756d6604fd1a9`, then `130` restore. `pdfinfo` shows 1 page, letter landscape. In my reading of `pdf-pages/empty-1.png` it has the title, the subtitle "0 soldiers", the full filter line ending "Horizon: 90 days · Rows by: Group" and the empty panel. No chrome, controls or added pages appear.
- The no-types Retry path is unit-proved only. I made no native claim about it.

## 4. Short one-row detail PDF (F3)

- `141` native click MOS, `142` fresh reload, `144` native click on 11B × Required. Request 398 returned Rows 1–1 of 1 with Baker and the selected outline. `145` print arm (0/0). `146` native click Print brief. `147` state before 1, after 0. `148` save of the exact loaded URL `…/training/reports?horizon=30&rowsBy=mos` produced `training-brief-30-mos-11b.pdf`: 174290 bytes, SHA-256 `89326b524eefba3c8ccdb5ba92206be0f96e22b196cd4fcd7cde9bca62661c07`, then `149` restore.
- 4 pages, all letter landscape (792×612). I inspected each page:
  - **p1**: title, subtitle, and the filter line "… Types: All required (2) · Horizon: 30 days · Rows by: MOS" beneath the title. Then the Bottom line 25% → 25% by 3 Nov with 1/0/3/0.
  - **p2**: Forecast "Next 30 days" with the goal line, 25% series and Today · 4 Oct / 1 Nov / 3 Nov ticks. Then the MOS grid with legend, red bands, the dashed 11B outline and Today/3 Nov columns.
  - **p3**: Type risk (Required 2/0, Targeted 1/0) and both Focus areas with what-if chips and no View links.
  - **p4**: the eyebrow "11B, Verification Required Training", the Affected soldiers heading, the status sentence, "Rows 1–1 of 1", the table header and the Baker row, all together.
- **F3 closed.** The short detail is no longer split from its table. No section is split. Text search of `short.txt` finds no Rows per page, Retry, Previous/Next, View links, Export, Print brief or Clear filters. The only hit is "Forecast · Next 30 days". No sidebar, header, toasts or trailing blank page appear. Page 1's lower half is empty because the forecast is kept whole, which matches the approved layout.
- After print, `151` native click 60 days gave request 399. Screenshot `152-postprint-h60.png` shows the 60-day chart rendered to 3 Dec, usable controls and no stale outline on 11B. In console `153` (preserved, warnings and errors), every entry is a known local Vercel-insights 404, a MIME refusal or an unused-preload warning. The LayerCake zero-width and negative `<rect>` warnings did not appear in this run. That supports no clean-console claim beyond these pages.

## 5. Cohort and long-detail print

- Pre-seed readbacks (`160-preseed-*`) of personnel, personnel_trainings, training_types, training_views and organizations in A and B are byte-identical to root's originals. `161` `seed training-pages` returned tag `83b7334e`, count 26 and first ID `3050554e-9581-4644-8965-f02ff29a91bc`.
- `162` fresh navigation to `/reports` (90/Group by default). Snapshot `164`: 29 soldiers, 3% → 3%, Ready 1, expired 0, not recorded 30 and lapse 0. That is 31 applicable: 29 Required plus 2 Targeted (Able and the first temporary person, who is 68W/Medic). 1/31 rounds to 3%.
- `165` Required Total: one request (521 `scope=cell&type=…`). The status reads "28 requirements not ready or lapsing by 2 Jan", the range is Rows 1–25 of 28 and Previous is disabled.
- **25-row PDF.** `200` fresh reload, `202` reopen Required Total (request 647, Rows 1–25 of 28). `203` arm, `204` native Print brief, `205` state before 1, after 0. `206` save **exited 2** with "Native page ID and unique exact report URL must agree" because page 3 was also on the exact `/reports` URL. My one argument repair: `208` native navigation of page 3 to `/training`. `210` save then produced `training-brief-cohort-25.pdf`: 253181 bytes, SHA-256 `ac1d03f61a0d005e4692dc90abc969ffde4a9caf42a0c0cc5f3a40adaaf28185`. `207` restore. The invocation proof is `205`, taken before capture. The print observer was restored before the repaired capture.
- **100-row PDF.** `220` fresh reload, `222` reopen (request 769), `224` click 100 (request 770 `pageSize=100`, Rows 1–28 of 28). `225` arm, `226` native Print brief, `227` before 1, after 0. `228` save produced `training-brief-cohort-100.pdf`: 261493 bytes, SHA-256 `52ad7059ff0c1637e71b9a7dcd2a4357710c25eb5892ec08cd646614be9caa26`. `229` restore.
- Both PDFs have 5 letter-landscape pages. Pages 1–3 are text- and pixel-identical between them. **p1** has the title, subtitle "29 soldiers", the filter line "… Horizon: 90 days · Rows by: Group" and the Bottom line 3% → 3% with 1/0/30/0. **p2** has the Forecast 3% series to 2 Jan, plus the Group grid (Bravo 0, Unassigned 0, Alpha 4/0, Total 3/0) with the Total Required outline. **p3** has Type risk (Required 28/0, Targeted 2/0) and both Focus areas (3% → 94% and 3% → 10%).
  - **25 p4**: eyebrow, heading, status, "Rows 1–25 of 28", table header, then Baker and MapTraining…e00 to e14 (16 rows). **25 p5**: a repeated header, then e15 to e23 (9 rows). That is 25 distinct names with no duplicate and no missing row.
  - **100 p4**: the same 16 rows under "Rows 1–28 of 28". **100 p5**: repeated header, then e15 to e25 and Unassigned (12 rows). That is 28 distinct names, matching the expected Required Not Done set: 26 seeded People plus Baker and Unassigned, with Able absent because he is Current.
  - All seven columns are present, and every Status cell shows the neutral "Not done" band. No header-only page, blank page, truncation or chrome appears. Whole-section keep-together leaves space at the bottom of pages 1–3, and the long table splits between rows with a repeated header. That is practical for paper and consistent with the approved layout.

## 6. Pager, detail Retry, rows per page, Excel and matrix consumer

- `167` Next gave one request (522 `&page=2`), Rows 26–28 of 28, Next disabled and focus on the section. `169` arm-fail detail, then `170` native click Previous. The helper shows one 503 (`172`). The alert reads "Unable to load affected soldiers … (503). Showing the page that loaded before. Retry". The loaded range stays 26–28 with 3 rows, and focus is on Previous.
- `173` restore, `174` Shift+Tab to Retry, `175` native Enter. One request (523, page 1) returned Rows 1–25 of 28 with focus on `SECTION#training-affected-soldiers`.
- `177` 100 gave one request (524) and Rows 1–28 of 28. `178` re-click and `179` Space caused no request and left 100 checked.
- **Excel.** `181` network arm-observe export, `182` export arm, then **`183`, one native click**. The network helper (`185`) recorded exactly one GET with 200, `attachment;filename="training-report-2026-10-04.xlsx"` and the xlsx MIME type. `184` export state shows captured, 12470 bytes. `186` save produced `training-report-cohort-90-group.xlsx`, SHA-256 `590f4c45e87c7bc498fcd5f11b1ffe0b9d7d98621d9d2fdccdfa7c446e5a7f00`, matching `sha256sum`. `187` and `188` restore. Parsed through the `workbook` helper (`189-wb-*`) and the zip's `workbook.xml`:
  - Sheet order is Summary, Forecast, Hot spots, Focus, Requirements, and nothing else.
  - **Summary**: as of 2026-10-04, horizon end 2027-01-02, goal 90, ready 3/3, drop 0, Ready 1, applicable 31, expired 0, not recorded 30, lapse 0. Filter rows: View "All training", Group "All groups", Rank "All ranks", MOS "All", Duty role "All", Types "All required (2)", Horizon "90 days", Rows by "Group".
  - **Forecast**: today, then 13 weekly rows ending 2027-01-02. The last row is the short bucket 28 Dec – 2 Jan. Every row is 1 ready, 3%.
  - **Hot spots**: Bravo 1 (0), Unassigned 1 (0), Alpha 27 (4/0), Total 29 (3/0).
  - **Focus**: the two areas with the on-screen sentences and 3 → 94 and 3 → 10.
  - **Requirements**: 30 rows, all Not Done. That is 28 Required (Baker, 26 seeded, Unassigned) plus 2 Targeted (Able, MapTraining…e00). Able Required is absent, and there are no Optional, N/A or foreign rows. The open 28-row detail did not narrow the workbook.
- **Matrix consumer.** `241` native click on the Training breadcrumb. `244` personnel_trainings A is identical to root's original. `246` native click on "Baker Verification Required Training: Not Done" opened "Add Training Record · SPC Baker, Synthetic · Verification Required Training" (`247`, `248`, screenshot `249`). `250` native Cancel. The request list (`253`) shows no POST, PUT, DELETE or PATCH. `254` personnel_trainings A is byte-identical to the original. After Cancel, focus returns to the Baker cell button. The TD keeps its internal `data-selected=true` memory with computed outline `none`, and the accessible name has no "selected". Screenshot `252` shows no visible selection outline. This uncontrolled consumer behaves as before. The ICT direct consumer was covered offline by root's 661 tests and was not driven live.

## 7. Restoration

- `260` clean-seeds: `cleaned:true`. Final readbacks (`261-final-*`) of all five tables in A and B are byte-identical to `root-*-original.json`. `262` trainingConfigure preferences are byte-identical to root's original. `263` trainingEmpty preferences match its pre-read `110`. No UI rows were created.
- Final page and environment state (`270`): both pages are at `/org/…/training`, 1905×2053, no html class, `mode-watcher-mode=system`, original localStorage keys only, no sidebar cookie and no `__map*` globals. Theme and sidebar were never toggled. Page 2 began on `/training`. Page 3 (new this round, opened by `actor` on `/training/reports`) ends on `/training` because of the repair navigation.
- On both pages, network, export and print controls report disarmed with no captures (`271`–`273`). The feedback observer was not used.
- Profile and pages (`274`): page 1 `about:blank`, page 2 trainingConfigure context, page 3 trainingEmpty context (new isolated context `map-trainingEmpty-7e8b67f0…`).
- `275-doctor-final` PASS with the exact binding. The worker is returned to root **uncleaned**.

## Findings

F1, F2 and F3 from v5 are closed in this native scope. No new P1 or P2 issue was found.

**N2 (P4, performance observation, not introduced by `77b55954`).** Clicking a Focus "View N soldiers" link produced a `training/reports/__data.json?…#training-affected-soldiers` request (148) before the detail request (149). The likely cause is SvelteKit's `data-sveltekit-preload-data="hover"` (`src/app.html:47`) preloading the in-page `#training-affected-soldiers` href on pointer hover. The click itself calls `preventDefault`. It is one redundant full page-data load per hovered Focus link. I did not test a fix. `data-sveltekit-preload-data="off"` on that link would falsify this.

**N3 (P3, keyboard focus, no-data branch).** Activating the in-panel Clear filters in the empty state (`121`) unmounts the button, and focus falls to BODY. This mirrors the v5 F1 pattern in a branch the Retry fix does not cover. The briefing region would be a stable target. Pre-existence was not checked against base.

**N4 (P4, visual).** At 390 px the header actions wrap so that Print brief sits alone on the left of a second row (`120`). It is legible and usable.

**N1 (carried, not re-tested).** The roving-tab-stop note from v5 is still open.

**Matrix page observation (out of scope).** Screenshot `252` shows large empty bands above and below the status legend on the Training matrix at 1905×2053. I did not investigate, and this round makes no claim about it.

## Driver errors and receipts

399 uniquely named receipts. Three exited nonzero:

- `063-release-action` (exit 2): my wrapper passed an invalid tool name. Nothing reached the browser. The real release is `063-release-cmd`.
- `206-print-save` (exit 2): the documented duplicate-URL guard refused the capture. It was repaired once by `208`/`210`.
- `242-wait` (exit 2): `wait_for` timed out because the target text is an accessible name, not visible text. Snapshot `243` replaced it.

`051-group-fail` was a mis-targeted native click on the "Verification Required Training" column header. It made no request and the hook was not consumed, and the intended click is `053`. All other receipts exited 0.

## Limits

- The PDFs prove Chromium print rendering after a native Print brief invocation, recorded as `beforeprint` 1 before capture. They do not prove a system dialog or physical printing.
- These were not repeated or established here: the dated-import fixture, many types, Organization/session races, multiple tabs, dark-mode print, the full ICT consumer live path, Onboarding, raw Organization writes, RLS/SQL, remote and release. v1–v5 coverage remains historical continuity at their own pins.
- This narrow round makes no claim that the whole issue is complete.

## Secrets

No credentials, cookies or tokens were printed or saved. A content scan of `driver/` and the PDFs for token, password, Bearer and Supabase auth-cookie patterns found nothing. The `actor` outputs contain only the nonsecret `browserContext` names. No files are flagged for root redaction.
