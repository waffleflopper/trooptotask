import json,pathlib
r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-twoport-final-native-20261007')
def read(name):return json.loads(json.loads((r/(name+'.json')).read_text())['stdout'])
keys={
 'type':{'id':'id','name':'name','description':'description','expirationMonths':'expiration_months','warningDaysYellow':'warning_days_yellow','warningDaysOrange':'warning_days_orange','appliesToRoles':'applies_to_roles','appliesToMos':'applies_to_mos','appliesToRanks':'applies_to_ranks','excludedRoles':'excluded_roles','excludedMos':'excluded_mos','excludedRanks':'excluded_ranks','color':'color','sortOrder':'sort_order','expirationDateOnly':'expiration_date_only','canBeExempted':'can_be_exempted','exemptPersonnelIds':'exempt_personnel_ids','isOptional':'is_optional','organization_id':'organization_id','created_at':'created_at'},
 'view':{'id':'id','name':'name','columnIds':'column_ids','createdBy':'created_by','createdAt':'created_at','updatedAt':'updated_at','organization_id':'organization_id'},
 'completion':{'id':'id','personnelId':'personnel_id','trainingTypeId':'training_type_id','completionDate':'completion_date','expirationDate':'expiration_date','notes':'notes','certificateUrl':'certificate_url','organization_id':'organization_id','created_at':'created_at','updated_at':'updated_at'}
}
def compare(kind,wireName,sqlName):
 w=read(wireName)['structuredContent']['networkRequest'];assert w['status']=='200',w['status'];body=json.loads(w['responseBody']);rows=read(sqlName)['rows'];assert len(rows)==1
 row=rows[0];assert set(body)==set(keys[kind]),(wireName,set(body));assert body=={out:row[source] for out,source in keys[kind].items()},wireName
 if kind=='type':assert 'updated_at' not in body and 'updated_at' not in row
 return {'kind':kind,'wire':wireName,'sql':sqlName,'id':row['id'],'keyCount':len(body),'allFieldsMatch':True,'httpStatus':200}
if __name__=='__main__':
 cases=[('type','annual-create-wire','annual-created-sql'),('type','annual-update-wire','annual-updated-sql')]
 out=[compare(*c) for c in cases];(r/'saved-shape-comparison-current.json').write_text(json.dumps({'status':'PASS','comparisons':out},indent=2));print(json.dumps(out,indent=2))
