window.__tb = () => {
	const box = (el) => { const r = el.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; };
	const hitOk = (el) => { const r = el.getBoundingClientRect(); if (!r.width) return 'zero'; const cx = r.x + r.width / 2, cy = r.y + r.height / 2; if (cx < 0 || cx > innerWidth || cy < 0 || cy > innerHeight) return 'offscreen'; const t = document.elementFromPoint(cx, cy); return t && (t === el || el.contains(t)) ? 'ok' : 'covered:' + (t?.tagName + '.' + (t?.className?.baseVal ?? t?.className ?? '')).slice(0, 40); };
	const actions = document.querySelector('[aria-label="Training report actions"]');
	const tb = document.querySelector('[aria-label="Training report controls"]');
	const items = [...actions.querySelectorAll('button,[role=status]'), ...tb.querySelectorAll('button')].map((el) => ({ n: (el.getAttribute('aria-label') || el.innerText.trim()).slice(0, 24), ...box(el), hit: el.tagName === 'BUTTON' ? hitOk(el) : 'status' }));
	const alert = document.querySelector('[role=alert]');
	return { vw: innerWidth, docW: document.documentElement.scrollWidth, theme: document.documentElement.dataset.theme, url: location.search, actions: box(actions), toolbar: box(tb), status: actions.querySelector('[role=status]')?.innerText ?? null, alert: alert ? { text: alert.innerText.replace(/\n/g, ' | '), ...box(alert) } : null, checked: [...document.querySelectorAll('[role=radio][aria-checked=true]')].map((r) => r.innerText.trim()), bl: [...document.querySelectorAll('section')].find((s) => s.innerText.startsWith('Bottom line'))?.innerText.split('\n').filter(Boolean).slice(1, 6).join(' '), items };
};
window.__hookInstall = () => {
	if (window.__origFetch) return 'already';
	window.__origFetch = window.fetch;
	window.__hook = { mode: null, log: [], held: [] };
	window.fetch = function (input, init) {
		const url = typeof input === 'string' ? input : input.url;
		const m = /\/api\/training-reports(\?|$)/.test(url);
		const entry = { t: new Date().toISOString(), url: url.replace(location.origin, ''), mode: m ? window.__hook.mode : 'pass' };
		window.__hook.log.push(entry);
		if (m && window.__hook.mode === 'fail') { entry.status = 503; return Promise.resolve(new Response(JSON.stringify({ message: 'synthetic v4 fault' }), { status: 503, headers: { 'content-type': 'application/json' } })); }
		const p = window.__origFetch.call(this, input, init);
		if (m && window.__hook.mode === 'hold') {
			return new Promise((resolve, reject) => { window.__hook.held.push(() => p.then(resolve, reject)); init?.signal?.addEventListener('abort', () => { entry.aborted = true; }); });
		}
		return p.then((r) => { entry.status = r.status; return r; });
	};
	return 'installed';
};
window.__release = () => { const n = window.__hook.held.length; window.__hook.held.splice(0).forEach((f) => f()); return n; };
window.__hookRemove = () => { if (window.__origFetch) { window.fetch = window.__origFetch; delete window.__origFetch; } const log = window.__hook?.log; delete window.__hook; return { restored: true, log }; };
'tb+hook installed'
