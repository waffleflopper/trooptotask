SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = '2136f91e-e059-4843-8985-fcba75f1ff2c'::uuid AND p.id = '3a175ee7-8fea-4aa2-a2f2-a95de88d5988'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = '2136f91e-e059-4843-8985-fcba75f1ff2c'::uuid AND id = 'e5ad42ae-51e5-49a3-ac8f-665492cfac8f'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = '2136f91e-e059-4843-8985-fcba75f1ff2c'::uuid AND s.onboarding_id = '3a175ee7-8fea-4aa2-a2f2-a95de88d5988'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
