#!/usr/bin/env python3
"""Read-only exact owned-worker provider metadata and post-disposal absence. Never SQL."""
import argparse,datetime,importlib.util,json,re,subprocess,os
from pathlib import Path
from urllib.parse import urlsplit
parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['before','after']);parser.add_argument('--worker',choices=['1'],required=True);args=parser.parse_args()
ROOT=Path(__file__).resolve().parents[3];assert Path.cwd().resolve()==ROOT
runName=os.environ['D15_EVIDENCE'];assert re.fullmatch(r'd15-removal-[a-z0-9-]+',runName)
B=ROOT/'.verification/evidence/verify-trooptotask'/runName
spec=importlib.util.spec_from_file_location('owned_environment',ROOT/'scripts/verification/environment.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
calls=[]
def docker(command,env):
 r=subprocess.run(['docker',*command],env=env,capture_output=True,text=True,check=True);calls.append({'command':['docker',*command],'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});return r.stdout.splitlines()
if args.mode=='before':
 session=Path(json.loads((B/'info.json').read_text())['session']);assert session.name=='worker-1'
 m.private_session(session);state,workdir,env=m.owned(session);assert state['repository']==str(ROOT)
 status=m.status(session);assert status['status']=='PASS' and status['project']==state['project']
 records=m.containers(state,workdir,env)
 public={'worker':1,'sessionDirectory':str(session),'project':state['project'],'DOCKER_HOST':env['DOCKER_HOST'],'status':status,'configSha256':state['config_sha256'],'containers':[{'id':c['Id'],'name':c['Name'].lstrip('/'),'supabaseProject':c['Config']['Labels']['com.supabase.cli.project'],'composeProject':c['Config']['Labels']['com.docker.compose.project']} for c in records]}
else:
 public=json.loads((B/'provider-before.json').read_text());session=Path(public['sessionDirectory']);assert not session.exists();assert public['worker']==1
 database=m.load_database(ROOT);env=database.clean_environment()
 for key in ['DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(key,None)
 endpoint=urlsplit(public['DOCKER_HOST']);assert endpoint.scheme=='unix' and not endpoint.netloc and endpoint.path.startswith('/')
 env['DOCKER_HOST']=public['DOCKER_HOST']
 assert json.loads((B/'owned-disposal.json').read_text())['status']=='PASS'
project=public['project'];assert re.fullmatch(r't2t-verify-[0-9a-f]{24}',project)
allContainers=docker(['ps','--all','--no-trunc','--filter','name=t2t-verify-','--format','{{.ID}} {{.Names}}'],env);allVolumes=docker(['volume','ls','--filter','name=t2t-verify-','--format','{{.Name}}'],env);allNetworks=docker(['network','ls','--filter','name=t2t-verify-','--format','{{.Name}}'],env)
exactContainers=[line for line in allContainers if line.split(' ',1)[1].endswith('_'+project)]
exactVolumes=[name for name in allVolumes if name.endswith('_'+project)];exactNetworks=[name for name in allNetworks if name.endswith('_'+project)]
if args.mode=='before':public.update({'volumeNames':exactVolumes,'networkNames':exactNetworks,'inventoryContainerNames':exactContainers})
else:
 originalIds={c['id'] for c in public['containers']};allIds=docker(['ps','--all','--no-trunc','--format','{{.ID}}'],env);remainingIds=[identifier for identifier in allIds if identifier in originalIds]
 remainingVolumes=[name for name in public['volumeNames'] if name in allVolumes];remainingNetworks=[name for name in public['networkNames'] if name in allNetworks]
 public={'worker':1,'project':project,'DOCKER_HOST':env['DOCKER_HOST'],'exactContainerIdMatches':remainingIds,'exactProjectContainerMatches':exactContainers,'exactRecordedVolumeMatches':remainingVolumes,'exactProjectVolumeMatches':exactVolumes,'exactRecordedNetworkMatches':remainingNetworks,'exactProjectNetworkMatches':exactNetworks,'privateDirectoryAbsent':not session.exists(),'method':'Read-only actual full-ID/name Docker inventory after exact owned cleanup; no resources modified'}
 assert not any([remainingIds,exactContainers,remainingVolumes,exactVolumes,remainingNetworks,exactNetworks])
pattern=re.compile(r'(?:^|_)t2t-verify-[0-9a-f]{24}$')
public['allVerificationNamespace']={'containers':[line for line in allContainers if pattern.search(line.split(' ',1)[1])],'volumes':[name for name in allVolumes if pattern.search(name)],'networks':[name for name in allNetworks if pattern.search(name)]}
public['dockerCommands']=calls
public['namespaceFilterDefinition']={'nativeFilter':'name=t2t-verify- (superset of every permitted verification project name)','exactSuffixRegex':pattern.pattern,'containerNameField':'second field after full ID','volumeAndNetworkField':'complete returned name','exactIdAbsence':'Full Docker container ID inventory, irrespective of name'}
public['capturedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (B/('provider-'+args.mode+'.json')).open('x') as f:json.dump(public,f,indent=2)
print(json.dumps({'worker':1,'project':project,'mode':args.mode,'status':'PASS','containerMatches':len(exactContainers),'volumeMatches':len(exactVolumes),'networkMatches':len(exactNetworks)}))
