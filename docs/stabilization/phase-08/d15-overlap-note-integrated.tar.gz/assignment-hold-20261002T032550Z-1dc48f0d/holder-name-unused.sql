SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('unused', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = 't2t-d15-overlap-95460610ad924b63b57dc7a2c88dd4ba'));
