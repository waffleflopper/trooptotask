#!/usr/bin/env python3
"""Frozen D15 probe: only an owned worker-1 onboarding-retention seed.

Root inspects/runs this scratch file; it never creates or starts a provider.
fault-on intentionally leaves one recorded, seed-restricted DELETE trigger;
run fault-off with the SAME seed capture before removing the seed ledger.
race invokes the real app cron and records observations, not an acceptance PASS.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import signal
import subprocess
import sys
import threading
import time
import tomllib
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, ProxyHandler, Request
import uuid


REPOSITORY = Path(__file__).resolve().parents[3]
ENDPOINT = "/api/cleanup-expired-onboardings"
EXPIRED_AT = datetime(2000, 1, 1, 12, tzinfo=timezone.utc)
EXPECTED_KEYS = {"expiredCompleted0", "expiredCancelled", "recentCompleted", "recentCancelled",
                 "nullCompleted", "nullCancelled", "active", "foreignRecent"}


class Blocked(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Blocked(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def public_error(error):
    return {"error_type": type(error).__name__,
            "message": str(error) if isinstance(error, Blocked) else "Private command/configuration diagnostics withheld."}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regular(value):
    path = Path(value).absolute()
    require(path.resolve() == path and path.is_file() and not path.is_symlink(),
            "Input must be a real regular file without symlink ancestors.")
    require(path.stat().st_uid == os.getuid(), "Input must belong to the current user.")
    return path


def read_json(path):
    return json.loads(regular(path).read_text())


def uid(value):
    require(isinstance(value, str), "Seed ID must be a UUID string.")
    require(str(uuid.UUID(value)) == value, "Seed ID must be a canonical lowercase UUID.")
    return value


def literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def instant(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        # Preserve the original redirect status/body as evidence; never follow it.
        return None


def http(request, timeout):
    opener = build_opener(ProxyHandler({}), NoRedirect())
    try:
        response = opener.open(request, timeout=timeout)
    except HTTPError as error:
        response = error
    with response:
        return response.status, {key.lower(): value for key, value in response.headers.items()}, response.read(1048576).decode("utf-8", errors="replace")


class Probe:
    def __init__(self, args):
        evidence = Path(args.evidence).absolute()
        require(evidence.resolve() == evidence, "Evidence directory must not have symlink ancestors.")
        evidence.mkdir(parents=True, exist_ok=True, mode=0o700)
        require(evidence.is_dir() and evidence.stat().st_uid == os.getuid(), "Evidence directory is not owned.")
        self.run = evidence / (args.mode + "-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
        self.run.mkdir(mode=0o700)
        self.save("input.json", {"mode": args.mode, "transition": args.transition,
                                 "session": str(Path(args.session).absolute()), "seed": str(Path(args.seed).absolute()),
                                 "repository": str(REPOSITORY), "probe_sha256": sha(Path(__file__)), "at": stamp()})
        module_path = REPOSITORY / "scripts/verification/environment.py"
        spec = importlib.util.spec_from_file_location("d15_owned_environment", module_path)
        environment = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(environment)
        self.session = environment.private_session(args.session)
        expected = Path.home() / ".local/state/trooptotask-verification" / hashlib.sha256(str(REPOSITORY).encode()).hexdigest()[:16] / "worker-1"
        require(self.session == expected, "Only this checkout's exact worker-1 session is allowed.")
        state, self.workdir, self.environment = environment.owned(self.session)
        require(state["repository"] == str(REPOSITORY), "Provider belongs to a different checkout.")
        status = environment.status(self.session)
        self.container = "supabase_db_" + state["project"]
        records = environment.containers(state, self.workdir, self.environment)
        matches = [item for item in records if item["Name"] == "/" + self.container and item["State"]["Running"]]
        require(len(matches) == 1, "Exact owned database container is not running.")
        self.project = state["project"]
        self.worker = read_json(self.session / "session.json")
        require(self.worker.get("repository") == str(REPOSITORY) and self.worker.get("worker") == "1"
                and self.worker.get("phase") == "running", "Worker-1 is not running for this checkout.")
        supervisor = self.worker["supervisor"]
        require(type(supervisor["pid"]) is int and supervisor["pid"] > 0, "Invalid supervisor identity.")
        proc = Path("/proc") / str(supervisor["pid"])
        stat = (proc / "stat").read_text()
        current_start = stat[stat.rfind(")") + 2:].split()[19]
        require(current_start == str(supervisor["start"]) and (proc / "cmdline").read_bytes().decode() == supervisor["command"],
                "Owned supervisor was replaced.")
        origin = urlsplit(self.worker["origin"])
        require(origin.scheme == "http" and origin.hostname == "127.0.0.1" and origin.port
                and not origin.username and not origin.password and origin.path in ("", "/")
                and not origin.query and not origin.fragment, "App origin is not owned loopback HTTP.")
        config = tomllib.loads((self.workdir / "supabase/config.toml").read_text())
        require(config["auth"]["site_url"] == self.worker["origin"], "App origin differs from the owned provider configuration.")
        port = self.worker["controlPort"]
        require(type(port) is int and 0 < port < 65536, "Invalid owned control port.")
        self.save("doctor-request.json", {"method": "POST", "url": f"http://127.0.0.1:{port}",
                                          "body": {"command": "doctor"}, "authorization": "owned token withheld"})
        code, headers, body = http(Request(f"http://127.0.0.1:{port}", data=b'{"command":"doctor"}', method="POST",
                                          headers={"Authorization": "Bearer " + self.worker["token"], "Content-Type": "application/json"}), 30)
        doctor = json.loads(body)
        self.save("doctor-result.json", {"http_status": code, "authenticated": headers.get("x-t2t-session") == self.worker["id"],
                                         "status": doctor.get("status"), "code": doctor.get("code")})
        require(code == 200 and headers.get("x-t2t-session") == self.worker["id"] and doctor.get("status") == "PASS",
                "Owned authenticated doctor did not pass; refusing a stale/unavailable worker.")
        seed_path = regular(args.seed)
        self.seed = read_json(seed_path)
        ledger_path = regular(self.session / "verify-trooptotask-owned.json")
        ledger = read_json(ledger_path)
        fixture = read_json(self.session / "fixtures.json")
        require(self.seed.get("kind") == "onboarding-retention" and re.fullmatch(r"[0-9a-f]{8}", self.seed.get("tag", "")),
                "Only the fixed, eight-packet onboarding-retention capture is allowed.")
        packets = self.seed["packets"]
        progress = self.seed["progress"]
        require(len(packets) == 8 and {row.get("key") for row in packets} == EXPECTED_KEYS and len(progress) == 8,
                "Seed capture does not match the fixed retention cohort.")
        self.org = uid(fixture["ids"]["orgA"])
        self.target = next(row for row in packets if row["key"] == "expiredCancelled")
        self.target_id = uid(self.target["id"])
        require(self.target["organization_id"] == self.org and self.target["status"] == "cancelled"
                and self.target["completed_at"] is None and instant(self.target["cancelled_at"]) == EXPIRED_AT,
                "The selected target is not the seed's expired-cancelled Org A packet.")
        for table, rows in (("personnel_onboardings", packets), ("onboarding_step_progress", progress)):
            require(len({uid(row["id"]) for row in rows}) == len(rows), "Duplicate seed IDs are not allowed.")
            for row in rows:
                organization = "orgA" if row["organization_id"] == self.org else "orgB"
                require(row["organization_id"] == uid(fixture["ids"][organization]), "Seed has an unknown organization.")
                require(any(entry.get("kind") == self.seed["kind"] and entry.get("tag") == self.seed["tag"]
                            and entry.get("table") == table and entry.get("organization") == organization
                            and row["id"] in entry.get("ids", []) for entry in ledger.get("seeded", [])),
                        "Capture ID is not recorded in this worker's owned seed ledger.")
        by_packet = {row["id"]: row["organization_id"] for row in packets}
        require(all(row["onboarding_id"] in by_packet and row["organization_id"] == by_packet[row["onboarding_id"]]
                    for row in progress) and {row["onboarding_id"] for row in progress} == set(by_packet),
                "Progress is not an exact witness for the selected cohort.")
        self.witness_ids = sorted(row["id"] for row in progress if row["onboarding_id"] == self.target_id)
        self.function = "t2t_d15_parent_delete_fault_" + self.seed["tag"]
        self.marker = "t2t-d15 project=" + self.project + " seed=" + self.target_id
        self.app_name = "t2t-d15-race-" + self.seed["tag"]
        self.save("ownership.json", {"provider": status, "worker": "1", "supervisor_identity_matches": True,
                                    "container": self.container, "container_id": matches[0]["Id"],
                                    "seed_sha256": sha(seed_path), "ledger_sha256": sha(ledger_path),
                                    "environment_helper_sha256": sha(module_path), "target": self.target,
                                    "target_progress_ids": self.witness_ids, "tag": self.seed["tag"]})
        # Never put either the provider keys or generated cron/supervisor secrets into evidence.
        self.command = ["docker", "exec", "-i", "-e", "PGPASSWORD=postgres", self.container,
                        "psql", "-X", "-q", "-A", "-t", "-U", "supabase_admin", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]
        self.fault_may_be_installed = False

    def save(self, name, value):
        descriptor = os.open(self.run / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "w") as output:
            json.dump(value, output, indent=2)
            output.write("\n")

    def plan(self, name, sql):
        path = self.run / (name + ".sql")
        if path.exists():
            require(path.read_text() == sql, "A recorded SQL plan changed within this run.")
        else:
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "w") as output:
                output.write(sql)

    def log(self, name, value):
        descriptor = os.open(self.run / (name + ".outputs.jsonl"), os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "a") as output:
            output.write(json.dumps({"at": stamp(), **value}) + "\n")

    def sql(self, name, sql):
        sql = "SET statement_timeout = '10s'; SET lock_timeout = '3s';\n" + sql
        self.plan(name, sql)
        result = subprocess.run(self.command, input=sql,
                                cwd=self.workdir, env=self.environment, text=True, capture_output=True, timeout=15)
        self.log(name, {"exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr[-4000:]})
        require(result.returncode == 0, "Controlled SQL failed; inspect the run's public SQL/results.")
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
        return rows

    def object_state(self):
        name = literal(self.function)
        return self.sql("fault-state", f"""SELECT json_build_object(
 'function', (SELECT json_build_object('marker', obj_description(p.oid, 'pg_proc')) FROM pg_proc p
              JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public' AND p.proname = {name} AND p.pronargs = 0),
 'trigger', (SELECT json_build_object('marker', obj_description(t.oid, 'pg_trigger')) FROM pg_trigger t
             WHERE t.tgrelid = 'public.personnel_onboardings'::regclass AND t.tgname = {name} AND NOT t.tgisinternal),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger t WHERE t.tgrelid = 'public.personnel_onboardings'::regclass
                         AND t.tgname LIKE 't2t_d15_parent_delete_fault_%' AND NOT t.tgisinternal));
""")[0]

    def remove_fault(self):
        state = self.object_state()
        require(all(item is None or item.get("marker") == self.marker for item in (state["function"], state["trigger"])),
                "Fault object ownership differs; refusing to drop it.")
        self.sql("fault-remove", f"""BEGIN;
DROP TRIGGER IF EXISTS {self.function} ON public.personnel_onboardings;
DROP FUNCTION IF EXISTS public.{self.function}();
COMMIT;
SELECT json_build_object('event', 'fault-remove-committed');
""")
        after = self.object_state()
        require(after["function"] is None and after["trigger"] is None, "Fault cleanup did not remove both owned objects.")
        return after

    def snapshot(self, name):
        packet_ids = ",".join(literal(row["id"]) + "::uuid" for row in self.seed["packets"])
        progress_ids = ",".join(literal(row["id"]) + "::uuid" for row in self.seed["progress"])
        return self.sql(name, f"""SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ({packet_ids})) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ({progress_ids})) s), '[]'::json));
""")[0]

    def fresh(self):
        before = self.snapshot("before")
        packets = [row for row in before["packets"] if row["id"] == self.target_id]
        require(len(packets) == 1 and packets[0]["organization_id"] == self.org and packets[0]["status"] == "cancelled"
                and packets[0]["completed_at"] is None and instant(packets[0]["cancelled_at"]) == EXPIRED_AT,
                "Target is missing/changed; use a fresh recorded retention seed.")
        actual = [row for row in before["progress"] if row["onboarding_id"] == self.target_id]
        require(sorted(row["id"] for row in actual) == self.witness_ids, "Fresh target progress witness is missing.")
        expected = {row["id"]: row for row in self.seed["progress"] if row["onboarding_id"] == self.target_id}
        require(all(all(row.get(key) == value for key, value in expected[row["id"]].items()) for row in actual),
                "Target progress differs from its seed capture; use a fresh seed.")
        return before

    def fault_on(self):
        self.fresh()
        before = self.object_state()
        require(before["function"] is None and before["trigger"] is None and before["probe_trigger_count"] == 0,
                "A fault object already exists; run fault-off with its original seed first.")
        sql = f"""BEGIN;
CREATE FUNCTION public.{self.function}() RETURNS trigger LANGUAGE plpgsql AS $d15$
BEGIN
  IF OLD.id = {literal(self.target_id)}::uuid AND OLD.organization_id = {literal(self.org)}::uuid THEN
    RAISE EXCEPTION USING ERRCODE = 'P0001', MESSAGE = 't2t-d15 intentional owned seed parent-delete fault';
  END IF;
  RETURN OLD;
END;
$d15$;
COMMENT ON FUNCTION public.{self.function}() IS {literal(self.marker)};
CREATE TRIGGER {self.function} BEFORE DELETE ON public.personnel_onboardings FOR EACH ROW
WHEN (OLD.id = {literal(self.target_id)}::uuid AND OLD.organization_id = {literal(self.org)}::uuid)
EXECUTE FUNCTION public.{self.function}();
COMMENT ON TRIGGER {self.function} ON public.personnel_onboardings IS {literal(self.marker)};
COMMIT;
SELECT json_build_object('event', 'fault-install-committed');
"""
        try:
            self.fault_may_be_installed = True
            self.sql("fault-install", sql)
            after = self.object_state()
            require(after["function"] == {"marker": self.marker} and after["trigger"] == {"marker": self.marker},
                    "Fault installation could not be confirmed.")
        except BaseException:
            try:
                cleanup = {"removed": True, "after": self.remove_fault()}
                self.fault_may_be_installed = False
            except BaseException as error:
                cleanup = {"removed": False, **public_error(error), "retry": "fault-off with the same session and seed"}
            self.save("fault-error-cleanup.json", cleanup)
            raise
        return {"status": "INSTALLED", "target_id": self.target_id, "function_and_trigger": self.function,
                "cleanup_required": True, "cleanup": "fault-off with the same session and seed BEFORE clean-seeds", "after": after}

    def cron(self, results):
        try:
            credential = read_json(self.session / "archive-cleanup.json")
            require(isinstance(credential.get("secret"), str) and bool(credential["secret"]), "Owned cron credential is unavailable.")
            code, _, body = http(Request(self.worker["origin"].rstrip("/") + ENDPOINT,
                                        headers={"Authorization": "Bearer " + credential["secret"]}), 90)
            result = {"endpoint": ENDPOINT, "status": code, "body": body, "at": stamp()}
        except BaseException as error:
            result = {"endpoint": ENDPOINT, "error_type": type(error).__name__, "at": stamp()}
        self.save("cron-result.json", result)
        results.append(result)

    def race(self, transition):
        before = self.fresh()
        require(self.object_state()["probe_trigger_count"] == 0, "A D15 fault trigger remains; remove it before race proof.")
        existing = self.sql("holder-preflight", f"SELECT json_build_object('count', count(*)) FROM pg_stat_activity WHERE application_name = {literal(self.app_name)};\n")[0]
        require(existing["count"] == 0, "This seed already has a probe backend; resolve it before starting another probe.")
        holder = None
        request = None
        results = []
        committed = False
        cleanup = {}
        try:
            recent = datetime.now(timezone.utc).isoformat()
            change = "status = 'in_progress', cancelled_at = NULL" if transition == "in-progress" else "status = 'cancelled', cancelled_at = " + literal(recent) + "::timestamptz"
            start_sql = f"""SET application_name = {literal(self.app_name)};
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
UPDATE public.personnel_onboardings SET {change}
WHERE id = {literal(self.target_id)}::uuid AND organization_id = {literal(self.org)}::uuid
  AND status = 'cancelled' AND cancelled_at = {literal(EXPIRED_AT.isoformat())}::timestamptz AND completed_at IS NULL
RETURNING json_build_object('event', 'updated', 'id', id, 'status', status, 'cancelled_at', cancelled_at);
SELECT json_build_object('event', 'holder-ready', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
"""
            holder = Holder(self, start_sql)
            holder.send(start_sql)
            ready, events = holder.until("holder-ready", 15)
            holder.identity = ready
            require(sum(item.get("event") == "updated" and item.get("id") == self.target_id for item in events) == 1,
                    "Held update did not change exactly the selected seed row.")
            pid = ready["pid"]
            require(type(pid) is int and pid > 0, "Invalid held backend PID.")
            self.save("cron-request.json", {"method": "GET", "url": self.worker["origin"].rstrip("/") + ENDPOINT,
                                            "authorization": "owned generated cleanup secret withheld", "at": stamp(),
                                            "transition": transition, "target_id": self.target_id, "holder_pid": pid})
            request = threading.Thread(target=self.cron, args=(results,), daemon=True)
            request.start()
            # Read query text only as a boolean inside PostgreSQL; never return it.
            observer = f"""SELECT json_build_object('waiting', COALESCE(json_agg(json_build_object(
 'pid', a.pid, 'wait_event_type', a.wait_event_type, 'wait_event', a.wait_event,
 'blocked_by_holder', {pid} = ANY(pg_blocking_pids(a.pid)), 'parent_delete', true)), '[]'::json))
FROM pg_stat_activity a WHERE a.datname = 'postgres' AND a.pid <> {pid}
 AND a.state = 'active' AND a.wait_event_type = 'Lock' AND {pid} = ANY(pg_blocking_pids(a.pid))
 AND a.query ~* 'delete[[:space:]]+from[[:space:]]+("?public"?[.])?"?personnel_onboardings"?([[:space:]]|$)';
"""
            deadline = time.monotonic() + 45
            waiting = []
            while time.monotonic() < deadline:
                waiting = self.sql("parent-delete-wait", observer)[0]["waiting"]
                if waiting:
                    break
                require(not results, "Cron finished before the expected parent-delete wait; transaction will roll back.")
                require(holder.process.poll() is None, "Held transaction exited before the expected parent-delete wait.")
                time.sleep(0.25)
            require(bool(waiting), "Expected cron parent DELETE did not wait within 45 seconds; transaction will roll back.")
            self.save("observed-parent-delete-wait.json", {"waiting": waiting, "holder": ready, "at": stamp()})
            visible = self.snapshot("committed-view-before-release")
            old = [row for row in visible["packets"] if row["id"] == self.target_id]
            require(len(old) == 1 and old[0]["status"] == "cancelled" and instant(old[0]["cancelled_at"]) == EXPIRED_AT,
                    "Old eligible committed row was not visible while the DELETE waited; transaction will roll back.")
            commit = "COMMIT;\nSELECT json_build_object('event', 'holder-committed');\n"
            self.plan("holder-commit", commit)
            holder.send(commit)
            holder.until("holder-committed", 10)
            committed = True
            request.join(95)
            require(bool(results), "Cron request did not finish; inspect cleanup evidence.")
            after = self.snapshot("after")
            retained = [row for row in after["packets"] if row["id"] == self.target_id]
            original_progress = [row for row in before["progress"] if row["onboarding_id"] == self.target_id]
            final_progress = [row for row in after["progress"] if row["onboarding_id"] == self.target_id]
            return {"status": "OBSERVED", "transition": transition, "target_id": self.target_id,
                    "parent_delete_wait_observed": True, "holder_update_committed": True, "cron": results[0],
                    "target_packet_survived": len(retained) == 1,
                    "target_progress_unchanged": final_progress == original_progress,
                    "target_progress_before": [row["id"] for row in original_progress],
                    "target_progress_after": [row["id"] for row in final_progress], "target_packet_after": retained}
        finally:
            if holder:
                try:
                    cleanup = holder.close(committed)
                except BaseException as error:
                    cleanup = {"holder_started": True, "holder_absent": False, **public_error(error),
                               "recovery": "Inspect recorded holder identity and cleanup SQL; 90s idle transaction timeout is a backstop."}
            else:
                cleanup = {"holder_started": False}
            if request:
                request.join(10)
                cleanup["cron_request_finished"] = not request.is_alive()
                cleanup["cron_result_recorded"] = bool(results)
            self.save("race-cleanup.json", cleanup)
            require(cleanup.get("holder_absent", not holder), "Held backend remains; cleanup is incomplete and recorded.")
            require(not request or not request.is_alive(), "Cron request remains unfinished; cleanup is incomplete and recorded.")


class Holder:
    def __init__(self, probe, sql):
        self.probe = probe
        self.identity = None
        self.lines = queue.Queue()
        self.probe.plan("holder-start", sql)
        self.process = subprocess.Popen(probe.command, cwd=probe.workdir, env=probe.environment,
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, bufsize=1)
        self.reader = threading.Thread(target=self.collect, daemon=True)
        self.reader.start()

    def collect(self):
        for line in self.process.stdout:
            self.probe.log("holder", {"line": line.rstrip("\n")})
            self.lines.put(line)
        self.lines.put(None)

    def send(self, sql):
        self.process.stdin.write(sql)
        self.process.stdin.flush()

    def until(self, event, timeout):
        deadline = time.monotonic() + timeout
        events = []
        while time.monotonic() < deadline:
            try:
                line = self.lines.get(timeout=max(0.01, deadline - time.monotonic()))
            except queue.Empty:
                break
            require(line is not None, "Held psql connection ended; inspect its recorded output.")
            if not line.strip().startswith("{"):
                continue
            value = json.loads(line)
            events.append(value)
            if value.get("event") == event:
                return value, events
        raise Blocked("Held psql did not report " + event + " within its bounded wait.")

    def close(self, committed):
        result = {"holder_started": True, "update_commit_confirmed": committed, "rollback_confirmed": False}
        if self.process.poll() is None and not committed:
            rollback = "ROLLBACK;\nSELECT json_build_object('event', 'holder-rolled-back');\n"
            self.probe.plan("holder-rollback", rollback)
            try:
                self.send(rollback)
                self.until("holder-rolled-back", 5)
                result["rollback_confirmed"] = True
            except BaseException as error:
                result["rollback_error"] = public_error(error)
        try:
            if self.process.poll() is None:
                self.send("\\q\n")
                self.process.stdin.close()
            self.process.wait(timeout=5)
        except BaseException:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        # A killed docker client alone does not prove its in-container backend exited.
        # Restrict recovery to this connection's PID + backend_start + application_name.
        if self.identity:
            pid = self.identity["pid"]
            started = literal(self.identity["backend_start"]) + "::timestamptz"
            condition = f"pid = {pid} AND backend_start = {started} AND application_name = {literal(self.probe.app_name)}"
            recovered = self.probe.sql("holder-cleanup", f"""SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE {condition};
""")[0]
            result["backend_cleanup"] = recovered
            result["holder_absent"] = self.probe.sql("holder-absent", f"SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE {condition}));\n")[0]["absent"]
        else:
            # If ready was never received, recover by this seed-specific name; no other
            # probe is permitted concurrently. The 90s idle timeout is a final backstop.
            recovered = self.probe.sql("holder-cleanup-unready", f"""SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE application_name = {literal(self.probe.app_name)} AND usename = 'supabase_admin';
""")[0]
            result["backend_cleanup"] = recovered
            result["holder_absent"] = self.probe.sql("holder-unready-absent", f"SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = {literal(self.probe.app_name)} AND usename = 'supabase_admin'));\n")[0]["absent"]
        return result


def interrupted(signum, frame):
    raise Blocked("Probe interrupted; bounded transaction cleanup will run.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("fault-on", "fault-off", "race"))
    parser.add_argument("--session", required=True)
    parser.add_argument("--seed", required=True, help="Saved control.mjs seed onboarding-retention JSON output")
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--transition", choices=("in-progress", "recent-cancelled"), default="in-progress")
    args = parser.parse_args()
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    probe = None
    try:
        # Retain the evidence location even if ownership/input validation blocks.
        probe = Probe.__new__(Probe)
        probe.__init__(args)
        if args.mode == "fault-on":
            result = probe.fault_on()
        elif args.mode == "fault-off":
            result = {"status": "REMOVED", "target_id": probe.target_id, "after": probe.remove_fault()}
        else:
            result = probe.race(args.transition)
        probe.save("result.json", result)
        print(json.dumps({**result, "evidence": str(probe.run)}, indent=2))
        return 0
    except BaseException as error:
        # Do not report private HTTP headers, configuration, or credentials.
        failure = {"status": "BLOCKED", **public_error(error)}
        if probe and hasattr(probe, "run"):
            # Includes interruptions after successful installation but before reporting it.
            if getattr(probe, "fault_may_be_installed", False):
                try:
                    cleanup = {"removed": True, "after": probe.remove_fault()}
                    probe.fault_may_be_installed = False
                except BaseException as cleanup_error:
                    cleanup = {"removed": False, **public_error(cleanup_error),
                               "retry": "fault-off with the same session and seed BEFORE clean-seeds"}
                probe.save("fault-final-cleanup.json", cleanup)
                failure["fault_cleanup"] = cleanup
            probe.save("failure.json", failure)
            failure["evidence"] = str(probe.run)
        print(json.dumps(failure, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
