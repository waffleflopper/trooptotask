#!/usr/bin/env node
// One-off lower-level proof. Run only after the coordinator freezes an owned verify:app worker.
// This calls real source and PostgREST; it earns no browser/UI or remote-database credit.
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { createClient } from '@supabase/supabase-js';
import { createServer } from 'vite';
import {
	repository,
	sessionPath,
	readJSON,
	writeJSON,
	processIdentity,
	candidate,
	assertCurrentCandidate,
	environment,
	cleanEnvironment
} from '../../scripts/verification/core.mjs';
import { provider } from '../../scripts/verification/fixtures.mjs';

const columns = [
	'id',
	'organization_id',
	'rated_person_id',
	'eval_type',
	'rater_person_id',
	'rater_name',
	'senior_rater_person_id',
	'senior_rater_name',
	'intermediate_rater_person_id',
	'intermediate_rater_name',
	'reviewer_person_id',
	'reviewer_name',
	'rating_period_start',
	'rating_period_end',
	'status',
	'notes',
	'report_type',
	'workflow_status',
	'created_at',
	'updated_at'
];
const mutableMembershipFields = ['role', 'member_preset', 'capability_overrides'];
const self = fileURLToPath(import.meta.url);
const sha = async (file) =>
	createHash('sha256')
		.update(await fs.readFile(file))
		.digest('hex');
const checked = (response) => {
	if (response.error) throw new Error('Provider operation failed; raw diagnostics suppressed.');
	return response.data;
};
const patchOf = (row) => Object.fromEntries(mutableMembershipFields.map((field) => [field, row[field]]));
const same = (actual, expected) => assert.deepEqual(actual, expected);

async function owned(worker, session, initialId) {
	const state = await readJSON(path.join(session, 'session.json'));
	assert.equal(state.repository, repository);
	assert.equal(state.worker, worker);
	assert.equal(state.phase, 'running');
	if (initialId) assert.equal(state.id, initialId);
	assert.equal(await fs.realpath(session), session);
	const identity = await processIdentity(state.supervisor?.pid);
	assert.ok(identity && identity.state !== 'Z');
	assert.equal(identity.start, state.supervisor?.start);
	assert.equal(identity.command, state.supervisor?.command);
	assert.ok(Number.isInteger(state.controlPort) && state.controlPort > 0 && state.controlPort < 65536);
	const response = await fetch(`http://127.0.0.1:${state.controlPort}`, {
		method: 'POST',
		headers: { Authorization: `Bearer ${state.token}`, 'Content-Type': 'application/json' },
		body: JSON.stringify({ command: 'doctor' }),
		signal: AbortSignal.timeout(180000)
	});
	assert.ok(response.ok);
	assert.equal(response.headers.get('X-T2T-Session'), state.id);
	const doctor = await response.json();
	assert.equal(doctor.status, 'PASS');
	assertCurrentCandidate(state, await candidate(), await candidate(path.join(session, 'app')));
	return state;
}

async function outputFile(name) {
	const root = path.join(repository, '.verification/evidence/verify-trooptotask');
	const file = path.resolve(repository, name);
	assert.ok(file.startsWith(root + path.sep) && file.endsWith('.json'));
	// Refuse existing symlink ancestors before creating the evidence directory.
	for (let current = path.dirname(file); ; current = path.dirname(current)) {
		try {
			assert.equal(await fs.realpath(current), current);
		} catch (error) {
			if (error.code !== 'ENOENT') throw error;
		}
		if (current === repository) break;
	}
	await fs.mkdir(path.dirname(file), { recursive: true, mode: 0o700 });
	assert.equal(await fs.realpath(path.dirname(file)), path.dirname(file));
	return { file, handle: await fs.open(file, 'wx', 0o600) };
}

async function noDotenv(directory) {
	for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
		assert.ok(!entry.name.startsWith('.env'));
		if (entry.isDirectory() && !['.svelte-kit', '.vercel', 'node_modules', '.git'].includes(entry.name))
			await noDotenv(path.join(directory, entry.name));
	}
}

async function run(options) {
	const worker = options.worker;
	const session = sessionPath(worker);
	const scriptSha = await sha(self);
	assert.match(options['expected-sha'] ?? '', /^[a-f0-9]{64}$/);
	assert.equal(scriptSha, options['expected-sha']);
	const output = await outputFile(options.out);
	const result = {
		status: 'RUNNING',
		proofKind: 'actual-provider / real-owner-and-coordinator / not-UI',
		command: [
			'node',
			'.verification/scratch/d16-review-probe.mjs',
			'--worker',
			worker,
			'--expected-sha',
			scriptSha,
			'--out',
			path.relative(repository, output.file)
		],
		scriptSha256: scriptSha,
		startedAt: new Date().toISOString(),
		limits: [
			'No independent browser execution or notification/audit persistence claim.',
			'Audit and notification ports capture coordinator requests only.',
			'No atomic approve/deny serialization or remote/schema replay claim.',
			'Only this worker fixture orgAdmin membership and this tagged witness are mutated.'
		],
		network: [],
		checks: {},
		cleanup: { status: 'NOT_STARTED' }
	};
	let stage = 'ownership';
	let state, service, fixture, originalMembership, baseline, vite;
	let membershipTouched = false;
	let probeEntryId, probeRequestId, tag, ledger;
	const previousCwd = process.cwd();
	const previousEnvironment = { ...process.env };
	const audit = [];
	const notifications = [];
	let phase = 'admission';
	let failure = false;
	const inheritedAllowed = cleanEnvironment();
	const membershipQuery = () =>
		service
			.from('organization_memberships')
			.select('*')
			.eq('organization_id', fixture.ids.orgA)
			.eq('id', fixture.ids.orgAdminMembership)
			.eq('user_id', fixture.actors.orgAdmin.id)
			.single();
	const entryQuery = () =>
		service
			.from('rating_scheme_entries')
			.select(columns.join(','))
			.eq('organization_id', fixture.ids.orgA)
			.eq('id', probeEntryId)
			.maybeSingle();
	const requestQuery = () =>
		service
			.from('deletion_requests')
			.select('*')
			.eq('organization_id', fixture.ids.orgA)
			.eq('id', probeRequestId)
			.maybeSingle();
	const neighbors = async () => {
		const rows = {};
		for (const key of ['orgA', 'orgB']) {
			rows[key] = checked(
				await service
					.from('rating_scheme_entries')
					.select(columns.join(','))
					.eq('organization_id', fixture.ids[key])
					.neq('id', probeEntryId)
					.order('id')
			);
			for (const row of rows[key]) same(Object.keys(row).sort(), [...columns].sort());
		}
		return rows;
	};
	const restoreMembership = async () => {
		if (!membershipTouched) return;
		checked(
			await service
				.from('organization_memberships')
				.update(patchOf(originalMembership))
				.eq('organization_id', fixture.ids.orgA)
				.eq('id', fixture.ids.orgAdminMembership)
				.eq('user_id', fixture.actors.orgAdmin.id)
				.select('id')
				.single()
		);
		same(checked(await membershipQuery()), originalMembership);
	};
	try {
		state = await owned(worker, session);
		// provider() validates the exact local project, config hash, container identities, and loopback URL.
		service = await provider(session);
		const config = await readJSON(path.join(session, 'provider.json'));
		const marker = await readJSON(path.join(session, 'environment.json'));
		const api = new URL(config.API_URL);
		assert.equal(api.protocol, 'http:');
		assert.equal(api.hostname, '127.0.0.1');
		assert.ok(!api.username && !api.password && !api.search && !api.hash);
		assert.equal(Number(api.port), marker.ports['api.port']);
		fixture = await readJSON(path.join(session, 'fixtures.json'));
		assert.equal(fixture.actors.orgAdmin.organization, 'orgA');
		assert.notEqual(fixture.ids.orgA, fixture.ids.orgB);
		assert.notEqual(fixture.ids.orgAdminMembership, fixture.ids.orgOwnerMembership);
		originalMembership = checked(await membershipQuery());
		assert.equal(originalMembership.role, 'admin');
		assert.equal(originalMembership.email, fixture.actors.orgAdmin.email);
		const person = checked(
			await service
				.from('personnel')
				.select('id,organization_id,archived_at')
				.eq('id', fixture.ids.personA)
				.eq('organization_id', fixture.ids.orgA)
				.single()
		);
		assert.equal(person.archived_at, null);
		result.session = {
			id: state.id,
			worker,
			origin: state.origin,
			revision: state.revision,
			candidate: state.candidate,
			artifact: state.artifact,
			sourceDigest: state.sourceDigest,
			buildDigest: state.buildDigest,
			providerProject: marker.project,
			providerApiPort: Number(api.port)
		};
		result.actor = {
			userId: fixture.actors.orgAdmin.id,
			orgId: fixture.ids.orgA,
			membershipId: fixture.ids.orgAdminMembership,
			admittedRole: 'admin'
		};
		result.membershipBefore = originalMembership;
		probeEntryId = randomUUID();
		probeRequestId = randomUUID();
		tag = `Synthetic D16 review revocation ${randomUUID()}`;
		result.witness = { entryId: probeEntryId, requestId: probeRequestId, tag };
		baseline = await neighbors();
		assert.equal(baseline.orgA.length, 9);
		assert.equal(baseline.orgB.length, 1);
		result.neighborsBefore = baseline;
		result.ratingFieldCount = columns.length;
		ledger = path.join(session, `d16-review-probe-${probeEntryId}.json`);
		await writeJSON(ledger, {
			sessionId: state.id,
			orgId: fixture.ids.orgA,
			membershipId: fixture.ids.orgAdminMembership,
			userId: fixture.actors.orgAdmin.id,
			originalMembership,
			entryId: probeEntryId,
			requestId: probeRequestId,
			tag,
			status: 'PREPARED'
		});

		stage = 'load-real-source';
		const copy = path.join(session, 'app');
		assert.equal(await fs.realpath(copy), copy);
		await noDotenv(copy);
		for (const key of Object.keys(process.env)) delete process.env[key];
		Object.assign(process.env, {
			...inheritedAllowed,
			PUBLIC_SUPABASE_URL: config.API_URL,
			PUBLIC_SUPABASE_ANON_KEY: config.ANON_KEY,
			SUPABASE_SERVICE_ROLE_KEY: config.SERVICE_ROLE_KEY,
			APP_PUBLIC_ORIGIN: state.origin,
			PUBLIC_APP_ORIGIN: '',
			PUBLIC_SITE_URL: '',
			APP_PUBLIC_ORIGIN_ALLOWLIST: '',
			NODE_ENV: 'production'
		});
		process.chdir(copy);
		// Middleware SSR only: no app listener, UI drive, build, or root maintenance dotenv.
		const quietLogger = {
			info() {},
			warn() {},
			warnOnce() {},
			error() {},
			clearScreen() {},
			hasErrorLogged: () => true,
			hasWarned: false
		};
		vite = await createServer({
			root: copy,
			configFile: path.join(copy, 'vite.config.ts'),
			envDir: copy,
			server: { middlewareMode: true, hmr: false, watch: null },
			appType: 'custom',
			logLevel: 'silent',
			customLogger: quietLogger
		});
		const owner = await vite.ssrLoadModule('/src/features/rating-scheme/index.server.ts');
		assert.equal(typeof owner.createApprovedRatingSchemeDeletionPort, 'function');
		const { approveDeletionRequest } = await vite.ssrLoadModule('/src/lib/server/core/useCases/deletionRequests.ts');
		const { createSupabaseDataStore } = await vite.ssrLoadModule('/src/lib/server/adapters/supabaseDataStore.ts');
		const { createPermissionContextFromMembership } = await vite.ssrLoadModule('/src/lib/server/permissionContext.ts');
		result.modules = [
			'src/features/rating-scheme/index.server.ts',
			'src/lib/server/core/useCases/deletionRequests.ts',
			'src/lib/server/adapters/supabaseDataStore.ts',
			'src/lib/server/permissionContext.ts'
		];
		const realFetch = globalThis.fetch;
		const authenticated = createClient(config.API_URL, config.ANON_KEY, {
			auth: { persistSession: false, autoRefreshToken: false },
			global: {
				fetch: async (input, init) => {
					const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
					assert.equal(url.origin, api.origin);
					const response = await realFetch(input, init);
					const table = url.pathname.match(/^\/rest\/v1\/(rating_scheme_entries|deletion_requests)$/)?.[1];
					if (table)
						result.network.push({
							phase,
							table,
							method: init?.method ?? (input instanceof Request ? input.method : 'GET'),
							status: response.status
						});
					return response;
				}
			}
		});
		const signIn = await authenticated.auth.signInWithPassword({
			email: fixture.actors.orgAdmin.email,
			password: fixture.actors.orgAdmin.password
		});
		assert.ok(!signIn.error);
		assert.equal(signIn.data.user?.id, fixture.actors.orgAdmin.id);
		const realStore = createSupabaseDataStore(authenticated);
		const auth = Object.freeze({
			userId: fixture.actors.orgAdmin.id,
			orgId: fixture.ids.orgA,
			...createPermissionContextFromMembership(originalMembership)
		});
		assert.equal(auth.role, 'admin');
		const guardedFindOne = async (table, orgId, filters, select) => {
			assert.equal(table, 'deletion_requests');
			assert.equal(orgId, fixture.ids.orgA);
			assert.equal(filters.id, probeRequestId);
			return realStore.findOne(table, orgId, filters, select);
		};
		// Transparent guards delegate every permitted read/write to the real authenticated adapter.
		const coordinatorStore = {
			findOne: guardedFindOne,
			update: async (table, orgId, id, data, select) => {
				assert.equal(table, 'deletion_requests');
				assert.equal(orgId, fixture.ids.orgA);
				assert.equal(id, probeRequestId);
				return realStore.update(table, orgId, id, data, select);
			}
		};
		const ctx = {
			auth,
			store: coordinatorStore,
			audit: { log: (event) => audit.push(structuredClone(event)) },
			notifications: {
				notifyUser: async (orgId, userId, notification) => {
					notifications.push({ orgId, userId, notification: structuredClone(notification) });
				}
			}
		};

		stage = 'setup-tagged-witness';
		await environment('status', session);
		const today = fixture.dates.ui;
		assert.match(today, /^\d{4}-\d{2}-\d{2}$/);
		const end = new Date(today + 'T12:00:00Z');
		end.setUTCDate(end.getUTCDate() + 90);
		checked(
			await service.from('rating_scheme_entries').insert({
				id: probeEntryId,
				organization_id: fixture.ids.orgA,
				rated_person_id: fixture.ids.personA,
				eval_type: 'NCOER',
				rater_person_id: null,
				rater_name: 'Synthetic External Probe Rater',
				senior_rater_person_id: null,
				senior_rater_name: 'Synthetic External Probe Senior Rater',
				intermediate_rater_person_id: null,
				intermediate_rater_name: null,
				reviewer_person_id: null,
				reviewer_name: null,
				rating_period_start: today,
				rating_period_end: end.toISOString().slice(0, 10),
				status: 'active',
				notes: tag,
				report_type: 'AN',
				workflow_status: 'drafting'
			})
		);
		checked(
			await service.from('deletion_requests').insert({
				id: probeRequestId,
				organization_id: fixture.ids.orgA,
				requested_by: fixture.actors.orgAdmin.id,
				requested_by_email: fixture.actors.orgAdmin.email,
				resource_type: 'rating_scheme_entry',
				resource_id: probeEntryId,
				resource_description: tag,
				resource_url: `/org/${fixture.ids.orgA}/evals`,
				status: 'pending'
			})
		);
		const originalEntry = checked(await entryQuery());
		const originalRequest = checked(await requestQuery());
		assert.ok(originalEntry && originalRequest);
		same(Object.keys(originalEntry).sort(), [...columns].sort());
		result.entryBefore = originalEntry;
		result.requestBefore = originalRequest;
		const deletionGuard = (table, orgId, id) => {
			assert.equal(table, 'rating_scheme_entries');
			assert.equal(orgId, fixture.ids.orgA);
			assert.equal(id, probeEntryId);
		};
		let deleteReached = false;
		const revokedPort = owner.createApprovedRatingSchemeDeletionPort({
			findOne: guardedFindOne,
			delete: async (table, orgId, id) => {
				deletionGuard(table, orgId, id);
				assert.equal(deleteReached, false);
				deleteReached = true;
				// The real owner passed its exact pending check. Change only the known live membership now.
				same(checked(await requestQuery()), originalRequest);
				membershipTouched = true;
				checked(
					await service
						.from('organization_memberships')
						.update({
							role: 'member',
							member_preset: 'viewer',
							capability_overrides: {}
						})
						.eq('organization_id', fixture.ids.orgA)
						.eq('id', fixture.ids.orgAdminMembership)
						.eq('user_id', fixture.actors.orgAdmin.id)
						.select('id')
						.single()
				);
				const downgraded = checked(await membershipQuery());
				assert.equal(downgraded.role, 'member');
				assert.equal(downgraded.member_preset, 'viewer');
				const liveAccess = createPermissionContextFromMembership(downgraded);
				assert.equal(liveAccess.capabilityMap.ratingScheme, 'view');
				assert.equal(liveAccess.isPrivileged, false);
				result.membershipDowngraded = downgraded;
				result.capturedActorRoleAtDelete = auth.role;
				await realStore.delete(table, orgId, id);
			}
		});
		stage = 'revoked-review';
		phase = 'revoked-review';
		let rejected = false;
		try {
			await approveDeletionRequest(ctx, probeRequestId, undefined, revokedPort);
		} catch {
			rejected = true;
		}
		assert.equal(deleteReached, true);
		assert.equal(rejected, true);
		const deniedEntry = checked(await entryQuery());
		const deniedRequest = checked(await requestQuery());
		same(deniedEntry, originalEntry);
		same(deniedRequest, originalRequest);
		same(await realStore.findOne('deletion_requests', fixture.ids.orgA, { id: probeRequestId }), originalRequest);
		same(audit, []);
		same(notifications, []);
		same(await neighbors(), baseline);
		assert.ok(
			result.network.some(
				(row) =>
					row.phase === phase && row.table === 'rating_scheme_entries' && row.method === 'DELETE' && row.status === 204
			)
		);
		assert.ok(
			result.network.some(
				(row) => row.phase === phase && row.table === 'deletion_requests' && row.method === 'PATCH' && row.status >= 400
			)
		);
		result.revoked = {
			rejected,
			entry: deniedEntry,
			request: deniedRequest,
			ownPendingRequestStillSelectable: true,
			auditRequests: [],
			notificationRequests: []
		};
		result.checks.liveRevocationRetainsTargetAndRequest = 'PASS';

		stage = 'restored-review';
		await restoreMembership();
		result.membershipRestored = checked(await membershipQuery());
		phase = 'restored-review';
		const restoredPort = owner.createApprovedRatingSchemeDeletionPort({
			findOne: guardedFindOne,
			delete: async (table, orgId, id) => {
				deletionGuard(table, orgId, id);
				await realStore.delete(table, orgId, id);
			}
		});
		const reviewStartedAt = new Date().toISOString();
		await approveDeletionRequest(ctx, probeRequestId, undefined, restoredPort);
		assert.equal(checked(await entryQuery()), null);
		const approved = checked(await requestQuery());
		assert.equal(approved.status, 'approved');
		assert.equal(approved.reviewed_by, fixture.actors.orgAdmin.id);
		assert.equal(approved.denial_reason, null);
		assert.ok(Date.parse(approved.reviewed_at) >= Date.parse(reviewStartedAt));
		assert.ok(Date.parse(approved.reviewed_at) <= Date.now());
		const expectedApproved = {
			...originalRequest,
			status: 'approved',
			reviewed_by: fixture.actors.orgAdmin.id,
			reviewed_at: approved.reviewed_at,
			denial_reason: null
		};
		same(approved, expectedApproved);
		assert.equal(audit.length, 1);
		assert.equal(audit[0].action, 'deletion_request.approved');
		assert.equal(audit[0].resourceId, probeRequestId);
		assert.equal(notifications.length, 1);
		assert.equal(notifications[0].orgId, fixture.ids.orgA);
		assert.equal(notifications[0].userId, fixture.actors.orgAdmin.id);
		assert.equal(notifications[0].notification.type, 'deletion_approved');
		result.restored = {
			entry: null,
			request: approved,
			auditRequests: audit,
			notificationRequests: notifications,
			sameCapturedActorAndAuthenticatedClient: true
		};
		result.coordinatorApprovalAttempts = 2;
		result.checks.restoredApprovalDeletesOnlyWitness = 'PASS';
	} catch {
		failure = true;
		result.failure = { stage, detail: 'Assertion or provider/source operation failed; raw diagnostics suppressed.' };
	} finally {
		phase = 'cleanup';
		if (service && fixture && originalMembership && probeEntryId && probeRequestId) {
			try {
				await environment('status', session);
				await restoreMembership();
				// Service cleanup is limited to both exact tagged witness IDs, never an original seeded row.
				checked(
					await service
						.from('deletion_requests')
						.delete()
						.eq('organization_id', fixture.ids.orgA)
						.eq('id', probeRequestId)
						.eq('resource_type', 'rating_scheme_entry')
						.eq('resource_id', probeEntryId)
						.eq('requested_by', fixture.actors.orgAdmin.id)
						.eq('resource_description', tag)
				);
				checked(
					await service
						.from('rating_scheme_entries')
						.delete()
						.eq('organization_id', fixture.ids.orgA)
						.eq('id', probeEntryId)
						.eq('notes', tag)
				);
				assert.equal(checked(await requestQuery()), null);
				assert.equal(checked(await entryQuery()), null);
				same(checked(await membershipQuery()), originalMembership);
				const after = await neighbors();
				if (baseline) same(after, baseline);
				result.neighborsAfter = after;
				result.cleanup = {
					status: 'PASS',
					membershipExact: true,
					entryAbsent: true,
					requestAbsent: true,
					seedRowsAll20FieldsExact: Boolean(baseline),
					orgACount: after.orgA.length,
					orgBCount: after.orgB.length
				};
				if (ledger)
					await writeJSON(ledger, {
						sessionId: state.id,
						orgId: fixture.ids.orgA,
						membershipId: fixture.ids.orgAdminMembership,
						userId: fixture.actors.orgAdmin.id,
						originalMembership,
						entryId: probeEntryId,
						requestId: probeRequestId,
						tag,
						status: 'CLEANED'
					});
			} catch {
				failure = true;
				result.cleanup = {
					status: 'FAIL',
					privateRecoveryLedger: ledger ? path.basename(ledger) : null,
					detail: 'Restore/cleanup verification failed. Retain the owned worker for coordinator recovery.'
				};
			}
		}
		try {
			await vite?.close();
		} catch {
			failure = true;
			result.ssrClose = 'FAIL';
		}
		process.chdir(previousCwd);
		for (const key of Object.keys(process.env)) delete process.env[key];
		Object.assign(process.env, previousEnvironment);
		try {
			if (state) await owned(worker, session, state.id);
			assert.equal(await sha(self), scriptSha);
			result.finalDoctorAndFrozenScript = state ? 'PASS' : 'NOT_RUN';
		} catch {
			failure = true;
			result.finalDoctorAndFrozenScript = 'FAIL';
		}
		result.status = failure ? 'FAIL' : 'PASS';
		result.finishedAt = new Date().toISOString();
		await output.handle.writeFile(JSON.stringify(result, null, 2) + '\n');
		await output.handle.close();
	}
	console.log(
		JSON.stringify({
			status: result.status,
			proofKind: result.proofKind,
			file: path.relative(repository, output.file),
			scriptSha256: scriptSha,
			candidate: state?.candidate,
			cleanup: result.cleanup.status
		})
	);
	if (failure) process.exitCode = 1;
}

try {
	const { values } = parseArgs({
		options: {
			worker: { type: 'string', default: '1' },
			out: { type: 'string' },
			'expected-sha': { type: 'string' },
			help: { type: 'boolean', short: 'h' }
		}
	});
	if (values.help) {
		console.log(
			'node .verification/scratch/d16-review-probe.mjs --worker 1|2 --expected-sha SHA256 --out .verification/evidence/verify-trooptotask/RUN/review-revocation-provider.json'
		);
	} else {
		assert.ok(values.out);
		await run(values);
	}
} catch {
	console.error(
		'D16 provider probe blocked before completion; raw diagnostics suppressed. Check worker ownership, required arguments, frozen SHA, and the sanitized output if present.'
	);
	process.exitCode = 1;
}
