import json,subprocess,hashlib,time,sys,os
from pathlib import Path
root=Path.cwd();base=root/'.verification/evidence/personnel-detail-ci-recovery';label=sys.argv[1]
paths=['src/features/calendar/components/BulkStatusPage.test.ts','src/features/onboarding/components/OnboardingInteraction.svelte.test.ts','src/features/personnel/components/PersonnelModals.test.ts','src/routes/org/[orgId]/personnel/personnelEditArchive.test.ts','src/features/onboarding/contexts/OnboardingPageContext.svelte.test.ts','src/features/training/components/TrainingPageView.test.ts','src/features/training/contexts/TrainingPageContext.svelte.test.ts']
commands={'reproduce':['npm','exec','vitest','--','run',*paths],'focused-pass':['npm','exec','vitest','--','run',*paths],'format':['npm','exec','prettier','--','--write',*paths],'format-check':['npm','exec','prettier','--','--check',*paths],'types':['npm','run','check'],'lint':['npm','exec','eslint','--',*paths],'diff':['git','diff','--check']}
command=commands[label];assert not (base/(label+'-command.json')).exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','--binary']);(base/(label+'.patch')).write_bytes(patch)
env=os.environ.copy();public={'PUBLIC_SUPABASE_URL':'http://127.0.0.1:9','PUBLIC_SUPABASE_ANON_KEY':'synthetic-ci-recovery-anon-key','TMPDIR':str(root/'.verification/ci-recovery-tmp')};env.update(public);Path(public['TMPDIR']).mkdir(mode=0o700,exist_ok=True)
start=time.time();p=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
(base/(label+'.stdout')).write_text(p.stdout);(base/(label+'.stderr')).write_text(p.stderr)
(base/(label+'-command.json')).write_text(json.dumps({'command':command,'cwd':str(root),'head':head,'workingPatch':label+'.patch','patchSHA256':hashlib.sha256(patch).hexdigest(),'publicOverrides':public,'exit':p.returncode,'durationSeconds':round(time.time()-start,3)},indent=2)+'\n')
print(json.dumps({'label':label,'exit':p.returncode,'durationSeconds':round(time.time()-start,3)}))
print((p.stdout+p.stderr)[-2400:])
sys.exit(p.returncode)
