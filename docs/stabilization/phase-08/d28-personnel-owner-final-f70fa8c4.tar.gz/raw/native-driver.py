import json,subprocess,pathlib,sys,datetime,os
os.environ["PATH"]="/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:"+os.environ["PATH"]
ROOT=pathlib.Path("/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93")
E=ROOT/".verification/evidence/verify-trooptotask/d28-personnel-owner-final-f70fa8c4"
def run(label,cmd):
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);(E/(label+".json")).write_text(r.stdout);(E/(label+".stderr")).write_text(r.stderr);
 with (E/"commands.jsonl").open("a") as f:f.write(json.dumps({"time":datetime.datetime.now(datetime.timezone.utc).isoformat(),"label":label,"argv":cmd,"exit":r.returncode})+"\n")
 print(r.stdout);
 if r.returncode:print(r.stderr);sys.exit(r.returncode)
if __name__=="__main__":
 label,kind,*args=sys.argv[1:]
 cmd=(["npm","run","--silent","verify:app","--"] if kind=="cli" else ["node",".agents/skills/verify-trooptotask/helpers/control.mjs"])+args+["--worker","1"]
 run(label,cmd)
