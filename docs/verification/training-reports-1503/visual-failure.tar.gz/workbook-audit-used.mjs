import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';

const [directory] = process.argv.slice(2);
const expected = [
  { file: 'full-small-roster-1.xlsx', sha: '47598642908bdc58ca23d01884d5784045a583e8e200f885a8ba64222d1eeb62',
    headers: ['Name', 'Rank', 'MOS', 'Duty Role', 'Group', 'Verification Required Training', 'Verification Targeted Training'],
    rows: [['Able, Synthetic', 'SPC', '68W', 'Medic', 'Alpha', 'Current (2027-09-26)', 'Not Done'],
      ['Baker, Synthetic', 'SPC', '11B', 'NCO', 'Bravo', 'Not Done', 'N/A'],
      ['Unassigned, Synthetic', 'SPC', '68W', 'NCO', null, 'Not Done', 'N/A']] },
  { file: 'alpha-required-1.xlsx', sha: 'be7e596771c4de9536a61833d681b5e3219f60056a5a469ac810364b68a46a68',
    headers: ['Name', 'Rank', 'MOS', 'Duty Role', 'Group', 'Verification Required Training'],
    rows: [['Able, Synthetic', 'SPC', '68W', 'Medic', 'Alpha', 'Current (2027-09-26)']] }
];
const observed = [];
for (const item of expected) {
  const bytes = await fs.readFile(`${directory}/downloads/${item.file}`);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), item.sha);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(bytes);
  assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Training Report']);
  const sheet = workbook.worksheets[0];
  const rows = Array.from({ length: sheet.rowCount }, (_, index) =>
    Array.from({ length: sheet.columnCount }, (_, column) => sheet.getRow(index + 1).getCell(column + 1).value));
  assert.deepEqual(rows, [item.headers, ...item.rows]);
  observed.push({ file: item.file, bytes: bytes.length, sha256: item.sha,
    sheet: sheet.name, headers: rows[0], rows: rows.slice(1) });
}
process.stdout.write(JSON.stringify({ status: 'PASS', proof: 'Offline artifact inspection, not browser execution', observed }, null, 2) + '\n');
