#!/usr/bin/env bash
# usage: shot.sh SRC NAME VW L T R B
set -euo pipefail
src=$1 name=$2 vw=$3 l=$4 t=$5 r=$6 b=$7
cp "$src" "png/$name.png"
iw=$(magick identify -format '%w' "png/$name.png")
s=$(python3 -c "print($iw/$vw)")
read x y w h < <(python3 -c "s=$s;l,t,r,b=$l,$t,$r,$b;print(round(l*s),round(t*s),round((r-l)*s),round((b-t)*s))")
z=$(python3 -c "print(6 if $w<260 else 3)")
magick "png/$name.png" -crop "${w}x${h}+${x}+${y}" +repage -filter point -resize "$((z*100))%" "png/$name-zoom.png"
echo "{\"dst\":\"png/$name.png\",\"imgW\":$iw,\"scale\":$s,\"crop\":[$x,$y,$w,$h],\"zoom\":$z}"
