# Independent completion baseline acceptance

Standards GO. Spec GO. Zero consequential findings for the unchanged completion baseline. This verdict does not accept the forthcoming completion persistence implementation, its final native proof, CI, hosted review, merge, or whole-issue closure.

The reviewer operated read-only against source and expanded artifacts. The sole written artifact is this requested local report. No application test, service, browser, provider, database, connector, publication, or child-agent execution occurred. This is same-model artifact acceptance, not independent live execution or model diversity.

## Archive and input provenance

The reviewed archive is `docs/stabilization/phase-08/d28-critical-task-completion-baseline.tar.gz`. Its actual size is 957,071 bytes. Its independently calculated SHA-256 is `aef3085e4e581ca6ce6248a68ba33798c8667bbde20c9e383a4d97b283b14f23`.

The fresh expansion is `/tmp/t2t-phase8-selection/completion-baseline-expanded-_boxkytc`. The tar has exactly 125 regular members. They comprise 124 payloads and `inventory.json`. There are no absolute paths, parent traversal paths, duplicate inventory paths, links, or special members. The archived and expanded file sets are exact. Every expanded file equals its actual archived bytes. All 124 payload sizes and SHA-256 values match the inventory. The inventory itself also equals its archived bytes.

The reviewer read every text payload programmatically and parsed every JSON file. There are 121 text files including the inventory, 83 JSON files including metadata, three PNGs, and one XLSX. All three PNGs were visually inspected. The actual XLSX passed ZIP CRC checks and its worksheet XML was independently decoded. No producer workbook helper or self-certified PASS substituted for that decoding.

`frozen-inputs.json` contains exactly 5,015 distinct inputs. Streaming `git archive 66a238a8fe9915f5dd3994a7d5d62f71c71f7de8` independently matches every recorded input byte count and SHA-256. There are no missing or differing inputs. SHA-256 over each sorted UTF-8 path, NUL, file bytes, and NUL independently reconstructs `e6bf62afba18df1dc6540bf6b6003eb13ccc3ca601db3add6548413ec88d1269`.

Launch, initial doctor, final doctor, and the report-marker recovery doctor consistently report revision `66a238a8fe9915f5dd3994a7d5d62f71c71f7de8`, that candidate, origin `http://127.0.0.1:40411`, session `aff38f93-453d-4e8d-ad5e-a070bdb5ce4a`, and Chromium 152.0.7977.82. The saved owned-session metadata excludes the private session token. Its running phase records its capture time; the later cleanup receipt separately records disposal.

## Native completion actions and provider effects

The reviewer inspected both saved Python drivers, the native tool schema, all action results and snapshots, raw driver logs, fixture fields, and provider row captures. `completion_probe.py` drives visible calendar selections, form fields, dialog Save, native reload, keyboard clearing, and screenshots. Provider observations use the maintained narrow row helper. The drivers do not call application handlers or alter application stores.

The initial matrix exposes Able at 50%, Baker at 0%, and Unassigned at 0%. The original completion is Alpha on 2026-09-14. The warning calendar action chooses 2025-10-20. The form submits Demonstration, `D28 completion baseline validator`, and `D28 completion baseline draft`.

`save-failure-state.json` records the controlled POST 503. The actual failed-click result displays `Synthetic request failure`, retains the dialog and entered values, and contains no saved-success feedback. `save-failed-rows.json` equals `original-completions.json` by every value. After hook restoration, the same visible Save succeeds. The actual click result displays `ICT completion saved`; reload and provider readback retain exactly one new All-MOS record.

The warning row is `b5c2ddc1-c59a-41f1-8aa2-b296758eb59c`. Its creation time is `2026-10-06T00:11:11.689519+00:00`. The visible warning record shows Expiring Soon, expiry 2026-10-20, and Able 100% with one current and one soon. `warning-person.png` independently agrees with the snapshot and raw fields.

The subsequent native edit selects 2024-10-05. Keyboard Control+A and Backspace leave the actual Notes textbox empty before Save. `expired-saved-rows.json` retains the same row ID, creation time, logging identity, validator, Person, and task. The date changes to 2024-10-05 and notes become null. Reload shows Expired, expiry 2025-10-05, and Able 50% with one current and one expired. `expired-person.png` independently agrees. The original Alpha row remains byte-value equivalent throughout failure, warning save, and expired edit.

No raw HTTP 200 receipt is invented for successful native Saves. Native feedback, actual reloads, and provider effects establish those successful actions. The controlled 503 is pre-dispatch failure proof, not a real provider outage or timing measurement.

## Reports and actual download

`expired-report-ready.txt` shows three People, 20% overall, Ready 1, and Applicable 5. `baseline-report.png` visually shows the same values, Able 50%, Baker and Unassigned 0%, and the expected MOS nonapplicability. The denominator is two applicable tasks for Able, one for Baker, and two for Unassigned. Only the original Able/Alpha assignment remains ready after the All-MOS edit becomes expired.

The actual `baseline-report.xlsx` is 7,176 bytes with SHA-256 `5d2f3a546db595b6682752d667d89efc47255998e51a7721ce67c8f46ba0e949`. Its visible sheet is `Critical Tasks Report`. Independent worksheet decoding yields its four headers and nine data rows. Summary Overall Readiness is 20%. Able is 50%; Baker and Unassigned are 0%. All-MOS is 0% with three gaps, Alpha is 50% with one gap, and three Soldiers are below 70%. The values agree with actual source rows and the native report. This workbook has no completion-date cells and no direct Ready/Applicable summary rows. The 1/5 ratio is established by the visible report and independent fixture arithmetic, not invented workbook columns.

## Failed controls, sanitization, and disposal

`driver-attempts.json` retains the wrong initial Able link label before any click. The corresponding fresh snapshot contains the actual Able link. It also retains the failed `Overall Readiness` report wait. `report-ready-wait.json` marks that attempt INCONCLUSIVE. `reports.log` contains its actual timed-out command and traceback. The correct visible marker is `Readiness summary`. The passing recovery doctor, fresh settled report snapshot, corrected export actions, and actual download establish recovery without an application change. These are control failures, not application failures or successful waits.

The reviewer scanned all expanded text for JWT, GitHub token, credential URL, Bearer-value, and private-key patterns. No matches or nonempty sensitive JSON credential fields were found. `sanitization.json` declares no observation redactions. Only generated `__pycache__/native_driver.cpython-314.pyc` was excluded. Both source drivers and actual failure captures remain.

Final doctor passes on the same candidate. `clean-seeds.json` reports cleaned seeds and cleared artifact HTTP sessions. The page-close result leaves only about:blank selected. `cleanup.json` passes with phase cleaned. The archive remains available after disposal. The new completion is disposed with the owned project; the captures do not claim a visible delete action, restoration of that new row, or an immediate final B-row comparison. B source captures establish setup only in this run.

The actual production-build log ends with the adapter completion marker. It retains chunk/plugin notices and the optional OpenTelemetry dependency warning. No deployment, performance, or remote parity result is inferred.

## Scope and retained proof

The prior baseline applicability verdict remains valid. Accepted #1542 proof supplies current task-reference composition, same-date completion import, archive guards, allowed ordinary deletion, dedicated-lane denials, reverse Personnel and Dashboard reads, and current local isolated SQL credit. The baseline completion store and entity mapping remain unchanged from accepted D11. Completion UI and date/import math changes since D11 are Personnel type-import relocation; the operational dependency changes are the accepted task-library cutover and admitted delivery composition.

Accepted D11 actual artifacts retain warning restoration, dated history, null clearing, same-date upsert identity, batch failure/retry, valid viewer and scoped update/delete/batch refusal, archived-Person history and refusal, stale-permission refusal, wide pagination, 500-row partial effects, held-response and Organization switch behavior. D10 contributes configuration/default and draft-lifetime proof, not successful completion-write proof. Historical native, lower-level SDK/component/domain, and local SQL credit stay separate. This new run does not repeat wide, held, permission-change, archive, import, denial, Personnel, Dashboard, or SQL ceremonies.

No consequential native gap blocks the behavior-preserving completion-ledger cutover from this baseline. Final changed-source proof remains required. Installed SDK tests must exercise the actual replacement provider boundary, mapping, missing-row and acknowledgment/error behavior, complete paging, stable ordering, and batch partial effects. A later change to authority, SQL, response lifetime, or date-selection semantics requires renewed focused proof of that changed mechanism.

The cohesive concern includes completion CRUD, batch lookup and writes, history, historical report/workbook/Dashboard reads, targeted Personnel readiness reads, and completion mapping consumed by latest RPC and its test model. Existing RPC implementation, settings, SQL, accepted raw export and retention ownership remain unchanged. Other domain persistence and final generic request/store/scope facade removal remain #1376 obligations. D29 mixed utilities and D30 remain blocked.

## Fresh comment review and principles

The reviewer read the exact installed No Comments skill and portable Comment Sicko prompt. Both produced Python scripts contain zero comments and zero suppressions. Fresh deletion candidates, MUST KILL flags, suppressions, skips, deletions, restorations, reruns, architect sketches, encodings, and unresolved constraints are zero. No tracked source comment cleanup or nested delegation was performed.

Prove It Works selected actual archive bytes, reconstructed inputs, rows, images, and worksheet XML. Boundary Discipline kept native action, ordinary HTTP, privileged provider observation, SQL, and historical reuse claims separate. Test Behavior, Not Implementation selected literal submitted values and independently compared persisted effects rather than trusting producer assertions.
