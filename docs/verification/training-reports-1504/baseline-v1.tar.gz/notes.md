# 1504 baseline v1 working notes
candidate ecb5155b1b4e93c831744c1e4bc036df79064d7871a61a385890597677614f67 / origin http://127.0.0.1:44453 / rev 3cc4ec4c / Chromium 152.0.7977.82
fixture dates: ui 2026-10-04; trainingCompleted 2026-09-27; trainingExpires 2027-09-27; expiredCompleted 2024-10-04; expiredExpires 2025-10-04; warningCompleted 2025-10-19; warningExpires 2026-10-19; warningDays 15
original A rows: 1 (5fdee766 Able/Required 2026-09-27→2027-09-27, notes null, url null); B rows: 0

## P1 live-verified PASS
matrix: Able Req Current(09/2027), Able Tgt Not Done, Able Opt N/A; Baker Req Not Done, Tgt N/A, Opt N/A; Unassigned same as Baker.
report via visible Reports link (client nav: only reports/__data.json, no training-reports summary): 25% ready today → 25% by 2 Jan, Ready1/expired0/notrec3/lapse0, 3 soldiers, Alpha50 Bravo0 Unassigned0, Total Req 33 / Tgt 0.
reload: document GET 200 only + notification-count; server HTML contains Bottom line text and cell aria names.
- operator error: receipt 030 clicked stale uid 8_8 = Toggle Sidebar (not group filter); 032 re-toggled; see p2-sidebar-restored.png
## P2 expectations before action: Alpha group -> Able only, Req ready 1/1, Tgt 0/1 => 50%; +Required type -> 1/1 = 100%, horizon no lapse (expires 2027-09-27)
## P2 live-verified PASS
Alpha via keyboard in group listbox -> URL ?group=<groupA>, 1 soldier, 50%, one api/training-reports GET, no __data.json navigation.
Required via types menu (menu lists only Required+Targeted) -> &types=<required>, 100%, Ready1/0/0/0, grid Alpha+Total Required 100.
30 days -> &horizon=30, BY 3 NOV, nothing lapses. Rows by MOS -> &rowsBy=mos, row 68W 1 soldier 100.
Reload of that URL: document only (no api fetch), same filters/numbers restored.
Visual note: at 100% the Bottom line "→ 100%" wraps under the big figure (desktop 1905 wide); not a failure.
Note: wait_for for "NEXT 30 DAYS" timed out (text-matching), snapshot confirmed.
## P2 narrow390 PASS: Clear filters from Alpha/Required/30/MOS -> URL bare, 3 soldiers, 25%, 90d, Group rows; one api/training-reports GET. Toolbar wraps 3 rows; Export+Clear in header.
## P3 expectation: Total Required -> 2 affected (Baker, Unassigned missing); Alpha Targeted -> 1 (Able missing)
## P3 live-verified PASS (desktop 1440x900)
Total Required click -> GET detail?scope=cell&type=<required> (no row) 200, totalRows 2 Baker/Unassigned Not Done; status "Total, Verification Required Training: 2 requirements not ready or lapsing by 2 Jan."; dashed outline; URL bare.
Alpha Targeted -> detail?scope=cell&row=<groupA>&type=<targeted> 200, 1 row Able Not Done; status line 1 requirement; outline moved. No table (expected baseline).
Observation: selected cell not exposed as pressed/selected in a11y tree (status line carries it).
## P4 live-verified PASS (synthetic browser 503 before dispatch; NOT provider outage)
report: arm-fail training-reports; select Bravo -> alert "Unable to update the briefing" / "(503). Showing the last briefing that loaded." + Retry; numbers stay 25% 3 soldiers; group control back to "All groups"; URL bare; no Clear filters.
export during alert (failure control restored first): GET /api/training-reports/export (no query) 200 -> 3 people = displayed input, not the failed Bravo attempt. p5-default-after-failure.xlsx sha256 1ac4a08d...
Retry (control restored): GET ?group=<bravo> 200 -> URL ?group=<bravo>, 1 soldier, 0%.
detail: Clear filters; arm-fail training-reports/detail; click Total Required -> alert "Unable to load affected soldiers" "(503)" + Retry, outline on cell; restore; Retry -> detail?scope=cell&type=<required> 200, status 2 requirements, alert gone.
## P5 live-verified PASS (visible Export Excel + export capture; independent zip decode p5-workbooks-decoded.json)
default (during P4 alert): GET /export 200, filename training-report-2026-10-04.xlsx, MIME xlsx, 6930B sha 1ac4a08d...; sheet "Training Report" only; headers Name,Rank,MOS,Duty Role,Group,Required,Targeted; Able Current (2027-09-27)/Not Done; Baker Not Done/N/A; Unassigned (group blank) Not Done/N/A. No Optional, no Foreign.
Alpha+Required: GET /export?group=<A>&types=<required> 200, 6805B sha 922605bb...; one row Able, one Training column Required Current (2027-09-27).
export failure: arm-fail training-reports/export -> alert "Unable to export the workbook" "(503)" + Retry; export state captured:false; no toast. restore, arm-observe, visible Retry -> /export 200, 6930B sha 002f291e... same decoded content (zip timestamp differs).
## P6 live-verified PASS (UI admission) + separate read-only same-origin GET probes (HTTP proof)
trainingView: reports admitted, 3 soldiers, 25%, Export Excel present (p6-view-report.*).
trainingScoped (Alpha): reports admitted, 1 soldier, 50%, Ready1/expired0/notrec1, grid Alpha+Total only. Probes 216: summary 50% 1/2; ?group=Bravo -> 200 scopeName "Bravo" soldierCount 0 (empty, group catalog names Alpha/Bravo visible in filterOptions); export -> Able only; export?group=Bravo -> headers only; detail type=Required -> 200 0 rows; detail row=Bravo -> 404 "Training report scope not found".
viewer (no lane): reports page renders 403 "You don't have permission to view this page."; reload document 403; summary/detail/export APIs 403 "requires Training can view".
trainingForeign (B): B report 1 soldier (Foreign), Foreign Private Training only, 0%; zero A names/types in snapshot. Probes 234: B export Foreign only; B ?group=<A group> -> 200 normalized groupId null (whole B); B detail type=<A required> -> 404 scope not found; A summary/export -> 404 "Organization not found".
Observation (baseline, not failure): out-of-scope group in A for scoped is kept as empty "Bravo" scope; unknown group in B is dropped to null.
## P7 live-verified PASS (rosterManager)
Personnel → Able Details: Readiness summary TRAINING "1 due" "Verification Targeted Training not completed." (Required current, Optional ignored).
Baker Details: TRAINING "1 due" "Verification Required Training not completed." (Targeted N/A excluded). Other lanes Unavailable for this actor (no lanes), not Training-related.
Dashboard (visible Home): Training & Evaluations "100% training current", Alpha 100%, Bravo 100%, 0 evals overdue; reload same. Retained currency-of-existing-records meaning; differs from report readiness 25% by design.
What's New modal dismissed per dashboard recipe; preferences rosterManager orgA => [] (no DB row).
Visual note: "0 evals overdue" rendered in red.
Matrix spot-check: see P1 (and final re-read below).
## Optional dated import live-verified PASS, then removed
Import UI (configure): 2-row CSV preview, 2 valid/selected, rows still 1 after preview; Import -> POST personnel-trainings/batch 200, Inserted 2 Updated 0 Exempted 0 Errors 0.
IDs: Baker/Required 983ff0af-db2c-4c8c-a721-31628acceebc 2024-10-04→2025-10-04; Able/Targeted a86af8c5-16d5-42d1-83f6-168bbe1b4c40 2025-10-19→2026-10-19.
Matrix after reload: Baker Req "Expired 365d ago", Able Tgt "15d left".
Report: 50% → 25% by 2 Jan, "loses 25 points in 90 days", Ready2/expired1/notrec1/lapse1; Alpha 100%→50%, Alpha×Targeted "drops 100 points by 2 Jan"; Total Req 33, Tgt 100.
Dated export (visible): 6967B sha 399ad823...; Able Current (2027-09-27) / 15d left (2026-10-19); Baker Expired 365d ago (2025-10-04) / N/A; Unassigned Not Done / N/A.
Cleanup: matrix cell → Delete → "Delete Training Record" Delete for each; DELETE 200; id readback count 0; final orgA rows = original 5fdee766 only, updated_at unchanged; orgB 0; deletion_requests orgA 0.
## Final
final matrix/report re-read = original (25%, 1/0/3/0). All network/export controls disarmed on pages 2-7. Viewport page2 restored to 1905x2053. Doctor PASS same candidate/session.
wait_for receipts 051/083/244/319/373 exited 2 (text-match timeout); each followed by snapshot establishing state. 214 was a malformed evaluate args call (no request sent); rerun as 216.
