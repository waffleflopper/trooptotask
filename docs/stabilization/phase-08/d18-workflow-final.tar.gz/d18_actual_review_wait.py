"""Owned real review HTTP versus an uncommitted authenticated-role cancellation.

The competing writer is a JWT SQL fixture, not normal-login cancellation proof.
No result from this script establishes global source-effect serialization.
"""
import concurrent.futures
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import time
import urllib.request
from urllib.parse import urlsplit
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from scripts.verification import environment as ownership
from scripts.verification.environment import (
    Blocked, ReviewFailureDatabase, admit_review_failure_request,
    canonical_uuid, private_json, private_session,
)


class ProofFailure(Exception):
    """Only controlled, credential-free failure messages belong in public evidence."""


def require(condition, message):
    if not condition:
        raise ProofFailure(message)


def bounded_execute(command, directory, environment, *, suppress_diagnostic=False, timeout=15, include_stderr=False):
    del suppress_diagnostic
    try:
        result = subprocess.run(command, cwd=directory, env=environment,
                                capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise Blocked("Owned command timed out; no command output disclosed.") from None
    if result.returncode:
        raise Blocked("Owned command failed; no command output disclosed.")
    return result.stdout + result.stderr if include_stderr else result.stdout


class BoundedOwnedDatabase(ReviewFailureDatabase):
    """The existing original-container admission, with bounded fixed SQL/commands."""
    def __init__(self, session, worker):
        previous = ownership.execute
        ownership.execute = bounded_execute
        try:
            super().__init__(session)
        finally:
            ownership.execute = previous
        self.session = session
        self.worker = worker
        self._check_binding()

    def _check_binding(self):
        marker = private_json(self.session / "environment.json")
        app = private_json(self.session / "session.json")
        require(marker["repository"] == self.worker["repository"]
                and marker["phase"] == "running"
                and marker["project"] == self.project
                and self.container_id in marker["container_ids"],
                "Original owned provider binding changed")
        require(all(app.get(key) == self.worker.get(key)
                    for key in ("repository", "worker", "id", "origin", "candidate", "supervisor"))
                and app["phase"] == "running", "Original running worker binding changed")

    def _execute(self, sql):
        self._check_binding()
        return bounded_execute([
            "docker", "exec", "-e", "PGPASSWORD=postgres", self.container_id,
            "psql", "-X", "-qAt", "-h", "127.0.0.1", "-p", "5432", "-U",
            "supabase_admin", "-d", "postgres", "-v", "ON_ERROR_STOP=1", "-c",
            "SET standard_conforming_strings=on; SET statement_timeout='8s'; SET lock_timeout='5s'; " + sql,
        ], self.workdir, self.environment, timeout=12)


class OwnedProof:
    def __init__(self):
        self.repository = Path.cwd().resolve()
        require(self.repository == Path(__file__).resolve().parent.parent, "Run this fixed fixture from its original checkout")
        self.session = private_session(str(Path.home() / ".local/state/trooptotask-verification"
            / hashlib.sha256(str(self.repository).encode()).hexdigest()[:16] / "worker-1"))
        self.worker = private_json(self.session / "session.json")
        provider = private_json(self.session / "environment.json")
        require(self.worker["repository"] == str(self.repository)
                and self.worker["worker"] == "1" and self.worker["phase"] == "running"
                and provider["repository"] == str(self.repository),
                "Use this checkout's existing running worker 1")
        canonical_uuid(self.worker["id"])
        run = os.environ.get("D18_RUN", "d18-workflow-final")
        require(bool(re.fullmatch(r"[A-Za-z0-9_.-]+", run)) and run not in (".", ".."),
                "Use a single evidence run directory name")
        self.evidence = self.repository / ".verification/evidence/verify-trooptotask" / run
        self.evidence.mkdir(parents=True, exist_ok=True)
        self.environment = dict(os.environ)
        self.environment["PATH"] = "/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:" + self.environment["PATH"]
        # Doctor authenticates the exact supervisor and current executable candidate.
        self.doctor = self.call("proof-control-doctor", "doctor", timeout=35)
        require(self.doctor.get("status") == "PASS"
                and self.doctor.get("session") == self.worker["id"]
                and self.doctor.get("origin") == self.worker["origin"]
                and self.doctor.get("candidate") == self.worker["candidate"],
                "Doctor did not admit the exact current worker")
        self.db = BoundedOwnedDatabase(self.session, self.worker)
        self.fixture = private_json(self.session / "fixtures.json")
        self.ledger = private_json(self.session / "verify-trooptotask-owned.json")

    def call(self, name, command, *args, timeout=60):
        if command == "doctor":
            invocation = ["npm", "run", "--silent", "verify:app", "--", "--worker", "1", "doctor"]
        elif command == "tool":
            invocation = ["npm", "run", "--silent", "verify:app", "--", "--worker", "1", "tool", *args]
        else:
            invocation = ["node", ".agents/skills/verify-trooptotask/helpers/control.mjs", "--worker", "1", command, *args]
        try:
            result = subprocess.run(invocation, cwd=self.repository, env=self.environment,
                                    capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            raise ProofFailure("Owned helper timed out; its pending request is not a completed proof") from None
        # Only the maintained helper's credential-free JSON is archived, never stderr.
        try:
            value = json.loads(result.stdout)
        except (ValueError, TypeError):
            raise ProofFailure("Owned helper returned no complete JSON observation") from None
        require(result.returncode == 0 and not value.get("isError"), "Owned helper failed; no private diagnostics disclosed")
        if command == "tool":
            content = "\n".join(part.get("text", "") for part in value.get("content", []) if part.get("type") == "text")
            match = re.search(r"```json\s*([\s\S]*?)```", content)
            require(match is not None, "Owned evaluation returned no complete JSON observation")
            value = json.loads(match.group(1))
        (self.evidence / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n")
        return value

    def review(self, name, page, request_id, action, reason=None):
        # Consume the actual maintained helper, with a one-call bounded fetch.
        # This is ordinary signed-page HTTP; no page hooks or credentials are installed.
        source = (self.repository / ".agents/skills/verify-trooptotask/helpers/deletion-requests.mjs").read_text()
        start = source.index("export async function requestDeletion(")
        end = source.index("\n// Separate ordinary HTTP proof", start)
        operation = source[start:end].strip().removeprefix("export ")
        body = {"id": canonical_uuid(request_id), "action": action}
        if reason is not None:
            body["denialReason"] = reason
        config = {"origin": self.doctor["origin"], "orgId": self.fixture["ids"]["orgA"], "action": "review", "body": body}
        evaluation = """async () => {
          const target = { location: window.location,
            fetch: (path, options) => window.fetch(path, { ...options, signal: AbortSignal.timeout(45000) }) };
          return await (""" + operation + ") (target, " + json.dumps(config) + "); }"
        return self.call(name, "tool", "evaluate_script", json.dumps({"pageId": page, "function": evaluation, "waitForStableDom": False}), timeout=60)

    def admit_request(self, request_id, *, pending=True):
        request_id = canonical_uuid(request_id)
        request = json.loads(self.db._execute(
            f"SELECT row_to_json(r) FROM (SELECT * FROM public.deletion_requests WHERE id='{request_id}'::uuid) r;"))
        require(isinstance(request, dict), "Recorded request is absent")
        # Restore permits a terminal request, but still requires its original exact binding.
        admit_review_failure_request(self.session, {**request, "status": "pending"} if not pending else request)
        require(request["organization_id"] == canonical_uuid(self.fixture["ids"]["orgA"]), "Use a recorded orgA request")
        requester = canonical_uuid(request["requested_by"])
        require(requester in [self.fixture["actors"][key]["id"] for key in ("deletionRequester", "deletionPeer")],
                "Use a recorded synthetic requester or peer")
        return request

    def counseling_binding(self, request, source):
        require(isinstance(source, dict) and request["resource_type"] == "counseling_record"
                and source["id"] == request["resource_id"]
                and source["organization_id"] == request["organization_id"], "Counseling source binding changed")
        parent = canonical_uuid(source["personnel_id"])
        path = source["file_path"]
        expected = f"{request['organization_id']}/counseling-records/{parent}/{request['resource_id']}-synthetic.pdf"
        require(path == expected, "Use the exact recorded synthetic counseling file")
        sources = [item for item in self.ledger.get("seeded", [])
                   if item.get("kind") == "deletion-sources" and item.get("organization") == "orgA"
                   and item.get("table") == "counseling_records" and request["resource_id"] in item.get("ids", [])]
        require(any(any(parent in item.get("ids", [])
                        and item.get("kind") == "deletion-sources" and item.get("organization") == "orgA"
                        and item.get("table") == "personnel" and item.get("tag") == row.get("tag")
                        and any(file.get("bucket") == "counseling-files" and file.get("path") == path
                                for file in item.get("files", []))
                        for item in self.ledger.get("seeded", [])) for row in sources),
                "Counseling row, parent and file must share the recorded seed tag")
        return parent, path


def counseling_file_absent(proof, request, source):
    """One fixed owned Storage listing, bounded without another doctor/helper call."""
    proof.db._check_binding()
    _parent, path = proof.counseling_binding(request, source)
    require(request["organization_id"] == canonical_uuid(proof.fixture["ids"]["orgA"]),
            "Storage observation must use the recorded orgA file")
    marker = private_json(proof.session / "environment.json")
    config_path = proof.session / "provider.json"
    config = private_json(config_path)
    require(marker["repository"] == str(proof.repository) and marker["session"] == str(proof.session)
            and marker["project"] == proof.db.project and marker["phase"] == "running"
            and ownership.digest(config_path) == marker["provider_sha256"],
            "Private provider configuration no longer matches original ownership")
    api = urlsplit(config["API_URL"])
    port = marker["ports"]["api.port"]
    require(api.scheme == "http" and api.hostname == "127.0.0.1" and api.port == port
            and api.netloc == f"127.0.0.1:{port}" and api.path in ("", "/")
            and not api.username and not api.password and not api.query and not api.fragment,
            "Storage endpoint must be the exact owned loopback allocation")
    key = config["SERVICE_ROLE_KEY"]
    require(isinstance(key, str) and bool(key), "Private owned Storage credential is missing")
    prefix, filename = path.rsplit("/", 1)
    endpoint = f"http://127.0.0.1:{port}/storage/v1/object/list/counseling-files"
    payload = json.dumps({"prefix": prefix, "search": filename, "limit": 100, "offset": 0}).encode()
    call = urllib.request.Request(endpoint, data=payload, method="POST",
        headers={"Content-Type": "application/json", "apikey": key, "Authorization": "Bearer " + key})

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *_args, **_kwargs):
            raise ProofFailure("Owned Storage observation refused a redirect")

    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        with opener.open(call, timeout=2) as response:
            require(response.status == 200 and response.geturl() == endpoint,
                    "Owned Storage listing did not acknowledge its exact endpoint")
            content = response.read(65537)
        require(len(content) <= 65536, "Owned Storage listing exceeded its bounded JSON size")
        rows = json.loads(content)
        require(isinstance(rows, list) and len(rows) < 100
                and all(isinstance(row, dict) and isinstance(row.get("name"), str) and "id" in row
                        and (row["id"] is None or isinstance(row["id"], str)) for row in rows),
                "Owned Storage listing returned no complete metadata array")
        for row in rows:
            if row.get("id") is not None:
                canonical_uuid(row["id"])
        require(not any(row["name"] == filename and row.get("id") is not None for row in rows),
                "Exact counseling PDF metadata still exists during the wait")
    except (OSError, ValueError):
        raise ProofFailure("Owned Storage listing failed or timed out; private diagnostics withheld") from None
    return {"bucket": "counseling-files", "path": path, "present": False,
            "status": 200, "metadataListingSucceeded": True}


def public_failure(error):
    return str(error) if isinstance(error, (ProofFailure, Blocked)) else type(error).__name__ + ": private diagnostics withheld"


def main():
    result = {"status": "FAIL", "boundary": "Real ordinary review HTTP/provider versus an authenticated-role JWT SQL cancellation fixture; not normal-login cancellation or global source serialization proof"}
    holder = executor = future = proof = None
    name = snapshot = None
    try:
        require(len(sys.argv) == 4, "Use REQUEST_ID PAGE approve|deny")
        request_id, page, action = sys.argv[1:]
        page = int(page)
        require(page > 0 and action in ("approve", "deny"), "Use a positive owned page and approve|deny")
        proof = OwnedProof()
        request = proof.admit_request(request_id)
        request_id = canonical_uuid(request["id"])
        org_id = canonical_uuid(request["organization_id"])
        requester = canonical_uuid(request["requested_by"])
        resource_id = canonical_uuid(request["resource_id"])
        source_table = ownership.REVIEW_SOURCE_TABLES[request["resource_type"]]

        def snapshot():
            return json.loads(proof.db._execute(f"""SELECT json_build_object(
              'request',(SELECT row_to_json(r) FROM (SELECT * FROM public.deletion_requests WHERE id='{request_id}'::uuid AND organization_id='{org_id}'::uuid) r),
              'source',(SELECT row_to_json(r) FROM (SELECT * FROM public.{source_table} WHERE id='{resource_id}'::uuid AND organization_id='{org_id}'::uuid) r),
              'audit',(SELECT coalesce(json_agg(r ORDER BY r.id),'[]'::json) FROM (SELECT * FROM public.audit_logs WHERE org_id='{org_id}'::uuid AND resource_id::text='{request_id}') r),
              'reviewNotifications',(SELECT coalesce(json_agg(r ORDER BY r.id),'[]'::json) FROM (SELECT * FROM public.notifications WHERE organization_id='{org_id}'::uuid AND user_id='{requester}'::uuid AND type IN ('deletion_approved','deletion_denied')) r));"""))

        before = snapshot()
        result["before"] = before
        require(isinstance(before["source"], dict), "Use a surviving recorded source for this wait proof")
        if request["resource_type"] == "counseling_record":
            proof.counseling_binding(request, before["source"])
        name = "d18_terminal_" + request_id.replace("-", "") + "_" + secrets.token_hex(3)
        result["holderApplicationName"] = name
        require(json.loads(proof.db._execute(f"SELECT count(*) FROM pg_stat_activity WHERE application_name='{name}';")) == 0,
                "An existing holder cannot be adopted")
        command = ["docker", "exec", "-i", "-e", "PGPASSWORD=postgres", proof.db.container_id,
                   "psql", "-X", "-qAt", "-h", "127.0.0.1", "-p", "5432", "-U", "supabase_admin", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]
        holder = subprocess.Popen(command, cwd=proof.db.workdir, env=proof.db.environment,
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        holder.stdin.write(f"""BEGIN ISOLATION LEVEL READ COMMITTED;
          SET LOCAL statement_timeout='25s'; SET LOCAL lock_timeout='5s';
          SET LOCAL idle_in_transaction_session_timeout='30s'; SET LOCAL application_name='{name}';
          SET LOCAL ROLE authenticated;
          SELECT set_config('request.jwt.claims','{{"sub":"{requester}","role":"authenticated"}}',true) IS NOT NULL;
          SELECT public.cancel_own_deletion_request('{org_id}'::uuid,'{request_id}'::uuid);
          """)
        holder.stdin.flush()
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            ready = json.loads(proof.db._execute(f"SELECT coalesce(json_agg(json_build_object('pid',pid,'state',state)),'[]'::json) FROM pg_stat_activity WHERE application_name='{name}' AND state='idle in transaction';"))
            if len(ready) == 1:
                break
            require(holder.poll() is None, "Cancellation holder exited before readiness")
            time.sleep(.1)
        else:
            raise ProofFailure("Cancellation holder did not become ready within its deadline")
        require(snapshot()["request"] == before["request"], "Uncommitted cancellation must remain invisible")
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = executor.submit(proof.review, "wait-" + action + "-" + request_id + "-http", page, request_id, action, "Competing cancellation must win")
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            observed = json.loads(proof.db._execute(f"""SELECT coalesce(json_agg(json_build_object('pid',a.pid,'waitEventType',a.wait_event_type,'waitEvent',a.wait_event,'blockingPids',pg_blocking_pids(a.pid),'query',a.query)),'[]'::json) FROM pg_stat_activity a WHERE a.wait_event_type='Lock' AND {ready[0]['pid']}=ANY(pg_blocking_pids(a.pid));"""))
            if observed:
                break
            require(not future.done(), "Review finished without an actual database wait")
            time.sleep(.1)
        else:
            raise ProofFailure("Real review did not wait within the deadline")
        result["actualWait"] = observed
        expected_query = "approve_counseling_deletion_request" if action == "approve" and request["resource_type"] == "counseling_record" else "deletion_requests"
        require(len(observed) == 1 and expected_query in observed[0]["query"]
                and (expected_query != "deletion_requests" or "update" in observed[0]["query"].lower()),
                "Observed wait is not the expected review transition")
        require(not future.done(), "Review must remain pending during observed blocking")
        during = snapshot()
        result["duringWait"] = during
        if action == "approve" and request["resource_type"] == "counseling_record":
            files = counseling_file_absent(proof, request, before["source"])
            still_waiting = json.loads(proof.db._execute(f"SELECT count(*) FROM pg_stat_activity WHERE pid={observed[0]['pid']} AND wait_event_type='Lock' AND {ready[0]['pid']}=ANY(pg_blocking_pids(pid));"))
            require(still_waiting == 1 and not future.done(), "Counseling transition did not remain blocked during file observation")
            result["duringWaitFiles"] = files
            result["blockedDuringFileObservation"] = True
        output, _errors = holder.communicate(input="COMMIT;\n", timeout=8)
        require(holder.returncode == 0 and output.splitlines() == ["t", "t"], "Cancellation did not acknowledge true and commit")
        result["cancelAcknowledgedTrue"] = True
        response = future.result(timeout=25)
        result["http"] = response
        require(response["status"] == 404, "Losing real review must return concealed 404")
        after = snapshot()
        result["after"] = after
        require(after["request"] == {**before["request"], "status": "cancelled"}, "Review overwrote terminal status or saved metadata")
        require(after["audit"] == before["audit"] and after["reviewNotifications"] == before["reviewNotifications"], "Losing review claimed success")
        if action == "deny" or request["resource_type"] == "counseling_record":
            require(after["source"] == before["source"], "Source changed outside the stated transition outcome")
        elif request["resource_type"] == "personnel":
            require(after["source"] is not None and after["source"]["archived_at"] is not None, "Personnel effect was not observed")
        else:
            require(during["source"] is None and after["source"] is None, "Preceding source deletion was not observed")
        result.update(status="PASS", terminalAndMetadataPreserved=True, noReviewSuccessEffects=True)
    except BaseException as error:
        result["failure"] = public_failure(error)
    finally:
        try:
            if holder is not None and holder.poll() is None:
                try:
                    holder.communicate(input="ROLLBACK;\n", timeout=5)
                except (subprocess.TimeoutExpired, ValueError, BrokenPipeError):
                    # Only this nonce-named original-container holder may be terminated.
                    proof.db._execute(f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE application_name='{name}';")
                    holder.terminate()
                    try:
                        holder.communicate(timeout=5)
                    except subprocess.TimeoutExpired:
                        holder.kill()
                        holder.communicate(timeout=5)
            if proof is not None and name is not None:
                require(json.loads(proof.db._execute(f"SELECT count(*) FROM pg_stat_activity WHERE application_name='{name}';")) == 0,
                        "Owned holder still exists; proof cleanup is incomplete")
            if future is not None and not future.done():
                try:
                    result["lateHttp"] = future.result(timeout=65)
                except BaseException as error:
                    result["lateHttpFailure"] = public_failure(error)
            if snapshot is not None:
                result["finalReadback"] = snapshot()
            result["holderReleased"] = True
        except BaseException as error:
            result.update(status="FAIL", cleanupFailure=public_failure(error), holderReleased=False)
        if executor is not None:
            executor.shutdown(wait=False, cancel_futures=True)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
