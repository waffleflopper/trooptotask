import current as x
import json
from pathlib import Path
d=x.d;tag=x.run['tag']
d.act('rank-edit-save-corrected','button','Save '+tag);x.rankwire('rank-edit-wire');x.full('rank-edited-full');d.tool('rank-edited-reload','navigate_page',{'pageId':2,'type':'reload'});d.snap('rank-edited-reopened')
for action,state in [('Retire','retired'),('Reactivate','active')]:
 d.act('rank-'+state+'-menu','button','Actions for '+tag);d.act('rank-'+state+'-action','menuitem',action);x.rankwire('rank-'+state+'-wire');x.full('rank-'+state+'-full');d.tool('rank-'+state+'-reload','navigate_page',{'pageId':2,'type':'reload'});d.act('rank-'+state+'-all','button','All');d.snap('rank-'+state+'-reopened')
d.act('rank-remove-menu','button','Actions for '+tag);d.act('rank-remove-action','menuitem','Remove');print(d.txt(d.snap('rank-remove-confirmation')))
