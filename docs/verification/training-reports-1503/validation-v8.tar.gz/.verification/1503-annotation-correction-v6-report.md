# 1503 annotation correction v6 report

Owner round after the independent v5 FAIL (D4). Scope: `src/lib/components/ui/report-chart/ReportForecastChart.svelte` and its `docs/component-catalog.md` entry. Scratch evidence is in `.verification/1503-annotation-v6/`. No app, database, worker, driver or service was started. No commit or publish. This round makes no claim about the live application.

## Premise (Attack the Premise)

Every failed fix from v3 to v5 assumed one thing. Each in-plot label, placed at a fixed offset from its anchor, would stay clear of the other marks once that single actor was moved. v5 moved the goal label out of the plot. The same strikethrough then showed up on the end label, because nothing in the chart knew where the horizontal rules were.

## Census

There are six annotation actors. The relevant marks are the goal rule, the gridlines (the readiness rules), the line, the area, the dots, the band and the bars.

| Actor | Where it lives | Rules (goal, grid) | Line / area | Dots | Band | Bars / counts | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Goal label | right gutter, `width + 13` | rules end at the plot edge | outside the plot | 8px from the end dot at minimum (observed in v5) | fill only | outside the plot | clear by structure (v5 observed, 384 records) |
| Axis ticks (x) | below the axis line | none there | none | none | fill only | below the bars | clear by structure |
| Axis ticks (y) | left gutter | gridlines start at x = 0 | none | none | none | none | clear by structure |
| Band label and caption | HTML row above the SVG | not in the SVG | not in the SVG | not in the SVG | aligned to the band | not in the SVG | clear by structure (D2 observed) |
| Bar counts | row above the bars, below `lineFloor + 32` | every rule is at or above `lineFloor` | the line never goes below `lineFloor` | dots are at or above `lineFloor` | fill only | thinned against each other | clear by structure |
| Start value | above and right of the start dot | **imbalance** | clear (see below) | 4px from the dot | fill only | far above | **unclear before v6** |
| End value | below and left of the end dot | **imbalance** | clear (see below) | 8px from the dot | fill only | 11px above the count glyphs at worst | **unclear before v6** |

The line and area are clear for a domain reason. `isReadyAt` is monotone in offset, so forecast points never rise. The start point is therefore the series maximum and the end point the minimum. The line stays at or below the start dot and at or above the end dot. "Above the start" and "below the end" are the sides the line can never reach.

The imbalance sits on just two actors, the in-plot value labels, and on one mark class, the horizontal rules. Everything else is clear by structure.

### Lever

`census.mjs` sweeps goal 1..100, start 0..100 and end 0..start. That is 515,100 valid states. It covers both y domains, flat and non-flat series, and every rule position. The container height is fixed at 312px, so vertical geometry is the same at 1440, 1024 and 390. Width only changes horizontal spacing, and the two value labels never share a row. `lever-body-match.txt` confirms the census `offsetPastRules` body matches the component `valueLabelOffset` exactly once whitespace and constant names are normalized.

Glyph calibration is observed, not assumed. LayerChart `Text` resolves `verticalAnchor="start"` as `0.71em` of a fixed 16px base (`getPixelValue`), not of the 12px label. So the v5 end glyphs actually begin about 13px below the dot. That matches v5 `png/03`, where "54%" starts about 12.7px below its dot. The figure height is IBM Plex Mono's 0.698em × 12px, about 8.4px.

### Observed versus predicted

These rows are **observed** in the old v5 candidate. They come from `.verification/1503-final-chart-v5-report.md` and `raw/11-sweeps-condensed.txt`, and are reproduced by the model in `observed-crosscheck.json`.
- Goal 95 flat 100: the end label is struck by the goal rule (24 of 24 observed). The model predicts exactly this, and nothing else, as a goal-rule strike across the 16 observed goal/state pairs.
- No other observed state had the goal rule through text. The model agrees.

These rows are **predicted** only. They are mathematical, from source geometry, and were never measured, because the v5 detector only checked `.stroke-success`.
- Gridline strikes on the old candidate. Start 74 under the 80 gridline (view and mixed states). Start and end 85 (nearEnd). Start 85 and end 75 (atGoal).
- Over all 515,100 states, the old placement has these counts. Start × goal rule: 28,045 strikes. End × goal rule: 25,058. Start × gridline: 185,417. End × gridline: 162,218. There are a further 11k to 77k sub-2px near-misses per pair (`census.json`).

## Competing sketches

1. **Gutter lanes.** Move every value label into the rule-free gutters, the way v5 moved the goal label.
   - The end value would share the right gutter with the goal label. They collide in 80,874 of 515,100 states, so this needs a column dodge.
   - The start value would sit in the left gutter beside the y tick labels. A tick label lies within one label height of the start dot in 486,183 states, so it needs tick suppression or a second dodge.
   - That is two new resolvers and stacked special cases. Rejected.
2. **Rule-aware offset (chosen).** Keep each label on its line-free side. One pure function steps the label past any rule its glyphs would cross.
   - Data shape: `ruleYs: number[]` holds every horizontal rule in plot pixels (`yTicks` plus the goal).
   - `valueLabelOffset(pointY, direction, ruleYs, minOffset)` returns the distance from the dot to the near glyph edge. Both labels use it.
   - The census shows zero strikes, zero sub-2px gaps, zero line-side placements, nothing above the SVG and nothing into the bar-count row, across all 515,100 states.
3. The reviewer's suggestion was to flip a label to the other side of its dot when the goal rule is near. It is kept as a baseline only. It puts 25,058 end labels and 28,045 start labels on the line's side, and it leaves every gridline strike. Rejected.

### Clearance choice

The clearance is measured from the rule centre to the glyph edge.
- At 3px, the maximum drift from the default position is 42px. A goal halfway between two 50-domain gridlines leaves two 13.9px slots, and a slot needs 14.4px.
- At 2.5px, both halves fit. Maximum drift is 25.6px, and 97.7% of label placements move 15px or less. The visible gap from the stroke edge is 2px.

2.5px was chosen.

## Change

`ReportForecastChart.svelte`. Source sha256 changed from `8c6e6fb9…960e` (v5) to `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831`.
- New `VALUE_CAP_PX = 12 * 0.7` and `RULE_CLEARANCE = 2.5`, plus `valueLabelOffset`.
- Template: `firstY`, `lastY` and `ruleYs` constants.
- The start label baseline is `firstY - valueLabelOffset(firstY, -1, ruleYs, LABEL_GAP)`. With no rule nearby this is the v5 position.
- The end label is now baseline-placed at `lastY + valueLabelOffset(lastY, 1, ruleYs, END_DOT_RADIUS + LABEL_GAP) + VALUE_CAP_PX`. `verticalAnchor="start"` is gone, which removes the 16px-em dependency. With no rule nearby, the glyph top is 13px below the dot. That is the v5 rendered position within 0.04px.
- One HTML comment records the monotone-forecast reason for the label sides.

`docs/component-catalog.md`. Sha256 changed from `0115b15c…ea90` to `212b62865478b0ec8c626140e1d000405cb6a50abeb0ffac93014ee646b4c0e2`. The entry now states the contract that points must not rise. It also says the start and end labels sit on the line-free sides and step past gridlines and the goal line.

Unchanged: props, the consumer (`TrainingReportsPage.svelte:394`), report math, domain, input, auth, backend, status colours and the goal-label gutter. Diff: `.verification/1503-annotation-v6/v6.patch` (sha256 `7eaf4c51e6dffc86228fb1fba1e7a4f50ad7985179250cee811582c026c496ef`).

## Prototype (model only)

`prototype.mjs`, `prototype.svg`, `prototype-inpage-expr.js` and `prototype-{top,bottom}.png` show v5 and rule-aware panels side by side. The states are Goal 95 flat 100, 74→60 at goal 85, 85→75 at goal 85, 88 flat at goal 92 (near-maximum drift), 7 flat at goal 1, and 96→0 at goal 100. They were rendered from model geometry in this agent's own blank T3 tab (`tab_4`, about:blank, no app, auth or cookies, closed afterwards). The font in that tab was not verified to be IBM Plex Mono.

Every rule-aware label reads clear of its rules. The maximum-drift case (88% at goal 92) still reads as attached, because the label stays aligned to its dot's column with nothing between them.

## Checks

| Check | Result |
| --- | --- |
| `npx prettier --check` (component, catalog) | PASS (`format.log`) |
| `npx eslint` (component) | PASS (`lint.log`) |
| `svelte-check` | 0 errors, 0 warnings, 7,494 files (`check.log`) |
| Svelte autofixer | no issues |
| `vitest run TrainingReportsPage.test.ts` (sole consumer) | 6 of 6 PASS (`tests.log`) |
| Census lever, rule-aware | 0 findings over 515,100 states (`census.json`) |

No new geometry, copy or mirror tests were added, per the brief. No global format, build or full test suite was run.

## Unresolved objections and limitations

- None of this proves the live application. The fresh independent round should repeat the D4 state (Goal 95 flat 100) and the D3 sweep. It should also add checks that v5 lacked: text-versus-gridline crossings, goals 1 and 100, and the 85→75 and 74→60 states. All of these at 1440, 1024 and 390 in both themes.
- Model assumptions:
  - Container height is 312px. A different `heightClass` changes the spacing, but the function reads real `yScale` values, so it stays correct.
  - Figure height is 0.7em. If a fallback font has taller figures (up to about 0.75em), the clearance shrinks by under 1px.
- The catalog contract that points must not rise is enforced by the domain (`isReadyAt`), not by the component. A future caller with rising points would get line crossings. No runtime guard was added, because the only caller cannot produce rising points.
- Drift: about 2.3% of label placements move more than 15px, and none more than 25.6px, from their default position. That is model-predicted, not observed, and the reviewer should judge legibility live.
- Not re-run in this round: focus-visible, the 390 actions-row 4.3px slack, and the Mac HTTPS/HTTP2 transport (owned by root's non-visual owner).
- Pre-existing working-tree items I did not touch: `D src/routes/.../export/server.test.ts` (staged) and untracked `docs/verification/training-reports-1503/`.
