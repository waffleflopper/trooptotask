#!/bin/bash
# snap.sh NAME PAGE GREP -> saved snapshot, prints matching lines
D=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v6/driver
MAXOUT=0 $D/r.sh $1 npm run --silent verify:app -- tool take_snapshot "{\"pageId\":$2,\"filePath\":\"$D/$1.txt\"}" --worker 1
grep -E "$3" $D/$1.txt | cut -c1-170
