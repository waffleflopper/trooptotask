# #1504 baseline report (owned browser, pre-implementation)

This is a baseline of unchanged behavior before #1504. It is not acceptance of #1504.

## Run identity

- Revision `3cc4ec4cd5ae3839c77fdb9da24ab71f29a9551b`.
- Candidate `ecb5155b1b4e93c831744c1e4bc036df79064d7871a61a385890597677614f67`.
- Origin `http://127.0.0.1:44453`, worker 1, session `06c9ea7d-d5fa-4937-86db-accf9a47ae92`, Chromium 152.0.7977.82 Arch Linux.
- Doctor returned PASS at the start (receipt `001-doctor`) and at the end (`399-doctor-final`), with the same candidate and session.
- Org A is `ee51047e…`. Org B is `b63379fe…`.
- Fixture dates: ui 2026-10-04. Original completion 2026-09-27 → 2027-09-27. Expired 2024-10-04 → 2025-10-04. Warning 2025-10-19 → 2026-10-19 (15 days).
- Original rows: Org A has one row (`5fdee766…`, Able/Required, notes and URL null). Org B has none.

All evidence is under `.verification/evidence/verify-trooptotask/1504-baseline-v1/`. Receipts are in `receipts/`: `index.jsonl` has the name, description, argv, exit code and time, with `NAME.stdout` and `NAME.stderr` beside it. `notes.md` holds the working observations. Native network headers redact cookies. Root found and sanitized serialized synthetic access/refresh token values in the saved document response before packaging; header redaction does not cover response bodies. `REDACTIONS.json` records the two fields. First-paint content and downloaded workbook bytes are preserved.

## Results by path

| Path | Result |
|---|---|
| 1. Sign-in, matrix, report first paint, reload | PASS |
| 2. Toolbar filters, URL reload, 390 and 1440 widths | PASS |
| 3. Cell drill-down requests | PASS |
| 4. Report and detail failure, then retry | PASS (synthetic 503) |
| 5. Visible Export Excel, export failure, retry | PASS |
| 6. Read, scoped, no-lane and foreign access | PASS (UI), with HTTP probes recorded separately |
| 7. Matrix, Personnel readiness, Dashboard | PASS (spot-check) |
| Optional dated import | PASS, then visibly removed |

### 1. First paint (trainingConfigure)

- **Matrix** (`p1-matrix.*`): Able Required Current (09/2027), Able Targeted Not Done. Baker and Unassigned are Required Not Done and Targeted N/A. Optional is N/A for everyone.
- **Report via the visible Reports link** (`p1-report.*`): 3 soldiers, 25% ready today, stays 25% by 2 Jan. Ready 1, expired 0, not recorded 3, lapse 0. Grid: Bravo 0, Unassigned 0, Alpha 50 (Required 100, Targeted 0). Total Required 33, Total Targeted 0.
- The client navigation loaded only `reports/__data.json` and made no `api/training-reports` call.
- **Reload** (`022`, `p1-reload-document.network-response`): only the document GET (200) plus the notification count. The server HTML already contains the Bottom line text and the cell names.

### 2. Toolbar filters

Before each change I recorded the expected result: Alpha should give 50%, and Alpha + Required should give 100% with 1 ready of 1.

- **Alpha:** chosen by keyboard in the Group listbox. URL became `?group=<A>`, 1 soldier, 50%. One `api/training-reports` GET and no page navigation.
- **+ Required:** the Types menu lists only Required and Targeted. URL gained `&types=<req>`; result 100%, Ready 1 with zeros elsewhere.
- **30-day horizon:** "BY 3 NOV", nothing lapses.
- **Rows by MOS:** a single 68W row at 100.
- **Reloading that URL** (`063`) restored the same state from the document alone.
- **Desktop screenshot:** `p2-h30-mos-desktop.png`, taken at the default 1905 px viewport (not at 1440).
- **Narrow 390 px** (`p2-narrow-*`): the toolbar wraps onto three rows. Clear filters returned a bare URL, 3 soldiers, 25%, 90 days and Group rows.
- **Desktop 1440 px:** the representative interaction is the path 3 drill-down.

### 3. Drill-down at 1440 px

- **Total Required:** `detail?scope=cell&type=<req>` with no `row`, status 200. It returned 2 rows: Baker and Unassigned, both Not Done (`p3-detail-total-required.network-response`).
- **Alpha × Targeted:** `detail?scope=cell&row=<A>&type=<tgt>`, 1 row (Able, Not Done).
- A dashed outline moves to the selected cell, and a status line gives the count. The page URL stays bare. No table is shown, which is expected for the baseline.
- The selected cell is not exposed as pressed or selected in the accessibility tree.

### 4. Failure and retry (synthetic browser 503)

These failures were injected in the browser before dispatch. They are not provider outages.

- **Report failure** (`p4-failed.*`): `arm-fail training-reports`, then choose Bravo. The page shows "Unable to update the briefing … (503). Showing the last briefing that loaded." with Retry. The numbers stay at 25% and 3 soldiers, the Group control reverts to "All groups", and the URL stays bare.
- **Export during the alert:** with the fail control restored, the export request was `/export` with no query and returned 3 people. It used the briefing on screen, not the failed Bravo attempt.
- **Retry:** produced `?group=<Bravo>`, 1 soldier, 0%.
- **Detail failure** (`p4-detail-*`): "Unable to load affected soldiers (503)" with Retry, and the outline stays. After restore, Retry returned 200 with 2 requirements.

### 5. Workbooks

All downloads came from the visible Export Excel button with export capture and `arm-observe`. Every file was named `training-report-2026-10-04.xlsx` with the xlsx MIME type. Each was decoded independently by `decode_xlsx.py` into `p5-workbooks-decoded.json`, and the decode matches the helper.

| File | Bytes | SHA-256 | Contents |
|---|---|---|---|
| `p5-default-after-failure.xlsx` | 6930 | `1ac4a08d…` | Single sheet "Training Report". Headers Name, Rank, MOS, Duty Role, Group, Required, Targeted. Able: Current (2027-09-27), Not Done. Baker: Not Done, N/A. Unassigned (blank group): Not Done, N/A. No Optional or Foreign. |
| `p5-alpha-required.xlsx` | 6805 | `922605bb…` | Request `export?group=<A>&types=<req>`. One row (Able) and one Training column (Required, Current). |
| `p5-default-retry.xlsx` | 6930 | `002f291e…` | Same worksheet content as the first file. ZIP and workbook created/modified timestamps differ. |

**Export failure** (`p5-export-failed.*`): "Unable to export the workbook (503)" with Retry. No Blob was captured and no toast appeared. The visible Retry then downloaded the file above.

### 6. Access

**UI admission:**

- **trainingView:** admitted to the report with 3 soldiers, 25% and Export Excel.
- **trainingScoped:** admitted with 1 soldier and 50% (Ready 1, not recorded 1). The grid shows only Alpha and Total.
- **viewer (no Training lane):** the page shows "403 You don't have permission to view this page." After reload the document returns 403.
- **trainingForeign (B):** 1 Foreign soldier, "Foreign Private Training", 0%. The snapshot contains no A names or types.

**HTTP probes.** These were read-only, same-origin GETs from each signed-in page. Their results are in `216-scoped-probes.json`, `224-viewer-probes.json` and `234-foreign-probes.json`.

- **viewer:** summary, detail and export all return 403 "requires Training can view".
- **Scoped, Bravo summary** (`?group=Bravo`): 200 with scope "Bravo" and 0 soldiers.
- **Scoped, Bravo export:** headers only.
- **Scoped, Bravo detail** (`row=Bravo`): 404 "Training report scope not found".
- **Scoped, unfiltered export:** Able only. The Alpha/Bravo Group catalog names appear in `filterOptions`.
- **B, A's group ID:** normalized to `groupId: null`, giving B's whole scope.
- **B, A's Required type:** 404 on detail.
- **A's endpoints from B's session:** 404 "Organization not found".

No mutation probes were run, as the brief specified.

### 7. Retained consumers (rosterManager)

- **Able Details:** the Training card says "1 due, Verification Targeted Training not completed."
- **Baker Details:** "1 due, Verification Required Training not completed." Targeted is N/A and not counted.
- **Dashboard** (`p7-dashboard*`): "100% training current", Alpha 100%, Bravo 100%. This is the retained currency-of-existing-records meaning. It is not expected to match the report's 25%.
- The What's New modal was dismissed with Got it, as the Dashboard recipe allows. `preferences rosterManager orgA` shows no rows written.

### Optional dated import

- **Import:** the configure Import preview had 2 valid rows and wrote nothing (row count still 1). Import then returned Inserted 2, Updated 0, Errors 0.
- **New IDs:** `983ff0af…` (Baker Required, 2024-10-04 → 2025-10-04) and `a86af8c5…` (Able Targeted, 2025-10-19 → 2026-10-19).
- **Matrix:** "Expired 365d ago" and "15d left".
- **Report:** 50% → 25%, "loses 25 points in 90 days". Ready 2, expired 1, not recorded 1, lapse 1. Alpha × Targeted "drops 100 points".
- **Dated export** (`opt-dated.xlsx`, 6967 bytes, `399ad823…`): "15d left (2026-10-19)" and "Expired 365d ago (2025-10-04)".

## Restoration proof

- **UI-created completions:** both were deleted through the matrix editor's Delete and then "Delete Training Record". The first DELETE's 200 response is preserved. The second is proved by its native confirmation, successful matrix wait and exact final row readback; its response status was not separately captured. An ID readback for the deleted Baker row returned count 0.
- **Org A rows (`368`):** only the original `5fdee766…` remains, with its original dates and an unchanged `updated_at`.
- **Org B and deletion requests:** Org B has 0 rows, and Org A has 0 deletion requests.
- **Final re-read** (`final-*`): the matrix and report are back to the original fixture (25%, 1/0/3/0).
- **Controls:** every network and export control on pages 2–7 reads disarmed and uncaptured (`382`/`383`). Feedback was restored.
- **Viewport:** page 2 is back to 1905×2053.
- **Seeds:** none were created, so no `clean-seeds` was needed.
- **Operator error:** receipt `030` clicked a stale UID and toggled the sidebar. Receipt `032` toggled it back, and `p2-sidebar-restored.png` shows it restored.
- **Left for root:** pages 3–7 (actor sessions) remain open for root's owned cleanup.

## Notes and limits

- **Receipts with non-zero exits.** Five `wait_for` calls exited 2 on text-match timeouts (`051`, `083`, `244`, `319`, `373`). In each case the snapshot that followed established the state. Receipt `214` had malformed evaluate arguments and sent no request; it was rerun as `216`.
- **Desktop width.** The path 2 desktop screenshot was taken at 1905 px, not 1440. The 1440 px interaction and screenshots are from path 3.
- **Visual observations, not failures.** At 100%, the Bottom line's "→ 100%" wraps under the large figure at desktop width. Zero counts render in red ("0 evals overdue" on the Dashboard, "Not ready, expired 0" on the report).
- **Out-of-scope group handling differs.** Scoped A keeps Bravo as an empty scope, while B drops an unknown group ID.
- **Not covered.** Onboarding, raw Organization export, write-heavy completion journeys, pagination and multi-tab timing were not driven. They are outside this baseline's scope.
- **Remaining blockers:** none for the baseline. Final #1504 acceptance needs a post-implementation drive and independent review.
