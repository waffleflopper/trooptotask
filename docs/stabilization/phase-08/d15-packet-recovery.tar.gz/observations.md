# Recovery run observations

Tested revision 1d940b66 plus tested.patch, subsequently committed 05c062c3.
Successful launch-retry.json and initial/final doctor bind candidate 7457bd01 and loopback 38235.
Native tool and helper inputs are preserved before each invocation; snapshots/screenshots and public field readbacks establish each boundary separately.

- start-* captures failed POST503 retained draft/error, exact unchanged packets and a real single retry/new packet/reload.
- stage-* captures failed Reviewed503/error/Submitted rollback and real Reviewed200/reload. checkbox-* captures complete, reverse, visible reload and another complete.
- complete-warning/dismissed-* captures one incomplete step and a dismissal without request. complete-failed-* captures503/error/retained warning/status.
- complete-retry-actual and complete-retry-rows: first retry click did not issue API request because the detail sheet remounted over the warning. This candidate FAILS single-click recovery. complete-second-click/complete-saved are subsequent successful clicks, not accepted immediate retry.
- scoped-* captures Alpha-only Configure (other lanes absent), actual Start/no-op Re-sync preserving the three IDs/business fields and native cancellation.
- switch-* captures real A Baker200 held after persistence, pending-form cancellation, native B empty/view-only, release without phantom/B mutation and returnA saved card.
- return-* initial click had not settled on Onboarding and release occurred on Dashboard. A premature visibility expectation failed; this is not an application regression or a passing return-boundary test.
- return2-* repeats with waits for real Home and Onboarding Pipeline before release; fresh saved Able card remains exactly once after release, no phantom/duplicates.
- history-visible is a native persisted second read; cleanup-* captures all three active packets cancelled, one dismissed warning/no request, original March witness preserved and A/B inactive. comparisons.json covers only selected business fields, not timestamps.

All armed hooks have scenario-specific restored:true receipts. clean-seeds had no helper seeds; cleanup destroyed only this worker provider/browser and proof survived. Initial long-TMPDIR Chromium failure and its cleanup remain, without journey credit. The successful run did not capture its private environment metadata before disposal.

Current Kanban has no note editor, so native note creation is not claimed. No SQL denial/provider fault/general same-org concurrency/reconciliation/legacy/retention acceptance is supplied by this run. Final confirmation follow-up is separately archived and does not erase the observed failure.
