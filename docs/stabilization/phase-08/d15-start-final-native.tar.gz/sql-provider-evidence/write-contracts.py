from pathlib import Path
prefix='d1508000-0000-4000-8000-'
def id(n):return prefix+f'{n:012d}'
seed=f'''INSERT INTO auth.users(id,email)
SELECT ('{prefix}'||lpad(n::text,12,'0'))::uuid,'atomic-start-'||n||'@example.test' FROM generate_series(1,8) n;
INSERT INTO public.organizations(id,name,created_by) VALUES
('{id(101)}','Atomic Start Alpha','{id(1)}'),('{id(102)}','Atomic Start Foreign','{id(1)}');
INSERT INTO public.groups(id,organization_id,name) VALUES
('{id(201)}','{id(101)}','Alpha'),('{id(202)}','{id(101)}','Bravo');
INSERT INTO public.organization_memberships(organization_id,user_id,role,member_preset,capability_overrides,access_scope_kind,access_scope_group_ids)
SELECT '{id(101)}',('{prefix}'||lpad(actor::text,12,'0'))::uuid,'member'::public.organization_role,'viewer',
 jsonb_build_object('onboarding',capability,'personnel',CASE WHEN actor=4 THEN 'operate' ELSE 'none' END,
 'training',CASE WHEN actor=8 THEN 'operate' ELSE 'none' END,'calendar','none'),scope,
 CASE WHEN actor IN (5,7) THEN ARRAY['{id(201)}']::uuid[] ELSE ARRAY[]::uuid[] END
FROM (VALUES(1,'operate','organization'),(2,'configure','organization'),(3,'view','organization'),
 (4,'none','organization'),(5,'operate','groups'),(6,'operate','groups'),(7,'configure','groups'),(8,'none','organization')) a(actor,capability,scope);
INSERT INTO public.organization_memberships(organization_id,user_id,role,member_preset,capability_overrides,access_scope_kind,access_scope_group_ids)
VALUES('{id(102)}','{id(1)}','member','viewer','{{"onboarding":"operate","personnel":"none","training":"none"}}','organization',ARRAY[]::uuid[]);
INSERT INTO public.personnel(id,organization_id,group_id,rank,first_name,last_name,slug,archived_at)
SELECT ('{prefix}'||lpad(n::text,12,'0'))::uuid,
 CASE WHEN n=304 THEN '{id(102)}' ELSE '{id(101)}' END::uuid,
 CASE WHEN n IN(303,304,307) THEN NULL WHEN n IN(302,306) THEN '{id(202)}' ELSE '{id(201)}' END::uuid,
 'SPC','Start',n::text,'atomic-start-'||n,CASE WHEN n=308 THEN '2026-08-01T12:00:00Z'::timestamptz ELSE NULL END
FROM generate_series(301,311) n;
INSERT INTO public.onboarding_templates(id,organization_id,name) VALUES
('{id(401)}','{id(101)}','Prepared template'),('{id(402)}','{id(101)}','Other template'),
('{id(403)}','{id(101)}','Empty template'),('{id(404)}','{id(102)}','Foreign template');
INSERT INTO public.training_types(id,organization_id,name) VALUES
('{id(601)}','{id(101)}','Expired matching Training'),('{id(602)}','{id(101)}','Missing Training'),('{id(603)}','{id(102)}','Foreign Training');
INSERT INTO public.personnel_trainings(id,organization_id,personnel_id,training_type_id,completion_date,expiration_date)
VALUES('{id(901)}','{id(101)}','{id(305)}','{id(601)}','2020-01-01','2020-02-01');
INSERT INTO public.onboarding_template_steps(id,organization_id,template_id,name,step_type,training_type_id,stages,sort_order) VALUES
('{id(501)}','{id(101)}','{id(401)}','Current Orientation','checkbox',NULL,NULL,10),
('{id(502)}','{id(101)}','{id(401)}','Current Paperwork','paperwork',NULL,'["Draft","Reviewed"]',20),
('{id(503)}','{id(101)}','{id(401)}','Current expired Training','training','{id(601)}',NULL,30),
('{id(504)}','{id(101)}','{id(401)}','Current missing Training','training','{id(602)}',NULL,40),
('{id(505)}','{id(101)}','{id(401)}','Training without type','training',NULL,NULL,50),
('{id(506)}','{id(101)}','{id(401)}','Paperwork empty stages','paperwork',NULL,'[]',60),
('{id(507)}','{id(101)}','{id(401)}','Paperwork null stages','paperwork',NULL,NULL,70),
('{id(511)}','{id(101)}','{id(402)}','Other checkbox','checkbox',NULL,NULL,0),
('{id(521)}','{id(102)}','{id(404)}','Foreign checkbox','checkbox',NULL,NULL,0);
INSERT INTO public.personnel_onboardings(id,organization_id,personnel_id,template_id,started_at,status,completed_at,cancelled_at) VALUES
('{id(701)}','{id(101)}','{id(301)}','{id(401)}','2026-01-01','in_progress',NULL,NULL),
('{id(702)}','{id(101)}','{id(302)}',NULL,'2026-01-01','completed','2026-01-03',NULL),
('{id(703)}','{id(101)}','{id(303)}','{id(401)}','2026-01-01','cancelled',NULL,'2026-01-04T12:00:00.123Z'),
('{id(704)}','{id(102)}','{id(304)}','{id(404)}','2026-01-01','in_progress',NULL,NULL);
INSERT INTO public.onboarding_step_progress(id,organization_id,onboarding_id,template_step_id,step_name,step_type,training_type_id,stages,sort_order,completed,current_stage,notes,active) VALUES
('{id(801)}','{id(101)}','{id(701)}','{id(501)}','Saved Orientation','checkbox',NULL,NULL,1,true,NULL,'[{{"text":"Original work","timestamp":"2026-01-01T01:00:00.123Z","userId":"{id(2)}","extra":[true,null]}}]',true),
('{id(802)}','{id(101)}','{id(702)}',NULL,'Deleted definition history','paperwork',NULL,'["Draft","Archived review"]',2,true,'Archived review','[{{"text":"Saved complete note","timestamp":"2026-01-02T01:00:00.123Z","userId":"{id(2)}"}}]',false),
('{id(803)}','{id(101)}','{id(703)}','{id(503)}','Cancelled Training snapshot','training','{id(601)}',NULL,3,false,NULL,'[{{"text":"Saved cancelled note","timestamp":"2026-01-02T01:00:00.123Z"}}]',false),
('{id(804)}','{id(102)}','{id(704)}','{id(521)}','Foreign saved work','checkbox',NULL,NULL,4,false,NULL,'[]',true);
'''
tables=['personnel','organization_memberships','onboarding_templates','onboarding_template_steps','training_types','personnel_trainings','personnel_onboardings','onboarding_step_progress']
# Membership identity is its composite organization/user pair rather than an id column.
def rows():
 return '\nUNION ALL '.join(f"SELECT '{t}'::text table_name,{('organization_id::text||\'/\'||user_id::text' if t=='organization_memberships' else 'id::text')} row_id,to_jsonb(p) row_data FROM public.{t} p WHERE organization_id IN ('{id(101)}','{id(102)}')" for t in tables)
payload=f'''CREATE FUNCTION pg_temp.start_steps() RETURNS jsonb LANGUAGE sql AS $snapshot$
 SELECT '[
 {{"template_step_id":"{id(501)}","step_name":"Prepared Orientation","step_type":"checkbox","training_type_id":null,"stages":null,"sort_order":10,"completed":true}},
 {{"template_step_id":"{id(502)}","step_name":"Prepared Paperwork","step_type":"paperwork","training_type_id":null,"stages":["Submitted","Reviewed","Filed"],"sort_order":20,"completed":true}},
 {{"template_step_id":"{id(503)}","step_name":"Prepared expired Training","step_type":"training","training_type_id":"{id(601)}","stages":null,"sort_order":30,"completed":true}},
 {{"template_step_id":"{id(504)}","step_name":"Prepared missing Training","step_type":"training","training_type_id":"{id(602)}","stages":null,"sort_order":40,"completed":false}},
 {{"template_step_id":"{id(505)}","step_name":"Training without type","step_type":"training","training_type_id":null,"stages":null,"sort_order":50,"completed":true}},
 {{"template_step_id":"{id(506)}","step_name":"Paperwork empty stages","step_type":"paperwork","training_type_id":null,"stages":[],"sort_order":60,"completed":false}},
 {{"template_step_id":"{id(507)}","step_name":"Paperwork null stages","step_type":"paperwork","training_type_id":null,"stages":null,"sort_order":70,"completed":false}}
 ]'::jsonb;
$snapshot$;
'''
def call(person=309,template=401,p='pg_temp.start_steps()',org=101):return f"SELECT public.start_onboarding_packet('{id(org)}','{id(person)}','{id(template)}','2026-02-03',{p})"
def throws(sql,code,label,msg='NULL'):return f"SELECT throws_ok($q$ {sql} $q$,'{code}',{msg},'{label}');\n"
before="-- A preceding populated schema; Start must add no automatic data changes.\nBEGIN;\nDO $$ BEGIN IF to_regprocedure('public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)') IS NOT NULL THEN RAISE EXCEPTION 'Start fixture requires preceding schema'; END IF; END; $$;\nCREATE SCHEMA IF NOT EXISTS upgrade_fixture;\n"+seed+"CREATE TABLE upgrade_fixture.onboarding_start_before AS\n"+rows()+";\nCOMMIT;\n"
Path('supabase/migration-tests/onboarding_start_before.sql').write_text(before)
main="-- Actual invoker persistence: prepared snapshots, scope and transactional failure.\nBEGIN;\nCREATE EXTENSION IF NOT EXISTS pgtap WITH SCHEMA extensions;\nSELECT no_plan();\n"+seed+payload
main+="CREATE TEMP VIEW saved_start_rows AS\n"+rows()+";\nCREATE TEMP TABLE original_rows AS SELECT * FROM saved_start_rows;\nCREATE TEMP TABLE returned(label text,value jsonb);\nGRANT SELECT,INSERT ON returned TO authenticated;\n"
main+='''SELECT ok(has_function_privilege('authenticated','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE'),'ordinary authenticated Start is granted');
SELECT ok(NOT has_function_privilege('anon','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE') AND NOT has_function_privilege('service_role','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE'),'anonymous and service roles have no Start grant');
SELECT ok(NOT EXISTS(SELECT 1 FROM pg_proc p,LATERAL aclexplode(p.proacl) a WHERE p.oid='public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)'::regprocedure AND a.grantee=0),'PUBLIC has no effective Start grant');
SELECT ok((SELECT provolatile='v' AND NOT prosecdef AND proconfig=ARRAY['search_path=""']::text[] AND proargnames=ARRAY['p_organization_id','p_personnel_id','p_template_id','p_started_at','p_steps'] FROM pg_proc WHERE oid='public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)'::regprocedure),'Start is volatile invoker with empty search path and only prepared inputs');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','',true);
'''
main+=throws(call(),'42501','missing identity cannot start')
for actor,label in [(3,'View cannot start'),(4,'Personnel alone cannot start'),(8,'Training alone cannot start'),(6,'empty Group scope cannot start')]:
 main+=f"SELECT set_config('request.jwt.claim.sub','{id(actor)}',true);\n"+throws(call(),'42501',label)
main+=f"SELECT set_config('request.jwt.claim.sub','{id(5)}',true);\n"
for person,label in [(306,'Group scope excludes Bravo'),(307,'Group scope excludes Unassigned'),(304,'foreign Person denied'),(399,'missing Person denied without existence bypass')]:main+=throws(call(person),'42501',label)
main+=f"SELECT set_config('request.jwt.claim.sub','{id(1)}',true);\n"
for template,label in [(404,'dual membership cannot borrow foreign template'),(499,'missing template is explicit')]:main+=throws(call(template=template),'P0002',label)
for d,label in [(511,'same Organization other-template definition denied'),(521,'foreign definition denied'),(599,'deleted definition denied')]:main+=throws(call(p=f"jsonb_set(pg_temp.start_steps(),'{{0,template_step_id}}',to_jsonb('{id(d)}'::text))"),'P0002',label)
main+=throws(call(p=f"jsonb_set(pg_temp.start_steps(),'{{2,training_type_id}}',to_jsonb('{id(603)}'::text))"),'42501','foreign Training reference denied by retained progress RLS')
for p,label in [("NULL","null prepared snapshot"),("'{}'::jsonb","non-array prepared snapshot"),("pg_temp.start_steps()||jsonb_build_array(pg_temp.start_steps()->0)","duplicate prepared definition"),("jsonb_set(pg_temp.start_steps(),'{0,template_step_id}','null'::jsonb)","null prepared definition"),("jsonb_set(pg_temp.start_steps(),'{0,sort_order}','0.5'::jsonb)","noninteger order"),("jsonb_set(pg_temp.start_steps(),'{0,sort_order}','99999999999999999999'::jsonb)","overflow order"),("jsonb_set(pg_temp.start_steps(),'{0,notes}','[]'::jsonb)","caller note array"),("jsonb_set(pg_temp.start_steps(),'{0,step_type}','\"unknown\"'::jsonb)","unknown step type"),("jsonb_set(pg_temp.start_steps(),'{1,stages}','[1]'::jsonb)","malformed prepared stages")]:main+=throws(call(p=p),'22023',label+' rejected')
main+=throws(call(person=301),'23505','named active index retains duplicate guard',"'duplicate key value violates unique constraint \"personnel_onboardings_active_idx\"'")
main+='''RESET ROLE;
SELECT results_eq($$ SELECT * FROM saved_start_rows ORDER BY table_name,row_id $$,$$ SELECT * FROM original_rows ORDER BY table_name,row_id $$,'all valid denied and malformed requests retain every original row field');
SET LOCAL ROLE authenticated;
'''
for actor,person,template,label,p in [(1,305,401,'operate','pg_temp.start_steps()'),(5,309,401,'group-operate','pg_temp.start_steps()'),(7,308,401,'group-configure-archived','pg_temp.start_steps()'),(2,307,403,'configure-unassigned-empty',"'[]'::jsonb"),(1,302,401,'after-completed','pg_temp.start_steps()'),(1,303,401,'after-cancelled','pg_temp.start_steps()')]:
 main+=f"SELECT set_config('request.jwt.claim.sub','{id(actor)}',true);\nINSERT INTO returned VALUES('{label}',({call(person,template,p)[7:]}));\n"
main+='''RESET ROLE;
SELECT results_eq($$ SELECT label,value->'onboarding' FROM returned ORDER BY label $$,$$ SELECT r.label,to_jsonb(p) FROM returned r JOIN public.personnel_onboardings p ON p.id=(r.value->'onboarding'->>'id')::uuid ORDER BY label $$,'raw parent responses equal every actual saved field');
SELECT results_eq($$ SELECT label,value->'steps' FROM returned ORDER BY label $$,$$ SELECT r.label,coalesce(jsonb_agg(to_jsonb(p) ORDER BY p.sort_order,p.id) FILTER(WHERE p.id IS NOT NULL),'[]'::jsonb) FROM returned r LEFT JOIN public.onboarding_step_progress p ON p.onboarding_id=(r.value->'onboarding'->>'id')::uuid GROUP BY r.label ORDER BY r.label $$,'raw step responses equal every actual saved field in stable saved order');
SELECT ok((SELECT bool_and(p.status='in_progress' AND p.started_at='2026-02-03' AND p.completed_at IS NULL AND p.cancelled_at IS NULL AND p.id NOT IN(SELECT row_id::uuid FROM original_rows WHERE table_name='personnel_onboardings')) FROM returned r JOIN public.personnel_onboardings p ON p.id=(r.value->'onboarding'->>'id')::uuid),'new parents have fresh IDs chosen date and fixed initial lifecycle');
SELECT ok((SELECT bool_and(p.notes='[]'::jsonb AND p.active AND p.organization_id='''+f"'{id(101)}'"+'''::uuid AND p.id NOT IN(SELECT row_id::uuid FROM original_rows WHERE table_name='onboarding_step_progress')) FROM returned r JOIN public.onboarding_step_progress p ON p.onboarding_id=(r.value->'onboarding'->>'id')::uuid),'new steps have fresh IDs fixed parent Organization active state and empty notes');
SELECT results_eq($$ SELECT p.step_name,p.completed,p.current_stage,p.stages,p.sort_order FROM returned r JOIN public.onboarding_step_progress p ON p.onboarding_id=(r.value->'onboarding'->>'id')::uuid WHERE r.label='operate' ORDER BY p.sort_order $$,$$ VALUES
('Prepared Orientation'::text,false,NULL::text,NULL::jsonb,10),('Prepared Paperwork',false,'Submitted','["Submitted","Reviewed","Filed"]'::jsonb,20),('Prepared expired Training',true,NULL,NULL,30),('Prepared missing Training',false,NULL,NULL,40),('Training without type',false,NULL,NULL,50),('Paperwork empty stages',false,NULL,'[]'::jsonb,60),('Paperwork null stages',false,NULL,NULL,70) $$,'prepared metadata is preserved without catalog equality and initial completion/stages follow the retained rules');
SELECT is((SELECT jsonb_array_length(value->'steps') FROM returned WHERE label='configure-unassigned-empty'),0,'an existing empty template admits an empty snapshot');
SELECT results_eq($$ SELECT s.* FROM saved_start_rows s JOIN original_rows o USING(table_name,row_id) ORDER BY s.table_name,s.row_id $$,$$ SELECT * FROM original_rows ORDER BY table_name,row_id $$,'every old packet dependency and saved history field remains unchanged');
CREATE TEMP TABLE before_fault AS SELECT * FROM saved_start_rows;
'''
main+=f'''CREATE FUNCTION pg_temp.start_partial_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF NEW.step_name='Prepared Paperwork' AND EXISTS(SELECT 1 FROM public.personnel_onboardings WHERE id=NEW.onboarding_id AND personnel_id='{id(310)}') THEN
  IF NOT EXISTS(SELECT 1 FROM public.onboarding_step_progress WHERE onboarding_id=NEW.onboarding_id AND step_name='Prepared Orientation') THEN RAISE EXCEPTION 'Partial fault did not witness prior child' USING ERRCODE='XX000'; END IF;
  RAISE EXCEPTION 'Controlled Start fault witnessed parent and prior child' USING ERRCODE='23514';
 END IF; RETURN NEW; END; $$;
CREATE TRIGGER atomic_start_partial_fault BEFORE INSERT ON public.onboarding_step_progress FOR EACH ROW EXECUTE FUNCTION pg_temp.start_partial_fault();
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','{id(1)}',true);
'''+throws(call(310),'23514','fault after prior inserts is propagated',"'Controlled Start fault witnessed parent and prior child'")+'''RESET ROLE;
SELECT results_eq($$ SELECT * FROM saved_start_rows ORDER BY table_name,row_id $$,$$ SELECT * FROM before_fault ORDER BY table_name,row_id $$,'partial child failure rolls back every new row and retains every original field');
DROP TRIGGER atomic_start_partial_fault ON public.onboarding_step_progress;
'''
main+=f'''CREATE FUNCTION pg_temp.start_deferred_fault() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.personnel_onboardings WHERE id=NEW.onboarding_id AND personnel_id='{id(311)}') THEN
  IF (SELECT count(*) FROM public.onboarding_step_progress WHERE onboarding_id=NEW.onboarding_id)<>7 THEN RAISE EXCEPTION 'Deferred fault did not witness full packet' USING ERRCODE='XX000'; END IF;
  RAISE EXCEPTION 'Controlled deferred Start failure witnessed full packet' USING ERRCODE='23514'; END IF; RETURN NEW; END; $$;
CREATE CONSTRAINT TRIGGER atomic_start_deferred_fault AFTER INSERT ON public.onboarding_step_progress DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION pg_temp.start_deferred_fault();
CREATE FUNCTION pg_temp.start_and_check_deferred() RETURNS void LANGUAGE plpgsql AS $$ BEGIN
 PERFORM public.start_onboarding_packet('{id(101)}','{id(311)}','{id(401)}','2026-02-03',pg_temp.start_steps());
 SET CONSTRAINTS atomic_start_deferred_fault IMMEDIATE; END; $$;
SET LOCAL ROLE authenticated;
'''+throws('SELECT pg_temp.start_and_check_deferred()','23514','deferred transaction failure is propagated',"'Controlled deferred Start failure witnessed full packet'")+'''RESET ROLE;
SELECT results_eq($$ SELECT * FROM saved_start_rows ORDER BY table_name,row_id $$,$$ SELECT * FROM before_fault ORDER BY table_name,row_id $$,'deferred failure rolls back parent and all steps with original fields unchanged');
DROP TRIGGER atomic_start_deferred_fault ON public.onboarding_step_progress;
SET LOCAL ROLE authenticated;
'''+f"INSERT INTO returned VALUES('retry',({call(310)[7:]}));\nRESET ROLE;\n"+'''SELECT is((SELECT jsonb_array_length(value->'steps') FROM returned WHERE label='retry'),7,'a restored genuine failure permits one complete retry');
SELECT results_eq($$ SELECT s.* FROM saved_start_rows s JOIN original_rows o USING(table_name,row_id) ORDER BY s.table_name,s.row_id $$,$$ SELECT * FROM original_rows ORDER BY table_name,row_id $$,'successful retry still preserves all original identities and fields');
SELECT * FROM finish();
ROLLBACK;
'''
Path('supabase/tests/onboarding_atomic_start.sql').write_text(main)
after='''-- Populated upgrade changes no saved facts and admits the new ordinary operation.
BEGIN;
CREATE EXTENSION IF NOT EXISTS pgtap WITH SCHEMA extensions;
SELECT no_plan();
SELECT is((SELECT count(*)::integer FROM supabase_migrations.schema_migrations WHERE version='20261002001100'),1,'atomic Start migration is applied');
CREATE TEMP VIEW upgraded_start_rows AS
'''+rows()+''';
SELECT results_eq($$ SELECT * FROM upgraded_start_rows ORDER BY table_name,row_id $$,$$ SELECT * FROM upgrade_fixture.onboarding_start_before ORDER BY table_name,row_id $$,'upgrade preserves the exact populated row set and every stored value');
SELECT ok((SELECT provolatile='v' AND NOT prosecdef AND proconfig=ARRAY['search_path=""']::text[] FROM pg_proc WHERE oid='public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)'::regprocedure),'upgraded function retains invoker volatility and empty search path');
SELECT ok(has_function_privilege('authenticated','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE') AND NOT has_function_privilege('anon','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE') AND NOT has_function_privilege('service_role','public.start_onboarding_packet(uuid,uuid,uuid,date,jsonb)','EXECUTE'),'upgraded ordinary execution grant excludes anonymous and service roles');
'''+payload+'''CREATE TEMP TABLE returned(value jsonb); GRANT INSERT ON returned TO authenticated;
SET LOCAL ROLE authenticated;
'''+f"SELECT set_config('request.jwt.claim.sub','{id(3)}',true);\n"+throws(call(),'42501','upgraded View cannot start')+f"SELECT set_config('request.jwt.claim.sub','{id(5)}',true);\n"+throws(call(306),'42501','upgraded Group excludes Bravo')+f"SELECT set_config('request.jwt.claim.sub','{id(1)}',true);\n"+throws(call(template=404),'P0002','upgraded same Organization template remains required')+'''RESET ROLE;
SELECT results_eq($$ SELECT * FROM upgraded_start_rows ORDER BY table_name,row_id $$,$$ SELECT * FROM upgrade_fixture.onboarding_start_before ORDER BY table_name,row_id $$,'upgraded denied requests retain every populated field');
SET LOCAL ROLE authenticated;
'''+f"SELECT set_config('request.jwt.claim.sub','{id(7)}',true);\nINSERT INTO returned VALUES(({call(305)[7:]}));\nRESET ROLE;\n"+'''SELECT is((SELECT jsonb_array_length(value->'steps') FROM returned),7,'upgraded Group Configure saves every prepared step');
SELECT results_eq($$ SELECT step_name,completed,current_stage FROM public.onboarding_step_progress WHERE onboarding_id=(SELECT(value->'onboarding'->>'id')::uuid FROM returned) ORDER BY sort_order $$,$$ VALUES ('Prepared Orientation'::text,false,NULL::text),('Prepared Paperwork',false,'Submitted'),('Prepared expired Training',true,NULL),('Prepared missing Training',false,NULL),('Training without type',false,NULL),('Paperwork empty stages',false,NULL),('Paperwork null stages',false,NULL) $$,'upgraded prepared snapshots retain default state and supplied Training presence');
SELECT results_eq($$ SELECT s.* FROM upgraded_start_rows s JOIN upgrade_fixture.onboarding_start_before o USING(table_name,row_id) ORDER BY s.table_name,s.row_id $$,$$ SELECT * FROM upgrade_fixture.onboarding_start_before ORDER BY table_name,row_id $$,'upgraded successful Start leaves every pre-existing value unchanged');
SELECT * FROM finish(); ROLLBACK;
'''
Path('supabase/migration-tests/onboarding_start_after.sql').write_text(after)
