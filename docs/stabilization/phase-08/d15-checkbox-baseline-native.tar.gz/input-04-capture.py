"""Run owned verification commands and preserve exact inputs, exits and raw outputs."""
import json, os, re, subprocess, sys
from pathlib import Path
run=os.environ.get('D15_CHECKBOX_RUN','')
if run not in ('baseline','final'): raise ValueError('Explicit baseline/final run required')
root=Path('.verification/evidence/verify-trooptotask')/f'd15-checkbox-{run}-native'
root.mkdir(exist_ok=True)
mode,label,*args=sys.argv[1:]
if mode not in ('verify','helper') or not re.fullmatch(r'[a-z0-9]+(?:[.-][a-z0-9]+)*',label): raise ValueError('Mode and unique plain label required')
command=({'verify':['npm','run','--silent','verify:app','--'],'helper':['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1']}[mode])+args
with (root/(label+'-input.json')).open('x') as f: json.dump({'argv':command},f,indent=2)
result=subprocess.run(command,capture_output=True,text=True)
for suffix,value in [('json',result.stdout),('stderr',result.stderr)]:
 with (root/(label+'.'+suffix)).open('x') as f:f.write(value)
with (root/(label+'-exit.json')).open('x') as f:json.dump({'exitCode':result.returncode},f)
print(result.stdout,end='');print(result.stderr,end='',file=sys.stderr)
raise SystemExit(result.returncode)
