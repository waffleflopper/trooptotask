(() => {
  if (window.__o3) return { already: true, n: window.__o3.log.length };
  const nativeFetch = window.fetch;
  const o = { log: [], events: [], errors: [], arm: null, held: [], installedAt: new Date().toISOString(), nativeFetch };
  const fam = (u) => { const p = new URL(u, location.href); if (p.pathname.endsWith('/api/training-reports')) return 'summary'; if (p.pathname.endsWith('/api/training-reports/detail')) return 'detail'; if (p.pathname.endsWith('/api/training-reports/export')) return 'export'; if (p.pathname.endsWith('__data.json')) return 'data'; return null; };
  const ts = () => new Date().toISOString();
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const f = fam(url);
    if (!f) return nativeFetch.apply(this, arguments);
    const signal = init?.signal ?? (input instanceof Request ? input.signal : undefined);
    const p = new URL(url, location.href);
    const rec = { n: o.log.length + 1, family: f, path: p.pathname.replace(/\/org\/[^/]+/, '/org/<A>'), search: p.search, start: ts(), stack: (new Error().stack || '').split('\n').slice(2, 6).map((s) => s.trim()) };
    o.log.push(rec);
    if (signal) signal.addEventListener('abort', () => { rec.abortedAt = ts(); });
    const arm = o.arm && o.arm.family === f ? o.arm : null;
    if (arm) { o.arm = arm.mode === 'fail' ? null : o.arm; if (arm.mode !== 'fail') o.arm = null; rec.fault = arm.mode; }
    const finish = (res) => { rec.end = ts(); rec.status = res.status; rec.headers = { 'content-type': res.headers.get('content-type'), 'cache-control': res.headers.get('cache-control'), 'content-disposition': res.headers.get('content-disposition') }; return res; };
    const synthetic = () => new Response(JSON.stringify({ message: 'Synthetic verification 503' }), { status: 503, headers: { 'content-type': 'application/json' } });
    if (arm?.mode === 'fail') { rec.synthetic = true; return Promise.resolve(finish(synthetic())); }
    if (arm?.mode === 'hold' || arm?.mode === 'hold-fail') {
      let release; const gate = new Promise((r) => (release = r));
      const h = { n: rec.n, release: () => { rec.releasedAt = ts(); release(); } }; o.held.push(h);
      const base = arm.mode === 'hold' ? nativeFetch.apply(this, arguments).then((res) => { rec.realStatus = res.status; rec.realReceivedAt = ts(); return res; }) : Promise.resolve(synthetic());
      if (arm.mode === 'hold-fail') rec.synthetic = true;
      return base.then((res) => gate.then(() => finish(res)));
    }
    return nativeFetch.apply(this, arguments).then(finish, (e) => { rec.end = ts(); rec.error = String(e?.name || e); throw e; });
  };
  const describe = (t) => t ? `${t.tagName}${t.getAttribute?.('role') ? '[' + t.getAttribute('role') + ']' : ''} ${(t.getAttribute?.('aria-label') || t.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 50)}` : null;
  for (const type of ['pointerdown', 'click', 'keydown']) addEventListener(type, (e) => { o.events.push({ type, t: ts(), trusted: e.isTrusted, key: e.key, target: describe(e.target) }); if (o.events.length > 300) o.events.shift(); }, true);
  addEventListener('error', (e) => o.errors.push({ type: 'error', t: ts(), msg: String(e.message) }));
  addEventListener('unhandledrejection', (e) => o.errors.push({ type: 'unhandledrejection', t: ts(), msg: String(e.reason?.message || e.reason) }));
  window.__o3 = o;
  o.armFault = (family, mode) => { o.arm = { family, mode }; return o.arm; };
  o.release = () => { const h = o.held.shift(); if (h) h.release(); return !!h; };
  o.state = (from = 0) => ({ log: o.log.slice(from), errors: o.errors, held: o.held.length, arm: o.arm });
  o.restore = () => { window.fetch = nativeFetch; o.held.forEach((h) => h.release()); delete window.__o3; return { restored: window.fetch === nativeFetch }; };
  return { installed: o.installedAt };
})()
