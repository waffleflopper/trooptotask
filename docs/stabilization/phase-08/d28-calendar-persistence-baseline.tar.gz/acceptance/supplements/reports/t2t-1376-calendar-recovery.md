# D28 Calendar crash recovery and bounded repair

Recovery integrity and closure pass. The broader Calendar baseline remains ISSUES. Bulk Remove review failed and its whole-entry warning, Back, and confirmed-removal journeys remain BLOCKED. The three-port persistence cutover must wait for those affected journeys to pass.

The original report and every raw capture remain unchanged. Recovery adds this separate receipt and `/home/waffleflops/.cache/t2t-1376-calendar-recovery-check.json`. The rerunnable comparison is `/home/waffleflops/.cache/t2t-1376-calendar-recovery-check.py`.

## Closed sessions and original rows

The recovered checkout is clean at `6adc6bd628cf082395646679ea0d46e9526c5d25`, tree `ebad2c62db82477116a619643e51577eef02b5f4`. All 5,078 executable and driving inputs reproduce their recorded bytes, SHA256 values, exact selected input set, and candidate `1d214ff0f94fb0c3324ed6235a43496e0644099c0cf3b60740b541a5c1b26578`.

The first session `cf2eff63-4fdd-4d62-8b58-81e73d4a68fa` used port 36689. Its final doctor and clean-seeds receipts pass. The documented `verify:app restart --worker 2` completed with exit 0. The frozen CLI implementation awaits cleanup PASS before launching the next session. The replacement session `12fb3ad5-815d-41a9-9357-014d85d0ba8c` used port 39625. Its initial and final doctors, clean-seeds, and final cleanup pass. Both doctors bind the same original revision and candidate. After the crash, the owned worker directory is absent and neither original app port listens. No browser driver or active worker is inherited.

Direct recovery comparison confirms all original full rows across six tables in each Organization were exact before seeded destruction. The intentional status deletion removed `8e154ef9-6825-4fc1-9789-c3079127bf0a` and its availability entry `dec4e900-5871-4e1b-a305-a91dcc384cab`. Assignment deletion removed `a9330e13-f9e3-43dd-bd02-ea80ff4395ba` and its slot `402e8c8d-f8f9-4b24-b057-576a63be1c51`. All other A rows and all B rows remained exact.

Federal reset replaced custom holiday `126d4c99-0374-47b9-b99c-66ed9199726d` with 44 federal rows. It preserved the full original closure `5ec0aec9-2e29-4715-a479-26e166615f4b`. All 44 date/type pairs match the corrected independent expectation, and all 45 saved full rows remain exact after reload. The original incorrect Memorial Day expectation and its correction remain separate artifacts.

Restart regenerated a new dataset. Old and new fixture UUID sets are disjoint. Recovery compared all 12 table/Organization rowsets after mapping each UUID to its actual named fixture identity and excluding only the new generation's created_at and updated_at. Every other stored field and relation matches. This proves equivalent fresh fixtures. It does not restore or claim to restore original UUIDs or timestamps.

The raw directory contains 915 payload files, 17,940,904 bytes, 20 PNGs, and 7 genuine XLSX files. The recovery JSON inventories every original payload with bytes and SHA256. These counts are not a coverage claim. Root still owns independent acceptance of the complete behavioral package.

The older held-mutation route transition in `switch-mutation-history-back.json` used `evaluate_script` to invoke `history.back()`. The original receipt literally records that method. Its saved A/B effects remain observable, but this is not a native `navigate_page` action. The fresh repair run will inspect the native tool schema and use the supported back operation when a pending dialog makes the Organization menu inert, or the visible Organization menu when available.

## Actual failure and canonical repair

The actual `bulk-remove-real-failure.png` and `bulk-remove-temp-settled.txt` show Organization A, Leave, October 14, Able and Baker selected, and an actionable range-load failure. The native network receipt identifies request 1746 as GET `/org/undefined/api/calendar-range?rangeStart=2026-10-14&rangeEnd=2026-10-14`, status 404. Direct comparison of captured rows confirms A's six original entries plus the two native Add entries remain fully unchanged. B's original row remains unchanged. This malformed request is an application defect. It is distinct from the earlier valid foreign-Person batch 404 in the same network list.

`src/routes/org/[orgId]/calendar/bulk/+page.svelte` projects `resolvedData.orgId` and `resolvedData.orgName` into the bulk page. `materializeWorkspaceData` only replaces the streamed Calendar workspace and never creates those legacy fields. The Calendar layout supplies admitted `shell.org.id`. `BulkStatusPage.svelte` captures its page-data orgId and passes it into `loadCalendarRange`, which interpolates it into the request URL. The active-instance and current-org checks run after loading and cannot repair a wrong request identity.

Use the existing sibling pattern. Project `data.shell.org.id` and `data.shell.org.name` in the bulk route. Assignment Planner already uses that exact source, Calendar uses the shell ID, and Reports passes the shell ID and URL segment separately. A census of Calendar route legacy identity reads finds only this bulk projection. Keep the range callback's mounted-instance and current-org guards intact. No universal provider, fallback URL parser, null guard, new abstraction, SQL, migration, or batching redesign is needed.

This is a separate complete Calendar baseline repair. The planned Evals/Rating persistence PR can carry shared progress-record reconciliation while Calendar repairs its independent behavior. Root owns the main merge, shared recipes, records, manifest, commits, and publication.

## Required proof before the repair is accepted

Add a route-boundary regression that renders the actual bulk `+page.svelte` with canonical ready-shell data, a distinct URL alias, no legacy root orgId or orgName, and the real Remove component. Supply independently known Person, status, and overlapping entry facts. Selecting a Person and Review Matching Entries must send a range fetch for the canonical UUID and show that literal matching entry. This catches the current projection failure, which the existing `BulkStatusPage.test.ts` misses because it supplies a correct orgId directly. Preserve its stale response, unmount, and A-to-B-to-A tests.

Select the existing real Remove interaction tests, range-loader tests, bulk page lifetime tests, Calendar hydration/layout tests, and the analogous Assignment route test. Add only distinct route-projection protection. Run the required application commands and production build. No test will treat status 404 as a passing removal review.

Use a newly launched, frozen worker 2 after the current-main integration and root's build-slot grant. Capture actual native review through the real route and canonical endpoint. Cover the seeded Baker yesterday-through-tomorrow entry with today's partial-overlap warning, Back, and complete unchanged rows. Use the documented temporary overlap seed for confirmed whole-entry removal, retaining its full pre-state and ID, reload absence, original March and Baker rows, and all B fields. Exercise a matched synthetic range failure followed by restored-hook native retry, with no deletion before confirmation. Verify scoped Alpha, explicit empty scope, view denial, and a held Remove range across an Organization switch without stale A data or store effects. Keep helper readback and ordinary HTTP proof separate from native interaction.

Finish every seed-dependent comparison before clean-seeds. Restore all controls and temporary grants, final doctor, complete owned cleanup, then recompute every frozen input. Preserve any failed or unavailable path. No new native proof, SQL/RLS enforcement, transactional rollback, model diversity, or full Calendar persistence acceptance is claimed by this recovery.

## Methods and limits

Prove It Works drove direct hash, original-row, request, PNG, and disposal checks instead of accepting the worker summary. Fix Root Causes selected the route's canonical identity projection rather than a nil guard in the range loader. Sequence Work into Verifiable Units keeps the persistence refactor behind the repaired affected baseline. Model the Domain uses explicit table/Organization row maps and named fixture identities in the recovery comparison. Build the Lever leaves a rerunnable ignored comparison script. Technical Writing and Unslop keep the recovery claims scoped to their actual receipts.

Throughput checkpoint is n/a for this read-only recovery investigation. The generic inherited-model delegate has no model-diversity claim. No nested delegate, live session, tracked source edit, database mutation, commit, PR, watch, thread, or scheduler was created. Two source-path guesses failed before corrected file discovery. They changed no artifacts and establish no application failure.
