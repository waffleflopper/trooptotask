from drive import *
import sys

def data(result):return json.loads(re.search(r'```json\n([\s\S]*?)\n```',result)[1])
def evaluate(page,function,tag):return data(native('evaluate_script',{'pageId':page,'waitForStableDom':False,'function':function},tag))
def button(page,name,tag,last=False):
 s=snap(page,tag+'-before');lines=[x for x in s.splitlines() if 'button "'+name+'"' in x];assert lines and (last or len(lines)==1),(name,lines);click(page,re.search(r'uid=(\S+)',lines[-1])[1],tag)
def rows(table,org,tag,field=None,value=None):return control(['rows',table,org]+([field,value] if field else []),tag)['rows']
def same(a,b):return {r['id']:r for r in a}=={r['id']:r for r in b}
def loaded(page,org,allowed,tag):
 r=evaluate(page,'async()=>{const r=await fetch(location.pathname+"/__data.json");return {status:r.status,body:await r.text()};}',tag+'-ordinary-read');assert r['status']==200
 allids=[r['id'] for o in ['orgA','orgB'] for r in json.loads((E/('seeded-personnel_onboardings-'+o+'.json')).read_text())['rows']]
 actual={i for i in allids if i in r['body']};assert actual==set(allowed),(actual,allowed)
 (E/(tag+'-read-comparison.json')).write_text(json.dumps({'status':200,'expectedPacketIds':allowed,'observedPacketIds':sorted(actual),'organization':org},indent=2)+'\n')
def stages(page,stage,tag):
 s=snap(page,tag);assert 'Current stage: '+stage in s
 r=evaluate(page,'()=>Array.from(document.querySelectorAll("[aria-label$=\\"paperwork stages\\"] button")).filter(e=>e.checkVisibility()).map(e=>({text:e.textContent,disabled:e.disabled,current:e.getAttribute("aria-current")}))',tag+'-controls');assert len(r)==3 and all(x['disabled'] for x in r)
 current=[x['text'] for x in r if x['current']=='step'];assert (len(current)==1 and 'Reviewed' in current[0]) if stage=='Reviewed' else not current
 screen(page,tag)
def history_route(page,tag):
 s=snap(page,tag+'-route');
 if '/onboarding/history"' not in s.splitlines()[0]:
  if 'link "History"' not in s:click(page,uid(s,'link "Onboard"'),tag+'-onboard');s=snap(page,tag+'-board')
  assert 'button "Start Onboarding"' not in s if 'Verification Organization B' in s else True
  click(page,uid(s,'link "History"'),tag+'-history')
def setup():
 for command,tag in [('doctor','doctor-initial'),('tools','native-tool-schemas')]:
  r=subprocess.run(['npm','run','--silent','verify:app','--',command,'--worker','1'],text=True,capture_output=True);(E/(tag+'.json')).write_text(r.stdout);(E/(tag+'-stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stderr
 control(['fixture'],'fixture')
 for org in ['orgA','orgB']:
  for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:rows(table,org,'original-'+table+'-'+org)
 control(['seed','onboarding-history'],'history-seed')
 for org in ['orgA','orgB']:
  for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:rows(table,org,'seeded-'+table+'-'+org)
def history():
 seed=json.loads((E/'history-seed.json').read_text());tag=seed['tag'];actor=control(['actor','onboardingView','onboarding'],'view-actor');page=actor['pageId'];s=snap(page,'view-board');assert 'button "Start Onboarding"' not in s;click(page,uid(s,'link "History"'),'view-history-navigation')
 s=snap(page,'view-history');assert all('History'+k+tag in s for k in ['alpha','archived','bravo']) and 'Historyforeign'+tag not in s
 loaded(page,'orgA',[r['id'] for r in json.loads((E/'seeded-personnel_onboardings-orgA.json').read_text())['rows']],'view-history')
 click(page,uid(s,'button "SPC Historyalpha'+tag),'view-alpha-open');stages(page,'Reviewed','view-alpha-opened');s=snap(page,'view-alpha-before-notes');assert all(x in s for x in ['1/3 complete','Previously completed','Removed from template','History Training alpha '+tag]);lines=[x for x in s.splitlines() if 'button "Toggle notes"' in x];assert len(lines)==3;click(page,re.search(r'uid=(\S+)',lines[1])[1],'view-paperwork-notes');s=snap(page,'view-alpha-notes');assert 'History note Paperwork alpha '+tag in s;screen(page,'view-alpha-notes')
 s=snap(page,'view-keyboard-before-focus');click(page,uid(s,'button "SPC Historyalpha'+tag),'view-keyboard-close-by-click');key(page,'Space','view-keyboard-space-open');s=snap(page,'view-keyboard-opened');assert 'History Paperwork alpha '+tag in s;key(page,'Enter','view-keyboard-enter-close');s=snap(page,'view-keyboard-closed');assert 'History Paperwork alpha '+tag not in s;key(page,'ArrowDown','view-keyboard-next');key(page,'Enter','view-keyboard-next-open');s=snap(page,'view-keyboard-next-opened');assert 'History Paperwork archived '+tag in s and 'History Paperwork alpha '+tag not in s;screen(page,'view-keyboard-next-opened')
 native('navigate_page',{'pageId':page,'type':'reload'},'view-history-reload');s=snap(page,'view-history-reloaded');click(page,uid(s,'button "SPC Historyalpha'+tag),'view-reloaded-alpha-open');stages(page,'Reviewed','view-reloaded-alpha');s=snap(page,'view-reloaded-before-notes');lines=[x for x in s.splitlines() if 'button "Toggle notes"' in x];click(page,re.search(r'uid=(\S+)',lines[1])[1],'view-reloaded-paperwork-notes');s=snap(page,'view-reloaded-alpha-notes');assert 'History note Paperwork alpha '+tag in s
 print('Final History labels, saved stages, notes, keyboard disclosure and reload passed.',flush=True)
def scopes():
 seed=json.loads((E/'history-seed.json').read_text());tag=seed['tag'];a=json.loads((E/'seeded-personnel_onboardings-orgA.json').read_text())['rows'];people={r['id']:r for r in seed['people']};alpha=[r['id'] for r in a if r['personnel_id'] not in people or people[r['personnel_id']]['group_id']==json.loads((E/'fixture.json').read_text())['ids']['groupA']]
 for role,allowed in [('onboardingScoped',alpha),('onboardingEmpty',[])]:
  page=control(['actor',role,'onboarding/history'],role+'-actor')['pageId']
  for read in ['initial','reloaded']:
   if read=='reloaded':native('navigate_page',{'pageId':page,'type':'reload'},role+'-reload')
   s=snap(page,role+'-'+read);assert 'Historybravo'+tag not in s and 'Historyforeign'+tag not in s
   if role=='onboardingScoped':assert 'Historyalpha'+tag in s and 'Historyarchived'+tag in s
   else:assert 'Historyalpha'+tag not in s and 'SPC Able' not in s
   loaded(page,'orgA',allowed,role+'-'+read);screen(page,role+'-'+read)
 page=control(['actor','onboardingSwitch','onboarding/history'],'switch-actor')['pageId']
 for org in ['orgB','orgA']:
  s=snap(page,'switch-'+org+'-before');click(page,uid(s,'button "Switch organization"'),'switch-'+org+'-menu-open');s=snap(page,'switch-'+org+'-menu');click(page,uid(s,'menuitem "VO Verification Organization '+('B' if org=='orgB' else 'A')+' member"'),'switch-'+org+'-select');history_route(page,'switch-'+org)
  for read in ['initial','reloaded']:
   if read=='reloaded':native('navigate_page',{'pageId':page,'type':'reload'},'switch-'+org+'-reload')
   s=snap(page,'switch-'+org+'-'+read);allowed=[r['id'] for r in json.loads((E/('seeded-personnel_onboardings-'+org+'.json')).read_text())['rows']];loaded(page,org,allowed,'switch-'+org+'-'+read)
   if org=='orgB':assert 'Historyalpha'+tag not in s;click(page,uid(s,'button "SPC Historyforeign'+tag),'foreign-'+read+'-open');stages(page,'Archived review','foreign-'+read+'-stage')
   else:assert 'Historyforeign'+tag not in s and 'Historyalpha'+tag in s;screen(page,'returned-'+read)
 for org in ['orgA','orgB']:
  for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:assert same(rows(table,org,'history-after-'+table+'-'+org),json.loads((E/('seeded-'+table+'-'+org+'.json')).read_text())['rows'])
 print('Final Alpha/empty and A → B → A scope/readback passed; saved History/Training fields unchanged.',flush=True)
def dialogs():
 legacy=control(['seed','onboarding-legacy'],'legacy-seed');packet=legacy['packets'][0]['id'];page=control(['actor','onboardingConfigure','onboarding'],'configure-actor')['pageId'];before=rows('personnel_onboardings','orgA','start-before-parents');button(page,'Start Onboarding','start-open');s=snap(page,'start-dialog');assert 'Add Person' not in s;button(page,'Member','start-member-open');s=snap(page,'start-member-list');fill(page,uid(s,'combobox "Member"'),'Baker','start-baker-search');snap(page,'start-search-results');key(page,'Enter','start-baker-select');s=snap(page,'start-selected');render=evaluate(page,'()=>Array.from(document.querySelectorAll("[role=dialog] button")).filter(e=>e.checkVisibility()).map(e=>({name:e.getAttribute("aria-label"),text:e.textContent,disabled:e.disabled}))','start-rendered-selection');assert any('Baker' in x['text'] for x in render);screen(page,'start-selected');button(page,'Cancel','start-cancel',True);assert same(before,rows('personnel_onboardings','orgA','start-after-cancel-parents'))
 control(['network','arm-fail',str(page),'onboarding-resync'],'assign-failure-arm');s=snap(page,'assign-board');click(page,uid(s,'button "SM SPC MapLegacy'+legacy['tag']),'assign-card-open');button(page,'Assign Template','assign-dialog-open');button(page,'Template','assign-choice-open');snap(page,'assign-choices');key(page,'Home','assign-choice-first');key(page,'Enter','assign-choice-select');snap(page,'assign-selected-dialog');choice=evaluate(page,'()=>Array.from(document.querySelectorAll("[role=dialog] button")).filter(e=>e.checkVisibility()).map(e=>e.textContent)','assign-selected-rendered');assert any('Verification Onboarding A' in x for x in choice)
 bparent=rows('personnel_onboardings','orgA','assign-before-parent','id',packet);bprogress=rows('onboarding_step_progress','orgA','assign-before-progress','onboarding_id',packet);button(page,'Assign Template','assign-failure-submit',True);s=snap(page,'assign-failure-retained');assert 'dialog "Assign Template"' in s;screen(page,'assign-failure-retained');control(['network','state',str(page)],'assign-failure-control-state');assert same(bparent,rows('personnel_onboardings','orgA','assign-failed-parent','id',packet));assert same(bprogress,rows('onboarding_step_progress','orgA','assign-failed-progress','onboarding_id',packet));choice=evaluate(page,'()=>Array.from(document.querySelectorAll("[role=dialog] button")).filter(e=>e.checkVisibility()).map(e=>e.textContent)','assign-retained-choice');assert any('Verification Onboarding A' in x for x in choice)
 button(page,'Assign Template','assign-same-dialog-retry',True);s=snap(page,'assign-retry-immediate');assert 'dialog "Assign Template"' not in s;screen(page,'assign-retry-immediate');control(['network','state',str(page)],'assign-retry-control-state');saved=rows('personnel_onboardings','orgA','assign-saved-parent','id',packet);progress=rows('onboarding_step_progress','orgA','assign-saved-progress','onboarding_id',packet);assert saved[0]['template_id']==json.loads((E/'fixture.json').read_text())['ids']['onboardingTemplate'];assert len(progress)==6 and sum(r['active'] for r in progress)==3
 for original in bprogress:
  current=next(r for r in progress if r['id']==original['id']);assert all(current[k]==original[k] for k in ['completed','current_stage','notes'])
 control(['network','restore',str(page)],'assign-control-restore');native('navigate_page',{'pageId':page,'type':'reload'},'assign-reload');s=snap(page,'assign-reloaded-board');click(page,uid(s,'button "SM SPC MapLegacy'+legacy['tag']),'assign-reloaded-card-open');s=snap(page,'assign-reloaded-card');assert 'Verification Onboarding A' in s;button(page,'Switch Template','switch-dialog-open');s=snap(page,'switch-dialog');assert 'dialog "Switch Template"' in s;screen(page,'switch-dialog');button(page,'Cancel','switch-dialog-cancel',True);snap(page,'switch-dialog-cancelled');assert same(saved,rows('personnel_onboardings','orgA','switch-cancel-parent','id',packet));assert same(progress,rows('onboarding_step_progress','orgA','switch-cancel-progress','onboarding_id',packet))
 (E/'observed-final-outcomes.json').write_text(json.dumps({'result':'PASS','sourceRevision':json.loads((E/'prelaunch-input-hashes.json').read_text())['revision'],'scope':'History ownership and saved-stage display, native labels/notes/disclosure/reload, scoped ordinary reads, A-B-A switching; new public Start/Assign/Switch dialog loader mount/cancel and synthetic503 retained-choice/actual200 Assign retry.','limits':'Synthetic503 is client recovery, not provider rejection. Switch mounts/cancels only; accepted #1470 saved-Switch proof is reused for unchanged implementation. Inactive notes retained by provider rows; History has no author label/note editor. Export/AddPerson/Calendar/Training mutations/remaining API access/broader concurrency are issue remainder.','savedProgressRows':len(progress),'activeProgressRows':sum(r['active'] for r in progress)},indent=2)+'\n')
 print('Final public dialog loader, cancel, retained failure and actual assignment retry passed.',flush=True)
{'setup':setup,'history':history,'scopes':scopes,'dialogs':dialogs}[sys.argv[1]]()
