() => {
  const ctx = document.createElement('canvas').getContext('2d');
  const out = {};
  for (const fam of ['"IBM Plex Mono"', 'monospace', 'sans-serif', '"DejaVu Sans Mono"', '"Liberation Mono"']) {
    out[fam] = ['100%', '74%', 'Goal 95%'].map((s) => {
      ctx.font = `${s.startsWith('Goal') ? 400 : 600} ${s.startsWith('Goal') ? 11 : 12}px ${fam}`;
      const m = ctx.measureText(s);
      return { s, width: +m.width.toFixed(2), ascent: +m.actualBoundingBoxAscent.toFixed(2), descent: +m.actualBoundingBoxDescent.toFixed(2), capPerEm: +(m.actualBoundingBoxAscent / (s.startsWith('Goal') ? 11 : 12)).toFixed(3) };
    });
  }
  out.faces = [...document.fonts].map((f) => `${f.family} ${f.weight} ${f.status} ${f.unicodeRange?.slice(0, 40)}`);
  return out;
}
