# 1503 final chart v7 evidence index

Candidate `7159b967…c055`, revision `3c0b6f2a`, origin `http://127.0.0.1:42057`, worker 1, Chromium 152.0.7977.82, session `983bff0a…`. Driven 2026-10-04 00:07–01:55 AKDT (asOf 4 Oct throughout, no midnight crossing). Actor `orgOwner`, page 2, browserContext `map-orgOwner-2ebcb606-…`.

## Actual captured output (not hand-written)

- `receipts/NNNN-label.{json,stdout,stderr}`: one receipt per CLI invocation written by `driver/d.sh`. The JSON holds argv (native tool name and input arguments), start/end time and exit code. stdout/stderr are complete process output with a defensive token/cookie redaction pass. 2,570 invocations in all.
- `measure/sweep/g{goal}-{theme}-{width}-{state}-{horizon}.json`: read-only `evaluate_script` measurements of rendered forecast marks, written by the native tool's `filePath`. 684 cases.
- `measure/d1/*.json`, `measure/hires/*.json`, `measure/focus-*.json`, `measure/fallback-font-metrics.json`, `measure/m000*.json`, `measure/fonts-0001-mixed.json`: the same kind of measurement.
- `snap/`: native `take_snapshot` files. `png/`: native `take_screenshot` files. `png/sweep/` and `png/hires/` are crops of native full-page/DPR2 screenshots (crop geometry comes from the matching measurement JSON).
- `downloads/training-report-filtered.xlsx`: Blob from the native Export Excel click (12,252 bytes, sha256 `eeefca82…e548`).
- `http/detail-cell-response.network-response`: native `get_network_request` body of the cell detail request.

## Derived (interpretation or tooling)

- `driver/`: the lever. `d.sh` (receipt wrapper), `sweep.sh`, `hires.sh`, `d1flow.sh`, `goal.sh`, `topolicies.sh`, `measure.js`, `d1.js`, `focus.js`, `fonts.js`, `fallback.js`, `analyze.py`.
- `measure/analysis-*.txt`: `analyze.py` output over the sweep JSON.
- `zoom/`: `magick` montages/crops of the PNGs above.
- `tmp/sweep-*.log`: sweep progress logs.
- `png/sweep-bad390/`: superseded first-pass 390 crops. The full-page capture missed the chart because `main` is the scroll container, not the document. The measurements from that pass are valid. Crops were redone with a 2400px-tall emulated viewport.

## Capability and redaction notes

- No credentials, cookies or auth bodies were printed or saved. The actor helper keeps synthetic credentials private. The `get_network_request` header list is the tool's own redacted list.
- No `preview_*`, Playwright, personal Chrome, HTTPS sidecar or other origin was used.
