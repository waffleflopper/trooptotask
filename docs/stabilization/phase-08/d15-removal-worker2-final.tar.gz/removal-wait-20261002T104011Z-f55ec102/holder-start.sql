SELECT json_build_object('event','identity','pid',pg_backend_pid(),
 'backend_start',(SELECT backend_start::text FROM pg_stat_activity WHERE pid=pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout='10s';
SET LOCAL lock_timeout='3s';
SET LOCAL idle_in_transaction_session_timeout='75s';
SELECT json_build_object('event','locked','id',id) FROM public.onboarding_step_progress
WHERE organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND onboarding_id='c973d7bd-307b-4a62-8320-bb0dba51268d'::uuid
 AND id='8950d7f6-e9e5-410d-9ca7-6281769d410b'::uuid AND NOT active AND NOT completed AND step_type='paperwork'
 AND current_stage='Reviewed' AND template_step_id='4a0cc039-99ce-4163-9048-825fdffc7af6'::uuid
 AND notes='[{"text": "Legacy retained work 5d768585", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "cb28ab00-eca9-472a-8d34-1af7965c912b"}]'::jsonb FOR UPDATE;
SELECT json_build_object('event','ready');
