from pathlib import Path
import json,subprocess,os,hashlib,datetime,re,socket

repo=Path.cwd();root=repo/'.verification/evidence/verify-trooptotask/d13-artifact-server-final-native';api=root/'ordinary-api'
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a1a8af8f89cb9f18/worker-1')
os.environ['TMPDIR']='/home/waffleflops/.cache/t2t-d13-context-root-tmp'
digest='687d977f5a85802272632f6c20798692d013eb91465dc4ec185055348faae272'
read=lambda p:json.loads(p.read_text())
write=lambda name,x:(root/name).write_text(json.dumps(x,indent=2)+'\n')
summary=read(api/'runner-summary.json')
assert summary['status']=='PASS' and summary['ordinaryArtifactRequests']==176
assert summary['statusCounts']=={'200':79,'403':17,'404':69,'409':4,'400':6,'413':1}
assert not (api/'runner-stopped.json').exists()
state=read(private/'session.json');assert state['id']=='5c036f4f-1ff3-4f32-a4a0-2fb007980830' and state['candidate']==digest
config=read(api/'config.json');context=read(root/'context-seed.json')
project=re.search(r'^project_id\s*=\s*"([^"]+)"',(private/'provider/supabase/config.toml').read_text(),re.M).group(1)
processes={k:{'pid':state[k]['pid'],'start':state[k]['start']} for k in ['supervisor','appProcess','mcpProcess','browserProcess']}
write('coordinator-cleanup-owned-identities.json',{'session':state['id'],'candidate':digest,'projectId':project,'origin':state['origin'],'controlPort':state['controlPort'],'processes':processes})

def call(name,cmd,parse=True):
 target=root/(name+'.stdout.json' if parse else name+'.stdout.txt')
 assert not target.exists(),'Refuse duplicate command receipt '+str(target)
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/'coordinator-cleanup-commands.jsonl').open('a') as f:f.write(json.dumps({'name':name,'command':cmd,'startedAt':started})+'\n')
 p=subprocess.run(cmd,text=True,capture_output=True)
 target.write_text(p.stdout);(root/(name+'.stderr.txt')).write_text(p.stderr)
 write(name+'.process.json',{'command':cmd,'exitCode':p.returncode,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 assert p.returncode==0,name+' exited '+str(p.returncode)
 return json.loads(p.stdout) if parse else p.stdout

def control(name,args):return call(name,['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args])
tables=['personnel','personnel_follow_ups','counseling_records','personnel_documents','leader_notes','personnel_trainings','personnel_ict_completions','rating_scheme_entries','availability_entries']
def compare_collections(folder,phase,before_folder,before_phase,receipt):
 entries=[]
 for org in ['orgA','orgB']:
  for table in tables:
   before=read(before_folder/f'{before_phase}-{org}-{table}.json');after=read(folder/f'{phase}-{org}-{table}.json')
   b={r['id']:r for r in before['rows']};a={r['id']:r for r in after['rows']}
   assert len(b)==len(before['rows']) and len(a)==len(after['rows'])
   assert a==b,(org,table,'complete rows changed')
   entries.append({'organization':org,'table':table,'count':len(a),'before':str((before_folder/f'{before_phase}-{org}-{table}.json').relative_to(root)),'after':str((folder/f'{phase}-{org}-{table}.json').relative_to(root)),'exactIdsAndEveryField':True})
 write(receipt,{'status':'PASS','collections':18,'rows':sum(e['count'] for e in entries),'entries':entries})

call('coordinator-api-final-collections',['python3',str(api/'capture-collections.py'),'final'])
compare_collections(api,'final',api,'original','coordinator-api-final-comparison.json')
assert sum(x['count'] for x in read(api/'final-collections.json'))==47

paths={}
def add(org,person,kind,path):
 if path is None:return
 key=(org,person);paths.setdefault(key,{})
 if path in paths[key]:assert paths[key][path]==kind
 paths[key][path]=kind
for person,items in read(api/'32-final-originals-recorded-paths.json').items():
 for path,kind in items:add('orgB' if person=='foreign' else 'orgA',config['people'][person],kind,path)
native=read(root/'native-created-identities.json')
for key,kind in [('counsel','counseling'),('document','document')]:
 row=native[key];add('orgA',row['personnel_id'],kind,row['file_path'])
for org in ['orgA','orgB']:
 for table,kind in [('counseling_records','counseling'),('personnel_documents','document')]:
  for row in read(api/f'original-{org}-{table}.json')['rows']:add(org,row['personnel_id'],kind,row.get('file_path'))
write('coordinator-recorded-file-paths.json',[{'organization':org,'personnelId':person,'files':[{'path':p,'kind':kind} for p,kind in sorted(items.items())]} for (org,person),items in sorted(paths.items())])
for index,((org,person),items) in enumerate(sorted(paths.items())):
 args=['artifact-files',org,person]
 for path,kind in sorted(items.items()):args.extend([kind,path])
 control(f'coordinator-before-seed-clean-files-{index}',args)

control('coordinator-restore-native-network',['network','restore','2'])
membership=context['membership']['id']
before=control('coordinator-before-seed-clean-membership',['rows','organization_memberships','orgB','id',membership])
assert before['count']==1 and before['rows'][0]['id']==membership
owned=read(private/'verify-trooptotask-owned.json')
write('coordinator-before-seed-clean-ownership.json',{'seeded':owned['seeded'],'grants':owned['grants'],'httpCacheExists':(private/'artifact-http-sessions'/state['id']).exists()})
control('coordinator-clean-seeds',['clean-seeds'])
call('coordinator-cleaned-collections',['python3',str(root/'capture-collections.py'),'cleaned'])
compare_collections(root,'cleaned',root,'original','coordinator-cleaned-original-comparison.json')
assert sum(x['count'] for x in read(root/'cleaned-collections.json'))==13
file_count=0
for index,((org,person),items) in enumerate(sorted(paths.items())):
 args=['artifact-files',org,person]
 for path,kind in sorted(items.items()):args.extend([kind,path])
 result=control(f'coordinator-after-seed-clean-files-{index}',args)
 assert len(result['files'])==len(items) and all(not x['present'] for x in result['files'])
 file_count+=len(result['files'])
after=control('coordinator-after-seed-clean-membership',['rows','organization_memberships','orgB','id',membership])
assert after['count']==0
owned=read(private/'verify-trooptotask-owned.json')
assert owned['seeded']==[] and owned['grants']==[] and not (private/'artifact-http-sessions'/state['id']).exists()
write('coordinator-after-seed-clean-ownership.json',{'seeded':owned['seeded'],'grants':owned['grants'],'httpCacheExists':False,'temporaryMembershipRows':0,'confirmedRecordedPathsAbsent':file_count,'unknownOrphanClaim':False})

manifest=root/'frozen-inputs.sha256'
call('coordinator-frozen-input-hashes',['sha256sum','-c',str(manifest)],False)
deleted=read(root/'deleted-inputs.json');assert len(deleted)==14 and all(not (repo/p).exists() for p in deleted)
write('coordinator-frozen-input-comparison.json',{'status':'PASS','regularInputs':len(manifest.read_text().splitlines()),'deliberateRemovedInputs':len(deleted),'candidate':digest,'allHashesMatch':True,'allRemovedInputsAbsent':True})
doctor=call('coordinator-final-doctor',['npm','run','--silent','verify:app','--','doctor'])
assert doctor['status']=='PASS' and doctor['candidate']==digest and doctor['session']==state['id']
cleanup=call('coordinator-owned-cleanup',['npm','run','--silent','verify:app','--','cleanup'])
assert cleanup['status']=='PASS'
survivors={}
for name,item in processes.items():
 stat=Path('/proc')/str(item['pid'])/'stat'
 alive=False
 if stat.exists():
  text=stat.read_text();fields=text[text.rfind(')')+2:].split()
  alive=fields[0]!='Z' and str(fields[19])==str(item['start'])
 survivors[name]=alive
assert not any(survivors.values())
ports=[35419,state['controlPort']];open_ports=[]
for port in ports:
 with socket.socket() as sock:
  sock.settimeout(1)
  if sock.connect_ex(('127.0.0.1',port))==0:open_ports.append(port)
assert not open_ports and not private.exists()
names=call('coordinator-provider-container-names',['docker','ps','-a','--filter','name='+project,'--format','{{.Names}}'],False)
owned_containers=[n for n in names.splitlines() if n.endswith('_'+project)]
assert not owned_containers
write('coordinator-disposal-verification.json',{'status':'PASS','workerDirectoryAbsent':True,'originalOwnedProcessesSurvive':survivors,'checkedPorts':ports,'openCheckedPorts':open_ports,'exactProjectContainerNames':owned_containers,'projectId':project,'rawEvidencePreserved':root.is_dir(),'candidate':digest,'originalRows':13,'apiFinalRows':47,'confirmedRecordedPathsAbsent':file_count})
print(json.dumps({'status':'PASS','apiFinalRows':47,'cleanedOriginalRows':13,'recordedPathsAbsent':file_count,'frozenInputs':len(manifest.read_text().splitlines()),'deletedInputs':len(deleted),'doctorCandidate':digest,'ownedDisposal':True}))
