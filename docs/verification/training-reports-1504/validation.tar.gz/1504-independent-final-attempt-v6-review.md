# Independent final-attempt-v6 artifact acceptance

The expanded v6 archive is internally consistent and supports native acceptance of the report Retry focus repair (F1), controlled matrix deselection repair (F2), and the short-detail PDF content boundary repair (F3) at source `77b55954cd1545814e1581e9d54e254d43c9c14b`. Whole-issue acceptance is **not clean at this pin**: N3 empty-panel Clear filters loses focus to BODY (P3), N2 Focus opens with a redundant report page-data request (P4), and the independently read source exposes the analogous export-error Retry disappearance pattern (P3, source inference only). Future source corrections and native v7 are not accepted by this report.

This is a bounded offline artifact audit: actual inventory, archive members and bytes, structured native receipts and evaluations, accessible snapshots, actual XLSX XML, PDF metadata/text, fixture readbacks, doctor and cleanup proofs. I did not operate the browser, execute app/test/services, inspect images, judge layout or pixels, mutate Git/source, use network, or execute SQL. The Claude driver's actual native execution and visual judgments are distinct from my inherited-model artifact review. Poteto generic persona, Prove It Works and Test Behavior Not Implementation were applied with t2t-engineer and repository contracts; bounded parent authority controls this review. Source/model/auth/export contracts remain governed by the preceding complete source reviews rather than being inferred from a screenshot or driver's conclusion.

## Exact pin and package

| Item | Actual value |
| --- | --- |
| Tested source | `77b55954cd1545814e1581e9d54e254d43c9c14b` |
| Integrated and reviewed base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Runtime candidate | `c568cd28014146aa637a0d818d83a2a2738ed0894a9b998d8c067dc8678868e9` |
| Session | `764a2288-b285-46b9-a6e2-5e0b1d8b9770` |
| Origin | `http://127.0.0.1:36135` |
| Archive | `docs/verification/training-reports-1504/final-attempt-v6.tar.gz` |
| Archive bytes / SHA256 | `3621597` / `b829e3a7c14995246df148fc0e487e9baad07c715cdadf137b8abc764f51f644` |
| Expanded package | `.verification/packaged/1504/final-attempt-v6` |
| Archive-only commit | `2aa7a2ea2ae0774d56d6594747fc27b4e2a69bb9` |

The inventory has exactly 944 unique payload paths. All payload byte sizes and SHA256 hashes match actual expanded files. The expansion has 945 files, with only the inventory itself additional. The tar has 945 unique regular members, no special members, and all member bytes equal the expanded counterparts. There are no missing, extra or mismatched payloads. The inventory is package evidence, not an independent promise of application success.

The root source checkpoint has 145 changed paths versus integrated ee1; every actual Git blob/deletion pin matches and the ordered census equals actual read-only Git diff. Independently reproduced scoped binary source patch SHA256 is `216bd8d64ff20528e2a2e14c87efec8c985b4b1eb2216ee1c8b9e110a0395476` (`src scripts supabase .agents/skills/verify-trooptotask`). Read-only diff of 77b559 to 2aa7 confirms only the v6 archive was committed. The preceding source-v3 report remains 24,751 bytes, SHA256 `03e2eb2a4cf5f28430386053f7572351ca1e7e3358767dc25f23928053c901d8`; the preceding native-v5 report remains 26,499 bytes, SHA256 `29e9c4078e99874f22eb59dd994b6c372160434ee21f54c0637f10e14941c687`. The old v5 F1/F2 findings remain valid at a586; acceptance here is tied to 77b559.

Chromium was actual local 152.0.7977.82 on Arch Linux at `/usr/bin/chromium`, not provisioned by this review. Configure actor used page 2; a new isolated trainingEmpty actor used page 3. Actual dispatch metadata records a Claude agent, `claude-opus-5-5`, medium effort and `inheritHistory:false`. I read the driver report, root closeout and actual artifacts; neither the report nor helper output alone substitutes for a native action.

## Receipt accounting and unsuccessful actions

There are 399 unique driver receipts: 396 exit zero and 3 exit two. Of 399 stdout files, 398 parse as whole JSON; `206-print-save` has empty stdout and the exact guard refusal in stderr. All other stderr files are empty. I parsed 103 native evaluation values and audited 44 before/action/after groups, including each action's actual argv, checked values, active element, URL, data selection and newly relevant Training requests. The 95 native network-list payloads have complete pagination (`hasNext:false`, `invalid:false`). Root has 3 launch, 12 fixture and 15 closeout receipts, all exit zero with parseable actual stdout JSON and empty stderr.

| Receipt / observation | Actual outcome and disposition |
| --- | --- |
| `063-release-action` | Exit 2 `BLOCKED/HARNESS`: invalid native command `bash -c`; reached no browser. The documented `063-release-cmd` helper then returned `released:true`. This is a harness correction, not an end-user action. |
| `206-print-save` | Exit 2, empty stdout: `Map control blocked: Native page ID and unique exact report URL must agree.` Both isolated pages had the same report URL. Repair is detailed below; refusal is retained. |
| `242-wait` | Exit 2 `INCONCLUSIVE/DEVTOOLS_TOOL`: accessible-name wait timed out at 15000 ms. Actual `243-snap.txt` replaced the observation. The timeout is not a successful action. |
| `051-group-fail` | Exit zero native click actually hit StaticText `VERIFICATION REQUIRED TRAINING` in a header. No Training request or error was produced; armed hook calls stayed empty. It does not prove a failed Group transition. The intended Group click `053` produced the one 503 recorded at `054`. |

Inspection-only evaluations, readbacks, native snapshots, no-op/negative commands and helper hook operations are not counted as successful user actions. Pointer or keyboard actions are accepted only with their actual before/after evidence. This report does not hide the three nonzero receipts or the mis-targeted click.

## Findings and acceptance at the tested pin

| ID | Severity | Evidence | Disposition at 77b559 |
| --- | --- | --- | --- |
| v5 F1 report-level Retry loses focus | P3 | `059`, `076`, `096` native actions; held/released evaluations `060/064`, `077/079`, `098/100`; actual snapshots | **Accepted repaired**: click and Enter move to persistent labelled briefing region while held; no response autofocus steals moved focus. |
| v5 F2 stale selected cell after closing detail | P3 | `014` selected 11B cell; `017` horizon closure; `020` reopen; `022` Focus transition; `151` later horizon closure | **Accepted repaired**: no stale `data-selected` or accessibility selection remains when detail closes or becomes Focus scope. |
| v5 F3 short detail heading/table split | P3 minor, visual severity delegated | Actual four-page short PDF text: heading, explanation, range, table header and Baker row all on page 4; Claude visual verdict | **Content boundary accepted**; visual layout judgment belongs to Claude. No image review performed here. |
| N2 redundant Focus page-data request | P4 | `022-focus-link-action` and actual new request IDs 148/149 | **Open at old pin**: report page-data GET plus necessary detail GET on one Focus interaction. Hover-preload cause is source inference, not an isolated hover experiment. |
| N3 empty-panel Clear filters focus | P3 | `121-empty-clear` before/action/after; actual default summary GET ID 134; after active element BODY | **Open at old pin**: activated control disappears and leaves focus BODY despite persistent labelled briefing region. |
| Export-error Retry disappearance | P3 source-inferred | Actual 77 source `exportExcel()` clears `exportError` before awaiting fetch; alert Retry calls it directly; disappearing-action census | **Open source concern at old pin**, not natively exercised by v6. A future fix is separate. |
| N4 Print brief wraps legibly at 390 | P4 note, delegated visual | Driver visual observation; narrow snapshot/text | Usable visual note, not an independently actionable objection. No pixel judgment here. |
| N1 first roving Tab item unchecked | Unestablished baseline note | Prior driver note; not retested in v6 and no established base regression | Retain limitation; do not invent a change requirement. |

No additional P1/P2 actionable objection was found in the bounded artifact audit. Source corrections to N2/N3/export Retry, a future native v7 and current-main integration remain outside this v6 acceptance.

## Canonical selections, detail and report Retry

The original Configure organization A has three soldiers and four applicable requirements: one current completion, three missing, no expired or impending lapses. Literal default readiness is 25%, not a shorthand aggregate. Alpha aggregate is 50%; its Required type is 100% and Targeted 0%. Bravo and Unassigned are 0%. Initial summary navigation has no extra summary API waterfall beyond the recorded route data load.

At `014`, native activation of MOS 11B / Required obtains one detail request (ID 145, horizon 30, rowsBy mos, correct row/type). The affected-soldiers section is focused; Baker is the sole row; the clicked TD has `data-selected:true` and its accessible label ends in selected. `017` selects 60: one summary request 146, detail closes, both actual selection lists empty, focus remains 60 radio and URL is 60/mos. `020` reopens detail with request 147. `022` native Focus then selects the focus link and clears matrix TD selection while showing Baker plus Unassigned (rows 1–2 of 2). Both stale visual-state marker and accessibility selection are absent. The detail region receives focus; the link is current. Later `151` horizon 60 repeats a successful closure with no stale selection. An early inspection's incidental `ranges:[]` is not evidence of absent detail: the next actual snapshot explicitly shows the row range.

The `022` interaction generated two relevant 200 GETs: request 148 `/training/reports/__data.json?horizon=60&rowsBy=mos&x-sveltekit-invalidated=0011#training-affected-soldiers` and request 149 `/api/training-reports/detail?horizon=60&rowsBy=mos&scope=focus&focus=gap%3A398...`. The former is redundant for the client-side prevented-default focus selection. Its source origin is consistent with inherited hover data preloading, but this artifact does not separately isolate hover timing or establish that every Focus link always preloads.

Ten separate active-option repetitions are supported by actual native pointer/Space receipts: 25 click/Space (`030/031`), 60 click/Space (`032/033`), MOS click/Space (`034/035`), 100 re-click/Space (`037/038`), and cohort 100 re-click/Space (`178/179`). After every activation each present group still has exactly one checked radio, checked values and URL remain identical, detail/range remains identical, and there is no new relevant Training request. The earlier v5 independently accepted pointer+Space for all six options at a586; v6 adds these ten checks, not a fresh all-six-options census. Genuine 100 selection produces exactly one detail request 150; genuine 30 produces summary 151. Native reload `040` retains URL 30/mos and checked canonical values. Its captured fetch/XHR slice has only notification activity; that is not a claim that the browser made no document/route requests during reload.

Report-level recovery was exercised through real native controls and deterministic synthetic hooks:

- Intended Group click `053` gives one summary 503 and keeps the loaded 30/mos canonical URL/data. After documented restoration plus hold, `059` native pointer Retry focuses `SECTION#training-briefing`, aria label `Training readiness briefing`, tabindex -1, while `aria-busy:true`. Attempted Group is checked while URL remains the loaded 30/mos state. Exactly one held GET ID 273 is present. Actual held snapshot `062` confirms the focused region. Correct helper release completes; `064` shows region still focused, busy false, Group canonical and no error.
- MOS failure `071` gives one 503; `072` ShiftTab focuses Retry. `076` Enter Retry moves focus to the same stable region while held, attempted MOS checked and previous Group URL preserved. Exactly one held GET 274; after release `079` shows the region still focused, MOS canonical and no error.
- Group failure `091` gives one 503; `092` ShiftTab focuses Retry; `096` Enter Retry moves focus to the region while held (one GET 275). Native Tab `097` intentionally moves to the Group radio. After release `100`, focus remains on that radio. There is no response-time focus steal.

The no-types Retry path is covered by prior behavioral source tests, not by a native no-types v6 action. Empty native briefing-region presence confirms the wrapping exists but does not certify that separate Retry branch. No source test substitutes for these actual native focus receipts.

## Empty actor and paging

The separate trainingEmpty actor opens a new isolated context at `111`. Snapshot `114` shows zero soldiers, no applicable requirements, disabled Excel, and no fabricated readiness chart values. At 1440 width, native 60 selection produces summary request 133. At 390 width, actual snapshot `119` contains both the header and the no-data panel Clear filters controls. Native `121` activates the panel control (UID 24_1): summary GET 134 returns default data, URL returns to reports and 90 is checked, but the panel control unmounts and the active element becomes BODY. The stable labelled briefing section still exists. This is N3; a header Clear focus loss is plausible from the same source handler but is not a native action proven here. TrainingEmpty preferences before/after are equal against the driver's own baseline, distinguished from root-original Configure restoration below.

Seeded cohort detail has 28 affected Required soldiers. `165` opens Total range 1–25 of 28 (request 521); native Next `167` gets page 2 (522), range 26–28, Next disabled, detail section focused. Native Previous `170` gives one 503; loaded final range and three rows remain, focus is Previous. After restored transport, `174` ShiftTab focuses actual Retry; native Enter `175` obtains page 1 (523) and focuses the section. `177` selects 100 (524), range 1–28 of 28. Repeated 100 checks are separately verified above. No pager success is inferred from a no-op or helper call.

## Real workbook and identity arithmetic

Native `183` is exactly one Export Excel click, after documented observer/transport arming. Actual observer state `184` contains 12,470 bytes; `185` records exactly one successful GET, correct dated filename and Excel MIME. `186` saves the exact captured download whose bytes/hash equal the packaged workbook. This is a single-click export, unlike v5's driver duplicate-click limitation. Hooks are restored at `187/188`.

The actual ZIP workbook relationships, ordered sheet definitions, shared strings and all worksheet cell XML were parsed. Exactly five ordered sheets are `Summary`, `Forecast`, `Hot spots`, `Focus`, `Requirements`; there are no formulas. The workbook represents the full report despite an open detail slice.

Summary has 29 soldiers, as of 2026-10-04, horizon end 2027-01-02, goal 90, readiness 3% → 3%, Ready 1, 31 applicable requirements, missing 30, expired/lapse zero, full filters 90/Group. Forecast is today plus 13 bucket ends (14 actual data points): Oct 11/18/25, Nov 1/8/15/22/29, Dec 6/13/20/27 and Jan 2, with final short interval Dec 28–Jan 2. Each point is Ready 1 / 3%, zero lapses. Hot spots contain Bravo, Unassigned, Alpha and Total. Alpha has 27 soldiers, Required 4%, Targeted 0%, aggregate 3%; Total 29 has Required 3%, Targeted 0%, aggregate 3%. Focus independently recomputes Required renewal of 28 gaps as 29/31 → 94%, and Targeted renewal of two as 3/31 → 10%.

Actual Requirements has 30 data rows: 28 Required and two Targeted, all Not Done, no expiration/lapse date and no in-horizon lapse. Names are Able/Targeted, Baker/Required, `MapTraining83b7334e00, Synthetic` twice (Required and Targeted), `MapTraining83b7334e01` through `...25` Required, and Unassigned/Required. All 26 expected synthetic names appear exactly as expected. Targeted applies only to original Able and first seeded 68W Medic; non-applicable/Optional cells and current Able Required are absent. Thus 29 People with 29 Required plus two Targeted are 31 applicable; one ready leaves 30 affected. The open Total Required detail has 28 rows and does not narrow the 30-requirement workbook.

The actual seed response records kind training-pages, tag `83b7334e`, count 26 and first UUID `3050554e-9581-4644-8965-f02ff29a91bc`. The public package exposes that first UUID, not a complete 26-UUID journal. The actual workbook/PDF name set and the complete original/restored readbacks establish cohort identity/removal without inventing a full public UUID census. Root explicitly records journaled cleanup; the private work directory and private journal were removed with the owned worker.

## Four native print invocations and actual PDFs

Four native Print brief invocations produced four actual PDFs, 15 total pages, all letter landscape 792×612 points. Every recorded pre-capture state has `beforePrintCount:1`, `afterPrintCount:0`; each initial arm is 0/0 and restores afterward. There is no physical printer/dialog acceptance in this audit.

| Actual file | Bytes | Pages | SHA256 |
| --- | ---: | ---: | --- |
| `training-brief-empty.pdf` | 70133 | 1 | `b78725a881cc4b2557dd683a0a19c6c2a0b0848db716ab26def756d6604fd1a9` |
| `training-brief-30-mos-11b.pdf` | 174290 | 4 | `89326b524eefba3c8ccdb5ba92206be0f96e22b196cd4fcd7cde9bca62661c07` |
| `training-brief-cohort-25.pdf` | 253181 | 5 | `ac1d03f61a0d005e4692dc90abc969ffde4a9caf42a0c0cc5f3a40adaaf28185` |
| `training-brief-cohort-100.pdf` | 261493 | 5 | `52ad7059ff0c1637e71b9a7dcd2a4357710c25eb5892ec08cd646614be9caa26` |

Empty: native print `127`, state `128`, exact page3/URL-bound save `129`; actual single page has organization/date/zero soldiers/full filters and no-applicable-requirements explanation, no false numeric readiness.

Short: fresh reload, 30/mos and 11B Required detail (`141–144`), native print `146`, state `147`, exact page2/30-mos save `148`. Actual page1 holds full briefing counts and filters; page2 holds 30-day forecast/90% goal and MOS grid; page3 holds type risks and Focus. Actual page4 contains detail eyebrow, Affected soldiers heading, explanation, rows 1–1 of 1, seven-column table header and Baker row together. The previously split heading/table boundary is repaired in actual text. Spacing, cropping, color and readability verdicts are Claude's delegated visual review, not this audit.

25 rows: reload/default90/Group/Total range 1–25 of 28 at `200–202`; native print `204`; prestate `205` at 15:37:14 proves beforeprint once. Save `206` at 15:37:18 was refused because the other isolated page had the same exact report URL. Print observer was restored at `207` (15:37:22). Native `208` moved only the other TrainingEmpty page3 to Training matrix (15:37:40), disambiguating the URL; read-only `209` at 15:37:42 confirms page2 still has original reports90/Group/25/Total range and Print focus. Same authorized page2/URL save `210` at 15:37:44 then succeeds. This is one documented bounded URL-guard repair, not another native Print invocation; there is no fresh immediately-before-210 observer counter after restore. The earlier native invocation/prestate remains proof for the unchanged page2. The refusal and timing are retained.

100 rows: fresh reload, Total, native 100 gives range 1–28 of 28 (`220–224`); native print `226`, prestate `227`, exact page2/defaultURL save `228`, restore `229`.

The two long PDFs have identical first-three-page text: full29-soldier filters/counts, 3% forecast with goal90, Group matrix and risk/Focus outputs. Page4 in each has heading/status/range and all seven headers plus Baker and seed00–14 (16 rows). Page5 repeats all seven headers: 25 version seed15–23 (9 rows), 100 version seed15–25 plus Unassigned (12 rows). Actual names and order match the workbook Required subset: exactly 25 distinct visible rows or all 28 distinct rows, no duplicate or missing expected row. Each table page has actual rows, not a header-only page. Every PDF page has nonblank extracted text. This verifies metadata/text boundaries and content; it does not certify pixel clipping.

All extracted PDF text omits Export Excel, Print brief, Rows per page, Retry, Clear filters, Navigation, Account, View soldiers and Notifications. Legitimate Rows by and Forecast Next labels remain. Captured console `153` has 13 entries and no LayerCake zero-width/negative-rect warning in that bounded slice; MIME/404/preload messages remain. A claim of a wholly clean app console would be false or unproven. Older v4 dark-chart warnings remain historical counterevidence, not silently removed by this run.

## Shared consumer continuity

Native Training breadcrumb `241` reaches the shared Training Matrix. The `242` wait timeout is retained; actual snapshot `243` shows the relevant cells. Original completion readback `244` is unchanged. Native Baker Required Not Done cell click `246` opens Add Training Record dialog (actual evaluation `247` and snapshot `248`); native Cancel `250` closes it, returning focus to the Baker cell (`251`). The internal `data-selected` memory remains for this uncontrolled matrix consumer as designed; its accessible label does not claim selected. Computed outline observations are recorded, not independently visually judged. Complete native request slice `253` has no POST/PUT/PATCH/DELETE, and final completion readback `254` equals `244` and root original bytes. No save/write was performed, and ICT consumers were not re-executed natively. Their source contract continuity was audited in source-v3; do not invent fresh live ICT coverage here.

## Exact restoration and cleanup

Root original and restored bytes match for all ten A/B tables. Driver preseed `160` and final `261` objects also match each root original. These are exact full table objects/bytes, not merely equal counts. Organization A/B counts are personnel 3/1, completions 1/0, types 3/1, views 1/1, organizations 1/1. The sole original A completion (Able Required, 2026-09-27 expiry2027-09-27, ID `d980e412-2be6-4df6-a10d-6d389c670e9a`) remains unchanged. Seed cleanup records `cleaned:true` and `artifactHttpSessionsCleared:true`; original rows and fields are restored with no residual seeds.

Configure preferences root original/restored and driver start/end are exact 211 bytes, SHA256 `9da2bfbee78956ab1455b870084de32046277b43406076ffa2510d978249dc0d`. TrainingEmpty driver before/final preferences/progress are equal and empty, qualified as its own baseline rather than root original capture. Both disposable pages finish Training matrix at 1905×2053, original two localStorage keys, system mode watcher, no sidebar cookie or `__map` globals. Page3's final route differs from its initial Reports route because it was moved to repair the save guard; no route-equivalence claim is made for that new disposable context.

Native final hook evaluations `271–273` for both pages show network unarmed/calls empty/held false, export unarmed/uncaptured/null fields, print unarmed/zero before/after counters. Root doctor start, after restoration, closeout, and driver start/final doctor JSON all have the exact same candidate/session/port binding and PASS. Root cleanup phase is cleaned/PASS. Actual owned-absence proof records exact supervisor/app/MCP/browser PIDs and expected start/cmdline fingerprints, each `exactOwnedProcessAbsent:true`, `profileProcessIds:[]`, `privateWorkerDirectoryAbsent:true`, and proof payloads still exist. This is captured historical proof; I did not independently query live processes.

| Process | PID | Expected start | Cmdline SHA256 |
| --- | ---: | ---: | --- |
| supervisor | 200654 | 154883523 | `210dea5922d87d5ff915ed6eb494748ccfeb1d11f6682572a950f821ea85501c` |
| app | 210036 | 154889363 | `3eaf2498413464929c2a175f1967b631357605e7cdf438c1d0cf508e85b32871` |
| MCP | 210090 | 154889430 | `bc5c4c5df883c788b5b4a4aacfbc325d98db9a7c7e413f0e8b49167634bc832e` |
| browser | 210122 | 154889466 | `827476123339f3bad0c2c488190249c040bbe5ec5cfc442e1a330201c782f5b6` |

All 945 actual files, plus decoded XLSX cells and PDF text, were scanned for JWT shape, concrete Bearer values, private-key blocks, concrete access/refresh/client/service-role assignments and `sb_secret_` forms: zero matches. This is a concrete credential-pattern scan, not a guarantee about arbitrary unknown strings or image-only content. No screenshot was viewed. Public fixture is synthetic and sanitized.

## Retained limits and release boundary

The unchanged goal SQL migration is 484 bytes, SHA256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`. It was not executed; separately authorized migration/release remains an obligation. Native v6 establishes only the actions and pin above. Unit/source tests do not certify native no-types Retry, physical print, unexecuted keyboard/modal states, ICT live behavior or future source changes. Driver visual PDF acceptance remains delegated judgment. The package contains honest repair/refusal/timeout evidence, not 399 successful user actions.

Current-main governance changed after this historical v6 source/runtime. This report is acceptance of owned behavior at integrated ee1/source77, not complete acceptance against an advanced main. Parent-boundary draft push and stop, deferred integration and current governance state belong to the handoff; this report does not authorize ready/merge/monitor/rebase.

## Reproducible offline audit artifacts

Exclusive scratch `.verification/review-1504-final-v6-e8b17/` preserves `inventory-audit.json`, `parsed-outputs.json`, `action-audit.json`, `download-audit.json`, `restoration-privacy-audit.json`, `source-pin-audit.json`, `network-pagination.json`, `identity-content-audit.json` and `supplementary-audit.json`. These contain the actual machine-readable hash/set arithmetic and parsed contents. No browser or app runner was used by this reviewer.

### Exact original/restored table hashes

| Table | Org | Bytes | Rows | Original = restored SHA256 |
| --- | --- | ---: | ---: | --- |
| `personnel` | orgA | 1466 | 3 | `15bcb8ae8590d60eca700fc08ea666eab3fa01f5dbe7630dfb3bfe755c7b7ee9` |
| `personnel` | orgB | 558 | 1 | `df7b05c22437801de2a01e6cb494f1fee1e8661cdcae2641d31e8f3ebbe4c930` |
| `personnel_trainings` | orgA | 592 | 1 | `64e738fabe810f0ca8c0d438a98cd46ef436670411859611dc01c77257d0d4af` |
| `personnel_trainings` | orgB | 91 | 0 | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| `training_types` | orgA | 2255 | 3 | `1c01e090aaa7c7303da82a3159feb1e20465034b93320d0a738f13cce06e6e68` |
| `training_types` | orgB | 792 | 1 | `5ff2faa26659db4f36a8a36619550864e8232b8c18200aa4110cfae537d91ea6` |
| `training_views` | orgA | 556 | 1 | `08dccdd11f0518d3990d9a9027d521e3f53c25d0a05442da623ff5711608890d` |
| `training_views` | orgB | 505 | 1 | `2065dcf03c544722e1e007e718e3dc11ac1ca0375e6ad21d0aa0b5cfdb36ee9e` |
| `organizations` | orgA | 656 | 1 | `2797bdc567b3eacbca0a33c581b61570199d8117fef7476c9a4d6ce24b91bf3c` |
| `organizations` | orgB | 656 | 1 | `547b79ee58380b3ed8e227e41e7abf703afb0c658d233984bb507294e24937f5` |

### Selected actual payload hashes

These selected hashes supplement, rather than replace, the complete verified inventory.

| Payload | Bytes | SHA256 |
| --- | ---: | --- |
| `root-source-checkpoint.json` | 35122 | `a17dbcd0dc5d4409ee4d9cdbdbf608238290ddf99954fa9ccd9b61a58dbdb4bf` |
| `root-1504-final-acceptance-v6-report.md` | 21328 | `c39febd2d4041be3301e2c24d1c334e5ce1d2876f0c5f6b38415f02737f898f1` |
| `root-1504-final-v6-dispatch-receipt.json` | 301 | `a4ba7ec4da286e51a6e769e00bf6550bf2cb222078e214c2c2ac77f6cc692891` |
| `root-restoration-audit.json` | 1410 | `0265b80baf6330c291f902474b0c1de000197f71c493d58b9b57d0af5b57221f` |
| `root-owned-absence.json` | 1115 | `0b3a423666e876d5e948919f1b4e77425c3e9d7b1530826706df70f77d21a8d5` |
| `root-owned-cleanup.json` | 160 | `43b8a7db6331e3cd3333eaaf11a20b57f351b4ec57e2a5dba872a5686bfa5b05` |
| `root-doctor-closeout.json` | 391 | `5dbf18a568379ec7f9b4869389c15c76611e8708e7cb03a017eec75fb9d463c8` |
| `driver/059-retry-click-held-after-state.out` | 1486 | `29e4a4b0ebae5904cd9a37286319ab4d5fc311f704d0787044ca4b006be72223` |
| `driver/076-retry-enter-held-after-state.out` | 1460 | `f87fef9f615965c58f93213b80cc920a7d627b4b4ccdfa832447b8db10119241` |
| `driver/100-after-release.out` | 1290 | `ab7478131b135814e24d7bf6793a1d59adc4abc294f5e4dfd6a4cb0e53bff144` |
| `driver/022-focus-link-after-net.out` | 5048 | `4d99c099fc04cd2cd5cacf336c17b6e294415501dea34cd879e16709b19d26f6` |
| `driver/121-empty-clear-after-state.out` | 1340 | `07c958d6f46f65ce873cd6ef8dbbc6fad535c78276612b903ebaa5b69bc71927` |
| `driver/205-print-state.out` | 49 | `788f46ceab7b3abbce6f7a313a2bfca72dd10b64abd34ba040036652bf4c43c9` |
| `driver/206-print-save.err` | 76 | `2f986abf8bff3d612b91fc965aeba27047ccfc908a5ae347c79668f55cebf9de` |
| `driver/209-page2-state.out` | 1844 | `c57d2da8ce3cb996dc36a55313621c909bcd679c5e559b6c7be5077678ca833f` |
| `driver/210-print-save-repair.out` | 540 | `85f6614e1acb984e3caaf024a6898038c05f578fef8d5d38b1b39749b629b14c` |
| `driver/183-click-export.out` | 192 | `39b97f4089931a43bd1c70f32db3cfeb143af6840c81ae60d8fe4e6cdd5f8135` |
| `driver/185-net-state.out` | 342 | `0fab59a0abc5f6046035c258348db2d1dad5ec03716ad6422f502a92c3e57da1` |
| `driver/186-export-save.out` | 415 | `3f0617733bb0d543260706aef6560ca1f2274ef2235d8c276e6a9e19721980a3` |
