SET statement_timeout='10s'; SET lock_timeout='3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_start_a1abe29f_3d8748a1_save ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.t2t_d15_start_a1abe29f_3d8748a1_save();
DROP TRIGGER IF EXISTS t2t_d15_start_a1abe29f_3d8748a1_delete ON public.personnel_onboardings;
DROP FUNCTION IF EXISTS public.t2t_d15_start_a1abe29f_3d8748a1_delete();
COMMIT;
SELECT json_build_object('removed',true);
