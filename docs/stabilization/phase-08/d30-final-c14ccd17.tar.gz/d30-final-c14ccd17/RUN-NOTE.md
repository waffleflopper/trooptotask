# D30 #1378 final affected-journey verification (worker 2)

- Candidate revision: c14ccd1793930ba7d409cf048aee672bad7dae41 (detached)
- Candidate digest: 534617ec5a4fafb4b44a928a10d81a4cb0141483410fa2c16f67905557a0d492
- Origin: http://127.0.0.1:41641 (owned `verify:app` worker 2, session ff2dca0c-71d5-4e89-87bd-ed3e538444ef)
- Browser: Chromium 152.0.7977.82 Arch Linux (native DevTools controls via `verify:app tool`)
- Doctor: PASS at start (doctor-initial.json) and PASS at end (doctor-final.json), same digest/revision.
- Organization: Verification Organization A (80cdb3fa-d556-474e-9580-5822f01dc0c7) unless noted; fixture.json has the IDs.
- Seeds: `seed platform-admin` (seed-platform-admin.json), `seed audit` (seed-audit.json). Both removed with `clean-seeds` (clean-seeds.json); audit seed/B sentinel read back as count 0.

Status vocabulary: live-verified / failed / unreachable / observed-preexisting.

## Calendar

| Path | Role | Expected | Observed | Status |
|---|---|---|---|---|
| /calendar as `manager` | manager | The recipe says manager has no Calendar grant, so access is denied | "Access Restricted" page (cal-manager-landing/denied). The tab title still reads "Sign In - Troop to Task" | live-verified (denial) |
| /calendar month view | calendarConfigure | Alpha/Bravo/Unassigned rows; Baker's current Training Oct 7-9; Retiring status on Oct 14 | Matches (cal-month-current) | live-verified |
| 3-Month toggle and back | calendarConfigure | October-December range view, then back to month | "October 2026 – December 2026" with Prev/Next 3 Months; back shows "October 2026" (cal-3month, cal-month-back) | live-verified |
| Month/year picker to Sep 2026 | calendarConfigure | Able Leave Sep 14-16 "Alpha seeded leave", Baker Training Sep 15, Unassigned leave, Unit Closure Sep 15, no Foreign | Matches; also VSD/VAD/VRD codes and Custom Holiday Sep 18 (cal-sep2026) | live-verified |
| Reload (streamed hydration) | calendarConfigure | Same data after full reload | After reload, the October snapshot diff (names/labels/descriptions) is IDENTICAL. September via the picker after reload is IDENTICAL to before; 0 Foreign (cal-reload-month, cal-sep2026-after-reload) | live-verified |
| /calendar/assignments | calendarConfigure | Planner slots; Sep 15 Staff=Able, Group=Alpha, Retiring=Baker | 182 slot controls; Sep 15 values match (cal-assignments) | live-verified |
| /calendar/bulk (Add) | calendarConfigure | Able/Baker/Unassigned offered, Leave offered, no Foreign | Matches. Selecting Able shows "1 of 3 selected" and is then unselected; nothing applied (cal-bulk, cal-bulk-able-selected) | live-verified |
| /calendar/settings | calendarConfigure | Status Types and Assignment Types catalogs; archived type excluded | 3 status types; 3 assignment types; Archived Duty absent (cal-settings, cal-settings-assignment-types) | live-verified |
| Workspace reuse | calendarConfigure | No `__data.json` on Planner → Calendar → Bulk → Calendar → Settings; Reports loads its own data with Calendar-layout digit 0 | `[]` across those stops; Reports `calendar/reports/__data.json 0001` | live-verified |
| /calendar/reports status-day 2026 | calendarConfigure | Able Leave 4; Unassigned Leave 1; Baker Training 1+3 overlap=4 plus Retiring 1 = 5; no Foreign | Baker 0/4/1=5, Able 4/0/0=4, Unassigned 1/0/0=1; 10 total (cal-reports-statusday) | live-verified |
| Scoped read | calendarScoped | Only Able/Alpha; range response 200 with only availabilityAlpha; no foreign IDs/labels | Grid shows ALPHA/Able only. Range 200 with alpha=true and every other ID false; no foreign label (cal-scoped-range-response.txt) | live-verified |

## Auth (signed out, public context d30w2-public)

| Path | Expected | Observed | Status |
|---|---|---|---|
| /auth/login render | Email, Password, Show password, Sign In; reset/renew/request links | Matches (auth-login) | live-verified |
| Password toggle | Input type flips | password→text, label "Hide password"; toggled back to password (auth-login-password-shown) | live-verified |
| Wrong password | Form stays usable with "Email or password is incorrect" | alert "Email or password is incorrect"; still on /auth/login (auth-login-wrong-password) | live-verified |
| /auth/forgot-password submit | Quiet generic response | "Check your email / If an account exists for … a password reset link is on the way." (auth-forgot-submitted) | live-verified |
| /auth/request-access | Renders | "Request access" form with 14-day note | live-verified |
| /auth/logout (no session) | No-session entry path | Redirected to public home `/` | live-verified (observed) |
| /auth/confirm (no token) | Unavailable link | "Link unavailable – invalid or has expired" | live-verified (observed) |
| /auth/mfa-verify (no session) | Observe | Renders the "Verify your code" form. The route has no server load (client page); unchanged behavior | live-verified (observed) |
| /auth/renew-invite | Renders | "Request a fresh setup link" form | live-verified (observed) |
| /auth/reset-password (no token) | Unavailable | "Reset link unavailable" | live-verified (observed) |
| /auth/setup-account (no token) | Unavailable | "Setup link unavailable" | live-verified (observed) |
| /auth/accept-invite (no token) | Unavailable | "Invite unavailable" | live-verified (observed) |
| Manager sign-in | Lands on /org/<A>/personnel | Matches (signin-manager-landed) | live-verified |
| Account menu → Sign Out | Lands on `/` with public Sign In | Matches (signout-after). On the first click after a navigation the menu did not open; a second click opened it (hydration timing, not product) | live-verified |

## Account / suspension

| Path | Role | Expected | Observed | Status |
|---|---|---|---|---|
| /account/security | manager | Password section | Email change plus Password section; checklist updates on input; Update disabled until all rules are met; not submitted (account-security, account-security-checklist) | live-verified |
| /suspended, not suspended | manager | Redirect to /dashboard | `__data.json` `{"type":"redirect","location":"/dashboard"}`, then lands on Org A home | live-verified |
| /suspended, signed out | none | Redirect to /auth/login | Lands on /auth/login (suspended-signed-out) | live-verified |
| Suspended user held | orgInvitee, suspended via admin UI | Held on /suspended | Signs in to /suspended "ACCOUNT SUSPENDED"; /dashboard and the temporary org URL both return to /suspended (suspended-held*) | live-verified |
| Restore | platformReviewer | Unsuspend; user no longer held | "User unsuspended"; `suspensions: []`; /suspended now redirects to the dashboard (suspended-after-restore) | live-verified |

Note: the /suspended document title shows "Sign In - Troop to Task" after a client navigation and "Troop to Task - Unit Staff Scheduling" after a full navigation. Cosmetic; not compared against the baseline here.

## Platform admin (platformReviewer super-admin)

| Path | Expected | Observed | Status |
|---|---|---|---|
| AdminSearch | Seeded org found | "Platform verification 6a4403cd 0 personnel" option; selecting it opens the org detail (admin-search-results) | live-verified |
| Org detail Suspend modal open/cancel | Dialog, no write | Dialog with Reason/Cancel/Suspend; Cancel closes it; `suspended_at` null (platform-state-after-modal-cancel.json) | live-verified |
| Org detail Transfer Ownership modal open/cancel | Dialog with candidate list; submit disabled until name typed | Matches; Cancel closes it; owner unchanged | live-verified |
| Organizations list | A, B, temp org | Present | live-verified |
| Users list | Directory | 20 Inspect links | live-verified |
| User detail Suspend modal open/cancel | Dialog, no write | Matches | live-verified |
| Access requests | Pending seed requests | Both pending names present | live-verified |
| Announcements | Renders | "No announcements yet." | live-verified |
| Audit | Entries with filters; View disclosure | Action/Severity filters; View shows masked `p***@example.test` (admin-audit-view-expanded) | live-verified |
| Feedback | Renders | "Beta Feedback", 0 items | live-verified |
| Non-admin /admin denial | orgMember | 403 page. Page data for /admin, /admin/users, /admin/organizations and /admin/access-requests has error node 403 "Platform admin access is required" and only the member's own email (admin-denied-orgMember-pagedata.txt) | live-verified |

## Organization settings (orgOwner)

| Path | Expected | Observed | Status |
|---|---|---|---|
| /settings/logs owner | Summaries with resolved labels | "latest 100 of 107"; actor email, System and "Synthetic stored actor" render. Page data resolves personnel "SPC Able Synthetic", training_type "Verification Required Training" and status_type "Verification Leave". Foreign IDs/labels absent; B sentinel absent; `[redacted]`/masked email kept (settings-logs-pagedata-labels.txt). Search filters to the stored-actor row | live-verified |
| /settings/logs orgAdmin | Denied | 403 "Only the organization owner can perform this action"; no seed rows in page data | live-verified |
| /settings/members render | Invite form, members, pending list | Matches | live-verified |
| Invite synthetic address | Pending row; delivery failure state expected in worker | "Invitation created, but email delivery failed"; 1 pending (Editor). Row 3b987860… pending, member/editor/organization; persists after reload | live-verified |
| Resend once | Same ID stays pending | "Invitation email delivery failed. The pending invitation is still intact"; same ID, pending, count 1 | live-verified |
| Revoke (cleanup) | Closed, 0 pending | "Invitation revoked."; 0 pending; row status revoked (history retained) | live-verified |
| /settings/ranks | Rank catalog | 4 active (SGT, SPC, PFC, VFY-ACTIVE-A), 1 retired; Retired filter shows VFY-RETIRED-A only | live-verified |

## Dashboard starter pack (API per dashboard.md; there is no rendered Apply control)

| Path | Role | Expected | Observed | Status |
|---|---|---|---|---|
| List (GET api/getting-started) | orgOwner | first-week-operations listed, canApply | Listed, canApply true, isFullyApplied false | live-verified (HTTP) |
| List/apply denial | trainingView | 403, no artifacts | canApply false with two deniedActions; apply POST 403 | live-verified (HTTP) |
| Apply | orgOwner | Creates "Complete unit orientation" Training step linked to "Unit Orientation" | 200, 7 created. The step's training_type_id equals the Unit Orientation ID | live-verified (HTTP) |
| Reapply | orgOwner | Skips without duplicates | 7 skipped; row counts still 1 | live-verified (HTTP) |
| Cleanup | orgOwner | Remove the artifacts through the ordinary delete endpoints | 3 DELETE 200; type, template and step counts 0 | done |
| Dashboard home | orgOwner | Renders; no Getting Started UI (recipe) | Renders; no Getting Started/starter text | live-verified |

## Critical Tasks

| Path | Role | Expected | Observed | Status |
|---|---|---|---|---|
| /critical-tasks | manager | Manager has no Critical Tasks lane (no sidebar link) | The main area is blank. The streamed chunk carries the 403 "requires Critical Tasks can view". Console shows "Uncaught Error: Failed to hydrate Critical Tasks workspace" (ict-manager*, ict-manager-console.json). Layout, hydrator and moved server helpers are byte-identical to merge-base 17229542 (pure path moves), so this is not a D30 regression | observed-preexisting (no friendly denial) |
| /critical-tasks matrix | ictConfigurator | A active tasks, Alpha/Bravo people, no foreign/archived | VERIFY-ICT-ALPHA/ALL; Able 50%, Baker 0% | live-verified |
| Task Library (visible link) | ictConfigurator | Library renders; one library `__data.json` with layout digit 0 | Matches (`library/__data.json 0001`) | live-verified |

## Not run / limits
- The manager role cannot exercise Calendar or Critical Tasks lanes because it has no grant. Calendar used calendarConfigure and calendarScoped; Critical Tasks used ictConfigurator.
- No network/export controls were armed. `feedback` was armed and restored once (it captured no toast). The temporary user suspension was restored before clean-seeds.
- The invitation row created through the UI remains as revoked history. Owned cleanup disposes it with the worker.
