#!/bin/bash
# act.sh NAME ACTION(click UID|key KEY)  ; obs before/after with fresh snapshot
n=$1; a=$2; v=$3
E=.verification/evidence/verify-trooptotask/1504-final-v5/driver
/tmp/obs.sh "$n-before" | grep -v '^   reqid=1[34][0-9] ' 
if [ "$a" = click ]; then /tmp/t.sh "$n-action" click "{\"pageId\":2,\"uid\":\"$v\"}" | head -1; else /tmp/t.sh "$n-action" press_key "{\"pageId\":2,\"key\":\"$v\"}" | head -1; fi
sleep 1.5
echo "== AFTER"; /tmp/obs.sh "$n-after"
/tmp/t.sh "$n-after-snap" take_snapshot "{\"pageId\":2,\"filePath\":\"$E/$n-after-snap.txt\"}" >/dev/null
grep -E 'radio|focused|ROWS [0-9]' $E/$n-after-snap.txt | cut -c1-120
