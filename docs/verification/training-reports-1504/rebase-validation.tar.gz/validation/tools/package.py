import hashlib
import json
import pathlib
import re
import shutil
import tarfile

root = pathlib.Path('.verification/evidence/verify-trooptotask/rebase-1511')
destination = pathlib.Path('docs/verification/training-reports-1504')
scratch = root / 'packaged'
patterns = [
    re.compile(r'(\b(?:gh[pousr]_|ghh_|github_pat_|sk-(?:proj-)?))[A-Za-z0-9_-]{15,}'),
    re.compile(r'([?&](?:token|key|secret|code)=)[A-Za-z0-9%_-]{12,}'),
    re.compile(r'()(eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,})'),
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

archives = []
for scope in ['baseline', 'final', 'worker2', 'd28-parent', 'd28-worker2', 'validation']:
    staging = scratch / scope
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True, exist_ok=True)
    inventory = []
    for source in sorted((root / scope).rglob('*')):
        if not source.is_file():
            continue
        relative = source.relative_to(root)
        original = source.read_bytes()
        payload = original
        redactions = 0
        if source.suffix in ['.json', '.txt', '.md', '.log', '.tsv', '.py']:
            value = original.decode()
            for pattern in patterns:
                value, count = pattern.subn(lambda m: m.group(1) + '[REDACTED_SYNTHETIC_TOKEN]', value)
                redactions += count
            payload = value.encode()
        target = staging / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        entry = {'filename': str(relative), 'sha256': digest(payload)}
        if redactions:
            entry.update(originalSha256=digest(original), redactions=redactions)
        inventory.append(entry)
    (staging / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
    archive = destination / ('rebase-' + scope + '.tar.gz')
    with tarfile.open(archive, 'w:gz') as output:
        for payload in sorted(staging.rglob('*')):
            if payload.is_file():
                output.add(payload, arcname=str(payload.relative_to(staging)))
    expanded = scratch / ('expanded-' + scope)
    if expanded.exists():
        shutil.rmtree(expanded)
    expanded.mkdir()
    with tarfile.open(archive) as input:
        input.extractall(expanded, filter='data')
    entries = json.loads((expanded / 'inventory.json').read_text())
    expected = {e['filename'] for e in entries} | {'inventory.json'}
    actual = {str(p.relative_to(expanded)) for p in expanded.rglob('*') if p.is_file()}
    assert actual == expected, (scope, actual ^ expected)
    for entry in entries:
        assert digest((expanded / entry['filename']).read_bytes()) == entry['sha256'], entry['filename']
    archives.append({'archive': str(archive), 'payloads': len(entries), 'sha256': digest(archive.read_bytes()), 'redactions': sum(e.get('redactions', 0) for e in entries), 'verified': True})
(root / 'archive-integrity.json').write_text(json.dumps(archives, indent=2) + '\n')
print(json.dumps(archives, indent=2))
