import json,re,subprocess,hashlib
from scope_helpers import *
baseline=base.parent.parent.parent.parent.parent/'unused'
baseline=__import__('pathlib').Path('/home/waffleflops/.cache/t2t-1360-personnel-detail/.verification/evidence/verify-trooptotask/personnel-detail-baseline')
def read(p):return json.loads(p.read_text())
def response(p):
 s='\n'.join(i.get('text','') for i in read(p)['content']);return json.loads(re.search(r'```json\s*([\s\S]*?)```',s)[1])
page=read(base/'scope-foreign-page.json')['pageId'];before={o:{t:read(base/('scope-foreign-org-denied-before-'+o+'-'+t+'.json'))['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']};after=projections('scope-foreign-attempt-after');assert before==after
previous=read(base/'scope-foreign-org-denied-audit-before.json')['rows'];now=call('scope-foreign-attempt-audit-after','control','rows','audit_logs','orgA')['rows'];select=lambda rows:sorted((r['id'],r['action'],r.get('resource_id')) for r in rows if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared']);assert select(previous)==select(now)
comparison={'status':'UNSUPPORTED_SCRATCH_EXPECTATION_SAME_BASELINE404','originalActor':read(baseline/'scope-foreign-login.json'),'finalActor':read(base/'scope-foreign-login.json'),'expectedScratch':[403,403],'baselineACK':response(baseline/'scope-foreign-org-denied-ack.json'),'finalACK':response(base/'scope-foreign-org-denied-a-target-ack.json'),'baselineSDS':response(baseline/'scope-foreign-org-denied-sds.json'),'finalSDS':response(base/'scope-foreign-org-denied-a-target-sds.json'),'fullABRowsLiteralExact':True,'successAuditsExact':True,'boundary':'Bothnormal-formforeignactors belongOrgB and requestOrgA; existing requestOrglookupconceals inaccessibleOrg before operation. Same fixtures/requeststore bytes as prior literalcomparison; all source/tests unchanged. Failedphase/raw requests retained.'}
assert comparison['baselineACK']['status']==comparison['finalACK']['status']==404 and comparison['baselineSDS']['status']==comparison['finalSDS']['status']==404
(base/'foreign-status-literal-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
denied_batch('scope-foreign-confirmed',page,[('a-target',PERSON,ORG,404,404)]);tool('scope-foreign-close','close_page',{'pageId':page})
for role,field,expected in [('manager','emergency_contact_phone','907-555-0188'),('personnelScoped','emergency_contact_name','Scoped Synthetic Contact')]:
 b=read(base/('scope-'+role+'-sds-before.json'))['rows'][0];a=read(base/('scope-'+role+'-sds-after.json'))['rows'][0];siblings_equal(b,a,{field,'updated_at'});assert a[field]==expected and a['award_tracking_acknowledged_at']==b['award_tracking_acknowledged_at'];checks.append({'scenario':role+' native admittedsave/reload','result':'PASS','before':b,'after':a})
for prefix,expected in [('scope-alpha-denials',404),('scope-view-only-denied',403),('scope-empty-denied',404),('scope-viewer-denied',403)]:
 b={o:{t:read(base/(prefix+'-before-'+o+'-'+t+'.json'))['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']};a={o:{t:read(base/(prefix+'-after-'+o+'-'+t+'.json'))['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']};assert b==a
 assert select(read(base/(prefix+'-audit-before.json'))['rows'])==select(read(base/(prefix+'-audit-after.json'))['rows'])
 requestRecords=[p for p in base.glob(prefix+'-*-ack.json')]+[p for p in base.glob(prefix+'-*-sds.json')]
 assert requestRecords and all(response(p)['status']==expected for p in requestRecords)
 checks.append({'scenario':prefix,'result':'PASS','expectedActualStatus':expected,'requestFiles':[p.name for p in requestRecords],'allFullABRowsLiteralExact':True,'successAuditsExact':True})
b=read(base/'scope-operate-before.json')['rows'][0];a=read(base/'scope-operate-after.json')['rows'][0];siblings_equal(b,a,{'emergency_contact_phone','updated_at'});assert a['emergency_contact_phone']=='907-555-0177'
checks.append({'scenario':'operate-onlyAPI200 with nativeDashboard403; siblingspreserved','result':'PASS','nativeLimit':'No bypassed Moreinfo UI; actual admittedendpoint proof separate from native denieddashboard.'})
(base/'scope-final-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'originalFailure':'scoped-actors.log/stderr retains unsupportedforeign403 expectation; literal identicalbaseline404+fullnoeffect checks resolve expectation, no application change.'},indent=2)+'\n')
