import sys,pathlib,subprocess,json,re,hashlib,datetime
root=pathlib.Path(__file__).resolve().parent
label,op,page,*args=sys.argv[1:]
page=int(page)
def call(label,kind,*args):
 p=subprocess.run(["python3",str(root/"run.py"),label,kind,*args],capture_output=True,text=True)
 if p.returncode:print(p.stdout,p.stderr);raise SystemExit(p.returncode)
 return (root/(label+".out")).read_text()
def tool(label,name,data):return call(label,"v","tool",name,json.dumps(data))
def show(raw):
 d=json.loads(raw);print("\n".join(x.get("text","") for x in d.get("content",[])))
def snap(label):return tool(label,"take_snapshot",{"pageId":page})
def uid(text,target,index=0):
 lines=[line for line in text.splitlines() if target in line and re.search(r"uid=[0-9_]+",line)]
 if len(lines)!=1 and len(args)<3:raise ValueError("Ambiguous/absent control "+target+": "+str(lines))
 return re.search(r"uid=([0-9_]+)",lines[index]).group(1)
if op=="snap":show(snap(label))
elif op in ["click","fill"]:
 s="\n".join(x.get("text","") for x in json.loads(snap(label+"-before"))["content"]);target=args[0];index=int(args[2]) if len(args)>2 else 0;u=uid(s,target,index)
 data={"pageId":page,"uid":u,"includeSnapshot":True}
 if op=="fill":data["value"]=args[1]
 show(tool(label,op,data))
elif op=="key":show(tool(label,"press_key",{"pageId":page,"key":args[0],"includeSnapshot":True}))
elif op=="reload":show(tool(label,"navigate_page",{"pageId":page,"type":"reload"}));show(snap(label+"-after"))
elif op=="back":show(tool(label,"navigate_page",{"pageId":page,"type":"back"}));show(snap(label+"-after"))
elif op=="shot":show(tool(label,"take_screenshot",{"pageId":page,"filePath":str(root/(label+".png"))}))
elif op=="eval":show(tool(label,"evaluate_script",{"pageId":page,"function":args[0],"waitForStableDom":False}))
elif op=="req":
 method,path=args[:2];body=json.loads(args[2]) if len(args)>2 else None
 options={"method":method}
 if body is not None:options.update({"headers":{"Content-Type":"application/json"},"body":json.dumps(body)})
 code="async () => { const r=await fetch("+json.dumps(path)+","+json.dumps(options)+"); return {method:"+json.dumps(method)+",path:"+json.dumps(path)+",submitted:"+json.dumps(body)+",status:r.status,body:await r.text()}; }"
 show(tool(label,"evaluate_script",{"pageId":page,"function":code,"waitForStableDom":False}))
else:raise ValueError(op)
