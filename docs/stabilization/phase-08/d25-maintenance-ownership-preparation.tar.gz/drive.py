import copy,json,pathlib,subprocess,time,datetime
root=pathlib.Path(__file__).resolve().parent
helper=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1']
events=[]
def call(label,args,cli=False,probe=False):
 start=time.time()
 command=(['node',str(root/'provider-readback.mjs')] if probe else ['npm','run','--silent','verify:app','--'] if cli else helper)+args
 r=subprocess.run(command,capture_output=True,text=True)
 (root/(label+'.json')).write_text(r.stdout)
 (root/(label+'.stderr')).write_text(r.stderr)
 events.append({'label':label,'command':command,'exit':r.returncode,'seconds':round(time.time()-start,3)})
 (root/'actions.json').write_text(json.dumps(events,indent=2)+'\n')
 print(label,r.returncode,flush=True)
 if r.returncode: raise RuntimeError('Control failed '+label)
 return json.loads(r.stdout)
def flattened(data):
 result={}
 for batch in data['batches']:
  target=result.setdefault(batch['table'],{})
  for row in batch['rows']: target[row['id']]=row
 return result
def equal(actual,expected,label):
 if actual!=expected:
  diffs=[]
  for table in sorted(set(actual)|set(expected)):
   a=actual.get(table,{});e=expected.get(table,{})
   for key in sorted(set(a)|set(e)):
    if a.get(key)!=e.get(key):diffs.append({'table':table,'id':key,'expected':e.get(key),'actual':a.get(key)})
  (root/(label+'-differences.json')).write_text(json.dumps(diffs,indent=2)+'\n')
  raise AssertionError(label+' exact state differs')
 print(label,'exact state PASS',flush=True)
def timestamp(value): return datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
def cron(label,job,mode='run'):
 start=time.time();result=call(label,['retention','cron',mode,job]);end=time.time()
 assert result['status']==(200 if mode=='run' else 401),(label,result)
 assert result['location'] is None
 return (json.loads(result['body']) if mode=='run' else None),start,end
fixture=call('fixture',['fixture'])
call('doctor-before',['doctor'],True)
call('settings',['retention','settings'])
original={}
tables=['ict_tasks','assignment_types','personnel_ict_completions','daily_assignments','audit_logs','notifications','personnel_onboardings','onboarding_step_progress','personnel','personnel_documents','counseling_records','leader_notes','personnel_follow_ups','rating_scheme_entries']
for table in tables:
 for org in ['orgA','orgB']: original[(table,org)]=call('original-'+table+'-'+org,['rows',table,org])
recipients={}
for org in ['orgA','orgB']:
 membership=call('memberships-'+org,['rows','organization_memberships',org])
 recipients[org]=sorted(row['user_id'] for row in membership['rows'] if row['role'] in ['owner','admin'])
assert len(recipients['orgA'])>0
assert original[('notifications','orgA')]['rows']==[]
assert original[('notifications','orgB')]['rows']==[]
original_users=call('original-users',['users'],probe=True)
summary_observations=[]
for size in ['small','large']:
 maintenance=call(size+'-maintenance-seed',['seed','maintenance-retention' if size=='small' else 'maintenance-retention-1001'])
 onboarding=call(size+'-onboarding-seed',['seed','onboarding-retention' if size=='small' else 'onboarding-retention-1001'])
 artifact=call(size+'-artifact-seed',['seed','artifact-retention']) if size=='small' else None
 personnel=call(size+'-personnel-seed',['seed','personnel-retention']) if size=='small' else None
 manifest=call(size+'-manifest',['manifest'],probe=True)
 manifest_file=size+'-manifest.json'
 before=flattened(call(size+'-before',['readback',manifest_file],probe=True))
 if size=='large':
  probe=call('legacy-setup-probe',['legacy-setup-probe',manifest_file],probe=True)
  assert probe=={'mode':'legacy-setup-probe','represented':1000,'actualMutatedCount':1001,'expectedExpired':1001,'exactRestoration':True,'cutoff':probe['cutoff']}
  equal(flattened(call('large-probe-restored',['readback',manifest_file],probe=True)),before,'large-probe-restored')
 for job in ['records','onboarding','audit','setup-links']:
  for mode in ['missing','wrong']:cron(size+'-'+job+'-'+mode,job,mode)
 equal(flattened(call(size+'-denied',['readback',manifest_file],probe=True)),before,size+'-denied')
 expected=copy.deepcopy(before)
 expired={table:{entry['row']['id'] for batch in maintenance['batches'] if batch['table']==table for entry in batch['records'] if entry['classification']=='expired'} for table in ['ict_tasks','assignment_types','audit_logs','account_setup_links']}
 removed_people=set(personnel['expiredIds']) if personnel else set()
 removed_artifacts={batch['table']:{entry['row']['id'] for entry in batch['records'] if entry['classification']=='expired'} for batch in artifact['rows']} if artifact else {}
 for table in ['personnel_follow_ups','counseling_records','personnel_documents','leader_notes','personnel','ict_tasks','assignment_types']:
  ids=expired.get(table,set())|removed_artifacts.get(table,set())|(removed_people if table=='personnel' else set())
  for identifier,row in list(expected.get(table,{}).items()):
   if identifier in ids or row.get('personnel_id') in removed_people:del expected[table][identifier]
 records,start,end=cron(size+'-records-run','records')
 assert records['deletedCount']==(10 if size=='small' else 2002)
 assert records['orgsAffected']==1
 assert [item['deletedCount'] for item in records['families']]==([1,2,2,1,2,1,1] if size=='small' else [0,0,0,0,0,1001,1001])
 observed=flattened(call(size+'-after-records',['readback',manifest_file],probe=True))
 if personnel:
  rating=expected['rating_scheme_entries'][personnel['ratingId']]
  for column in ['rater_person_id','senior_rater_person_id','intermediate_rater_person_id','reviewer_person_id']:rating[column]=None
  if 'updated_at' in rating and rating['updated_at']!=observed['rating_scheme_entries'][personnel['ratingId']]['updated_at']:
   updated=observed['rating_scheme_entries'][personnel['ratingId']]['updated_at']
   assert start-1<=timestamp(updated)<=end+1
   rating['updated_at']=updated
 equal(observed,expected,size+'-records')
 if size=='small':
  files=call('small-after-records-files',['retention','files'])['files']
  for file in files:
   removed=file.get('personnelId') in removed_people or file.get('classification')=='expired'
   assert file['present']==(not removed),(file['path'],removed)
   if file['present']:assert file['observedSize']==file['size'] and file['observedSha256']==file['sha256']
 repeated,_,_=cron(size+'-records-repeat','records')
 assert repeated['deletedCount']==0 and repeated['orgsAffected']==0
 equal(flattened(call(size+'-after-records-repeat',['readback',manifest_file],probe=True)),expected,size+'-records-repeat')
 removed_packets={packet['id'] for packet in onboarding['packets'] if packet['key'].startswith('expired')}
 for table in ['personnel_onboardings','onboarding_step_progress']:
  for identifier,row in list(expected.get(table,{}).items()):
   if identifier in removed_packets or row.get('onboarding_id') in removed_packets:del expected[table][identifier]
 result,_,_=cron(size+'-onboarding-run','onboarding')
 assert result['deletedCount']==(2 if size=='small' else 1002) and result['orgsAffected']==1
 equal(flattened(call(size+'-after-onboarding',['readback',manifest_file],probe=True)),expected,size+'-onboarding')
 repeated,_,_=cron(size+'-onboarding-repeat','onboarding')
 assert repeated['deletedCount']==0 and repeated['orgsAffected']==0
 for identifier in expired['audit_logs']:del expected['audit_logs'][identifier]
 result,_,_=cron(size+'-audit-run','audit');assert result=={'auditLogsDeleted':2}
 equal(flattened(call(size+'-after-audit',['readback',manifest_file],probe=True)),expected,size+'-audit')
 repeated,_,_=cron(size+'-audit-repeat','audit');assert repeated=={'auditLogsDeleted':0}
 result,start,end=cron(size+'-setup-run','setup-links')
 assert result=={'revokedExpiredUnusedCount':1 if size=='small' else 1001,'staleRevokedCount':2 if size=='small' else 1002,'completedSetupHistoryCount':1,'failedSetupHistoryCount':1,'activeLinkCount':1,'deletedAccessRequestCount':0,'deletedUserAccountCount':0}
 observed=flattened(call(size+'-after-setup',['readback',manifest_file],probe=True))
 for identifier in expired['account_setup_links']:
  value=observed['account_setup_links'][identifier]['revoked_at'];assert start-1<=timestamp(value)<=end+1
  expected['account_setup_links'][identifier]['revoked_at']=value
  expected['account_setup_links'][identifier]['revocation_reason']='cleanup'
 equal(observed,expected,size+'-setup')
 assert call(size+'-users-after-setup',['users'],probe=True)==original_users
 repeated,_,_=cron(size+'-setup-repeat','setup-links');assert repeated==dict(result,revokedExpiredUnusedCount=0)
 equal(flattened(call(size+'-after-all-repeat',['readback',manifest_file],probe=True)),expected,size+'-all-repeat')
 for org in ['orgA','orgB']:
  notifications=call(size+'-notifications-'+org,['rows','notifications',org])['rows']
  if org=='orgB':assert notifications==[]
  else:
   assert len(notifications)==len(recipients[org])*(2 if size=='small' else 4)
   for kind in ['archive_auto_deleted','onboarding_auto_deleted']:
    rows=[row for row in notifications if row['type']==kind]
    assert sorted(row['user_id'] for row in rows)==sorted(recipients[org]*(1 if size=='small' else 2))
    assert all(row['link'] is None for row in rows)
   new_rows=[row for row in notifications if row['id'] not in {value['id'] for value in summary_observations}]
   assert all(str(10 if size=='small' else 2002) in row['message'] for row in new_rows if row['type']=='archive_auto_deleted')
   assert all(str(2 if size=='small' else 1002) in row['message'] for row in new_rows if row['type']=='onboarding_auto_deleted')
   summary_observations=notifications
 call(size+'-clean',['clean-seeds'])
 clean=call(size+'-after-clean',['readback',manifest_file],probe=True)
 assert all(batch['count']==0 for batch in clean['batches'])
 for table in tables:
  if table=='notifications':continue
  for org in ['orgA','orgB']:
   restored=call(size+'-restored-'+table+'-'+org,['rows',table,org])
   assert restored==original[(table,org)],(size,table,org)
call('doctor-final',['doctor'],True)
import importlib.util
session_result=subprocess.run(['node','--input-type=module','-e',"import {sessionPath} from './scripts/verification/core.mjs';console.log(sessionPath('1'));"],capture_output=True,text=True,check=True)
session=pathlib.Path(session_result.stdout.strip())
(root/'app.log').write_bytes((session/'app.log').read_bytes())
call('cleanup',['cleanup'],True)
(root/'verification-result.json').write_text(json.dumps({'status':'PASS','smallFamilyCounts':[1,2,2,1,2,1,1],'largeFamilyCounts':[0,0,0,0,0,1001,1001],'largeOnboardingDeleted':1002,'largeSetupRevoked':1001,'deniedCalls':16,'exactRowComparisons':True,'completeCurrentAdministratorRecipients':True,'foreignFalseSummaries':0,'allRecordedSeedRowsAbsentAfterClean':True,'finalDoctor':'PASS','ownedDisposal':'PASS','claim':'headless job/API and privileged provider observations; no native UI journey claimed'},indent=2)+'\n')
