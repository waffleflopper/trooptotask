import json
from pathlib import Path
r=Path(__file__).parent
load=lambda name:json.loads((r/(name+'.json')).read_text())
comparisons=[]
for org in ['orgA','orgB']:
 for table in ['personnel_follow_ups','leader_notes','counseling_records','personnel_documents']:
  before=(r/f'before-{org}-{table}.json').read_bytes()
  for stage in ['guards','after']:
   assert before==(r/f'{stage}-{org}-{table}.json').read_bytes(),(stage,org,table)
   comparisons.append({'stage':stage,'organization':org,'table':table,'completeBytesUnchanged':True})
assert load('cache-before-guards')['privateActorCacheCount']==0
assert load('cache-after-guards')['privateActorCacheCount']==0
matrix=load('api-matrix');assert len(matrix)==11
assert len([x for x in matrix if x['status']==200 and x['exit']==0])==9
assert len([x for x in matrix if x['status'] is None and x['exit']==2])==2
for label in ['reject-outside-json','reject-outside-upload']:
 assert (r/(label+'.json')).read_bytes()==b''  # Actual stdout-only capture; stderr is separately transcribed.
follow=load('alias-follow-up-create');doc=load('alias-document-create');person=load('lifecycle-seed')['ids']['person'];prefix='d13-artifact-auth-realpath/'
assert follow['request']['source']==prefix+'follow-up-create.json'
assert doc['request']['source']==prefix+'document-create.json'
assert follow['request']['body']==load('follow-up-create')
assert follow['body']['personnelId']==person and doc['body']['personnelId']==person
for family,created,field in [('follow-ups',follow,'title'),('documents',doc,'title')]:
 saved=next(x for x in load('alias-manager-get-'+family)['body'] if x['id']==created['body']['id'])
 assert saved[field]==created['request']['body'][field]
rows=load('created-follow-up-row')['rows'];assert len(rows)==1 and rows[0]['notes']=='Exact evidence survives the path alias'
rows=load('created-document-row')['rows'];assert len(rows)==1 and rows[0]['title']=='D13 canonical alias document'
upload=doc['request']['upload'];assert upload['source']==prefix+'synthetic-artifact.pdf'
assert upload['bytes']==3187 and upload['sha256']=='c47b428801acb793600762a0190a8a50f27986fe81ff39e48b39e80d176441cb'
assert doc['request']['body']['file']['path']==upload['source']
files=load('created-doc-files')['files'];created=[f for f in files if f['present']];assert len(created)==1
assert created[0]['size']==3187 and created[0]['sha256']==upload['sha256']
assert any(f['path']==created[0]['path'] and not f['present'] for f in load('after-orgA-files')['files'])
assert load('alias-manager-download')['body']['url'].endswith('?token=[REDACTED]')
assert load('cache-before-cleanup')['privateActorCacheCount']==1 and load('cache-after-cleanup')['privateActorCacheAbsent']
assert load('doctor-final')['status']=='PASS' and load('disposal')['status']=='PASS'
assert load('outside-input-cleanup')['exactCreatedAliasAndTwoOutsideFilesRemoved']
(r/'comparison-results.json').write_text(json.dumps({'tables':comparisons,'canonicalBodyAndUploadSources':True,'exactPayloadAndStoredFields':True,'guardBlocksBeforeActorCacheCreation':True,'actualFileSize':3187,'actualFileSHA256':upload['sha256'],'explicitCreatedPathAbsentAfterOrdinaryDelete':True,'artifactRequests':9,'blockedHelperCommands':2,'privateCacheRemoved':True},indent=2)+'\n')
print('PASS 16 complete table comparisons, canonical body/upload paths, exact saved fields/PDF bytes, two pre-auth guard blocks and ordinary deletion/cache/disposal closure')
