SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 849 AND backend_start = '2026-10-02 03:25:52.398976+00'::timestamptz AND application_name = 't2t-d15-overlap-95460610ad924b63b57dc7a2c88dd4ba' AND usename = 'supabase_admin' AND datname = 'postgres';
