# Issue 1503 Mac transport implementation

This agent implemented only ignored scratch files in `.verification/mac-preview-1503/` and this report. No repository app, installed helper, feature recipe, provider or browser files were changed, and this agent launched no worker, provider, preview, browser or Serve mapping. Root's separately owned startup and cleanup observations are qualified below.

## Ready for root inspection

- `transport.mjs`: original-worker/process admission, authenticated doctor/candidate/copied-source/output/adapter checks, private environment allowlist, exact native-TLS Host/Origin guard, cookie header namespace and own-port-only Serve inspection.
- `sidecar.mjs`: Vite production preview over the existing owned copy/output, native HTTPS using the helper's certificate paths, runtime external `APP_PUBLIC_ORIGIN`, guarded one-use orgOwner field-fill carrier and 1.5-second ownership heartbeat. It does not rebuild, proxy the provider, preload server-source control or create an auth session.
- `command.mjs`: fixed worker-1 `start`, `check`, `stage`, `stop` and `help`. `start` stays foreground and uses the installed helper's `info`, `cert`, `run tls`; the helper owns forwarding. Receipts bind starter, helper, sidecar, original app/supervisor and the exact helper-child Serve process. Cleanup signals only matching recorded identities and verifies the precise listener/Serve port are absent.
- `README.md`: startup, checkpoint, private credential-fill and cleanup instructions; receipt fields and limitations. Never package the private runtime directory or relay capability expression.

The installed Vite runs `configurePreviewServer` hooks before its returned preview post-hooks. Installed SvelteKit installs SSR in a returned post-hook and calls `res.setHeader` for Set-Cookie. The adapter's `enforce:'pre'` middleware therefore surrounds that ordinary header boundary. This is source inspection of the installed consumer, not a live TLS claim.

Cookie names gain a unique session namespace solely in normal HTTP response headers and are translated back on incoming owned requests. Values/security attributes/chunks/deletion are preserved. Foreign cookie names are omitted without sending any clearing instruction. The unchanged app still signs in and signs out normally; the assigned driver must use native Sign In. This is a recorded transport difference rather than fresh proof of original production cookie names on the shared Mac hostname.

`stage` reads no password into stdout or arguments. It writes a two-minute one-use private capability and safe field-fill expressions for orgOwner only. A same-origin login-page navigation carries synthetic fixture credentials briefly through `window.name`, returns to the normal form, and the field-fill expression clears that carrier before filling. No scripted submit, provider auth call, cookie/session injection, arbitrary role/file route or provider proxy exists. Capability-bearing tool arguments/URLs must be excluded from public captures with an explicit redaction record.

## Actual checks

Node 24.21.0 was used. All results are preserved under `.verification/mac-preview-1503/`:

| Check                                          | Actual result               | Receipt      |
| ---------------------------------------------- | --------------------------- | ------------ |
| `node --test transport.test.mjs`               | 13 passed, 0 failed, exit 0 | `tests.log`  |
| `node --check` on the three executable modules | All exit 0                  | `syntax.log` |
| Explicit scratch Prettier check                | Passed, exit 0              | `format.log` |
| Focused ESLint on modules and tests            | Passed, exit 0              | `eslint.log` |
| `command.mjs help`                             | Exit 0; no launch           | `help.log`   |
| `git diff --check`                             | Exit 0                      | This record  |

The tests exercise independently specified foreign-cookie exclusion, owned chunks/embedded equals, exact response values/options/deletion, middleware wrapping, host/port/Origin/TLS and lost-owner denial, original worker/candidate/process guards, transport shutdown on app loss, and own-port foreground Serve selection without other-port interference. Added checks cover the exact helper interpreter transition, inter-read races, rejection of replacements/unexpected script/executable/arguments, safe failed-capture cleanup and disclosure, and complete cleanup with preserved startup/cleanup codes and an uncertain lease. They use fake in-memory owners/HTTP exchanges only; no server or real worker is accessed by tests.

Per-file SHA-256 is recorded in `source-sha256.json`. The final combined runtime adapter digest is `7d4293a8e3aa20ac3088bf02cd1326762cb63e66630283b7f91e34b09aa817c7` (the ordered three executable modules); every admission/checkpoint binds this value to the live run. `validation-initial/` preserves the initial seven-test records and manifest for digest `c413aaabeef07027b27b6b7d3d5dc3116b7d43ddb72cffa610f3ba79424ae441`. `validation-interpreter-capture/` preserves the twelve-test records and manifest for digest `80d2ca94f5f3bb201d6aadea5bc0e624fb39c8adb347bae131e6782fea4b2385`. Root application validation and live acceptance remain separate from these scratch checks.

## First-start diagnosis and correction

Root's first owned startup exited with sanitized `PREVIEW_EXITED` before any browser/login activity. The saved helper identity caught the installed `#!/usr/bin/env python3` handoff before `env` exec'd Python at the same PID/start. The initial adapter then rejected the changed parent command at `sidecar.mjs:137` (`HELPER_CHANGED`); the early catch had hidden that code. The capture was at initial `command.mjs:207`. The private helper log was empty and no sidecar identity receipt existed. Read-only inspection ruled out both a helper parent wrapper and the proposed cwd-derived repository mismatch.

The correction captures only the final installed Python command at the original PID/start with exact executable, canonical script and arguments. Bounded before/after metadata samples handle the permitted interpreter transition between iterations or individual proc reads. Replacements and unexpected commands are still rejected. The initial spawned identity enables equally guarded reconciliation if final capture fails. Sidecar startup failures now save only a validated uppercase code in an owned private receipt/log.

Root confirmed exact stop and normal doctor PASS after the first failure. Root's next attempt using digest `80d2…` passed native HTTPS startup, certificate-verified external login response and all bound candidate/source/build/process checks. Root then stopped it successfully before these final cleanup edits; no browser/login actions occurred. Root receipts are `root-transport-start-retry.json` and `root-transport-lint-reconciliation-stop.json` in its `evidence1503-final-chart-v5` evidence directory. This successful connection qualifies the interpreter fix; it does not qualify the final changed executable bytes or browser journey.

Focused ESLint identified two throwing-finally paths. They are now sequential owned cleanup attempts that preserve safe startup and cleanup failure codes, attempt subsequent stops and retain the startup lease on uncertain cleanup. No rule was suppressed. The added fake test proves both-failure disclosure, continued cleanup and lease behavior.

Failed/live private run bytes were not changed by this agent. Root owns archival of each fully stopped run before recreating the same session directory. No automatic retry/archive mechanism, app rebuild, installed-helper edit, provider route or seed change was added. No executable or documentation edits remain pending after this report.

## Launch checkpoint and limits

After root finishes integration, freezes source/recipes/fixture lever and launches/doctors the fresh normal worker, run:

```bash
node .verification/mac-preview-1503/command.mjs start
```

Keep that foreground process handle. Root can call `check` and delegate the explicit external HTTPS origin to the visual owner. `stage` is optional when literal field typing would expose the synthetic password. Follow README for private expression handling and native submission. Restore goal/theme/hooks and sign out visibly; root performs final doctor/check and journal-bound restoration before `stop` and ordinary worker cleanup.

This agent exercised no Mac connectivity, native HTTPS service, real-cookie round trip, real-worker death cleanup or browser journey. Root's prior-digest native HTTPS success is qualified above. Final-digest startup/check and the browser journey remain live acceptance checks. A changed candidate/output, mismatched process, foreign Host/Origin or remaining cleanup resource blocks the adapter; it neither borrows services nor clears foreign resources. Checkpoint hashing is explicit rather than repeated on every request; root must keep candidate and driving inputs frozen.

For issue 1503, retained Supabase imports are server-only, so the original disposable loopback provider and static public provider URL stay unchanged; runtime `APP_PUBLIC_ORIGIN` supplies the external origin without rebuilding. Browser-direct signed Storage links and primary-app server-source controls are outside this sidecar's scope. Native browser helpers tied to the launcher Chromium cannot drive the T3 Mac tab. Nonbrowser fixture/rows/journal readbacks remain owned-worker controls.
