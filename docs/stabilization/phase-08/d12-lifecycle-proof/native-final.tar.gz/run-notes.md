# Native repaired lifecycle recovery final

Tested revision420e367dd0beeee859c00a0400bdd3940891258f; production/test bytes identical to worker repair4f0c557e7f5bbf2174bd5761008309cd69d54e73 cherry-picked as4649513e. Candidate e873432e7e0788ae9b31e5c5c28ed2d3e759cac005bede5fb4b5b50d000e0186. Owned production worker2 at http://127.0.0.1:41865, session9ae4ad66-dded-4317-bb8a-b655c937b1a9; Node24.21.0/npm11.19.0/Chromium152.0.7977.82 Arch Linux. Launch/initial/finaldoctorPASS with unchanged revision/digest; ownedcleanupPASS. Source/fixtures/controls/driving instructions frozen throughout; ignored captures only.

Scope/selection same bounded recipe7 as unchanged baseline: manager selects dedicated populated Alpha parent and duplicateBravo using named checkbox+Group context;9parent artifacts, independent August sibling histories/completedfollowup, Training/ICT, unrelated Able control; exact fresh seed IDs in seed.json. No old baseline IDs reused. Metadata document rows only, no stored-file claim.

Native bulk selected2 and ConfirmArchive/confirmationArchive: synthetic POST503 useful error2couldnotbearchived; all preserved rows unchanged and mode/selection clears. Restore hooks; fresh select2 then actualPOST200/success2archived. Reload exact two absent. Parents share event2026-10-01T00:55:26.375+00:00. Active note/counseling/document/openfollowup exact event/status; all independent/completed/Training/ICT/unrelated fields preserved.

Separate ordinary authenticated replay of same2IDs returns200 with archivedIds exactlyboth/noerrors/norequests; saved timestamp and all artifact fields unchanged. Scoped Alpha-only replay acknowledges parentAlpha and concealsBravo/noeffects. Operate archived replay retains existing per-ID error/noapproval/noartifacts; helper deletion_requests orgA empty. EmptyUI shows no roster/archive control; validbatchtwoIDs missing/noeffects. ForeignA request404/noeffects. These HTTP/provider checks aren't another UI archive journey.

Owner native SettingsArchives sees selectedtwo+independentolderduplicate. SyntheticPATCH503 retains all rows/usefulerror. Restorehooks then parentretryPATCH200/success. Natively restoreduplicateBravo too. Ownerreload retains onlyolderAlpha archive. Managerreload sameIDs/originalfields/seednames; PNG captured. Ordinary owner repeatedactiveRestore400 andemptyRestore404 preserve rows. All event-owned children restored; independent/completed history unchanged.

Analysis field-comparisons.json73exact row-set comparisons; literal-lifecycle-expectations.json24independently literal artifact rows. Only automatic updated_at on activelychanged counseling/document/openfollowup is explicitly recorded with monotonic check separately from full meaningful-field equality. Every independent/control row retains everyfield. Replay/noeffects comparisons include all fields.

Control limitations: ids-only nativePOST/PATCH state records method/status but count0/ids[] is not payload proof. Native selected2+providerexacteffects identify targets; separateHTTPpayloads are explicit. No native latepartialprovider fault; realcommand fake-persistence faults inserverarchives prove that boundary. No transaction/concurrent/lostresponse guarantee or whole#1360 acceptance.

Pre-action target error: guessed ArchiveSelected(2) name had zeroUIDmatches, so no action. Captured bulk-confirm-open-before.json and bulk-selection-inspect.json; corrected fresh named ConfirmArchive control, no source/recipe change. One ordinary probe guessed nonexistent personnel/ID PATCH path and failed HTMLJSON parsing exit2; preserved repeated-restore-wrong-endpoint.json. DoctorPASS, corrected existing personnel PATCH with action/id gives400 and subsequentallfieldnoeffects readback. Neither control mistake earns productfailure/gate credit.

Cleanup: restore allnetwork/feedback controls, clean onlyhelper-owned seedIDs/dependents, exact originalA3/B1 restored; ownerArchivesreload0. FinaldoctorPASS andownedcleanupPASS. NoUI-createdPeople, remote or existinglocaldatabase touched. Captures survivecleanup.

Sanitization: syntheticnames/accounts/publicIDs only; PNGs visually inspected and text scanned for credential/token material. No redactions needed. Archive packaging after this clean run doesn't change its tested revision/digest or claim another native run. Independent expanded-artifact acceptance separate from coordinator native execution.

