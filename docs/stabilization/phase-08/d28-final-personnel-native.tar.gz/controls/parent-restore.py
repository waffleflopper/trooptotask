import current as x
import json
d=x.d;seed=json.loads((x.c/'seed.json').read_text());person=seed['ids']['person'];before=json.loads((d.E/'before-parent-archive-full.json').read_text())['rows'];event=json.loads((x.c/'parent-event.json').read_text())
x.artifact_button('parent-restore','SPC '+seed['name']+', Synthetic','Restore');d.wire('parent-restore-wire',2,'personnel');after=x.full('parent-restored-full');r=next(r for r in after['orgA']['personnel'] if r['id']==person);assert r['archived_at'] is None
for table in ['counseling_records','personnel_documents','personnel_follow_ups','leader_notes']:
 for old in before['orgA'][table]:
  new=next(r for r in after['orgA'][table] if r['id']==old['id'])
  if old['id'] in event['activeIDs']:
   assert new['archived_at'] is None;assert {k:v for k,v in new.items() if k!='updated_at'}=={k:v for k,v in old.items() if k!='updated_at'}
  else:assert new==old
for org,ts in before.items():
 for table,rs in ts.items():
  if org=='orgA' and table in ['personnel','audit_logs','counseling_records','personnel_documents','personnel_follow_ups','leader_notes']:continue
  assert rs==after[org][table]
for old in before['orgA']['personnel']:
 new=next(r for r in after['orgA']['personnel'] if r['id']==old['id'])
 if old['id']==person:assert {k:v for k,v in old.items() if k!='updated_at'}=={k:v for k,v in new.items() if k!='updated_at'}
 else:assert old==new
for k in ['noteArchived','counselingArchived','documentArchived','followArchived']:
 table={'noteArchived':'leader_notes','counselingArchived':'counseling_records','documentArchived':'personnel_documents','followArchived':'personnel_follow_ups'}[k];row=next(r for r in after['orgA'][table] if r['id']==seed['ids'][k]);assert row['archived_at']=='2026-08-01T12:00:00+00:00'
f=next(r for r in after['orgA']['personnel_follow_ups'] if r['id']==seed['ids']['followCompleted']);assert f['status']=='completed' and f['archived_at'] is None and f['completed_at']=='2026-09-14T12:00:00+00:00'
d.snap('parent-restored-archives');d.act('parent-restored-personnel-nav','link','Personnel');d.within('parent-restored-person-open','row','Open SPC '+seed['name']+', Synthetic','button','Details');d.tool('parent-restored-detail-reload','navigate_page',{'pageId':2,'type':'reload'});d.snap('parent-restored-detail');d.shot('parent-restored-detail');d.call('parent-restored-files',['artifact-files','orgA',person],True)
(d.E/'group3-parent-assertions.json').write_text(json.dumps({'status':'PASS','parentID':person,'event':event['event'],'exactEventChildren':event['activeIDs'],'childCount':8,'historicalAndSiblingRowsExact':True,'AugustArchive':'2026-08-01T12:00:00Z','completedSeptemberFollowup':'2026-09-14T12:00:00Z','SDSAndTrainingFullRowsExact':True,'foreignAndOtherPeopleFullRowsExact':True,'allowedUpdatedAtEffects':'Parent and active mutable artifact rows updated by legitimate archive/restore. No timestamp forgery.','nativeOwnerRestore':'PASS and named Person reopened after reload'},indent=2))
