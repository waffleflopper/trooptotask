import datetime, json, os, pathlib, subprocess, sys

root = pathlib.Path.cwd()
run = root / '.verification/evidence/verify-trooptotask/d17-units-final'
run.mkdir(parents=True, exist_ok=True)
label, kind, *args = sys.argv[1:]
prefix = {'verify': ['npm', 'run', '--silent', 'verify:app', '--'],
          'helper': ['node', '.agents/skills/verify-trooptotask/helpers/control.mjs', '--worker', '1'],
          'command': []}[kind]
argv = prefix + args + (['--worker', '1'] if kind == 'verify' else [])
assert not (run / (label + '.stdout')).exists(), 'Preserve original attempts; use a new label'
env = os.environ.copy()
env['npm_config_cache'] = str(root / '.verification/d17-units-npm-cache')
node_bin = pathlib.Path('/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin')
assert (node_bin / 'node').is_file()
env['PATH'] = str(node_bin) + os.pathsep + env['PATH']
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True)
(run / (label + '.stdout')).write_text(result.stdout)
(run / (label + '.stderr')).write_text(result.stderr)
(run / (label + '.command.json')).write_text(json.dumps({
    'argv': argv, 'cwd': str(root), 'environmentOverrides': {'npm_config_cache': env['npm_config_cache'], 'PATH_prepend': str(node_bin)},
    'start': start, 'finish': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit': result.returncode}, indent=2) + '\n')
print(result.stdout[:10000])
if result.stderr: print('STDERR:', result.stderr[-2500:])
print('EXIT:', result.returncode)
sys.exit(result.returncode)
