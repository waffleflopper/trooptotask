from drive import *
from datetime import datetime,timezone
seed=json.loads((E/'notes-legacy-seed.json').read_text());step=next(r for r in seed['progress'] if r['step_name']=='Orientation');outcome=json.loads((E/'notes-outcome.json').read_text());saved=outcome['savedNotes'];ready=json.loads((E/'notes-holder-ready.json').read_text());held=json.loads((Path(ready['evidence'])/'input.json').read_text());now=datetime.now(timezone.utc);checks=[]
for label in ['A','B']:
 response=json.loads((E/('notes-response-'+label+'.json')).read_text());request=json.loads((E/('notes-request-'+label+'.json')).read_text());body=response['body'];notes=body['notes'];own=[n for n in notes if n.get('text')==request['text']];assert response['status']==200 and body['id']==step['id'];assert notes[:len(step['notes'])]==step['notes'];assert len(own)==1 and own[0]['userId']==response['actorId'];assert all(n in saved for n in notes)
 for n in own:
  assert re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',n['timestamp']);stamp=datetime.fromisoformat(n['timestamp'].replace('Z','+00:00'));assert datetime.fromisoformat(held['at'])<=stamp<=now
 checks.append({'label':label,'result':'PASS','idMatchesStep':True,'originalPrefixRetained':True,'ownMarkerAuthorMatchesOrdinaryActor':True,'savedUtcMillisecondsWithinObservedRun':True,'everyReturnedNoteIsSaved':True,'returnedNoteCount':len(notes)})
assert sorted(c['returnedNoteCount'] for c in checks)==[len(step['notes'])+1,len(step['notes'])+2]
write(E/'notes-authoritative-response-comparison.json',json.dumps({'result':'PASS','kind':'Read-only analysis of already captured ordinary responses and provider rows; no repeated mutation','analysisAt':now.isoformat(),'checks':checks,'noWinnerOrderAssumed':True},indent=2)+'\n')
print('Both authoritative responses retain original notes and their own saved attributed additions; UTC milliseconds and final saved membership pass.',flush=True)
