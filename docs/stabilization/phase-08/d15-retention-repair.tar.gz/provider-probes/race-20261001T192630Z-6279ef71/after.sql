SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('f26f12be-6e4c-459a-9799-af3362e03e53'::uuid,'60adab62-28c5-4ac1-8392-f0dad30afd75'::uuid,'53e1a61a-f990-491d-8a2d-7ffdbc1e4cae'::uuid,'b996fb21-3706-4e46-9eeb-13ecb0ab4e99'::uuid,'0000ee48-e1ab-4f68-97ef-592faf23afdb'::uuid,'52857546-463d-4c0e-ab30-c0103bb623f9'::uuid,'e2022d59-2538-490e-ba30-a504107cf437'::uuid,'fbbdead6-2aed-4918-937a-b15097318ef4'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('35d09cc4-ac94-4ca5-a503-116016a5c947'::uuid,'5d4f5240-1528-489e-9650-b6a9ce24ab89'::uuid,'69a9d712-7ffa-4424-8138-a45be9fc9a3b'::uuid,'7e59dc0d-7daa-4b89-b3de-be1311854766'::uuid,'121e753b-9896-419e-b372-e52150ca73a6'::uuid,'65a8c444-8672-45ac-aec4-560d72a1fa4f'::uuid,'d6f0133a-83f6-49a5-9f2b-b7df6f19312c'::uuid,'ba767031-9519-4563-9516-8bce6e96544f'::uuid)) s), '[]'::json));
