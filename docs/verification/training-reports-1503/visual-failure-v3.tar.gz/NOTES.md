# 1503 final acceptance v3: driver notes

These are driver-written interpretation notes, not raw captures. Raw preview and Paper tool calls/results are extracted verbatim from the session transcript into `raw/` (458 files, `raw-index.json`, three recorded tool errors) by `extract-raw.py`. Screenshots are in `png/` with `png/INDEX.txt`. Measurement scripts injected through `preview_evaluate` are in `scripts/`.

## Run identity

- Candidate 20902555358097834f7b7cdab652e845bc86136097b05db2434ab0507d443696, revision 83b58c2c8a3a5218d944912ff5795cf39bb4966e, session 9b701c6c-4fa5-4a9b-9769-186c7106243f, worker 1, origin http://127.0.0.1:39077 driven through http://localhost:39077.
- Doctor PASS at 02:40:09Z (`doctor-acceptance-start.txt`) and 03:13:46Z (`doctor-acceptance-final.txt`), same candidate and session.
- Runtime: T3 preview tab `tab_4`, UA T3Code(Nightly)/0.0.46-nightly.20261003.2638 Chrome/152.0.7977.130 Electron/44.4.2. The launcher's Chromium was not used. Preview tab reported `visible:false` throughout.
- Process-local date 2026-10-03 (AKDT), fixture `dates.ui` 2026-10-03, asOf 3 Oct 2026 in UI. Times below are UTC 2026-10-04.
- App theme at start: dark (`data-theme` dark, mode-watcher `system`). Theme was changed only through the app's Toggle theme button. Left dark; localStorage `theme` now reads `dark` (its value before the run was not captured).

## Sign-in and rate budget

A private loopback relay on localhost:47935 set `window.name`; one evaluate filled the visible #email/#password, cleared `window.name` and returned only the email and password length 48. Every Sign In was a native click. Auth POSTs: login 02:40:31, logout ~02:48:03, login 02:48:14, logout ~02:48:33, login 02:48:39, logout ~02:49:15, login 02:49:21, logout ~02:49:33, login 02:49:38, logout ~02:49:50, then waited for the window, login 02:55:46, logout ~03:12:3x, login 03:12:54, logout 03:13:2x. Fourteen POSTs, never more than ten in a 15-minute window, no 429. The relay's first process hit the harness background limit at about 03:10 (after its last use) and was restarted for trainingForeign, then stopped; its port and directory are gone. Clipboard never used.

## Outcome 1 (trainingConfigure, 02:40–02:48)

- Matrix (png/01): Able Required 09/2027 Current, Targeted Not Done, Optional N/A; Baker/Unassigned Required Not Done.
- Matrix Reports link 02:41:24: only `training/reports/__data.json`; no summary GET. 3 soldiers, 25%, "stays at" (sr-only), Ready 1 / expired 0 / not recorded 3 / lapse 0, grid Bravo 0/—, Unassigned 0/—, Alpha 100/0 (50%), Total 33/0 (25%).
- Reload 02:41:35: navigation type reload 200; only resource was app-shell notification-count. Same-origin page HTML 76,230 bytes sha256 b0f01ff5…d155; SSR `<main>` text holds 3 soldiers, 25%, stays at, "Nothing lapses before 1 Jan.", the sr forecast table and grid; no Foreign.
- Group open/Escape/reopen: zero requests. Alpha: one GET `?group=<A>` 200 `private, no-store`, "1 soldier", 50%. Bravo: one GET, 0%.
- MOS 68W → 33%, 2 soldiers; +11B request `mos=68W&mos=11B`, canonical URL `mos=11B&mos=68W`, 3 soldiers. Role options Medic/NCO; Medic 50%. Rank SPC 25%. View options All training / Verification Focus View; Focus columns Targeted, Required; Types menu lists Targeted, Required; Required alone 33%; +Targeted keeps saved-view order.
- Horizons 30/60/180: BY 2 NOV / 2 DEC / 1 APR, sr rows 6/10/27 with short final buckets (2 Nov, 2 Dec, 1 Apr), ticks without collisions. Rows by Duty role (NCO 2, Medic 1) and MOS (11B 1, 68W 2).
- Invalid address-bar inputs defaulted independently: first case canonicalised to `view=<focus>&mos=68W&types=<req>`; second (foreign view/group/type, horizon 60, rowsBy role) to `horizon=60&rowsBy=role`. No foreign IDs or names in HTML. Canonical `group=<A>&horizon=60&rowsBy=role` reload rendered from SSR with no API fetch.
- Filtered empty `group=<B>&types=<tgt>`: "No applicable requirements for these filters." with Clear filters, 1 soldier, Export enabled.
- Cell detail: Alpha × Targeted one GET `scope=cell&row=<A>&type=<tgt>`; selected cell, status "1 requirement not ready or lapsing by 1 Jan."; Total × Required GET without `row`, status 2. No record IDs in URL. Detail synthetic 503 → "Unable to load affected soldiers" + Retry → 200.
- Direct API probes (API proof, not UI): missing scope 400, cell without type 400, bad scope 400, foreign type 404, Optional 404, stale row 404, foreign group row 404, type outside `types` 404, focus gap 200 (2 rows), focus gap outside types 404, focus wave 404, empty valid Alpha × Required 200 `[]`, Bravo × Targeted 200 `[]`, pageSize 1000 → 100, pageSize 1 → 2 pages, page 2 → Unassigned, page 99 → page 1, page 0/pageSize 0 → 1/25, extra record id ignored; summary horizon 45 and foreign group default independently. Errors carry no Cache-Control; successes `private, no-store`.
- Export (header button): mouse click unfiltered GET `/export` 200, xlsx, `attachment; filename="training-report-2026-10-03.xlsx"`, `private, no-store`; Blob 6929 bytes sha256 8bb41a2b…c9ff; one sheet "Training Report"; Able "Current (2027-09-26)" (= fixture `trainingExpires`), Baker/Unassigned Not Done, N/A for Targeted. Alpha + Required with trusted keyboard Enter on the focused button: 6806 bytes sha256 ae4753b0…3270, one row Able. Export synthetic 503 → "Unable to export the workbook" + Retry → 200 Blob 6806 bytes (not saved). Blob capture suppressed only the blob anchor click; restored and verified native.
- Matrix → Manage Types and Matrix → Manage Views → Back to Matrix navigated client-side and kept matrix data.

## Outcome 2 (trainingConfigure, synthetic in-page fetch faults; all other traffic real)

- Synthetic 503 on Alpha: alert "Unable to update the briefing … Showing the last briefing that loaded." + Retry; Group trigger reverted to All groups, 25% unchanged, URL unchanged, aria-busy false (png/02). Retry: real GET 200, Alpha 50%.
- Revisit Bravo → Alpha: two fresh GETs; Bravo signal aborted at the next selection.
- Hold real Bravo 200: "Updating briefing" in the reserved header slot, model still Alpha, toolbar and actions rects unchanged (png/03). Clear filters → GET ""; held Bravo aborted then released 3 s later: no overwrite.
- Held synthetic 503 for Bravo, then Rows by Duty role (new GET 200), release: no alert, latest result kept. One earlier attempt where the second click landed on the closing select overlay (event target HTML) produced the alert correctly because no newer selection existed; preserved in raw.
- Hold MOS request, client-navigate to Training: signal aborted on navigation; release on the matrix produced no error, no alert.
- Observer `errors` stayed empty. Console showed only Vercel analytics 404/MIME, preload warnings and my own probe 400/403/404s; no hydration warnings.
- Harness note: a click issued ~300–400 ms after choosing a select option sometimes lands on the closing overlay (target HTML). I retried those visibly; no request was issued by the swallowed click.

## Outcome 5 access

- trainingView 02:48: nav Home/Training only; matrix toolbar has no Import/Manage; 0 cell buttons; Reports 25%, 3 soldiers, Export enabled; summary/detail/export 200 `private, no-store`.
- rosterScoped 02:48: `?group=<Bravo>` kept, "0 soldiers", filtered-empty copy, Export disabled (png/04). Group options Alpha and Bravo (catalog metadata); MOS 68W, rank SPC, role Medic only. No Baker/Unassigned/Foreign names in DOM or bodies. Detail Bravo row / `unassigned` / foreign row 404; Total × Required 200 `[]`; Alpha × Targeted 200 Able. Direct API exports (API-only): Bravo headers-only 6727 bytes; unfiltered one Able row 6831 bytes.
- trainingEmpty 02:49: "0 soldiers", "No applicable requirements." + "No soldier is required to hold the configured training.", no Clear filters, Export disabled (png/05). Summary/Alpha summary soldierCount 0; detail Total 200 `[]`; Alpha row 404; direct export headers-only 6728 bytes.
- viewer 02:49: page title "Error 403", "You don't have permission to view this page."; raw document 403; summary/detail/export 403 `{"message":"You don't have permission. This requires Training can view permissions. …"}`.
- trainingForeign 03:13: B report "Verification Organization B · 1 soldier", 0%; B summary only Foreign group; B detail Foreign type 200 [Foreign]; B detail with A type 404; A page document 404; A summary/detail/export 404 "Organization not found".
- Visible disabled Export buttons were not clicked; direct exports are API proof only.

## Boundary setup (privileged fixture) and goal

- Before: provider A/B organization rows and A/B personnel_trainings equal root originals; goals 90/90.
- 02:50 `node .verification/1503-boundary-seed.mjs setup 1` rc 0: tag e679357b, role BriefingBoundarye679357b, view ca691a60… "Boundary briefing e679357b", 100 people, 13 types, 1 view, 852 records; readback counts identical. Lever sha256 1fc8ad6f…4051 (`boundary-seed-sha256.txt`, copy `boundary-seed-used-v3.mjs`, receipt `boundary-seed-receipt.json`).
- orgOwner Settings → Policies: goal 90 → 85, Training Readiness Save, toast "Training readiness goal saved" (02:57). Provider A 85, B 90.

## Outcome 3 (orgOwner, goal 85)

- View + role: 100 soldiers; 74% falls to 61% by 1 Jan; Ready 752, expired 0, not recorded 261, lapse 139; sentence "loses 14 points". Cells 85/84/75/74/65/64/55/54 each ▼10 with tiers good/okay/okay/caution/caution/warn/warn/danger; Rounding 11/13 85 okay no drop; Drop nine 85 good no drop; Cliff fifty 100 ▼50; Not applicable "—" non-button. Legend "Readiness bands for a 85% goal": 85+ / 75–84 / 65–74 / 55–64 / <55 / ▼10+. The 13th type is absent from the view.
- Toolbar census (`__geo`, two passes; the first pass in a hidden tab once reported false misses, the second pass is recorded):
  - 1440 dark, long view + role: one row 1126/1126, all ten controls hit-test themselves; view trigger truncates with ellipsis and `title`. Multi-filter (view, Alpha, PFC, role, two types): same (png/06). Pending: "Updating briefing" in the reserved slot, no control or action rect moved; 30 D activated while pending → new GET, held response released without overwrite. Error: radio reverted, alert below toolbar, Retry worked.
  - 1024 dark: two rows (filters, horizon), toolbar top 184 in steady, pending and error, nothing covered (png/07, 08). Light: same, pending and error repeated (png/13).
  - 390 dark: three filter rows + horizon row, toolbar top 220 steady/pending, header status/Clear/Export on one row, shell `sidebar-wrapper` 390/390 (png/09, 10, 11). Light steady same (png/12).
  - 1440 light steady: one row, all hit.
- At 390 only, the first filter reflows the wrapped rows (shorter group label) and Clear filters is inserted before Export, moving Export 101 px right. At 1024 and 1440 Export stays put. Recorded as an observation.
- Grid click Total × Below 74 at 1440 light: one detail request, status "36 requirements not ready or lapsing by 1 Jan.", dashed 2 px outline offset 2 on the trigger, drop marker solid 2 px inset ring + chip. documentElement 1440, only the grid scrolled (126). Escape and theme toggle left every scroll position identical (png/14).
- Contrast (canvas-composited computed colors, Total row): light min cell text 4.57 (danger #e7000b / #fafaf9), outline and chip vs cell min 4.14 on red, chip text 18.92, N/A 7.31, horizon column 4.57; dark min text 5.19 (danger #fb2c36 / #0c0a09), outline/chip min 3.65 on red, N/A 7.64, horizon 5.19. Legend swatches equal the cell band colors.
- Keyboard: native `preview_press Tab` moved focus to the next grid cell, but `document.hasFocus()` stayed false and `:focus-visible` never matched, so the focus ring could not be observed live. Built CSS (`.svelte-kit/output/client/_app/immutable/assets/0.DRNhDZzA.css`) contains the table-scoped `focus-visible` relative/z-20/ring-2/ring-foreground/ring-offset-4/ring-offset-background rules; the trigger carries no own focus classes. This is source/build inspection, not live proof. No styles injected.
- Shared consumers (orgOwner, read-only): Training matrix 750/750 (1024), 372/439 (390, Manage Types and More offscreen); Training types and views fit at both widths; Personnel 718/726 (1024), 364/694 (390, Archive/Manage Groups/Add Person offscreen); Calendar Reports 718/718 and 364/364; Assignment Planner 710/710 and 348/348; Critical Tasks Reports 726/726 (1024), 348/481 (390, Duty role and Export offscreen). Every toolbar is nowrap with static actions and nothing covered. The 390 offscreen controls are main's unchanged hidden-scroll contract: `git diff 3de24c86` shows the actions group identical to main and the root's default branch unchanged. Other consumers (BulkStatus, Calendar page, ICT library/personnel, Onboarding history/templates, Rating Scheme, Ranks, report-workspace-toolbar) were not driven.
- Critical Tasks Reports live: cells `data-palette="ramp"`, danger rgb(232,185,168) / text rgb(36,33,29), legend <60% … 90%+ / Not applicable, position static (png/23).

## Outcome 4 chart (orgOwner, goal 85)

`__sweepFn` clicks the horizon radios programmatically (`element.click()`) inside the measurement script to step 30/60/90/180; native horizon clicks were exercised separately above. It measures SVG text and the HTML caption row for pairwise overlap, text over amber bars, text outside the SVG, line fill, ticks and the sr table. `__lineHits` samples the drawn line path and reports text boxes it passes through.

- Ordinary (view + role): dark 1440/1024/390 and light 1440/1024/390, all four horizons: no text overlaps, nothing outside, line fill none, area `fill-foreground/5`, goal rule `stroke-success` dashed 4px 4px, goal label right and muted, domain 50–100 includes 85, single amber bar inside the plot on the axis, caption row above the SVG (y −37…−4), end label "61%" `fill-current` red, sr lapse in the 17 Oct week (first expired day 14 Oct = asOf+11). At 1024 the chart is 324 px wide beside the Bottom line.
- Cliff fifty: dark and light at 1440/1024/390, all horizons: "100%" start label at y16–31 inside the SVG, caption in its own row above; no overlaps. D2 from v2 is fixed (png/15, 16).
- 13-type mix (All training + role) at 1440: no line/label hits.
- Flat (role Medic, 33%) at 1440: "stays at", no bars, no overlaps.
- Goal near end (Medic + Required, 100% flat, goal 85) at 1440/1024/390: goal label stays right (y61–75), green "100%" end label directly above (y45–60), no overlap.
- finalBucketWitness (All training + Final bucket fifty + role), light and dark at 1440/1024/390: 30 days 100% → 50%, Ready 100, lapse 50 by 2 Nov; sr ends "31 Oct 100% 0 No", "2 Nov 50% 50 Yes"; caption "1 Nov – 2 Nov" right-aligned; end label "50%" 5 px above the bar count "50"; no text-text or text-bar overlap. 60/90/180 clean.
- **Defect D3.** In the finalBucketWitness 30-day state, the drawn forecast line passes through the "Goal 85%" label at every width and both themes: 1440 x 660–664 of label box 639–692 (between "Goa" and "l"), 1024 x 267–268 of 223–276 (through "%"), 390 x 291–293 of 249–302 (through "%"), each across the label's full height y61–74. Visible in png/17, 18, 19, 21. The author's census checked text-text and text-bar overlaps only. The goal-label side rule only tests the end label, not the line.
- Screenshots png/20 and png/22 show a stale radio highlight while the DOM reports the correct `aria-checked`; a fresh capture (png/21) is correct. Treated as a hidden-tab paint lag, not an app defect.
- Paper (read-only, `paper/`): anatomy matches: header with actions right, toolbar row, BLUF beside forecast, line with light area, dashed green goal with right label, highlighted window with caption, amber bars on the axis, hot-spot grid with legend and drop chips, Today and horizon columns. Accepted amendments: green→amber→red bands, dark/inverse drop outline and chip instead of amber, muted goal label (success token 3.08:1 on light for 11 px text). Paper's caption sits inside the highlighted band; the candidate uses a separate row above the plot. Paper has no label crossing.

## Restoration

- Goal 85 → 90 through Settings → Policies, toast "Training readiness goal saved" (03:12:13). Provider A 90, B 90; A and B organization rows equal root originals; B personnel_trainings equal; A personnel_trainings: the one original row is identical, the other 852 are recorded seed rows.
- Seed e679357b remains for root: readback personnel 100, training_types 13, training_views 1, personnel_trainings 852 (`boundary-seed-readback-final.json`).
- All in-page hooks lived in page memory and were discarded by navigations; final readback after sign-out: no `__o3/__x3/__geo/__sweepFn`, `createObjectURL` and anchor `click` native, `fetch` is the app's SvelteKit wrapper, `window.name` empty. Signed out; post-logout API fetch returns an opaque redirect.
- No source, recipe, helper or Paper writes. Worker and seeds left running for root closeout.
