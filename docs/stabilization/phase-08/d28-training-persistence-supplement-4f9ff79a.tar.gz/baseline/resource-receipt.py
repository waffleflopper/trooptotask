import json,pathlib,subprocess,re,sys
r=pathlib.Path('/home/waffleflops/.cache/t2t-1376-training-remaining-20261007'); session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1'); raw=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-remaining-20261007')
if sys.argv[1]=='before':
 s=json.loads((session/'session.json').read_text());state={k:s[k] for k in ['repository','worker','id','phase','candidate','revision','origin','supervisor','appProcess','mcpProcess','browserProcess','controlPort']}
 groups={p['group'] for k,p in state.items() if isinstance(p,dict) and 'group' in p};state['ownedGroupMembers']=[]
 for p in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   stat=(p/'stat').read_text().rsplit(')',1)[1].split();group=int(stat[2]);start=stat[19]
   if group in groups:state['ownedGroupMembers'].append({'pid':int(p.name),'group':group,'start':start})
  except (OSError,ValueError):pass
 porttext=(session/'provider/supabase/config.toml').read_text();state['ports']=sorted(set(map(int,re.findall(r'^port\s*=\s*(\d+)',porttext,re.M)))|{int(s['origin'].rsplit(':',1)[1]),s['controlPort'],int((session/'chrome-profile/DevToolsActivePort').read_text().splitlines()[0])})
 state['containers']=json.loads(subprocess.check_output(['docker','inspect',*subprocess.check_output(['docker','ps','-aq'],text=True).split()],text=True));state['containers']=[{'Id':c['Id'],'Name':c['Name'],'Created':c['Created'],'Mounts':sorted(c['Mounts'],key=lambda m:m['Destination']),'Pid':c['State']['Pid'],'StartedAt':c['State']['StartedAt'],'Ports':c['NetworkSettings']['Ports']} for c in state['containers']]
 (raw/'precleanup-owned-resources.json').write_text(json.dumps(state,indent=2));print('Captured owned process/group identities, ports and container resource identities.')
else:
 s=json.loads((raw/'precleanup-owned-resources.json').read_text());fail=[]
 for p in s['ownedGroupMembers']:
  f=pathlib.Path('/proc')/str(p['pid'])/'stat'
  if f.exists():
   try:
    stat=f.read_text().rsplit(')',1)[1].split()
    if stat[19]==p['start'] and stat[0]!='Z':fail.append({'processRemaining':p})
   except OSError:pass
 listeners=subprocess.check_output(['ss','-ltnp'],text=True);presentports=[p for p in s['ports'] if re.search(r':'+str(p)+r'\s',listeners)]
 if presentports:fail.append({'portsRemaining':presentports})
 containers=json.loads(subprocess.check_output(['docker','inspect',*subprocess.check_output(['docker','ps','-aq'],text=True).split()],text=True));now={c['Id']:c for c in containers};original=[json.loads(x) for x in (r/'pre-containers.jsonl').read_text().splitlines()];originalids={c['ID'] for c in original}
 missing=originalids-set(now)
 if missing:fail.append({'preexistingMissing':sorted(missing)})
 ownedids={c['Id'] for c in s['containers']}-originalids
 if ownedids&set(now):fail.append({'ownedContainersRemain':sorted(ownedids&set(now))})
 for c in s['containers']:
  if c['Id'] in originalids:
   n=now[c['Id']]
   if (c['Name'],c['Created'],c['Mounts'],c['Pid'],c['StartedAt'])!=(n['Name'],n['Created'],sorted(n['Mounts'],key=lambda m:m['Destination']),n['State']['Pid'],n['State']['StartedAt']):fail.append({'preexistingIdentityChanged':c['Id']})
 for kind,command in [('networks',['docker','network','ls','--no-trunc','--format','{{json .}}']),('volumes',['docker','volume','ls','--format','{{json .}}'])]:
  before=[json.loads(x) for x in (r/('pre-'+kind+'.jsonl')).read_text().splitlines()];after=[json.loads(x) for x in subprocess.check_output(command,text=True).splitlines()]
  if sorted(before,key=str)!=sorted(after,key=str):fail.append({'resourceSetChanged':kind})
 if session.exists():fail.append({'ownedDirectoryRemains':str(session)})
 result={'status':'PASS' if not fail else 'FAIL','failed':fail,'ownedProcessesChecked':len(s['ownedGroupMembers']),'ownedPorts':s['ports'],'ownedContainersRemoved':len(ownedids),'preexistingContainersRetained':len(originalids),'preexistingNetworksRetained':len((r/'pre-networks.jsonl').read_text().splitlines()),'preexistingVolumesRetained':len((r/'pre-volumes.jsonl').read_text().splitlines()),'workerDirectoryAbsent':not session.exists()};(raw/'actual-closure.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
