import json,os,subprocess,sys,pathlib
mode,label,*args=sys.argv[1:]
env=dict(os.environ,PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH'],TMPDIR='/home/waffleflops/.cache/t2t-d21-tmp')
cmd=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args] if mode=='control' else ['npm','run','--silent','verify:app','--',*args]
r=subprocess.run(cmd,text=True,capture_output=True,env=env)
p=pathlib.Path('.verification/evidence/verify-trooptotask/d21-operations-final')/(label+'.json');p.write_text(r.stdout)
if r.stderr: p.with_suffix('.stderr.log').write_text(r.stderr);print(r.stderr[-2000:],file=sys.stderr)
try:
 j=json.loads(r.stdout)
 if 'content' in j:
  for c in j['content']:
   if c.get('type')=='text':print(c['text'])
 else:print(json.dumps(j,indent=2))
except Exception:print(r.stdout[-6000:])
sys.exit(r.returncode)
