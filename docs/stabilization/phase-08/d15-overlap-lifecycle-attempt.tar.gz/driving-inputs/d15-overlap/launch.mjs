import * as core from '../../../scripts/verification/core.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
if(process.cwd()!==core.repository||!/^d15-overlap-[a-z0-9-]+$/.test(process.env.D15_EVIDENCE||''))throw Error('Exact checkout and explicit safe run name required');
const e=path.join(core.repository,'.verification/evidence/verify-trooptotask',process.env.D15_EVIDENCE);
if(await fs.realpath(e)!==e)throw Error('Non-symlink evidence directory required');
async function write(name,text){await fs.writeFile(path.join(e,name),text,{flag:'wx'});}
const entries=[];
for(const file of await core.files()) {
 const map=file==='.agents/skills/verify-trooptotask/SKILL.md'||(file.startsWith('.agents/skills/verify-trooptotask/features/')&&file.endsWith('.md'));
 if((file.endsWith('.md')&&!map)||path.basename(file).startsWith('.env'))continue;
 try{entries.push({path:file,sha256:createHash('sha256').update(await fs.readFile(path.join(core.repository,file))).digest('hex')});}
 catch(error){if(error.code!=='ENOENT')throw error;entries.push({path:file,deleted:true});}
}
const {stdout:revision}=await core.execute('git',['rev-parse','HEAD']);
const candidate=await core.candidate();
await write('prelaunch-input-hashes.json',JSON.stringify({revision:revision.trim(),candidate,entries},null,2)+'\n');
const args=['run','--silent','verify:app','--','launch','--worker','1'];
await write('launch-command.json',JSON.stringify({command:['npm',...args],nonsecretOverrides:{TMPDIR:process.env.TMPDIR}},null,2)+'\n');
try {
 const r=await core.execute('npm',args,{cwd:core.repository,timeout:420000,maxBuffer:16*1024*1024});
 await write('launch.json',r.stdout); await write('launch-stderr.log',r.stderr);
 const state=JSON.parse(r.stdout);if(state.candidate!==candidate)throw new Error('Launch candidate mismatch');
 console.log(JSON.stringify({revision:revision.trim(),candidate,inputs:entries.length,launch:state}));
}catch(error){await write('launch-error-stdout.log',error.stdout||'');await write('launch-error-stderr.log',error.stderr||'');throw error;}
