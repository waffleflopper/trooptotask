#!/usr/bin/env bash
# usage: t.sh NAME DESC TOOL JSON   (native tool)
E=.verification/evidence/verify-trooptotask/1504-final-v1/accept
n=$1; d=$2; tool=$3; j=$4
exec $E/r.sh "$n" "$d" -- npm run --silent verify:app -- tool "$tool" "$j"
