from pathlib import Path
import hashlib,json,re
c=Path('/home/waffleflops/.cache/t2t-1376-final-personnel-implementation-ad0cea51-20261008')
report=(c/'comment-review-scratch/report.md').read_text()
blocks=re.findall(r'```ts\n(.*?)\n```',report,re.S)[:4]
paths=['src/lib/server/adapters/inMemory.ts','src/lib/server/adapters/test-support/inMemoryRows.types.ts','src/lib/server/adapters/test-support/scopedFixtureRows.ts','src/lib/storage/contracts.ts']
frozen={x['path']:x for x in json.loads((c/'final-native-freeze.json').read_text())['inputs']}
results=[]
for path,block in zip(paths,blocks):
    current=Path(path).read_text()
    if path.endswith('/inMemory.ts'):
        marker="import type { FixtureRowStore, FixtureFindOptions, FixtureFindResult } from './test-support/inMemoryRows.types';"
        possibilities=[current.replace(marker,block+'\n'+marker,1),current.replace('\n\n'+marker,'\n'+block+'\n'+marker,1),current.replace('\n\n'+marker,'\n'+block+'\n\n'+marker,1)]
    elif path.endswith('inMemoryRows.types.ts'):possibilities=[current.replace('\trangeFilters?',block+'\n\trangeFilters?',1)]
    elif path.endswith('scopedFixtureRows.ts'):possibilities=[current.replace('\t\tinsert: inner.insert.bind(inner),',block+'\n\t\tinsert: inner.insert.bind(inner),',1)]
    else:possibilities=[block+'\n'+current]
    matched=[s for s in possibilities if hashlib.sha256(s.encode()).hexdigest()==frozen[path]['sha256']]
    assert len(matched)==1,path
    results.append({'path':path,'originalNativeSHA256':frozen[path]['sha256'],'currentSHA256':hashlib.sha256(current.encode()).hexdigest(),'reconstructedByOnlyAcceptedCommentInsertion':'EXACT'})
print(json.dumps({'status':'PASS','fourSourceFiles':'Only exact accepted comment removals and associated blank-line normalization since native candidate','results':results},indent=2))
