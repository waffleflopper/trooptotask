import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'd15-overlap'))
from drive import *

for action in ['doctor', 'tools']:
    command = ['npm', 'run', '--silent', 'verify:app', '--', action, '--worker', '1']
    write(E / (action + '-initial-command.json'), json.dumps(command, indent=2) + '\n')
    result = subprocess.run(command, text=True, capture_output=True)
    write(E / (action + '-initial.json'), result.stdout)
    write(E / (action + '-initial-stderr.log'), result.stderr)
    assert result.returncode == 0, result.stderr
control(['fixture'], 'fixture')
for org in ['orgA', 'orgB']:
    for table in ['personnel_onboardings', 'onboarding_step_progress', 'personnel_trainings']:
        control(['rows', table, org], 'original-' + table + '-' + org)
seed = control(['seed', 'onboarding-legacy'], 'lifecycle-legacy-seed')
page = control(['actor', 'onboardingOperate', 'onboarding'], 'lifecycle-before-actor')['pageId']
snapshot = snap(page, 'lifecycle-native-before')
assert seed['person']['last_name'] in snapshot and 'NO TEMPLATE' in snapshot, snapshot
screen(page, 'lifecycle-native-before')
print('Original A/B rows and native active packet captured; ledgered lifecycle cohort ready.', flush=True)
