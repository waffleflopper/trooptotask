#!/usr/bin/env bash
# usage: snap.sh NAME PAGE -> snapshot to snaps/NAME.txt (refuses reuse)
E=.verification/evidence/verify-trooptotask/1504-final-v2/accept
[ -e $E/snaps/$1.txt ] && { echo "REFUSED snapshot $1 exists"; exit 1; }
MAXOUT=300 $E/t.sh "snap-$1" "snapshot $1" take_snapshot "{\"pageId\":$2,\"filePath\":\"$E/snaps/$1.txt\"}" >/dev/null
echo $E/snaps/$1.txt
