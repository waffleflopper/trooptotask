import json, subprocess
from pathlib import Path
p=Path.cwd()/'.verification/evidence/verify-trooptotask/d16-integrity-final'; f=json.loads((p/'fixture.json').read_text())['ids']; s=json.loads((p/'seed.json').read_text())['ids']; a=json.loads((p/'actor-scoped.json').read_text())
setup={'orgId':a['orgId'],'rated':f['personA'],'rater':f['personB'].upper(),'senior':f['personB'],'intermediate':s['archived'],'reviewer':f['personUnassigned'],'existing':s['due30']}
script='''async () => {
 const s=SETUP, endpoint='/org/'+s.orgId+'/api/rating-scheme';
 const createdBody={ratedPersonId:s.rated,evalType:'NCOER',ratingPeriodStart:'2026-09-30',ratingPeriodEnd:'2027-09-29',status:'active',reportType:'AN',
  raterPersonId:s.rater,seniorRaterPersonId:s.senior,intermediateRaterPersonId:s.intermediate,reviewerPersonId:s.reviewer,notes:'API local create witness'};
 const created=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(createdBody)});
 const createdResult=await created.json();
 const clearBody={id:s.existing,raterPersonId:'',seniorRaterPersonId:null,intermediateRaterPersonId:'',reviewerPersonId:null,
  raterName:'External cleared Rater',seniorRaterName:'External cleared Senior',intermediateRaterName:'External cleared Intermediate',reviewerName:'External cleared Reviewer',notes:'API external clearing witness'};
 const cleared=await fetch(endpoint,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(clearBody)});
 return {created:{submitted:createdBody,status:created.status,body:createdResult},cleared:{submitted:clearBody,status:cleared.status,body:await cleared.json()}};
}'''
params={'pageId':a['pageId'],'function':script.replace('SETUP',json.dumps(setup)),'filePath':str(p/'09-api-create-clear.json'),'waitForStableDom':False}
r=subprocess.run(['npm','run','--silent','verify:app','--','tool','evaluate_script',json.dumps(params)],capture_output=True,text=True,check=True)
(p/'09-api-create-clear-action.json').write_text(r.stdout)
x=json.loads((p/'09-api-create-clear.json').read_text()); print(json.dumps({'created_status':x['created']['status'],'created_id':x['created']['body'].get('id'),'cleared_status':x['cleared']['status']}))
