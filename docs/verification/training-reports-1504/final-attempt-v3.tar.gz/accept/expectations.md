# Final-v3 independent expectations (written before any native action)

Sources: `.verification/1504-issue.json`, `1433-for-1504.json`, the training-completions-reports recipe, root's untouched `root-public-fixture.json` and `root-*-original.json`. No app calculator was called.

Identity: HEAD 06834840, base ee1ca2b2, worker 1, candidate cf12aef2…c0d, origin http://127.0.0.1:34391, session 4ff43aa1…, Chromium 152.0.7977.82.
Fixture day 2026-10-04 (dates.ui). Default horizon 90 days -> 2027-01-02. Org A 426de6e0…, Org B 064ad4ae…, groupA 4760ca80…, groupB fc151208…
Required 144a0d89… (all, 12 months, 60/30 warning), Targeted f97043a4… (MOS 68W, excluding NCO), Optional 449a5cd2… (is_optional, excluded from readiness).
People A: Able da710157… (Alpha, 68W, Medic), Baker ad9ad507… (Bravo, 11B, NCO), Unassigned 314c19c8… (68W, NCO).
Original row: abc75aa0… Able Required 2026-09-27 -> 2027-09-27 (ready; lapses after horizon). Org B has zero completion rows. Goal 90%.

## 1. Original
Applicable: Required x3 + Targeted x Able = 4. Ready 1, expired 0, missing 3, lapse 0 -> 25% today, 25% horizon.
Type risk: Required Not ready 2 / By-horizon 0 above Targeted 1 / 0.
Total Required cell -> Baker + Unassigned Not Done (2 rows). Alpha x Targeted -> Able Not Done.

## 2. Dated import (literal dates)
Baker Required completed 2024-10-04 -> expires 2025-10-04 (expired). Able Targeted completed 2025-10-19 -> expires 2026-10-19 (15 days, orange warning, ready; lapses inside horizon).
Ready 2, expired 1, missing 1, lapse 1 -> 50% today, 25% horizon.
Required risk 2/0 above Targeted 0/1.
Total Required detail: Unassigned Not Done first, then Baker expired 2025-10-04. Targeted: Able, warning, 2026-10-19, Lapses Yes.
Workbook: sheets exactly Summary, Forecast, Hot spots, Focus, Requirements; Requirements exactly 3 rows (Unassigned Req Not Done; Baker Req expired 2025-10-04; Able Tgt warning 2026-10-19 Yes), regardless of open detail.

## 3. training-pages seed (+26 Alpha PFC; #1 68W/Medic, 25 x 11B/NCO)
29 People; applicable = 29 Required + Targeted (Able, temp#1) = 31.
Ready 2, expired 1, missing 28, lapse 1 -> 2/31 = 6% today, 1/31 = 3% horizon.
Required Total = 26 temp + Unassigned + Baker = 28 rows: page 1 "Rows 1–25 of 28", page 2 "Rows 26–28 of 28" (2 pages; no live middle page).
Focus expectation: after native Enter on Next reaching the last page and Previous reaching page 1, document.activeElement is SECTION#training-affected-soldiers after the actual response. If focus moved to another ordinary control during a held response, it stays there after release.
Retry: on initial-detail 503 and page-change 503, native Enter on Retry focuses the section during the held load and after success; failed page change keeps the old range; retry requests the attempted page.

## 4. Empty Bravo + Targeted
Bravo has only Baker (11B/NCO); Targeted excludes NCO -> zero applicable. Print: exactly one landscape page with title, filter line and empty-state message; no trailing blank page.

## Print omission list
No sidebar, header, banners, toolbar/filters, Export/Print/Clear filters, Rows by, Rows per page, Focus links, pagination, Retry. Filters line beneath title. Error message remains truthful.

## Access (step 6)
trainingView: A report and download (Required/Targeted A data). rosterScoped: Alpha only -> Able only (Required + Targeted = 2 applicable; post-import Able ready on both). trainingEmpty: no People, empty state, export disabled, API export 5 sheets with zero Requirements rows. viewer (no Training lane): direct denial. trainingForeign: B only, no A rows; B has no completions.
