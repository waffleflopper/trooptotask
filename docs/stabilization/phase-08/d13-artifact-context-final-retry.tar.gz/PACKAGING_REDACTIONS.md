Packaging follows final doctor and owned cleanup. Public synthetic Organization/Person/contributor IDs, row fields and artifact paths remain visible. Binary PDF/screenshots and non-redacted payload bytes are exact. JWT/signed-query/Bearer token values alone are sanitized, without changing observations. Failed launches and malformed commands retain their explicit outcomes; archives do not establish a fresh live run.

{
  "redactions": []
}
