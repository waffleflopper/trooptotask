import hashlib,json,pathlib,re,subprocess,zipfile,xml.etree.ElementTree as X

C=pathlib.Path(__file__).parent
E=pathlib.Path.cwd()/'.verification/evidence/verify-trooptotask/d28-final-persistence-baseline-recovery-6f5bcb15-20261008'
def read(name):return json.loads((E/name).read_text())
def full(name):return read(name)['rows']
inventory=json.loads((C/'public-artifact-inventory.json').read_text())
for r in inventory:
 b=(E/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
seed=json.loads(read('lifecycle-seed.json')['stdout'])['ids'];seedids=set(seed.values())
original=full('original-full.json');restored=full('restored-full.json');count=0
for org,tables in original.items():
 for table,rows in tables.items():
  if table=='audit_logs':continue
  expected=[r for r in rows if r['id'] not in seedids];assert restored[org][table]==expected,(org,table);count+=len(expected)
assert count==27
def row(name,table,rid):return next(r for r in full(name)['orgA'][table] if r['id']==rid)
fid='d2665769-c09b-47d8-b5b1-31ac22df3c0a'
f=[row(n,'personnel_follow_ups',fid) for n in ['follow-created-full.json','follow-edited-full.json','follow-completed-full.json','follow-reopened-full.json']]
assert all(r['due_date']=='2026-11-01' for r in f)
assert f[2]['status']=='completed' and f[2]['completed_at'] and f[3]['status']=='open' and f[3]['completed_at'] is None
assert all(r['id']==f[0]['id'] and r['personnel_id']==f[0]['personnel_id'] and r['created_at']==f[0]['created_at'] for r in f)
nid='f03e159f-fc1d-4863-a8b4-383e8d2cecd8';notes=[row(n,'leader_notes',nid) for n in ['note-created-full.json','note-archived-full.json','note-restored-full.json']]
assert notes[0]['archived_at'] is None and notes[1]['archived_at'] and notes[2]['archived_at'] is None
assert all(r['text']=='Literal final persistence note 0c60fb11' and r['author']==notes[0]['author'] and r['created_at']==notes[0]['created_at'] for r in notes)
before=full('note-restored-full.json');archived=full('parent-archived-full.json');returned=full('parent-restored-full.json');cascade=read('cascade-assertions.json');events=0
for check in cascade['checks']:
 table=check['table'];rid=check['id'];b=next(r for r in before['orgA'][table] if r['id']==rid);a=next(r for r in archived['orgA'][table] if r['id']==rid);r=next(r for r in returned['orgA'][table] if r['id']==rid)
 assert set(b)==set(a)==set(r)
 if check['parentEvent']:
  events+=1;assert a['archived_at']==cascade['parentArchiveEvent'] and r['archived_at'] is None
  assert {k:v for k,v in b.items() if k not in ['archived_at','updated_at','status']}=={k:v for k,v in r.items() if k not in ['archived_at','updated_at','status']}
 else:assert a==b==r
assert len(cascade['checks'])==14 and events==8
assert before['orgB']==archived['orgB']==returned['orgB']
assert before['orgA']['personnel_extended_info']==archived['orgA']['personnel_extended_info']==returned['orgA']['personnel_extended_info']
assert before['orgA']['personnel_trainings']==archived['orgA']['personnel_trainings']==returned['orgA']['personnel_trainings']
pid='4c98aad9-c812-40b0-935a-1646f2a468fb'
counsel=next(r for r in full('counsel-saved-full.json')['orgA']['counseling_records'] if r['id']=='1cc6594a-3be8-4f59-8214-65d8aa735200')
assert counsel['personnel_id']==pid and counsel['date_conducted']=='2026-10-07' and counsel['title']==counsel['subject']=='RECOVERY-0c60fb11 counseling' and counsel['summary']==counsel['notes']=='Literal counseling summary'
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(E/'personnel-records.xlsx') as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in pathlib.PurePosixPath(n).parts;z.read(n)
 strings=[''.join(n.itertext()) for n in X.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
 names=[n.attrib['name'] for n in X.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',ns)];assert names==['Personnel Info','Training Records','Counseling Records','Availability History']
 sheets=[]
 for i in range(1,5):
  rows=[]
  for r in X.fromstring(z.read(f'xl/worksheets/sheet{i}.xml')).findall('s:sheetData/s:row',ns):
   cells={}
   for c in r.findall('s:c',ns):
    ref=re.match('[A-Z]+',c.attrib['r'])[0];index=0
    for a in ref:index=index*26+ord(a)-64
    v=c.find('s:v',ns);value=v.text if v is not None else None
    if c.attrib.get('t')=='s':value=strings[int(value)]
    if c.attrib.get('t')=='inlineStr':value=''.join(c.find('s:is',ns).itertext())
    cells[index-1]=value
   rows.append([cells.get(k) for k in range(max(cells,default=-1)+1)])
  sheets.append(rows)
 assert [len(s)-1 for s in sheets]==[21,1,3,0]
 info={r[0]:r[1] if len(r)>1 else None for r in sheets[0][1:]}
 expected={'Rank':'SPC','Last Name':'MapLifecycle0c60fb11','First Name':'Synthetic','MOS':'68W','Duty Role':'Medic','Group':'Alpha','ETS':None,'PCS / DEROS':None,'Archived At':None,'Emergency Contact Name':'Synthetic Contact','Emergency Contact Relationship':'Sibling','Emergency Contact Phone':'555-0101','Spouse Name':'Synthetic Spouse','Spouse Phone':'555-0102','Vehicle Make/Model':'Synthetic Sedan','Vehicle Plate':'VFY1376','Vehicle Color':'Blue','Personal Email':'sheet@example.invalid','Personal Phone':'555-0103','Address':'1 Test Street, Test City, AK, 99501','Leader Notes':None}
 assert info==expected
 assert sheets[1][1]==['Verification Required Training','2026-09-14']
 padded=[tuple(r+[None]*(7-len(r))) for r in sheets[2][1:]]
 assert set(padded)=={('2026-10-07','RECOVERY-0c60fb11 counseling',None,None,'completed',None,'Literal counseling summary'),('2026-09-14','Archived counseling 0c60fb11',None,None,'draft',None,None),('2026-09-14','Active counseling 0c60fb11',None,None,'draft',None,None)}
 assert padded[0][0]=='2026-10-07'
pre=read('precleanup-owned-resources.json');assert read('actual-closure.json')['status']=='PASS'
assert all(not (pathlib.Path('/proc')/str(r['pid'])).exists() for r in pre['ownedGroupMembers'])
ss=subprocess.check_output(['ss','-ltnp'],text=True);assert all(not re.search(':'+str(p)+r'\s',ss) for p in pre['ports'])
containers=set(subprocess.check_output(['docker','ps','-aq','--no-trunc'],text=True).split());assert all(r['Id'] not in containers for r in pre['ownedContainers'])
nets=set(subprocess.check_output(['docker','network','ls','-q','--no-trunc'],text=True).split());assert not set(pre['ownedNetworks'])&nets
volumes=set(subprocess.check_output(['docker','volume','ls','-q'],text=True).split());assert not set(pre['ownedVolumes'])&volumes
assert not pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1').exists()
print(json.dumps({'status':'PASS','payloadHashes':len(inventory),'originalRowsAfterInsertOnlySeed':count,'wholeWorkbook':'4sheets/21+1+3+0literalrows','counselingDate':'October7','directOwnedClosure':'PASS','independentLiveExecution':False}))
