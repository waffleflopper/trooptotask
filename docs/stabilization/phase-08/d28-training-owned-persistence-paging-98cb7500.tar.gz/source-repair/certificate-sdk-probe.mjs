import { createRequire } from 'node:module';
const require = createRequire('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/package.json');
const { createClient } = require('@supabase/supabase-js');
const { trainingCompletedRow } = await import('file:///home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/src/features/training/server/trainingPersistenceMapping.server.ts');
let wire;
const client = createClient('http://training.invalid', 'synthetic-request-key', {
 auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
 global: { fetch: async (input, init) => {
  const request = new Request(input, init);
  wire = { url: request.url, prefer: request.headers.get('prefer'), body: await request.json() };
  return Response.json([]);
 }}
});
const mapped = [{personnelId:'person-a',trainingTypeId:'type-a',completionDate:'2026-10-07',expirationDate:'2027-10-07',notes:null,updatedAt:'2026-10-07T15:12:46.986Z'}].map(row => trainingCompletedRow(row,'org-a'));
await client.from('personnel_trainings').upsert(mapped,{onConflict:'organization_id,personnel_id,training_type_id'}).select('id, certificate_url');
const columns = new URL(wire.url).searchParams.get('columns').split(',').map(s=>s.replaceAll('"',''));
if (columns.includes('certificate_url') || columns.includes('id') || columns.includes('created_at')) throw new Error('Completed upsert must exclude certificate and saved identity metadata from conflict updates');
console.log(JSON.stringify({boundary:'Installed SDK wire observation only; stored preservation independently proved by native and SQL artifacts',columns,wire},null,2));
