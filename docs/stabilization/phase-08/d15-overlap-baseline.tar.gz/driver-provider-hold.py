#!/usr/bin/env python3
"""D15 note/lifecycle overlap probe; fixed seed-bound SQL, no data mutation.
Root warms/drives both ordinary HTTP requests after HOLDING. Exactly two ordinary update
wait chains must reach the holder; then it automatically ROLLBACKs.
Timeout/SIGINT/SIGTERM also release. Root must drain requests before seed cleanup.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import signal
import subprocess
import sys
import threading
import time
import tomllib
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, ProxyHandler, Request
import uuid


REPOSITORY = Path(__file__).resolve().parents[3]


class Blocked(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Blocked(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def public_error(error):
    return {"error_type": type(error).__name__,
            "message": str(error) if isinstance(error, Blocked) else "Private command/configuration diagnostics withheld."}


def decode_json_values(stdout):
    """psql rows are complete JSON values; json_agg may put newlines inside one."""
    decoder = json.JSONDecoder()
    values = []
    cursor = 0
    while cursor < len(stdout):
        while cursor < len(stdout) and stdout[cursor].isspace():
            cursor += 1
        if cursor == len(stdout):
            break
        value, cursor = decoder.raw_decode(stdout, cursor)
        values.append(value)
        if cursor < len(stdout) and not stdout[cursor].isspace():
            raise json.JSONDecodeError("Expected whitespace between JSON values", stdout, cursor)
    return values


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regular(value):
    path = Path(value).absolute()
    require(path.resolve() == path and path.is_file() and not path.is_symlink(),
            "Input must be a real regular file without symlink ancestors.")
    require(path.stat().st_uid == os.getuid(), "Input must belong to the current user.")
    return path


def read_json(path):
    return json.loads(regular(path).read_text())


def uid(value):
    require(isinstance(value, str), "Seed ID must be a UUID string.")
    require(str(uuid.UUID(value)) == value, "Seed ID must be a canonical lowercase UUID.")
    return value


def literal(value):
    return "'" + str(value).replace("'", "''") + "'"


def instant(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        # Preserve the original redirect status/body as evidence; never follow it.
        return None


def http(request, timeout):
    opener = build_opener(ProxyHandler({}), NoRedirect())
    try:
        response = opener.open(request, timeout=timeout)
    except HTTPError as error:
        response = error
    with response:
        return response.status, {key.lower(): value for key, value in response.headers.items()}, response.read(1048576).decode("utf-8", errors="replace")


class Probe:
    def __init__(self, args):
        evidence_root = REPOSITORY / ".verification/evidence/verify-trooptotask"
        evidence = Path(args.evidence).absolute()
        require(evidence.resolve() == evidence and evidence.is_relative_to(evidence_root),
                "Evidence must be under this checkout's durable verification root without symlinks.")
        evidence.mkdir(parents=True, exist_ok=True, mode=0o700)
        require(evidence.is_dir() and evidence.stat().st_uid == os.getuid(), "Evidence directory is not owned.")
        self.run = evidence / ("assignment-hold-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
        self.run.mkdir(mode=0o700)
        self.app_name = "t2t-d15-overlap-" + uuid.uuid4().hex
        self.mode = args.mode
        self.seconds = args.max_hold_seconds
        require(5 <= self.seconds <= 40, "Hold bound must be 5 through 40 seconds.")
        seed_path = regular(args.seed)
        requests = [regular(args.request_a), regular(args.request_b)]
        require(all(path.is_relative_to(evidence_root) for path in [seed_path, *requests]),
                "Seed and frozen request files must be under this checkout's durable evidence root.")
        for path in requests:
            body = read_json(path)
            require(isinstance(body, dict), "Use a frozen ordinary JSON object.")
            if self.mode == "notes":
                require(set(body) == {"action", "stepId", "text"} and body["action"] == "addNote"
                        and isinstance(body["text"], str) and re.fullmatch(r"D15 overlap note [AB] [0-9a-f]{8}", body["text"]),
                        "Use only the fixed attributed note inputs.")
                uid(body["stepId"])
            else:
                require(set(body) == {"id", "status"} and body["status"] in ("cancelled", "completed"),
                        "Use only ordinary cancel/complete inputs.")
                uid(body["id"])
        self.save("input.json", {"mode": self.mode, "at": stamp(), "repository": str(REPOSITORY),
                  "session": str(Path(args.session).absolute()), "session_id": args.session_id,
                  "probe_sha256": sha(Path(__file__)), "max_hold_seconds": self.seconds,
                  "seed": {"path": str(seed_path), "sha256": sha(seed_path)},
                  "requests": [{"path": str(path), "sha256": sha(path), "body": read_json(path)} for path in requests]})
        module_path = REPOSITORY / "scripts/verification/environment.py"
        spec = importlib.util.spec_from_file_location("d15_owned_environment", module_path)
        environment = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(environment)
        self.session = environment.private_session(args.session)
        expected = Path.home() / ".local/state/trooptotask-verification" / hashlib.sha256(str(REPOSITORY).encode()).hexdigest()[:16] / "worker-1"
        require(self.session == expected, "Only this checkout's exact worker-1 session is allowed.")
        require(read_json(self.session / "environment.json").get("repository") == str(REPOSITORY),
                "Provider marker must name this checkout before loading its environment.")
        state, self.workdir, self.environment = environment.owned(self.session)
        require(state["repository"] == str(REPOSITORY), "Provider belongs to a different checkout.")
        status = environment.status(self.session)
        self.container = "supabase_db_" + state["project"]
        records = environment.containers(state, self.workdir, self.environment)
        matches = [item for item in records if item["Name"] == "/" + self.container and item["State"]["Running"]]
        require(len(matches) == 1, "Exact owned database container is not running.")
        self.project = state["project"]
        self.worker = read_json(self.session / "session.json")
        require(self.worker.get("id") == uid(args.session_id), "Worker session ID differs from the frozen argument.")
        require(self.worker.get("repository") == str(REPOSITORY) and self.worker.get("worker") == "1"
                and self.worker.get("phase") == "running", "Worker-1 is not running for this checkout.")
        supervisor = self.worker["supervisor"]
        require(type(supervisor["pid"]) is int and supervisor["pid"] > 0, "Invalid supervisor identity.")
        proc = Path("/proc") / str(supervisor["pid"])
        stat = (proc / "stat").read_text()
        current_start = stat[stat.rfind(")") + 2:].split()[19]
        require(current_start == str(supervisor["start"]) and (proc / "cmdline").read_bytes().decode() == supervisor["command"],
                "Owned supervisor was replaced.")
        origin = urlsplit(self.worker["origin"])
        require(origin.scheme == "http" and origin.hostname == "127.0.0.1" and origin.port
                and not origin.username and not origin.password and origin.path in ("", "/")
                and not origin.query and not origin.fragment, "App origin is not owned loopback HTTP.")
        config = tomllib.loads((self.workdir / "supabase/config.toml").read_text())
        require(config["auth"]["site_url"] == self.worker["origin"], "App origin differs from the owned provider configuration.")
        port = self.worker["controlPort"]
        require(type(port) is int and 0 < port < 65536, "Invalid owned control port.")
        self.save("doctor-request.json", {"method": "POST", "url": f"http://127.0.0.1:{port}",
                                          "body": {"command": "doctor"}, "authorization": "owned token withheld"})
        code, headers, body = http(Request(f"http://127.0.0.1:{port}", data=b'{"command":"doctor"}', method="POST",
                                          headers={"Authorization": "Bearer " + self.worker["token"], "Content-Type": "application/json"}), 30)
        doctor = json.loads(body)
        self.save("doctor-result.json", {"http_status": code, "authenticated": headers.get("x-t2t-session") == self.worker["id"],
                                         "status": doctor.get("status"), "code": doctor.get("code")})
        require(code == 200 and headers.get("x-t2t-session") == self.worker["id"] and doctor.get("status") == "PASS",
                "Owned authenticated doctor did not pass; refusing a stale/unavailable worker.")
        self.seed = read_json(seed_path)
        fixture = read_json(self.session / "fixtures.json")
        ledger_path = regular(self.session / "verify-trooptotask-owned.json")
        ledger = read_json(ledger_path)
        require(self.seed.get("kind") == "onboarding-legacy" and re.fullmatch(r"[0-9a-f]{8}", self.seed.get("tag", "")),
                "Use the recorded onboarding-legacy seed.")
        require(len(self.seed.get("packets", [])) == 1 and len(self.seed.get("progress", [])) == 3,
                "Use the fixed original legacy cohort.")
        self.org = uid(fixture["ids"]["orgA"])
        self.packet = self.seed["packets"][0]
        self.packet_id = uid(self.packet["id"])
        self.person = self.seed["person"]
        require(set(self.person) == {"id", "organization_id", "group_id", "rank", "first_name", "last_name", "slug"}
                and set(self.packet) == {"id", "organization_id", "personnel_id", "template_id", "started_at", "status"},
                "Use the original helper's fixed Person/packet capture fields.")
        require(self.person["id"] == self.packet["personnel_id"]
                and self.person["organization_id"] == self.org and self.person["group_id"] == fixture["ids"]["groupA"]
                and self.person["first_name"] == "Synthetic" and self.person["rank"] == "SPC"
                and self.person["last_name"] == "MapLegacy" + self.seed["tag"]
                and self.person["slug"] == "map-legacy-" + self.seed["tag"], "Unexpected legacy Person capture.")
        require(self.packet["organization_id"] == self.org and self.packet["template_id"] is None
                and self.packet["status"] == "in_progress" and self.packet["started_at"] == fixture["dates"]["ui"],
                "Use the original null-template seed capture.")
        expected = [("Orientation", "checkbox", True, None, None),
                    ("Paperwork", "paperwork", False, ["Submitted", "Reviewed", "Filed"], "Reviewed"),
                    ("Historic task", "checkbox", True, None, None)]
        progress = sorted(self.seed["progress"], key=lambda row: row["sort_order"])
        require(len({row["id"] for row in progress}) == 3, "Progress identities must be distinct.")
        for index, (row, shape) in enumerate(zip(progress, expected)):
            require(set(row) == {"id", "organization_id", "onboarding_id", "template_step_id", "step_name", "step_type",
                    "completed", "stages", "current_stage", "sort_order", "active", "notes"},
                    "Use the original helper's fixed progress capture fields.")
            require((row["step_name"], row["step_type"], row["completed"], row["stages"], row["current_stage"]) == shape
                    and row["sort_order"] == index and row["template_step_id"] is None and row["active"] is True
                    and row["onboarding_id"] == self.packet_id and row["organization_id"] == self.org
                    and row["notes"] == [{"text": "Legacy retained work " + self.seed["tag"],
                        "timestamp": "2000-01-01T12:00:00.000Z", "userId": fixture["actors"]["onboardingConfigure"]["id"]}],
                    "Progress capture differs from independently specified legacy business fields.")
        for table, rows in (("personnel", [self.person]), ("personnel_onboardings", [self.packet]),
                            ("onboarding_step_progress", progress)):
            for row in rows:
                uid(row["id"])
                require(any(entry.get("kind") == self.seed["kind"] and entry.get("tag") == self.seed["tag"]
                    and entry.get("table") == table and entry.get("organization") == "orgA"
                    and row["id"] in entry.get("ids", []) for entry in ledger.get("seeded", [])),
                    "A target ID is absent from the current worker's seed ledger.")
        self.target = progress[0]
        self.target_id = self.target["id"]
        bodies = [read_json(path) for path in requests]
        if self.mode == "notes":
            require(all(body["stepId"] == self.target_id for body in bodies)
                    and [body["text"] for body in bodies] == ["D15 overlap note " + label + " " + self.seed["tag"] for label in ("A", "B")],
                    "Both notes must target exactly the original ledgered Orientation progress.")
        else:
            require(all(body["id"] == self.packet_id for body in bodies)
                    and [body["status"] for body in bodies] == ["cancelled", "completed"],
                    "Both transitions must target exactly the ledgered active parent.")
        self.table = "onboarding_step_progress" if self.mode == "notes" else "personnel_onboardings"
        self.lock_id = self.target_id if self.mode == "notes" else self.packet_id
        self.endpoint = "onboarding-steps" if self.mode == "notes" else "onboarding"
        self.container_id = matches[0]["Id"]
        require(re.fullmatch(r"[0-9a-f]{64}", self.container_id), "Invalid exact database container ID.")
        self.save("ownership.json", {"provider": status, "worker": "1", "worker_id": self.worker["id"],
                  "supervisor_identity_matches": True, "container": self.container, "container_id": self.container_id,
                  "seed_sha256": sha(seed_path), "ledger_sha256": sha(ledger_path),
                  "environment_helper_sha256": sha(module_path), "config_sha256": sha(self.workdir / "supabase/config.toml"),
                  "target": self.target, "packet": self.packet,
                  "requests": [{"method": "PUT", "url": self.worker["origin"].rstrip("/") + "/org/" + self.org + "/api/" + self.endpoint,
                                "body": read_json(path), "authorization": "ordinary actor credentials withheld"} for path in requests]})
        self.command = ["docker", "exec", "-i", "-e", "PGPASSWORD=postgres", "-e", "PGAPPNAME=" + self.app_name + "-observer",
                        self.container_id, "psql", "-X", "-q", "-A", "-t", "-U", "supabase_admin", "-d", "postgres", "-v", "ON_ERROR_STOP=1"]
        self.holder_command = ["PGAPPNAME=" + self.app_name if arg == "PGAPPNAME=" + self.app_name + "-observer" else arg
                               for arg in self.command]

    def save(self, name, value):
        descriptor = os.open(self.run / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "w") as output:
            json.dump(value, output, indent=2)
            output.write("\n")

    def plan(self, name, sql):
        path = self.run / (name + ".sql")
        if path.exists():
            require(path.read_text() == sql, "A recorded SQL plan changed within this run.")
        else:
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "w") as output:
                output.write(sql)

    def log(self, name, value):
        descriptor = os.open(self.run / (name + ".outputs.jsonl"), os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "a") as output:
            output.write(json.dumps({"at": stamp(), **value}) + "\n")

    def sql(self, name, sql):
        sql = "SET statement_timeout = '10s'; SET lock_timeout = '3s';\n" + sql
        self.plan(name, sql)
        result = subprocess.run(self.command, input=sql,
                                cwd=self.workdir, env=self.environment, text=True, capture_output=True, timeout=15)
        self.log(name, {"exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr[-4000:]})
        require(result.returncode == 0, "Controlled SQL failed; inspect the run's public SQL/results.")
        return decode_json_values(result.stdout)

    def snapshot(self, name):
        org, packet, person = literal(self.org), literal(self.packet_id), literal(self.person["id"])
        return self.sql(name, f"""SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = {org}::uuid AND p.id = {packet}::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = {org}::uuid AND id = {person}::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = {org}::uuid AND s.onboarding_id = {packet}::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
""")[0]

    def validate_before(self, before):
        require(len(before["packets"]) == 1 and before["probe_trigger_count"] == 0, "Packet absent or old probe fault remains.")
        packet = before["packets"][0]
        require(all(packet.get(key) == value for key, value in self.packet.items())
                and packet["completed_at"] is None and packet["cancelled_at"] is None, "Packet business fields changed.")
        require(before["person"] == self.person, "Seed Person business fields changed.")
        rows = {row["id"]: row for row in before["progress"]}
        require(len(rows) == 3 and set(rows) == {row["id"] for row in self.seed["progress"]}, "Expected exactly the three original progress rows.")
        require(all(all(rows[row["id"]].get(key) == value for key, value in row.items())
                    and rows[row["id"]]["training_type_id"] is None for row in self.seed["progress"]), "Progress business fields changed.")
    def observer(self, identity):
        pid = identity["pid"]
        holder_match = f"pid = {pid} AND backend_start = {literal(identity['backend_start'])}::timestamptz AND application_name = {literal(self.app_name)} AND usename = 'supabase_admin' AND datname = 'postgres'"
        return f"""WITH RECURSIVE chain(root_pid, node_pid, path) AS (
 SELECT a.pid, a.pid, ARRAY[a.pid] FROM pg_stat_activity a
 WHERE a.datname = 'postgres' AND a.pid <> {pid} AND a.state = 'active' AND a.wait_event_type = 'Lock'
 AND a.query ~* 'update[[:space:]]+("?public"?[.])?"?{self.table}"?([[:space:]]|$)'
 UNION ALL SELECT c.root_pid, b.pid, c.path || b.pid FROM chain c
 CROSS JOIN LATERAL unnest(pg_blocking_pids(c.node_pid)) AS b(pid)
 WHERE NOT b.pid = ANY(c.path) AND cardinality(c.path) < 12
), reached AS (SELECT root_pid, json_agg(path) AS paths FROM chain WHERE node_pid = {pid} GROUP BY root_pid)
SELECT json_build_object('holder_matches', EXISTS(SELECT 1 FROM pg_stat_activity WHERE {holder_match}),
 'waiting', COALESCE((SELECT json_agg(json_build_object('pid', a.pid, 'backend_start', a.backend_start::text,
 'query_class', '{self.mode}-ordinary-update', 'query_bytes', octet_length(a.query),
 'activity_query_capture_size', current_setting('track_activity_query_size'),
 'state', a.state, 'wait_event_type', a.wait_event_type,
 'wait_event', a.wait_event, 'blocking_paths', r.paths) ORDER BY a.pid)
 FROM pg_stat_activity a JOIN reached r ON r.root_pid = a.pid), '[]'::json));
"""

    def hold(self):
        before = self.snapshot("before")
        self.validate_before(before)
        unused = self.sql("holder-name-unused", f"SELECT json_build_object('unused', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = {literal(self.app_name)}));\n")[0]
        require(unused["unused"], "Generated holder name already exists.")
        if self.mode == "notes":
            where = f"onboarding_id = {literal(self.packet_id)}::uuid AND template_step_id IS NULL AND step_name = 'Orientation' AND step_type = 'checkbox' AND completed AND active AND current_stage IS NULL AND training_type_id IS NULL AND stages IS NULL AND notes = {literal(json.dumps(self.target['notes']))}::jsonb"
        else:
            where = f"personnel_id = {literal(self.person['id'])}::uuid AND template_id IS NULL AND status = 'in_progress' AND completed_at IS NULL AND cancelled_at IS NULL"
        start = f"""SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.{self.table}
WHERE organization_id = {literal(self.org)}::uuid AND id = {literal(self.lock_id)}::uuid AND {where}
FOR UPDATE;
SELECT json_build_object('event', 'ready');
"""
        holder = None
        cleanup = {"holder_started": False}
        observed = False
        try:
            holder = Holder(self, start)
            holder.send(start)
            identity, _ = holder.until("identity", 5)
            require(type(identity["pid"]) is int and identity["pid"] > 0, "Invalid holder PID.")
            holder.identity = identity
            _, events = holder.until("ready", 8)
            require([event.get("id") for event in events if event.get("event") == "locked"] == [self.lock_id], "Hold did not lock exactly the ledgered row.")
            held = self.snapshot("held-original")
            require(held == before, "Business rows changed before either controlled request.")
            self.save("ready.json", {"status": "HOLDING", "at": stamp(), "holder": identity, "application_name": self.app_name,
                      "packet_id": self.packet_id, "step_id": self.target_id, "requests_driven_by_root": True})
            print(json.dumps({"status": "HOLDING", "evidence": str(self.run), "holder": identity}), flush=True)
            observer = self.observer(identity)
            deadline = time.monotonic() + self.seconds
            while time.monotonic() < deadline:
                require(holder.process.poll() is None, "Holder exited before both writer waits.")
                waits = self.sql("writer-waits", observer)[0]
                require(waits["holder_matches"], "Held backend identity disappeared or changed.")
                require(len(waits["waiting"]) <= 2, "More than two writers make this interleaving ambiguous.")
                if len(waits["waiting"]) == 2:
                    self.save("observed-two-writers.json", {"at": stamp(), "holder": identity, **waits})
                    require(self.snapshot("committed-before-release") == before, "Committed business state changed while both controlled writers waited.")
                    observed = True
                    break
                time.sleep(0.25)
            require(observed, "Both ordinary update waits were not observed within the bound; outcome is inconclusive.")
        finally:
            if holder:
                try:
                    cleanup = holder.close()
                except BaseException as error:
                    cleanup = {"holder_started": True, "holder_absent": False, **public_error(error),
                               "recovery": "Exact holder identity/plans are recorded; 90s idle transaction timeout is a backstop."}
            self.save("cleanup.json", {"at": stamp(), **cleanup, "root_must_drain_http_requests_before_seed_cleanup": True})
            require(cleanup.get("holder_absent", not holder), "Holder absence not proven; cleanup is incomplete and recorded.")
        return {"status": "TWO_WRITERS_OBSERVED_AND_RELEASED", "holder_absent": True,
                "rollback_confirmed": cleanup.get("rollback_confirmed"), "app_outcome": "unestablished; root collects both responses and final rows/UI"}


class Holder:
    def __init__(self, probe, sql):
        self.probe = probe
        self.identity = None
        self.lines = queue.Queue()
        self.probe.plan("holder-start", sql)
        self.process = subprocess.Popen(probe.holder_command, cwd=probe.workdir, env=probe.environment,
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        text=True, bufsize=1)
        self.reader = threading.Thread(target=self.collect, daemon=True)
        self.reader.start()

    def collect(self):
        for line in self.process.stdout:
            self.probe.log("holder", {"line": line.rstrip("\n")})
            self.lines.put(line)
        self.lines.put(None)

    def send(self, sql):
        self.process.stdin.write(sql)
        self.process.stdin.flush()

    def until(self, event, timeout):
        deadline = time.monotonic() + timeout
        events = []
        while time.monotonic() < deadline:
            try:
                line = self.lines.get(timeout=max(0.01, deadline - time.monotonic()))
            except queue.Empty:
                break
            require(line is not None, "Held psql connection ended; inspect its recorded output.")
            if not line.strip().startswith("{"):
                continue
            value = json.loads(line)
            events.append(value)
            if value.get("event") == event:
                return value, events
        raise Blocked("Held psql did not report " + event + " within its bounded wait.")

    def close(self):
        result = {"holder_started": True, "rollback_confirmed": False}
        if self.process.poll() is None:
            rollback = "ROLLBACK;\nSELECT json_build_object('event', 'holder-rolled-back');\n"
            self.probe.plan("holder-rollback", rollback)
            try:
                self.send(rollback)
                self.until("holder-rolled-back", 5)
                result["rollback_confirmed"] = True
            except BaseException as error:
                result["rollback_error"] = public_error(error)
        try:
            if self.process.poll() is None:
                self.send("\\q\n")
                self.process.stdin.close()
            self.process.wait(timeout=5)
        except BaseException:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        # A killed docker client alone does not prove its in-container backend exited.
        # Restrict recovery to this connection's PID + backend_start + application_name.
        if not self.identity:
            candidates = self.probe.sql("holder-recover-identity", f"""SELECT json_build_object('holders', COALESCE(json_agg(
 json_build_object('pid', pid, 'backend_start', backend_start::text)), '[]'::json)) FROM pg_stat_activity
WHERE application_name = {literal(self.probe.app_name)} AND usename = 'supabase_admin' AND datname = 'postgres';
""")[0]["holders"]
            require(len(candidates) <= 1, "Holder recovery identity is ambiguous; refusing termination.")
            if candidates:
                self.identity = candidates[0]
        if self.identity:
            pid = self.identity["pid"]
            started = literal(self.identity["backend_start"]) + "::timestamptz"
            condition = f"pid = {pid} AND backend_start = {started} AND application_name = {literal(self.probe.app_name)} AND usename = 'supabase_admin' AND datname = 'postgres'"
            recovered = self.probe.sql("holder-cleanup", f"""SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE {condition};
""")[0]
            result["backend_cleanup"] = recovered
            result["holder_absent"] = self.probe.sql("holder-absent", f"SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE {condition}));\n")[0]["absent"]
        else:
            # No candidate remained after closing the exact child process. Never
            # terminate a guessed PID. The transaction idle timeout is a backstop.
            result["backend_cleanup"] = {"no_holder_candidate": True}
            result["holder_absent"] = self.probe.sql("holder-unready-absent", f"SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = {literal(self.probe.app_name)} AND usename = 'supabase_admin' AND datname = 'postgres'));\n")[0]["absent"]
        return result


def interrupted(_signum, _frame):
    raise Blocked("Probe interrupted; held transaction cleanup will run.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("notes", "lifecycle",))
    parser.add_argument("--session", required=True)
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--seed", required=True)
    parser.add_argument("--request-a", required=True)
    parser.add_argument("--request-b", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--max-hold-seconds", type=int, default=25)
    args = parser.parse_args()
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    probe = Probe.__new__(Probe)
    try:
        probe.__init__(args)
        result = probe.hold()
        probe.save("result.json", result)
        print(json.dumps({**result, "evidence": str(probe.run)}), flush=True)
        return 0
    except BaseException as error:
        failure = {"status": "BLOCKED", **public_error(error)}
        if hasattr(probe, "run"):
            probe.save("failure.json", failure)
            failure["evidence"] = str(probe.run)
        print(json.dumps(failure), flush=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
