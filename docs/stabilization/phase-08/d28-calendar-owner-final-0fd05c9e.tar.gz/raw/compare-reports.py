import pathlib,json,datetime,zipfile,hashlib
r=pathlib.Path(__file__).resolve().parent
load=lambda name:json.loads((r/name).read_text())
a=load('original-availability_entries-orgA.out')['rows'];p=load('original-personnel-orgA.out')['rows'];s=load('original-status_types-orgA.out')['rows'];t=load('original-assignment_types-orgA.out')['rows'];d=load('original-daily_assignments-orgA.out')['rows'];g=load('original-groups-orgA.out')['rows']
p.sort(key=lambda x:x['last_name']);s.sort(key=lambda x:x['sort_order']);date=datetime.date.fromisoformat
count=lambda person,status,start,end:sum(max(0,(min(date(x['end_date']),date(end))-max(date(x['start_date']),date(start))).days+1) for x in a if x['personnel_id']==person and x['status_type_id']==status)
ident=lambda x:[x['rank'],x['last_name'],x['first_name']]
expected={}
expected['status']=[]
for person in p:
 vals=[count(person['id'],x['id'],'2026-01-01','2026-12-31') for x in s];expected['status'].append(ident(person)+[x or None for x in vals]+[sum(vals)])
expected['tempo']=[]
for person in p:
 vals=[count(person['id'],x['id'],'2026-07-08','2026-10-06') for x in s[:2]];total=sum(vals);expected['tempo'].append(ident(person)+vals+[total,round(total/91*100)])
expected['forecast']=[]
for offset in range(31):
 day=date('2026-10-06')+datetime.timedelta(days=offset);away={x['personnel_id'] for x in a if date(x['start_date'])<=day<=date(x['end_date'])};row=[str(day),len(away),len(p)-len(away),str(round((len(p)-len(away))/len(p)*100))+'%']
 if away:row.append(', '.join(x['rank']+' '+x['last_name'] for x in p if x['id'] in away))
 expected['forecast'].append(row)
# Report column order is frozen by actual workbook headers; membership in Personnel-only targets is independent of display order.
actual=load('p06-assignment-workbook.out');types=[next(x for x in t if x['name']==name) for name in actual['headers'][3:-2]];assert all(x['target_type']=='personnel' for x in types)
expected['assignment']=[]
for person in p:
 vals=[sum(x['assignment_type_id']==typ['id'] and x['assignee_id']==person['id'] and '2026-01-01'<=x['date']<='2026-12-31' for x in d) for typ in types];total=sum(vals);expected['assignment'].append(ident(person)+vals+[total,('+' if total>1 else '')+str(total-1)])
expected['assignment'].append([None,None,'Average']+[round(sum(row[3+i] for row in expected['assignment'])/len(p),1) for i in range(len(types))]+[1])
expected['readiness']=[]
for group in sorted(g,key=lambda x:x['name']):
 people=[x for x in p if x['group_id']==group['id']];row=[group['name']]
 for offset in range(7):
  day=date('2026-10-05')+datetime.timedelta(days=offset);away={x['personnel_id'] for x in a if date(x['start_date'])<=day<=date(x['end_date'])};available=sum(x['id'] not in away for x in people);row.append(f'{available}/{len(people)} ({round(available/len(people)*100)}%)')
 expected['readiness'].append(row)
files={'status':'status-days.xlsx','forecast':'availability-forecast.xlsx','tempo':'personnel-tempo.xlsx','assignment':'assignment-coverage.xlsx','readiness':'group-readiness.xlsx'};checks=[]
for key,path in files.items():
 actual=load(f'p06-{key}-workbook.out');f=r/path;z=zipfile.ZipFile(f);checks.append({'report':key,'headers':actual['headers'],'expectedRows':expected[key],'actualRows':actual['rows'],'allCellsEqual':actual['rows']==expected[key],'zipIntegrity':z.testzip(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'foreignIdsAbsent':all(x['id'] not in f.read_bytes().decode('latin1') for x in load('original-personnel-orgB.out')['rows'])})
result={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'derivation':'Original complete provider rows, inclusive independently clipped dates; compare actual native-export workbook cells. Provider readback and workbook extraction are separate from native UI proof.','checks':checks};(r/'report-independent-comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert all(x['allCellsEqual'] and x['zipIntegrity'] is None for x in checks)
