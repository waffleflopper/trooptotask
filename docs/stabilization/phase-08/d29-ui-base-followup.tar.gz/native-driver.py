import json
import os
import re
from pathlib import Path
import subprocess
import sys

label, name, argument = sys.argv[1:]
arguments = json.loads(Path(argument[1:]).read_text() if argument.startswith("@") else argument)
env = dict(os.environ, PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + os.environ['PATH'])
result = subprocess.run(['node', 'scripts/verification/cli.mjs', 'tool', name, json.dumps(arguments), '--worker', '2'], text=True, capture_output=True, env=env)
destination = Path('.verification/evidence/verify-trooptotask/d29-ui-base-followup')
(destination / (label + '.json')).write_text(result.stdout)
with (destination / 'native-actions.ndjson').open('a') as log:
    log.write(json.dumps({'label': label, 'tool': name, 'arguments': arguments, 'exit': result.returncode}) + '\n')
if result.stderr:
    (destination / (label + '.stderr')).write_text(result.stderr)
try:
    data = json.loads(result.stdout)
    for content in data.get('content', []):
        if content.get('type') == 'text':
            value = content['text']
            if os.environ.get('D29_PRINT_MATCH'):
                print('\n'.join(line for line in value.splitlines() if re.search(os.environ['D29_PRINT_MATCH'], line)))
            elif len(value) > 5000:
                print('\n'.join(line for line in value.splitlines() if ' option ' not in line or ' selectable selected ' in line))
            else:
                print(value)
except ValueError:
    print(result.stdout)
sys.exit(result.returncode)
