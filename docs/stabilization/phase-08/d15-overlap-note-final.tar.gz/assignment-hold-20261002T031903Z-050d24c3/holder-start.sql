SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.onboarding_step_progress
WHERE organization_id = 'ffebf369-a1b5-4f7c-8154-6c98ae41927f'::uuid AND id = 'dee9a01a-4baf-438c-9513-90eade784c5c'::uuid AND onboarding_id = 'f6a57232-3999-421e-a72c-b4eef9e7069d'::uuid AND template_step_id IS NULL AND step_name = 'Orientation' AND step_type = 'checkbox' AND completed AND active AND current_stage IS NULL AND training_type_id IS NULL AND stages IS NULL AND notes = '[{"text": "Legacy retained work ff9e0839", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "5b016bf8-21d7-4643-b2e7-64282cb17347"}]'::jsonb
FOR UPDATE;
SELECT json_build_object('event', 'ready');
