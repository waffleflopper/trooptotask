import json,subprocess,sys,time,hashlib
from pathlib import Path
from flow import base,root
label,script=sys.argv[1:];command=['python3',script];start=time.time();p=subprocess.run(command,cwd=root,capture_output=True,text=True)
(base/(label+'.log')).write_text(p.stdout);(base/(label+'.stderr')).write_text(p.stderr)
sources={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in Path('.verification/sds-driver-recovery').glob('*.py')}
(base/(label+'-command.json')).write_text(json.dumps({'command':command,'cwd':str(root),'exit':p.returncode,'durationSeconds':round(time.time()-start,3),'sourceDriverSHA256':sources},indent=2)+'\n')
print(json.dumps({'phase':label,'exit':p.returncode,'stdout':label+'.log','stderr':label+'.stderr'}),flush=True)
if p.returncode:print(p.stderr[-6000:],flush=True)
raise SystemExit(p.returncode)
