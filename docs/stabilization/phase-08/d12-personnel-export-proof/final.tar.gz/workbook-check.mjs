import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import ExcelJS from 'exceljs';
const base=path.resolve('.verification/evidence/verify-trooptotask/personnel-export-final');
const read=async name=>JSON.parse(await fs.readFile(path.join(base,name+'.json'),'utf8'));
const files=[['manager-able','manager-able-save','manager-able-network'],['manager-calendar','manager-calendar-save','manager-calendar-network'],['owner-able','owner-able-save','owner-able-network'],['owner-lifecycle-active','owner-lifecycle-active-save','owner-lifecycle-active-network'],['owner-lifecycle-archived','owner-lifecycle-archived-save','owner-lifecycle-archived-network'],['owner-lifecycle-restored','owner-lifecycle-restored-save','owner-lifecycle-restored-network'],['owner-archives-duplicate','owner-archives-duplicate-save','owner-archives-duplicate-network'],['scoped-able','scoped-able-save','scoped-able-network'],['manager-error-retry','manager-error-retry-save','manager-error-retry-network'],['manager-unassigned','manager-unassigned-save','manager-unassigned-network']];
const sheets=['Personnel Info','Training Records','Counseling Records','Availability History'];
const columns={'Personnel Info':['Field','Value'],'Training Records':['Training Type','Completed Date','Expiration Date','Notes'],'Counseling Records':['Date','Subject','Key Points','Plan of Action','Status','Follow-Up Date','Notes'],'Availability History':['Status','Start Date','End Date']};
const avail=[['Verification Leave','2026-09-14','2026-09-16'],['Verification Leave','2026-03-11','2026-03-11']];
const seedname='MapLifecyclee3a95654';const checks=[];
for(const [label,receipt,network] of files){
 const bytes=await fs.readFile(path.join(base,label+'.xlsx'));const saved=await read(receipt);const actualSha256=createHash('sha256').update(bytes).digest('hex');
 assert.equal(actualSha256,saved.sha256);assert.equal(bytes.byteLength,saved.bytes);assert.equal(saved.mimeType,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
 const calls=(await read(network)).calls;assert.equal(calls.length,1);assert.equal(calls[0].method,'GET');assert.equal(calls[0].status,200);assert.equal(calls[0].contentType,saved.mimeType);
 const wb=new ExcelJS.Workbook();await wb.xlsx.load(bytes);assert.deepEqual(wb.worksheets.map(s=>s.name),sheets);
 const out={};for(const sheet of sheets){const s=wb.getWorksheet(sheet);const count=columns[sheet].length;assert.deepEqual(Array.from({length:count},(_,i)=>s.getRow(1).getCell(i+1).value),columns[sheet]);out[sheet]=Array.from({length:s.rowCount-1},(_,r)=>Array.from({length:count},(_,c)=>s.getRow(r+2).getCell(c+1).value??''));}
 const seed=label.startsWith('owner-lifecycle');const duplicate=label==='owner-archives-duplicate';const unassigned=label==='manager-unassigned';
 const expected=[['Rank','SPC'],['Last Name',seed?seedname:duplicate?'MapDuplicatee3a95654':unassigned?'Unassigned':'Able'],['First Name','Synthetic'],['MOS','68W'],['Duty Role',unassigned?'NCO':'Medic'],['Group',unassigned?'':'Alpha'],['ETS',seed?'2027-05-01':''],['PCS / DEROS',seed?'2027-06-01':''],['Archived At',label==='owner-lifecycle-archived'?'2026-10-01T08:01:53.431+00:00':duplicate?'2026-08-01T12:00:00+00:00':'']];
 assert.deepEqual(out['Personnel Info'],expected);
 assert.deepEqual(out['Training Records'],seed?[['Verification Required Training','2026-09-14','','']]:label==='owner-able'?[['Verification Required Training','2026-09-23','2027-09-23','']]:[]);
 assert.deepEqual(out['Availability History'],['manager-calendar','owner-able'].includes(label)?avail:[]);
 assert.deepEqual(out['Counseling Records'].sort((a,b)=>a[1].localeCompare(b[1])),seed?[['2026-09-14','Active counseling e3a95654','','','draft','',''],['2026-09-14','Archived counseling e3a95654','','','draft','','']]:[]);
 assert.equal(JSON.stringify(out).includes('Active note e3a95654'),false);assert.equal(JSON.stringify(out).includes('Older note e3a95654'),false);
 const expectedFilename=duplicate?'SPC-MapDuplicatee3a95654-records.xlsx':`SPC_${expected[1][1]}_Synthetic-export-2026-10-01.xlsx`;assert.equal(saved.filename,expectedFilename);
 checks.push({file:label+'.xlsx',bytes:bytes.byteLength,sha256:actualSha256,filename:saved.filename,sheets:sheets,independentLiteralContent:true,realResponseStatus:200});
}
const fault=await read('export-fault-state');assert.equal(fault.captured,false);assert.equal((await read('export-fault-network')).calls[0].status,503);
const snap=(await read('export-fault-after')).content[0].text;assert(snap.includes('Unable to export personnel records.'));
assert.equal((await read('manager-error-retry-after')).content[0].text.includes('Unable to export personnel records.'),false);
const result={status:'PASS',checkedWorkbooks:checks.length,workbooks:checks,controlledClientFailure:{status:503,noBlob:true,inlineError:true,retryReal200:true},limits:['Workbook identity is tied through the actual endpoint ID and saved provider Person ID; the workbook contains no Person ID field.','All native fixtures lacked extended info. Conditional extended fields and blank legacy Leader Notes row remain focused test proof.','Client503 does not establish a provider read failure; existing focused source test covers that boundary.']};
await fs.writeFile(path.join(base,'workbook-independent-checks.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,checkedWorkbooks:checks.length}));
