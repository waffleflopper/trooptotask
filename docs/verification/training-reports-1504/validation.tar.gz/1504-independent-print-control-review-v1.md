# Independent source review of the #1504 print control

The original integrated print control has one blocking P2 finding. A directory replacement during the final document check can produce a PASS receipt for a PDF missing from the returned path, or publish into the renamed directory outside the evidence root. Root accepted the finding and owns its reproduction and repair. This report reviews the original committed control only and does not approve an intervening fix.

Runtime support is **UNRUN**. I performed independent read-only source review, with no tests, browser, services, database, connector calls, or nested workers. Root's reported 14 passing tests are not independent execution by this reviewer. No model-diversity or visual-acceptance claim is made.

## Candidate and scope

The reviewed commit is `bf7640d735200b48ccd44bea0b994b1789d30cf9`, the primary-checkout integration of source commit `cfd423c01e254644fb6417bc453914c73cc31d54`. The seven-file patch SHA-256 is `685179765caf28fa927083ec2d22651ab2b0bfa68ac2704416d92431714b9244`. File hashes below come from `git show bf7640d735200b48ccd44bea0b994b1789d30cf9:PATH`, so root's later working-tree repairs are outside this verdict.

| Committed file reviewed | SHA-256 |
| --- | --- |
| `.agents/skills/verify-trooptotask/SKILL.md` | `7b8c727ed99c1b14c7274a388b261d09db5cc065e30f9ad55e7b6ea5065b2869` |
| `.agents/skills/verify-trooptotask/helpers/control.mjs` | `d426c720af9eed040bbd4827352303e471c576792cf5adfecdd7f02a46af1bda` |
| `.agents/skills/verify-trooptotask/helpers/print-observation.mjs` | `05885ab449dc9b15805f159896234890762e2b25770c9e708b675e09a5db0489` |
| `.agents/skills/verify-trooptotask/helpers/print-observation.test.mjs` | `e9a3c9bb5c9ce486d200beae84e7b1a05f4cfa6dd867cc5d891d904c53b2b509` |
| `scripts/verification/daemon.mjs` | `c28b1e68f74fb4481fe80c09f2d31bdd35f59026e36ece87e68bbd6619f72510` |
| `scripts/verification/print-capture.mjs` | `74be75ec557dad6843853e513e4af287a4cab624181d9ca71feb6edc56af7577` |
| `scripts/verification/print-capture.test.mjs` | `81a04376e7de8567e694e511c875789a768e87c05dc928e564e4c2af7489719b` |

Direct and reverse consumers inspected were the daemon's authenticated serialized dispatch and freshness check, the core process-identity/session/candidate helpers, the native browser driver, the control helper's owned-supervisor and evaluate paths, and the installed `chrome-devtools-mcp` browser configuration, native tool schemas, response formatter, and bundled Puppeteer connection/detachment paths. No application/CSS re-review occurred. T3 Claude's concurrent app-print work remains outside this lane.

I read `.verification/1504-print-control-implementation-report.md` and `.verification/1504-print-control-grounding.md` as claims to verify. This report is the only file I wrote in this round.

## P2. Revalidate the published path after the awaited final document check

The finding is in `scripts/verification/print-capture.mjs:309`, `:317`, and `:320`.

The code writes a partial file through an open directory descriptor. It checks that the lexical parent still has the descriptor's device/inode and canonical path at lines 309 through 315. It then awaits `checkDocument()` at line 317. That awaits `page.evaluate`, leaving time for the evidence directory to be renamed and replaced. Publication at line 320 still uses `/proc/self/fd/<parent>` for the old directory. The subsequent check only tests the capture clock. It sets `succeeded = true` and returns `saved: request.target` without checking the final lexical path.

A falsifiable failure sequence follows directly from the source:

1. Capture reaches the final document check after creating its `.part` file and validating the parent.
2. During that check's awaited `page.evaluate`, rename the evidence directory and create a new directory at its former path. Preserve the page's URL, readiness, and time origin.
3. `checkDocument()` succeeds. `fs.link` publishes `brief.pdf` in the renamed original directory through the pinned descriptor.
4. Capture returns PASS with the old lexical `saved` path. That path now points at the replacement directory, which has no PDF. Moving the original directory outside the evidence root also makes the accepted PDF reside outside the admitted destination.

The descriptor correctly prevents following a replacement final-directory symlink. It cannot by itself establish that the descriptor still names the returned path. Because `succeeded` is already true, the failure cleanup does not remove this accepted but misplaced published link.

The minimal correction is to revalidate canonical parent path/device/inode after the awaited document check, then verify the accepted final path and its identity after publication before setting `succeeded`. On mismatch, reject with `PRINT_PATH` and remove only the operation-owned link through the pinned descriptor. Keep no-overwrite hard-link publication and inode comparison for cleanup.

Add a controlled test that renames/recreates the evidence directory during the last document observation while returning the unchanged document. It must reject, leave no operation-owned partial or PDF in the renamed directory, and preserve a literal unrelated file in the replacement directory. This checks the filesystem effect rather than merely counting a validation call. Root will reproduce and patch this independently. I did not execute this reproduction.

## Other source conclusions

| Boundary | Source assessment of the original commit |
| --- | --- |
| Public inputs | `print-capture.mjs:15` admits only command/page ID/exact URL/output path. It rejects extra protocol, script, media, or format inputs. Positive safe-integer native IDs, owned origin, no credentials/hash, the Training report path, and canonical existing query keys are enforced. Singular `role` and repeated `mos` are supported. |
| Daemon admission | `daemon.mjs:260` retains the authenticated loopback POST boundary and rejects Origin headers. Commands remain serialized. `fresh()` at line 282 checks candidate/copied source/build/provider before print dispatch at line 332. The helper checks repository/worker/running phase and supervisor identity before using that authenticated channel. |
| Process/profile ownership | `ownedPrintEndpoint` at `print-capture.mjs:48` compares current PID/start/full command for supervisor, MCP, and browser, rejecting replaced/zombie identities. It requires one exact private profile argument, the port argument, no pipe argument, and canonical profile identity. Commands are not returned in receipts. |
| Debug endpoint ownership | The endpoint is derived from a small regular non-symlink `DevToolsActivePort`, validates its port and browser UUID path, and stays on 127.0.0.1. `/proc` descriptor socket inodes must match one IPv4-loopback LISTEN row for the port, with no competing IPv6/listener row. The caller cannot supply an endpoint. Real launch/socket behavior remains unrun. |
| Native target mapping | `nativePage` at line 146 uses `structuredContent.pages`, requiring exactly one full-URL match with the requested native ID. It does not use selected-page state, title parsing, array indexes, or a native ID as a CDP target ID. A temporary connection also requires exactly one open page at the exact full URL. |
| Document lifetime | The native observation and temporary page observation compare exact URL, complete ready state, and finite `performance.timeOrigin`. Main-frame navigation and closure abort capture. Same-URL reloads, closed/signed-out/mismatched documents, and a second exact-URL page are rejected by event and final observation checks. This establishes document identity by source; it does not independently prove Training feature permission or content. |
| Fixed rendering | Font readiness, `Page.printToPDF`, background printing, CSS page size, no headers/footers, stream reads, and stream closure are internal fixed operations. Capture does not navigate or install persistent media emulation. It prints the loaded document. |
| Deadline and output size | One clock bounds protocol work and fonts at 20 seconds. Stream bytes are capped at 20 MiB and checked for PDF header/EOF. Timeout races cannot resume the main capture continuation and publish a late response. Local filesystem awaits use deadline checks rather than independently cancellable metadata calls; this is not proof of a wall-clock bound for a hung filesystem. |
| Temporary clients | Late connection and CDP attachment settlements have disconnect/detach handlers. Normal and failed capture closes a known stream, detaches only the temporary CDP session, and disconnects only the temporary Puppeteer client with a two-second protocol cleanup bound. No capture path calls page/browser close or signals a process. Native-client continuity and actual Chromium stream lifetime still require runtime proof. |
| Output restrictions | Static traversal, existing output, and symlink directories are rejected. Exclusive mode-0600 partial files and no-overwrite hard-link publication protect preexisting artifacts. Failure cleanup compares output/partial device/inode before unlinking an unaccepted published file. The directory replacement race above is the remaining accepted-output defect. |
| Print observer | `print-observation.mjs` installs/removes only private beforeprint/afterprint listeners and returns their counters. It neither assigns nor invokes `window.print`. Helper actions are fixed to arm/state/restore. The docs correctly require native button-click evidence and event state before PDF capture, because capture can itself produce print events. |
| Failure reporting | The daemon returns a sanitized INCONCLUSIVE result on a failed capture. It does not turn command failure into feature acceptance. A successful capture receipt contains the page/URL/candidate/session/path/byte count/hash, rather than private endpoint or process commands. |

## Installed native transport and response schema

The installed package is `chrome-devtools-mcp` 1.10.1. This conclusion comes from its local package and source, not a live tool call.

The port-transport proposal is supported by the installed source:

- `config/browser-options.js:111` declares `chromeArg` as a string array. The MCP parser uses dashed-name normalization at `config/mcp-options.js:280`.
- `BrowserManager.js:192` forwards that array into Puppeteer launch even while passing `pipe: true` at line 220.
- Bundled Puppeteer at `third_party/index.js:91629` adds its pipe argument only when no caller argument begins with `--remote-debugging-`. The supplied port argument therefore prevents the pipe argument.
- Launch chooses the actual transport from presence of `--remote-debugging-pipe` at line 91317 and uses its socket branch at line 91375 when absent. This is the same native-owned browser launch, not a second browser.

The response assumptions also match installed source:

- `tools/pages.js:11` defines `list_pages` and requests page output. `McpResponse.js:638` returns `structuredContent.pages`.
- `McpResponse.js:1072` creates page records containing numeric native ID, URL, title, selected state, and optional isolated context.
- `tools/script.js:70` defines the evaluation inputs, including page ID in the page-routing schema and `waitForStableDom`. Its fixed evaluation output is JSON fenced text at line 193.
- `McpResponse.js:543` copies that same text into `structuredContent.message`, which the capture parses. The legacy text-content fallback is also compatible.
- Bundled `CDPSession.detach` sends `Target.detachFromTarget` at `third_party/index.js:75428`. `browser.disconnect` disposes the temporary connection at line 84086. Those differ from browser close at line 84082.

These are static support conclusions. Actual argument parsing/launch, native routing, profile/listener ownership, page enumeration across isolated contexts, capture rendering, and native controls after detachment are **UNRUN** in this lane.

## Test adequacy

The existing tests use controlled protocol/document dependencies and actual filesystem effects. Their accepted case compares literal saved bytes, a literal byte count/hash, and the output directory. Rejection cases preserve existing bytes, prevent output on traversal/symlink/ID/URL/duplicate/ownership failures, reject oversized/incomplete output, and prevent publication after a timed-out read later settles. The partial-file test changes the document after temporary output is created and asserts no output remains. `/proc` fixtures exercise the real ownership parser against current/replaced identities and known socket tables.

The observer tests dispatch actual EventTarget events and assert literal counts, detached-listener behavior, successful re-arm, and an unchanged print function that would throw if invoked. These protect the stated observer behavior without requiring a system print dialog.

Resource flags and listener assertions complement artifact effects. They cannot establish real Chromium cleanup or rendered PDF correctness. The PDF fixture is controlled bytes, not a Chromium-generated PDF. The original suite has no directory-replacement-during-final-observation test, which is why its existing passing result does not catch the P2 finding. No appearance, geometry, or implementation-source scanner test was introduced.

## Remaining evidence

The source verdict for this original commit is **changes required** until the P2 path-publication defect is repaired and independently reviewed. Root owns the controlled regression proof, focused checks, and a distinct review of its fix.

Runtime support remains **UNRUN**. Required live proof includes a fresh owned worker launched with the real port transport, actual native ID/URL mapping, a protected report capture with literal filters/counts, positive and rejected target cases, native controls continuing after temporary-client detachment, and pre-capture Print brief click/event evidence. A known fixture with print-only and screen-only literal text can distinguish actual print rendering from screen output. T3 Claude owns app print appearance and CSS acceptance.

This review adds no merge, deployment, publication, or database authority. Boundary Discipline kept endpoint/script/media inputs fixed and ownership conclusions separate from feature-permission claims. Test Behavior, Not Implementation selected saved bytes, retained files, and controlled rejection effects. No nested comment-specialist or additional model review was run under the parent's explicit no-spawn boundary.
