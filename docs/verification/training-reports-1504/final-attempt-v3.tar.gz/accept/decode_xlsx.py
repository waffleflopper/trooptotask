import zipfile, re, sys, hashlib, json, xml.etree.ElementTree as ET
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
def decode(p):
    z=zipfile.ZipFile(p); out={'file':p,'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'bytes':len(open(p,'rb').read())}
    wb=ET.fromstring(z.read('xl/workbook.xml')); rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    rmap={r.get('Id'):r.get('Target') for r in rels}
    ss=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS): ss.append(''.join(t.text or '' for t in si.iter('{%s}t'%NS['m'])))
    sheets={}
    for s in wb.find('m:sheets',NS):
        tgt=rmap[s.get('{%s}id'%NS['r'])].lstrip('/'); tgt=tgt if tgt.startswith('xl/') else 'xl/'+tgt
        rows=[]
        for row in ET.fromstring(z.read(tgt)).iter('{%s}row'%NS['m']):
            vals={}
            for c in row.findall('m:c',NS):
                col=re.match(r'[A-Z]+',c.get('r')).group(); t=c.get('t'); v=c.find('m:v',NS); isn=c.find('m:is',NS)
                if t=='s': val=ss[int(v.text)]
                elif t=='inlineStr': val=''.join(x.text or '' for x in isn.iter('{%s}t'%NS['m']))
                else: val=v.text if v is not None else None
                vals[col]=val
            rows.append(vals)
        sheets[s.get('name')]=rows
    out['sheets']=sheets; return out
print(json.dumps([decode(p) for p in sys.argv[1:]],indent=1))
