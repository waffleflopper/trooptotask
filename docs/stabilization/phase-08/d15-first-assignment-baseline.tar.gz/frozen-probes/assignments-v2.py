from drive import *
import hashlib,concurrent.futures,threading,queue
probe=ROOT/'.verification/tmp/d15-concurrency/provider-hold-v2.py'
expected='170a88d9b60f689dd54d9db3b10632a83a8ddc795cf602f82ecd174d8e861576'
assert hashlib.sha256(probe.read_bytes()).hexdigest()==expected
(E/'frozen-probes/provider-hold-v2.py').write_bytes(probe.read_bytes())
private='/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1'
launch=json.loads((E/'launch.json').read_text()); packet=json.loads((E/'legacy-seed.json').read_text())['packets'][0]['id']
for table in ['personnel_onboardings','onboarding_step_progress']: control(['rows',table,'orgA','id' if table=='personnel_onboardings' else 'onboarding_id',packet],'before-overlap-v2-'+table)
hold=['python3',str(probe),'hold','--session',private,'--session-id',launch['session'],'--seed',str(E/'legacy-seed.json'),'--request-a',str(E/'request-a.json'),'--request-b',str(E/'request-b.json'),'--evidence',str(E),'--max-hold-seconds','25']
commands={letter:['node','.verification/tmp/d15-packets/owned-onboarding-http.mjs',role,'orgA','POST','onboarding-resync',str(E/('request-'+letter.lower()+'.json'))] for letter,role in [('A','onboardingConfigure'),('B','onboardingSwitch')]}
(E/'overlap-v2-command-plan.json').write_text(json.dumps({'hold':hold,'requests':commands},indent=2)+'\n')
h=subprocess.Popen(hold,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
lines=queue.Queue()
def collect():
 for line in h.stdout: lines.put(line)
 lines.put(None)
threading.Thread(target=collect,daemon=True).start()
output=[]; stderr=None
try:
 line=lines.get(timeout=30); assert line is not None
 output.append(line); ready=json.loads(line); assert ready['status']=='HOLDING',ready
 (E/'holder-v2-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
 def request(item):
  letter,cmd=item; r=subprocess.run(cmd,text=True,capture_output=True,timeout=65)
  (E/('assignment-v2-'+letter+'.json')).write_text(r.stdout); (E/('assignment-v2-'+letter+'-stderr.log')).write_text(r.stderr)
  return {'letter':letter,'exit':r.returncode,'status':json.loads(r.stdout)['status'] if r.returncode==0 else None}
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: responses=list(pool.map(request,commands.items()))
 h.wait(timeout=25)
 while True:
  line=lines.get(timeout=5)
  if line is None: break
  output.append(line)
 stderr=h.stderr.read()
 (E/'assignment-v2-v2-statuses.json').write_text(json.dumps({'requests':responses,'holderExit':h.returncode},indent=2)+'\n')
 print(responses,'holderExit',h.returncode)
finally:
 if h.poll() is None: h.terminate(); h.wait(timeout=25)
 if stderr is None: stderr=h.stderr.read()
 (E/'holder-v2-stdout.log').write_text(''.join(output)); (E/'holder-v2-stderr.log').write_text(stderr)
parent=control(['rows','personnel_onboardings','orgA','id',packet],'after-overlap-v2-parent')['rows'][0]
progress=control(['rows','onboarding_step_progress','orgA','onboarding_id',packet],'after-overlap-v2-progress')['rows']
defs=sum([json.loads((E/('prepared-definitions-'+letter+'.json')).read_text())['rows'] for letter in ['A','B']],[])
owners={row['id']:row['templateId'] for row in defs} if defs and 'templateId' in defs[0] else {row['id']:row['template_id'] for row in defs}
active=[row for row in progress if row['active']]
foreign=[row['id'] for row in active if row['template_step_id'] is not None and owners[row['template_step_id']]!=parent['template_id']]
old=json.loads((E/'before-overlap-v2-onboarding_step_progress.json').read_text())['rows']; after={r['id']:r for r in progress}
work=['completed','current_stage','notes']
result={'observation':'FAIL' if foreign else 'NO_MIXED_ACTIVE_STEPS','selectedTemplate':parent['template_id'],'savedRows':len(progress),'activeRows':len(active),'activeRowsFromOtherTemplate':foreign,'originalWorkAndNotesRetained':all(r['id'] in after and all(r.get(k)==after[r['id']].get(k) for k in work) for r in old),'orderingAssumed':False}
(E/'overlap-v2-result.json').write_text(json.dumps(result,indent=2)+'\n'); print(result)
