import datetime,json,pathlib,socket,subprocess,hashlib,re
p=pathlib.Path(__file__).resolve().parent
root=p.parents[3]
def read(n): return json.loads((p/n).read_text())
def run(args):
 q=subprocess.run(args,text=True,capture_output=True,check=True)
 return q.stdout.strip()
def dump(n,x): (p/n).write_text(json.dumps(x,indent=2)+'\n')
own=read('owned-environment-identity.json'); session=read('owned-session-identity.json'); pre=read('resources-before.json'); proc=read('owned-process-identities-preclosure.json'); mounts=read('owned-container-mount-network-identities.json')
ids=run(['docker','ps','-aq','--no-trunc']).splitlines()
containers=[]
if ids:
 for line in run(['docker','inspect','--format','{{json .Id}} {{json .Name}} {{json .State.Status}}',*ids]).splitlines():
  vals=re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"',line)
  containers.append({'id':vals[0],'name':vals[1].lstrip('/'),'state':vals[2]})
networks=[json.loads(x) for x in run(['docker','network','ls','--no-trunc','--format','{{json .}}']).splitlines()]
volumes=[json.loads(x) for x in run(['docker','volume','ls','--format','{{json .}}']).splitlines()]
dump('recovery-resources-after.json',{'containers':containers,'networks':networks,'volumes':volumes})
checks=[]
for old in proc['processes']:
 path=pathlib.Path('/proc')/str(old['pid'])/'stat'
 exists=path.exists()
 actualStart=None
 if exists:
  stat=path.read_text(); actualStart=stat[stat.rfind(')')+2:].split()[19]
 checks.append({'pid':old['pid'],'originalStart':old['start'],'present':exists,'actualStart':actualStart,'originalProcessAbsent':not exists or actualStart!=old['start']})
ports=[*own['ports'].values(),int(session['origin'].rsplit(':',1)[1]),session['controlPort']]
portchecks=[]
for port in ports:
 with socket.socket() as s:
  s.settimeout(.3)
  result=s.connect_ex(('127.0.0.1',port))
 portchecks.append({'port':port,'connectResult':result,'refused':result==111})
ownednames=[x['name'].lstrip('/') for x in mounts]
ownednet={k for x in mounts for k in x['networks']}
ownedvol={m['Name'] for x in mounts for m in x['mounts'] if m['Type']=='volume'}
currentBy={x['id']:x for x in containers}
prechecks=[{'id':x['id'],'name':x['name'],'state':x['state'],'exact':currentBy.get(x['id'])==x} for x in pre['containers']]
netBy={x['ID']:x for x in networks}; volBy={x['Name']:x for x in volumes}
networkPreservation=[{'id':x['ID'],'name':x['Name'],'exact':netBy.get(x['ID'])==x} for x in pre['networks']]
volumePreservation=[{'name':x['Name'],'exact':volBy.get(x['Name'])==x} for x in pre['volumes']]
closure={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supportedCleanup':read('cleanup-final.json'),'processes':checks,'ports':portchecks,'ownedContainersAbsent':all(x not in currentBy for x in own['container_ids']),'ownedContainerNamesAbsent':all(x not in [c['name'] for c in containers] for x in ownednames),'ownedNetworksAbsent':all(x not in [n['Name'] for n in networks] for x in ownednet),'ownedVolumesAbsent':all(x not in volBy for x in ownedvol),'ownedWorkerDirectoryAbsent':not pathlib.Path(own['session']).exists(),'ownedTmpPathsAbsent':all(not pathlib.Path(x.removesuffix(' (deleted)')).exists() for x in proc['openTmpPaths']),'preexistingContainers':prechecks,'preexistingNetworks':networkPreservation,'preexistingVolumes':volumePreservation}
closure['PASS']=all(x['originalProcessAbsent'] for x in checks) and all(x['refused'] for x in portchecks) and all(closure[k] for k in ['ownedContainersAbsent','ownedContainerNamesAbsent','ownedNetworksAbsent','ownedVolumesAbsent','ownedWorkerDirectoryAbsent','ownedTmpPathsAbsent']) and all(x['exact'] for x in prechecks+networkPreservation+volumePreservation)
dump('recovery-actual-closure.json',closure)
f=read('freeze-before.json')
changed=[n for n,h in f['files'].items() if not (root/n).is_file() or hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
freeze={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changedTrackedFiles':changed,'fileCount':len(f['files']),'head':run(['git','-C',str(root),'rev-parse','HEAD']),'tree':run(['git','-C',str(root),'rev-parse','HEAD^{tree}']),'status':run(['git','-C',str(root),'status','--short'])}
freeze['PASS']=not changed and freeze['head']==f['head'] and freeze['tree']==f['tree'] and freeze['status']==f['status']
dump('recovery-freeze-confirmation.json',freeze)
patterns={'jwt':rb'eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}','secret_key':rb'(?:sb_secret_|sk_live_)[A-Za-z0-9_-]{12,}','private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'}
hits=[]
for path in p.rglob('*'):
 if path.is_file() and path.name!='recovery-privacy-scan.json':
  data=path.read_bytes()
  for name,pattern in patterns.items():
   matches=list(re.finditer(pattern,data))
   if matches: hits.append({'path':str(path.relative_to(p)),'kind':name,'count':len(matches)})
privacy={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorExactPrivateValueScan':read('privacy-preclosure.json'),'patterns':list(patterns),'hits':hits,'PASS':not hits and read('privacy-preclosure.json')['PASS'],'limit':'Pattern scan of current raw captures and inherited six-value exact scan before owned private configuration was removed. No claim about historical tool transcripts.'}
dump('recovery-privacy-scan.json',privacy)
print(json.dumps({'closurePASS':closure['PASS'],'processes':len(checks),'ports':len(portchecks),'containers':len(own['container_ids']),'networks':len(ownednet),'volumes':len(ownedvol),'preexistingCounts':[len(prechecks),len(networkPreservation),len(volumePreservation)],'freezePASS':freeze['PASS'],'privacyPASS':privacy['PASS'],'privacyHits':hits}))
