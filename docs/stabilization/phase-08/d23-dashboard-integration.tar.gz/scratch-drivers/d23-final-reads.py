import importlib.util,json,subprocess
from pathlib import Path
spec=importlib.util.spec_from_file_location('capture','.verification/tmp/d23-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.call('helper','seed',['dashboard-currency'],'seed-currency.json')
m.capture(2,'large-full')
for label,role in [('scoped','dashboardScoped'),('empty','dashboardEmpty'),('none','dashboardNone'),('foreign','dashboardForeign')]:
 a=m.call('helper','actor',[role,'home'],'actor-'+label+'.json');m.capture(a['pageId'],label)
 if label=='foreign':
  fixture=json.load(open(m.out/'fixture.json'))
  target='/org/'+fixture['ids']['orgA']+'/__data.json'
  fn=Path('.verification/tmp/d23-readfn.txt').read_text().replace("location.pathname + '/__data.json'",json.dumps(target))
  m.native('evaluate_script',{'pageId':a['pageId'],'function':fn,'filePath':str(m.out/'foreign-A-page-data.json'),'waitForStableDom':False},'foreign-A-page-data-action.json')
  subprocess.run(['mise','exec','node@24','--','node','.verification/tmp/d23-projection-decode.mjs','foreign-A-page-data.json',m.run],check=True,capture_output=True,text=True)
print('Larger currency, scoped/empty/no-lane/foreign reads captured',flush=True)
