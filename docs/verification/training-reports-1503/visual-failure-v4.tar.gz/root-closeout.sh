#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH
export TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp
export NODE_DISABLE_COMPILE_CACHE=1
run_dir=.verification/evidence/verify-trooptotask/1503-final-chart-v4
control=.agents/skills/verify-trooptotask/helpers/control.mjs
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v4')
r=json.loads((p/'root-doctor-closeout.json').read_text())
assert r['status']=='PASS'
assert r['candidate']=='361e8c6fe26f3f0862062fa3e26b6a541b0e737f780b1ccf804a95532d8a64bd'
assert r['session']=='b78667b7-2c94-4692-a547-d5b1521bd7ed'
PY
node "$control" --worker 1 rows organizations orgA > "$run_dir/root-organizations-orgA-restored.json"
node "$control" --worker 1 rows organizations orgB > "$run_dir/root-organizations-orgB-restored.json"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v4')
for org in ['orgA','orgB']:
 a=json.loads((p/f'root-organizations-{org}-original.json').read_text())
 b=json.loads((p/f'root-organizations-{org}-restored.json').read_text())
 assert a==b,org
 assert b['rows'][0]['training_readiness_goal_percent']==90
PY
node "$control" --worker 1 clean-seeds > "$run_dir/root-clean-seeds.json"
node .verification/1503-boundary-seed.mjs readback 1 > "$run_dir/root-seed-absence.json"
node "$control" --worker 1 rows personnel_trainings orgA > "$run_dir/root-personnel_trainings-orgA-restored.json"
node "$control" --worker 1 rows personnel_trainings orgB > "$run_dir/root-personnel_trainings-orgB-restored.json"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v4')
r=json.loads((p/'root-seed-absence.json').read_text())
assert set(r['observed'])=={'personnel','training_types','training_views','personnel_trainings'}
assert all(v==[] for v in r['observed'].values())
for org in ['orgA','orgB']:
 assert json.loads((p/f'root-personnel_trainings-{org}-original.json').read_text())==json.loads((p/f'root-personnel_trainings-{org}-restored.json').read_text()),org
r={'status':'PASS','proof':'Root owned provider readback after journal-bound cleanup','exactSeedIdsAbsent':True,'originalTrainingAndOrganizationRowsEqual':True,'goals':{'orgA':90,'orgB':90}}
(p/'root-restoration-audit.json').write_text(json.dumps(r,indent=2)+'\n')
PY
npm run --silent verify:app -- doctor --worker 1 > "$run_dir/root-doctor-after-seeds.json"
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('.verification/evidence/verify-trooptotask/1503-final-chart-v4/root-doctor-after-seeds.json').read_text())
assert r['status']=='PASS'
PY
npm run --silent verify:app -- cleanup --worker 1 > "$run_dir/root-owned-cleanup.json"
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('.verification/evidence/verify-trooptotask/1503-final-chart-v4/root-owned-cleanup.json').read_text())
assert r['status']=='PASS' and r['phase']=='cleaned'
print('Root restoration, exact seed absence, doctor and owned cleanup PASS.')
PY
