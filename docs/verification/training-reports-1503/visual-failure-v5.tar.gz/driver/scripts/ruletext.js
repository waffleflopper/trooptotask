window.__rt = () => {
	const svg = document.querySelector('[data-testid="training-briefing-forecast"] svg');
	const rule = svg.querySelector('.stroke-success');
	const rr = rule.getBoundingClientRect();
	const y = (rr.top + rr.bottom) / 2;
	const hits = [];
	for (const t of svg.querySelectorAll('text')) {
		const b = t.getBoundingClientRect();
		const ink = { t: b.top + b.height * 0.2, b: b.bottom - b.height * 0.2 };
		if (b.right > rr.left && b.left < rr.right && y > ink.t && y < ink.b) hits.push({ text: t.textContent.trim(), top: +b.top.toFixed(1), bottom: +b.bottom.toFixed(1), ruleY: +y.toFixed(1), fill: getComputedStyle(t).fill });
	}
	return hits;
};
