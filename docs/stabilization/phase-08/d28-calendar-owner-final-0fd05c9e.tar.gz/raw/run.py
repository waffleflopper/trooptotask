import sys,json,os,subprocess,datetime,pathlib,hashlib
root=pathlib.Path(__file__).resolve().parent
label,kind,*args=sys.argv[1:]
env=os.environ.copy();env['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+env['PATH'];env['TMPDIR']=json.loads((root/'tmp-binding.json').read_text())['path'];assert len(os.fsencode(env['TMPDIR']))<40;assert pathlib.Path(env['TMPDIR']).is_dir()
cmd={'v':['npm','run','--silent','verify:app','--','--worker','1'],'h':['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1'],'exec':[]}[kind]+args
out=root/(label+'.out');err=root/(label+'.err');assert not out.exists(),str(out)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def log(x):
 with (root/'journal.jsonl').open('a') as f:f.write(json.dumps(x)+'\n')
log({'event':'dispatch','timestamp':now(),'label':label,'kind':kind,'command':cmd,'cwd':os.getcwd(),'nodePathFirst':env['PATH'].split(':')[0],'TMPDIR':env['TMPDIR'],'driverOrder':'serial'})
with out.open('w') as o,err.open('w') as e:
 r=subprocess.run(cmd,env=env,stdout=o,stderr=e)
log({'event':'completion','timestamp':now(),'label':label,'exit':r.returncode,'stdout':out.name,'stderr':err.name,'stdoutBytes':out.stat().st_size,'stderrBytes':err.stat().st_size})
print(json.dumps({'label':label,'exit':r.returncode,'stdout':out.name,'stderr':err.name}));print(out.read_text());print(err.read_text(),file=sys.stderr)
sys.exit(r.returncode)
