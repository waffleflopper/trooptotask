from drive import *
for page,actor in [(3,'manager'),(4,'personnelScoped')]:
    native('navigate_page',{'pageId':page,'type':'reload'},'dashboard-'+actor+'-reload')
    text=snap(page,'dashboard-'+actor+'-reloaded')
    assert 'MapLegacy0b7658e1' in text and '67%' in text
    assert ('SPC Unassigned, Synthetic' in text)==(actor=='manager')
    screen(page,'dashboard-'+actor+'-reloaded')
for org in ['orgA','orgB']:
    for table in ['personnel_onboardings','onboarding_step_progress']:
        control(['rows',table,org],'dashboard-before-clean-'+org+'-'+table)
control(['clean-seeds'],'dashboard-clean-seeds')
for page,actor in [(3,'manager'),(4,'personnelScoped')]:
    native('navigate_page',{'pageId':page,'type':'reload'},'dashboard-'+actor+'-clean-reload')
    text=snap(page,'dashboard-'+actor+'-clean')
    assert 'MapLegacy0b7658e1' not in text and 'SPC Unassigned, Synthetic' not in text
    screen(page,'dashboard-'+actor+'-clean')
for org in ['orgA','orgB']:
    for table in ['personnel_onboardings','onboarding_step_progress','onboarding_templates','onboarding_steps']:
        control(['rows',table,org],'final-restored-'+org+'-'+table)
control(['doctor'],'final-doctor')
print('Dashboard reload, seed cleanup, final readbacks and doctor completed')
