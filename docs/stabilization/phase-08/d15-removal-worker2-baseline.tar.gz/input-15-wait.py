"""Fixed worker-2 ordinary RPC/DELETE interleaving; no native/app state mutation."""
import argparse
import json
from pathlib import Path
import queue
import signal
import subprocess
import threading
import time
from drive import ROOT, E, app, control, save


def main(page, seed, prepared):
    actor = json.loads((E / "configure-actor-stdout.json").read_text())
    assert actor["role"] == "onboardingConfigure" and page == actor["pageId"]
    assert seed == E / "wait-seed-stdout.json"
    assert seed.resolve() == seed and prepared.resolve() == prepared and prepared.is_relative_to(E)
    capture = json.loads(prepared.read_text())
    original = json.loads(seed.read_text())
    target = next(row for row in original["progress"] if row["step_name"] == "Paperwork")
    saved = next(row for row in capture["snapshot"]["progress"] if row["id"] == target["id"])
    definition = next(row for row in capture["snapshot"]["definitions"] if row["id"] == saved["template_step_id"])
    bodies = [{"onboardingId": original["packets"][0]["id"], "newTemplateId": definition["template_id"]},
              {"id": target["id"]}]
    body_files = [save("wait-reconcile-body.json", bodies[0]), save("wait-delete-body.json", bodies[1])]
    doctor = app("doctor", "wait-doctor")
    command = ["python3", ".agents/skills/verify-trooptotask/helpers/onboarding-removal-provider.py", "wait",
               "--worker", "2", "--session-id", doctor["session"], "--seed", str(seed), "--prepared", str(prepared),
               "--reconcile-body", str(body_files[0]), "--delete-body", str(body_files[1]), "--evidence", str(E)]
    save("wait-probe-input.json", {"command": command, "worker": "2", "pageId": page,
                                 "requests": bodies, "navigationForbiddenUntilDrained": True})
    output, events = [], queue.Queue()
    process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def read_stdout():
        for line in process.stdout:
            output.append(line)
            events.put(json.loads(line))
        events.put(None)

    threading.Thread(target=read_stdout, daemon=True).start()

    def await_event(status, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            event = events.get(timeout=max(0.01, deadline - time.monotonic()))
            assert event is not None, "Provider probe ended before required observation"
            if event.get("status") == status:
                save("wait-" + status.lower() + ".json", event)
                return event
            assert event.get("status") not in ("BLOCKED", "FAIL"), "Provider observation unavailable"
        raise RuntimeError("Provider checkpoint unavailable")

    started, states = [], []
    try:
        await_event("HOLDING", 90)
        started.append(control(["onboarding-request", str(page), "orgA", "POST", "onboarding-resync",
                                json.dumps(bodies[0]), "start"], "wait-start-reconcile"))
        await_event("RECONCILIATION_WAITING", 30)
        started.append(control(["onboarding-request", str(page), "orgA", "DELETE", "onboarding-steps",
                                json.dumps(bodies[1]), "start"], "wait-start-delete"))
        await_event("ORDERED_WRITERS_OBSERVED_AND_RELEASED", 40)
        process.wait(timeout=20)
        assert process.returncode == 0, "Probe failed after release"
    finally:
        if process.poll() is None:
            process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                save("wait-cleanup-unavailable.json", {"probeProcessStillRunning": True,
                     "appOutcome": "INCONCLUSIVE", "driverMustInspectExactHolderCleanup": True})
        save("wait-probe-stdout.jsonl", "".join(output))
        if process.poll() is not None:
            save("wait-probe-stderr.log", process.stderr.read())
        # Even an unavailable interleaving must settle its already-started app work.
        if started:
            deadline = time.monotonic() + 120
            index = 0
            while time.monotonic() < deadline:
                state = control(["onboarding-request-state", str(page)], "wait-state-" + str(index).zfill(3))
                states = state["requests"]
                assert len(states) == len(started), "Request capture vanished; no navigation/cancellation credit"
                if all(record["state"] != "pending" for record in states):
                    break
                index += 1
                time.sleep(0.25)
            save("wait-drained-outcomes.json", {"requests": states,
                 "allSettled": bool(states) and all(record["state"] != "pending" for record in states),
                 "completeHttpBodies": bool(states) and all(record["state"] == "completed" for record in states)})
            assert states and all(record["state"] != "pending" for record in states), "Pending requests remain; no reload/cleanup"
            control(["onboarding-request-restore", str(page)], "wait-request-restore")
    assert all(record["state"] == "completed" for record in states), "Transport/body gap retained; no HTTP acceptance"
    print(json.dumps({"status": "OUTCOMES_RECORDED", "appVerdict": "unestablished",
                      "responses": [record["response"] for record in states]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--page", type=int, required=True)
    parser.add_argument("--seed", type=Path, required=True)
    parser.add_argument("--prepared", type=Path, required=True)
    args = parser.parse_args()
    main(args.page, args.seed, args.prepared)
