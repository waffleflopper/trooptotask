SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 1404 AND backend_start = '2026-10-02 03:06:19.016833+00'::timestamptz AND application_name = 't2t-d15-overlap-df6e2471443e49aba1430147eb4a66ad' AND usename = 'supabase_admin' AND datname = 'postgres';
