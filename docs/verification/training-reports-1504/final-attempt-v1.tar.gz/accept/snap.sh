#!/usr/bin/env bash
# usage: snap.sh NAME [PAGE]  -> saves snapshot to $E/NAME.txt and prints path
E=.verification/evidence/verify-trooptotask/1504-final-v1/accept
P=${2:-2}
MAXOUT=0 $E/t.sh "snap-$1" "snapshot $1" take_snapshot "{\"pageId\":$P,\"filePath\":\"$E/$1.txt\"}" >/dev/null
echo $E/$1.txt
