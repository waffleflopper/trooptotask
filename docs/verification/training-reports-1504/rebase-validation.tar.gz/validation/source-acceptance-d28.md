# D28 source acceptance for the second PR #1511 integration round

PASS for source preservation and composition at `f7d83ccc80238e83b29b1b513e3296b2b44a75e6` on main `51e4a9eb78ac4541b1a323dfbceeb9f3f36523cc`. No supported lost behavior, authorization regression, persistence regression, or additional request waterfall was found in the reviewed integration delta. This is source acceptance only. Current-head required checks and fresh native follow-up remain separate gates.

The reviewer inspected the new main delta, the complete current-main-to-candidate path inventory, immutable git objects, shared integration files, owner/provider code, direct and reverse consumers, and meaningful test contracts. The reviewer made no source edits, commits, service starts, test runs, database calls, or browser actions. The only new write is this exclusive report. Independent reasoning does not establish independent execution or model diversity.

## Pins and preservation census

| Input | Commit |
| --- | --- |
| Old PR base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Old PR head | `f5221ecdcf0dde3be595bccdaaa8f898b7153ca3` |
| First integration main | `66a238a8fe9915f5dd3994a7d5d62f71c71f7de8` |
| Accepted first-round test successor | `4389400634aadedfe0fc4f1909ae01323cd5b80a` |
| Current main with completion persistence | `51e4a9eb78ac4541b1a323dfbceeb9f3f36523cc` |
| Reviewed second-round candidate | `f7d83ccc80238e83b29b1b513e3296b2b44a75e6` |

[d28-range-diff.txt](d28-range-diff.txt) has 20 equal replay entries. Independent tree comparison agrees with [reconciliation-d28.json](reconciliation-d28.json):

| Census | Paths |
| --- | ---: |
| Old PR changes against its base | 150 |
| Current main changes against that base | 459 |
| Combined input inventory | 591 |
| Shared input paths | 18 |
| PR-only paths, all identical old-to-candidate | 132 |
| Main-only paths | 441 |
| Main-only paths identical main-to-candidate | 440 |
| Intended main-only Training context adaptation | 1 |
| Explicit previously accepted MFA test repair outside the input inventory | 1 |
| Current candidate diff against current main | 151 |

The only main-only adaptation is `src/lib/server/adapters/featureRequestContexts.server.ts`. The sole reported unexpected path is the explicitly accepted `mfaGate.server.test.ts` fixture repair. Its git object is identical to the accepted `43894006` object. Production MFA remains unchanged. No other path is outside the input inventory.

The current diff has exactly the same 151-path set as the first-round successor: 81 `src`, 36 `docs`, 20 `supabase`, eight `.agents`, five `scripts`, and `CONTEXT.md`. Its partition is 132 PR-only, 17 shared, one main-only adaptation, and the one accepted fixture repair. The prior 132 PR-only objects or absences remain exact.

The new main delta has 51 changed-file entries with rename detection, or 52 explicit tree paths when both sides of the test-support rename are counted. All 52 are included in the rebased prior-to-current tree delta. There is no tree drift outside that complete delta. Of the 51 named entries, 47 match current main exactly. Four combine both inputs: the authorization-boundary document, boundary manifest, feature request contexts, and in-memory composition. For each of those four files, the new main's added/deleted lines are identical to the added/deleted lines in `43894006` to `f7d83ccc`. This supplements the equal range-diff entries with direct integration checks.

## Critical Task completion boundary and retained behavior

Current main's `CriticalTaskCompletionPersistence` contract and implementation are retained byte-for-byte. `criticalTaskCompletionPersistence.server.ts:12-136` binds the ordinary authenticated request client and canonical Organization ID. Every ledger query and write remains Organization-bound. Named reads return typed values through the private mapper; no provider work happens during factory construction.

The owner port preserves the distinct consumers:

- Individual history traverses complete pages and orders by completion date descending with an ID tie-break.
- Personnel readiness traverses the complete Person history with its retained unordered meaning.
- Reports/Dashboard traverse all requested Person/task history, deduplicate input IDs, limit each filter dimension to 50 IDs, use stable ID ordering, and allow at most four report windows concurrently. An empty dimension dispatches no query.
- Imports retain all dates, batch matched pairs in groups of 50, deduplicate overlapping saved IDs, and preserve their existing unordered lookup behavior. The use case's maximum 500 inputs bounds the number of import windows.
- Create supplies null defaults for optional details and stamps the bound Organization. Partial edit filters only undefined fields, preserving explicit null. Protected ID/Organization/logger/timestamp input fields cannot become write columns. Missing references return null; provider errors remain errors.

`personnelIctCompletionOperations.server.ts` retains route and owner policy checks, old/replacement Person scope, active/archive restrictions for both Person and task, request-local reference reuse, and success audit after the owner operation. `ictCompletionsBatch.server.ts` retains preliminary matching and Group policy before completion lookup, same-date update identity, bulk create followed by per-row fallback only after a rejected bulk request, partial inserted/updated/error outcomes, and audit counts. A short or empty successful bulk acknowledgment is not converted into a retry that duplicates persisted effects.

The old `PersonnelIctCompletionEntity`, its test, generic completion write-store interfaces, and old test-support path remain deleted. Completion operations, imports, individual history, report history, and Personnel readiness no longer query or mutate the completion table through their generic store. Remaining Critical Tasks settings reads are explicit D28 debt, rather than a restored completion CRUD path. The latest RPC adapter remains separate and uses the private mapper without changing its RPC, empty-filter guard, or pagination.

## Direct and reverse request composition

`featureRequestContexts.server.ts:108-141` preserves main's new bindings:

- Completion POST/PUT/DELETE and batch routes select `createRequestIctCompletionContext`, containing auth, audit, the ordinary library, the ordinary completion port, and the separate Personnel-owned completion roster. It does not spread the generic write-store context.
- Critical Task workspace/report/matrix export and report export select the read context with the ordinary completion port and unchanged latest read model.
- Individual history selects the history context with the two owned readers and Personnel roster, without a generic history store.

`requestContexts.server.ts` remains identical to current main. Its Personnel detail-stream context binds the ordinary completion factory at line 457; the Personnel page passes that exact binding to `loadCriticalTasksReadinessLane`. That function awaits Person lane authorization before launching the library, completion history, and settings reads in parallel (`personnelCriticalTasksReadiness.server.ts:35-41`). A Personnel-only member cannot query those sources by opening detail. The Dashboard summary context binds the completion port at line 625; the real summary consumes Critical Tasks report history while Training and Onboarding retain their distinct projections.

The in-memory merge preserves every current-main completion factory option, unavailable-port guard, and third completion argument to the synthetic latest adapter. The owned test-support helper binds the library, completion, and latest adapters explicitly. The removed production export of the synthetic latest adapter stays removed. Generic test contexts do not silently fall back to a completion table reader when the owner collaborator is absent.

## Accepted Training patch and selected coverage

The first-round [source acceptance](source-acceptance.md) remains applicable to unchanged Training policy, providers, goal validation, archive/name readers, HTTP integration, and consolidated export-test behavior. It is reused as source proof, rather than relabeled as a current-head execution. The first-round [artifact acceptance](artifact-acceptance.md) remains pinned to its original live source and main.

The merged feature adapter retains separate Training roster and briefing factories (`featureRequestContexts.server.ts:62-78`). The briefing still supplies the ordinary Organization goal/name reader while completion/matrix retains its roster context. All three Training report APIs and the report page keep their briefing selection. The in-memory Organization reader still selects and maps the goal plus `findTrainingBriefingContext`; its policy writer still maps the goal update. Training's public server exports retain its archive reader, type-name reader, and Person export function. Organization export composition still selects Training's owner-held archive reader at `requestContexts.server.ts:589`. No new main completion factory displaces these collaborators.

Reviewed tests express independent retained outcomes rather than import-name checks alone. The ordinary SDK provider witnesses exercise 1,001 captures and tail fields, first/later page errors, bounded report windows, empty scopes, dated imports, nullable/protected writes, missing/foreign references, saved identities and partial acknowledgments. The real selected Personnel context test obtains ordinary completion rows with an otherwise empty generic completion store, proves 100% readiness from literal dated facts, and denies a Personnel-only member before source queries. The real Dashboard context test proves a scoped Critical Tasks-only viewer's 100% result, empty-scope settlement without privileged roster acquisition, and denial before acquisition. Route/query tests retain actual summary and workbook behavior. These contracts were inspected, not freshly run by this reviewer.

No new integration comments or suppressions were introduced. Source files touched none; comment deletions zero; MUST KILL flags none. Upstream D28 and old-PR comments were not reopened as an unrelated cleanup.

## Remaining limits

This bounded review covers the 51-entry current-main delta, its rename source, shared integrations, complete candidate path census, and prior patch preservation. It does not freshly review every unchanged PR implementation, execute SQL/RLS, validate remote enforcement, measure latency, or establish current-head browser behavior. First-round blank-goal native validation and dropdown pointer-visibility limits remain. The accepted MFA stimulus repair and all prior meaningful assertions survive, but earlier `43894006` check results do not substitute for the parent-owned current-head checks. Fresh affected native/artifact follow-up and completed required checks must be assessed separately before a broader final acceptance claim.
