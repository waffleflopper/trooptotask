import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import {
	repository,
	sessionPath,
	readJSON,
	processIdentity,
	candidate,
	directoryDigest,
	cleanEnvironment,
	sleep,
	stopOwnedProcess,
	Blocked
} from '../../scripts/verification/core.mjs';

export const scratch = path.dirname(fileURLToPath(import.meta.url));
export const implementationFiles = ['transport.mjs', 'command.mjs', 'sidecar.mjs'];
const ignoredSourcePaths = ['node_modules', '.svelte-kit', '.vercel'];
const cookieName = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
export class TransportError extends Error {
	constructor(code) {
		super(code);
		this.code = code;
	}
}
export function requireThat(condition, code) {
	if (!condition) throw new TransportError(code);
}
export function sameProcess(expected, actual) {
	return Boolean(
		expected &&
		actual &&
		actual.state !== 'Z' &&
		expected.pid === actual.pid &&
		expected.start === actual.start &&
		expected.command === actual.command
	);
}
export async function resolveExecutable(name, searchPath) {
	for (const directory of searchPath.split(path.delimiter)) {
		const file = path.resolve(directory, name);
		try {
			await fs.access(file, 1);
			return file;
		} catch (error) {
			if (!['ENOENT', 'ENOTDIR', 'EACCES'].includes(error.code)) throw error;
		}
	}
	throw new TransportError('HELPER_EXECUTABLE_MISSING');
}
function helperArguments(current, expected) {
	const args = current.command.split('\0').filter(Boolean);
	const transient = path.basename(args[0]) === 'env';
	const scriptIndex = transient ? 2 : 1;
	requireThat(
		args.length === expected.args.length + scriptIndex + 1 &&
			JSON.stringify(args.slice(scriptIndex + 1)) === JSON.stringify(expected.args),
		'HELPER_ARGUMENTS_CHANGED'
	);
	requireThat(args[scriptIndex] === expected.launcher, 'HELPER_SCRIPT_CHANGED');
	requireThat(
		transient ? args[1] === 'python3' : ['python3', expected.pythonExecutable].includes(args[0]),
		'HELPER_EXECUTABLE_CHANGED'
	);
	return transient;
}
async function helperSnapshot(captured, expected, dependencies) {
	const identity = dependencies.identity ?? processIdentity;
	const executable = dependencies.executable ?? ((processId) => fs.realpath(`/proc/${processId}/exe`));
	const script = dependencies.script ?? ((file) => fs.realpath(file));
	const before = await identity(captured.pid);
	if (!before || before.state === 'Z') return { absent: true };
	requireThat(before.pid === captured.pid && before.start === captured.start, 'HELPER_REPLACED');
	const transient = helperArguments(before, expected);
	const program = await executable(captured.pid);
	const installedScript = await script(expected.launcher);
	const after = await identity(captured.pid);
	requireThat(after?.pid === captured.pid && after.start === captured.start, 'HELPER_REPLACED');
	const afterTransient = helperArguments(after, expected);
	if (!sameProcess(before, after)) {
		requireThat(transient && !afterTransient, 'HELPER_COMMAND_CHANGED');
		return null;
	}
	requireThat(installedScript === expected.script, 'HELPER_SCRIPT_CHANGED');
	if (transient && program === expected.pythonExecutable) return null;
	requireThat(
		program === (transient ? expected.envExecutable : expected.pythonExecutable),
		'HELPER_EXECUTABLE_CHANGED'
	);
	return { identity: after, transient };
}
export async function capturePreviewHelper(captured, expected, dependencies = {}) {
	const pause = dependencies.pause ?? sleep;
	for (let attempt = 0; attempt < 60; attempt++) {
		const snapshot = await helperSnapshot(captured, expected, dependencies);
		requireThat(!snapshot?.absent, 'HELPER_START_FAILED');
		if (snapshot && !snapshot.transient) return snapshot.identity;
		await pause(25);
	}
	throw new TransportError('HELPER_START_UNSETTLED');
}
export async function reconcileSpawnedHelper(captured, expected, dependencies = {}) {
	const pause = dependencies.pause ?? sleep;
	const stop = dependencies.stop ?? stopOwnedProcess;
	for (let attempt = 0; attempt < 60; attempt++) {
		const snapshot = await helperSnapshot(captured, expected, dependencies);
		if (snapshot?.absent) return;
		if (snapshot) {
			try {
				await stop(snapshot.identity);
				return;
			} catch (error) {
				if (error.code !== 'PROCESS_REPLACED') throw error;
			}
		}
		await pause(25);
	}
	throw new TransportError('HELPER_CLEANUP_UNSETTLED');
}
export function safeStartupCode(error) {
	const code = error?.code;
	if (
		typeof code === 'string' &&
		/^[A-Z][A-Z0-9_]{1,63}$/.test(code) &&
		(error instanceof TransportError || error instanceof Blocked || /^E[A-Z0-9_]+$/.test(code))
	)
		return code;
	return 'START_BLOCKED';
}
export async function finishOwnedCleanup(startupCode, operations, release) {
	const cleanupCodes = [];
	for (const operation of operations) {
		try {
			await operation();
		} catch (error) {
			cleanupCodes.push(safeStartupCode(error));
		}
	}
	if (!cleanupCodes.length && release) {
		try {
			await release();
		} catch (error) {
			cleanupCodes.push(safeStartupCode(error));
		}
	}
	if (startupCode || cleanupCodes.length) {
		const failure = new TransportError(startupCode ?? 'CLEANUP_INCOMPLETE');
		if (startupCode) failure.startupCode = startupCode;
		failure.cleanupCodes = cleanupCodes;
		throw failure;
	}
}
export function assertWorker(binding, state, identities) {
	requireThat(
		state.repository === binding.repository &&
			state.worker === binding.worker &&
			state.id === binding.sessionId &&
			state.phase === 'running',
		'WORKER_CHANGED'
	);
	for (const key of ['candidate', 'artifact', 'sourceDigest', 'buildDigest', 'origin'])
		requireThat(state[key] === binding[key], 'WORKER_CHANGED');
	for (const key of ['supervisor', 'appProcess'])
		requireThat(sameProcess(binding[key], state[key]) && sameProcess(binding[key], identities[key]), 'OWNER_CHANGED');
	for (const key of ['starter', 'helper'])
		if (binding[key]) requireThat(sameProcess(binding[key], identities[key]), `${key.toUpperCase()}_GONE`);
}
export async function assertLive(binding, dependencies = {}) {
	const readState = dependencies.readState ?? (() => readJSON(path.join(binding.session, 'session.json')));
	const identity = dependencies.identity ?? processIdentity;
	const state = await readState();
	const identities = {};
	for (const key of ['supervisor', 'appProcess', 'starter', 'helper'])
		if (binding[key]) identities[key] = await identity(binding[key].pid);
	assertWorker(binding, state, identities);
	return state;
}
export async function guardTurn(binding, onLost, dependencies = {}) {
	try {
		await assertLive(binding, dependencies);
		return true;
	} catch {
		await onLost();
		return false;
	}
}
export async function doctor(state) {
	const response = await fetch(`http://127.0.0.1:${state.controlPort}`, {
		method: 'POST',
		headers: { Authorization: `Bearer ${state.token}`, 'Content-Type': 'application/json' },
		body: JSON.stringify({ command: 'doctor' }),
		signal: AbortSignal.timeout(20000)
	});
	requireThat(response.ok && response.headers.get('X-T2T-Session') === state.id, 'DOCTOR_UNAVAILABLE');
	const result = await response.json();
	requireThat(
		result.status === 'PASS' &&
			result.session === state.id &&
			result.candidate === state.candidate &&
			result.origin === state.origin,
		'DOCTOR_BLOCKED'
	);
	return result;
}
export async function implementationDigest() {
	const hash = createHash('sha256');
	for (const name of implementationFiles) hash.update(name + '\0').update(await fs.readFile(path.join(scratch, name)));
	return hash.digest('hex');
}
export async function fileDigest(file) {
	return createHash('sha256')
		.update(await fs.readFile(file))
		.digest('hex');
}
export async function checkpoint(binding) {
	const state = await assertLive(binding);
	const result = await doctor(state);
	requireThat(
		(await candidate()) === binding.candidate && (await candidate(binding.appCopy)) === binding.artifact,
		'CANDIDATE_CHANGED'
	);
	requireThat(
		(await directoryDigest(binding.appCopy, ignoredSourcePaths)) === binding.sourceDigest &&
			(await directoryDigest(path.join(binding.appCopy, '.svelte-kit/output'))) === binding.buildDigest,
		'ARTIFACT_CHANGED'
	);
	requireThat((await implementationDigest()) === binding.adapterDigest, 'ADAPTER_CHANGED');
	requireThat(
		(await fileDigest(path.join(binding.session, 'fixtures.json'))) === binding.fixtureDigest,
		'FIXTURE_CHANGED'
	);
	await assertLive(binding);
	return result;
}
export async function admit() {
	const session = sessionPath('1');
	const state = await readJSON(path.join(session, 'session.json'));
	requireThat(
		state.repository === repository &&
			state.worker === '1' &&
			state.phase === 'running' &&
			/^[0-9a-f-]{36}$/.test(state.id),
		'WORKER_NOT_OWNED'
	);
	const binding = {
		version: 1,
		repository,
		worker: '1',
		session,
		sessionId: state.id,
		appCopy: path.join(session, 'app'),
		revision: state.revision,
		candidate: state.candidate,
		artifact: state.artifact,
		sourceDigest: state.sourceDigest,
		buildDigest: state.buildDigest,
		origin: state.origin,
		supervisor: state.supervisor,
		appProcess: state.appProcess,
		adapterDigest: await implementationDigest(),
		fixtureDigest: await fileDigest(path.join(session, 'fixtures.json')),
		cookiePrefix: `t2t_verify_${state.id.replaceAll('-', '')}_`
	};
	requireThat((await fs.realpath(binding.appCopy)) === binding.appCopy, 'APP_COPY_PATH');
	await checkpoint(binding);
	return binding;
}
export async function ownedEnvironment(binding) {
	await assertLive(binding);
	const bytes = await fs.readFile(`/proc/${binding.appProcess.pid}/environ`, 'utf8');
	await assertLive(binding);
	const original = Object.fromEntries(
		bytes
			.split('\0')
			.filter(Boolean)
			.map((part) => {
				const equals = part.indexOf('=');
				return [part.slice(0, equals), part.slice(equals + 1)];
			})
	);
	const keys = [
		'PUBLIC_SUPABASE_URL',
		'PUBLIC_SUPABASE_ANON_KEY',
		'SUPABASE_SERVICE_ROLE_KEY',
		'ACCOUNT_SETUP_LINK_SECRET',
		'ACCOUNT_SETUP_SESSION_SECRET',
		'CLEANUP_SECRET'
	];
	for (const key of keys) requireThat(Boolean(original[key]), 'APP_ENVIRONMENT');
	const provider = new URL(original.PUBLIC_SUPABASE_URL);
	requireThat(
		provider.protocol === 'http:' &&
			provider.hostname === '127.0.0.1' &&
			provider.port &&
			!provider.username &&
			!provider.password &&
			!provider.search &&
			!provider.hash,
		'PROVIDER_NOT_LOCAL'
	);
	requireThat(original.APP_PUBLIC_ORIGIN === binding.origin && original.NODE_ENV === 'production', 'APP_ENVIRONMENT');
	return {
		...cleanEnvironment(),
		...Object.fromEntries(keys.map((key) => [key, original[key]])),
		NODE_ENV: 'production',
		PUBLIC_APP_ORIGIN: '',
		PUBLIC_SITE_URL: '',
		APP_PUBLIC_ORIGIN_ALLOWLIST: ''
	};
}
export function validatePreviewInfo(info, appCopy) {
	const url = new URL(info.url);
	requireThat(
		info.project === appCopy &&
			/^[a-z0-9.-]+\.ts\.net$/.test(info.hostname) &&
			Number.isInteger(info.local_port) &&
			info.local_port >= 19000 &&
			info.local_port < 20000 &&
			Number.isInteger(info.public_port) &&
			info.public_port >= 18000 &&
			info.public_port < 19000 &&
			url.protocol === 'https:' &&
			url.hostname === info.hostname &&
			Number(url.port) === info.public_port &&
			url.origin === info.url &&
			!url.username &&
			!url.password &&
			!url.search &&
			!url.hash &&
			typeof info.cert_file === 'string' &&
			typeof info.key_file === 'string',
		'PREVIEW_ALLOCATION'
	);
	return info;
}
export function validateRunBinding(binding) {
	const appOrigin = new URL(binding.origin);
	requireThat(
		binding.repository === repository &&
			binding.worker === '1' &&
			binding.session === sessionPath('1') &&
			/^[0-9a-f-]{36}$/.test(binding.sessionId) &&
			binding.appCopy === path.join(binding.session, 'app') &&
			binding.runDirectory === path.join(scratch, 'runs', binding.sessionId) &&
			appOrigin.protocol === 'http:' &&
			appOrigin.hostname === '127.0.0.1' &&
			appOrigin.port &&
			appOrigin.origin === binding.origin &&
			!appOrigin.username &&
			!appOrigin.password,
		'RUN_NOT_OWNED'
	);
}
export function incomingCookies(header, prefix) {
	if (typeof header !== 'string') return '';
	return header
		.split(';')
		.map((part) => part.trim())
		.filter((part) => {
			const equals = part.indexOf('=');
			const name = part.slice(0, equals);
			return equals > 0 && name.startsWith(prefix) && cookieName.test(name.slice(prefix.length));
		})
		.map((part) => part.slice(prefix.length))
		.join('; ');
}
export function outgoingCookies(header, prefix) {
	const rename = (cookie) => {
		requireThat(typeof cookie === 'string', 'COOKIE_HEADER');
		const equals = cookie.indexOf('=');
		const name = cookie.slice(0, equals);
		requireThat(equals > 0 && cookieName.test(name), 'COOKIE_HEADER');
		return name.startsWith(prefix) ? cookie : prefix + cookie;
	};
	return Array.isArray(header) ? header.map(rename) : rename(header);
}
export function cookieMiddleware({ origin, prefix, sessionId, alive = () => true, relay }) {
	const expectedHost = new URL(origin).host;
	return function ownedMacTransport(req, res, next) {
		if (!alive()) {
			res.writeHead(503).end();
			return;
		}
		if (
			req.socket.encrypted !== true ||
			req.headers.host !== expectedHost ||
			(req.headers[':authority'] && req.headers[':authority'] !== expectedHost) ||
			(req.headers.origin && req.headers.origin !== origin)
		) {
			res.writeHead(403).end();
			return;
		}
		if (sessionId) res.setHeader('X-T2T-1503-Session', sessionId);
		const admitted = incomingCookies(req.headers.cookie, prefix);
		if (admitted) req.headers.cookie = admitted;
		else delete req.headers.cookie;
		const setHeader = res.setHeader;
		res.setHeader = function (name, value) {
			return setHeader.call(this, name, name.toLowerCase() === 'set-cookie' ? outgoingCookies(value, prefix) : value);
		};
		if (relay)
			Promise.resolve(relay(req, res))
				.then((handled) => {
					if (!handled) next();
				})
				.catch(() => {
					if (!res.headersSent) res.writeHead(503);
					res.end();
				});
		else next();
	};
}
export function servePortState(config, port) {
	const suffix = ':' + port;
	let present = false,
		funnel = false;
	function visit(section) {
		present ||=
			Object.hasOwn(section.TCP ?? {}, String(port)) ||
			Object.keys(section.Web ?? {}).some((key) => key.endsWith(suffix));
		funnel ||= Object.entries(section.AllowFunnel ?? {}).some(([key, value]) => key.endsWith(suffix) && value === true);
		for (const name of ['Foreground', 'Services']) for (const child of Object.values(section[name] ?? {})) visit(child);
	}
	visit(config);
	return { present, funnel };
}
