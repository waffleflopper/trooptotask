# #1504 final acceptance v4 (owned browser, PR1511)

## Verdict

**PASS for this bounded scope.** The print blocker (P1) is fixed on this candidate. No new blocker was found.

- Every one of the 10 Print brief PDFs is landscape only, with no blank portrait page.
  - The empty Bravo+Targeted brief is exactly 1 page, in both light and dark.
  - The loaded 25-row brief is 5 pages; v3 produced 6.
- An active toast is left out of the printed brief.
- The roster-shrink pager edge passes natively, in both variants.
- Alt+T focuses the notifications list.
- All fixture readbacks equal root's originals, and the final doctor passes with the exact identity.

There is one minor non-blocking finding (F1, the "Rows per page" control) and a few observations. This lane certifies only its own live observations. Independent source/artifact acceptance belongs to root.

## Identity

- HEAD `53ab7cc9997746e243817fb4a283d99b0d3a0825`, base `ee1ca2b2…`, worker 1, candidate `cda447f1…c29e90`.
- Origin `http://127.0.0.1:34603`, session `626b9a39-ff2e-479b-9be6-897f1a3b2a1b`, Chromium 152.0.7977.82 Arch Linux.
- Doctor PASS with the exact candidate, revision and session at the start (`000`) and at the end (`358`).
- Actor `trainingConfigure`, page 2, Org A `a94fb3a0…`. Fixture day 2026-10-04; the horizon ends 2027-01-02.
- `expectations.md` was written from `root-public-fixture.json` and the `root-*-original.json` rows before driving.
- Starting state: 1905×2053, light theme, `mode-watcher-mode=system`, no sidebar cookie, preferences `[]`.

Evidence lives in `.verification/evidence/verify-trooptotask/1504-final-v4/accept/`:

- `receipts/index.jsonl` holds **460 unique receipts**. Each records argv, exit code, time and seconds, with stdout/stderr files.
- Other folders: `snaps/`, `shots/`, `pdf/`, `pdfpages/` (every page as PNG, plus `.info.txt`, `.txt` and montages), and `xlsx/` (with decoded JSON).
- Also: `pdf-census.json`, `final-readback-comparison.json` and `notes.md`.
- Labels: "READ-ONLY" receipts are rendered DOM or request observations. They are kept separate from native interaction.
- Token scan (JWTs, access/refresh tokens, `sb-*-auth-token`, Bearer) found nothing. The native `get_network_request` output already shows `cookie: <redacted>`. No file is flagged for redaction.

**Nonzero receipts: 4, from two missteps, each repaired once.**

- **`088` click, then `089`/`091` waits:** the "Clear filters" UID grep matched two buttons (header and empty state), so the click failed.
  - The resulting `pdf/dated-unfiltered-dark.pdf` (`093`) is **mislabeled**. It is really a second native-invoked empty Bravo+Targeted dark brief (1 landscape page).
  - It is kept and counted as such. The repair is `094`–`100`, saved as `dated-unfiltered-dark-r1`.
- **`338` confirm:** an empty UID meant no DELETE was sent (state showed no calls). Repaired at `344`–`350`.

There were also two zero-exit missteps in the toast work. They are described in §6.

## Results by path

| # | Path | Result |
|---|---|---|
| 1 | Original report, cell and focus-link SECTION focus, full screenshot, native transport | PASS |
| 2 | Dated CSV import, readback/reload, dated briefing and detail, native 5-sheet workbook | PASS |
| 3 | P1: empty Bravo+Targeted brief in light and dark | **PASS** (exactly 1 landscape page each) |
| 4 | Dated unfiltered light/dark, Alpha with open detail, failed-refresh alert, 1920 collapsed, seeded 25-row | **PASS** (every page inspected) |
| 5 | Roster-shrink edge: two cohorts, `page=2` clamped to page 1, SECTION focus and radio no-steal; pager and Retry smoke | **PASS** |
| 6 | Root Toaster: real error toast, Alt+T, print with an active toast | PASS (Alt+T needed one confound repair; see §6) |
| 7 | Loaded/wide chart after print, then native horizon change and restore, console, 1440/390 screens | PASS; LayerCake warnings recur on one print (see §7) |
| 8 | Restoration, readbacks, final doctor | PASS; two added browser keys recorded |

## 1. Original report

- **Matrix (`004`):**
  - Able: Required Current, Targeted Not Done.
  - Baker and Unassigned: Required Not Done, Targeted N/A.
  - Optional is N/A for all three.
- **Reports via the visible link (`005`–`007`):**
  - "3 soldiers · as of 4 Oct 2026"; 25% stays 25%; Ready 1, expired 0, not recorded 3, lapse 0.
  - Grid: Alpha 100/0, Bravo 0, Unassigned 0; Total Required 33, Total Targeted 0.
- **Load requests (`008`, `013`):** only the `training/reports/__data.json` request loaded the report. There was no summary fetch.
- **Total Required cell:** request `detail?scope=cell&type=dc2cac91…`, 2 rows (Baker and Unassigned, both Not Done). Focus went to `SECTION#training-affected-soldiers` (`011`).
- **Focus link "View 1 soldier":** request `scope=focus&focus=gap%3A04180432…`, Able Not Done. Focus went to the SECTION (`016`–`018`).
- **Screenshot:** `shots/p1-original-cell-detail-full.png`.
- **Native transport:** `list_pages` returned `structuredContent.pages`, and click and snapshot both worked.

## 2. Dated import and workbook

- **CSV:** `p2-import.csv` with Baker Required 2024-10-04 and Able Targeted 2025-10-19.
- **Preview (`026`):** 2 valid rows, 2 selected. Provider count stayed 1 (`027`).
- **Import (`029`–`033`):** batch POST 200 for both Person IDs. Result: Inserted 2, Updated 0, Exempted 0, Errors 0.
- **New IDs (`038`):**
  - Baker Required `a6436f5f-acb5-4c17-9f69-ecbd5c919c57`: 2024-10-04 → 2025-10-04.
  - Able Targeted `3cebfc94-d159-4493-ae7a-d2c03ee8c6d3`: 2025-10-19 → 2026-10-19.
- **Matrix after reload:** Able Targeted "15d left", Baker Required "Expired 365d ago".
- **Dated briefing (`041`):**
  - 50% → 25%, "loses 25 points"; Ready 2, expired 1, not recorded 1, lapse 1.
  - Type risk: Required 2/0 above Targeted 0/1.
  - Alpha × Targeted is 100%, "drops 100 points".
- **Required Total detail:** Unassigned Not Done, then Baker "Expired 365d ago", Oct 4, 2025.
- **Alpha × Targeted:** Able, 15d left, Oct 19, 2026, Yes.
- **Native export with Alpha × Targeted open (1 row) (`049`–`056`):**
  - GET 200; `training-report-2026-10-04.xlsx`; xlsx MIME; 11859 bytes; SHA `ddc60606…0a11`.
  - Sheets are exactly Summary, Forecast, Hot spots, Focus, Requirements.
  - Requirements has exactly 3 rows: Unassigned Not Done; Baker Expired 2025-10-04; Able 15d left 2026-10-19 / 2026-10-20 / Yes. So the open detail did not narrow the export.
  - Summary shows 50/25/90, 2/4/1/1/1, and all filter rows.
- Other v3 model, access and consumer coverage was not repeated.

## 3–4. Print

For every case: reload, rebuild the state with native controls, `print arm`, native click on Print brief, `print state` **before** save, `print save` of the exact URL from `list_pages` into a new PDF, then restore.

**Census:** 10 PDFs, all with `beforeprint=1` saved before capture. There were zero zero-event attempts. All pages are 792×612 landscape, and no PDF has a portrait or blank page.

The page-by-page visual verdict below comes from the 90 dpi renders.

| PDF | Pages | Visual verdict |
|---|---|---|
| `empty-bravo-targeted-light` | 1 | Title; "Verification Organization A · 1 soldier · as of 4 Oct 2026"; full filter line under the title (Group Bravo, Types Verification Targeted Training, Horizon 90, Rows by Group); "No applicable requirements for these filters." plus explanation. No chrome. **PASS (exactly 1).** |
| `empty-bravo-targeted-dark` (theme dark, `084`) | 1 | Identical paper-legible output. **PASS.** |
| `dated-unfiltered-dark` (mislabeled) | 1 | Second empty Bravo+Targeted dark render, identical. PASS as an empty-dark repeat. |
| `dated-unfiltered-dark-r1` | 3 | **p1:** title, subtitle, all-default filter line, Bottom line 50%→25% with 2/1/1/1. **p2:** Forecast (ticks 0–100%, Goal 90%, 50%/25% labels, lapse bar, x-axis Today·4 Oct to 2 Jan) and Hot-spot grid (legend, semantic bands, ▼100 markers, Today/2 Jan columns). **p3:** Type risk (red Required bar 2/0, orange Targeted bar 0/1) and both Focus areas with what-if chips; no "View" links. **PASS.** |
| `dated-unfiltered-light` | 3 | Same structure and content. **PASS.** |
| `alpha-detail-open-light` | 3 | Filter line says "Group: Alpha"; 100%→50%; Alpha forecast; grid with selected-cell outline. p3 has Type risk, one Focus area and Affected soldiers (status, "Rows 1–1 of 1", Able 15d left, Oct 19 2026, Yes), with no radios or pagination. **PASS.** |
| `failed-refresh-alpha-light` | 3 | The alert "Unable to update the briefing / could not be updated (503). Showing the last briefing that loaded." prints with **no Retry**. The filter line truthfully stays "Group: Alpha", matching the displayed briefing, URL and Group control (`133`), even though the attempted change was Bravo. **PASS.** |
| `wide-1920-collapsed-light` | 3 | Collapsed sidebar, chart 1436 px on screen. **p1:** header, Bottom line and Forecast. **p2:** grid and Type risk. **p3:** Focus. Slightly smaller scale, still legible. **PASS.** |
| `seeded-25-row-detail-light` | 5 | **p1:** 29 soldiers, 6%→3%, 2/1/1→28/1. **p2:** Forecast and grid (Alpha 27 soldiers, selected Total Required). **p3:** Type risk 28/0 and 1/1, two Focus areas, Affected soldiers heading, status "28 requirements…", "Rows 1–25 of 28". **p4:** header plus rows 00–18. **p5:** repeated header plus rows 19–24. All 25 rows, no clipping, no page 6. **PASS.** |
| `active-toast-dated-light` | 3 | 2 toasts were visible before and after capture (`317-b` snapshot, `318`). Neither the PDF image nor its text contains a toast. Otherwise identical to `dated-unfiltered-light`. **PASS.** |

Notes on the print results:

- No PDF contains the app header, sidebar, banners, toolbar, header actions, Rows by, Rows per page, Focus links, pagination, Retry, Clear filters or toasts. A text search of every `.txt` found no control labels.
- **Minor layout notes, not failures:**
  - Sections that fit are kept whole, so page 1 of the 3-page briefs has about 40% white space.
  - In the 25-row brief, the Affected soldiers heading, status and range end page 3 while the table starts on page 4.
  - The Targeted "By 2 Jan = 1" figure is orange in light prints and plain in the dark print.
- **Events versus rendering:** each print's `beforeprint` count comes from the native click and was saved before capture. The PDFs establish print rendering, not a system dialog or physical printing.
- **Active-toast case:** I did not reload first, because a reload would remove the toast. `beforeprint=1` was still observed.
- **Not established:** many-type coverage (only two selected types exist) and unchanged-page rendered print.

## 5. Pager edge and smoke

**Edge 1 (cohort `c984f780`, 26 People):**

- With "Rows 1–25 of 28" shown and native focus on Next (`182`), I ran `clean-seeds` without reloading (`183`).
- The A completion IDs were exactly `3cebfc94`, `8e94ca6f`, `a6436f5f`; the original People were Able, Baker and Unassigned (`184`, `186`).
- I armed a hold on `training-reports/detail` and pressed Enter on Next.
- **While held (`189`):** focus on Next, `aria-busy=true`, "Loading page 2", and the honest range "Rows 1–25 of 28".
- **After release (`193`–`198`):**
  - Focus on `SECTION#training-affected-soldiers`; "Rows 1–2 of 2"; rows Unassigned Not Done, then Baker Expired; the pager was removed.
  - The real request was `detail?scope=cell&type=dc2cac91…&page=2` (reqid 1487). The response body has `page:1`, `totalPages:1`, `totalRows:2`, `pageSize:25`.

**Edge 2 (cohort `5096298a`, after reload):**

- Same setup. After Enter on Next with the response held, Shift+Tab moved focus to the "25" item and ArrowRight moved it to "100 rows per page" without selecting it.
- While held, the old range stayed honest and showed "Loading page 2".
- **After release (`222`–`227`):** focus **stayed on the "100 rows per page" button**; 2 rows; no pager. The request was `page=2` (reqid 1609); the body has `page:1`, `totalPages:1`, `totalRows:2`.

**Cleanup and scope:** both cohorts were cleaned with `clean-seeds`, and readback shows only the 3 original People. This is documented synthetic setup, not a real concurrent-user or session race.

**Smoke (cohort `d9b04329`):**

- **Enter Next with the response held (`239`–`247`):** honest held state, then SECTION focus and "Rows 26–28 of 28" (seed 25, Unassigned, Baker).
- **Previous with a 503 (`251`–`256`):** alert "could not be loaded (503). Showing the page that loaded before." The range stayed 26–28, and focus stayed on Previous.
- **Shift+Tab to Retry, then Enter with the response held:** focus moved to the SECTION, "Loading page 1". Tab moved focus to the ordinary "25" radio during the hold. After release, focus stayed on that radio, with "Rows 1–25 of 28" (request without `page`, reqid 1732).
- Cohort cleaned (`276`).

**1440/390 screens:**

- `shots/widths-lower-montage.png`, `w390-*` and `w1440-*`.
- At 390, the 912 px table scrolls inside a 356 px `overflow:auto` wrapper; the document width stays 390.
- The app scrolls inside an inner container, so "full page" captures cover only the viewport. I brought the lower region into view with keyboard focus instead.

**F1 (minor, non-blocking, a11y state):**

- A native click on the **already-checked** "25 rows per page" toggle clears its checked state. Afterwards the snapshot shows neither 25 nor 100 as checked.
- No request is sent, and the table stays at 25 rows per page. This was reproduced at `234`–`238`.
- This was my focus-only click; the pager clamp did not cause it. It also explains the unchecked radios after edges 1 and 2.
- The rows-per-page group appears to allow deselection. It is reported for root's triage; it is not live-certified as a regression against an earlier candidate.

## 6. Root Toaster

**DOM structure (`290`):**

- `div.contents[data-print-chrome]` (`display: contents`) sits after `.app`.
- Inside it: `section[aria-label="Notifications alt+T"][tabindex=-1][aria-live=polite]`, then `ol[data-sonner-toaster][tabindex=-1]`, then the toast.

**Real toast:**

- With Notes set to a draft on Able Required (original `8e94ca6f`) and `network arm-fail personnel-trainings` armed, Save produced POST 503.
- A visible error toast read "Synthetic request failure". The feedback observer recorded `error / Synthetic request failure`.
- Screenshots: `shots/toast-visible.png` and `toast-montage.png`.

**Alt+T:**

- **First press (`293`):** the toast had already expired (0 toasts), so focus stayed on Save.
- **One repair (`299`–`301`):** the toast was present, but focus stayed on Save. The modal Edit dialog was still open, which confounds the test: its focus trap would pull focus back into the dialog.
- **One bounded attempt for that distinct cause (`303`–`307`):** Save (503), then Cancel (closes the editor and discards the draft), then Alt+T.
- **Result:** focus was on `OL[data-sonner-toaster][tabindex=-1]`, inside the Notifications section and inside the `data-print-chrome` wrapper. The stack expanded to 2 toasts (`shots/toast-alt-t-ol-focused.png`).
- **Limit:** Alt+T is not established while a modal dialog is open; this is expected focus-trap behavior.

**Draft and row:**

- After the first failure the draft was retained in the editor (`296`). Cancel discarded it.
- Provider readback (`313`): `8e94ca6f` is unchanged (notes null, original `updated_at`).
- Hooks restored.

**Active-toast print:** the toast persisted while focus was in the list. I went to Reports through the normal link (`315`) and printed: see the `active-toast-dated-light` row in §3–4.

No component tests were added.

## 7. Chart and console after print

**`dated-unfiltered-dark-r1` print (1905 wide, expanded sidebar):**

- The console (`101`) recorded `[LayerCake] Target div has zero or negative width` (×2) and roughly 14 `<rect> attribute width: A negative value` errors (−5.98, −5.12).
- **Impact:** none observed. The printed chart in that PDF is complete.

**Wide 1920 collapsed print and the 1905 25-row print:** no LayerCake or `rect` messages (`148`, `172`). Both consoles held only the baseline CSP/Vercel-insights 404 and preload-warning noise (8 messages).

**After the wide print (`149`–`158`):**

- The on-screen chart was 1436 px wide, with 13 bars and 0 negative widths.
- I changed the horizon natively to 180: URL `?horizon=180`, ticks through 2 Apr, 26 bars, 0 negative (screenshot `wide-horizon-180.png`).
- I changed it back to 90: empty URL, focus on "90 D", 13 bars.
- The console still held only the 8 baseline messages. The forecast and controls recovered.

**Conclusion:** the warnings recur intermittently during print. I cannot call the console clean or establish a cause. No user-visible impact was seen in the PDFs or after recovery.

## 8. Restoration

- **Imported rows:** removed visibly through the editor's Delete, then confirm.
  - Baker `a6436f5f`: DELETE 200 (`329`); readback then showed `3cebfc94`, `8e94ca6f`.
  - Able `3cebfc94`: DELETE 200 (`350`).
  - After reload, the matrix equals the original (`354`).
- **Seed cohorts:** all three were cleaned with `clean-seeds`; readback shows the 3 original People.
- **Controls:** the network, export, print and feedback controls on page 2 all report unarmed or not captured (`356`). No other pages were used.
- **Browser state, restored through native controls:**
  - Viewport 1905×2053; light theme; sidebar expanded; filters cleared; horizon 90.
  - Preferences `[]` match root's original.
- **Browser keys added by this run (cannot be removed with native controls):**
  - localStorage `theme: "light"`, added by the Toggle theme control; the original had no `theme` key.
  - Cookie `sidebar:state=true`, added by Toggle Sidebar; the original had no cookie.
  - sessionStorage `sveltekit:snapshot` and `sveltekit:scroll`, both SvelteKit navigation keys.
- **Final readbacks (`357-*`, `final-readback-comparison.json`) equal root's originals exactly** for:
  - `personnel_trainings`, `training_types`, `training_views` and `organizations`, each for A and B;
  - trainingConfigure preferences.
- **Final doctor PASS** with the exact identity (`358`). Pages 1 (`about:blank`) and 2 (Training) remain open. The worker is returned to root without cleanup.

## Other observations (outside #1504)

- **Sidebar collapse does not survive reload (`139`–`142`):** Toggle Sidebar wrote `sidebar:state=false`, but after reload the sidebar rendered expanded. I recreated the collapsed state after the reload for the wide print case.

## Remaining limits

The following remain unrun, and no claims are made about them:

- full Onboarding and raw Organization export write flows;
- the whole feature map;
- Organization/session timing races;
- many-type print;
- unchanged-page rendered print;
- release, RLS and remote checks.

Other limits:

- Alt+T while a modal is open is not established.
- The intermittent print-time LayerCake warnings are unresolved, with no observed impact.
- F1 awaits root's triage.
- The poteto-mode skill named in the persona prompt was not available in this session, so its leaf principles were not loaded.
