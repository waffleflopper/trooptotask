# Confirmation follow-up observations

Tested 05c062c3 plus followup.patch; frozen candidate184468c9 at loopback39385. Recipe unchanged. Exact native/helper inputs precede every invocation.

- start-* creates fresh Able packet f11b8f10 with3fresh steps, orientation/paperwork incomplete and real matching Training complete.
- complete-* opens2incomplete warning. PUT503 shows error and retained confirmation; read-only activeElement evaluation confirms focusInsideConfirmation:true. Matching captured packet fields unchanged. After recorded restoration, first native confirmation retry issues exactly one realPUT200, dismisses sheet/warning and saves completed status/date with all3step fields/IDs unchanged. Native reload and History show1/3progress rather than changing step completion.
- cancel-* creates fresh Baker packet18a50a2a with3incomplete steps. PUT503 shows error/retained confirmation/focusInsideConfirmation:true and unchanged packet business fields. After restoration, first native retry issues exactly onePUT200 and saves cancelled timestamp/status; progress snapshots unchanged. Reload has noactive cards.
- view-* supplies independent-lane View History: both fresh packets plus original March witness; native opening completedOctober packet shows disabledpaperwork stages and noworkflow/config actions.
- comparisons.json verifies originalMarch business-field witnesses, failure no-effects and complete/cancel unchangedsteps. It excludes omittedtimestamps. finaldoctorPASS binds originalfrozen candidate; ownedcleanupPASS and exactprojectlabel container inventoryempty establishdisposal. All4network/2feedback restoration receipts reporttrue; nohelperseeds remained. NoUI hard-delete is claimed.

Three meaningful red assertions preceded the correction; green.log8files71tests andtypes0/0. The currentKanban hasno noteeditor, so older-list note draft repair is established by handlerchecks rather than browsernotecreation. General concurrency/provider/security/reconciliation/legacy/retention remainlaterproof. No secretsredacted; payloads syntheticonly. Initial read-only focus script had Python syntaxerror before execution; no appaction occurred.
