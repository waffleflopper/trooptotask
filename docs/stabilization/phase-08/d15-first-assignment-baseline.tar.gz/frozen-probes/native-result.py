from drive import *
page=json.loads((E/'page-id.json').read_text())['pageId']
s=snap(page,'mixed-before-onboard'); click(page,uid(s,'link "Onboard"'),'mixed-onboard-nav')
print(snap(page,'mixed-active-list')); screen(page,'mixed-active-list')
