import pathlib,sys,subprocess,json
r=pathlib.Path(__file__).resolve().parent;label,page,suffix=sys.argv[1:]
p=subprocess.run(["python3",str(r/"run.py"),label+"-list","v","tool","list_network_requests",json.dumps({"pageId":int(page),"resourceTypes":["fetch","xhr"],"pageSize":100})],capture_output=True,text=True)
if p.returncode:print(p.stdout,p.stderr);raise SystemExit(p.returncode)
x=json.loads((r/(label+"-list.out")).read_text())["structuredContent"]["networkRequests"];m=[x for x in x if suffix in x["url"]];print(json.dumps(m))
if not m:raise SystemExit("No matching native request")
for i,x in enumerate(m):
 p=subprocess.run(["python3",str(r/"native-body.py"),label+"-"+str(i),page,str(x["requestId"])],capture_output=True,text=True);print(p.stdout,p.stderr)
 if p.returncode:raise SystemExit(p.returncode)
