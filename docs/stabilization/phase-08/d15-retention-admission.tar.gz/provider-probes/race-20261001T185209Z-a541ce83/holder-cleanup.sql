SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 1345 AND backend_start = '2026-10-01 18:52:10.952186+00'::timestamptz AND application_name = 't2t-d15-race-87a0325d';
