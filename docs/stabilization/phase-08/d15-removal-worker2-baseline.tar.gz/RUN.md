# Worker 2 inactive-removal baseline

This is an unchanged-application baseline for D15 / #1363. Product outcomes include failures; successful cleanup does not change those verdicts.

## Frozen candidate and ownership

- Revision: `696875aa743fed288ce9cb4895b53e65006c3a77` (preparation only; application unchanged from merged #1484 / `391edcb1`).
- Branch: `stabilization/1363-onboarding-step-removal`.
- Candidate: `a349650a6f82fc7b4f1e99fefa44a6ec8565898e5d6b203df77242f2371c07aa`.
- Worker: 2, session `ad176e6b-d960-49aa-89b7-2f198a96c760`.
- Origin: `http://127.0.0.1:42771`; Chromium 152.0.7977.82 Arch Linux.
- Owned project: `t2t-verify-df6ae04743df4c44ad9b95c4`.
- Exact checkout: `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413`.
- Normal isolated actors: Onboarding Configure, page 2; Onboarding Operate, page 3. Their Personnel and Training capabilities remain absent. Actor metadata is in `configure-actor-stdout.json` and `operate-actor-stdout.json`.

`frozen-inputs.json` records twenty prelaunch input copies and hashes. `final-frozen-input-check.json` confirms every source and copy still matches, tracked Git blobs match the frozen revision, and HEAD/branch/status are unchanged. Initial/final doctor and launch inputs/outputs are retained. Native commands use only the repository's `verify:app` tools and documented controller. Every command carries worker 2 and the owned short TMPDIR. There is no integrated browser or personal/development/remote database.

## Real provider failure and native retry

Fresh legacy cohorts `a1a5b24e` and `867114fc` were used separately. Normal native Assign Template selected canonical Verification Onboarding A, whose differently named definitions left original Orientation/Paperwork/Historic work inactive and added three fresh active snapshots. Original IDs, work, notes and the strict Person shape were preserved; no Personnel edits or privileged work edits were performed.

The accepted seed-ID-restricted temporary DELETE trigger caused a real native Remove to return 500. Both cohorts restored the optimistic row, had unchanged complete prepared provider snapshots, and showed no readable error: captured feedback entries were empty. Immediate screenshots/snapshots retain that observed failure. The second cohort supplies complete matching failure/retry business bodies captured before any navigation:

- `repeat-fault-failure.network-request` / `.network-response`: original Paperwork DELETE, actual 500 and `{"message":"Internal server error"}`.
- `repeat-fault-unchanged.json`: complete prepared parent/progress snapshot equality.
- `repeat-fault-native-failure-feedback-state-stdout.json`: actual empty rendered feedback capture.
- `repeat-fault-native-failure-after.txt` / `.png`: row restored without readable error.
- `repeat-fault-off-stdout.json` and its returned provider evidence directory: exact fault removed and function/trigger catalog absence established before retry/seed cleanup.
- `repeat-fault-retry.network-request` / `.network-response`: actual retry 200, `{"success":true}`.
- `repeat-fault-native-retry-outcome.json` and `repeat-fault-retry-persistence-open.txt` / `.png`: target absent after real retry/reload, other original IDs/work/notes retained.

The first attempt's retry status/provider absence/native reload are available, but full response-body capture was attempted after reload and the response file was unavailable. `first-fault-retry-response-gap.json` expressly denies full-body acceptance for that attempt; the fresh repeat resolves the needed body observation without erasing it. Both cohorts were cleaned before the next cohort, with complete original rowsets equal after each.

## Observed reactivation followed by DELETE

Fresh legacy cohort `a562c287` is in `wait-seed-stdout.json`. Through native Templates UI, Configure duplicated canonical A, renamed the clone `D15 Removal Matching a562c287`, and renamed only its Paperwork definition to exact `Paperwork`. `wait-native-template-manifest.json` preserves clone/definition IDs. No saved progress work or Person fields were manufactured.

Normal native assignment to the clone linked original Paperwork `1645827e-32a5-4a61-9eec-8a2947d9978e` while preserving Reviewed/incomplete, notes and identity. Normal native switch to canonical A made that same row inactive. Both real native 200 request/response bodies were saved before reload (`wait-assign.network-*`, `wait-switch.network-*`), with separate provider readback and reload screenshots.

The accepted provider helper then held only this original row with a read-only row lock. Exact request bodies were frozen before execution (`wait-reconcile-body.json`, `wait-delete-body.json`). Ordinary authenticated requests were launched through the documented asynchronous controller, without applying their results to the UI. No page navigation occurred while pending.

`removal-wait-20261002T095000Z-7935e330/observed-ordered-writers.json` records RPC PID 2796 waiting on exact holder PID 2903 and DELETE PID 2798 waiting transitively through that RPC to the holder, with backend-start identities and lock classes. The holder was rolled back automatically after this observation; direct holder absence is in the same directory's `cleanup.json` / `result.json`. Both real requests were fully drained before restore/reload.

Actual product verdict: **FAIL**. The reconciliation 200 body returned the original Paperwork active, Reviewed/incomplete, with retained notes. The waiting DELETE then returned 200 / success. Final provider readback contains seven rows, two active, and no original Paperwork ID. Native reload shows `0/2`, active checkbox/Training only, and no active exact Paperwork; the separate deprecated `Verification Paperwork` remains. Other original Orientation/Historic IDs/work/notes survived. `wait-observed-outcome.json`, `wait-drained-outcomes.json`, `wait-final-parent-stdout.json`, `wait-final-progress-stdout.json` and `wait-final-persistence-open.txt` / `.png` retain these observations.

This is known provider ordering, not an invented last-issued request guarantee. The HTTP pair does not exercise optimistic response application; native reload is separate. It does not prove behavior against arbitrary direct writers, post-wait capability changes, or other overlaps.

## Preserved driving gaps

- The frozen utility initially expected a Template combobox; actual native accessibility exposes a Template button and an empty listbox while the screenshot shows options. `fault-assignment-driving-gap.json` retains the failed selector. Focused native Home/End and Enter selected the visible choices, verified by screenshot and actual saved template IDs. Nested Assign/Switch dialogs used fresh snapshot UIDs for the modal footer only.
- A mistaken placeholder UUID in the first assignment readback was rejected by the controller before any mutation; `fault-invalid-readback-driving-gap.json` preserves it. The proper recorded IDs were then used.
- The first retry's unavailable response after reload is explicit above. No status/body inference replaced it.
- Frozen preparation reused one recorder tag for a snapshot and row read, and inline recovery reused another for click/fill. The exclusive-create recorder stopped safely rather than overwriting captures. `wait-preparation-recorder-gap.json` and `wait-preparation-second-recorder-gap.json` preserve those instrumentation failures. Recovery used distinct tags and fresh native snapshots. No frozen helper or utility source was changed during this run.

## Cleanup and disposal

All fault objects were explicitly removed before seed cleanup. The temporary template was visibly deleted, and the clone plus all three definitions were read back absent. Helper `clean-seeds` removed only its recorded cohorts; exact absence reads include ordinary-generated progress IDs. `final-row-and-id-check.json` records thirty unique known temporary IDs absent across three cohorts and the native template/definitions.

Original rows were read **before any seed**. `original-before-rowsets.json` and `original-after-all-rowsets.json` compare every returned row in both Organizations for Personnel, Training, packet/progress and template/definition tables: twelve complete selected rowsets, no seed-ID exclusion predicate. Exact equality is recorded in `full-original-restoration.json`. All network/feedback/request namespaces were restored after their requests settled.

Final doctor PASS retains the frozen candidate/revision. `owned-disposal-stdout.json` is supported worker cleanup PASS. `resources-before.json` captures the actual five full container IDs, two volume names and full network ID during the run. After cleanup, `resources-after.json` and six raw-command/raw-output records prove every exact resource and private worker directory absent. Fresh complete `t2t-verify-[24hex]` container/volume/network inventory is empty, including the earlier disposed worker 1 namespace. `final-resource-check.json` records that timeline explicitly.

`post-disposal-count-checkpoint.json` records the payload before this RUN note. Root owns byte-exact packaging and independent expanded-artifact acceptance. The actual failures and driving gaps must remain. No migration, source repair, publication or whole-issue completion is claimed by this baseline.
