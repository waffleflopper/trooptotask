import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
s=json.loads((pathlib.Path(__file__).parent/'runtime.json').read_text());p=s['onboardingPage'];d.act('onboarding-training-reference-edit','button','Edit Verification Training Step',p);d.snap('onboarding-training-reference-draft',p)
