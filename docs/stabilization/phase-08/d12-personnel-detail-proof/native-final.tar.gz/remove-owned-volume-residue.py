import argparse
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--worker', required=True)
assert parser.parse_args().worker == '2'
p = Path(__file__).parent
targets = json.loads((p / 'owned-disposal-targets.json').read_text())
project = targets['project']
names = sorted({m['name'] for c in targets['containers'] for m in c['volumes'] if m['type'] == 'volume'})
assert names == ['supabase_db_' + project, 'supabase_storage_' + project]
commands = []
for name in names:
    for argv in [['docker', 'volume', 'inspect', '--format', '{{json .Labels}}', name], ['docker', 'ps', '-a', '--filter', 'volume=' + name, '--format', '{{.ID}} {{.Names}}']]:
        r = subprocess.run(argv, text=True, capture_output=True)
        commands.append({'argv': argv, 'exit': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
        assert r.returncode == 0
        if 'inspect' in argv:
            labels = json.loads(r.stdout)
            assert labels.get('com.supabase.cli.project') == project, labels
        else:
            assert not r.stdout.strip(), r.stdout
    argv = ['docker', 'volume', 'rm', name]
    r = subprocess.run(argv, text=True, capture_output=True)
    commands.append({'argv': argv, 'exit': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
    assert r.returncode == 0
result = {'status': 'PASS', 'worker': 2, 'project': project, 'scope': 'Only two exact volumes recorded from owned containers before verify:app cleanup; matching Supabase project labels and no attached containers verified before removal. No preexisting/local-development/remote provider touched.', 'commands': commands}
(p / 'owned-volume-residue-cleanup.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
