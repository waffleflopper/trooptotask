import { listOnboardingTemplateSteps } from '$features/onboarding/index.server';
/**
 * Onboarding lifecycle use cases — start, cancel, and complete an onboarding record.
 *
 * `startOnboarding(ctx, input)` instantiates a new onboarding record from a template,
 * creating step records for each template step. Returns the created record ID.
 *
 * Lifecycle transitions (cancel, complete) enforce that the record is in the correct
 * state before proceeding. For step-level progress, see `onboardingStepProgress.ts`.
 * For retention logic (auto-archive when complete), see the Onboarding-owned `cleanupExpiredOnboardings` server operation.
 */
import { fail } from '$lib/errors';
import type { OnboardingTrainingPorts, OnboardingWorkflowPorts } from './onboardingPolicy';
import { subjectDetails } from '$lib/server/auditDetails';
import { formatToday } from '$lib/utils/dates';
import {
	requireOnboardingManagePolicyForOnboarding,
	requireOnboardingManagePolicyForPersonnel
} from './onboardingPolicy';

interface StartInput {
	personnelId: string;
	templateId: string;
	startedAt?: string;
}

interface StepResult {
	id: string;
	onboardingId: string;
	stepName: string;
	stepType: string;
	trainingTypeId: string | null;
	stages: string[] | null;
	sortOrder: number;
	completed: boolean;
	currentStage: string | null;
	notes: Array<{ text: string; timestamp: string }>;
	templateStepId: string | null;
	active: boolean;
}

interface StartResult {
	id: string;
	personnelId: string;
	templateId: string;
	status: string;
	startedAt: string;
	completedAt: string | null;
	cancelledAt: string | null;
	steps: StepResult[];
}

export async function startOnboarding(ctx: OnboardingTrainingPorts, input: StartInput): Promise<StartResult> {
	await requireOnboardingManagePolicyForPersonnel(ctx, input.personnelId);

	// Enforce one-active-per-soldier
	const existing = await ctx.store.findMany<{ id: string }>('personnel_onboardings', ctx.auth.orgId, {
		personnel_id: input.personnelId,
		status: 'in_progress'
	});
	if (existing.length > 0) {
		fail(409, 'Soldier already has an active onboarding');
	}

	// Fetch template steps
	const templateSteps = await listOnboardingTemplateSteps(ctx.store, ctx.auth.orgId, input.templateId);

	// Create onboarding record
	const startedAt = resolveStartedAt(input.startedAt);
	const onboarding = await ctx.store.insert<{ id: string }>('personnel_onboardings', ctx.auth.orgId, {
		personnel_id: input.personnelId,
		template_id: input.templateId,
		status: 'in_progress',
		started_at: startedAt,
		completed_at: null,
		cancelled_at: null
	});

	try {
		// Check training records for training-type steps (targeted query)
		const trainingTypeIds = templateSteps
			.filter((ts) => ts.stepType === 'training' && ts.trainingTypeId)
			.map((ts) => ts.trainingTypeId!);

		const completedTrainingTypeIds =
			trainingTypeIds.length > 0
				? ((
						await ctx.trainingOnboardingReferences.completedTypeIds(ctx.auth, [input.personnelId], trainingTypeIds)
					).get(input.personnelId) ?? new Set<string>())
				: new Set<string>();

		// Snapshot template steps into step progress rows
		const stepRows = templateSteps.map((ts) => ({
			onboarding_id: onboarding.id,
			step_name: ts.name,
			step_type: ts.stepType,
			training_type_id: ts.trainingTypeId,
			stages: ts.stages,
			sort_order: ts.sortOrder,
			completed:
				ts.stepType === 'training' && ts.trainingTypeId ? completedTrainingTypeIds.has(ts.trainingTypeId) : false,
			current_stage:
				ts.stepType === 'paperwork' && Array.isArray(ts.stages) && ts.stages.length > 0 ? ts.stages[0] : null,
			notes: [],
			template_step_id: ts.id,
			active: true
		}));

		const steps = await ctx.store.insertMany<{
			id: string;
			onboarding_id: string;
			step_name: string;
			step_type: string;
			training_type_id: string | null;
			stages: string[] | null;
			sort_order: number;
			completed: boolean;
			current_stage: string | null;
			notes: Array<{ text: string; timestamp: string }>;
			template_step_id: string | null;
			active: boolean;
		}>('onboarding_step_progress', ctx.auth.orgId, stepRows);

		ctx.audit.log({
			action: 'onboarding.started',
			resourceType: 'personnel_onboarding',
			resourceId: onboarding.id,
			details: {
				...subjectDetails({ subjectType: 'personnel', subjectId: input.personnelId }),
				template_id: input.templateId
			}
		});

		return {
			id: onboarding.id,
			personnelId: input.personnelId,
			templateId: input.templateId,
			status: 'in_progress',
			startedAt,
			completedAt: null,
			cancelledAt: null,
			steps: steps.map((s) => ({
				id: s.id,
				onboardingId: s.onboarding_id,
				stepName: s.step_name,
				stepType: s.step_type,
				trainingTypeId: s.training_type_id,
				stages: s.stages,
				sortOrder: s.sort_order,
				completed: s.completed,
				currentStage: s.current_stage,
				notes: s.notes,
				templateStepId: s.template_step_id,
				active: s.active
			}))
		};
	} catch (error) {
		try {
			await ctx.store.delete('personnel_onboardings', ctx.auth.orgId, onboarding.id);
		} catch {
			// Preserve the original failure from the start workflow.
		}
		throw error;
	}
}

function resolveStartedAt(startedAt?: string): string {
	if (startedAt === undefined) {
		return formatToday();
	}

	if (!/^\d{4}-\d{2}-\d{2}$/.test(startedAt)) {
		fail(400, 'Start date must be a YYYY-MM-DD date');
	}

	const [year, month, day] = startedAt.split('-').map(Number);
	const date = new Date(Date.UTC(year, month - 1, day));
	if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
		fail(400, 'Start date must be a valid calendar date');
	}

	return startedAt;
}

interface LifecycleResult {
	id: string;
	status: string;
	cancelledAt: string | null;
	completedAt: string | null;
}

export async function cancelOnboarding(ctx: OnboardingWorkflowPorts, id: string): Promise<LifecycleResult> {
	await requireOnboardingManagePolicyForOnboarding(ctx, id);

	const onboarding = await ctx.store.findOne<{ id: string; status: string }>('personnel_onboardings', ctx.auth.orgId, {
		id
	});
	if (!onboarding) {
		fail(404, 'Onboarding not found');
	}

	if (onboarding.status !== 'in_progress') {
		fail(400, 'Only in-progress onboardings can be cancelled');
	}

	const now = new Date().toISOString();
	const updated = await ctx.store.update<{
		id: string;
		status: string;
		cancelled_at: string | null;
		completed_at: string | null;
	}>('personnel_onboardings', ctx.auth.orgId, id, {
		status: 'cancelled',
		cancelled_at: now
	});

	ctx.audit.log({
		action: 'onboarding.cancelled',
		resourceType: 'personnel_onboarding',
		resourceId: id
	});

	return {
		id: updated.id,
		status: updated.status,
		cancelledAt: updated.cancelled_at,
		completedAt: updated.completed_at
	};
}

export async function reopenOnboarding(ctx: OnboardingWorkflowPorts, id: string): Promise<LifecycleResult> {
	await requireOnboardingManagePolicyForOnboarding(ctx, id);

	const onboarding = await ctx.store.findOne<{ id: string; status: string }>('personnel_onboardings', ctx.auth.orgId, {
		id
	});
	if (!onboarding) {
		fail(404, 'Onboarding not found');
	}

	if (onboarding.status !== 'cancelled') {
		fail(400, 'Only cancelled onboardings can be reopened');
	}

	const updated = await ctx.store.update<{
		id: string;
		status: string;
		cancelled_at: string | null;
		completed_at: string | null;
	}>('personnel_onboardings', ctx.auth.orgId, id, {
		status: 'in_progress',
		cancelled_at: null
	});

	ctx.audit.log({
		action: 'onboarding.reopened',
		resourceType: 'personnel_onboarding',
		resourceId: id
	});

	return {
		id: updated.id,
		status: updated.status,
		cancelledAt: updated.cancelled_at,
		completedAt: updated.completed_at
	};
}

interface CompleteResult extends LifecycleResult {
	incompleteCount: number;
}

export async function completeOnboarding(ctx: OnboardingWorkflowPorts, id: string): Promise<CompleteResult> {
	await requireOnboardingManagePolicyForOnboarding(ctx, id);

	const onboarding = await ctx.store.findOne<{ id: string; status: string }>('personnel_onboardings', ctx.auth.orgId, {
		id
	});
	if (!onboarding) {
		fail(404, 'Onboarding not found');
	}

	if (onboarding.status !== 'in_progress') {
		fail(400, 'Only in-progress onboardings can be completed');
	}

	// Count incomplete active steps (type-agnostic)
	const incompleteSteps = await ctx.store.findMany<{ id: string }>('onboarding_step_progress', ctx.auth.orgId, {
		onboarding_id: id,
		active: true,
		completed: false
	});

	const now = new Date().toISOString();
	const updated = await ctx.store.update<{
		id: string;
		status: string;
		cancelled_at: string | null;
		completed_at: string | null;
	}>('personnel_onboardings', ctx.auth.orgId, id, {
		status: 'completed',
		completed_at: now
	});

	ctx.audit.log({
		action: 'onboarding.completed',
		resourceType: 'personnel_onboarding',
		resourceId: id,
		details: { incomplete_count: incompleteSteps.length }
	});

	return {
		id: updated.id,
		status: updated.status,
		cancelledAt: updated.cancelled_at,
		completedAt: updated.completed_at,
		incompleteCount: incompleteSteps.length
	};
}
