# Current-main Calendar baseline round2 receipt

**CLOSED — ISSUES.** All 116 selected cases are accounted for:114 PASS,2 ISSUE,0 UNRUN. The two ISSUE observations remain owner-deferred and non-blocking. No additional supported-workflow product failure was observed in the completed selected cases. This is worker verification; parent acceptance remains pending.

Raw evidence: `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2`. 5331 files, 135526000 bytes, individually hashed in [inventory.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/inventory.json). Exact case IDs/statuses/reasons are in [case-ledger.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/case-ledger.json).

**Owner-deferred observations**

- P03-14 ISSUE: missing/foreign catalog PUT returned HTTP500 with unchanged complete A/B catalogs. Owner-deferred rare edge, backlog [#1554](https://github.com/waffleflopper/trooptotask/issues/1554).
- P05-13 ISSUE: with the 501-Person Alpha cohort, scoped Calendar range returned500 and native reload stayed busy; app log records URI Too Long. Full-source range succeeded, originals stayed unchanged, and scoped reload recovered after cohort cleanup. Owner-deferred rare edge, backlog [#1555](https://github.com/waffleflopper/trooptotask/issues/1555).

Owner rated their likelihood qualitatively Very low. No percentage is inferred. Both failures/raw evidence retain ISSUE status; no later reproduction, investigation or repair was performed after the steering. See [owner-steering-followup.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/owner-steering-followup.json).

**Bindings**

- Workspace `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93`, branch `stabilization/1376-calendar-owner-current-main`.
- HEAD `2024a521d93716cfca452c9c0f919923883d0db5`, tree `74d6d0fab41d05d3ef553384b537ca80a3629ce7`.
- Candidate `97e90a3a666c663031cc720d5358fb86ec5dd4873bd6eb1119e8e659a73ddf5f`; source digest `1538b1fba877d5be1cb34dbde5cb6f4ba00ee4372bc21dacea4b0db3860d5d55`; actual build digest `c707a65be8371ad729365e21db56880967580ce6c4291354b05d776ba2827a34`.
- Fresh worker1/session `e7aea237-a98c-4bee-b027-a5a195d3c2d3`, owned origin `http://127.0.0.1:37063`. One production build and one native driver; multiple synthetic actor contexts belong to that same owned driver.
- Node 24.21.0/npm 11.19.0 captured before launch, explicit Node 24 PATH first and login false. Chromium 152.0.7977.82. Short private TMPDIR `/tmp/t2c-c9mqzeu2`, 17 bytes, 0700, prepared before freeze and removed only after exact resource closure.
- Doctor passed before driving and after final proof on the same candidate. All 5,127 source files, 44,444 dependency files and 7 external inputs matched before/after. All 18 effective supplemental input bindings matched; two preparation bindings were superseded before first use. Root and all three protected private worktrees stayed clean at their required heads.

**Observed practical coverage**

Calendar-only full/Alpha/empty/view/B reads retained saved September and March intervals, closures, archived assignment references and expected ordinary write denials. Native single-status lifecycle preserved drafts on denial, same-ID edits and NULL notes, then visibly removed only the new row. Catalogs retained original IDs/order/references and literal metadata after lifecycle/header edits. Planner, date-modal, Quick Fill, Cancel/Clear and hidden-slot409 cases saved/removed only their exact intended rows.

Bulk native Add/Import and whole-entry review/Back/failure/retry were completed. The 501-Person partial path saved first 500, retained only the failed Person/draft, and explicitly retried that one with every first 500 full row and separate-note witness unchanged. The fresh ordinary MAIN 500 path then completed native Add200/reload,501-selected500-match review, Back/no-effects, synthetic HTTP503/no-effects, restored explicit native DELETE200 `{ "deleted":500 }`, exact 500-ID effects and reload. All owned cohorts were compared separately and cleaned. [p05-main500-independent-comparison.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/p05-main500-independent-comparison.json).

All five native Reports exports are real XLSX files with independently checked complete cells and actual date bounds: annual Status Days; inclusive31-day Forecast; inclusive91-day Tempo; Person-only Assignment Coverage including archived history; and independently clipped week Readiness. Personnel detail/history exports retain the manager Calendar-none header-only boundary and positively granted Able/Baker/Alpha history. Organization JSON/Excel artifacts contain exactfive Calendar raw tables and readable projections, actual lifecycle/requester/bytes/audit/notifications. Admitted availability-source export failure produced no artifact and a failed lifecycle; explicit restored retry produced a separate completed artifact.

Dashboard full/Alpha/empty/none/B facts, independent lanes, usable pending/error shells and native retries were compared. Availability and assignments were each independently held as real provider reads and independently failed with marked HTTP500 controls. A real held A availability response remained isolated across native B admission; open scope narrowing/restoration recovered exact facts. Whole-dashboard navigation hooks are not substituted for isolated source proof.

Calendar and Planner uncached additional-range503 errors exposed usable explicit Retry controls; restored retries returned real HTTP200. A real held A200 containing March history remained isolated across native Organization B admission/release. A real persisted A status200 remained held while schema-supported native Back admitted B; before/after release B had no A note/status/feedback and exact A/B rows persisted correctly through reloads. The owned A row was removed visibly. Already-open grantnone returned403 and settled Access Restricted; restored access recovered native March history and same-candidate doctor.

**Terminal effects and restoration**

All 76 complete original A/B public business/membership sets (153 rows) were captured before any mutation. Every original row was intact before the deliberate final phase. Separate all 76-set comparisons after each destructive action establish exact effects and unrelated retention:

- Retiring Status: only the original selected type and linked availability row were consumed; one exact status_type.deleted audit and notifications to all five A administrators were observed.
- Retiring Assignment: only the original selected type and linked slot were consumed; Staff/Group/archived/unrelated full sets remained unchanged; actual audit and notifications to all five A administrators were observed.
- Federal reset: original custom federal row was consumed;44 new federal rows match every independent observed date/name/type for nominal2025–2028. Native 2026 list includes July3 Independence Day and May25 Memorial Day. The custom closure retains its original ID/full fields, and every complete B set is unchanged by reset.

The five original terminal exceptions are intentional consumption, not failed restoration. No same-ID replacement was manufactured and no dependent journey followed destruction. All 148 remaining original rows are literally retained; original memberships (64 in A and 21 in B) are exact. Temporary UI rows/cohorts are absent. Legitimate new audit, notification, completed/failed export lifecycle and44 federal rows are preserved as observed additive effects in [final-restoration-comparison.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/final-restoration-comparison.json). No transactional/asynchronous notification guarantee is inferred.

- availability_entries A `31af3880-2e18-4b4a-a43f-435471c4b310` — deliberate terminal consumption.
- status_types A `ea93747a-6f76-497f-913b-cd8c78c552d5` — deliberate terminal consumption.
- assignment_types A `78455c53-855d-4525-8533-4b16cefeb8cb` — deliberate terminal consumption.
- daily_assignments A `7ec3ab0c-d085-4d90-b7ce-88c2ef1bc192` — deliberate terminal consumption.
- special_days A `bfa45a6b-b3de-4b8f-ba86-727ec02ae1a4` — deliberate terminal consumption.

**Resource closure**

All 21 owned pages had no armed/held network, export or feedback control. Server-source state is unarmed; seed/grant/Dashboard-access journal is empty. Final doctor PASS precedes owned cleanup. Actual closure verifies worker directory absent, all 33 recorded owned identities absent (including profile-bound processes), all ten owned TCP ports refused connection, no owned running/stopped provider container remains, and the pre-existing running container identity set is unchanged. Only the task short TMPDIR was removed afterward. [resource-closure.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/resource-closure.json) and [tmp-closure.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/tmp-closure.json).

**Proof limits and failed tooling observations**

- Native Chrome DevTools/helper controls, ordinary signed-in HTTP, provider privileged synthetic rows, and source-derived expectations are separate evidence boundaries.
- Browser synthetic HTTP503 is before dispatch. Network hold dispatches a real HTTP200 then withholds its client delivery. Server-source fail-hard500 is a marked synthetic owned-process provider read rejection.
- Dashboard isolated availability and assignment controls were used; whole-page navigation hooks are not substituted for them. Single-Person export source control has no Person-ID predicate; the isolated admitted action made one availability source read.
- No new SQL, local full CI, concurrency/rollback, performance measurement, production outage or remote database proof. Owner-provided prior CI/SQL remains separately attributed.
- Native catalog bodies captured after reload could not all be recovered. Exact UI/provider lifecycle proof and some native metadata/bodies remain; unavailable bodies must remain explicit.
- Native attachment response capture returned zero bytes; real Blob/download artifacts were retained and actual JSON/XLSX bytes/cells checked separately.
- Catalog sort-order PUT intentionally retained saved11; no actual UI order control. Staff target remained Person; recipe metadata/header/literal restoration exercised, no target conversion claimed.
- Initial partial500-of501 toast was missed; a separately noted native repeat observed exact toast and failed-only retry before owner deferral steering. Both runs retained.
- Feedback observer deduplicates identical type/text and has no per-event timestamp; dispatch/completion and actual provider timestamps must not be called precise toast timestamps.
- Dashboard was driven before Bulk; both cohorts were separately compared and cleaned, with no overlapping cohort. Phase numbering denotes selection, not actual driving order.
- Journal driverOrder serial is per wrapper, not global: independent public provider reads overlap; early actor preparation and two early p02 native dispatches overlapped. Actual journal/native outputs establish completion order. One operator/driver, worker and production build only.
- Preparatory project/skill reads and inline postcapture readers are in the task tool transcript; the raw command journal begins with runtime/preflight and is not claimed to include every earlier read or reporting shell command.
- A mistaken p07 /dashboard route404 HTML capture exposed synthetic credentials once in the tool transcript. Its saved output was privacy-redacted with original bytes/SHA and projection declaration; that single file is not an immutable exact original. Correct /org route probe retained separately. No token values are republished.
- Routine locator/cached-range/parser mistakes and failed v1 report/holiday expectations are retained. V2 independent holidays uses last enumerated Monday; v1 second-last-Monday mistake was never used for reset or PASS.
- Preserved prior round1 files and reports are immutable and earn no current native coverage credit. All current proof binds the fresh round2 session.
- Original retiring linked rows and custom federal row are intentional terminal consumed exceptions; no same-ID restoration is manufactured. No dependent journey follows their destruction.

The 75 native request-detail projections are capture attempts, not a complete count of all writes. Two attempted closure-response bodies were unavailable after navigation, and some catalog writes were never recovered as full bodies. Six attachment captures returned zero bytes; their real artifacts are separately retained. See [native-body-capture-summary.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/native-body-capture-summary.json). Native credential-bearing headers/stdout are omitted in full with per-capture projections. A pattern-only final scan found no JWT-shaped values in text captures; this is not a comprehensive secret detector.

Journal dispatch/completion coverage is 2,406 wrapped commands at its integrity check, all completed. Wrapper CLI failures (two) and native tool/body/locator/reader errors are different classes; not all outer locator/parser failures appear as nonzero wrapper exits. Failed v1 reporting comparators and corrected cached-range/locator attempts remain in raw captures or the task transcript. Preparation/reporting shell reads are not claimed to be wholly covered by this journal.

**Case ledger — all 116 selected cases**

Phase 1.

- P01-01 PASS. Calendar-only September full scope and saved metadata.
- P01-02 PASS. Alpha scoped range.
- P01-03 PASS. Explicit empty range with retained closure.
- P01-04 PASS. View-only affordances.
- P01-05 PASS. Historical March inclusive overlap.
- P01-06 PASS. View single/batch availability denial.
- P01-07 PASS. No-lane single/batch availability denial.
- P01-08 PASS. Scoped Bravo and Unassigned single/batch denial.
- P01-09 PASS. Empty-scope single/batch denial.
- P01-10 PASS. Foreign Organization single/batch denial.
- P01-11 PASS. Foreign status reference rejection.
- P01-12 PASS. Foreign range denial and positive B range.
- P01-13 PASS. Missing/foreign single-entry classification.
- P01-14 PASS. Attempted Personnel identity PATCH rejection.

Phase 2.

- P02-01 PASS. Seeded leave inspect and Cancel Edit no effects.
- P02-02 PASS. Open form grant downgrade and denied Add retained draft.
- P02-03 PASS. Restored native Add exact row and reload.
- P02-04 PASS. Denied same-ID edit preserves fields and draft.
- P02-05 PASS. Restored same-ID edit type/date/note and reload.
- P02-06 PASS. Keyboard-empty note saved null.
- P02-07 PASS. Visible removal of newly created entry and unrelated full sets retained.

Phase 3.

- P03-01 PASS. Temporary status native create/reload/delete.
- P03-02 PASS. Seeded Leave same-ID name/color edit and literal restoration.
- P03-03 PASS. Authenticated order PUT and reference preservation.
- P03-04 PASS. Temporary Person and Group assignment catalogs create/delete.
- P03-05 PASS. Staff same-ID name/code/color/target metadata edit and restore.
- P03-06 PASS. Date-header radio change and restore.
- P03-07 PASS. Archived assignment labels retained in reads but excluded from active controls.
- P03-08 PASS. Canceled catalog edit no effects.
- P03-09 PASS. All configuration actor/tenant POST denials.
- P03-10 PASS. View saved-status PUT denial.
- P03-11 PASS. Temporary closure create/default date/reload.
- P03-12 PASS. Open closure edit configure-to-view denial and draft feedback.
- P03-13 PASS. Restored closure same-ID edit/reload/delete.
- P03-14 ISSUE. Missing/foreign catalog reference rejection. Owner-deferred non-blocking; https://github.com/waffleflopper/trooptotask/issues/1554.

Phase 4.

- P04-01 PASS. September original Person/Group/archived slots and reload.
- P04-02 PASS. Native Planner empty Person and Group save/reload.
- P04-03 PASS. Occupied Person replacement exact slot and unrelated rows.
- P04-04 PASS. Visible Person/Group clear and reload absence.
- P04-05 PASS. Calendar date-header modal set/clear.
- P04-06 PASS. Quick Fill independently enumerated dates/reload.
- P04-07 PASS. Cancel Clear no effects and confirm exact type-only clear.
- P04-08 PASS. Native hidden Bravo slot scoped Planner conflict 409.
- P04-09 PASS. Native hidden Bravo slot date-modal conflict 409.
- P04-10 PASS. Authorized visible hidden-slot cleanup.
- P04-11 PASS. Valid single/batch assignment denials.
- P04-12 PASS. Mixed invalid/forbidden later batch no effects.

Phase 5.

- P05-01 PASS. Native two-Person Bulk Add exact rows/reload.
- P05-02 PASS. Native valid Import exact row/reload and completion retained.
- P05-03 PASS. Canonical Baker whole-entry Remove review real 200.
- P05-04 PASS. Back preserves complete A/B rows and selection.
- P05-05 PASS. Controlled range 503 review failure draft/no effects.
- P05-06 PASS. Restored explicit review retry real 200.
- P05-07 PASS. Overlap seed exact whole-entry confirmation and unrelated retention.
- P05-08 PASS. One-Person nondefault synthetic HTTP503 zero-save retained draft.
- P05-09 PASS. One-Person explicit retry exact real HTTP200 row.
- P05-10 PASS. 501 partial native first 500 real HTTP200 second1 synthetic HTTP503.
- P05-11 PASS. Failed-only retained draft and explicit one-Person retry.
- P05-12 PASS. Every first 500 full row unchanged plus separate-note witness.
- P05-13 ISSUE. Scoped Alpha full marked range and exclusions. Owner-deferred non-blocking; https://github.com/waffleflopper/trooptotask/issues/1555.
- P05-14 PASS. HTTP501 removal input400 no effects.
- P05-15 PASS. Ordinary 500-ID HTTP200 body/effects and absent replay0.
- P05-16 PASS. One ordinary MAIN native500-ID Add/review/Back/controlled removal failure/explicit retry HTTP200 exact body/effects/reload witness.
- P05-17 PASS. Owned cohort comparisons and complete cleanup.

Phase 6.

- P06-01 PASS. Status Days annual native Run/response/export actual XLSX independent all cells.
- P06-02 PASS. Availability Forecast native Run/export actual XLSX inclusive day expectations.
- P06-03 PASS. Personnel Tempo native Run/export actual XLSX actual bounds.
- P06-04 PASS. Assignment Coverage native Run/export actual XLSX Person-only/archived facts.
- P06-05 PASS. Group Readiness native Run/export actual XLSX independently clipped dates.
- P06-06 PASS. Calendar current/historical/long-range native facts and exclusion.

Phase 7.

- P07-01 PASS. Manager Calendar-none record/header baseline.
- P07-02 PASS. Temporary Calendar-view Baker detail readiness exact status/history.
- P07-03 PASS. Restore manager Calendar-none and verify header-only Availability History export boundary.
- P07-04 PASS. Positively authorized Able full descending history native workbook.
- P07-05 PASS. Positively authorized Baker full descending history native workbook.
- P07-06 PASS. Alpha authorized Able export and hidden/empty/foreign denial.
- P07-07 PASS. Available exact single-Person source-failure boundary or explicit unavailable declaration.
- P07-08 PASS. Owner A native JSON complete five Calendar raw tables.
- P07-09 PASS. Owner A native Excel complete Calendar raw/readable sheets.
- P07-10 PASS. B owner positive artifact and ordinary unauthorized tenant probe.
- P07-11 PASS. Export lifecycle/bytes/requester/audit/notification readback.
- P07-12 PASS. Availability source fail-hard admitted export failure/no artifact/unchanged originals.
- P07-13 PASS. Restored explicit export retry separate completed artifact.

Phase 8.

- P08-01 PASS. Dashboard full combined facts and independent lanes/reload.
- P08-02 PASS. Dashboard Alpha exact facts/reload.
- P08-03 PASS. Dashboard empty settled facts/reload.
- P08-04 PASS. Dashboard no-lanes response and settled shell.
- P08-05 PASS. Dashboard B exact foreign-only facts/reload.
- P08-06 PASS. Dashboard foreign-to-A serialized denial and no disclosure.
- P08-07 PASS. Usable Home/source navigation and return.
- P08-08 PASS. Isolated availability real provider hold with usable pending shell/release/settle.
- P08-09 PASS. Isolated assignments real provider hold with usable pending shell/release/settle.
- P08-10 PASS. Isolated availability marked HTTP500/error usable shell/restore/Retry Dashboard.
- P08-11 PASS. Isolated assignments marked HTTP500/error usable shell/restore/Retry Dashboard.
- P08-12 PASS. Real held A availability across native B admission/no stale facts or feedback.
- P08-13 PASS. Already-open Dashboard Alpha scope narrowing and restored recovery.
- P08-14 PASS. Complete Dashboard original/cohort comparisons before cleanup.

Phase 9.

- P09-01 PASS. Uncached normal Calendar range synthetic HTTP503/error/explicit retry real HTTP200.
- P09-02 PASS. Uncached Planner range synthetic HTTP503/error/explicit retry real HTTP200.
- P09-03 PASS. Uncached real Calendar A200 hold native B admission release/no stale facts.
- P09-04 PASS. Actual saved A status real HTTP200 held response and B marked absence.
- P09-05 PASS. Retired-save feedback quietness through schema-supported native Back or separately declared scripted-history limit.
- P09-06 PASS. A/B saved rows after release and reload plus visible A-row cleanup.
- P09-07 PASS. Already-open Calendar grant none denied range/settled Access Restricted.
- P09-08 PASS. Restored Calendar grant explicit recovery and historical preservation.

Phase 10.

- P10-01 PASS. Native retiring Status warning exact type/linked-row deletion.
- P10-02 PASS. Status deletion unrelated complete A/B sets retained.
- P10-03 PASS. Actual status audit and asynchronous admin notification.
- P10-04 PASS. Native retiring Assignment warning exact type/linked-slot deletion.
- P10-05 PASS. Assignment deletion Staff/Group/archived/unrelated complete A/B retention.
- P10-06 PASS. Actual assignment admin notification.
- P10-07 PASS. Frozen source/current-year independently derived every supported observed federal holiday.
- P10-08 PASS. Native federal-reset preservation warning and actual confirmation.
- P10-09 PASS. Every federal date/name/type exact effect and custom-federal terminal exception.
- P10-10 PASS. Custom closure same-ID retention plus unrelated complete B table sets.
- P10-11 PASS. Reload terminal exceptions and no manufactured same-ID restoration.

Detailed per-case reasons and evidence prefixes remain in [case-ledger.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/case-ledger.json). Complete raw payload hashes/bytes are in [inventory.json](/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-calendar-main-baseline-2024a521-r2/inventory.json). Read the three final full-set independent comparisons, freeze comparison, body projections and closure before independent acceptance.

No archive, commit, source/helper/recipe/git mutation, parent canonical cache/trail write, remote or other existing database mutation, delegation, new thread or review round occurred. Parent may independently examine/package/review the closed run. This report does not approve Calendar cutover.
