SET application_name = 't2t-d15-race-789045c2';
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
UPDATE public.personnel_onboardings SET status = 'in_progress', cancelled_at = NULL
WHERE id = 'ae333df7-4b21-46de-841d-f3913e51b638'::uuid AND organization_id = 'bcc91ccd-0ade-4c1f-84c0-ec8fd9604116'::uuid
  AND status = 'cancelled' AND cancelled_at = '2000-01-01T12:00:00+00:00'::timestamptz AND completed_at IS NULL
RETURNING json_build_object('event', 'updated', 'id', id, 'status', status, 'cancelled_at', cancelled_at);
SELECT json_build_object('event', 'holder-ready', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
