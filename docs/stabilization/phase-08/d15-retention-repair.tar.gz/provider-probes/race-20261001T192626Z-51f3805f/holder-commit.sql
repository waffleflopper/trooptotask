COMMIT;
SELECT json_build_object('event', 'holder-committed');
