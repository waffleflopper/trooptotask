# D24 scoped comment review

Candidate `0b35b5b7b01c849f04e149592b190f7d9f0aefb7`, including the current working tree. Base `93be09751f40db3d43f0574afa2aa1a4a609d6d9`.

Read-only review of application and helper/test comments in `git diff --find-renames BASE`, including comments retained in moved files. Source files touched by this review are none. The only written artifact is this report. No service, connector, network, database or publication action occurred.

## Finding

- Delete the retained narrative comment in `src/features/data-export/web/SettingsDataExportWorkspace.svelte:44`, inside `handleOrganizationExport`. It says `// An intentionally requested download may finish after leaving this Organization.` The component move brings it into this scoped review. Lines 40-46 already read the artifact, call `downloadBlob` without the `active` guard, and guard only the success feedback. `src/routes/org/[orgId]/settings/exports/page.svelte.test.ts:109-149` independently describes the requested download continuing while the new Organization keeps its own export state. This is our product policy, rather than behavior forced by an external dependency. Delete the comment without changing that retained behavior.

Actual comment deletions are 0. Recommended comment deletions are 1. `MUST KILL` refactor flags are 0. The code expresses the behavior directly, so no rename, extraction or rearchitecture is required by this finding.

## Exceptions and skips

- Keep `src/routes/org/[orgId]/settings/exports/page.svelte.test.ts:1`, `// @vitest-environment happy-dom`. It is an executable test-runner environment directive, rather than narration. It is unchanged by this candidate.
- Skip unchanged comments in `.agents/skills/verify-trooptotask/helpers/control.mjs` at lines 3, 1362, 1371-1372, 1507-1508, 1795, 2075 and 2126. The helper diff changes fixture table/column selection only. No prose comment is added or modified.
- Skip unchanged comments in `src/features/identity/index.server.ts:1-2`. D24 adds one export below the existing header.
- No scoped lint or TypeScript suppression exists. No newly added prose comment exists. No `IMPORTANT`, `do not remove`, workaround justification or commented-out code requires further investigation.
- Docs, archives and JSON configuration are outside the requested application/helper-comment review. No unrelated main or D22 source was reviewed.

The Prove It Works principle changed the verification choice. I inspected the actual base-to-working-tree diff and current source lines rather than relying on the previous acceptance report. Unslop guided the report wording.
