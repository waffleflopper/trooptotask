import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createClient } from '@supabase/supabase-js';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { GET as cleanupRecords } from './+server';
import { GET as cleanupOnboardings } from '../cleanup-expired-onboardings/+server';

const { getAdminClient, env } = vi.hoisted(() => ({
	getAdminClient: vi.fn(),
	env: { CLEANUP_SECRET: 'synthetic-retention-secret', CRON_SECRET: 'synthetic-shared-cron-secret' }
}));
vi.mock('$lib/server/supabase', () => ({ getAdminClient }));
vi.mock('$env/dynamic/private', () => ({ env }));

// This is controlled installed-SDK dispatch evidence, not live cleanup or RLS evidence.
// The handlers, cleanup use cases and feature adapters run unchanged. Every resource
// cohort is empty, so a complete job must discover work for every Organization but
// must never issue a mutation, notification or Storage request.
const artifactDirectory = resolve('.verification/evidence/d17-retention-enumeration-baseline');
const discoveryTables = new Set([
	'personnel_follow_ups',
	'counseling_records',
	'personnel_documents',
	'leader_notes',
	'personnel',
	'ict_tasks',
	'assignment_types',
	'personnel_onboardings'
]);
const scenarios = [
	{ label: 'empty', count: 0 },
	{ label: '1000', count: 1000 },
	{ label: '1001', count: 1001 }
] as const;

function organizationFixture(count: number) {
	return Array.from({ length: count }, (_, index) => ({
		id: `00000000-0000-4000-8000-${String(index + 1).padStart(12, '0')}`,
		archive_retention_months: index === 0 ? null : index === 1 ? 0 : 12,
		// The tail is deliberately suspended. Current maintenance enumerates all
		// Organizations; suspension must not remove its retention dispatch.
		suspended_at: index === count - 1 ? '2020-01-01T00:00:00.000Z' : null
	}));
}

function cappedProvider(count: number) {
	const organizations = organizationFixture(count);
	const expectedIds = new Set(organizations.map(({ id }) => id));
	const state = {
		organizationReads: [] as Array<Record<string, unknown>>,
		resourceReads: [] as Array<{ table: string; organizationId: string; query: string }>,
		unexpectedEffects: [] as Array<{ method: string; path: string }>
	};
	const client = createClient('http://127.0.0.1:9', 'synthetic-service-key', {
		auth: { persistSession: false, autoRefreshToken: false },
		global: {
			fetch: async (input, init) => {
				const url = new URL(String(input));
				const table = url.pathname.split('/').at(-1)!;
				const method = init?.method ?? 'GET';
				if (method !== 'GET' || !url.pathname.startsWith('/rest/v1/')) {
					state.unexpectedEffects.push({ method, path: url.pathname });
					throw new Error('Empty discovery fixture must not mutate rows or invoke Storage');
				}
				if (table === 'organizations') {
					const offset = Number(url.searchParams.get('offset') ?? 0);
					const limit = Number(url.searchParams.get('limit') ?? 1000);
					const fields = (url.searchParams.get('select') ?? '*').split(',');
					const ordered =
						url.searchParams.get('order') === 'id.asc'
							? [...organizations].sort((left, right) => left.id.localeCompare(right.id))
							: organizations;
					const page = ordered.slice(offset, offset + Math.min(limit, 1000));
					state.organizationReads.push({ query: url.search, offset, limit, returnedCount: page.length });
					return Response.json(
						page.map((row) =>
							fields[0] === '*'
								? row
								: Object.fromEntries(fields.map((field) => [field, row[field as keyof typeof row]]))
						)
					);
				}
				if (!discoveryTables.has(table)) throw new Error(`Unexpected discovery table: ${table}`);
				const organizationId = url.searchParams.get('organization_id')?.replace(/^eq\./, '');
				if (!organizationId || !expectedIds.has(organizationId)) {
					throw new Error('Resource discovery must target a known Organization');
				}
				state.resourceReads.push({ table, organizationId, query: url.search });
				return Response.json([]);
			}
		}
	});
	return { client, organizations, state };
}

beforeEach(() => getAdminClient.mockReset());

describe.each([
	{ label: 'records', run: cleanupRecords, path: '/api/cleanup-archived-records' },
	{ label: 'onboarding', run: cleanupOnboardings, path: '/api/cleanup-expired-onboardings' }
])('$label Organization enumeration through the unchanged handler', ({ label, run, path }) => {
	it.each(scenarios)('dispatches all $count Organizations ($label)', async ({ count, label: scenario }) => {
		const provider = cappedProvider(count);
		getAdminClient.mockReturnValue(provider.client);
		const response = await run({
			request: new Request(`http://owned-handler.test${path}`, {
				headers: { authorization: 'Bearer synthetic-retention-secret' }
			})
		} as Parameters<typeof run>[0]);
		const body = await response.json();
		const dispatchedIds = new Set(provider.state.resourceReads.map(({ organizationId }) => organizationId));
		const missingIds = provider.organizations.filter(({ id }) => !dispatchedIds.has(id)).map(({ id }) => id);
		writeFileSync(
			resolve(artifactDirectory, `${label}-${scenario}.json`),
			JSON.stringify(
				{
					classification: 'Controlled installed-SDK dispatch; no live database, RLS or cleanup-effect claim',
					endpoint: path,
					fixture: provider.organizations,
					designatedTail: provider.organizations.at(-1)?.id ?? null,
					response: { status: response.status, body },
					dispatchedOrganizationIds: [...dispatchedIds],
					missingOrganizationIds: missingIds,
					...provider.state
				},
				null,
				2
			) + '\n'
		);

		expect(response.status).toBe(200);
		expect(body).toMatchObject({ deletedCount: 0, orgsAffected: 0 });
		expect(provider.state.unexpectedEffects).toEqual([]);
		expect(
			missingIds,
			'Every supplied Organization, including the designated suspended tail, must reach resource discovery'
		).toEqual([]);
	});
});
