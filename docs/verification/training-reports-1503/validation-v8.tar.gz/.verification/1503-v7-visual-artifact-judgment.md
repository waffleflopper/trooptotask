# 1503 v7 visual artifact judgment

This judgment covers saved artifacts only. It is not live execution. The reviewer was a fresh T3 Claude Opus 5.5 delegate at medium effort. This lane uses the same model family as the v7 driver, so it does not claim model diversity. No app, browser, database, driver or service command was run. No source, recipe, helper or evidence file was edited. This file is the only write.

## Verdict

**Both v7 objections are nonblocking. Treat them as advisory polish.** Neither one is a wrong-association or legibility defect under the 1433/1503 contract. The D3 and D4 native screenshots support the measurements. The goal-100 overlay and the hidden dashed rule are reported truthfully. Two v7 report claims need correction (see "Corrections to the v7 report"). Neither correction changes the verdict.

## Bindings read

- Evidence root is `.verification/evidence/verify-trooptotask/1503-final-chart-v7/`. Its `SOURCE-BINDING.json` has candidate `7159b967…c055`, revision `3c0b6f2a`, origin `http://127.0.0.1:42057`, worker 1 and Chromium 152.0.7977.82. These match the dispatch binding.
- The source is `src/lib/components/ui/report-chart/ReportForecastChart.svelte`. Its sha256 was re-hashed here as `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831`, the value the v7 report states.
- Inputs read:
  - `.verification/1503-final-chart-v7-report.md` and `INDEX.md`
  - `driver/measure.js` and `driver/analyze.py`
  - `measure/analysis-all.txt` and `measure/fallback-font-metrics.json`
  - the sweep JSON `measure/sweep/g95-light-1440-mixed-90.json` and `g100-light-1440-flat100-90.json`
  - a drift census recomputed here over all 684 sweep JSON files

## Requirements and prior findings carried forward

- **Contract.** The spec requires a labelled dashed success goal, start and end value labels, shared bands and no new math. It specifies no pixel placement for labels. Routine legibility placement is authorized, and there is no spec-amendment gate.
- **D3 (v3 FAIL).** The line crossed Goal 85 in the final 30-day bucket. v4 fixed that state with a halo but failed on the dot, text and turn. v5 passed D3 after moving the goal text into the gutter.
- **D4 (v5 FAIL).** The dashed goal-95 rule crossed the end value "100%" in all 24 flat-100 cases. v5 did not measure gridline contact.
- **v6 correction.** This was source-only. `valueLabelOffset` moves each value label past any rule (grid or goal) it would strike, on a fixed side: the start label goes up and the end label goes down. The v6 model predictions did not establish live legibility. The v6 browser round produced no outcomes.
- **v7 driver claim.** PASS on all three outcomes, with two minor objections left "for Robert's call".

## Objection 1. Displaced start label with a gridline between label and dot

**Disposition. Nonblocking advisory polish. Not a wrong-association defect.**

### Evidence

- `png/hires/g95-light-1440-mixed-90.png` is a DPR2 crop.
  - The start dot is at cy 481.4. "74%" has ink at t 454.2 and b 462.2, with its baseline at 462.2. The 80% gridline is at y 464.7, so the gap is 2.0px.
  - The label's vertical centre maps to about 82.4% on the axis. The driver's "reads near 83%" is accurate.
  - Drift is 11.2px. The edge gap from the label to its own dot is 16.1px. The other dot is 607px away.
- `zoom/z0004-mixed-start.png` shows goal 85 at DPR2. "74%" is wedged between the 80% gridline (2.0px) and the dashed goal-85 rule. The glyphs are clean and nothing strikes them.
- `png/sweep/g85-dark-390-mixed-90.png` is a 1x native crop at the narrowest width in dark theme. The label is legible at 1x. The dark gridline is very faint.
- `png/0007-focus-cell-tab.png` is an unzoomed in-page view at 1440 with goal 100 and the 180-day horizon. Here "74%" sits beside the "80%" axis tick at nearly the same height. This is the worst reading of the objection. The two labels could be misread as a pair, but they differ in weight and colour, and they sit at different x positions.
- In source, `valueLabelOffset(firstY, -1, ruleYs, LABEL_GAP)` gives offset = 16.7 + 2.5 = 19.2px. The default is 8. So the jump is exactly what the rule specifies.

### Why it is not wrong association

1. **No mark competes for the label.** The nearest other dot is at least 175px away in all 684 cases. The label sits in its own dot's column (x = firstX + 6). It is the only foreground-semibold text near that dot. No reading pairs "74%" with any mark other than the start dot.
2. **Gridlines are background structure, not data.** They have low contrast in both themes (see the screenshots above). Crossing one does not detach a label from its point. The label text carries the exact value, and the dot itself sits at 74% on the axis.
3. **Paper does the same thing.** The v7 report says "Paper never shows this state". That is incorrect. The Paper design capture (`evidence/verify-trooptotask/1503-final-chart-v5/driver/png/paper-annotations-scale2.jpg`, captured 2026-10-04T06:08Z from file `01M3HXNN6A4S0FTNQ88XS9YJ9X`, artboard `S8-1`, per `raw/paper-readonly.json`) shows exactly this geometry. Its start "78%" sits above the 80% gridline. The gridline lies between the label and its dot, and the label reads near 81–82%. So the candidate's displaced state matches Paper's own idiom.

### Residual cost and smallest change

- The label sits about 8% above its true value on the axis scale, at most 11.7px of drift. A reader who judges the value from label height instead of dot height, or who reads it alongside the axis tick, pays a small cost.
- The smallest optional polish is to let the start label settle *below* a near gridline when it fits, instead of only jumping above it: offset = gridDist − VALUE_CAP_PX − RULE_CLEARANCE, when that value is ≥ about 4px.
  - In this case that is about 5.8px above the dot centre. The label would then come within about 5px of the 2px line stroke, which is the tradeoff.
  - Affected verification would be a rerun of the v7 sweep lever (`driver/sweep.sh`, `measure.js`, `analyze.py`) for the start-label rows, plus 1x and 2x crops of mixed, view, atGoal, drop9 and nearEnd.
- This polish is reversible and not required by 1433/1503. It is not a blocker. No approval gate is needed.

## Objection 2. 2.0–2.5px glyph-to-rule gaps

**Disposition. Nonblocking qualified residual.**

- **What was measured.** `analysis-all.txt` reports a minimum start-label rule gap of 2.0px and an end-label rule gap of 2.4px. There are zero strikes and zero cases under 2px across 684 cases. All three label fonts resolve to `"IBM Plex Mono", monospace`, rendered width equals the Plex canvas width, and `plexLoaded400/600` is true.
- **Measurement precision.** Canvas `actualBoundingBoxAscent` comes back as whole pixels: 8 for Plex and 9 for Liberation Mono (`fallback-font-metrics.json`). So the measured 2.0px carries about ±0.5px uncertainty. The model's own allowance, VALUE_CAP 8.4 against Plex's measured ascent of 8.0, adds about 0.4px of margin. The DPR2 crops show visible paper between glyph and rule. These are `png/hires/g95-light-1440-flat100-90.png`, `png/hires/g95-dark-390-flat100-90.png` and `zoom/z0004-mixed-start.png`.
- **Fallback font.** The 1.4px figure is a canvas prediction, not a rendered fallback. No fallback render was run, and this file does not claim one. Fallback is a degraded state for a self-hosted, loaded face, and even the prediction shows no strike. I treat it as a qualified residual, not as proof.
- **Legibility judgment.** Separation is clear at 1x and 2x in both themes. A 2px gap to a 1px, low-contrast gridline or a 1px dashed rule does not merge the glyphs. Nothing more than advisory polish follows.

## D3 and D4 screenshot validation

- **D4 (goal 95, flat 100).** `png/hires/g95-light-1440-flat100-90.png`, `png/hires/g95-dark-390-flat100-90.png` and `zoom/z-g95-light-flat100.png` show the green end "100%" right-aligned under the end dot. It sits in the strip between the dashed goal-95 rule and the 90% gridline, and neither line touches it. The v5 defect, a rule through the glyphs, is gone. The label reads as the end dot's value: it sits directly below and left of the dot, with no other mark nearby. **Supports the measurement. PASS.**
  - `zoom/z-g95-light-flat100.png` crops off the top of the *start* label. That is a crop-window artifact. The uncropped `png/hires` file shows the label whole, and `outsideSvg.t` is negative in the JSON.
- **D3 (goal 85, final 30-day bucket).** `zoom/montage-g85-light-final30.png` covers 1440 and 390 in light theme. The final turn is unmasked. The end dot, red "50%", bar count "50" and the right-aligned caption are all separated. The band reaches the plot edge. **Supports the measurement. PASS.**
  - The dark theme is in `zoom/montage-g85-dark-1440.png`. I did not view it; the light montage and the hires dark crop were enough to judge the geometry.
- **1024 at 180 days.** `zoom/montage-g85-light-1024-180x2.png` shows sparse ticks (Today · 4 Oct / 1 Feb / 2 Apr) that are legible and do not overlap. Narrow bars, counts 139/50/10 and the highlighted band are distinct. The end labels 54%, 50% and 75% sit below their dots. **Legible.**

## Goal 100 overlay truthfulness

- In `measure/sweep/g100-light-1440-flat100-90.json`, the goal rule exists with dash `4px, 4px`, stroke-width 1, at y 372.5. That is identical to both dots' cy. In source, `<Rule>` (line 249) is drawn before `<Spline strokeWidth={2}>` (line 258). So the 2px line covers the 1px dashed rule where the series is at 100.
- `zoom/montage-g100-390.png` confirms this. In flat 100 the rule is hidden and the gutter "Goal 100%" marks it. In the final-bucket and cliff states the dashed segment becomes visible as soon as the line leaves 100.
- **The v7 description is truthful.** The goal is always labelled, and it is drawn wherever it is not under the line.

## D1 and focus spot checks

- **D1.** `zoom/d1-dark-390.png` shows steady, pending and error at 390 in dark theme. The positions of Clear filters and Export Excel do not move between states. "Updating briefing" fills the reserved slot. The error alert and Retry render below the toolbar. The 23px right slack in the steady state is visible and cosmetic.
- **Focus.** `png/0007-focus-cell-tab.png` shows the dashed selected cell (84) and a distinct double focus ring on the next cell (75). The page reads correctly with goal 100.

## Coverage limits

- **Sweep provenance.** The 684 sweep cases are URL-navigated SSR states measured by a read-only `evaluate_script` (`measure.js`). They are not 684 native filter clicks and not 684 screenshot judgments. Native control actions were limited to the D1 flow, the settings-goal changes, the filter, focus and cell smoke tests, and the export.
- **Screenshot coverage.** 684 sweep PNGs exist: 144 crops each for light 1440, 1024 and 390, 90 for dark 1440, 90 for dark 390 and 72 for dark 1024. I personally viewed these:
  - the four `png/hires` crops
  - `zoom/z0004-mixed-start.png`
  - `zoom/z-g95-light-flat100.png`
  - `zoom/montage-g85-light-final30.png`, `zoom/montage-g85-light-1024-180x2.png` and `zoom/montage-g100-390.png`
  - `zoom/d1-dark-390.png`
  - `png/0007-focus-cell-tab.png`
  - `png/sweep/g85-dark-390-mixed-90.png`
  - the Paper capture

  Every other case rests on the measurement lever plus the driver's own sampling.
- **Measurement scope.** `measure.js` checks every value and goal label against all horizontal grid and goal rules (stroke-edge gap), the spline (sampled every 0.5px), dots, bars, other text, the axis, the SVG box and the nearest clipping ancestor. It does not measure contrast, and it uses canvas ink metrics rather than raster pixels.
- **Paper.** Fresh Paper MCP was unavailable this round. `get_guide`, `find_nodes` and `get_basic_info` all timed out. The Paper relationship above relies on the saved read-only capture from earlier the same day (v5 evidence), not on a fresh Paper read.
- **Unrun.** These were not run, by v7 or here: a live fallback-font render, a live stale-reply race, the export failure path, real server or provider faults, scoped or foreign actors, Mac/HTTPS/T3-browser, and an actual screen reader.

## Corrections to the v7 report

1. "Paper never shows this state" (objection 1) is wrong. Paper's start label crosses the 80% gridline in the same way.
2. "In the common case [value labels] are pixel-identical to Paper's placement (drift 0)" is overstated. A census of the sweep JSON finds drift above 0.5px for 352 of 684 start labels and 342 of 684 end labels. Displacement is routine, not exceptional. It stays bounded: the maximum is 11.7px and none exceeds 15px. It remains associated with the right dot in every viewed screenshot.

## Unresolved objections

None are blocking. The objection 1 polish is optional and described above with its verification cost. Root still owns integration, the remaining nonvisual lanes and publication. This judgment does not declare 1503 complete.
