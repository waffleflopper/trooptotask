# Independent v7 artifact and composed local handoff review

**Scoped owned local handoff: ACCEPTED at tested source `8cdd5310cba49fb2782ccd9da0af39ea8b9c5106`, against integrated/reviewed base `ee1ca2b275d71cd0b9a51367b58c4754a687a443`, with the retained notes and evidence limits below.** Actual v7 observations close the new disappearing Clear filters, export-error Retry and redundant Focus preload findings. The complete pinned source reviews and earlier actual artifact reviews supply the unchanged model, detail/paging, role and print coverage. No new actionable objection was found that blocks this bounded owned local review. This supports the user's authorized same-DRAFT push-and-stop handoff after separate integrity review of final doc/artifact successors; it does not accept the whole current-main candidate, CI, readiness, merge, deployment or remote database release.

**Full current-main candidate acceptance remains BLOCKED.** Actual v8 governance exits1 behind main-at-validation `49cacc665891b7e0edf95c6bb97993b8ca9837a2`; Phase8 integration is explicitly deferred and no bypass/rebase/merge was performed. Latest observed main is now `9b6f9b74d76af91895cf16b063b157c1927eb1c6`. Neither incoming version is semantically accepted here. Six other actual v8 checks pass, including689 files/6892 tests and production build. These are root-recorded results, not commands executed by this reviewer.

This is independent **offline source-context/artifact analysis**, using inherited model, Poteto generic persona and t2t-engineer with repository requirements. It is not independent browser execution or model diversity. Claude owns actual native execution and bounded visual judgment; I audited actual bytes, structured observations, accessible snapshots, native request IDs, XLSX XML, restoration and cleanup proofs. No browser, screenshot viewing, layout judgment, app/test/service execution, network, Git mutation, source edit, remote SQL or nested agent was used. Sole writes are this report and exclusive `.verification/review-1504-final-v7-e8b17/` scratch.

## Pin, package and complete integrity

| Binding | Actual value |
| --- | --- |
| Tested/runtime source | `8cdd5310cba49fb2782ccd9da0af39ea8b9c5106` |
| Reviewed integrated base | `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Main at v8 validation / governance failure | `49cacc665891b7e0edf95c6bb97993b8ca9837a2` |
| Latest observed main, mechanical census only | `9b6f9b74d76af91895cf16b063b157c1927eb1c6` |
| Candidate | `adab9515aab5c4d0e8c4809125788b137b4c3fc538f581bd9a8eb55a6c01614e` |
| Session | `175e46b6-bbc7-4ff8-8555-00e0d167c893` |
| Origin / owned worker | `http://127.0.0.1:38327` / worker1 |
| Configure Organization A | `dc75955a-f25d-44ed-aec3-d62f3515fe24` |
| Native browser | local `/usr/bin/chromium`, Chromium152.0.7977.82 Arch Linux, provisioned false |
| Archive | `docs/verification/training-reports-1504/final-attempt-v7.tar.gz` |
| Archive bytes / SHA256 | 1,326,574 / `b1f5e57947205e53a5663603bb75c3b91146f292152d84a51ec887f9684d3ff1` |
| Actual expansion | `.verification/packaged/1504/final-attempt-v7` |

Actual inventory has732 unique payload paths, all exact SHA256 matches. Actual expansion has733 files including inventory only; no missing/extra payload. Tar has733 unique regular members, all actual member bytes equal expansion, no special/link member. Inventory is archive integrity, not application behavior. No PDF is present; two real saved XLSX files are present. Images were byte/hash-verified and credential-scanned but never viewed.

Actual `root-source-checkpoint.json` has390 rename-aware current-main49 diff paths/pins, matching actual `git diff --name-only 49 8cdd` and all actual blob/deletion hashes. Its scoped binary source patch (`src scripts supabase .agents/skills/verify-trooptotask`) independently reproduces SHA256 `2504dc16caaaaf7cca428f30824694ab8bc44154e0f09a38c0a94f8eb68f9a42`. This main49 patch pin is not the integrated-ee1 source-review patch and does not imply semantic incoming acceptance. Every actual 146 owned source-v4 census pin and20 selected unchanged dependency pins reproduce the actual 8cdd Git blobs without mismatch. The source checkpoint's initial `live acceptance pending` state is a preserved pre-launch checkpoint; actual driver/root closeout supplies the subsequent results rather than silently rewriting it.

At initial read, runtime HEAD remained8cdd and v7 archive was an untracked packaging successor. Final documentation/validation packaging is outside this report until separately reviewed. Doc/archive-only successors can preserve this tested source identity with metadata/integrity checks; they cannot be described as fresh app runs, and actual runtime/source changes would need affected evidence.

## Receipts and command classification

Actual v7 receipts use separate `drive/NNN-name.json` with exact `argv`, `exit`, ISO `start` and `end`; they are not the older JSONL/index format. All210 are uniquely named with valid four-field schema and monotonic start/end. Actual stdout of all 210 parses as whole JSON and all 210 stderr files are empty. Counts are207 exit0 and3 exit2. I parsed28 read-only native evaluation values and14 native network lists, all complete (`hasNextPage:false`, `invalidPage:false`). The actual 28 evaluate arguments have no handler invocation, focus/click, dispatch, fetch, storage-write or checked/value mutation pattern; they read state. There are41 native action commands (click, key, hover, navigate/reload or resize), distinguished from snapshots/probes/actor setup/helpers and waits. Two hundred ten successful user actions are not claimed.

| Nonzero receipt | Actual argv/outcome | Disposition |
| --- | --- | --- |
| `160-settle` | `wait_for`, page 2, nonexistent marker `__nonexistent_settle_marker__`, timeout2000ms; stdout INCONCLUSIVE/DEVTOOLS_TOOL Timed out | Deliberately unsuccessful2-second bounded observation window after first hover. Not successful UI proof. |
| `163-settle` | Same nonexistent marker and2000ms after second hover; Timed out | Same qualification. |
| `176-settle` | Same marker, timeout1500ms after active30 click/Space; Timed out | Deliberately unsuccessful settle window, not successful keyboard/application result. |

No stale-target/tool repair is hidden in these receipts. Timed-out waits are retained as failures even though deliberate; the before/after network/state observations, not the waits themselves, establish behavior. Normal successful waits are likewise only observations, not end-user activations.

`network state` helper GET entries report `count:0` and `ids:[]` even for underlying requests. That cannot establish request uniqueness. Real IDs and before/after complete native `list_network_requests` establish one/no-extra claims below. Synthetic503 hooks fail before underlying request dispatch, so those503 failures appear as hook status and visible error, not a native network503 falsely invented from a missing request. Real200 retries do appear in native network lists.

Actual dispatch records provider `claudeAgent`, model `claude-opus-5-5`, medium effort, no inherited history; governance explicitly blocked. Driver report's conclusions were checked against actual observations and corrected/qualified where needed, rather than treated as proof.

## Independently counted original data and source context

Root-original OrganizationA has three SPC soldiers: Able/68W/Medic/Alpha, Baker/11B/NCO/Bravo, Unassigned/68W/NCO/no group. Required applies to all three; Targeted applies to68W excludingNCO, hence only Able; Optional stays excluded. One original completion is Able Required, ID `67c3cbe3-09e7-4c3f-ae16-ad154981bd05`, completion2026-09-27, expiry2027-09-27, unchanged after the run. Required type ID is `f8ed0d7d-90d7-4669-b199-cb23e28f939e`. Thus original applicable denominator is4 requirements, ready1, missing3, expired0, horizon lapse0, literal readiness25%→25%. Alpha aggregate is50%; its Required cell100% and Targeted0%. Total Required33%, Targeted0%, aggregate25%. Driver shorthand “Alpha100/0” is valid only for its two type cells, not Alpha aggregate100%.

Actual native Reports click005 and baseline snapshot 006 show these figures. Native network007 has Reports route-data GET139 and no summary API fetch; server paint is used. Baseline1905×2053/DPR1/light/expanded sidebar and original two mode-watcher localStorage keys are recorded. Source-v4 retains initial server paint, canonical/session/url, data/export/model/auth/performance contracts. This round adds no providers, mirrors, effects, chart changes, globals, response autofocus or print/CSS changes.

## Toolbar and empty-panel Clear: actual closure

Configure page 2: native 30 andMOS produce legitimate summary143/144 and URL `?horizon=30&rowsBy=mos`. Probe013 locates exactly one Clear outside the briefing. Actual015 pointer click activates that toolbar button under documented held transport. Held probe 016 and snapshot 018 show it removed, labelled `SECTION#training-briefing` focused, tabindex−1, busy true, Updating briefing status, checked90/Group, and loaded URL still30/mos. The displayed report remains the last loaded briefing while canonical controls show the attempted reset. Release020 completes; probe 022/snapshot 024 keep region focus with busy false, defaultURL,25%/1/0/3/0 and correct Group grid. Native before012→after025 adds exactly one200 request 145 to the canonical summary endpoint, no page-data or detail extras. This closes the source-reproduced toolbar disappearance failure at 8cdd.

Second toolbar attempt028–040 recreates30/MOS and clicks Clear032 under hold. Probe033 shows region focused/busy. NativeTab034 changes active focus to MOS radio (035); after release036, probe 038 and snapshot 039 retain exactly that active radio, busy false/defaultURL. Final complete list107 separately records146/147 legitimate30/MOS requests then exactly one canonical148. No response-time focus steal occurred. MOS is unchecked after the reset while still a roving Tab destination; that is N1 below, not a checked-value regression invented from focus.

TrainingEmpty page 3 is a separate isolated context with zero applicable requirements. Native30 causes two visible Clear controls. At1440×900, actual snapshot 050 confirms panel UID21_1 is focused, distinct from toolbar21_0. Hold053 plus actualEnter054 removes both, focuses persistent labelled briefing region, busy true and90 checked (055/snapshot 056). After release059,061/063 show region still focused/defaultURL, no-applicable explanation and disabled Excel;062 confirms no percentage text. Native051→065 adds exactly one canonical200 request 134. This directly repairs v6's actual panel BODY result at 77.

At390×844, native 30 followed byTab reaches panel UID27_1 (072), not the toolbar. HeldEnter075 gives the same stable region/busy/removed-control state076; after release078,080 preserves region/defaultURL. Complete network082 shows one legitimate30 request 135 and one canonical136, no extra report calls. Viewport is restored1905×2053 at 084/085. Empty actor's actual preference/progress baseline041 and after086 are identical, qualified as driver-owned Empty baseline rather than root-original Configure capture. Claude's inspected empty screenshots support its legibility judgment; this reviewer did not view them or independently certify truncation/layout.

## Export-error Retry: native closure, real requests and saved bytes

Actual090 pointer Export under fail hook088/capture089 produces visible503 alert with Retry (092/093) and no captured Blob095. The ordinary Export button is focused in this fast synthetic-failure state. The hook state094 records503; it is not an actual dispatched server503.

After restoring fail and arming hold, nine actualTabs100 reach focused alert Retry in101. ActualEnter102 clears/disconnects the alert and moves focus to stable briefing region (103/snapshot 104). Header says Exporting.../disabled. Briefing `aria-busy` remains false because that attribute tracks summary loading, not export; no claim is made that export sets it. Hook105 is held and Blob106 is not captured yet. Complete native 107 adds exactly one real export GET149/status200. On release109, probe 111 and snapshot 114 retain region focus, no alert, normal Export label. Blob113 is now captured; actualsave115 hashes match the exact packaged workbook.

Second fail/hold scenario119–140 produces another visible503/noBlob, then actual 128 pointer Retry focuses the region while held129. NativeTab130 moves to MOS131; after release133,135/snapshot 137 retain the same radio. Real export200 ID 150 is the only new export in that scenario, as the later complete native 157 list confirms. Saved138 second workbook has identical worksheets and differs only ZIP member `docProps/core.xml` from the first. Thus both Enter and pointer Retry, during-held focus and response no-steal are actually established at 8cdd. The old77 source inference/component red is not relabelled a native success; the fresh8cdd observations close it.

Normal Export144 is a separately retained behavior: real 200 ID 151, captured11764-byte Blob149, no alert, but immediate145 and settled147 active element are **BODY**. This is candidly not a clean focus retention result. The normal Blob was observed but not separately saved; do not certify its unsaved byte contents by borrowing either Retry file's hash. See retained usability classification below.

### Actual XLSX XML, not helper decoding

I parsed actual workbook relationships, shared strings, ordered sheet declarations and every actual worksheet cell from both saved ZIP buffers; helper workbook118 outputs are only corroboration. Exactly five ordered sheets `Summary`, `Forecast`, `Hot spots`, `Focus`, `Requirements`, no formulas. No extra or missing ZIP member between files; only core-property metadata differs.

| Actual saved workbook | Bytes | SHA256 |
| --- | ---: | --- |
| `drive/115-training-report-retry.xlsx` | 11763 | `dbf468e122b9e53f318a157d15833518c928fb07af7de0d5f02305d965d77076` |
| `drive/138-training-report-retry-tabaway.xlsx` | 11764 | `99bdd5e7e34cf55b17e25fb40e83897ba04af6f4bea6550ba4ccf1dae159ccf7` |

Summary is default full scope3 soldiers/asof2026-10-04/end2027-01-02/goal90/ready1/applicable4/missing3/expired0/lapse0/readiness25→25/drop0, with all eight filter display rows. Forecast is today plus13 bucket endpoints (14 data points), allready1/25%, zero lapses, exact end2Jan and short final28Dec–2Jan. Hot spots are Bravo,Unassigned,Alpha,Total; Alpha pertype100/0 aggregate50; Total33/0 aggregate25. Focus has Required standing gap2 people/2 requirements,25→75 and Targeted gap1/1,25→50, exact fixed sentences. Arithmetic independently matches1/4,3/4,2/4. Requirements are exactly three pairs, in order: Able Targeted, Baker Required, Unassigned Required; all Not Done, no expiry/lapse and No horizon lapse. Ready Able Required, Optional/N/A and foreign pairs are absent. These full-scope exports occur before opening the narrow30/mos Focus detail; v6 separately establishes full30 affected export while a28-row detail is open. No fresh detail-open export is invented in v7.

## Focus preload and correct detail: native closure

Native30 thenMOS154/155 generates legitimate152/153 and shallowURL30/mos. Probe158 reads two real Focus anchors, href `#training-affected-soldiers`, opt-out off, no aria-current. That attribute read alone does not prove preload behavior. Nativehover159 targets actual View2 soldiers, followed by deliberate failed2-second marker wait160; complete native 157→161 lists are identical at 153 requests. Nativehover162 targets actual View1soldier, wait163; native 161→164 again identical. Both hover windows added **zero requests of any kind** in the captured complete lists, including zero Reports page-data/summary/detail. Native hover was available; no evaluate-dispatched hover or helper substituted.

Actual165 click View2 soldiers adds exactly one new native request 154, `GET api/training-reports/detail?horizon=30&rowsBy=mos&scope=focus&focus=gap%3Af8ed0d7d-90d7-4669-b199-cb23e28f939e`,200. Before164→167 and subsequent170 establish no duplicate page-data or summary. Snapshot168 has focused Affected soldiers region, exact standing-gap explanation2 requirements by3Nov, range1–2of2, Baker/Bravo and Unassigned, Required/NotDone. Probe169 has selectedCells empty, current View2 soldiers=true, detail SECTION ID and unchanged query/no hash. This proves correct scoped activation and absence of the v6 redundant route-data request at fresh8cdd, closing N2 without treating a source attribute assertion as browser proof.

Native reload171 shows actual SSRdocument155 plus shell notification-count only in173; no summary API. Snapshot172 restores30/MOS/25%, detail closed. Active30 pointer174 thenSpace175 add no request compared173→178, and final177/179 stillshow30/MOS checked and radiofocus. **Limit:** this v7 pair has only one checked-state observation after both activations, not a separately preserved after-pointer state. It cannot independently re-prove the after-EACH invariant that exposed the old two-click bug. Per-activation active-option acceptance remains supplied by v5's12 separate pointer/Space observations and v6's10 separate repetitions, with canonical bindings byte-identical through8cdd. V7 contributes a combined smoke without upgrading it to new all-six/per-activation proof.

## Retained notes: candid severity and requirement assessment

| Note | Actual evidence / independently established scope | Classification for this handoff |
| --- | --- | --- |
| Normal Export success ends atBODY | Native144→145/147; button mounted but disabled during fetch; successful unsaved Blob | **P3 retained usability debt, non-blocking for this bounded correction.** The issue demands correct download/error/retry, not a newly specified post-download focus destination. Parent explicitly retained normal Export focus behavior. This does not pass an all-actions-focus-retention claim. |
| Programmatically focused briefing region has no outline/box shadow |062 reads focusVisible true, outlineStyle none/width1px, boxShadow none; source persistent noninteractive labelled section/classoutline-none; visual no-indicator judgment delegated | **Retained accessibility/visibility limitation, not a newly introduced source defect.** Stable programmatic section focus and label are real; no broad focus-visible/a11y compliance verdict is issued. No explicit requirement here demands styling the noninteractive destination, and no interactive-control ring regression is proven. |
| N1 rovingTab may land on uncheckedMOS after reset |035/038and131/135 activeMOS, checked90/Group; unchanged shared toggle | **Baseline-unestablished behavior note.** No base regression or new selection failure established. Checked canonical values remain correct. |
| N4 Print brief wraps legibly at 390 | PriorClaude visual observation/sourceunchanged; no v7print/PDF | **Usable delegated visual note**, not an actionable layout defect established by this reviewer. |

Normal Export's focus-relevant `onclick={exportExcel}`, disabled expression and Exporting/Export label are already present at historical `3cc4ec4cd5ae3839c77fdb9da24ab71f29a9551b`, independently read from actual Git. Whole button bytes are not identical that far back: later variant=outline and multiline formatting differ. Ordinary button bytes are exactly equal source 77→8cdd. Thus the disabling mechanism is retained; a native historical3cc4 BODY run is not claimed. The fact it pre-exists does not make it good behavior; it remains disclosed usability debt. Expanding the mandated disappearance repair to normal-button policy or adding response autofocus would change an explicitly retained boundary without a current product requirement. No new defect was dismissed merely because Claude called it minor or because it pre-existed.

Likewise, computed outline-none is a real limitation rather than a fabricated clean focus ring. The destination is noninteractive, programmatically focused, persistently labelled and outside ordinaryTab order, using the existing detail/report seam. This round changed no CSS/layout. This acceptance establishes durable focus placement/no-steal and scoped keyboard actions, not universal screen-reader behavior, visual focus indication or accessibility conformance.

## Composed requirements, consumers and print acceptance

I rechecked the source-review pins and every actual v1–v6 archive, expanded inventory and tar member. Every payload, file set and member byte still matches. Their qualified observations carry forward; later success does not reconstruct missing or overwritten captures or convert unavailable lanes to PASS.

| Earlier failure at its actual pin | Distinct correction and proof |
| --- | --- |
| v1 print transport failed, no PDF; detail Retry BODY at 2e3 | Structured-content launch correction and real native Enter Retry/print transport in v2; v2 remaining failures retained. |
| v2 boundary pager BODY and surplus portrait/textless page; v3 same surplus page | Ordinary boundary covered v3; print chrome/Toaster correction and v4 short1/long5 landscape metadata/text accepted with delegated visual judgment. V2 beforeprint0 attempts remain rendering-only. |
| Disconnected pager on delayed one-page shrink P2 at 0683 | Source 53ab guard, independent positive/moved-focus-negative tests, v4 actual shrink/page-clamp/focus/no-steal proof. |
| Active mandatory radio unchecked P2 at 53ab | Source a586 canonical getter binding, red/green, v5's12 separate pointer/Space observations and v6's10 extra repetitions. |
| Report Retry BODY, stale selected cell, short heading/table split P3 ata586 | Source 77/source-v3; v6 native click/Enter held/no-steal and cell closure; actual short four-page PDF has heading/table together on page 4. Visual spacing remains Claude's judgment. |
| v6 empty Clear BODY, redundant Focus page-data, source/component export Retry BODY at 77 | Source 8cdd/source-v4; fresh v7 native closure above. Old findings remain true at 77. |

The complete source-v2/v3/v4 chain covers all 146 owned paths at 8cdd (53A/89M/4D,23 archives),70 inherited access dependencies and direct/reverse consumers against integrated ee1. Model, server, API, export, workbook, session, status and migration bytes are unchanged by the latest correction. Five OperationalMatrixRoot consumers retain controlled null/identity versus omitted internal memory semantics. V6 Training Matrix open/Cancel/no-write and exact completion readback keeps its original scope; ICT was not newly exercised live. V1/v3 role/scoped/foreign read observations remain distinct from mutation-denial, RLS or remote policy proof.

Print composes without a new v7 PDF. Source-v4 confirmed Page DOM equals source 77 apart from authorized handler/callback changes, and Focus DOM apart from the hidden preload attribute. All20 selected print/matrix/session/chart/workbook/UI dependencies reproduce at 8cdd. V6's four PDFs have15 landscape pages: empty 1, short detail4, cohort25 rows5 and100-page-size/28rows5; each has native prestate beforeprint1. Heading/table placement is text-proven; no extra portrait/textless or header-only table page is present. The v6 save-guard refusal and repair timing stay qualified. No chart, layout, CSS, detail marker, pagination, matrix or print behavior changed at 8cdd, so action/preload evidence composes with those PDFs. They are not fresh8cdd outputs. No physical print, dialog or v7 visual-PDF verdict is invented.

Coverage remains proportional: actual defaults, dated import, filters, detail, paging, scoped/full workbooks and retained Training/Personnel/Dashboard spot-checks combine with meaningful reviewed lower-level clock, model, cliff, ordering, parity, settings, authorization and migration evidence. Large-population performance, five-or-more-lapse waves, all three Focus slots, many-column print, Organization/sign-out races and every feature-map journey are not fresh live proofs. Personnel Availability, Critical Tasks and Rating Scheme lanes remain unavailable. Full raw Organization export and Onboarding journeys remain unrun, with unchanged source/lower-level consumer coverage retained.

V1 truncated successful summary bodies, overwritten names and foreign-observer mismatch remain historical limits. V3 whole-body known-name summaries and native B status improve their own observations, not universal field-by-field non-disclosure proof. Earlier LayerCake/negative SVG print warnings remain unresolved observed limitations. V7 has no fresh console or PDF that erases them. No clean-console claim is made.

V4 active on-screen toast omission from actual PDFs remains covered at its pin. Native Alt+T was observed only after the print dialog closed; a modal-open keyboard test was not established. Sidebar reload/expanded behavior outside #1504 retains its unchanged-source qualification. These are historical limits, not fresh v7 actions.

These limits do not demonstrate a new owned correction regression or contradict scoped Training requirements. They prevent sweeping whole-app, current-main, security or visual acceptance. The release obligation and governance blocker remain separate from clean owned local review.

### Actual previous archive continuity

| Version | Payloads | Archive bytes | SHA256 | Current recheck |
| --- | ---: | ---: | --- | --- |
| v1 | 1364 | 8194402 | `0347ab3ccd6e78bc303fe65c8171126e9b0b98d4e9bf108b9cdd4ad33ab85104` | allpayload/set/tarbytes match |
| v2 | 832 | 4659392 | `a7eebee6b56f22187bc73da4b00b07f75f74bae655bd3e65d39b9ba2c72a7c05` | allpayload/set/tarbytes match |
| v3 | 1015 | 5452614 | `0231f92582ce913d59ff37e09cfd9a5316a33b6dbe5f4f734e8abb68f44791cc` | allpayload/set/tarbytes match |
| v4 | 1156 | 7392445 | `81af91ee6e2fec495d5426d71e35f0c61e2dfae1a32e5e07c5b1949ae3220d98` | allpayload/set/tarbytes match |
| v5 | 749 | 1755326 | `3227b88d8b18171dc5b9416a729d2252484e854cfbe0bdab7bca481ab1356aaf` | allpayload/set/tarbytes match |
| v6 | 944 | 3621597 | `b829e3a7c14995246df148fc0e487e9baad07c715cdadf137b8abc764f51f644` | allpayload/set/tarbytes match |

### Unchanged selected dependency pins

All below reproduce actualsource 77→8cdd continuity and actual 8cdd blobs; no fresh runtime test of every consumer is implied.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `src/app.css` | 14610 | `8536b4f70d589435a87181e445ab5a4d5e607e8351d855b049eade028b7683a8` |
| `src/app.html` | 1201 | `f24a686265cca5cf2eeba816e7667a6d664d2ddd888147b2d86a2cf2606a0b7f` |
| `src/features/critical-tasks/components/IctMatrix.svelte` | 15559 | `4d4fbc1417f856edf2ccf23770a5ae6c19d30a5471a0982c9a88e6877851d272` |
| `src/features/critical-tasks/components/IctReadinessMatrixTable.svelte` | 5933 | `70ae5a9f40d6024196271cb0226dfb1895f778a61d4fddf4b8bb45ad464b63da` |
| `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | 5910 | `b279c8b2482ff74495785067e66270b977dcba000e93651d14bbe2ad14a7e443` |
| `src/features/training/components/TrainingMatrix.svelte` | 11398 | `c36e04aca73ddd84fdf6d464f1d7c33f699de15e8b51f55af85344a59b34731b` |
| `src/features/training/read-model/trainingBriefingSession.svelte.ts` | 6735 | `cec6544443d09a1a5d61a06b0b0a6bb1bf5db48fff7a25a0dac36e3ea239105d` |
| `src/features/training/utils/trainingBriefing.ts` | 26284 | `fb6bf3af5c5fd4e4287c8a159fda126eb6fe3247853c02544effc08eb33c6863` |
| `src/lib/components/ui/button/button.svelte` | 3844 | `82dcaad7df84064398e90eb2171beb42406983d3aab0b1876ee49e997f123d86` |
| `src/lib/components/ui/operational-matrix/OperationalMatrix.test.ts` | 3098 | `ef04b68487c938864a367ce1d06cdcc9b1f2218af63611c748bbc2122923f19d` |
| `src/lib/components/ui/operational-matrix/OperationalMatrixTest.svelte` | 3394 | `68e363482aa4702b40ab7c0825a77efcb4fd7450bf33e06f2e5843f6aab894f2` |
| `src/lib/components/ui/operational-matrix/cell.svelte` | 2150 | `ccc90d5025d3055ff5dea862cea5e75671c3f47b0cf43d105f773d5e035f38cd` |
| `src/lib/components/ui/operational-matrix/context.ts` | 1153 | `27752ce1c597b8d3068f5f64c6ba5627d7ffd50b824c283af6ea65fb43332d51` |
| `src/lib/components/ui/operational-matrix/root.svelte` | 2456 | `975d2518edd5cdbe57f9f441f8031246cc1c9a954ba1faea59f8fabf4de191ed` |
| `src/lib/components/ui/operational-matrix/types.ts` | 939 | `e62d5f9fa1d311f4f8d1297ad0e546b9052a579e9b5ab652487afe44409db70d` |
| `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | 10377 | `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` |
| `src/lib/components/ui/report-workspace/report-workspace-root.svelte` | 546 | `cc224212cbf54cca16dc68a79f6ef180bde77e64e1b09a8bbf7d6bb8a2db4101` |
| `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | 2752 | `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` |
| `src/lib/components/ui/report-workspace/report-workspace-state.svelte` | 1885 | `a978880a5b04ee73ea9ce8588d8199dc9189320ee708a38ada2aa291597f2490` |
| `src/lib/utils/workbook.ts` | 4679 | `e6c0a7944bb2a63bdc258c974dd2e7fc7bd05182e25ce4aa62d14a93b5fb5ef9` |

## Exact restoration, privacy and cleanup

All ten root-original/restored A/B table files are byte-identical and fully JSON-equal. Driver final184 objects equal root originals too. Counts A/B are personnel3/1, completions1/0, types3/1, views1/1 and organizations1/1. Configure original/restored preferences and driver185 are exact 211 bytes SHA256 `1d90413f1beec453b5a393fb28c99c6303ea70c1470bbc17adb05217a919070a`. Empty actor041/086 separately equals its own baseline, not a root-original capture.

No seed or application UI/provider row was created. Root clean-seeds reports cleanedtrue/artifactHttpSessionsClearedtrue. The helper audit's generic “journaled temporary training-pages cleanup” wording is boilerplate, not proof of seeds never created here. Exact ten readbacks establish no residual row/field change.

Final Configure Clear180 returns default URL,90/Group, region focus,1905×2053/light/expanded sidebar and original mode-watcher keys (182/183). Empty viewport is restored1905×2053; default URL and preferences are recorded. Neither theme nor sidebar was toggled. Final network187/188 shows both pages unarmed, empty calls and heldfalse. Export restores116/139/151 each return restoredtrue. There is no separate final export-state evaluation: restore receipts and profile cleanup support closure, not an invented evaluation. No print observer/PDF was used.

Root doctor start, after restoration, closeout and driver001/189 match exact binding/PASS. Root3 launch/12 fixture/15 closeout receipts all exit0 with parseable stdout JSON and empty stderr. Cleanup is cleaned/PASS. The four exact-owned-absence process records include expected PID/start/cmdline fingerprints and exactOwnedProcessAbsenttrue. ProfileProcessIds is empty; privateWorkerDirectoryAbsent/proofPayloadsStillExist are true. These are captured historical proofs, not reviewer live-process inspection.

| Owner | PID | Expected start | Cmdline SHA256 |
| --- | ---: | --- | --- |
| supervisor | 548388 | `155182803` | `210dea5922d87d5ff915ed6eb494748ccfeb1d11f6682572a950f821ea85501c` |
| appProcess | 557156 | `155188544` | `804bd2e64af0c2a3aad8f30dc6f471eb246977bd1ff554cd9731d7a244a8c914` |
| mcpProcess | 557219 | `155188610` | `bc5c4c5df883c788b5b4a4aacfbc325d98db9a7c7e413f0e8b49167634bc832e` |
| browserProcess | 557231 | `155188646` | `827476123339f3bad0c2c488190249c040bbe5ec5cfc442e1a330201c782f5b6` |

All733 actual package files and decoded workbook cells were scanned for concrete JWT, Bearer, private-key, secret-token assignment and `sb_secret_` patterns: zero matches. This is bounded pattern assurance, not a guarantee about unknown strings or image-only content. No screenshot was viewed/OCRed. Synthetic identities are preserved. Owned absence proof is distinct from shared processes, which were not inspected or touched.

| Table | Org | Original/restored bytes | Rows | Exact SHA256 |
| --- | --- | ---: | ---: | --- |
| `personnel` | orgA | 1469 | 3 | `12279d00343f185b8c9fdedccffb8883b112ce93d475bc17faf1d4b4900128cc` |
| `personnel` | orgB | 559 | 1 | `52ee3bba5d50244f5a29498d6ba57dbaaf396ab7417ee681581cf40b80b334db` |
| `personnel_trainings` | orgA | 592 | 1 | `09642e6120d3b5f01d1c3b05b935f6c545cdd5b0a6d54870f87a0ac08381bd09` |
| `personnel_trainings` | orgB | 91 | 0 | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |
| `training_types` | orgA | 2255 | 3 | `3f96de07072874fa02a8a4f01fdf07eaa4b6759b5ed571e72741cab5041998ce` |
| `training_types` | orgB | 792 | 1 | `f7a5c739b13202e196dc6d14f476d51fd2a04e1346dbb604a3202581cdbbebcd` |
| `training_views` | orgA | 556 | 1 | `9377a3208c302da4128fe7dac428eb72062932325613b8dc3c9286cf159ffa7c` |
| `training_views` | orgB | 505 | 1 | `26df0c46caf5c7b7da709da15e5b95cebb2664b944c0698f4f265408520b7dfd` |
| `organizations` | orgA | 656 | 1 | `9593ae2a71646941086d564bea54830d7d4629300a0da130f3950e88c42363b5` |
| `organizations` | orgB | 656 | 1 | `58a7f54ee5722ad039fd04e32de3e28951a869238ffb5e3989fb1d86906af57f` |

## Main, gates and final handoff boundary

Historical main49→8cdd has390 rename-aware entries/397 endpoint paths,251 incoming-only. Source-v4 recorded the complete census and blocked semantic acceptance. Latest main `9b6f9b74d76af91895cf16b063b157c1927eb1c6` (`test(ui): prepare shared interaction verification (#1529)`)→8cdd has398 rename-aware entries (60A/309M/22D/7R) and405 endpoint paths (67A/309M/29D),259 incoming-only. Both have merge base ee1. Refreshed mechanical census pins every immutable main/head endpoint and rename entry; it is not semantic review, integration, conflict resolution or rollback approval. Counts exclude the uncommitted v7 archive/future docs, which need final metadata review. Historical390/397 remains actual v8/runtime49 binding.

V8's seven entries are unchanged and equal the runtime checkpoint: format0, format-check0, lint0, governance1, check0, test0 and build0. Tests pass689 files/6892 tests; check0 errors/warnings, lint15 warnings/0 errors, buildPASS with retained optional-dependency warning. Governance reports behind49/module-boundary comparison unavailable. That is a real failed gate. No guard change, exception, allowlist, reduced scan, bypass or unauthorized integration occurred. Main advancing again does not create a new unchanged-owned-runtime failure; current-main acceptance remains blocked.

The Definition of Done permits authorized push/review handoff with validation pending and requires honest disclosure before acceptance/merge. User boundary is clean owned local review, normal push to the same DRAFT PR, and STOP. This report supplies qualified review, not ready/hosted-review-request/monitoring/rebase/merge authority or evidence. Root's final doc/artifact successor integrity review must preserve tested source/runtime/gates and blockers. Harmless packaging/prose alone does not imply fresh app gates.

Unchanged goal migration `supabase/migrations/20261004100618_training_readiness_goal.sql` is484 bytes SHA256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`. Historical isolated fresh/upgrade/security evidence keeps its pins. No SQL executed or new remote/RLS claim is made. Production application remains a separately authorized, unperformed release obligation.

**Remaining actionable acceptance blocker:** current-main integration/governance/current-candidate verification, explicitly deferred. **No remaining actionable new owned-source/native-correction objection** was found. **Retained notes/limits:** ordinary Export BODY usability debt, noninteractive destination outline-none, N1 baseline unknown, N4 delegated usable wrap, earlier unavailable/unrun consumer/security/performance/print-console limits. Scoped local handoff acceptance is not unrestricted whole-issue/current-main acceptance.

## Reproducible audit and report pins

Exclusive scratch contains `inventory-audit.json`, `parsed-outputs.json`, `workbook-audit.json`, `native-action-audit.json`, `behavior-content-checks.json`, `restoration-privacy-audit.json`, `source-pin-audit.json`, `latest-main-census.json`, `retained-focus-source-history.json`, `composed-review-pins.json` and `prior-package-continuity.json`. They preserve actual set/hash/receipt/request/focus/content arithmetic and scope dispositions. All prior review reports were rehashed, below.

| Prior review | Bytes | SHA256 |
| --- | ---: | --- |
| `.verification/1504-independent-cumulative-source-review-v1.md` | 55325 | `c54fb7fc6588687f14e1af38c5b6e910de1a9e1b619b55ef9ec5470be036bdeb` |
| `.verification/1504-independent-final-source-review-v1.md` | 60379 | `a1419375caacc10b52abe51f0f911e215ba6395303b468c3942a3d1fa4ee2ae1` |
| `.verification/1504-independent-final-source-review-v2.md` | 65587 | `a59d7e2f4cee65b43eae768f47fa3936a444529d2ae7f5d6337b8d4199ea342e` |
| `.verification/1504-independent-final-source-review-v3.md` | 24751 | `03e2eb2a4cf5f28430386053f7572351ca1e7e3358767dc25f23928053c901d8` |
| `.verification/1504-independent-final-source-review-v4.md` | 53687 | `6cde63e103854c17df6a1ed59d8b408d444dcaa1f01f1a6f75273ef440279371` |
| `.verification/1504-independent-final-attempt-v1-artifact-review.md` | 26596 | `702092b2c8ded6d3a2fce5e4c43d33a6018c9710771dd57636157875662f8fe1` |
| `.verification/1504-independent-final-attempt-v2-review.md` | 29267 | `8493d0819228c9c5d83faa2df0d34da334b2446084fdc5f7665ece05cfec1d2a` |
| `.verification/1504-independent-final-attempt-v3-review.md` | 34101 | `eb7acdc372a9223c41821e911777bf30249f86d07cfa2d65bb642915a886bc53` |
| `.verification/1504-independent-final-attempt-v4-review.md` | 29516 | `645a720997f7622c412dadedb64ca5c88082cdbc6d788ed99c2180324278b0ec` |
| `.verification/1504-independent-final-attempt-v5-review.md` | 26499 | `29e9c4078e99874f22eb59dd994b6c372160434ee21f54c0637f10e14941c687` |
| `.verification/1504-independent-final-attempt-v6-review.md` | 29672 | `7857fda334a112b671456a5a8458107fdf37a7a66eada9b59bf8b3ede8a894b3` |

### Selected actual v7 payload and scratch hashes

All732 payload hashes are verified against the actual inventory. Selected hashes make key conclusions reviewable without printing credentials or images.

| Payload | Bytes | SHA256 |
| --- | ---: | --- |
| `inventory.json` | 98113 | `e149fa5777f230c2239e05334a4b0e539bd04fb91b72d3867a99430d5869f4b2` |
| `root-source-checkpoint.json` | 91981 | `8bc4aaf999c9e56ccd0b1d4192a952d896ad5d803df4bcf8323ad22b5cd79012` |
| `root-1504-final-acceptance-v7-report.md` | 11608 | `cf0bf57d74be2ad2bce3d6ffde2d50c156a3f0fc2cde234a7339ff1a01b327bb` |
| `root-1504-final-v7-dispatch-receipt.json` | 373 | `fdc30074bf8d9260aef1dfebe392a8de3ed8bc944a95a6f885970e73e9c642d1` |
| `root-closeout-summary.json` | 1333 | `966152bc0dab501b7f41af53712a1b02bddfb26cb7a69da02cb7dffb0909b82d` |
| `root-restoration-audit.json` | 1410 | `0265b80baf6330c291f902474b0c1de000197f71c493d58b9b57d0af5b57221f` |
| `root-owned-absence.json` | 1115 | `f4f3dfed6683166221f7d846cae0ebaaf478605526361b7ef2a97d7a0437dd7a` |
| `root-owned-cleanup.json` | 160 | `43b8a7db6331e3cd3333eaaf11a20b57f351b4ec57e2a5dba872a5686bfa5b05` |
| `root-doctor-closeout.json` | 391 | `47bbe738c0cab9f6489da0b0e39cfed2fae34703ed012eee6a3e4057f38a5087` |
| `drive/016-probe-held.stdout` | 1018 | `20842eb85a1b6831cfbd434844bde41b6e406e48027ccfa95b655cb882c7a41c` |
| `drive/038-probe-after2.stdout` | 876 | `a81c1e47d89cc6354489ce920742f299e99c5117a0f87de5b1627d0d0e2f1409` |
| `drive/055-probe-held.stdout` | 976 | `ab157a1c0bbf8e007267000f08aab1af06c766fdeccac158fe4722f0a6158664` |
| `drive/080-probe-after.stdout` | 914 | `96642c464ddb2a4c11a7cfaf749bcc0c8503cfd05c20f84c6ae5d0c6d28fa7e1` |
| `drive/103-probe-held.stdout` | 934 | `54763fd6c7b366c04dfaa5f1f025f7023012a5d38dafc3a570264076a989911c` |
| `drive/111-probe-after.stdout` | 934 | `54763fd6c7b366c04dfaa5f1f025f7023012a5d38dafc3a570264076a989911c` |
| `drive/135-probe-after2.stdout` | 876 | `a81c1e47d89cc6354489ce920742f299e99c5117a0f87de5b1627d0d0e2f1409` |
| `drive/145-probe-imm.stdout` | 956 | `69e4a5201de0e11a8a1691f614360cda2a110446f7862bd73d41dd783e8aa471` |
| `drive/147-probe-after.stdout` | 956 | `69e4a5201de0e11a8a1691f614360cda2a110446f7862bd73d41dd783e8aa471` |
| `drive/062-region-style.stdout` | 654 | `357c695327f70118e60a4f786713be6a847eeb64e575779f336af9e0dfb6d83e` |
| `drive/107-net-list-held.stdout` | 4372 | `efe3a009606d16310dfe745d6e6345a4cb022a431e65c675174e7e7b71616577` |
| `drive/157-net-before.stdout` | 45515 | `96b496a3535724154b6d898c0d396a65908957cb240b4f9686f613b2e99ff6f7` |
| `drive/161-net-after-hover.stdout` | 45515 | `96b496a3535724154b6d898c0d396a65908957cb240b4f9686f613b2e99ff6f7` |
| `drive/164-net-after-hover2.stdout` | 45515 | `96b496a3535724154b6d898c0d396a65908957cb240b4f9686f613b2e99ff6f7` |
| `drive/167-net-after-click.stdout` | 46035 | `1532a558e12aad97be58b3a6a3ffec3bcde6650b809a6034c75dac6423969943` |
| `drive/169-probe.stdout` | 680 | `fefc21493cb4c552b4f16f3e10413dc32cb1b554242c8389416aed69e29d3852` |
| `drive/173-net-reload.stdout` | 1155 | `4fb08cc4c2b61e593b98ac915b2faebbaed8950332266a91f802a72d8f749d50` |
| `drive/177-probe.stdout` | 968 | `52042eed04355b6d4c44d334c7c0e50dfde0a5f5cd7a080fc7b0fba44007237d` |
| `drive/178-net.stdout` | 1155 | `4fb08cc4c2b61e593b98ac915b2faebbaed8950332266a91f802a72d8f749d50` |
| `drive/160-settle.json` | 285 | `dcebcc7b61cb2c9a078d92d9759fbd16126f052217f5bc731598760462120be2` |
| `drive/160-settle.stdout` | 129 | `6501e0ba3948d8e61507165088c455694ad23f0c1d8ef4ba4657dfcca6143bc7` |
| `drive/163-settle.json` | 285 | `a7e3f9017c51f7238f2967c8feb38c4e4c57748b9a8987ca20fb860dc9fcc473` |
| `drive/176-settle.json` | 285 | `55c180db8e1d03461576df4a9dec08100646e754267ed06e72b360791961d86d` |
| `.verification/review-1504-final-v7-e8b17/behavior-content-checks.json` | 1123 | `68be446ad1550f23da2a70458f6097b4def0dd1404703bd8ceb2a23f161f2606` |
| `.verification/review-1504-final-v7-e8b17/composed-review-pins.json` | 2529 | `fbab0a394b601d37d94c60d809e6c7f6d08ac3c53b5be1a6dc0471bb39659243` |
| `.verification/review-1504-final-v7-e8b17/inventory-audit.json` | 345 | `83a7e1aa1ebaa7de9b5d64ccedc8457c59e70cdb03ce84c67744c2cba3d81b58` |
| `.verification/review-1504-final-v7-e8b17/latest-main-census.json` | 247881 | `308ccc648cff4f5ece808161361d877fb81bb508ab49eb41d5a31ba7e51e425f` |
| `.verification/review-1504-final-v7-e8b17/native-action-audit.json` | 31773 | `a1244a44037b8e37594f8134053cf567bec8941ad7d464bbd6d344a95a0267b6` |
| `.verification/review-1504-final-v7-e8b17/parsed-outputs.json` | 1696273 | `3303310a771abf5688d7658774bc73c68d8c4a15baf43435f4923f8bb28c0974` |
| `.verification/review-1504-final-v7-e8b17/prior-package-continuity.json` | 2382 | `ded251ded751bd2f352af0ac1a60ebd74fc0ab45a8ca4658a1fa454d8c135f83` |
| `.verification/review-1504-final-v7-e8b17/restoration-privacy-audit.json` | 7273 | `d6742892a8e1cefb2d9a16fce10387be5de999f31c1016c62dac695be4cc1fc9` |
| `.verification/review-1504-final-v7-e8b17/retained-focus-source-history.json` | 1173 | `cea644532e4b58d350e77e682a28bf1cf464751337485234e44ce041aef54f7a` |
| `.verification/review-1504-final-v7-e8b17/source-pin-audit.json` | 1345 | `091d5ca674221b5ac9014c5defe944a7962710b1b22f3dcf754e6686f66b7ff5` |
| `.verification/review-1504-final-v7-e8b17/workbook-audit.json` | 23527 | `3ed70ec49d68010fc7999d7d4d27eb2fcb3dfffb8ef677848eebf50af58ad688` |
