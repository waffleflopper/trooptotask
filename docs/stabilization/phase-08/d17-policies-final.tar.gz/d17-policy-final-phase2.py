from d17_policy_final_support import *
import datetime
p=json.load(open(RUN/'actor-owner-policies.json'))['pageId'];seed=json.load(open(RUN/'seed-personnel-lifecycle.json'));name=seed['name'];person=seed['ids']['person']
today=datetime.date.fromisoformat(json.load(open(RUN/'fixture.json'))['dates']['ui']);dated=today+datetime.timedelta(days=60);assert dated.isoformat()=='2026-12-01'
(RUN/'loss-date-context.json').write_text(json.dumps({'local_date':str(today),'ETS':str(dated),'distance_days':60,'DEROS':None,'id':person,'name':name},indent=2))
control('loss-person-original','rows','personnel','orgA','id',person)
step('loss-warning30-fill',p,'fill','spinbutton','Warning lead time',30);step('loss-warning30-save',p,'click','button','Save','region:Loss Warning Window');rows('loss-warning30-row')
step('loss-personnel-open',p,'click','link','Personnel');step('loss-person-edit-open',p,'click','button','Edit','row:Open SPC '+name+', Synthetic',row=True)
step('loss-ets-picker-open',p,'click','button','ETS');step('loss-ets-next-nov',p,'click','button','Next');step('loss-ets-next-dec',p,'click','button','Next');step('loss-ets-day',p,'click','button','Tuesday, December 1, 2026');step('loss-person-save',p,'click','button','Save Changes')
control('loss-person-dated','rows','personnel','orgA','id',person)
for window in [30,90]:
 if window==90:
  step('loss-policy90-open-settings',p,'click','link','Organization Settings');step('loss-policy90-open',p,'click','link','Policies');step('loss-policy90-fill',p,'fill','spinbutton','Warning lead time',90);step('loss-policy90-save',p,'click','button','Save','region:Loss Warning Window');rows('loss-policy90-row');step('loss-list90-open',p,'click','link','Personnel')
 step('loss-list'+str(window)+'-reload',p,'reload');screen('loss-list'+str(window),p)
 step('loss-detail'+str(window)+'-open',p,'click','button','Details','row:Open SPC '+name+', Synthetic',row=True);step('loss-detail'+str(window)+'-reload',p,'reload');snapshot('loss-detail'+str(window)+'-settled',p);screen('loss-detail'+str(window),p)
 step('loss-calendar'+str(window)+'-open',p,'click','link','Calendar');step('loss-calendar'+str(window)+'-reload',p,'reload');screen('loss-calendar'+str(window),p)
 s=step('loss-dashboard'+str(window)+'-open',p,'click','link','Home')
 if 'button "Got it"' in s:step('loss-dashboard'+str(window)+'-dismiss',p,'click','button','Got it')
 step('loss-dashboard'+str(window)+'-reload',p,'reload');snapshot('loss-dashboard'+str(window)+'-settled',p);screen('loss-dashboard'+str(window),p)
step('loss-restore-open-list',p,'click','link','Personnel');step('loss-restore-open-detail',p,'click','button','Details','row:Open SPC '+name+', Synthetic',row=True);step('loss-restore-edit',p,'click','button','Edit basic info');step('loss-restore-picker',p,'click','button','ETS');step('loss-restore-clear',p,'click','button','Tuesday, December 1, 2026');step('loss-restore-save',p,'click','button','Save basic info');control('loss-person-restored','rows','personnel','orgA','id',person)
step('owner-settings-return',p,'click','link','Organization Settings');step('owner-policies-return',p,'click','link','Policies');step('owner-retention-restore-fill',p,'fill','spinbutton','Retention period',36);step('owner-retention-restore-save',p,'click','button','Save','region:Archive Retention');step('owner-warning-restore-fill',p,'fill','spinbutton','Warning lead time',180);step('owner-warning-restore-save',p,'click','button','Save','region:Loss Warning Window');step('owner-restore-reload',p,'reload');rows('owner-restored-before-switch')
