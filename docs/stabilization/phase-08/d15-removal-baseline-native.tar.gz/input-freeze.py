from drive import *
import hashlib

tracked = {
    '.agents/skills/verify-trooptotask/helpers/control.mjs': 'input-control.mjs',
    '.agents/skills/verify-trooptotask/helpers/onboarding-request.mjs': 'input-onboarding-request.mjs',
    '.agents/skills/verify-trooptotask/helpers/onboarding-removal-provider.py': 'input-onboarding-removal-provider.py',
    '.agents/skills/verify-trooptotask/helpers/network-control.mjs': 'input-network-control.mjs',
    '.agents/skills/verify-trooptotask/helpers/feedback-control.mjs': 'input-feedback-control.mjs',
    '.agents/skills/verify-trooptotask/helpers/onboarding-fixtures.mjs': 'input-onboarding-fixtures.mjs',
    '.agents/skills/verify-trooptotask/features/onboarding-packets.md': 'input-packet-recipe.md',
    '.agents/skills/verify-trooptotask/features/personnel-records-lifecycle.md': 'input-personnel-recipe.md',
    '.agents/skills/verify-trooptotask/SKILL.md': 'input-verification-skill.md',
    'scripts/verification/environment.py': 'input-environment.py',
    'scripts/verification/core.mjs': 'input-core.mjs',
    'scripts/verification/daemon.mjs': 'input-daemon.mjs',
}
ignored = {'.verification/tmp/d15-removal/'+name: 'input-'+name for name in ['drive.py','business.py','provider-inventory.py','freeze.py']}
revision = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
manifest = {'revision': revision, 'unchangedApplicationBase': '391edcb1022b7805127d65d173733a24bc58d2f3',
            'protocol': 'Maintained supported step operations and inactive removal recipe; actual native/helper payloads retained as invoked', 'inputs': {}}
for relative, copy in {**tracked, **ignored}.items():
    payload=(ROOT/relative).read_bytes()
    item={'copy':copy, 'sha256':hashlib.sha256(payload).hexdigest(), 'tracked':relative in tracked}
    if relative in tracked:
        blob=subprocess.check_output(['git','rev-parse',revision+':'+relative],text=True).strip()
        assert subprocess.check_output(['git','show',revision+':'+relative])==payload, 'Tracked driving input is uncommitted'
        item['gitBlob']=blob
    (E/copy).open('xb').write(payload)
    manifest['inputs'][relative]=item
write(E/'inputs-before-launch.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'revision': revision,'inputs':len(manifest['inputs']),'evidence':str(E)}))
