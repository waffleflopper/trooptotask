from drive import *
for command,tag in [('doctor','doctor-initial'),('tools','native-tool-schemas')]:
 r=subprocess.run(['npm','run','--silent','verify:app','--',command,'--worker','1'],text=True,capture_output=True)
 (E/(tag+'.json')).write_text(r.stdout);(E/(tag+'-stderr.log')).write_text(r.stderr);assert r.returncode==0,r.stderr
fixture=control(['fixture'],'fixture')
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  control(['rows',table,org],'original-'+table+'-'+org)
seed=control(['seed','onboarding-history'],'history-seed')
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  control(['rows',table,org],'seeded-'+table+'-'+org)
observed=[]
for role,key,stage in [('onboardingView','alpha','Reviewed'),('onboardingForeign','foreign','Archived review')]:
 actor=control(['actor',role,'onboarding/history'],key+'-actor');page=actor['pageId']
 for read in ['initial','reloaded']:
  if read=='reloaded':native('navigate_page',{'pageId':page,'type':'reload'},key+'-history-reload')
  tag=key+'-'+read
  s=snap(page,tag+'-before-open');click(page,uid(s,'button "SPC History'+key+seed['tag']),tag+'-open')
  s=snap(page,tag+'-opened');screen(page,tag+'-opened');assert 'Current stage: '+stage in s
  result=native('evaluate_script',{'pageId':page,'waitForStableDom':False,'function':'() => Array.from(document.querySelectorAll("[aria-label$=\\"paperwork stages\\"] button")).filter(e=>e.checkVisibility()).map(e=>({text:e.textContent,disabled:e.disabled,current:e.getAttribute("aria-current")}))'},tag+'-rendered-stage-controls')
  data=json.loads(re.search(r'```json\n([\s\S]*?)\n```',result)[1]);assert len(data)==3 and all(r['disabled'] for r in data)
  current=[r['text'] for r in data if r['current']=='step'];assert (len(current)==1 and 'Reviewed' in current[0]) if key=='alpha' else not current
  observed.append({'role':role,'read':read,'savedStage':stage,'listedCurrent':current,'allControlsDisabled':True})
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  now=control(['rows',table,org],'repair-after-'+table+'-'+org)['rows'];old=json.loads((E/('seeded-'+table+'-'+org+'.json')).read_text())['rows'];assert {r['id']:r for r in now}=={r['id']:r for r in old}
(E/'observed-repair-outcomes.json').write_text(json.dumps({'result':'PASS','observed':observed,'scope':'Matching native History paperwork display repair only; selected packet/progress/Training fields unchanged. Other unchanged baseline behaviors reuse the separate preceding run.'},indent=2)+'\n')
print('Known and unknown History stages identified read-only, immediately and after reload; selected saved fields unchanged.')
