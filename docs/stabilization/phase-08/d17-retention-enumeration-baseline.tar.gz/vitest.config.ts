import { defineConfig, mergeConfig } from 'vitest/config';
import base from '../vitest.config';

export default mergeConfig(base, defineConfig({
	cacheDir: '.verification/vite-exports-jobs-baseline-cache',
	test: {
		include: ['src/routes/api/cleanup-archived-records/organizationEnumeration.baseline.test.ts'],
		maxWorkers: 1,
		fileParallelism: false
	}
}));
