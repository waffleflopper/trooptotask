# D15 inactive-step removal — worker 2 final

This is actual native/app/provider verification of the frozen removal repair. It is worker 2 execution evidence; independent artifact acceptance and the coordinator's complete PR gates remain separate. It does not claim #1363 complete.

## Frozen candidate and ownership

- Revision: `a9660b48905882dc2caf646e6ea8acbf61eb89a6`.
- Candidate: `2474434878c14f06ac7e8bdfe65568e316870982df8f6b610dbbc5035b8635d7`.
- Branch: `stabilization/1363-onboarding-step-removal`.
- Checkout: `/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413`.
- Owned worker: `2`; session `ce0cf4d9-287e-48cb-85d6-97d7bfc8ec05`; origin `http://127.0.0.1:44185`.
- Project: `t2t-verify-4995d693707048239c117fbb`.
- Native Chromium: `152.0.7977.82 Arch Linux`, `/usr/bin/chromium`.
- Configure actor page 2 and Operate actor page 3 reused their isolated ordinary sessions. Actor metadata and fixture contracts are archived; neither actor borrows Personnel or Training capabilities.
- `frozen-inputs.json` preserves 21 exact copied skill, recipe, helper, environment and ignored driving inputs before launch. `final-freeze-and-row-checks.json` confirms every copy/hash, all 15 tracked Git blobs, clean Git status, revision and candidate remained unchanged through disposal.
- The launch and every browser action used repository `npm run verify:app`, documented native tools and accepted helpers. No T3/integrated browser, direct browser protocol, app-handler invocation or existing/remote database was used.

The actual launch, doctor, tools, ownership inventory and initialization passed. `memory-prelaunch-after-execution.json` faithfully records the earlier actual `free -m` output (11,653 MiB available), with its after-execution recording timeline. All twelve complete original A/B business/catalog rowsets were captured **before the first seed** in `original-before-rowsets.json`. There are no excluded IDs or normalized fields in the restoration comparisons.

## Actual provider fault, readable error and retry

Fresh legacy cohort tag `e8267bd7`, packet `564d6856-b2f3-4f03-a808-5c8e26b72338`, original Paperwork `83855371-dace-4a3f-b300-17280a246fc0`.

The native Configure actor assigned canonical Verification Onboarding A. The coordinator inspected `fault-assign-selected.png` before allowing the native save. The real POST200 request/response was captured before navigation (`fault-assign.network-request` / `.network-response`); provider and reload confirmed assignment and six rows, including original saved inactive work.

The accepted provider helper validated this exact checkout/private worker/project/session/container/config, seed ledger and original Person/work. It installed only the original Paperwork-ID restricted delete fault. Native Operate Remove produced actual DELETE500 with full business bodies in `fault-failure.network-request` / `.network-response` before any navigation. The response was `{ "message": "Internal server error" }`. Every prepared raw parent/progress/catalog/Person field remained equal (`fault-unchanged.json` and before/after prepared snapshots). Actual rendered feedback contained the readable error **Could not remove this step. Reload and try again.** (`fault-feedback-observation.json`, native snapshot and screenshot).

Exact fault removal reported catalog absence in `fault-off-stdout.json`: no function, no trigger, zero probe triggers. Only then were controls restored and native Remove retried. Actual DELETE200 full business bodies were captured before navigation (`fault-retry.network-request` / `.network-response`, `{ "success": true }`). Separate native reload showed the target absent and the other original inactive history retained. `saved-row-acceptance-checks.json` additionally compares all five surviving complete raw rows to the prepared before-failure snapshot, without field normalization. This passed.

The cohort was cleaned before any wait cohort setup. Every captured seed/ordinary ID was actually absent and all twelve original A/B rowsets exactly matched (`fault-exact-id-absence.json`, `original-after-fault-rowsets.json`).

## Actual reconciliation-before-delete waiting chain

Fresh separate legacy tag `5d768585`, packet `c973d7bd-307b-4a62-8320-bb0dba51268d`, original Paperwork `8950d7f6-e9e5-410d-9ca7-6281769d410b`.

The normal native Configure UI duplicated the canonical template and renamed it **D15 Removal Matching 5d768585** (`8c82e063-429c-41c7-8506-57758aa1aabf`). Only the native Paperwork definition name changed to exact Paperwork; the three definitions and retained stages were read back and reloaded. There was no privileged active/work/Person edit. The coordinator inspected `wait-assign-selected.png` before save, and later `wait-switch-selected.png` before the canonical switch save.

Native assignment to the matching clone returned POST200 and preserved the original Paperwork ID, Reviewed stage, incomplete state, stages and original note, with a real linked template definition. Native switch-away to canonical A returned POST200 and marked that same row inactive normally. Both native saves' complete business bodies were captured before navigation; separate provider reads and native reloads are archived.

The reviewed wait driver froze the exact ordinary POST reconciliation and DELETE bodies, validated Configure page 2, and used the accepted seed/prepared capture. The read-only holder locked only the original inactive incomplete row. The helper observed the ordinary reconciliation waiting first, then started the ordinary DELETE and observed its transitive chain:

- Holder PID `1976`, backend start `2026-10-02 10:40:12.732725+00`.
- Reconciliation PID `2078` → holder `1976` (Lock/transactionid).
- DELETE PID `1867` → reconciliation `2078` → holder `1976` (Lock/tuple).

Exact identities, query classes/byte lengths and blocking paths are in `removal-wait-20261002T104011Z-f55ec102/observed-ordered-writers.json`; no full session-bearing queries or JWTs were captured. Holder rollback and exact identity absence are explicit in that directory's `cleanup.json` / `holder-absent.outputs.jsonl`. The holder made no business mutation. The driver drained both complete real HTTP outcomes before restoring controls or navigating:

- Ordinary reconciliation POST200.
- Ordinary DELETE409: `{ "message": "Step changed before removal; reload and try again" }`.

`wait-drained-outcomes.json` retains the complete ordinary request/response bodies; `wait-observed-outcome.json` is PASS. Raw provider readback has eight rows / three active. The original Paperwork remains active, Reviewed, incomplete and retains its exact original note. All three original IDs/work/notes/stages are checked from actual saved rows. Native reload is a separate observation (`wait-final-persistence-open.png` / `.txt`): matching template, 0/3, Paperwork Submitted CLEARED, Reviewed CURRENT, Filed QUEUED, with inactive saved history also visible.

These ordinary fetch captures did not call client store handlers. The native reload proves persisted rendering separately. The test establishes this exact known write order; it does not claim every arbitrary writer order, parent-status serialization, a job-wide transaction or whole-issue concurrency completion. Success-audit behavior is covered by the meaningful lower service tests, not claimed from an uncollected native audit rowset here.

## Cleanup and disposal

The temporary matching template and its three definitions were deleted through the normal UI, then provider absence and reload were checked. Accepted clean-seeds removed only the ledgered cohort. Both cohorts together have **22 exact captured temporary IDs**: 18 Person/parent/progress IDs plus one native template and three definitions. All are actually absent. Complete final A/B rowsets equal the before-first-seed originals (`original-after-all-rowsets.json` and `final-freeze-and-row-checks.json`). Restored network/feedback/request controls, exact fault catalog absence and holder rollback/absence are retained independently.

Final doctor passed at the same revision/candidate/origin/session (`final-doctor-stdout.json`). Supported owned cleanup passed (`owned-disposal-stdout.json`). Exact captured five full container IDs, two volume names, full network ID and private worker-2 directory are absent (`resources-before.json`, `resources-after.json` and each raw command record). The actual after-disposal Docker commands/raw returns and namespace filter are archived. At this worker-2 disposal timeline, coordinator worker 1 project `t2t-verify-0dd82c6c2d864633be661723` still existed. The namespace output is therefore **not empty**, and this run does not claim global namespace absence; every worker-2 resource is absent. The coordinator must capture its own later disposal/namespace state.

## Driving gaps and limits preserved

All executed final live stages completed with their required expected results. The intentional native500 was the expected fault outcome, not an unexpected final product failure.

Two post-execution read-only summarization/checker mistakes are preserved rather than treated as product failures: a rows response envelope was initially treated as a list (`wait-assign-retained-summary.json` records the TypeError and correction); later a derived checker looked for training_type_id in the smaller seed object (`saved-row-checker-v1-gap.json` records the KeyError). The corrected checker compares the six seed work fields against seed objects and raw training_type_id against the accepted prepared raw snapshot. Corrected results passed in `saved-row-acceptance-checks.json`. No live request, saved state or frozen helper changed for either correction. Prior offline guard attempts and their limitations are preserved separately.

Unlike earlier baseline driving gaps, every required final native500/200 business body was captured before navigation. Baseline raw archives remain immutable and retain their own failures and unavailable first-retry capture. No baseline failure was replaced by final evidence. Independent artifact review, all coordinator PR gates and remaining #1363 acceptance still apply.

## Executed commands

All commands used `D15_EVIDENCE=d15-removal-worker2-final`, `PYTHONDONTWRITEBYTECODE=1`, and `TMPDIR=/home/waffleflops/.cache/t2t-d15-tmp`. The frozen drivers admit worker 2 only; all repository app/control/provider invocations carry `--worker 2` in their archived command inputs.

The frozen `drive.py` performed freeze, app info, launch, doctor and tools; `resources.py before` captured ownership. Frozen `final.py` phases, each exit0, were initialize, fault-pick, fault-save-install, fault-remove, fault-off-retry, fault-clean, wait-template, wait-assign-pick, wait-assign-save-switch-pick, wait-switch-save, wait-readback and wait-clean. Save phases ran only after coordinator screenshot inspection and explicit go.

The frozen wait command was:

```sh
python3 .verification/tmp/d15-removal-provider/wait.py --page 2 --seed /home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413/.verification/evidence/verify-trooptotask/d15-removal-worker2-final/wait-seed-stdout.json --prepared /home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413/.verification/evidence/verify-trooptotask/d15-removal-worker2-final/removal-capture-20261002T103954Z-2d2e6780/prepared.json
```

It exited0; wait-driver stdout/stderr and all probe inputs/SQL/public outputs are preserved. Disposal used `drive.py app owned-disposal cleanup`, followed by `resources.py after`, both exit0. After-disposal derived row/input checks preserve their assertions and command outputs in the named records. No source edits, commits, Git moves, packaging or extra test service occurred during this run.
