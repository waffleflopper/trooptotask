SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_remove_fault_e8267bd7_ce0cf4d9() RETURNS trigger LANGUAGE plpgsql SET search_path='' AS $removal$
BEGIN
 RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned progress-delete fault';
END;
$removal$;
COMMENT ON FUNCTION public.t2t_d15_remove_fault_e8267bd7_ce0cf4d9() IS '{"container_id": "ea93de15e62ab8c2eb29c1c7cc4a3da2e0ff162d1c37cf85be6a3fbc6fa99909", "organization_id": "46bb6cff-3364-4cb9-9d4f-c85d9958cf91", "packet_id": "564d6856-b2f3-4f03-a808-5c8e26b72338", "project": "t2t-verify-4995d693707048239c117fbb", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "e04f8316cd5191e04ad8b81da2e0cec72e0e7a7a5c7a35960544012a18025b78", "session_id": "ce0cf4d9-287e-48cb-85d6-97d7bfc8ec05", "step_id": "83855371-dace-4a3f-b300-17280a246fc0", "worker": "2"}';
CREATE TRIGGER t2t_d15_remove_fault_e8267bd7_ce0cf4d9 BEFORE DELETE ON public.onboarding_step_progress FOR EACH ROW
WHEN (OLD.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND OLD.onboarding_id='564d6856-b2f3-4f03-a808-5c8e26b72338'::uuid
 AND OLD.id='83855371-dace-4a3f-b300-17280a246fc0'::uuid) EXECUTE FUNCTION public.t2t_d15_remove_fault_e8267bd7_ce0cf4d9();
COMMENT ON TRIGGER t2t_d15_remove_fault_e8267bd7_ce0cf4d9 ON public.onboarding_step_progress IS '{"container_id": "ea93de15e62ab8c2eb29c1c7cc4a3da2e0ff162d1c37cf85be6a3fbc6fa99909", "organization_id": "46bb6cff-3364-4cb9-9d4f-c85d9958cf91", "packet_id": "564d6856-b2f3-4f03-a808-5c8e26b72338", "project": "t2t-verify-4995d693707048239c117fbb", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "e04f8316cd5191e04ad8b81da2e0cec72e0e7a7a5c7a35960544012a18025b78", "session_id": "ce0cf4d9-287e-48cb-85d6-97d7bfc8ec05", "step_id": "83855371-dace-4a3f-b300-17280a246fc0", "worker": "2"}';
COMMIT;
SELECT json_build_object('event','fault-installed');
