SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_remove_fault_a1a5b24e_ad176e6b ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.t2t_d15_remove_fault_a1a5b24e_ad176e6b();
COMMIT;
SELECT json_build_object('event','fault-removed');
