SELECT json_build_object('event','identity','pid',pg_backend_pid(),
 'backend_start',(SELECT backend_start::text FROM pg_stat_activity WHERE pid=pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout='10s';
SET LOCAL lock_timeout='3s';
SET LOCAL idle_in_transaction_session_timeout='75s';
SELECT json_build_object('event','locked','id',id) FROM public.onboarding_step_progress
WHERE organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND onboarding_id='034a793a-540b-4999-8c88-dddd4b0e00ff'::uuid
 AND id='1645827e-32a5-4a61-9eec-8a2947d9978e'::uuid AND NOT active AND NOT completed AND step_type='paperwork'
 AND current_stage='Reviewed' AND template_step_id='651a0230-682e-4f66-b2b3-4a78976087fb'::uuid
 AND notes='[{"text": "Legacy retained work a562c287", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "2c15cb02-8355-4272-8b0a-0068cc77edb9"}]'::jsonb FOR UPDATE;
SELECT json_build_object('event','ready');
