# Worker 2 final inactive-removal verification

Run only after root commits and freezes the complete application/helper/recipe
candidate and sends launch go. Preserve the accepted baseline archive and all old
recorder sources. Root owns shared source/records, worker 1 and publication.
Worker 2 uses the same exact coordinator checkout and separate owned --worker 2
browser/app/provider. Do not switch shared HEAD or edit tracked inputs during a
session. Use repository native verify:app tools/controller only.

Set D15_EVIDENCE=d15-removal-worker2-final,
TMPDIR=/home/waffleflops/.cache/t2t-d15-tmp,
PYTHONDONTWRITEBYTECODE=1. The revised ignored final.py fixes baseline tag
collisions, uses actual Template/New Template buttons and fresh modal footer UIDs,
and captures complete business bodies BEFORE reload. Screenshots after native
Home/End+Enter selection must be inspected before each separate save phase.
No assumed DOM option UID, app handler, direct client-state mutation, or borrowed
permission is allowed.

## Freeze and launch, only after exact root candidate/go

```
python3 .verification/tmp/d15-removal-provider/drive.py freeze prelaunch EXACT_ROOT_REVISION
python3 .verification/tmp/d15-removal-provider/drive.py app info info
# Notify root exact frozen inputs/digest/source hashes and actual available memory.
# Wait for required launch go.
python3 .verification/tmp/d15-removal-provider/drive.py app launch launch
python3 .verification/tmp/d15-removal-provider/drive.py app doctor doctor
python3 .verification/tmp/d15-removal-provider/drive.py app tools tools
python3 .verification/tmp/d15-removal-provider/resources.py before
python3 .verification/tmp/d15-removal-provider/final.py initialize
```

Freeze copies all .py drivers plus this PLAN, skill/recipes/controller/fixtures and
provider helper; input manifest is declared before launch. Resources-before saves
five full container IDs, two volume names, full network ID, exact session/project
and safe command/raw-output inventories. Initialize captures all twelve original
A/B business/catalog rowsets BEFORE ANY SEED. No excluded-ID predicates. Two normal
Onboarding-only actor sessions (Configure and Operate) are reused throughout.
No Personnel, note, stage, completion or Group edit on provider targets.

## Fault: real provider 500, readable feedback, native retry 200

```
python3 .verification/tmp/d15-removal-provider/final.py fault-pick
# Inspect actual screenshot: canonical Verification Onboarding A selected.
python3 .verification/tmp/d15-removal-provider/final.py fault-save-install
python3 .verification/tmp/d15-removal-provider/final.py fault-remove
python3 .verification/tmp/d15-removal-provider/final.py fault-off-retry
python3 .verification/tmp/d15-removal-provider/final.py fault-clean
```

Canonical names differ, so normal assignment keeps original Reviewed/incomplete
Paperwork inactive and original completed Orientation/Historic retained. Actual
native assignment body/response and raw fresh IDs are captured before reload.
Accepted exact-seed provider capture/fault-on uses the returned absolute prepared
file. Native Remove must return real 500 with actual business bodies, retain the
row and every complete prepared provider field, and show readable captured error.

A failed assertion is preserved, then cleanup still proceeds. Never clean a seed
while its fault remains installed. Fault-off proves exact function/trigger catalog
absence first. Restore hooks; real native retry must return 200/success, delete
only target, preserve other saved work/notes/IDs and survive native reload. Full
retry response is captured BEFORE restore/reload. Restore every hook. Clean the
cohort and all original/fresh IDs; compare all twelve original rowsets before the
fresh wait cohort. No redundant repeat cohort unless a real evidence gap requires
it and root is informed.

## Linked inactive wait: known RPC reactivation then conditional rejection

```
python3 .verification/tmp/d15-removal-provider/final.py wait-template
python3 .verification/tmp/d15-removal-provider/final.py wait-assign-pick
# Inspect screenshot: D15 Removal Matching TAG selected.
python3 .verification/tmp/d15-removal-provider/final.py wait-assign-save-switch-pick
# Inspect screenshot: canonical Verification Onboarding A selected.
python3 .verification/tmp/d15-removal-provider/final.py wait-switch-save
python3 .verification/tmp/d15-removal-provider/wait.py --page ACTUAL_CONFIGURE_PAGE --seed ABSOLUTE_WAIT_SEED --prepared ABSOLUTE_RETURNED_PREPARED
python3 .verification/tmp/d15-removal-provider/final.py wait-readback
python3 .verification/tmp/d15-removal-provider/final.py wait-clean
```

Create one normal native canonical clone, rename to D15 Removal Matching TAG,
rename only its Paperwork definition to exact Paperwork; preserve type/stages and
other definitions. Assignment normally adopts the original Paperwork identity,
Reviewed/incomplete work and original notes. Switching away normally makes that
same linked row inactive. No privileged active/work/Person edits manufacture a
winner. Capture full native assignment/switch bodies before each reload and use
accepted provider prepared capture unchanged.

The unchanged bounded wait driver freezes exact request body files before its
accepted provider holder. Start ordinary reconciliation only after HOLDING;
start only the DELETE after actual RECONCILIATION_WAITING. Require real transitive
chain through the same RPC/backend identity to holder, rollback and exact holder
absence. Default35/max60 observation and75 idle backstop remain. Unavailable
observations/body transport are inconclusive. Drain all started records before
navigation or restore; no forced navigation/cancellation credit.

Final expected behavior is explicit: ordinary RPC200 returns original active
Reviewed/incomplete Paperwork, waiting DELETE returns409 without successful
removal, provider still contains same active ID/work/notes, and native reload has
its active stage controls. This follows known persistence/lock ordering; do not
invent a last-issued winner or post-wait policy guarantee. Full current parent,
progress and all original saved work/notes are compared. The HTTP helper does not
apply responses to UI; native reload is separate.

## Cleanup, freeze and handoff

Native Delete removes only captured temporary template; read back clone and all
three definitions absent. Clean owned seeds, all original/fresh progress IDs,
compare all twelve original rowsets, retain final doctor. Then run recorded owned
cleanup and resource-after to prove exact five CIDs/two volume names/networkID
and private directory absent. Preserve raw complete allocator namespace inventory;
other root worker may still run, distinguish that timeline.

```
python3 .verification/tmp/d15-removal-provider/drive.py app owned-disposal cleanup
python3 .verification/tmp/d15-removal-provider/resources.py after
```

Check every frozen source/copy/hash/revision/digest unchanged during the run.
Readable RUN.md records actual statuses/business bodies, native observations,
raw provider readbacks, any failures/driving gaps and cleanup. Keep per-run2500
regular files/32MiB cap. No packaging/helper/source/maps edits during active run.
Root packages byte-exact durable artifacts only after final disposal. Source tests
and controlled outcomes do not replace final actual-provider/native acceptance.
