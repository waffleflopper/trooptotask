#!/bin/bash
# r.sh NAME cmd... -> driver/NAME.out/.err plus one receipt line in receipts.jsonl
cd /home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp NODE_DISABLE_COMPILE_CACHE=1
E=.verification/evidence/verify-trooptotask/1504-final-v6/driver
n=$1; shift
[ -e "$E/$n.out" ] && { echo "EXISTS $n" >&2; exit 99; }
s=$(date +%s.%N); start=$(date -Is)
"$@" >"$E/$n.out" 2>"$E/$n.err"; rc=$?
e=$(date +%s.%N)
python3 - "$E/receipts.jsonl" "$n" "$rc" "$s" "$e" "$start" "$@" <<'PY'
import json,sys
f,n,rc,s,e,start,*argv=sys.argv[1:]
open(f,'a').write(json.dumps({"name":n,"argv":argv,"exitCode":int(rc),"startedAt":start,"seconds":round(float(e)-float(s),3),"stdout":n+".out","stderr":n+".err"})+"\n")
PY
echo "rc=$rc"; head -c ${MAXOUT:-3000} "$E/$n.out"; [ -s "$E/$n.err" ] && { echo "--stderr--"; head -c 1500 "$E/$n.err"; }
exit 0
