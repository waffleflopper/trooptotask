SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_legacy_write_fault_a8f0cefb ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.t2t_d15_legacy_write_fault_a8f0cefb();
COMMIT;
SELECT json_build_object('event', 'fault-remove-committed');
