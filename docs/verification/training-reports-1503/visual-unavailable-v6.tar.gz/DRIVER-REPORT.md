# Training Reports 1503 final chart acceptance v6

## Verdict

This round is **BLOCKED**. Acceptance was not established. The HTTPS transport worked. The T3 browser automation host did not deliver native input to the page. So no orgOwner session exists and nothing in issue 1503 was observed in the browser. No outcome passed and none failed on product behavior. All three outcomes are unrun.

## Bindings

- Candidate `67cd9d795d2de52bbd5cd9db1718e44e8465085f4338fc68e95cb0c3445e1112`, revision `3c0b6f2a9cb4e923ba86d0dda2a698c5e255a04c`, base `0fa2960956572a8f5dea2de2ab5c8d4893178589`.
- Session `223a5780-ad58-4738-92f0-703a634ce774`. External origin `https://omarchy.tail930090.ts.net:18031`.
- Source digest `88e721a7…6ddc7c`, build `d884c0d5…5e8f8a`, adapter `aac7a76e…97f84b0`, read from `SOURCE-BINDING.json`.
- Seed asOf 2026-10-03, view `27b93c72-db75-4774-85fd-72d71c86a140`, final-bucket type `95fa0b50-5f2c-4f43-bab3-c583b593ea14` (lapse 2026-11-02), cliff type `aaef3807-52c6-41c4-b6a3-b319a123ccb4`, read from `root-seed-setup.json`.

## What happened

All times are AKDT on 2026-10-03.

1. 23:15. Doctor PASS and adapter check PASS (H2 ALPN h2, certificate verified, 200, plus H1 login). See `driver/01-*.json`.
2. 23:16. `preview_status` reported no tab. `preview_open` created tab_5 on the exact external `/auth/login`. The page loaded over `h2`. The real environment was T3Code Nightly 0.0.46 on Electron 44.4.2 / Chrome 152.0.7977.130, platform Linux, America/Anchorage, DPR 1.6, 1280x800, prefers-color-scheme dark, mode-watcher `system`. Nothing ran on a Mac and I make no Mac claim.
3. `stage` PASS for orgOwner. The navigate expression went through `preview_evaluate`. That tool call returned an error, as expected when the page context is replaced, and the normal login form came back. The fill expression returned `filled:true, carrierCleared:true`.
4. Native Sign In failed. Four `preview_click` calls (two locators, one alternate locator, one coordinate click) all reported success. The page saw nothing. There was no navigation and no login request, and a capture-phase `click` observer recorded zero events. `document.hasFocus()` was false. `preview_press Enter` failed outright with "Preview automation press failed on client preview-8bd77910776ed8ea70f5199bba559268".
5. Other automation also failed. `preview_snapshot` failed every time. `preview_resize` timed out. One snapshot error read "No preview automation host is available … ask the user to open this thread in the T3 Code desktop app". `preview_status` showed `visible:false` throughout, even after `preview_open open:true`.
6. I retried once with corrected arguments, using a fresh tab_6 with `open:true`. The result was identical. A native click on a visible link produced no event and snapshot failed.
7. I stopped there. The brief forbids localhost, Chrome, Playwright, the helper actor, API login and scripted submits, so I tried none of them.

## Root cause as observed

`preview_evaluate` works. Every input and capture path (click, press, snapshot, resize) either fails or turns into a silent no-op. The host's own message points at the delegated thread not being open in a connected T3 Code desktop window, which also matches `visible:false`. I could not fix that from inside the task. It needs Robert to open this delegated thread in the T3 desktop app, or root to supply a preview host that can take input. Then the round can be rerun as written.

## Per-outcome status

1. **D4/D3 chart legibility. UNRUN.** Not checked: the Goal95 flat-100 and Goal85 final-30-day captures, the width/theme/horizon sweep, annotation-against-gridline contact, goals 1 and 100, loaded font and glyph gaps, label drift, 1024/180 legibility, the screen-reader table, and the Paper comparison. I did not open Paper because without a live chart there was nothing to compare it to. This round produces no v6 visual verdict. The author's 515,100-state model is still only a prediction.
2. **D1/D2, filters, SSR, Retry, focus and export. UNRUN.** No native filters, reload, SSR request observation, hold/503/Retry, keyboard focus or native Export click. No workbook was downloaded.
3. **Contracts smoke. UNRUN in the browser.** I did no source review this round. Root's nonvisual review and receipts (7 required commands, the database chain) remain root's evidence, not mine.

## Midnight coverage

The two literal cases had to be captured before local midnight and were not. After 2026-10-04 00:00 AKDT the report's asOf moves forward. The 30-day final-bucket witness (lapse 2026-11-02) then falls on day 29, not day 30. A rerun needs fresh-date reseeding by root to reproduce the original D3 state.

## Cleanup and handoff state

- Login POSTs from this driver: 0. No session was created, so there was nothing to Sign Out. A same-origin `fetch` of the orgA Training Reports route with `redirect:'manual'` returned `opaqueredirect`, which means the tab was unauthenticated. `document.cookie` was empty.
- `window.name` was cleared in tab_5, and tab_6 was length 0. Both tabs are closed. Theme and storage were never changed.
- The carrier route was consumed and `private-navigate.json` is gone. `private-fill.json` is still in the private run directory and the adapter's shutdown removes it. It has no credential. I did not delete it because it is outside my write scope.
- The goal was never changed. OrgA and OrgB readback matches the root originals exactly, with goal 90 for both (`driver/90-*`).
- No observers, fault or export wrappers were installed beyond read-only capture listeners on two tabs that are now closed.
- Final doctor PASS and adapter check PASS at 23:21 (`driver/91-*`). The worker, adapter and seeded rows are still running for root's cleanup.

## Evidence

All of it is under `.verification/evidence/verify-trooptotask/1503-final-chart-v6/driver/`:
- Start and end doctor/adapter receipts and the stage receipt.
- `10-browser-observations.json`, which holds the evaluate outputs and tool errors as returned. The raw records are root's supported T3 activity recovery.
- `REDACTION-INDEX.md`, which marks the two capability-bearing evaluate inputs.
- `NOTES.md`.

No screenshots exist because no snapshot succeeded.

## Unresolved objections carried forward

- D4 (the goal-95 rule crossing the end value) is still open. It was not re-observed this round.
- D3 is still preserved only by v5 evidence.
- From v5: keyboard focus, goals 1/100, gridline contact and the 390 dark Export wrap caveat were never checked live.
- v5's HTTPS H2 403 is superseded by root's passing H2 check. Even so, no browser-level HTTPS acceptance has happened in any round.
