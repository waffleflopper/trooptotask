window.__m = () => {
	const host = document.querySelector('[data-testid="training-briefing-forecast"]');
	if (!host) return { error: 'no forecast' };
	const svg = host.querySelector('svg');
	if (!svg) return { error: 'no svg' };
	const R = (r) => ({ l: +r.left.toFixed(1), t: +r.top.toFixed(1), r: +r.right.toFixed(1), b: +r.bottom.toFixed(1) });
	const dist = (a, b) => {
		const dx = Math.max(0, b.l - a.r, a.l - b.r);
		const dy = Math.max(0, b.t - a.b, a.t - b.b);
		return Math.hypot(dx, dy);
	};
	const texts = [...svg.querySelectorAll('text')];
	const goalEl = texts.find((t) => /^Goal \d+%$/.test(t.textContent.trim()));
	if (!goalEl) return { error: 'no goal text' };
	const g = R(goalEl.getBoundingClientRect());
	const svgR = R(svg.getBoundingClientRect());
	const cs = getComputedStyle(goalEl);
	const ctx = document.createElement('canvas').getContext('2d');
	ctx.font = `${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
	const tm = ctx.measureText(goalEl.textContent.trim());
	const marks = [];
	const ctm = (el, x, y) => new DOMPoint(x, y).matrixTransform(el.getScreenCTM());
	for (const p of svg.querySelectorAll('path')) {
		const cls = p.getAttribute('class') || '';
		if (!/stroke-foreground|fill-foreground/.test(cls)) continue;
		const len = p.getTotalLength();
		let min = Infinity, maxX = -Infinity;
		for (let i = 0; i <= 400; i++) {
			const q = p.getPointAtLength((len * i) / 400);
			const s = ctm(p, q.x, q.y);
			maxX = Math.max(maxX, s.x);
			min = Math.min(min, dist(g, { l: s.x, r: s.x, t: s.y, b: s.y }));
		}
		const sw = parseFloat(getComputedStyle(p).strokeWidth) || 0;
		marks.push({ kind: /fill-foreground/.test(cls) ? 'area' : 'line', gap: +(min - (/fill-foreground/.test(cls) ? 0 : sw / 2)).toFixed(1), maxX: +maxX.toFixed(1) });
	}
	for (const c of svg.querySelectorAll('circle')) marks.push({ kind: 'dot', gap: +dist(g, R(c.getBoundingClientRect())).toFixed(1), rect: R(c.getBoundingClientRect()) });
	let band = null;
	for (const rc of svg.querySelectorAll('rect')) {
		const cls = rc.getAttribute('class') || '';
		if (!/fill-warning/.test(cls)) continue;
		const r = R(rc.getBoundingClientRect());
		if (r.r - r.l === 0 && r.b - r.t === 0) continue;
		const kind = /warning\/10/.test(cls) ? 'band' : 'bar';
		if (kind === 'band') band = r;
		marks.push({ kind, gap: +dist(g, r).toFixed(1), rect: r });
	}
	for (const t of texts) { if (t === goalEl) continue; const r = R(t.getBoundingClientRect()); marks.push({ kind: 'text:' + t.textContent.trim(), gap: +dist(g, r).toFixed(1), rect: r }); }
	const rule = svg.querySelector('.stroke-success');
	const ruleR = rule ? R(rule.getBoundingClientRect()) : null;
	const nearest = marks.sort((a, b) => a.gap - b.gap).slice(0, 4);
	const clipAnc = [];
	for (let el = svg; el && el !== document.body; el = el.parentElement) {
		const o = getComputedStyle(el);
		if (o.overflowX !== 'visible') { const r = el.getBoundingClientRect(); clipAnc.push({ tag: el.tagName, ov: o.overflowX, right: +r.right.toFixed(1), clipsGoal: r.right < g.r }); }
	}
	const checked = document.querySelector('[aria-label="Forecast horizon"] [aria-checked="true"]');
	return {
		vw: innerWidth, theme: document.documentElement.dataset.theme, horizon: checked?.textContent.trim(), url: location.search,
		goal: goalEl.textContent.trim(), goalRect: g, ruleY: ruleR ? +((ruleR.t + ruleR.b) / 2).toFixed(1) : null, textMidY: +((g.t + g.b) / 2).toFixed(1),
		ruleL: ruleR?.l, ruleR: ruleR?.r, svg: svgR, edgeSlack: +(svgR.r - g.r).toFixed(1), font: cs.fontFamily, fontSize: cs.fontSize, fill: cs.fill,
		measuredW: +tm.width.toFixed(1), boxW: +(g.r - g.l).toFixed(1), plexLoaded: document.fonts.check('11px "IBM Plex Mono"'),
		minGap: nearest[0]?.gap, nearest, band, bandOverrun: band && ruleR ? +(band.r - ruleR.r).toFixed(1) : null, clipAnc,
		sr: [...host.querySelectorAll('.sr-only tbody tr')].map((r) => r.textContent.replace(/\s+/g, ' ').trim()).slice(-2)
	};
};
