export async function request(input) {
 const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
 if(location.origin!==input.origin || !/^http:\/\/127\.0\.0\.1:\d+$/.test(input.origin)) throw Error('Wrong owned origin');
 if(!uuid.test(input.org)||input.organizations.length!==2||!input.organizations.every(x=>uuid.test(x.id)&&/^[a-z0-9-]+$/.test(x.segment))||!input.organizations.some(x=>x.id===input.org&&x.segment===input.organizationSegment)) throw Error('Wrong synthetic Organization');
 if(!input.organizations.some(x=>location.pathname.split('/')[2]===x.id||location.pathname.split('/')[2]===x.segment)||location.pathname.split('/')[1]!=='org') throw Error('Use owned Organization page');
 const body=input.body;
 if(!body||Array.isArray(body)||typeof body!=='object') throw Error('Body denied');
 let path;
 if(input.family==='ict-defaults') {
  if(input.method!=='POST'||Object.keys(body).sort().join(',')!=='defaultExpirationMonths,expiringSoonWarningDays') throw Error('Defaults method/fields denied');
  if(!(body.defaultExpirationMonths===null||Number.isInteger(body.defaultExpirationMonths)&&body.defaultExpirationMonths>=1&&body.defaultExpirationMonths<=120)||!(body.expiringSoonWarningDays===null||Number.isInteger(body.expiringSoonWarningDays)&&body.expiringSoonWarningDays>=1&&body.expiringSoonWarningDays<=365)) throw Error('Defaults values denied');
  path='api/critical-tasks/settings';
 } else {
  if(input.method!=='GET'||Object.keys(body).length) throw Error('Read method/body denied');
  const paths={'members':'settings/members/__data.json','danger':'settings/danger/__data.json','dashboard':'__data.json','ict-summary':'api/critical-tasks/reports/summary'};
  path=paths[input.family]; if(!path) throw Error('Family denied');
 }
 const response=await fetch(`/org/${input.organizationSegment}/${path}`,{method:input.method,credentials:'same-origin',redirect:'manual',headers:{'Content-Type':'application/json'},...(input.method==='POST'?{body:JSON.stringify(body)}:{})});
 let text=await response.text();const secrets=new Set();
 for(const line of text.split('\n')) {try {const root=JSON.parse(line);function visit(v){if(Array.isArray(v)){for(const x of v){if(x&&typeof x==='object'&&!Array.isArray(x))for(const [key,index] of Object.entries(x))if(/^(access_token|refresh_token|anonKey|supabaseAnonKey)$/i.test(key)&&typeof index==='number'&&typeof v[index]==='string')secrets.add(v[index]);visit(x);}}else if(v&&typeof v==='object'){for(const [k,x] of Object.entries(v)){if(/^(access_token|refresh_token|anonKey|supabaseAnonKey)$/i.test(k)&&typeof x==='string')secrets.add(x);visit(x);}}}visit(root);}catch{}}
 for(const secret of secrets)if(secret)text=text.split(secret).join('[REDACTED AUTH]');
 text=text.replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,'[REDACTED JWT]');
 return {url:response.url,method:input.method,body,status:response.status,contentType:response.headers.get('content-type'),response:text,authValuesRedacted:secrets.size};
}
