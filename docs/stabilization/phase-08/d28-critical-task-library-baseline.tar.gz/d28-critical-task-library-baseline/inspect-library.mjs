import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import ExcelJS from 'exceljs';
import { unflatten } from 'devalue';

const root = dirname(fileURLToPath(import.meta.url));
const read = (name) => readFileSync(join(root, name));
const json = (name) => JSON.parse(read(name));
const rows = (name) => json(name).rows;
const one = (name) => {
	const values = rows(name);
	assert.equal(values.length, 1, name);
	return values[0];
};
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
const payloads = readdirSync(root).filter((name) => name !== 'inventory.json').sort();
const inventory = json('inventory.json').files;
assert.deepEqual(payloads, Object.keys(inventory).sort());
for (const name of payloads) assert.equal(digest(read(name)), inventory[name], name);

const candidate = 'd4751ae6d8c63013052a0aabfce9c6c533ca266a84357d970d5885fc875fcc10';
for (const file of ['doctor-start.json', 'doctor-final.json']) {
	const doctor = json(file);
	assert.equal(doctor.status, 'PASS');
	assert.equal(doctor.candidate, candidate);
	assert.equal(doctor.revision, 'cba2ee802355c6f5a62c886de2979ebcf5085ccf');
}
assert.equal(json('cleanup-final.json').status, 'PASS');
assert.equal(json('clean-seeds.json').cleaned, true);
assert.equal(json('critical-tasks-sql-receipt.json').exit, 0);
assert.match(read('critical-tasks-sql.log').toString(), /Files=4, Tests=75/);

const created = one('task-created-row.json');
assert.equal(created.task_code, 'VERIFY-D28-LIB-BASE');
assert.equal(created.title, 'D28 baseline library task');
assert.deepEqual(created.mos, ['68W', '18D']);
assert.equal(created.expiration_months, 24);
assert.equal(created.sort_order, 30);
assert.equal(created.description, 'Synthetic task-definition persistence witness');
assert.equal(created.category, 'Readiness Verification');
const edited = one('task-edited-row.json');
assert.equal(edited.id, created.id);
assert.equal(edited.created_at, created.created_at);
assert.equal(edited.title, 'D28 baseline library task edited');
assert.equal(edited.expiration_months, 18);
assert.deepEqual(one('task-canceled-row.json'), edited);
assert.equal(one('task-retry-row.json').task_code, 'VERIFY-D28-LIB-RETRY-BASE');
assert.equal(json('task-import-invalid-row.json').count, 0);

const imported = one('task-imported-row.json');
const upserted = one('task-upsert-row.json');
const archived = one('task-before-batch-restore.json');
const restored = one('task-after-batch-restore.json');
for (const value of [upserted, archived, restored]) {
	assert.equal(value.id, imported.id);
	assert.equal(value.created_at, imported.created_at);
}
assert.equal(upserted.title, 'D28 imported library task updated');
assert.equal(upserted.expiration_months, 9);
assert.notEqual(archived.archived_at, null);
assert.equal(restored.archived_at, null);
assert.match(read('import-restore-result.txt').toString(), /1 restored/);

const original = one('completions-A-before.json');
assert.deepEqual(one('alpha-restored-completion.json'), original);
const completed = rows('completion-retry-rows.json');
assert.equal(completed.length, 2);
const allMos = completed.find((row) => row.notes === 'D28 task reference baseline');
assert.ok(allMos);
assert.equal(allMos.completed_at, '2026-10-05');
assert.equal(allMos.validated_by, 'D28 synthetic validator');
assert.equal(allMos.validation_method, 'Demonstration');
assert.equal(one('completion-edited-row.json').id, allMos.id);
assert.equal(one('completion-edited-row.json').notes, 'D28 task reference baseline edited');
const afterImport = rows('completion-import-rows.json');
assert.equal(afterImport.length, 3);
assert.equal(afterImport.find((row) => row.notes === 'D28 imported same-date task reference').id, allMos.id);
assert.equal(rows('completion-failure-rows.json').length, 1);
assert.equal(json('completion-failure-state.json').calls[0].status, 503);
assert.ok(json('archived-completion-guards.json').every((request) => request.status === 400));
assert.equal(json('active-completion-delete.json')[0].status, 200);
assert.deepEqual(rows('active-delete-readback.json').find((row) => row.id === original.id), original);
assert.equal(rows('active-delete-readback.json').length, 2);

for (const actor of ['viewer', 'scoped', 'empty', 'training-only']) {
	assert.ok(json(`${actor}-denials.json`).every((request) => request.status === 403));
}
assert.ok(json('foreign-denials.json').every((request) => request.status === 404));
assert.deepEqual(json('tasks-B-after-denials.json'), json('tasks-B-before.json'));
assert.ok(!rows('tasks-A-after-denials.json').some((row) => row.task_code === 'VERIFY-D28-DENIED-BASE'));
assert.match(read('owner-personnel-detail-settled.txt').toString(), /2 of 2 applicable ICT tasks ready/);
assert.ok(!read('personnel-manager-detail-reload.txt').toString().includes('applicable ICT tasks ready'));

const dashboard = json('owner-dashboard-http-redacted.json');
assert.equal(dashboard.status, 200);
const decoded = dashboard.records.flatMap((record) => record.nodes
	? record.nodes.filter((node) => node?.data).map((node) => unflatten(node.data, { Promise: (id) => ({ pending: id }) }))
	: record.data ? [unflatten(record.data, { Promise: (id) => ({ pending: id }) })] : []);
const summary = decoded.find((value) => value.ictlSummary)?.ictlSummary;
assert.equal(summary.overallReadinessPercent, 60);
assert.equal(summary.readyCount, 3);
assert.equal(summary.applicableCount, 5);
assert.equal(summary.atRiskSoldiers.find((row) => row.soldierName === 'Able, Synthetic').readinessPercent, 100);

async function sheet(file, name) {
	const workbook = new ExcelJS.Workbook();
	await workbook.xlsx.readFile(join(root, file));
	const target = workbook.getWorksheet(name);
	assert.ok(target, name);
	const values = [];
	target.eachRow((row) => values.push(row.values.slice(1)));
	return values;
}
const report = await sheet('report-initial.xlsx', 'Critical Tasks Report');
assert.equal(report.find((row) => row[0] === 'Summary' && row[1] === 'Overall Readiness')[2], '20%');
assert.equal(report.find((row) => row[1] === 'Able, Synthetic')[2], '50%');
const matrix = await sheet('matrix-after-import.xlsx', 'Critical Task Matrix');
assert.deepEqual(matrix[0].slice(5), [
	'VERIFY-ICT-ALPHA Verification Alpha Critical Task',
	'VERIFY-ICT-ALL Verification All-MOS Critical Task',
	'VERIFY-D28-LIB-IMPORT-BASE D28 imported library task updated'
]);
assert.equal(matrix.length, 4);
assert.equal(matrix.find((row) => row[0] === 'Able, Synthetic')[6], 'Current (2026-10-05)');
assert.equal(matrix.find((row) => row[0] === 'Baker, Synthetic')[6], 'Not Recorded');
assert.equal(matrix.find((row) => row[0] === 'Unassigned, Synthetic')[6], 'Current (2026-10-05)');
console.log(JSON.stringify({ status: 'PASS', payloads: payloads.length, candidate, workbooks: 2 }));
