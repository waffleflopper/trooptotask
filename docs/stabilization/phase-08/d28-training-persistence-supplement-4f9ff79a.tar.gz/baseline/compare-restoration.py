import json,pathlib
r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-remaining-20261007');j=json.loads((r/'precleanup-seed-journal.json').read_text());tables=['training_types','training_views','personnel_trainings','personnel'];comparisons=[]
for org in ['orgA','orgB']:
 for table in tables:
  before=json.loads((r/f'original-{org}-{table}.json').read_text())['rows'];after=json.loads((r/f'afterclean-{org}-{table}.json').read_text())['rows'];key=lambda v:v['id'];assert sorted(before,key=key)==sorted(after,key=key),(org,table);comparisons.append({'organization':org,'table':table,'rows':len(before),'allSavedFieldsExact':True})
absence=[]
for seed in j['seeded']:
 rows=json.loads((r/f'afterclean-orgA-{seed["table"]}.json').read_text())['rows'];found={x['id'] for x in rows}&set(seed['ids']);assert not found,(seed,found);absence.append({'kind':seed['kind'],'table':seed['table'],'temporaryIdsAbsent':len(seed['ids'])})
pre=json.loads((r/'precleanup-orgA-groups.json').read_text())['rows'];temps={i for s in j['seeded'] if s['table']=='groups' for i in s['ids']};pre=[x for x in pre if x['id'] not in temps];post=json.loads((r/'afterclean-orgA-groups.json').read_text())['rows'];assert sorted(pre,key=lambda x:x['id'])==sorted(post,key=lambda x:x['id'])
private=json.load(open('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1/verify-trooptotask-owned.json'));assert not private['seeded'];assert not private['grants'];(r/'postcleanup-seed-journal.json').write_text(json.dumps(private,indent=2))
result={'status':'PASS','originalComparisons':comparisons,'temporaryAbsence':absence,'temporaryIdsAbsent':sum(v['temporaryIdsAbsent'] for v in absence),'originalGroupsExact':len(post),'journalCleared':True,'originalTimestampEquality':'PASS all original business rows unchanged; no original writes were performed in this session.'};(r/'restoration-comparison.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
