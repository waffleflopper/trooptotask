import json,subprocess,pathlib,time
root=pathlib.Path(__file__).resolve().parent
helper=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1']
events=[]
def call(label,args,cli=False):
 start=time.time()
 command=(['npm','run','--silent','verify:app','--'] if cli else helper)+args
 r=subprocess.run(command,capture_output=True,text=True)
 (root/(label+'.json')).write_text(r.stdout)
 (root/(label+'.stderr')).write_text(r.stderr)
 events.append({'label':label,'command':command,'exit':r.returncode,'seconds':round(time.time()-start,3)})
 (root/'actions.json').write_text(json.dumps(events,indent=2)+'\n')
 print(label,r.returncode,flush=True)
 if r.returncode: raise RuntimeError('Control failed: '+label)
 return json.loads(r.stdout)
call('doctor-before',['doctor'],True)
call('fixture',['fixture'])
call('settings',['retention','settings'])
for table in ['ict_tasks','assignment_types','personnel_ict_completions','daily_assignments','audit_logs','notifications','personnel_onboardings','onboarding_step_progress']:
 for org in ['orgA','orgB']: call('original-'+table+'-'+org,['rows',table,org])
call('small-seed',['seed','maintenance-retention'])
call('onboarding-seed',['seed','onboarding-retention'])
call('small-before',['retention','maintenance'])
for job in ['records','onboarding','audit','setup-links']:
 for mode in ['missing','wrong']: call('small-'+job+'-'+mode,['retention','cron',mode,job])
call('small-denied-readback',['retention','maintenance'])
for job in ['records','onboarding','audit','setup-links']:
 call('small-'+job+'-run',['retention','cron','run',job])
 call('small-'+job+'-repeat',['retention','cron','run',job])
call('small-after',['retention','maintenance'])
for table in ['notifications','personnel_onboardings','onboarding_step_progress']:
 for org in ['orgA','orgB']:call('small-after-'+table+'-'+org,['rows',table,org])
call('small-clean',['clean-seeds'])
call('large-seed',['seed','maintenance-retention-1001'])
call('large-before',['retention','maintenance'])
for job in ['records','audit','setup-links']:
 call('large-'+job+'-run',['retention','cron','run',job])
call('large-after',['retention','maintenance'])
call('large-clean',['clean-seeds'])
for table in ['ict_tasks','assignment_types','personnel_ict_completions','daily_assignments','personnel_onboardings','onboarding_step_progress']:
 for org in ['orgA','orgB']:call('restored-'+table+'-'+org,['rows',table,org])
call('doctor-final',['doctor'],True)
call('cleanup',['cleanup'],True)
