import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ExcelJS from 'exceljs';

const root = path.dirname(fileURLToPath(import.meta.url));
const read = async (name) => JSON.parse(await fs.readFile(path.join(root, name), 'utf8'));
const text = async (name) => fs.readFile(path.join(root, name), 'utf8');
const rows = async (name) => (await read(name)).rows;
const index = (values) => {
 const result = new Map(values.map(row => [row.id, row]));
 assert.equal(result.size, values.length, 'Duplicate saved identity');
 return result;
};
const tables = ['organizations','groups','personnel','personnel_extended_info','organization_rank_catalog','leader_notes','personnel_follow_ups','counseling_records','personnel_documents','availability_entries','status_types','assignment_types','daily_assignments','special_days','notifications','audit_logs','data_exports','organization_memberships','organization_invitations','organization_invitation_email_outbox','access_request_organization_invitation_links','dashboard_configs','getting_started_progress','user_org_preferences','user_pinned_groups','beta_feedback','sign_in_rosters','training_types','training_views','personnel_trainings','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress','deletion_requests','ict_tasks','personnel_ict_completions','rating_scheme_entries'];
const fixture = await read('fixture.json');
const memberships = {orgA: await rows('requesters-a.json'), orgB: await rows('requesters-b.json')};
const requester = Object.fromEntries(Object.entries(memberships).map(([org, values]) => {
 const owners = values.filter(row => row.role === 'owner');
 assert.equal(owners.length, 1, `Expected one synthetic ${org} owner`);
 return [org, owners[0].user_id];
}));
const book = new ExcelJS.Workbook();
await book.xlsx.readFile(path.join(root, 'owner-a.xlsx'));
const raw = book.getWorksheet('Raw - Data Export Records');
assert.ok(raw, 'Missing lifecycle worksheet');
const headers = raw.getRow(1).values.slice(1).map(value => String(value).toLowerCase().replaceAll(' ', '_'));
const workbookRows = [];
for(let n = 2; n <= raw.rowCount; n++) workbookRows.push(Object.fromEntries(headers.map((key, column) => [key, raw.getRow(n).getCell(column + 1).value ?? null])));
const cases = [
 {name:'json',org:'orgA',artifact:'owner-a.json',before:'initial-orgA-data_exports.json',after:'json-after-lifecycle.json'},
 {name:'excel',org:'orgA',artifact:'owner-a.xlsx',before:'json-after-lifecycle.json',after:'excel-after-lifecycle.json'},
 {name:'retry',org:'orgA',artifact:'retry-a.json',before:'failure-after-lifecycle.json',after:'retry-after-lifecycle.json'},
 {name:'b',org:'orgB',artifact:'owner-b.json',before:'initial-orgB-data_exports.json',after:'b-after-lifecycle.json'}
];
const verified = [];
for(const entry of cases) {
 const prior = await rows(entry.before), later = await rows(entry.after);
 const previous = index(prior), saved = index(later);
 for(const row of prior) assert.deepEqual(saved.get(row.id), row, `${entry.name} changed previous history`);
 const added = later.filter(row => !previous.has(row.id));
 assert.equal(added.length, 1, `${entry.name} new lifecycle count`);
 assert.equal(later.length, prior.length + 1);
 const row = added[0];
 assert.equal(row.org_id, fixture.ids[entry.org]);
 assert.equal(row.requested_by, requester[entry.org]);
 assert.equal(row.status, 'completed');
 const data = await fs.readFile(path.join(root, entry.artifact));
 const savedArtifact = await read(`${entry.name}-save.json`);
 assert.equal(savedArtifact.bytes, data.length);
 assert.equal(savedArtifact.sha256, createHash('sha256').update(data).digest('hex'));
 assert.equal(row.file_size_bytes, data.length);
 assert.ok(Number.isFinite(Date.parse(row.created_at)));
 assert.ok(Number.isFinite(Date.parse(row.completed_at)));
 assert.ok(Date.parse(row.completed_at) >= Date.parse(row.created_at));
 let artifactRows;
 if(entry.name === 'excel') artifactRows = workbookRows;
 else {
  const backup = JSON.parse(data);
  assert.equal(backup.organizationId, fixture.ids[entry.org]);
  assert.deepEqual(backup.sectionInventory.map(section => section.table).sort(), [...tables].sort());
  for(const section of backup.sectionInventory) {
   const values = backup[section.key];
   assert.deepEqual(values, backup.sections[section.key]);
   assert.equal(values.length, section.rowCount);
   const orgKey = section.table === 'organizations' ? 'id' : ['audit_logs','data_exports','dashboard_configs'].includes(section.table) ? 'org_id' : 'organization_id';
   for(const value of values) assert.equal(value[orgKey], fixture.ids[entry.org], `${entry.name} foreign ${section.table}`);
  }
  artifactRows = backup.dataExports;
 }
 const archived = index(artifactRows);
 assert.equal(artifactRows.length, later.length);
 for(const previousRow of prior) assert.deepEqual(archived.get(previousRow.id), previousRow, `${entry.name} lost prior history`);
 assert.deepEqual(archived.get(row.id), {...row, status:'processing', completed_at:null, file_size_bytes:null});
 verified.push({name:entry.name,organization:entry.org,exportId:row.id,requester:row.requested_by,createdAt:row.created_at,completedAt:row.completed_at,bytes:data.length});
}
const beforeFailure = await rows('excel-after-lifecycle.json'), afterFailure = await rows('failure-after-lifecycle.json');
const failureIndex = index(beforeFailure);
for(const row of beforeFailure) assert.deepEqual(index(afterFailure).get(row.id), row);
const failed = afterFailure.filter(row => !failureIndex.has(row.id));
assert.equal(failed.length, 1);
assert.equal(afterFailure.length, beforeFailure.length + 1);
assert.equal(failed[0].org_id, fixture.ids.orgA);
assert.equal(failed[0].requested_by, requester.orgA);
assert.equal(failed[0].status, 'failed');
assert.equal(failed[0].file_size_bytes, null);
assert.ok(Number.isFinite(Date.parse(failed[0].completed_at)));
assert.ok(Date.parse(failed[0].completed_at) >= Date.parse(failed[0].created_at));
assert.deepEqual((await read('failure-network.json')).calls.map(call => call.status), [500]);
assert.equal((await read('failure-capture.json')).captured, false);
const source = (await read('failure-source-state.json')).control;
assert.equal(source.phase, 'synthetic-failure');
assert.deepEqual(source.call, {method:'GET',table:'availability_entries',orgId:fixture.ids.orgA,status:500,synthetic:true});
assert.deepEqual((await read('retry-network.json')).calls.map(call => call.status), [500,200]);
assert.match(await text('failure-after-ui.txt'), /Export failed\. Please try again\./);
for(const name of ['json','excel','retry','b']) assert.match(await text(`${name}-after-ui.txt`), /Export downloaded successfully\./);
for(const name of ['json','excel']) assert.deepEqual((await read(`${name}-network.json`)).calls.map(call => call.status), [200]);
const nativeB = (await read('b-native-network.json')).content.filter(item => item.type === 'text').map(item => item.text).join('\n');
assert.ok(nativeB.includes(`POST ${(await read('doctor-start.json')).origin}/org/${fixture.ids.orgB}/api/export [200]`));
assert.equal((await read('viewer-http.json')).status, 403);
assert.equal((await read('foreign-target-http.json')).status, 404);
assert.match(await text('viewer-ui.txt'), /403|Forbidden|don't have access|do not have access/i);
for(const org of ['orgA','orgB']) {
 const final = await rows(org === 'orgA' ? 'retry-after-lifecycle.json' : 'b-after-lifecycle.json');
 assert.deepEqual(index(await rows(org === 'orgA' ? 'a-reload-lifecycle.json' : 'b-reload-lifecycle.json')), index(final));
 assert.deepEqual(index(await rows(`after-denials-${org}-data_exports.json`)), index(final));
 const successes = verified.filter(entry => entry.organization === org);
 const audit = (await rows(`after-denials-${org}-audit_logs.json`)).filter(row => ['export.created','export.excel_created'].includes(row.action));
 assert.deepEqual(audit.map(row => row.resource_id).sort(), successes.map(entry => entry.exportId).sort());
 for(const row of audit) assert.equal(row.user_id, requester[org]);
 const admins = memberships[org].filter(row => ['owner','admin'].includes(row.role) && row.user_id !== requester[org]);
 const notifications = (await rows(`after-denials-${org}-notifications.json`)).filter(row => row.type === 'bulk_data_exported');
 assert.equal(notifications.length, admins.length * successes.length);
 for(const admin of admins) assert.equal(notifications.filter(row => row.user_id === admin.user_id).length, successes.length);
 for(const table of ['organizations','personnel','availability_entries','sign_in_rosters']) assert.deepEqual(index(await rows(`after-${org}-${table}.json`)), index(await rows(`initial-${org}-${table}.json`)), `Changed original ${org} ${table}`);
}
const report = {status:'PASS',completed:verified,failedExportId:failed[0].id,sourceFailure:500,explicitRetry:200,nativeB:200,viewer:403,foreignTarget:404,reloadedHistoriesUnchanged:true,deniedHistoriesUnchanged:true,originalSourceTablesUnchanged:8,workbookSheets:book.worksheets.length};
await fs.writeFile(path.join(root,'lifecycle-comparison.json'), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
