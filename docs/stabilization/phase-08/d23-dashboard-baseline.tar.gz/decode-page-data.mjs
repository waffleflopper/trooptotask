import fs from 'node:fs';
import { unflatten } from 'devalue';
const dir='.verification/evidence/verify-trooptotask/d23-dashboard-baseline/';
const input=JSON.parse(fs.readFileSync(dir+process.argv[2],'utf8'));
const messages=input.body.trim().split('\n').map(JSON.parse);
const decode=data=>unflatten(data,{Promise:id=>({deferredId:id})});
const chunks=new Map(messages.filter(m=>m.type==='chunk').map(m=>[m.id,decode(m.data)]));
const resolve=value=>{
 if (!value||typeof value!=='object') return value;
 if (Object.keys(value).length===1 && 'deferredId' in value) return resolve(chunks.get(value.deferredId));
 if (Array.isArray(value)) return value.map(resolve);
 return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,resolve(item)]));
};
const data=messages.find(m=>m.type==='data');
const nodes=data?.nodes.map(node=>node?.type==='data'?resolve(decode(node.data)):node);
const combined=Object.assign({},...nodes.filter(node=>node&&typeof node==='object'));
fs.writeFileSync(dir+process.argv[2].replace('.json','-decoded.json'),JSON.stringify({path:input.path,status:input.status,nodes},null,2));
const dashboard=combined.dashboard?.data;
console.log(JSON.stringify({status:input.status,timezone:input.timezone,nodeKeys:nodes.map(n=>Object.keys(n??{})),personnel:dashboard?.data?.personnel?.map(p=>({id:p.id,name:p.lastName})),ratingEntries:dashboard?.data?.ratingSchemeEntries,onboarding:dashboard?.data?.activeOnboardings,trainingSummary:combined.summary?.trainingSummary,ictlSummary:combined.summary?.ictlSummary},null,2));
