SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('count', count(*)) FROM pg_stat_activity WHERE application_name = 't2t-d15-race-87a0325d';
