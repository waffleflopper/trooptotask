import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createClient} from '@supabase/supabase-js';
import {repository,sessionPath,readJSON,processIdentity} from '../scripts/verification/core.mjs';
import {cleanPlatform,readPlatform} from '../.agents/skills/verify-trooptotask/helpers/platform-fixtures.mjs';
const directory=sessionPath('1');
const state=await readJSON(path.join(directory,'session.json'));
assert.equal(state.repository,repository); assert.equal(state.worker,'1'); assert.equal(state.phase,'running');
const supervisorProcess=await processIdentity(state.supervisor.pid);
assert.equal(supervisorProcess.start,state.supervisor.start); assert.equal(supervisorProcess.command,state.supervisor.command);
const response=await fetch(`http://127.0.0.1:${state.controlPort}`,{method:'POST',headers:{Authorization:`Bearer ${state.token}`,'Content-Type':'application/json'},body:JSON.stringify({command:'doctor'})});
assert.equal(response.headers.get('X-T2T-Session'),state.id); assert.equal((await response.json()).status,'PASS');
const config=await readJSON(path.join(directory,'provider.json'));
const url=new URL(config.API_URL); assert.equal(url.hostname,'127.0.0.1'); assert.equal(url.protocol,'http:');
const client=createClient(config.API_URL,config.SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
const fixture=await readJSON(path.join(directory,'fixtures.json'));
const ledger=path.join(directory,'verify-trooptotask-owned.json');
const scratch='.verification/d21-explicit-audit-sentinels.json';
const ownedState=await readJSON(ledger);
const save=async(value)=>fs.writeFile(ledger,JSON.stringify(value,null,2),{mode:0o600});
const checked=(result)=>{if(result.error) throw new Error('Owned audit proof failed: '+result.error.message);return result.data;};
if(process.argv[2]==='prepare') {
  const userId=fixture.actors.orgInvitee.id;
  const rows=[
    {id:randomUUID(),user_id:userId,org_id:null,resource_id:userId,resource_type:'user',action:'suspend_user',severity:'critical',timestamp:new Date().toISOString(),details:{synthetic:'unregistered current platform audit sentinel'}},
    {id:randomUUID(),user_id:userId,org_id:null,resource_id:userId,resource_type:'user',action:'auth.password_update_rate_limited',severity:'warning',timestamp:new Date().toISOString(),details:{synthetic:'unrelated audit sentinel'}},
    {id:randomUUID(),user_id:userId,org_id:null,resource_id:userId,resource_type:'user',action:'suspend_user',severity:'critical',timestamp:new Date(new Date(ownedState.platform.seededAt).getTime()-86400000).toISOString(),details:{synthetic:'earlier platform audit sentinel'}}
  ];
  await fs.writeFile(scratch,JSON.stringify({session:state.id,rows},null,2),{mode:0o600});
  checked(await client.from('audit_logs').insert(rows));
  console.log(JSON.stringify({boundary:'Privileged synthetic audit setup, not an Identity producer invocation.',rows,platform:await readPlatform({client,fixture,ownedState})},null,2));
} else if(process.argv[2]==='verify-clean') {
  const sentinels=await readJSON(scratch); assert.equal(sentinels.session,state.id);
  const ids=sentinels.rows.map(row=>row.id);
  const read=()=>client.from('audit_logs').select('id,user_id,org_id,resource_id,resource_type,action,severity,timestamp,details').in('id',ids).order('id');
  const before=checked(await read()); assert.equal(before.length,3);
  const platformBefore=await readPlatform({client,fixture,ownedState});
  assert.ok(platformBefore.audit.some(row=>row.action==='suspend_user'));
  assert.ok(platformBefore.audit.some(row=>row.action==='unsuspend_user'));
  assert.equal(platformBefore.audit.filter(row=>!ids.includes(row.id)).length,2);
  assert.equal(ownedState.platform.userAuditIds.length,2);
  assert.ok(ownedState.platform.userAuditIds.every(id=>!ids.includes(id)));
  const cleaned=await cleanPlatform({client,fixture,ownedState,save});
  const after=checked(await read()); assert.deepEqual(after,before);
  assert.equal(cleaned.removedAuditIds.length,2);
  assert.ok(cleaned.retainedUserAuditIds.includes(sentinels.rows[0].id));
  console.log(JSON.stringify({boundary:'Exact owned provider cleanup proof, separate from native mutation.',sentinelsBefore:before,platformBefore,cleaned,sentinelsAfter:after},null,2));
  checked(await client.from('audit_logs').delete().in('id',ids));
  assert.deepEqual(checked(await read()),[]);
  await fs.unlink(scratch);
  console.log(JSON.stringify({sentinelFixtureCleanup:{removedExactIds:ids,remaining:[]}}));
} else throw new Error('Unknown audit proof mode');
