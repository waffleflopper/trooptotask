#!/usr/bin/env bash
# usage: r.sh NAME DESCRIPTION -- cmd args...
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp NODE_DISABLE_COMPILE_CACHE=1
E=.verification/evidence/verify-trooptotask/1504-baseline-v1
n=$1; d=$2; shift 3
out=$("$@" 2>$E/receipts/$n.stderr); rc=$?
printf '%s' "$out" > $E/receipts/$n.stdout
printf '{"name":"%s","description":"%s","exit":%d,"at":"%s","argv":%s}\n' "$n" "$d" $rc "$(date -Is)" "$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1:]))' "$@")" >> $E/receipts/index.jsonl
echo "[exit $rc]"; printf '%s\n' "$out"; [ -s $E/receipts/$n.stderr ] && { echo "--stderr--"; head -c 2000 $E/receipts/$n.stderr; }
exit 0
