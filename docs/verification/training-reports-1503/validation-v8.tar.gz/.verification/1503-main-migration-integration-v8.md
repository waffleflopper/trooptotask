# Issue 1503 main migration integration v8

The unreleased Training goal migration now uses the observed UTC timestamp `20261004100618`. This separates it from main's `20261004000200_critical_task_archive_retention.sql`. Training SQL remains byte-for-byte unchanged; all main migration bytes, retained contracts and archived proof remain intact.

Inspected HEAD: `c09b67376abc3936e1b141407c6759b362fe5c6a`, after main `6555c3c` integration and root's restoration of its own work. This pass changed only the paths below and this ignored report. It performed no staging, commit, publication, full application suite/build, DB/service, browser, worker or Serve operation.

## Actual changes

| Path                                                                                                            | Change                                                                                                                                                         |
| --------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `supabase/migrations/20261004000200_training_readiness_goal.sql` → `20261004100618_training_readiness_goal.sql` | Filename only, using root's observed `2026-10-04T10:06:18Z`; no SQL edit.                                                                                      |
| `scripts/ci/database.py`                                                                                        | One Training filename replacement. All main held migrations, fixture/contract entries, their order and lifecycle behavior preserved.                           |
| `supabase/migration-tests/training_readiness_goal_before.sql` and `_after.sql`                                  | Goal ledger version only: `20261004000200` → `20261004100618`. All assertions and saved witnesses retained.                                                    |
| `supabase/migration-tests/critical_task_archive_retention_before.sql`                                           | Organization branch of current-row view excludes exactly `training_readiness_goal_percent`.                                                                    |
| `docs/verification/training-reports-1501/acceptance.md` and `1502/acceptance.md`                                | Only current release-prerequisite paragraphs name the timestamped migration and qualify the second collision. Earlier 00100→00200 integration context remains. |

The actual working-tree diff against HEAD also contains root's earlier uncommitted 00100→00200 integration. This pass specifically moved the existing 00200 Training file to the timestamped name; it did not alter historical receipts or treat the new name as their tested version.

## Exact hashes and preserved proof

- Training SQL, before/after: `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`.
- Main Critical Task retention SQL, unchanged: `0f6a4e55c4f12ce0e0e2c5db8fd8599cb0c304271bd04eceaf5b5bac863d9c3b`.
- Immutable Critical Task after contract, unchanged: `b3fc14866744ad85e6d1856bff7871d3386aa22ccfe2e08097bb23703aa8d17f`.
- Existing account-preferences before fixture, untouched: `140eeeb708d3413fe84042bcf0b9cadf917f29c582c929f08be1d211bf170ce5`.

All 168 other migration files were hashed before and after this pass and matched. The Critical Task before fixture's exact inspected view used full Organization JSON, then materialized an independent immutable `before_rows` table before upgrade. The new goal key would appear only in the live after view. Excluding this one added key preserves every old Organization field, row identity and timestamp, plus all task/completion witnesses. The saved table is not rebuilt from after rows; the main baseline version `20261004000200`, all fixture values and all after assertions remain unchanged. No general unknown-field exclusion, privilege weakening or threshold change was introduced.

The unchanged separate Training goal contract protects the new field: type, required/default 90, bounds, existing Organization defaults, allowed owner/admin changes and denied member/foreign changes. The existing account-preferences exclusion already handles its own saved old fields and was left untouched.

Root's frozen v7 chart proof remains identified at base `0fa2960956572a8f5dea2de2ab5c8d4893178589` / head `3c0b6f2a`, archive `docs/verification/training-reports-1503/final-v7.tar.gz`, supplied SHA-256 `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200`. This pass neither modified nor relabeled that proof as a run of the integrated candidate.

## Actual no-service checks

Python 3.14.7 was used; explicit Markdown formatting used the established Node 24.21.0 path and npm 11.19.0.

| Check                                                               | Actual result                                                                                                                                                                                   |
| ------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `python3 -B -m unittest discover -s scripts/ci -p test_database.py` | 14 tests passed in 10.130 seconds; exit 0. Docker/Supabase are mocked or fake, with only test-owned temporary files/processes/sockets.                                                          |
| Python in-memory runner compilation/definition load                 | Passed; the entry point and real database validation were not invoked.                                                                                                                          |
| Migration uniqueness/range/reference inspection                     | 169 files / 169 distinct numeric versions, compared with 169 files / 168 distinct versions before the rename. All 28 held migration, 22 fixture and 24 populated contract references exist.     |
| Held fixture/order inspection                                       | Passed: all before fixtures load before migration restoration/up; contracts run afterward. CT/account-preferences/Training fixture and contract entries retain their existing relative order.   |
| Byte/hash preservation checks                                       | Passed: required Training SQL hash, every main migration, immutable CT after contract and untouched account-preferences fixture; only the named CT projection and goal ledger literals changed. |
| Explicit touched-Markdown Prettier write/check                      | Passed, exit 0.                                                                                                                                                                                 |
| Existing local links and `git diff --check`                         | Local targets exist; no link/anchor changes; whitespace check exit 0.                                                                                                                           |

The relevant format check is:

```bash
npm exec prettier -- --ignore-path /dev/null --check \
  docs/verification/training-reports-1501/acceptance.md \
  docs/verification/training-reports-1502/acceptance.md \
  .verification/1503-main-migration-integration-v8.md
git diff --check
```

No filename/prose mirror test or new test abstraction was added. Source ordering checks and existing runner regressions do not establish executed SQL behavior.

## Root-owned release and acceptance

Run the existing `python3 -B scripts/ci/database.py` after root freezes the integrated candidate. It creates two distinct, seed-disabled disposable projects, uses verified unused ports in `58000..64999` and cleans up only its own resources. It performs both fresh replay and populated upgrade; there is no public `--staged-upgrade` option.

Fresh replay now applies all 169 migrations, from `20260413001158_remote_schema.sql` through `20261004100618_training_readiness_goal.sql`. Populated replay uses the unchanged 141-migration predecessor through `20261002000100_atomic_onboarding_note_append.sql`, loads all 22 before fixtures, restores the 28 held files, then runs `supabase migration up --local --yes --include-all` and all 24 after contracts plus retained provider probes. CLI application order is numeric: progress scope `20261004000100`, Critical Task retention `20261004000200`, Training goal `20261004100618`; restoration-list order does not override that ordering. Require independent absent-before/present-after ledger witnesses, exact old-field equality, retained main security/cleanup contracts and separate goal-field checks.

Fresh/populated SQL, final full gates/build and fresh affected browser smoke remain unperformed by this bounded agent and belong to root. Record their actual versions, allocations, commands, results and owned cleanup before acceptance. Do not run `npm run db:test` against the checkout's existing local project; the runner invokes it from its disposable copied context.

Release still requires authorized application of `20261004100618_training_readiness_goal.sql` before deploying consumers that select the new column. No remote migration/deployment is claimed. No further writes are pending after this report.
