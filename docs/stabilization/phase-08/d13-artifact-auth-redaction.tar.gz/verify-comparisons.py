import json
from pathlib import Path
r=Path(__file__).parent
load=lambda name:json.loads((r/(name+'.json')).read_text())
checks=[]
for org in ['orgA','orgB']:
 for table in ['personnel_follow_ups','leader_notes','counseling_records','personnel_documents']:
  before=load(f'before-{org}-{table}')['rows']; after=load(f'after-{org}-{table}')['rows']
  assert before==after,(org,table)
  checks.append({'organization':org,'table':table,'completeRowsUnchanged':True,'count':len(before)})
seed=load('lifecycle-seed'); person=seed['ids']['person']; tag=seed['tag']
expected=[('follow-ups','followOpen','title','Open follow-up '+tag),('leader-notes','noteActive','text','Active note '+tag),('counseling-records','counselingActive','title','Active counseling '+tag),('documents','documentActive','title','Active document '+tag)]
for family,key,field,value in expected:
 body=load('manager-get-'+family)['body']; row=next(x for x in body if x['id']==seed['ids'][key])
 assert all(x['personnelId']==person for x in body)
 assert row[field]==value,(family,row[field],value)
 assert load('manager-get-'+family)['redactedValues']==0
files=load('created-doc-files')['files']; created=[f for f in files if f['present']]; assert len(created)==1
assert created[0]['size']==3187 and created[0]['sha256']=='c47b428801acb793600762a0190a8a50f27986fe81ff39e48b39e80d176441cb'
assert any(f['path']==created[0]['path'] and not f['present'] for f in load('after-orgA-files')['files'])
assert load('manager-real-document-download')['status']==200
assert load('manager-real-document-download')['body']['url'].endswith('?token=[REDACTED]')
assert load('manager-real-document-download')['redactedValues']==1
matrix=load('api-matrix'); assert len(matrix)==17
assert [x['status'] for x in matrix].count(500)==1
assert load('cache-before-cleanup')['privateActorCacheCount']==3
assert load('cache-after-cleanup')['privateActorCacheAbsent']
assert load('doctor-final')['status']=='PASS'
assert load('disposal')['status']=='PASS'
(r/'comparison-results.json').write_text(json.dumps({'tables':checks,'allFamilySeededIDsAndExactKnownFieldsPreserved':True,'actualFileSize':3187,'actualFileSHA256':created[0]['sha256'],'explicitCreatedPathAbsentAfterOrdinaryDelete':True,'requests':17,'metadataOnlyDownloadFailureRetained':True,'privateCachesRemoved':True},indent=2)+'\n')
print('PASS eight complete table comparisons, all-family exact known fields, real PDF, token redaction, explicit deletion path, cache removal and disposal')
