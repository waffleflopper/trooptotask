# 1503 final integration v8 driver evidence

Candidate `0196ae3f…cda1d`, revision `c09b6737`, origin `http://127.0.0.1:33003`, worker 1, session `8f3afad2…`, Chromium 152.0.7977.82 owned profile. Driven 2026-10-04 02:03–02:38 AKDT (asOf 4 Oct throughout). Interpretation lives in `.verification/1503-final-integration-v8-report.md`.

## Levers

- `d.sh` is the v7 receipt wrapper with only its directory changed. Each CLI call writes `receipts/NNNN-label.{json,stdout,stderr}` with argv, start/end time and exit code.
- `t.sh` defines `T` (native tool), `H` (control helper), `S` (fresh snapshot to `snap/`), `C` (fresh snapshot then native click on the first matching accessible name) and `P` (native screenshot).
- `goal.sh VALUE` does the native fill and Save of the Settings › Policies goal, then a privileged `rows organizations orgA` readback.
- `measure.js`, `analyze.py`, `m.sh` and `fonts.js` are copied from v7 (same chart bytes, `ReportForecastChart.svelte` sha256 `706cd892…7b831`). Only paths changed. `m.sh` writes `measure/sweep/<case>.json`.

## Receipts by outcome (receipt numbers)

- Binding and host: `0001` doctor start PASS, `0002` tools, `0003` actor login (page 2), `0004`/`0005` first snapshot and screenshot.
- Shell: Home/Training/Settings/Training/Reports clicks from `0006` to about `0030`. Console list `0010` and network list `net-shell` and `net-shell2`. PNGs `0010`–`0018`, montage `measure/shell-montage.png`.
- SPC: rank listbox keyboard selection, `0040-wait-spc` (exit 2, waiting for the brief's "25%", which never appears), `snap/spc.txt`, `rows-rounding-type` (`0045`), reload `reload-spc`, `net-ssr-spc`, `html-spc` (direct read-only same-origin HTML GET), `console-spc`. PNGs `0020`, `0024`.
- Mixed: Clear filters, view listbox keyboard, duty-role Space, `net-mixed`, `snap/mixed.txt`, PNG `0030`. Rows by role, 180 days, `reload-mixed`, `net-ssr-mixed`, `snap/mixed-reload.txt`, PNG `0034`.
- Cell: `click-cell`, `net-cell`, `get-detail` (`0088`; cookie header redacted by the tool), body `http/detail-418.network-response`, PNG `0040`.
- Export: `net-observe-export` (`0090`), `export-arm`, `click-export`, `export-net-state` (`0094`), `export-state`, `export-save` (`0096`), `net-export`, `export-restore`, `net-restore-export`, `net-state-after`, `workbook`. Bytes are in `downloads/training-report-filtered.xlsx` (sha256 `b4f46367…b69e`, 12,254 bytes).
- Goal 85: `goal85-*`, PNG `goal85.png`. Final bucket: `snap/final.txt`, `measure/sweep/g85-light-1440-final-30.json`, `g85-dark-390-final-30.json`, PNGs `0050`–`0053`.
- Goal 95: `goal95-*`. Flat 100: `snap/flat.txt`, `measure/sweep/g95-light-1440-flat100-90.json`, `g95-dark-390-flat100-90.json`, PNGs `0060`–`0063` (DPR2 `0061`, `0063`).
- Restore: `goal90-*`, `storage-orig`, `storage-before-restore`, `storage-restore`, `emu-clear`, `resize`, `vp-after`, `net-state-final`, `export-state-final`, `rows-orgA-final`, `rows-orgB-final`, `rows-trA-final`, `rows-trB-final`.
- Sign Out: `click-account`, `click-signout`, `url-signout`, `nav-protected`, `url-protected`, PNG `0070`. Final doctor `0233` PASS.

## Qualified failures and caveats

- `0040-wait-spc` exit 2. The brief expected 25%; the briefing showed 17%, explained in the report.
- `png/0012-training.png` shows the Dashboard, not Training. The first Training click landed while Home's What's New dialog was open; the click dismissed it instead. `0016` is the actual Training page.
- One `C clear3` produced `NO MATCH` with no click. Reports had been freshly opened without filters, so there was no Clear filters button.
- `receipts/0002-tools.stdout` mentions "password" and "token" only inside native tool schema descriptions.
- Console output lists only messages since the last full navigation. Earlier pages' messages are intrinsically omitted.
