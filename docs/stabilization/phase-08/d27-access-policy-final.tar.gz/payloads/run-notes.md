# D27 final policy candidate observations

The production-build app used revision a59c6c92bba242cde37f15a5d59e6d305e5267ac plus the frozen 69-path source inventory, candidate 3862d21bf0d52a9c124fcc6e3afb43efbec82cf4066a8e1706bc67e3f04f5dc1. Run environment, fixture, commands and actual responses are retained separately. Source was committed only after final doctor and owned cleanup. Packaging and acceptance prose are not a new live run.

Native Training description, Critical Task title, Onboarding name, Calendar status name, Personnel duty role and Evals notes edits each persisted after reload with the same provider ID. Original edited fields were restored. Personnel's ordinary full edit also regenerated its slug; the receipt claims restoration of the edited duty role, not every original field. Training empty-fill restoration did not persist; native keyboard deletion restored null, as in the unchanged baseline.

Absent-grant Training, ICT, Onboarding and Evals writes returned 403 with zero/stable provider effects. Alpha Training completion notes persisted and were restored; Organization-wide Training type/view writes returned 403 without rows. Native alphabetical Training preference persisted after reload and was restored to Group mode. Its ordinary preference row remained until disposable cleanup.

Native mark-all-read changed all 24 own notifications. Peer/foreign notifications stayed unread; targeted PUTs returned 404. Forged preference identity/Organization fields returned 200 and changed only the admitted user's A preference. Peer preference remained absent. The changed calendar field was restored; the own row remained until disposal.

Admin retention 36 to 37 persisted after reload. Member 38 mutation returned 403 without effect. Admin restored 36. Native owner Logs loaded Audit Log; native admin Logs rendered Error 403.

Two native owner JSON exports and one native admin Excel export are saved. The first JSON preceded private seeds. The second JSON and Excel contain A active/archived private metadata, reconcile all 38 inventory sections and exclude exact B Organization, Person and private-record IDs. Three completed lifecycle rows match requester and 207097, 221615 and 71856 bytes respectively. Member export returned 403 and added no lifecycle row. Every export hook was restored.

Ordinary authenticated manager document admission returned 200 with a redacted signed URL; member returned 403 and foreign Organization returned 404. Separate provider readback matched all eight seeded PDF sizes/hashes. No native document download is claimed.

Own deletion submission returned 201/pending. Peer cancellation returned 404 and admin reviewer cancellation 403; the same request stayed pending. Own cancellation returned 200/cancelled. Source Person was unchanged. This is HTTP/provider proof; there is no cancellation UI.

Native roster viewer listed three saved snapshots and exposed Re-print. Scan GET returned 200 with its URL redacted before capture. Create, roster DELETE, scan DELETE and a valid 3180-byte jsPDF multipart upload all returned 403. Exact roster row and 3205-byte stored scan SHA-256 47bd90f24fc83191e2c06c3c6b54db257f31a5eb87aa58064482a612eaaccd38 remained unchanged. No native scan download, reprint generation or upload lifecycle is claimed.

Final doctor retained the candidate; helper cleanup and owned disposal passed. Copied repository logs preserve full tests, types, lint, governance, production build, formatting and docs. Original admission/scope/narrowing/concurrent and SQL observations remain in their separately accepted archives and are applicable to unchanged admission, membership projection, provider operations, schema, grants and RLS. Actual membership removal, broader request/provider composition, full private-file/client-failure/race journeys and measured performance remain whole-issue work or unrun limits.

The partial pre-comment candidate was cleaned before the sole accepted comment deletion. Only two normal logins and an unsaved Training draft occurred. It is not final acceptance evidence.
