from drive import *
import hashlib
(E/'final-restored-orgA-onboarding_steps-stderr.log').write_text('Map control blocked: Table is outside the synthetic readback allowlist.\n')
for org in ['orgA','orgB']:
    for table in ['personnel_onboardings','onboarding_step_progress','onboarding_templates','onboarding_template_steps']:
        control(['rows',table,org],'final-restored-corrected-'+org+'-'+table)
for org in ['orgA','orgB']:
    for short,table in [('packets','personnel_onboardings'),('progress','onboarding_step_progress')]:
        before=json.loads((E/f'original-{short}-{org}.json').read_text())['rows']
        after=json.loads((E/f'final-restored-corrected-{org}-{table}.json').read_text())['rows']
        assert before==after,(org,table)
(E/'restoration-comparison.json').write_text(json.dumps({'result':'PASS','orgA':{'parents':1,'progress':3},'orgB':{'parents':0,'progress':0},'comparison':'Exact original selected business fields; omitted row timestamps are outside proof.'},indent=2)+'\n')
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1')
ledger=json.loads((private/'verify-trooptotask-owned.json').read_text())
(E/'ledger-clean.json').write_text(json.dumps({'seeded':ledger.get('seeded'),'httpCacheExists':(private/'artifact-http-sessions').exists()},indent=2)+'\n')
assert not ledger.get('seeded')
for action in ['doctor','cleanup']:
    command=['npm','run','--silent','verify:app','--','--worker','1',action]
    (E/(action+'-final-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    result=subprocess.run(command,text=True,capture_output=True)
    (E/(action+'-final.json')).write_text(result.stdout)
    (E/(action+'-final-stderr.log')).write_text(result.stderr)
    assert result.returncode==0,result.stderr or result.stdout
project=json.loads((E/'owned-provider.json').read_text())['project']
resources={}
for kind in ['container','volume','network']:
    command=['docker',kind,'ls']+(['-a'] if kind=='container' else [])+['--filter','label=com.supabase.cli.project='+project,'--format','{{json .}}']
    (E/(kind+'-empty-command.json')).write_text(json.dumps(command,indent=2)+'\n')
    result=subprocess.run(command,text=True,capture_output=True)
    assert result.returncode==0,result.stderr
    resources[kind]=[json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    assert not resources[kind],resources
resources['privateWorkerExists']=private.exists()
assert not private.exists()
(E/'owned-project-empty.json').write_text(json.dumps({'project':project,'resources':resources},indent=2)+'\n')
print('Exact A/B selected business fields restored; doctor, owned cleanup and exact project inventory PASS')
