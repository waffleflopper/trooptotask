SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = 'a4507cd3-e62c-4471-8ed8-effe4abacf5a'::uuid AND p.id = 'bf401b95-b8d8-4c5c-8e41-fa6d61f14ca8'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = 'a4507cd3-e62c-4471-8ed8-effe4abacf5a'::uuid AND id = '64960f87-4330-464e-b414-5d189be8ca6d'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = 'a4507cd3-e62c-4471-8ed8-effe4abacf5a'::uuid AND s.onboarding_id = 'bf401b95-b8d8-4c5c-8e41-fa6d61f14ca8'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
