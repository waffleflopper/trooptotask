Expect Alpha: 1 soldier, 100%→50%, Ready2 exp0 nr0 lapse1
Expect Alpha+Required: 100%→100% Ready1 others 0, 'Nothing lapses'
Expect Focus View: columns Targeted then Required, 50%→25%, same 4 cells
Expect MOS 68W: 2 soldiers, 67%→33%, Ready2 exp0 nr1 lapse1
Expect role NCO: 2 soldiers (Baker, Unassigned), 0%→0%, Ready0 exp1 nr1 lapse0
Expect rank SPC: 3 soldiers 50%→25%; +180d BY 2 APR 25%; rows by duty role: NCO 0 then Medic 100
DEFECT (print save, helper transport): `print save` blocks with "Native page list has no structured pages." (receipts 135, 138 retry).
Root cause (read-only): scripts/verification/daemon.mjs launches chrome-devtools-mcp 1.10.1 without --experimentalStructuredContent
(default false in config/mcp-options.js:65); ToolHandler.js:280 only attaches result.structuredContent when that flag is set;
print-capture.mjs:147 requires result.structuredContent.pages. print-capture.test.mjs mocks structuredContent, so unit tests pass.
Native click on Print brief DID invoke print: print state before=1 after=0 (receipt 134).
