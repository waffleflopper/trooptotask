# D12 Personnel lifecycle server ownership handoff

Source revision: `9d4a76ce3a5c0cb8a37691beadbf158450ea9cac`; tree: `d711aad4a449f1b9a6b08441dd2e269f23dd4c07`.
Branch: `stabilization/1360-personnel-lifecycle-owner-server`.
Exclusive worker: `/tmp/t2t-1360-personnel-lifecycle-owner-server`.
Clean tracked/untracked Git status after the commit. No publication.

## Provenance

Phase 1 test-only permanent-delete ordering proof is preserved at `9ddb9af4f19c15bc5ccc38b8845179a3a1f17948`, with its separate original evidence directory and archive. Root already cherry-picked that proof as `1def9f5e`.
The worker merged main `c17fecbb4faedda5231c0b88d8fc99bf7daeffbb` into Phase 1 using merge commit `ff55b0225f1045edfd48c2f38b785d590c74bec8`, then ran the unchanged central Personnel baseline before any production edits: 1 file / 35 tests passed (`baseline-tests.log`, exit 0).
The source commit is a cohesive ownership cutover after that baseline. No migration, retention implementation or notification behavior repair.

## Production seams

Personnel owns five named lifecycle operations in `personnelLifecycle.server.ts`, the private parent-owned archive/restore cascade in `personnelArchiveCascade.server.ts`, and the portable `ArchivePersonnelBatchResult` leaf exported through contracts. The public server entry point exports the named operations.
The prepared batch performs one deduped scoped candidate read, owns per-ID eligibility/policies/sequential parent writes, and finishes artifact effects in original/shared event timestamp groups with the success audit afterward.
`src/lib/server/personnelArchiveBatchDelivery.ts` owns the ID loop, canonical result aggregation and eligible D18 request submission/409 handling. Provider/policy/source-finish failures remain outside the request-only catch.
The public approved Personnel effect admits Organization review governance without reimposing ordinary Personnel manage/archive capability or adding a Personnel success audit. D18 retains pending-request admission/status/audit/notification.
Permanent deletion keeps delete -> audit -> awaited narrow notification callback. The route owns notification recipients and payload.
Central Personnel factory/interface/file are removed. Parent-only artifact metadata/effects are removed centrally; mixed archived-artifact detail read and individual artifact operations remain for their later owners.

## Test coverage and checks

Existing lifecycle/recovery tests were relocated to meaningful owner/delivery seams; the Phase 1 held/rejected notification proof remains intact. Two parent cascade tests moved to their private owner. D18 admin-with-no-Personnel-capability, event replay after approval-status failure, denial/provider failure, and approved-effect-before-status tests remain. Added a direct public approved-effect denial proof, empty-batch no candidate/effects proof, saved-name callback proof and real route notification payload assertion.

First cutover focused run: 11 files, 137 passed / 1 failed (`initial-focused-tests.log`, exit 1). The failure was a test-only alias: replacing `ctx.store.findMany` also replaced `ctx.rawStore.findMany`, so the fixture's later persistent readback threw. Replaced the scoped test store with a separate wrapper; production source did not change for that correction. Original failure retained verbatim.
After correction: 11 files / 138 tests passed (`focused-tests.log`, exit 0). Exact command and offline placeholder provider environment are in `focused-tests.command.txt`. No services or provider connection were used.
Final formatting, ESLint and diff checks all exit 0. Final `npm run check` reports 0 errors and 0 warnings. Commands and outputs are retained under `final-*.command.txt`, `final-*.log`, `final-*.exit`.
After the passing test run, the only edits were erased interface narrowing of the optional artifact port to `Pick<..., 'forPeople'>`, merging duplicate type-compatible imports in an adapter test, and formatting. Final types/lint/format passed after those edits. Root owns exact integrated tests/build/native/review gates.

Governance has NOT passed in this exclusive worker: `initial-governance.log` exit 1 reports only the expected root-owned manifest followups, 703 findings compared with c17 and Personnel 08-M04 115 vs earlier 126. Delete stale assignments for `src/lib/server/core/useCases/personnel.ts` and `.test.ts`; register the two new Delivery `.ts`/`.test.ts` paths (one missing-source-owner finding repeats). No other governance failure was reported. No manifest edits were made here.

## Environment and limits

Node v24.21.0; npm 11.19.0; Vitest 4.1.8 Linux x64. Type/Svelte sync and Vitest ran sequentially, never concurrently.
Exact lockfile dependencies use this worker-only ignored node_modules symlink to `/home/waffleflops/.cache/t2t-1360-personnel-lifecycle-owner-server-dependencies`. Original Phase 1 npm ci ENOSPC exit 228 and recovered private-prefix npm ci exit 0 remain in Phase 1 evidence. Installation engine/deprecation/audit/allowScripts warnings were retained; no dependency settings changed.
No root files, UI, shared controls, docs, manifest, database, browser or service were changed. Worker has no native acceptance claim; root owns fresh affected native proof. Existing accepted #1450 recovery and #1453 approval/detail/permanent receipts are baseline provenance only.
All 20 changed/deleted/new source paths appear in `source-files.txt`; exact source diff is `source-commit.diff`.
Raw logs remain ignored scratch. No Phase 2 archive was packed into this or another active source checkout; root packages after its cleanup.
