from pathlib import Path
import json,datetime
p=Path(__file__).parent;stateDirectory=Path('/home/waffleflops/.local/state/trooptotask-verification/80ad0b6c7cddb4c6/worker-1')
s=json.loads((stateDirectory/'session.json').read_text());d=json.loads((stateDirectory/'provider.json').read_text())
x={k:s.get(k)for k in ['id','repository','worker','phase','origin','candidate']}
x['processes']={k:{v:s[k].get(v)for v in ['pid','start']}for k in ['supervisor','appProcess','mcpProcess','browserProcess']}
x['provider']={k:d.get(k)for k in ['project','docker_host','ports','container_ids','phase']}
x.update(stateDirectory=str(stateDirectory),recordedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(p/'owned-public-identity-final-before-cleanup.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
