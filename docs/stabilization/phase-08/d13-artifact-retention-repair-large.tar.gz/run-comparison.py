from pathlib import Path
import json
p=Path(__file__).parent
seed=json.load(open(p/'seed.json'))
n=seed['expiredCountPerFamily']; assert n==1001
expected={f['table']:{i['row']['id'] for i in f['records'] if i['classification']=='expired'} for f in seed['rows']}
results=[]
for f in p.glob('before-org*.json'):
 before=json.load(open(f)); after=json.load(open(p/f.name.replace('before-','after-')))
 if before['table']=='notifications': continue
 removed=expected.get(before['table'],set()) if before['organization']=='orgA' else set()
 assert [r for r in before['rows'] if r['id'] not in removed]==after['rows'],f.name
 results.append({'organization':before['organization'],'table':before['table'],'before':len(before['rows']),'after':len(after['rows']),'removedIds':sorted(removed),'allOtherFieldsUnchanged':True})
files=json.load(open(p/'files-after.json'))['files']; byPath={f['path']:f for f in files}
for f in seed['files']:
 seen=byPath[f['path']]
 if f['classification']=='expired': assert seen['present'] is False,f['path']
 else: assert seen['present'] and seen['observedSize']==f['size'] and seen['observedSha256']==f['sha256'],f['path']
assert json.load(open(p/'settings-before.json'))==json.load(open(p/'settings-after.json'))
cron=json.load(open(p/'cron-run.json')); body=json.loads(cron['body']); assert cron['status']==200 and body['deletedCount']==4*n and body['orgsAffected']==1
assert {f['table']:f['deletedCount'] for f in body['families']}==dict.fromkeys(['personnel_follow_ups','counseling_records','personnel_documents','leader_notes'],n)|dict.fromkeys(['personnel','ict_tasks','assignment_types'],0)
notes=json.load(open(p/'after-orgA-notifications.json'))['rows']; assert len(notes)==3
for r in notes:
 assert r['type']=='archive_auto_deleted' and r['link'] is None
 assert r['title']=='Archived Records Auto-Deleted'
 for x in [f'{4*n} archived records',f'Personnel follow-ups: {n}',f'Counseling records: {n}',f'Personnel documents: {n}',f'Leader notes: {n}']:assert x in r['message']
 assert seed['tag'] not in r['message'] and 'Synthetic' not in r['message']
assert json.load(open(p/'after-orgB-notifications.json'))['rows']==[]
replayComparisons=0
for f in p.glob('after-org*.json'):
 reference=p/'before-replay-orgA-notifications.json' if f.name=='after-orgA-notifications.json' else f
 assert json.load(open(reference))==json.load(open(p/f.name.replace('after-','replay-'))),f.name
 replayComparisons+=1
assert json.load(open(p/'files-after.json'))==json.load(open(p/'files-replay.json'))
replay=json.load(open(p/'cron-replay.json')); replayBody=json.loads(replay['body']);assert replay['status']==200 and replayBody['deletedCount']==0 and replayBody['orgsAffected']==0
assert all(f['deletedCount']==0 for f in replayBody['families'])
report={'completeRowComparisons':results,'files':{'knownPaths':len(files),'expiredRemoved':4,'retainedExactBytes':10},'job':body,'notifications':{'orgA':len(notes),'orgB':0,'countOnly':True,'link':None},'settingsUnchanged':True,'replay':{'completeRowComparisons':replayComparisons,'completeFileManifestUnchanged':True,'job':replayBody}}
(p/'run-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'completeRowComparisons':len(results),'expiredArtifactsRemoved':4*n,'filesRemoved':4,'filesRetainedExactHash':10,'parentCount':0,'notificationRecipients':3,'replayComparisons':replayComparisons,'replayNewDeletions':0}))
