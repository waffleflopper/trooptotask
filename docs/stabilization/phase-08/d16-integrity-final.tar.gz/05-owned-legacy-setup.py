import importlib.util,json,subprocess
from pathlib import Path
repo=Path.cwd(); evidence=repo/'.verification/evidence/verify-trooptotask/d16-integrity-final'
session=Path('/home/waffleflops/.local/state/trooptotask-verification/03a73328abf6e511/worker-1')
spec=importlib.util.spec_from_file_location('owned_environment',repo/'scripts/verification/environment.py'); envmod=importlib.util.module_from_spec(spec); spec.loader.exec_module(envmod)
status=envmod.status(session); state,workdir,environment=envmod.owned(session); envmod.containers(state,workdir,environment)
f=json.loads((evidence/'fixture.json').read_text())['ids']; s=json.loads((evidence/'seed.json').read_text())['ids']
columns=[('rater_person_id','rater'),('senior_rater_person_id','senior_rater'),('intermediate_rater_person_id','intermediate_rater'),('reviewer_person_id','reviewer')]
sql='BEGIN;\n'
sql+=f"DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM public.rating_scheme_entries WHERE id='{s['current']}' AND organization_id='{f['orgA']}') OR NOT EXISTS (SELECT 1 FROM public.personnel WHERE id='{f['personForeign']}' AND organization_id='{f['orgB']}') THEN RAISE EXCEPTION 'Owned fixture mismatch'; END IF; END; $$;\n"
sql+='CREATE TEMP TABLE legacy_constraint_before AS SELECT conname, pg_get_constraintdef(oid) AS definition FROM pg_constraint WHERE conrelid=\'public.rating_scheme_entries\'::regclass AND contype=\'f\';\n'
for _,suffix in columns: sql+=f'ALTER TABLE public.rating_scheme_entries DROP CONSTRAINT rating_scheme_entries_organization_{suffix}_fkey;\n'
sql+=f"UPDATE public.rating_scheme_entries SET "+', '.join(f"{column}='{s['officer'] if column in ['rater_person_id','senior_rater_person_id'] else f['personForeign']}'" for column,_ in columns)+", rater_name=NULL, senior_rater_name=NULL, intermediate_rater_name=NULL, reviewer_name=NULL, notes='Synthetic retained historical evaluator witness' "+f"WHERE id='{s['current']}' AND organization_id='{f['orgA']}';\n"
sql+='SET CONSTRAINTS ALL IMMEDIATE;\n'
for column,suffix in columns: sql+=f'ALTER TABLE public.rating_scheme_entries ADD CONSTRAINT rating_scheme_entries_organization_{suffix}_fkey FOREIGN KEY (organization_id,{column}) REFERENCES public.personnel (organization_id,id) ON DELETE SET NULL ({column}) NOT VALID;\n'
sql+='DO $$ BEGIN IF EXISTS ((SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid=\'public.rating_scheme_entries\'::regclass AND contype=\'f\' EXCEPT SELECT * FROM legacy_constraint_before) UNION ALL (SELECT * FROM legacy_constraint_before EXCEPT SELECT conname, pg_get_constraintdef(oid) FROM pg_constraint WHERE conrelid=\'public.rating_scheme_entries\'::regclass AND contype=\'f\')) THEN RAISE EXCEPTION \'Fixture changed constraint definitions\'; END IF; END; $$;\n'
sql+="NOTIFY pgrst, 'reload schema';\nCOMMIT;\nSELECT conname, pg_get_constraintdef(oid), convalidated FROM pg_constraint WHERE conrelid='public.rating_scheme_entries'::regclass AND contype='f' ORDER BY conname;\n"
(evidence/'05-legacy-fixture.sql').write_text(sql)
command=['docker','exec','-i','-e','PGPASSWORD=postgres',f"supabase_db_{state['project']}",'psql','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
r=subprocess.run(command,cwd=workdir,env=environment,input=sql,capture_output=True,text=True,check=False)
(evidence/'05-legacy-fixture-result.txt').write_text(json.dumps(status)+'\n'+r.stdout+r.stderr)
if r.returncode: print(r.stderr); raise SystemExit(r.returncode)
print(json.dumps({'status':'PASS','project':state['project'],'legacy_entry_id':s['current'],'constraint_definitions':'unchanged'}))
