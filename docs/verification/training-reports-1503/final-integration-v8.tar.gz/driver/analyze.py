#!/usr/bin/env python3
"""Summarize read-only forecast measurements: every annotation actor against every plotted mark."""
import glob
import json
import os
import sys

E = os.path.dirname(os.path.abspath(__file__))
pattern = sys.argv[1] if len(sys.argv) > 1 else 'g*'
rows, problems = [], []
for path in sorted(glob.glob(f'{E}/measure/sweep/{pattern}.json')):
    name = os.path.basename(path)[:-5]
    raw = open(path).read()
    data = json.loads(raw)
    if isinstance(data, str):
        data = json.loads(data)
    if 'error' in data:
        problems.append((name, 'ERROR', data))
        continue
    goal, theme, width, state, horizon = name.split('-')
    row = {'case': name, 'drift': data['drift'], 'labels': {}}
    for label in data['labels']:
        role = label['role']
        rules = label['rules']
        min_rule = min((r['gap'] for r in rules), default=None)
        others = [d['gap'] for d in label['dots']]
        own = None
        if role == 'startValue':
            own, other = others[0], others[-1]
        elif role == 'endValue':
            own, other = others[-1], others[0]
        else:
            other = min(others)
        clip = max(label["outsideClip"]["l"], label["outsideClip"]["r"]) if label["outsideClip"] else None
        svg_out = label['outsideSvg']
        entry = {
            'value': label['value'], 'minRule': min_rule, 'ruleKind': rules[0]['kind'] if rules else None,
            'spline': label['splineGap'], 'ownDot': own, 'otherDot': other, 'bars': label['bars'],
            'text': label['texts'][0]['gap'] if label['texts'] else None, 'textWho': label['texts'][0]['value'] if label['texts'] else None,
            'xAxis': label['xAxisGap'], 'clip': clip, 'svgOut': svg_out,
        }
        row['labels'][role] = entry
        checks = [('rule', min_rule), ('spline', label['splineGap']), ('bars', label['bars']), ('text', entry['text']), ('xAxis', label['xAxisGap'])]
        if role != 'goalLabel':
            checks.append(('otherDot', other))
        for kind, gap in checks:
            if gap is not None and gap < 2:
                problems.append((name, f'{role} {label["value"]} {kind} gap {gap}', rules[:2] if kind == 'rule' else entry.get('textWho')))
        if clip is not None and clip > -1:
            problems.append((name, f'{role} {label["value"]} clipped/edge {clip}', label['outsideClip']))
        if role != 'goalLabel' and (svg_out['t'] > 0 or svg_out['b'] > 0):
            problems.append((name, f'{role} {label["value"]} outside svg vertically', svg_out))
    for o in data['textOverlaps']:
        problems.append((name, f'text overlap {o["a"]} / {o["b"]} gap {o["gap"]}', None))
    if data.get('band'):
        row['bandRight'] = data['band']['rightVsPlot']
    row['tw'] = data['textWidths']
    row['bottom'] = (data.get('bottomLine') or '')[:80]
    row['sr'] = data['srTable']
    row['xTicks'] = data['xTicks']
    row['alert'] = data.get('alert')
    rows.append(row)

def stat(role, key):
    values = [r['labels'][role][key] for r in rows if role in r['labels'] and r['labels'][role][key] is not None]
    return (min(values), max(values)) if values else None

print(f'cases {len(rows)}')
for role in ('startValue', 'endValue', 'goalLabel'):
    print(role, {k: stat(role, k) for k in ('minRule', 'spline', 'ownDot', 'otherDot', 'bars', 'text', 'xAxis', 'clip')})
drifts = [abs(r['drift'][k]) for r in rows for k in ('start', 'end') if r['drift'][k] is not None]
print('drift max', max(drifts) if drifts else None, 'over15', sum(d > 15 for d in drifts), 'of', len(drifts))
fonts = {(t['v'][-1] == '%', t['family'], t['weight'], t['rendered'] == t['plex']) for r in rows for t in r['tw']}
print('fonts', fonts)
alerts = [r['case'] for r in rows if r['alert']]
print('alerts', alerts)
print(f'problems {len(problems)}')
for p in problems:
    print(' ', p)
