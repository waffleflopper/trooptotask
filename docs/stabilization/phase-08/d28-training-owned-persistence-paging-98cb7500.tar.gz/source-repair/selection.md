# Training main integration and review repair

1. Read Principles in full. Complete.
2. Reproduce it yourself on the matching surface via the control skill. Lower installed-SDK/provider seam selected; native/app/build explicitly excluded by parent. Existing actual native certificate proof reused.
3. Binary-search the cause. Trace shared recognized failures and tied page-query ordering. Follow how locally; parent sequential/no-fanout overrides skill delegation defaults.
4. Plan the fix. Retain settled17/10 contracts and captured ordinary authority. No new boundary/type abstraction. Architect ground/sketch performed locally; agree/arena skipped because settled routine integration and no fanout allowed.
5. Verify on the same surface; the original repro now passes. Preserve original failed paging receipt, then focused adapter/operation/boundary checks.
6. Stage the commits so the failing repro lands before the fix in git history. Preserve failing log and pre-repair source/test hashes in scratch instead; parent authorizes local merge commit, root owns later publishing.
7. Run Opening a PR. Skip; existingPR1565 owned by root, no external writes authorized.

Data shape remains Organization-bound Catalog17 and Completion10 domain ports, complete saved20/7/10. Page order is the existing primary sort followed by unique row ID. Shared RequestFailure marks intended app failures; untrusted provider Errors are generic500. No copied Training interfaces, Entity imports or ordinary generic stores can return during conflict resolution.

Throughput checkpoint. Merge only exact acceptedmain837a4350. Retain acceptedmain byte-for-byte outside concrete Training overlaps. Upgrade existing ten-method paging behavioral cases with tied rows and page-order drift rather than adding a fake framework or duplicate matrix. Preserve real saved certificate proof and installedSDK columns mechanism; no speculative upsert repair. Run failed and justified adjacent checks, type/governance, touched lint/format/diff. Propose one bounded native dense read/workbook only if changed paging requires it, with error proof reused where semantics match. No app/build/resources in this stage.

Principles applied. Boundary Discipline places intended failure recognition in shared errors, leaves provider errors untrusted. Test Behavior uses complete independently numbered projected facts instead of order-string-only assertions. Model the Domain retains settled domain ports and a small existing provider fixture. Laziness keeps primarysort+id as the only production paging change and rejects unnecessary upsert rework. Prove It Works binds certificate disposition to actual native wire/SQL and SDK code, and keeps failed paging log. Sequence Verifiable Units separates merge, failure reproduction, repair and focused lower acceptance.
