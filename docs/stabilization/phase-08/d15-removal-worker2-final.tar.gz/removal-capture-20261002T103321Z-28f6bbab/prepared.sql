SET statement_timeout = '10s'; SET lock_timeout = '3s';
WITH selected_templates AS (
 SELECT template_id AS id FROM public.personnel_onboardings WHERE organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND id='564d6856-b2f3-4f03-a808-5c8e26b72338'::uuid
 UNION SELECT definition.template_id FROM public.onboarding_template_steps definition
 JOIN public.onboarding_step_progress progress ON progress.template_step_id=definition.id
 WHERE progress.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND progress.id='83855371-dace-4a3f-b300-17280a246fc0'::uuid AND progress.onboarding_id='564d6856-b2f3-4f03-a808-5c8e26b72338'::uuid
 AND definition.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid
)
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND p.id='564d6856-b2f3-4f03-a808-5c8e26b72338'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id',id,'organization_id',organization_id,'group_id',group_id,
 'rank',rank,'first_name',first_name,'last_name',last_name,'slug',slug,'archived_at',archived_at)
 FROM public.personnel WHERE organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND id='5e6b2ebd-2be4-497b-a8c4-8f1560274e4d'::uuid),
 'progress', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.onboarding_step_progress p
 WHERE p.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND p.onboarding_id='564d6856-b2f3-4f03-a808-5c8e26b72338'::uuid), '[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.onboarding_templates t
 WHERE t.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND t.id IN (SELECT id FROM selected_templates)), '[]'::json),
 'definitions', COALESCE((SELECT json_agg(d ORDER BY d.id) FROM public.onboarding_template_steps d
 WHERE d.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND d.template_id IN (SELECT id FROM selected_templates)), '[]'::json));
