# D29 final follow-up native run

Final executable source `ba4b7d5a11fba32ea60a61bba4a523e2b7a51b64`, digest `c03a43fa0a67213960f51b98153a0c5f941815fd4bec324760baddcc17a578eb`, owned worker2 at http://127.0.0.1:38441, session `8cc9e10d-0f4a-4cb3-865a-0ca99e218c30`. Node24.21.0, npm11.12.1 outer launch, Chromium152.0.7977.82. Normal manager page2, platformReviewer page4 and orgOwner page6; helper/login JSON records exact fixture/Organization/browser contexts. Helper access=not-assessed is not admission proof; actual rendered routes/content establish selected admitted views.

Launch/production build, initial doctor, final settled doctor and owned cleanup PASS. Source/recipes remain frozen through final doctor and cleanup. No controls/seeds were armed. Modified activation creates only the owned same-context new tabs, which are closed afterward. Themes/viewports are restored; readback113/116 confirms desktop Sidebar state expanded and no tooltip/modal. Three PNGs were visually inspected, including restoration-debug. No further capture redaction was needed; values are synthetic and credentials/private configuration were never copied.

| Contract | Actual passing result | Captures |
| --- | --- | --- |
| Header accessible tooltip | Actual Tab focus opens unique c6 role tooltip with resolving description, light theme/Dark mode label. | 001–004 |
| Header Enter | Confirmed open tooltip before Enter; actual theme changes light→dark, focus stays Toggle theme, description disappears and tooltip count becomes0. | 004–006 |
| Header Space | Tab away/back opens Light mode tooltip; Space changes dark→light, preserves focus and clears description/tooltip. | 007–011 |
| Header Escape/pointer | Refocus opens Dark mode; Escape dismisses. Later pointer hover opens; pointer click changes to dark and dismisses; same control restores light. Callback-once belongs to the separate real Header test, not native callback instrumentation. | 012–021 |
| Collapsed app tooltip | Home hover has c16, role tooltip, unique count1 and matching description; Escape dismisses. Existing86f genuine Home keyboard focus proof remains applicable to unchanged focus handlers. | 022–025 |
| App ordinary/current links | Mobile Home navigation reaches Dashboard with Sidebar gone; legitimate automatic What's New is closed separately. Current Home closes drawer with zero tooltip/modal; later Personnel navigation closes and reaches Personnel. | 026–035, 041–043 |
| App Escape | Keyboard Tab focuses Home inside drawer; Escape closes and restores actual BUTTON Toggle Sidebar focus. | 036–040 |
| App modified navigation | Control+Enter from focused Home opens owned Dashboard tab3; parent remains Personnel with Sidebar open and no tooltip. Tab3 closes, Escape closes parent drawer. | 044–053 |
| Admin tooltip/admission | Normal Platform actor reaches actual Users with82 directory accounts. Collapsed Users hover has c14, role tooltip, unique count1 and matching description; Escape dismisses. | 054–058 |
| Admin current link | Current Users activation closes drawer; actual URL stays/admin/users with zero tooltip/modal. Screenshot shows the usable mobile page. | 059–064 |
| Admin ordinary link | Dashboard activation changes actual URL/title/content and closes drawer with zero tooltip/modal. | 065–068 |
| Admin Escape | Tab focuses Dashboard; Escape closes and restores actual BUTTON Toggle Sidebar focus. | 069–073 |
| Admin modified navigation | Control+Enter opens owned same-context Dashboard tab5; parent drawer stays open. Tab5 closes; parent Escape closes. | 074–081 |
| Header Settings consumer | Ordinary owner sign-in reaches Organization Settings; activating its sidebar link returns the Settings destination while closing the drawer. This covers the third actual MenuButton owner. | 082–087 |
| Header Account counterexample | Account button opens its real menu while Sidebar stays open. First Escape closes menu, second closes drawer/restores trigger. No Account/Sign Out action is submitted. | 088–095 |
| Restoration | Final controls read expanded desktop Sidebar, light theme and zero tooltips/modals. Final settled doctor identifies the same source/digest; owned cleanup passes. | 096–116, final-doctor-settled.json, owned-cleanup.json |

## Retained attempt limits

- login-platform-command-failed.json records the mistaken actor invocation through the public CLI. It failed before acting. The documented control.mjs actor helper then performs normal sign-in; its result is preserved separately.
- Immediate click/closing-transition snapshots alone do not prove settled closure; the separate DOM results do.
- 035 reads the whole BODY as the post-navigation active element. It proves closure/current path, not navigation focus restoration. The scoped Escape probes040/073 establish focus restoration separately.
- Restoration096–100/101–108 initially toggles to collapsed desktop state and encounters visible Organization/Platform tooltips after layout moves under the pointer. Those attempts do not establish restoration. Escape clears them; fresh111–116 explicitly proves expanded state and no remaining tooltip/modal. restoration-debug.png records the diagnostic view. No source or timing workaround is applied.
- final-doctor.json passes before the last restoration actions; final-doctor-settled.json is the last matching doctor before cleanup.
- This follow-up repairs Header keyboard activation and shared navigation failures. It does not rerun Personnel Edit/Calendar/import/Archive; their implementation and fixture/control bytes are unchanged from86f, whose separate first-run successful observations/readback remain applicable. Pagination has no production callers; final public component tests own its browser-navigation boundary. Unconsumed RangeCalendar likewise has component proof, not invented native use.
- No save/import/archive mutation, authorization/RLS, production deployment, performance timing or unrelated whole-feature acceptance is claimed.
