import sys,json
sys.path.insert(0,'.verification'); import d18_ui as v
sources=json.load(open(v.root/'seeds.json'))['sources']
tables=['personnel','training_types','personnel_trainings','rating_scheme_entries','counseling_records','deletion_requests']
def capture(prefix):
 for org in ['orgA','orgB']:
  for table in tables:
   result=v.helper(f'{prefix}-{org}-{table}','rows',table,org)
   print(prefix,org,table,result['count'],flush=True)

def file_capture(prefix):
 seeds=json.load(open(v.root/'seeds.json'))
 for org in ['orgA','orgB']:
  parent=sources[org]['parent']; path=next(f['path'] for f in seeds['files'] if '/'+parent+'/' in f['path'])
  v.helper(prefix+'-files-'+org,'artifact-files',org,parent,'counseling',path)

def rows(name):return json.load(open(v.root/(name+'.json')))['rows']
def originals(prefix):
 for org in ['orgA','orgB']:
  ids=set(sources[org].values())
  for table in tables:
   before=[r for r in rows(f'before-{org}-{table}') if r.get('id') not in ids and r.get('resource_id') not in ids]
   after=[r for r in rows(f'{prefix}-{org}-{table}') if r.get('id') not in ids and r.get('resource_id') not in ids]
   assert sorted(before,key=lambda r:r['id'])==sorted(after,key=lambda r:r['id']),(prefix,org,table)

def compare_failed_requests():
 original=json.loads(json.load(open(v.root/'submit-training_type.json'))['body'])
 for name in ['reject-type-request','503-type-request']:
  assert rows(name)==[original],name
 for name,submitted in [('switch-error-A-person-request','submit-personnel'),('switch-error-B-type-request','submit-B-type')]:
  assert rows(name)==[json.loads(json.load(open(v.root/(submitted+'.json')))['body'])],name

def compare_effects(prefix):
 for org in ['orgA','orgB']:
  for table in tables[:-1]:
   before=rows(f'before-{org}-{table}');after=rows(f'{prefix}-{org}-{table}')
   if org=='orgA' and table=='personnel_trainings':before=[r for r in before if r['id']!=sources[org]['personnel_training']]
   if org=='orgA' and table=='rating_scheme_entries':before=[r for r in before if r['id']!=sources[org]['rating_scheme_entry']]
   assert sorted(before,key=lambda r:r['id'])==sorted(after,key=lambda r:r['id']),(org,table)
 for resource,expected in [('personnel','pending'),('training_type','denied'),('personnel_training','approved'),('rating_scheme_entry','approved'),('counseling_record','pending')]:
  original=json.loads(json.load(open(v.root/('submit-'+resource+'.json')))['body'])
  row=next(r for r in rows(prefix+'-orgA-deletion_requests') if r['id']==original['id'])
  assert row['status']==expected,(resource,row['status'])
  differences={k for k in original if original[k]!=row[k]}
  assert differences <= {'status','denial_reason','reviewed_by','reviewed_at'},(resource,differences)
  if expected!='pending':assert row['reviewed_by'] and row['reviewed_at']
  if resource=='training_type':assert row['denial_reason']=='D18 final denial reason'
 assert rows(prefix+'-orgB-deletion_requests')==[json.loads(json.load(open(v.root/'submit-B-type.json'))['body'])]
 for org in ['orgA','orgB']:
  assert json.load(open(v.root/('before-files-'+org+'.json')))==json.load(open(v.root/(prefix+'-files-'+org+'.json'))),(org,'file changed')

def cleanup_absence(prefix):
 for org in ['orgA','orgB']:
  ids=set(sources[org].values())
  for table in tables:
   assert not any(r.get('id') in ids or r.get('resource_id') in ids for r in rows(prefix+'-'+org+'-'+table)),(org,table)

if __name__=='__main__':
 compare_failed_requests()
 capture('after-effects');file_capture('after-effects');originals('after-effects');compare_effects('after-effects')
 print('PASS exact failed requests, effect/status metadata, all original projections and both real PDFs',flush=True)
 v.helper('seed-cleanup','clean-seeds')
 capture('after-cleanup');file_capture('after-cleanup');originals('after-cleanup');cleanup_absence('after-cleanup')
 print('PASS all12 temporary source IDs/request sets absent and all original projections unchanged',flush=True)
 v.call('final-doctor','tool','doctor')
 v.call('owned-cleanup','tool','cleanup')
