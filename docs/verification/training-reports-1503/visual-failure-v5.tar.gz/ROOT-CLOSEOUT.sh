#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH
export TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp
export NODE_DISABLE_COMPILE_CACHE=1
run_dir=.verification/evidence/verify-trooptotask/1503-final-chart-v5
control=.agents/skills/verify-trooptotask/helpers/control.mjs
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5')
r=json.loads((p/'root-doctor-closeout.json').read_text())
assert r['status']=='PASS'
assert r['candidate']=='34438fcff6e95e651d3f6dcbd17453bfbc0e44234c3dc0ed8ac41367b6949f8f'
assert r['session']=='34ec9b7e-a20d-4939-86fd-2314839257fc'
PY
node "$control" --worker 1 rows organizations orgA > "$run_dir/root-organizations-orgA-restored.json"
node "$control" --worker 1 rows organizations orgB > "$run_dir/root-organizations-orgB-restored.json"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5')
for org in ['orgA','orgB']:
 a=json.loads((p/f'root-organizations-{org}-original.json').read_text())
 b=json.loads((p/f'root-organizations-{org}-restored.json').read_text())
 assert a==b,org
 assert b['rows'][0]['training_readiness_goal_percent']==90
PY
node "$control" --worker 1 clean-seeds > "$run_dir/root-clean-seeds.json"
node .verification/1503-boundary-seed.mjs readback 1 > "$run_dir/root-seed-absence.json"
node "$control" --worker 1 rows personnel_trainings orgA > "$run_dir/root-training-orgA-restored.json"
node "$control" --worker 1 rows personnel_trainings orgB > "$run_dir/root-training-orgB-restored.json"
python3 - <<'PY'
import json
from pathlib import Path
p=Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5')
r=json.loads((p/'root-seed-absence.json').read_text())
assert set(r['observed'])=={'personnel','training_types','training_views','personnel_trainings'}
assert all(v==[] for v in r['observed'].values())
for org in ['orgA','orgB']:
 assert json.loads((p/f'root-training-{org}-original.json').read_text())==json.loads((p/f'root-training-{org}-restored.json').read_text()),org
r={'status':'PASS','proof':'Root owned provider readback after journal-bound cleanup','exactSeedIdsAbsent':True,'originalTrainingAndOrganizationRowsEqual':True,'goals':{'orgA':90,'orgB':90}}
(p/'root-restoration-audit.json').write_text(json.dumps(r,indent=2)+'\n')
PY
npm run --silent verify:app -- doctor --worker 1 > "$run_dir/root-doctor-after-seeds.json"
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5/root-doctor-after-seeds.json').read_text())
assert r['status']=='PASS'
PY
node .verification/mac-preview-1503/command.mjs check > "$run_dir/root-transport-check-after-seeds.json"
node .verification/mac-preview-1503/command.mjs stop > "$run_dir/root-transport-stop.json"
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5/root-transport-stop.json').read_text())
assert r['status']=='PASS' and r['sessionId']=='34ec9b7e-a20d-4939-86fd-2314839257fc'
assert r['localListenerGone'] and r['serveMappingGone']
PY
npm run --silent verify:app -- cleanup --worker 1 > "$run_dir/root-owned-cleanup.json"
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('.verification/evidence/verify-trooptotask/1503-final-chart-v5/root-owned-cleanup.json').read_text())
assert r['status']=='PASS' and r['phase']=='cleaned'
print('Root restoration, exact seed absence, doctor and owned cleanup PASS.')
PY
