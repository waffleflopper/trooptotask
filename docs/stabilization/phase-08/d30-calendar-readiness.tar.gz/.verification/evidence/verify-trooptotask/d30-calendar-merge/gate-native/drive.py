import json, os, re, subprocess
from pathlib import Path
root=Path.cwd(); out=root/'.verification/evidence/verify-trooptotask/d30-calendar-merge/gate-native'
env=os.environ.copy();env['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+env['PATH']
def call(args,name):
 p=subprocess.run(args,env=env,text=True,capture_output=True,timeout=120)
 (out/name).write_text(p.stdout+p.stderr)
 if p.returncode: raise RuntimeError(f'{name}: exit {p.returncode}')
 return p.stdout
def control(args,name):return call(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args],name)
def tool(name,args,receipt): return call(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args)],receipt)
call(['npm','run','--silent','verify:app','--','doctor'],'doctor-start.json')
actor=json.loads(control(['actor','calendarOperate','personnel'],'actor.json'));page=actor['pageId']
def snap(name):
 p=out/(name+'.txt');tool('take_snapshot',{'pageId':page,'filePath':str(p)},name+'.receipt.json');return p.read_text()
def click(label,kind,name):
 s=snap(name+'-before');m=re.search(r'uid=(\S+) '+kind+' "'+re.escape(label)+r'"(?: |$)',s)
 if not m:raise RuntimeError('Missing '+label)
 tool('click',{'pageId':page,'uid':m[1]},name+'-action.json')
def wait(label,name):tool('wait_for',{'pageId':page,'text':[label],'timeout':30000},name+'.json')
control(['server-source','arm','availability_entries','hold','1','120000'],'source-arm.json')
try:
 click('Calendar','link','calendar-entry')
 s=snap('held')
 if 'Loading Calendar data' not in s or 'button "3-Month"' in s or 'button "Bulk Status"' in s:raise RuntimeError('Workspace usable before bootstrap')
 source=json.loads(control(['server-source','state'],'source-held.json'))
 if source['control']['phase']!='held' or source['control']['call']['status']!=200:raise RuntimeError('Real bootstrap not held')
 net=tool('list_network_requests',{'pageId':page,'resourceTypes':['fetch']},'network-held.json')
 if '/api/calendar-range?' in net:raise RuntimeError('Range request started before bootstrap')
 tool('take_screenshot',{'pageId':page,'filePath':str(out/'held.png')},'held-screenshot.json')
 control(['server-source','release'],'source-release.json')
 wait('3-Month','released-wait');s=snap('released')
 for label in ['Able, Synthetic','Baker, Synthetic','Unassigned, Synthetic']:
  if label not in s:raise RuntimeError('Missing '+label)
 click('3-Month','button','three-month')
 wait('Next 3 Months','range-wait');snap('three-month')
 net=tool('list_network_requests',{'pageId':page,'resourceTypes':['fetch']},'network-range.json')
 if not re.search(r'/api/calendar-range\?rangeStart=2026-12-01&rangeEnd=2026-12-31 \[200\]',net):raise RuntimeError('Additional range not completed')
 click('3-Month','button','month-return');click('Prev','button','september')
 wait('Verification Unit Closure','september-wait');s=snap('september')
 for label in ['Able, Synthetic','Baker, Synthetic','Unassigned, Synthetic','Verification Leave','Verification Training','Verification Unit Closure']:
  if label not in s:raise RuntimeError('Missing saved fact '+label)
 tool('take_screenshot',{'pageId':page,'filePath':str(out/'september.png')},'september-screenshot.json')
 click('Next','button','october-return');click('Prev','button','september-reread');wait('Verification Unit Closure','second-read-wait');snap('second-read')
 print('PASS: initial readiness, subsequent range 200, September saved facts and second read',flush=True)
finally: control(['server-source','restore'],'source-restore.json')
