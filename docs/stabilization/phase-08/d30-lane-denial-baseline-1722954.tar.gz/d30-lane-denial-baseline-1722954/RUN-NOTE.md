# D30 #1378 lane-denial baseline (unchanged app)

- Revision: `172295422a6b97838ad6cd9c3b4d5f079a1245aa` (detached, no source changes)
- Candidate digest: `4d8fa99d3e2e76049b1c343efd78354648fef8a0f9cc21958a57d9568f7a5b86`
- Worker 1, origin `http://127.0.0.1:33759`, session `b117334b-e587-4531-92ab-59306c91eb7e`
- Browser: Chromium 152.0.7977.82 (owned verify:app profile, native DevTools tools only)
- Doctor PASS at start (`doctor-start.json`) and before cleanup (`doctor-final.json`); `clean-seeds` and owned `cleanup` PASS.
- Organization A `6a8d58d8-d6fa-461d-b02b-cb4539564101`. Date 2026-10-08.
- No seeds, grant changes or network controls were used.

## Actors (from `scripts/verification/fixtures.mjs` membership overrides)

| Actor | Org A grants |
| --- | --- |
| `manager` | Personnel configure; Calendar, Training, Critical Tasks, Onboarding, Rating Scheme none |
| `ictViewer` | Critical Tasks view; every other lane none (incl. Personnel) |
| `dashboardNone` | every lane none, Organization scope |

Each actor signed in through `control.mjs actor` (isolated browser context): manager page 2, ictViewer page 3, dashboardNone page 4. Each path was then opened by direct URL (`navigate_page` type url). The first manager Critical Tasks and first ictViewer Personnel captures are the actor helper's own direct arrival (`manager-critical-tasks-*`, `ictViewer-personnel-arrival-*`; the ictViewer actor helper timed out waiting for its ready text because nothing rendered).

## Method per path

`LABEL-snapshot.txt` / `LABEL-screenshot.png`: visible state ~8 s after load (wait for "Access Restricted"/"permission"; `LABEL-wait.txt` records timeout when absent). `LABEL-console.txt`: native console messages for that navigation (the first capture of each context also contains login-page messages). `LABEL-data.txt`: read-only same-page `fetch(path + '/__data.json')` with status, streamed nodes/chunks, probe for fixture Person names/IDs (Able/Baker/Unassigned/Foreign), `main` text. `LABEL-data-summary.json` summarizes it. `ACTOR-document-status.txt`: read-only fetch of each path's HTML document status. `dashboardNone-ssr-html-context.txt`: SSR HTML around the denial text.

Redaction: the root layout's `__data.json` session node carries `access_token`/`refresh_token`; their values were replaced with `[REDACTED]` in-page before capture. No other change.

Expected (approved, as Calendar/Evals): visible "Access Restricted", no lane data, no uncaught error.

## Observations

| Path | Actor | Visible | Console | Doc / `__data.json` | Lane data leak | Status |
| --- | --- | --- | --- | --- | --- | --- |
| critical-tasks | manager, dashboardNone | Blank main (breadcrumb only) | `Uncaught Error: Failed to hydrate Critical Tasks workspace` + `Uncaught (in promise)` | doc 200; data 200, streamed chunk 1 error "You don't have permission. This requires Critical Tasks can view permissions…" | none | failed (baseline defect) |
| training | manager, dashboardNone | "Access Restricted / You don't have permission to view this area…" | `Uncaught Error: Failed to hydrate training workspace` + `Uncaught (in promise)` | doc 200; data 200, chunk 1 error "…requires Training can view permissions…" | none | failed (visible OK, uncaught error) |
| onboarding | manager, dashboardNone | Route error page "403 / You don't have permission to view this page. / Back to Dashboard" (not the lane "Access Restricted" state) | `Failed to load resource: 403` (document); no uncaught error | doc 403; data 200 with node error `{"message":"You do not have permission to view Onboarding"}` status 403 | none | live-verified denial; differs from approved Access Restricted presentation |
| personnel | ictViewer, dashboardNone | Blank main (breadcrumb only); document title stayed "Sign In - Troop to Task" on helper arrival | `Uncaught Error: Failed to hydrate personnel workspace` (+ `Failed to load personnel workspace` on direct reload) + `Uncaught (in promise)` | doc 200; data 200, chunk 1 error "…requires Personnel can view permissions…" | none | failed (baseline defect) |
| home (dashboard) | dashboardNone | Overview renders: Strength 0/0, no attention items, 0 evals overdue, no assignments/onboardings/changes | none | doc 200; data 200, empty personnel/availability; trainingSummary/ictlSummary null | none | live-verified (no lane gate on home; lane-absent sections empty) |
| home (dashboard) | ictViewer | Overview with 0/0 strength, Alpha/Bravo 0/0 | none | data 200; `ictlSummary` lists Able/Baker/Unassigned names, IDs and readiness | CT-view-authorized ictlSummary only; not Personnel-lane data. Flag for review if Personnel-none should hide names | live-verified (note) |
| calendar (control) | manager, dashboardNone | "Access Restricted / You don't have permission to view this area…" | none | doc 200; data 200, chunk `{laneKey:"calendar",access:"restricted"}` | none | live-verified |
| evals (control) | manager, dashboardNone | "Access Restricted / You don't have permission to view evaluations…" | none | doc 200; data 200, chunk `{laneKey:"ratingScheme",access:"restricted"}` | none | live-verified |

Root-cause hint (Critical Tasks): SSR HTML already contains the `critical-tasks-restricted-title` "Access Restricted" section; the client then rejects the streamed workspace promise during hydration and the main region becomes empty. Personnel SSR renders no restricted section at all. Training SSR and client both render Access Restricted but the rejected workspace promise is still thrown uncaught. Calendar/Evals stream a resolved `{access: 'restricted'}` value instead of rejecting.

Ambient console noise on every page (not lane related): Vercel insights/speed-insights 404 + MIME refusal, CSP `eval` issue, unused preload warning.

No path was unreachable: fixture actors lacking each lane's view grant exist for all lanes.
