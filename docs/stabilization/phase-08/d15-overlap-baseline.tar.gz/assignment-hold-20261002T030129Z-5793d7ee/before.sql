SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND p.id = '1932420d-b8fa-4c4d-999b-65563125fdd0'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND id = '56a2b353-dbc1-46de-959d-b1ff125dbca5'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND s.onboarding_id = '1932420d-b8fa-4c4d-999b-65563125fdd0'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
