SET application_name = 't2t-d15-race-87a0325d';
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
UPDATE public.personnel_onboardings SET status = 'cancelled', cancelled_at = '2026-10-01T18:52:10.921029+00:00'::timestamptz
WHERE id = '57fa3d0d-a43f-45b3-86f8-c5a87866503b'::uuid AND organization_id = 'bcc91ccd-0ade-4c1f-84c0-ec8fd9604116'::uuid
  AND status = 'cancelled' AND cancelled_at = '2000-01-01T12:00:00+00:00'::timestamptz AND completed_at IS NULL
RETURNING json_build_object('event', 'updated', 'id', id, 'status', status, 'cancelled_at', cancelled_at);
SELECT json_build_object('event', 'holder-ready', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
