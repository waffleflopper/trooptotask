import current as x
import json
d=x.d;seed=json.loads((x.c/'seed.json').read_text())
d.act('parent-archive-open','button','Archive SPC '+seed['name']+', Synthetic');r=d.snap('parent-archive-confirmation');print([(n.get('role'),n.get('name')) for n in d.walk(r['structuredContent']['snapshot']) if n.get('role') in ['dialog','alertdialog','button']][-12:])
