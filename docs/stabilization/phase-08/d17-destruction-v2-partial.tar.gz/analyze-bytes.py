import hashlib,json,pathlib,sys
p=pathlib.Path(__file__).resolve().parent
phase=sys.argv[1];assert phase in ['partial','after','before-stepup','after-stepup']
read=lambda name:json.loads((p/(name+'.json')).read_text())
before_api=read('files-before')['files'];after_api=read('files-'+phase)['files']
key=lambda f:(f['bucket'],f['path'])
assert len(before_api)==len({key(f) for f in before_api})
assert {key(f) for f in before_api}=={key(f) for f in after_api}
assert all(f['present'] and f['size']==f['observedSize'] and f['sha256']==f['observedSha256'] for f in before_api)
metadata=read('cascade-pre-fault')['storage_objects'];known={key(f) for f in metadata}
def physical(name):
 d=read(name);out={}
 for f in d['physical_storage_files']:
  matches=[k for k in known if '/'+k[0]+'/'+k[1]+'/' in f['path']]
  assert len(matches)==1,(f,matches)
  k=matches[0];assert k not in out;out[k]=f
 return out
b=physical('physical-bytes-before');a=physical('physical-bytes-'+phase)
assert set(b)==known and set(a)<=known
for f in before_api:
 assert (b[key(f)]['size'],b[key(f)]['sha256'])==(f['size'],f['sha256'])
for f in after_api:
 assert f['present']==(key(f) in a)
 if f['present']:assert (a[key(f)]['size'],a[key(f)]['sha256'])==(f['observedSize'],f['observedSha256'])==(f['size'],f['sha256'])
for k,f in a.items():assert f==b[k]
org=read('fixture')['ids']['orgA']
is_target=lambda k:k[1].split('/',1)[0].lower()==org
roster=[k for k in known if k[1].endswith('-native-roster.pdf')];assert len(roster)==1
pdf=(p/'native-roster.pdf').read_bytes();assert (b[roster[0]]['size'],b[roster[0]]['sha256'])==(len(pdf),hashlib.sha256(pdf).hexdigest())
x={'phase':phase,'baseline_ledger_count':len(before_api),'baseline_api_hashes_match':True,'baseline_physical_count':len(b),'baseline_physical_keys_match_all_metadata':True,'baseline_physical_hashes_match_all_ledger_and_native_pdf':True,'remaining_physical_count':len(a),'remaining_target_count':sum(is_target(k) for k in a),'remaining_foreign_lookalike_count':sum(not is_target(k) for k in a),'removed_target_count':sum(is_target(k) for k in b if k not in a),'all_remaining_files_exact_same_paths_sizes_hashes':True,'api_presence_matches_actual_physical_keys':True,'native_roster_present':roster[0] in a,'removed_files':[{'bucket':k[0],'path':k[1],**b[k]} for k in sorted(set(b)-set(a))],'remaining_files':[{'bucket':k[0],'path':k[1],**a[k]} for k in sorted(a)]}
(p/('byte-comparison-'+phase+'.json')).write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({k:v for k,v in x.items() if k not in ['removed_files','remaining_files']}))
