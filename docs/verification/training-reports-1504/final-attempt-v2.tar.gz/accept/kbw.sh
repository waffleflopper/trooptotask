#!/usr/bin/env bash
# usage: kbw.sh PREFIX WIDTH HEIGHT
E=.verification/evidence/verify-trooptotask/1504-final-v2/accept
p=$1; w=$2; h=$3
$E/t.sh "$p-a-resize" "native resize_page ${w}x${h}" resize_page "{\"pageId\":2,\"width\":$w,\"height\":$h}" >/dev/null
$E/v.sh "$p-b-arm-fail" "arm-fail detail ($w)" network arm-fail 2 training-reports/detail >/dev/null
$E/snap.sh "$p-c-pre" 2 >/dev/null
U=$(grep 'button "Total, Verification Required' $E/snaps/$p-c-pre.txt | grep -o 'uid=[0-9_]*' | cut -d= -f2)
$E/t.sh "$p-d-click-cell" "native click Total Required ($w, 503 armed)" click "{\"pageId\":2,\"uid\":\"$U\"}" >/dev/null
$E/v.sh "$p-e-restore" "restore detail fail ($w)" network restore 2 >/dev/null
$E/t.sh "$p-f-tab" "native Tab ($w)" press_key '{"pageId":2,"key":"Tab"}' >/dev/null
$E/t.sh "$p-g-tab" "native Tab ($w)" press_key '{"pageId":2,"key":"Tab"}' >/dev/null
$E/focus.sh "$p-h-focus-before" "focus BEFORE Enter ($w)"
$E/shot.sh "k-$w-retry-focused" 2 false >/dev/null
$E/t.sh "$p-i-enter" "native Enter on Retry ($w)" press_key '{"pageId":2,"key":"Enter"}' >/dev/null
$E/focus.sh "$p-j-focus-after" "focus AFTER Retry ($w)"
$E/shot.sh "k-$w-region-focused-after-retry" 2 false >/dev/null
