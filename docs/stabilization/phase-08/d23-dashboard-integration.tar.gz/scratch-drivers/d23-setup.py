import importlib.util
spec=importlib.util.spec_from_file_location('capture','.verification/tmp/d23-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
for org in ['orgA','orgB']:
 for table in ['personnel','personnel_onboardings','onboarding_step_progress','training_types','personnel_trainings','rating_scheme_entries','daily_assignments']:
  m.call('helper','rows',[table,org],f'original-{org}-{table}.json')
m.call('helper','seed',['dashboard'],'seed-dashboard.json')
print('Originals preserved; dashboard cohort prepared',flush=True)
