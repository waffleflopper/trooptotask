import os,pathlib,subprocess
root=pathlib.Path('.verification/evidence/verify-trooptotask/rebase-1511/validation')
env=dict(os.environ, PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH'], TMPDIR=str(pathlib.Path('.verification/tmp-rebase-1511').resolve()), PUBLIC_SUPABASE_URL='http://127.0.0.1:9', PUBLIC_SUPABASE_ANON_KEY='synthetic-anon', SUPABASE_SERVICE_ROLE_KEY='synthetic-service', ACCOUNT_SETUP_SESSION_SECRET='verification-only-account-setup-session-secret')
for k in ['APP_PUBLIC_ORIGIN','PUBLIC_APP_ORIGIN','PUBLIC_SITE_URL']: env.pop(k,None)
with (root/'results-successor.tsv').open('w') as result:
 for check in ['format','format:check','lint','governance:check','check','test','build']:
  taskenv=dict(env)
  if check=='build': taskenv['APP_PUBLIC_ORIGIN']='http://127.0.0.1:4173'
  with (root/(check.replace(':','-')+'-successor.log')).open('w') as out:
   p=subprocess.run(['npm','run',check],stdout=out,stderr=subprocess.STDOUT,env=taskenv)
  result.write(f'{check}\t{p.returncode}\n');result.flush()
  print(check,p.returncode,flush=True)
