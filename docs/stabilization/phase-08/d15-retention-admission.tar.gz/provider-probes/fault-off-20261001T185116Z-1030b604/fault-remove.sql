SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_parent_delete_fault_dd2bba08 ON public.personnel_onboardings;
DROP FUNCTION IF EXISTS public.t2t_d15_parent_delete_fault_dd2bba08();
COMMIT;
SELECT json_build_object('event', 'fault-remove-committed');
