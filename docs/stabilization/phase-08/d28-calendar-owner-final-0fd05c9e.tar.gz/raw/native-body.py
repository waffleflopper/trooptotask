import sys,pathlib,os,json,subprocess,datetime,hashlib
root=pathlib.Path(__file__).resolve().parent
label,page,req=sys.argv[1:];now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
data={"pageId":int(page),"reqid":int(req),"requestFilePath":str(root/(label+".network-request")),"responseFilePath":str(root/(label+".network-response"))}
cmd=["npm","run","--silent","verify:app","--","--worker","1","tool","get_network_request",json.dumps(data)]
env=os.environ.copy();env["PATH"]="/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:"+env["PATH"];env["TMPDIR"]=json.load(open(root/"tmp-binding.json"))["path"]
def journal(x):
 with (root/"journal.jsonl").open("a") as f:f.write(json.dumps(x)+"\n")
journal({"event":"dispatch","timestamp":now(),"label":label,"kind":"native-body-projection","command":cmd,"driverOrder":"serial","projection":"Native tool body files exact; stdout credential-bearing headers and structured request metadata omitted in full."})
r=subprocess.run(cmd,capture_output=True,text=True,env=env)
try:d=json.loads(r.stdout);toolError=d.get("isError",False)
except Exception:toolError=True
result={"timestamp":now(),"commandExit":r.returncode,"toolError":toolError,"pageId":int(page),"reqid":int(req),"projection":"Entire credential-bearing native stdout omitted. Exact native request/response body files retained.","bodies":[]}
for key in ["requestFilePath","responseFilePath"]:
 p=pathlib.Path(data[key]);result["bodies"].append({"kind":key,"path":p.name,"exists":p.exists(),"bytes":p.stat().st_size if p.exists() else None,"sha256":hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None})
(root/(label+"-projection.json")).write_text(json.dumps(result,indent=2));journal({"event":"completion","timestamp":now(),"label":label,"exit":r.returncode,"projection":label+"-projection.json"});print(json.dumps(result,indent=2));sys.exit(r.returncode or int(toolError))
