#!/usr/bin/env python3
"""Native actions selected from a fresh saved accessibility snapshot."""
import json,re,subprocess,sys
from pathlib import Path
import os
run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');base='.verification/evidence/verify-trooptotask/'+run+'/'
mode,page,tag=sys.argv[1:4];page=int(page)
def tool(label,name,args):
 r=subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','tool',label,name,json.dumps(args)],check=True,capture_output=True,text=True)
 return r.stdout
if mode=='click':
 needle=sys.argv[4]
 tool(tag+'-before','take_snapshot',{'pageId':page,'filePath':base+tag+'-before.txt'})
 snap=Path(base+tag+'-before.txt').read_text();lines=[s for s in snap.splitlines() if needle in s]
 if len(lines)!=1:raise SystemExit('Expected unique fresh snapshot match: '+str(lines))
 uid=re.search(r'uid=([^\s]+)',lines[0]).group(1)
 tool(tag+'-click','click',{'pageId':page,'uid':uid,'includeSnapshot':True})
elif mode=='reload':tool(tag+'-reload','navigate_page',{'pageId':page,'type':'reload'})
elif mode=='url':tool(tag+'-navigate','navigate_page',{'pageId':page,'type':'url','url':sys.argv[4]})
else:raise SystemExit('Unknown mode')
tool(tag+'-after','take_snapshot',{'pageId':page,'filePath':base+tag+'-after.txt'})
tool(tag+'-screen','take_screenshot',{'pageId':page,'filePath':base+tag+'.png','fullPage':True})
print(Path(base+tag+'-after.txt').read_text())
