# Issue 1501 affected baseline

Revision 3a1cd50880356eb9b9c1c7bca570938b563fcee6. Candidate 09a4e3c3379dfc20d42bfdbfc1463c4005b645ff8166e6e165958f35469a3135. Production owned app http://127.0.0.1:44451. Node 24.21.0, npm 11.19.0, Chromium 152.0.7977.82, Supabase CLI 2.101.0. Doctor and cleanup passed. Initial Node 26.8.2 build was rejected by Vercel adapter. Owned failed run cleaned before retry. No source changes for runtime recovery.

Owner opened Policies. Retention 36, warning 180. Native fill 181 and Save succeeded. Reload showed 181 and Saved. Restored warning to 180 through native fill and Save. The new goal does not exist before this change.

trainingConfigure opened Training and native Reports. Readiness 25%, Current 1, Not Done 3, Expired 0, Expiring 0. Native import used Baker Required completion 2024-10-03 and Able Targeted completion 2025-10-18, two valid selected rows. Result Inserted 2, Updated 0, Exempted 0, Errors 0. Done, Reports, reload. Dated report remains 25%, Current 1, Expiring 1, Expired 1, Not Done 1. Alpha 50%, Bravo 0%, Unassigned 0%. This is the old current-only readiness rule. Final acceptance expects same independently counted scenario at 50% and Alpha 100%.

Snapshots, actions, screenshots and privileged synthetic completion readback retained separately. Baseline focused Vitest files 6 passed, tests 70 passed. Report calculation, report query, Organization policy, Policies state, settings provider and policy provider checks ran. This is not final acceptance or independent live execution.
