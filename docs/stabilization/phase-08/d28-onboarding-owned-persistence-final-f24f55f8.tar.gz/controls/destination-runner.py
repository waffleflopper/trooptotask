import ast, hashlib, importlib.util, json, pathlib, sys, types
sys.dont_write_bytecode = True
OLD = pathlib.Path('/home/waffleflops/.cache/t2t-1376-onboarding-ordinary-baseline-f064-20261007')
CACHE = pathlib.Path('/home/waffleflops/.cache/t2t-1376-onboarding-focused-native-f24f55f8-20261007')
RUN = 'd28-onboarding-twoport-focused-f24f55f8-20261007'
OLD_RUN = 'd28-onboarding-ordinary-baseline-f064-20261007'
EVIDENCE = pathlib.Path.cwd() / '.verification/evidence/verify-trooptotask' / RUN
assert pathlib.Path.cwd() == pathlib.Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
assert CACHE == pathlib.Path(__file__).parent and EVIDENCE.is_dir()
ALLOWED = ['native_driver.py', 'resource-receipt.py', 'full-rows.py', 'catalog-setup-request.py']
def source(name):
    assert name in ALLOWED
    original = (OLD / name).read_text()
    before = ast.parse(original)
    effective = original.replace(OLD_RUN, RUN)
    after = ast.parse(effective)
    old_nodes, new_nodes = list(ast.walk(before)), list(ast.walk(after))
    assert len(old_nodes) == len(new_nodes)
    changed = []
    for a, b in zip(old_nodes, new_nodes):
        assert type(a) == type(b)
        if isinstance(a, ast.Constant) and a.value != b.value:
            assert isinstance(a.value, str) and a.value.replace(OLD_RUN, RUN) == b.value
            assert a.value.endswith(OLD_RUN)
            changed.append({'old': a.value, 'new': b.value})
            b.value = a.value
    assert ast.dump(before) == ast.dump(after)
    assert len(changed) == (0 if name == 'catalog-setup-request.py' else 1)
    return effective, {'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'effectiveSha256': hashlib.sha256(effective.encode()).hexdigest(), 'changedConstants': changed, 'allOtherAstEqual': True, 'executionFilename': str(CACHE / name if name == 'resource-receipt.py' else OLD / name)}
def driver():
    code, binding = source('native_driver.py')
    module = types.ModuleType('native_driver')
    module.__file__ = str(OLD / 'native_driver.py')
    exec(compile(code, module.__file__, 'exec'), module.__dict__)
    assert module.E == EVIDENCE
    sys.modules['native_driver'] = module
    return module
if __name__ == '__main__':
    name, *args = sys.argv[1:]
    if name == 'bindings':
        print(json.dumps({name: source(name)[1] for name in ALLOWED}, indent=2))
    else:
        assert name in ['resource-receipt.py', 'full-rows.py', 'catalog-setup-request.py']
        if name == 'catalog-setup-request.py': driver()
        code, binding = source(name)
        sys.argv = [binding['executionFilename'], *args]
        exec(compile(code, binding['executionFilename'], 'exec'), {'__name__': '__main__', '__file__': binding['executionFilename']})
