import { defineConfig, mergeConfig } from 'vitest/config';
import rootConfig from '../../../../vitest.config';

const config = mergeConfig(rootConfig, defineConfig({}));
// Keep the project plugins/aliases, but run only this explicitly admitted scratch probe.
config.test = {
	...config.test,
	include: ['.verification/evidence/verify-trooptotask/d13-artifact-retention-sdk-probe/probe.test.ts'],
	// Actual SDK GET/503 retries wait 1s + 2s + 4s; preserve them unchanged.
	testTimeout: 15000
};
export default config;
