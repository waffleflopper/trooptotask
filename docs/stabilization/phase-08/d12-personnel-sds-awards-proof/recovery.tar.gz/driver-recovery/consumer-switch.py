import json,re
from flow import call,tool,snapshot,click,shot,base
from http import flags,ack,request,ORG,PERSON
seed=json.loads((base/'seed-lifecycle.json').read_text());fixture=json.loads((base/'fixture.json').read_text());origin=json.loads((base/'initial-doctor.json').read_text())['origin'];checks=[]
def named_link(label,page,name):
 s=snapshot(label+'-before',page);m=re.findall(r'uid=([^ ]+) link '+re.escape(json.dumps(name))+r' ',s)
 if len(m)!=1:raise RuntimeError('Expected exact link '+name+', got '+str(m))
 return tool(label,'click',{'pageId':page,'uid':m[0]})
page=json.loads((base/'owner-page.json').read_text())['pageId']
named_link('consumer-native-home-open',page,'Home');s=snapshot('consumer-native-home',page);shot('consumer-native-home',page);assert 'Forbidden' not in s
f=flags('consumer-home-ack-ids',page,route='');assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
named_link('consumer-native-roster-open',page,'Personnel');s=snapshot('consumer-native-roster',page);shot('consumer-native-roster',page);assert seed['name'] in s and 'Synthetic Spouse' not in s
checks.append({'scenario':'Native Org Dashboard and Personnel roster retained; real public projections select both admitted IDs','result':'PASS','limit':'No native acknowledgement toggle/badge exists; native normal pages plus public data projection are distinct boundaries.'})
actor=call('switch-login','control','actor','personnelSwitch','personnel');page=actor['pageId'];(base/'switch-page.json').write_text(json.dumps({'pageId':page},indent=2)+'\n')
s=snapshot('switch-a-before',page);shot('switch-a-before',page);assert seed['name'] in s
f=flags('switch-a-ack-ids',page);assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
click('switch-b-menu-open',page,'Switch organization');s=snapshot('switch-b-menu',page)
m=re.findall(r'uid=([^ ]+) menuitem "[^"\n]*Verification Organization B[^"\n]*"',s)
if len(m)!=1:raise RuntimeError('Need actual B menuitem, got '+str(m))
tool('switch-b-select','click',{'pageId':page,'uid':m[0]});s=snapshot('switch-b-roster',page);shot('switch-b-roster',page)
assert 'Foreign, Synthetic' in s and seed['name'] not in s and 'Add Person' not in s
f=flags('switch-b-ack-ids',page,org=fixture['ids']['orgB']);assert any(m['ids']==[] for m in f['matches']),f
before={o:{t:call('switch-b-before-'+o+'-'+t,'control','rows',t,o)['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']}
a=ack('switch-b-view-ack-denied',page,person=fixture['ids']['personForeign'],org=fixture['ids']['orgB']);assert a['status']==403,a
b=request('switch-b-view-sds-denied',page,'/org/'+fixture['ids']['orgB']+'/api/personnel/'+fixture['ids']['personForeign']+'/extended-info','PUT',{'personnelId':fixture['ids']['personForeign'],'bloodType':'AB-'});assert b['status']==403,b
foreign=ack('switch-b-foreign-id-concealed',page,person=PERSON,org=fixture['ids']['orgB']);assert foreign['status']==404,foreign
after={o:{t:call('switch-b-after-'+o+'-'+t,'control','rows',t,o)['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']};assert before==after
click('switch-a-menu-open',page,'Switch organization');s=snapshot('switch-a-menu',page)
m=re.findall(r'uid=([^ ]+) menuitem "[^"\n]*Verification Organization A[^"\n]*"',s)
if len(m)!=1:raise RuntimeError('Need actual A menuitem, got '+str(m))
tool('switch-a-select','click',{'pageId':page,'uid':m[0]});s=snapshot('switch-a-returned',page);shot('switch-a-returned',page);assert seed['name'] in s
f=flags('switch-a-returned-ack-ids',page);assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
checks.append({'scenario':'Native Aconfigure→Bview→A organization switch; B conceals A and rejects SDS/ack writes while retaining all A/B rows','result':'PASS','ackStatus':a['status'],'sdsStatus':b['status'],'foreignIDStatus':foreign['status'],'allFullABRowsExact':True,'limit':'Independent actor context is not a held-save/stale cross-tab proof; those unchanged ordering paths remain separate lower-level/baseline evidence.'})
(base/'native-consumer-switch-check.json').write_text(json.dumps({'result':'PASS','checks':checks},indent=2)+'\n')
