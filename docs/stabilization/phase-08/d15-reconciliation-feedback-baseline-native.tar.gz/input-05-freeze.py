import hashlib,json,os,subprocess
from pathlib import Path
run=os.environ.get('D15_RECONCILE_RUN','')
if run not in ('baseline','final'): raise ValueError('Explicit run')
root=Path('.verification/evidence/verify-trooptotask')/f'd15-reconciliation-feedback-{run}-native'
root.mkdir(exist_ok=True)
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],text=True).strip(): raise ValueError('Clean committed freeze required')
paths=['.agents/skills/verify-trooptotask/SKILL.md','.agents/skills/verify-trooptotask/features/README.md','.agents/skills/verify-trooptotask/features/onboarding-packets.md']
paths+=['.verification/tmp/d15-reconciliation-feedback/'+n for n in ['plan.md','capture.py','freeze.py','resources.py','business.py']]
paths+=subprocess.check_output(['git','ls-files','scripts/verification','.agents/skills/verify-trooptotask/helpers'],text=True).splitlines()
paths+=['src/features/onboarding/stores/onboarding.svelte.ts','src/features/onboarding/contexts/OnboardingPageContext.svelte.ts','src/features/onboarding/components/OnboardingStepRow.svelte','src/features/onboarding/components/OnboardingDetailSheet.svelte','src/features/onboarding/components/OnboardingModals.svelte','src/features/onboarding/components/OnboardingKanbanView.svelte']
records=[]
for n,path in enumerate(dict.fromkeys(paths)):
 data=Path(path).read_bytes();name=f'input-{n:02d}-'+Path(path).name
 with (root/name).open('xb') as f:f.write(data)
 item={'path':path,'copy':name,'sha256':hashlib.sha256(data).hexdigest()}
 if not path.startswith('.verification/'):
  if data!=subprocess.check_output(['git','show',revision+':'+path]):raise ValueError('Blob mismatch '+path)
  item['gitBlob']=subprocess.check_output(['git','rev-parse',revision+':'+path],text=True).strip()
 records.append(item)
with (root/'frozen-inputs.json').open('x') as f:json.dump({'revision':revision,'base':'366facdfdc7ef887cd5e8f8d20315c80223e36f1','inputs':records},f,indent=2)
print(json.dumps({'revision':revision,'inputs':len(records)}))
