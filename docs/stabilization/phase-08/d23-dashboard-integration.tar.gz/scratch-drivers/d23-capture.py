import json,subprocess,sys,os,re
from pathlib import Path
run=os.environ.get('D23_RUN','d23-projections-before')
out=Path('.verification/evidence/verify-trooptotask')/run
out.mkdir(parents=True,exist_ok=True)
def call(kind,name,arg,file):
 r=subprocess.run(['python3','.verification/tmp/d23-projection-call.py',kind,name,json.dumps(arg),file],capture_output=True,text=True)
 if r.returncode: print(r.stdout,r.stderr,flush=True);raise SystemExit(r.returncode)
 return json.loads((out/file).read_text())
def native(name,arg,file):return call('native',name,arg,file)
def capture(page,label):
 s=native('take_snapshot',{'pageId':page},label+'-initial.json')
 txt='\n'.join(x.get('text','') for x in s['content'])
 m=re.search(r'uid=(\S+) button "Got it"',txt)
 if m:native('click',{'pageId':page,'uid':m[1]},label+'-dismiss.json')
 native('navigate_page',{'pageId':page,'type':'reload'},label+'-reload.json')
 native('take_snapshot',{'pageId':page},label+'-reloaded.json')
 native('evaluate_script',{'pageId':page,'function':Path('.verification/tmp/d23-readfn.txt').read_text(),'filePath':str(out/(label+'-page-data.json')),'waitForStableDom':False},label+'-page-data-action.json')
 r=subprocess.run(['mise','exec','node@24','--','node','.verification/tmp/d23-projection-decode.mjs',label+'-page-data.json',run],capture_output=True,text=True)
 if r.returncode:print(r.stderr);raise SystemExit(r.returncode)
 print(label,'captured page',page,flush=True)
if __name__=='__main__':
 for label,role in [('scoped','dashboardScoped'),('empty','dashboardEmpty'),('none','dashboardNone')]:
  if label=='scoped' and run.endswith('before'):
   a=json.loads((out/'actor-scoped-retry.json').read_text())
  else:a=call('helper','actor',[role,'home'],'actor-'+label+'.json')
  capture(a['pageId'],label)
