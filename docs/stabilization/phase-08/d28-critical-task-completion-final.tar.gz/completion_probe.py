import json
import native_driver as n

n.PAGE = json.loads((n.ROOT / 'operator-login.json').read_text())['pageId']
fixture = json.loads((n.ROOT / 'fixture.json').read_text())
original = json.loads((n.ROOT / 'original-completions.json').read_text())['rows']
ids = fixture['ids']
n.fill([('combobox', 'Select a year', '2025')], 'warning-year')
n.click('Monday, October 20, 2025', 'warning-date')
n.fill([
    ('combobox', 'Validation Method', 'Demonstration'),
    ('textbox', 'Validated By', 'D28 completion final validator'),
    ('textbox', 'Notes (optional)', 'D28 completion final draft')
], 'warning-draft')
n.control(['network', 'arm-fail', str(n.PAGE), 'personnel-ict-completions'], 'save-failure-arm')
n.click_dialog('Save', 'save-failed')
n.snap('save-failed-visible')
state = n.control(['network', 'state', str(n.PAGE)], 'save-failure-state')
failed = n.control(['rows', 'personnel_ict_completions', 'orgA'], 'save-failed-rows')
assert failed['rows'] == original
n.control(['network', 'restore', str(n.PAGE)], 'save-failure-restore')
n.click_dialog('Save', 'save-retry')
n.reload('warning-reload')
n.snap('warning-visible')
saved = n.control(['rows', 'personnel_ict_completions', 'orgA'], 'warning-saved-rows')
rows = [row for row in saved['rows'] if row['ict_task_id'] == ids['ictTaskGeneral']]
assert len(rows) == 1
row = rows[0]
assert row['personnel_id'] == ids['personA']
assert row['completed_at'] == fixture['dates']['ictWarningCompleted']
assert row['validation_method'] == 'Demonstration'
assert row['validated_by'] == 'D28 completion final validator'
assert row['notes'] == 'D28 completion final draft'
assert row['logged_by'] is not None
assert row['created_at'].split('+')[0].split('.')[-1].isdigit()
(n.ROOT / 'created-completion-id.json').write_text(json.dumps({'id': row['id'], 'createdAt': row['created_at']}) + '\n')
n.tool('take_screenshot', {'pageId': n.PAGE, 'filePath': str(n.ROOT / 'warning-person.png')}, 'warning-person-shot')
n.click('Edit completion for VERIFY-ICT-ALL', 'expired-edit-open')
n.click('Completion Date', 'expired-picker-open')
n.fill([('combobox', 'Select a year', '2024')], 'expired-year')
n.click('Saturday, October 5, 2024', 'expired-date')
n.click('Notes (optional)', 'null-note-focus', role='textbox')
n.key('Control+A', 'null-note-select')
n.key('Backspace', 'null-note-clear')
n.snap('null-note-empty-draft')
n.click_dialog('Save', 'expired-save')
n.reload('expired-reload')
n.snap('expired-visible')
updated = n.control(['rows', 'personnel_ict_completions', 'orgA'], 'expired-saved-rows')
edited = [record for record in updated['rows'] if record['id'] == row['id']]
assert len(edited) == 1
assert edited[0]['completed_at'] == fixture['dates']['ictExpiredCompleted']
assert edited[0]['notes'] is None
assert edited[0]['created_at'] == row['created_at']
assert edited[0]['logged_by'] == row['logged_by']
assert [record for record in updated['rows'] if record['id'] == ids['ictCompletionAlpha']] == original
n.tool('take_screenshot', {'pageId': n.PAGE, 'filePath': str(n.ROOT / 'expired-person.png')}, 'expired-person-shot')
print('FINAL COMPLETION FAILURE/RETRY/DATE/NULL/ID PASS')
