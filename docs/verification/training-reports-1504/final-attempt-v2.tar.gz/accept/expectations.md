# Final-v2 independent expectations (written before any native action)

Sources: #1433/#1504 spec, training-completions-reports recipe, literal fixture `001-fixture` and root originals. No app calculator.
Fixture day 2026-10-04 (dates.ui). Horizon 90 -> 2027-01-02. Org A f1b5242a…, Alpha group 429aed2d…, Required b0c5ee05…, Targeted c9ea77d1…, Optional ae84bf90… (excluded).
People A: Able (Alpha, 68W, Medic, SPC), Baker (Bravo, 11B, NCO), Unassigned (no group, 68W, NCO).
Applicability: Required -> all 3; Targeted -> 68W excluding NCO -> Able only; Optional excluded. 4 applicable pairs.
Original row: Able Required e2b8c0cd… 2026-09-27 -> 2027-09-27 (ready; lapses 2027-09-28 > horizon).

## 1. Original
3 People / 4 applicable. Ready 1, expired 0, missing 3, lapse 0 -> 1/4 = 25% today, 25% horizon.
Type risk: Required not-ready 2 / by-horizon 0, above Targeted 1 / 0.
Total Required cell -> Baker + Unassigned, both Not Done (2 rows, 2 distinct soldiers). Alpha x Targeted -> Able Not Done.
Focus link Required gap -> same 2 rows; focus moves to Affected soldiers region.

## 2. Dated import (CSV, literal fixture dates)
Baker Required 2024-10-04 (expires 2025-10-04 -> expired). Able Targeted 2025-10-19 (expires 2026-10-19 -> 15 days, warning, ready today, lapses 2026-10-20 within horizon).
Ready 2 (Able Req, Able Tgt), expired 1 (Baker Req), missing 1 (Unassigned Req), lapse 1 (Able Tgt) -> 2/4 = 50% today, 1/4 = 25% horizon.
Required risk 2/0 above Targeted 0/1.
Total Required detail: Unassigned Not Done first, then Baker expired 2025-10-04.
Targeted affected (Alpha x Targeted / Total Targeted): Able, warning label (15d left), 2026-10-19, Lapses Yes.
Unfiltered workbook Requirements: exactly 3 rows: Unassigned Req Not Done; Baker Req expired 2025-10-04; Able Tgt warning 2026-10-19 Yes. Sheets exactly Summary, Forecast, Hot spots, Focus, Requirements.

## 3. training-pages seed (after dated): +26 Alpha PFC People (#1 68W/Medic, 25 x 11B/NCO)
29 People; applicable = 29 Required + Able Tgt + temp#1 Tgt = 31.
Ready 2, expired 1, missing 28 (26 temp Req + Unassigned Req + temp#1 Tgt), lapse 1 -> 2/31 = 6.45% -> 6% today; 1/31 = 3.2% -> 3% horizon.
Required Total affected = 26 temp + Unassigned + Baker = 28 rows -> page size 25: "Rows 1–25 of 28", page 2 "Rows 26–28 of 28".
Failed page change keeps the old range label. Keyboard Retry repeats attempted page; focus = Affected soldiers region (not body) during load and after.

## Keyboard focus expectation (corrected behavior)
After Enter on detail Retry: document.activeElement is the Affected soldiers section (id training-affected-soldiers, tabindex -1) while loading and after response, not BODY.
Ordinary Next / page-size / filter changes: focus not moved to the region by the app (stays on the activated control or its replacement).

## Print expectations
Paper output: title + subtitle + filter line under title; Bottom line, Forecast, Hot spots, Type risk, Focus and loaded detail/range when open.
Absent in paper: sidebar, header, banners, toolbar/filters, header actions (Export/Print/Clear filters), Rows by, page-size radios, Focus links, paging, Retry.
Forecast fully inside the page at ~1920 collapsed sidebar (no clipped annotation/tick). Rows not split across pages where avoidable.
