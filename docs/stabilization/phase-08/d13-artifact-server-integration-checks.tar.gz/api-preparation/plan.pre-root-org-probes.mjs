export const families = ['follow-ups', 'documents', 'counseling-records'];
export const tables = ['personnel_follow_ups', 'personnel_documents', 'counseling_records', 'leader_notes'];
const token = (key) => '${' + key + '}';
export function buildPlan() {
  const plan = [];
  const snap = (name, compare = undefined) => plan.push({ kind: 'snapshot', name, compare });
  const request = (name, role, person, method, family, status, body, record, capture) => plan.push({
    kind: 'request', name, role, organization: person === 'foreign' ? 'orgB' : 'orgA',
    person: token('people.' + person), method,
    endpoint: record ? [family, token('created.' + record + '.' + family)] : [family],
    expectedStatus: status, body, capture
  });
  const input = (family, suffix = 'ordinary') => family === 'follow-ups'
    ? { title: token('tag') + ' ' + suffix + ' follow-up', notes: 'Synthetic ordinary API history', dueDate: '2026-10-15' }
    : { title: token('tag') + ' ' + suffix + ' ' + family,
        ...(family === 'counseling-records' ? { dateConducted: '2026-10-01', summary: 'Synthetic ordinary API PDF' } : {}),
        file: { path: token('files.validPdf'), type: 'application/pdf', name: 'synthetic-artifact.pdf' } };
  const archive = (family) => family === 'follow-ups' ? { status: 'archived' } : { action: 'archive' };
  snap('00-initial');
  for (const [person, role] of [['alpha', 'personnelScopedOperate'], ['bravo', 'personnelOperate'], ['unassigned', 'personnelOperate'], ['foreign', 'personnelForeign']]) {
    for (const family of families) request('01-create-' + person + '-' + family, role, person, 'POST', family, 200, input(family, person), undefined, 'created.' + person + '.' + family);
  }
  snap('02-created');
  for (const [role, person, status] of [['manager', 'alpha', 200], ['personnelScoped', 'alpha', 200], ['personnelForeign', 'foreign', 200], ['personnelOperate', 'alpha', 403]]) {
    for (const family of families) request('03-read-' + role + '-' + person + '-' + family, role, person, 'GET', family, status);
  }
  for (const [role, person, status] of [['viewer', 'alpha', 403], ['personnelEmpty', 'alpha', 404], ['personnelScopedOperate', 'bravo', 404], ['personnelScopedOperate', 'unassigned', 404], ['personnelForeign', 'alpha', 404]]) {
    for (const family of families) {
      // Use configure for concealed Group reads and operate for scoped writes.
      // Viewer and the other roles retain their ordinary grants.
      request('05-denied-read-' + role + '-' + person + '-' + family, role === 'personnelScopedOperate' ? 'personnelScoped' : role, person, 'GET', family, status);
      request('05-denied-create-' + role + '-' + person + '-' + family, role, person, 'POST', family, status, input(family, 'denied'));
      request('05-denied-archive-' + role + '-' + person + '-' + family, role, person, 'PATCH', family, status, archive(family), person);
      request('05-denied-delete-' + role + '-' + person + '-' + family, role, person, 'DELETE', family, status, undefined, person);
    }
  }
  for (const family of families) request('05-manager-to-B-read-' + family, 'manager', 'foreign', 'GET', family, 404);
  for (const family of families) {
    request('06-wrong-person-archive-' + family, 'manager', 'alpha', 'PATCH', family, 404, archive(family), 'bravo');
    request('06-wrong-person-delete-' + family, 'manager', 'alpha', 'DELETE', family, 404, undefined, 'bravo');
    request('07-active-delete-' + family, 'personnelScopedOperate', 'alpha', 'DELETE', family, 409, undefined, 'alpha');
  }
  for (const [role, person, record, status] of [
    ['manager', 'alpha', 'alpha', 200], ['personnelScoped', 'alpha', 'alpha', 200], ['personnelForeign', 'foreign', 'foreign', 200],
    ['viewer', 'alpha', 'alpha', 403], ['personnelOperate', 'alpha', 'alpha', 403],
    ['personnelEmpty', 'alpha', 'alpha', 404], ['personnelScoped', 'bravo', 'bravo', 404], ['personnelScoped', 'unassigned', 'unassigned', 404],
    ['personnelForeign', 'alpha', 'alpha', 404], ['manager', 'foreign', 'foreign', 404], ['manager', 'alpha', 'bravo', 404]
  ]) {
    request('08-download-' + role + '-' + person + '-' + record, role, person, 'GET', 'documents', status, undefined, record);
    plan.at(-1).endpoint.push('download');
  }
  for (const family of ['documents', 'counseling-records']) {
    for (const guard of ['signature', 'mime', 'oversize']) {
      const body = input(family, 'invalid-' + guard);
      if (guard === 'signature') body.file.path = token('files.spoofPdf');
      if (guard === 'mime') body.file.type = 'text/plain';
      if (guard === 'oversize') body.file.path = token('files.oversizePdf');
      request('09-file-' + family + '-' + guard, 'manager', 'alpha', 'POST', family, family === 'documents' && guard === 'oversize' ? 413 : 400, body);
    }
  }
  request('10-follow-create-identity-mismatch', 'manager', 'alpha', 'POST', 'follow-ups', 400, { ...input('follow-ups'), personnelId: token('people.bravo') });
  snap('11-after-denials', '02-created');
  request('12-follow-url-identity', 'personnelScopedOperate', 'alpha', 'PATCH', 'follow-ups', 200, {
    personnelId: token('people.bravo'), followUpId: token('created.bravo.follow-ups'),
    title: token('tag') + ' URL-bound edited follow-up', notes: 'Only URL target changes', dueDate: null
  }, 'alpha');
  plan.at(-1).expectedIdentity = { id: token('created.alpha.follow-ups'), personnelId: token('people.alpha'), title: token('tag') + ' URL-bound edited follow-up', notes: 'Only URL target changes', dueDate: null };
  snap('13-follow-url-identity');
  for (const family of families) request('17-archive-' + family, 'personnelScopedOperate', 'alpha', 'PATCH', family, 200, archive(family), 'alpha');
  snap('18-archived');
  for (const family of families) {
    request('23-delete-' + family, 'personnelScopedOperate', 'alpha', 'DELETE', family, 200, undefined, 'alpha');
  }
  snap('24-alpha-deleted');
  for (let index = 1; index <= 10; index++) {
    const body = { title: token('tag') + ' cap document ' + index, file: { path: token('files.exactTenMiBPdf'), type: 'application/pdf', name: 'exact-ten-mib.pdf' } };
    request('26-cap-create-' + index, 'personnelScopedOperate', 'cap', 'POST', 'documents', 200, body, undefined, 'created.cap-' + index + '.documents');
  }
  snap('27-cap-full');
  request('28-cap-rejection', 'personnelScopedOperate', 'cap', 'POST', 'documents', 409, input('documents', 'cap-rejected'));
  snap('29-cap-rejected', '27-cap-full');
  for (const [person, role] of [['bravo', 'personnelOperate'], ['unassigned', 'personnelOperate'], ['foreign', 'personnelForeign']]) {
    for (const family of families) {
      request('30-cleanup-archive-' + person + '-' + family, role, person, 'PATCH', family, 200, archive(family), person);
      request('30-cleanup-delete-' + person + '-' + family, role, person, 'DELETE', family, 200, undefined, person);
    }
  }
  for (let index = 1; index <= 10; index++) {
    request('31-cap-cleanup-archive-' + index, 'personnelScopedOperate', 'cap', 'PATCH', 'documents', 200, archive('documents'), 'cap-' + index);
    request('31-cap-cleanup-delete-' + index, 'personnelScopedOperate', 'cap', 'DELETE', 'documents', 200, undefined, 'cap-' + index);
  }
  snap('32-final-originals', '00-initial');
  return plan;
}
