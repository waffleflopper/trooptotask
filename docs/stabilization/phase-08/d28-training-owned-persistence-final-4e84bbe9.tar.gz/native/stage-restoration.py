import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
s=json.loads((pathlib.Path(__file__).parent/'runtime.json').read_text());r=d.tool('precleanup-owned-pages','list_pages',{});print(d.txt(r),flush=True)
for p in range(1,14):
 a=d.result_value(d.evaluate('precleanup-hooks-page-'+str(p),'()=>({origin:location.origin,path:location.pathname,network:!!window.__mapNetwork,export:!!window.__mapExport,feedback:!!window.__mapFeedback,print:!!window.__mapPrint})',p));assert not any(a[x] for x in ['network','export','feedback','print']),(p,a)
d.act('final-filters-clear','button','Clear filters',2);d.snap('preclean-all-report',2)
private=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1/verify-trooptotask-owned.json');(d.E/'precleanup-seed-journal.json').write_text(private.read_text())
for org in ['orgA','orgB']:
 for table in ['training_types','training_views','personnel_trainings','personnel','groups','organizations','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress']:d.call('preclean-'+org+'-'+table,['rows',table,org],True)
d.call('clean-seeds',['clean-seeds'],True)
for org in ['orgA','orgB']:
 for table in ['training_types','training_views','personnel_trainings','personnel','groups','organizations','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress']:d.call('afterclean-'+org+'-'+table,['rows',table,org],True)
(d.E/'postcleanup-seed-journal.json').write_text(private.read_text())
d.tool('final-report-reload','navigate_page',{'pageId':2,'type':'reload'});d.snap('final-original-report',2);d.shot('final-original-report',2);d.call('doctor-final',['doctor'])
