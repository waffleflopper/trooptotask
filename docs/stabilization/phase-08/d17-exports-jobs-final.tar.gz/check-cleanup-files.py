import json,pathlib,concurrent.futures,subprocess
p=pathlib.Path(__file__).parent
files=json.loads((p/'recorded-original-file-manifest.json').read_text());groups={};unsupported=[]
orgA=json.loads((p/'before-organizations-orgA.stdout').read_text())['rows'][0]['id']
for f in files:
 person=f.get('personnelId');parts=f['path'].split('/')
 if not person:unsupported.append(f);continue
 org='orgA' if parts[0]==orgA else 'orgB'
 groups.setdefault((org,person),{'counseling':[],'document':[]})['counseling' if f['bucket']=='counseling-files' else 'document'].append(f['path'])
def read(item):
 (org,person),families=item;args=[]
 for family,paths in families.items():
  for filePath in paths:args.extend([family,filePath])
 name=f'cleaned-files-{org}-{person}'
 r=subprocess.run(['python3','.verification/run-d17-final.py',name,'helper','artifact-files',org,person,*args],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stdout+r.stderr)
 actual=json.loads((p/(name+'.stdout')).read_text())
 assert not actual['tables']['counseling_records'] and not actual['tables']['personnel_documents'],actual
 for f in actual['files']:assert f['present'] is False,f
 return {'org':org,'person':person,'count':len(actual['files']),'confirmedAbsent':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(read,groups.items()))
assert sum(r['count'] for r in results)==30
out={'passed':True,'confirmedAbsentPersonPrefixObjects':30,'readbacks':results,'unsupportedAfterManifestCleanup':[{'bucket':f['bucket'],'path':f['path']}for f in unsupported],'limitation':'Two non-Person-prefix unrelated sentinel paths cannot be reread by frozen helper after clean-seeds clears ledger; no separate pre-disposal object-absence claim.'}
(p/'cleanup-file-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
