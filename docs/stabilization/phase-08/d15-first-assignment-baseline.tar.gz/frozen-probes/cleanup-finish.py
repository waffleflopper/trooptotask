from drive import *
import importlib.util
page=json.loads((E/'page-id.json').read_text())['pageId']; tag=json.loads((E/'legacy-seed.json').read_text())['tag']
s=snap(page,'cleanup-A-confirm-before'); click(page,uid(s,'button "Delete"'),'cleanup-A-confirm-delete')
s=snap(page,'cleanup-B-before'); click(page,uid(s,'button "Delete D15 Assignment Race B '+tag+'"'),'cleanup-B-open')
s=snap(page,'cleanup-B-confirm'); click(page,uid(s,'button "Delete"'),'cleanup-B-confirm-delete')
print(snap(page,'cleanup-native-templates')); screen(page,'cleanup-native-templates')
control(['clean-seeds'],'clean-seeds')
for org in ['orgA','orgB']:
 for short,table in [('packets','personnel_onboardings'),('progress','onboarding_step_progress'),('templates','onboarding_templates'),('definitions','onboarding_template_steps')]:
  rows=control(['rows',table,org],'restored-'+short+'-'+org)['rows']; original=json.loads((E/('original-'+short+'-'+org+'.json')).read_text())['rows']
  assert rows==original,(org,table)
(E/'restoration-comparison.json').write_text(json.dumps({'result':'PASS','scope':'Exact selected business fields for original A/B parents, progress, templates and definitions. Row timestamps excluded.','cohortRemoved':True},indent=2)+'\n')
s=snap(page,'cleanup-pipeline-nav-before'); click(page,uid(s,'link "Onboard"'),'cleanup-pipeline-nav')
native('navigate_page',{'pageId':page,'type':'reload'},'cleanup-pipeline-reload')
print(snap(page,'cleanup-empty-pipeline')); screen(page,'cleanup-empty-pipeline')
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1')
ledger=json.loads((private/'verify-trooptotask-owned.json').read_text()); assert not ledger.get('seeded')
(E/'ledger-clean.json').write_text(json.dumps({'seeded':ledger.get('seeded'),'cacheDirectoryExists':(private/'artifact-http-sessions').exists()},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('owned_env',ROOT/'scripts/verification/environment.py'); env=importlib.util.module_from_spec(spec); spec.loader.exec_module(env)
state,workdir,environ=env.owned(env.private_session(str(private))); project=state['project']; env.status(private)
for action in ['doctor','cleanup']:
 command=['npm','run','--silent','verify:app','--',action]; (E/(action+'-final-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 r=subprocess.run(command,text=True,capture_output=True); (E/(action+'-final.json')).write_text(r.stdout); (E/(action+'-final-stderr.log')).write_text(r.stderr)
 assert r.returncode==0,r.stderr or r.stdout
resources={}
for kind in ['container','volume','network']:
 command=['docker',kind,'ls']+(['-a'] if kind=='container' else [])+['--filter','label=com.supabase.cli.project='+project,'--format','{{json .}}']
 (E/(kind+'-empty-command.json')).write_text(json.dumps(command,indent=2)+'\n')
 r=subprocess.run(command,env=environ,text=True,capture_output=True); assert r.returncode==0,r.stderr
 resources[kind]=[json.loads(line) for line in r.stdout.splitlines() if line.strip()]; assert not resources[kind],resources
resources['privateWorkerExists']=private.exists(); assert not private.exists()
(E/'owned-project-empty.json').write_text(json.dumps({'project':project,'resources':resources},indent=2)+'\n')
print('Original selected A/B business fields restored; owned doctor, cleanup and exact project disposal PASS.')
