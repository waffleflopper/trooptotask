import contextlib, datetime, hashlib, importlib.util, io, json, pathlib, socket, subprocess
repo=pathlib.Path.cwd();run=repo/'.verification/evidence/verify-trooptotask/d17-units-final'
d=json.load(open(run/'owned-before-cleanup.json'))
p=pathlib.Path.home()/'.local/state/trooptotask-verification'/hashlib.sha256(str(repo).encode()).hexdigest()[:16]/'worker-1'
assert json.load(open(run/'65-cleanup.stdout'))['status']=='PASS' and not p.exists()
spec=importlib.util.spec_from_file_location('local_database',repo/'scripts/ci/database.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with contextlib.redirect_stdout(io.StringIO()):env=m.local_docker_environment(repo)
assert env['DOCKER_HOST']==d['docker_host']
def docker(*args):
    r=subprocess.run(['docker',*args],capture_output=True,text=True,env=env,timeout=20)
    assert r.returncode==0,'Read-only local inventory failed; not absence'
    return r.stdout.split()
labelled=docker('ps','--all','--filter','label=com.supabase.cli.project='+d['project'],'--format','{{.ID}}')
ids=set(docker('ps','--all','--no-trunc','--format','{{.ID}}'))
processes=[]
for item in d['processes']:
    stat=pathlib.Path('/proc')/str(item['pid'])/'stat';same=False
    if stat.exists():
        s=stat.read_text();same=s[s.rfind(')')+2:].split()[19]==str(item['start'])
    processes.append({**item,'original_process_present':same})
ports=[]
for port in sorted(set([int(d['origin'].rsplit(':',1)[1]),d['controlPort'],*d['provider_ports'].values()])):
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        try:s.bind(('127.0.0.1',port));free=True
        except OSError:free=False
    ports.append({'port':port,'bindable':free})
out={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'session':d['session'],'candidate':d['candidate'],
     'project':d['project'],'official_cleanup':'PASS','private_session_absent':not p.exists(),'processes':processes,
     'ports':ports,'exact_container_presence':{i:i in ids for i in d['container_ids']},'exact_project_containers':labelled,
     'scope':'Only original worker disposal; fresh read-only inventory on the same verified local Docker socket.'}
(run/'owned-disposal.json').write_text(json.dumps(out,indent=2)+'\n')
assert not labelled and not any(out['exact_container_presence'].values()) and not any(x['original_process_present'] for x in processes) and all(x['bindable'] for x in ports)
print(json.dumps(out,indent=2))
