from overlap import *
mode='notes'
seed=json.loads((E/'notes-legacy-seed.json').read_text());fixture=json.loads((E/'fixture.json').read_text());packet=seed['packets'][0]['id'];step=next(r['id'] for r in seed['progress'] if r['step_name']=='Orientation')
before={(org,table):json.loads((E/(mode+'-before-'+table+'-'+org+'.json')).read_text())['rows'] for org in ['orgA','orgB'] for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']}
bodies=[json.loads((E/(mode+'-request-'+label+'.json')).read_text()) for label in ['A','B']]
responses=[json.loads((E/(mode+'-response-'+label+'.json')).read_text()) for label in ['A','B']]
parents=json.loads((E/(mode+'-after-parent.json')).read_text())['rows'];progress=json.loads((E/(mode+'-after-progress.json')).read_text())['rows'];assert len(parents)==1 and len(progress)==3
if mode=='notes':
 current=next(r for r in progress if r['id']==step);texts=[n['text'] for n in current['notes']];retainedOriginal=all(n in current['notes'] for n in next(r for r in seed['progress'] if r['id']==step)['notes']);markers=[b['text'] for b in bodies]
 outcome={'result':'PASS' if [r['status'] for r in responses]==[200,200] and retainedOriginal and all(t in texts for t in markers) else 'FAIL','expected':'Two successful ordinary appends retain original notes and both attributed new markers','statuses':[r['status'] for r in responses],'originalRetained':retainedOriginal,'savedMarkers':[t for t in markers if t in texts],'missingMarkers':[t for t in markers if t not in texts],'savedNotes':current['notes'],'ordinaryActorIds':[r['actorId'] for r in responses]}
else:
 statuses=[r['status'] for r in responses];parent=parents[0];winners=[i for i,status in enumerate(statuses) if status==200];winner_matches=len(winners)==1 and parent['status']==bodies[winners[0]]['status'];oneTerminal=(parent['status']=='cancelled' and parent['cancelled_at'] is not None and parent['completed_at'] is None) or (parent['status']=='completed' and parent['completed_at'] is not None and parent['cancelled_at'] is None)
 outcome={'result':'PASS' if len([s for s in statuses if s==200])==1 and all(s in [200,400,409] for s in statuses) and oneTerminal and winner_matches else 'FAIL','expected':'Only one transition from the same in-progress parent succeeds; the other receives a rejected state/conflict response (400/409); single matching terminal timestamp','statuses':statuses,'savedParent':parent,'singleTerminalTimestamp':oneTerminal,'savedStatusMatchesSuccessfulRequest':winner_matches}
after={}
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  after[org,table]=control(['rows',table,org],mode+'-after-'+table+'-'+org)['rows']
comparisonIssues=[]
for key,old in before.items():
 oldMap={r['id']:r for r in old};newMap={r['id']:r for r in after[key]};
 if oldMap.keys()!=newMap.keys():comparisonIssues.append({'table':list(key),'issue':'row identities changed'})
 target_id=step if mode=='notes' else packet;target_table='onboarding_step_progress' if mode=='notes' else 'personnel_onboardings'
 for record_id,row in oldMap.items():
  if record_id not in newMap:continue
  if key==('orgA',target_table) and record_id==target_id:
   allowed={'notes','updated_at'} if mode=='notes' else {'status','completed_at','cancelled_at'}
   
   if {k:v for k,v in row.items() if k not in allowed}!={k:v for k,v in newMap[record_id].items() if k not in allowed}:comparisonIssues.append({'table':list(key),'id':record_id,'issue':'unexpected target fields changed'})
  elif newMap[record_id]!=row:comparisonIssues.append({'table':list(key),'id':record_id,'issue':'untouched captured row changed'})
outcome['otherFullPacketProgressAndSelectedTrainingAndUntouchedTargetFieldsUnchanged']=not comparisonIssues
outcome['unexpectedRowChanges']=comparisonIssues
if comparisonIssues:outcome['result']='FAIL'
if mode=='notes':
 from datetime import datetime
 expected_count=len(next(r for r in seed['progress'] if r['id']==step)['notes'])+2
 attributed=[]
 for label,body,response in zip(['A','B'],bodies,responses):
  matches=[n for n in current['notes'] if n['text']==body['text']]
  valid=len(matches)==1 and matches[0].get('userId')==response['actorId']
  if valid:
   try:valid=datetime.fromisoformat(matches[0]['timestamp'].replace('Z','+00:00')).tzinfo is not None
   except (ValueError,KeyError,TypeError):valid=False
  attributed.append({'label':label,'valid':valid})
 outcome['attribution']=attributed;outcome['expectedNoteCount']=expected_count;outcome['savedNoteCount']=len(current['notes'])
 if not all(x['valid'] for x in attributed) or len(current['notes'])!=expected_count:outcome['result']='FAIL'
save(mode+'-outcome',outcome);print(json.dumps(outcome),flush=True)
