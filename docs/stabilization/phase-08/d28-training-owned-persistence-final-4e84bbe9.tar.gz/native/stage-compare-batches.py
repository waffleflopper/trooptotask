import json,importlib.util,pathlib
p=pathlib.Path(__file__).with_name('compare-saved.py');sp=importlib.util.spec_from_file_location('saved',p);c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
initial=c.read('dated-created-sql')['rows'][0];f=c.read('fixture')['ids'];out=[]
for tag in ['repeat','mixed']:
 w=c.read(tag+'-batch-wire')['structuredContent']['networkRequest'];assert w['status']=='200'
 req=json.loads(w['requestBody']);body=json.loads(w['responseBody']);assert not any('certificateUrl' in x for x in req['records'])
 assert len(body['updated'])==1 and not body['inserted'] and not body['errors']
 rows=c.read(tag+'-annual-record-sql')['rows'];assert len(rows)==1;row=rows[0]
 assert body['updated'][0]=={target:row[source] for target,source in c.keys['completion'].items()}
 assert row['id']==initial['id'] and row['created_at']==initial['created_at'] and row['certificate_url']=='https://example.test/d28-ordinary'
 assert row['completion_date']=='2026-10-07' and row['expiration_date']=='2027-10-07'
 assert row['notes']==('D28 repeated completed batch' if tag=='repeat' else 'D28 mixed completed batch')
 t=c.read(tag+'-expiry-type-sql')['rows'][0];records=c.read(tag+'-expiry-record-sql')['rows']
 assert len(records)==1 and records[0]['personnel_id']==f['personA']
 assert t['exempt_personnel_ids']==([] if tag=='repeat' else [f['personB']]);assert len(body['exempted'])==(0 if tag=='repeat' else 1)
 event=sorted(c.read(tag+'-audit')['rows'],key=lambda a:a['timestamp'])[-1]
 assert event['details']=={'inserted':0,'updated':1,'exempted':0 if tag=='repeat' else 1}
 out.append({'nativeImport':tag,'httpStatus':200,'sameRecordId':row['id'],'certificateOmittedAndRetained':True,'fullTenFieldsMatch':True,'completion':'2026-10-07','expiration':'2027-10-07','exempted':len(body['exempted']),'noBakerExpiryRecord':True,'auditEventId':event['id'],'auditTimestamp':event['timestamp'],'auditDetails':event['details']})
receipt={'status':'PASS','observations':out,'orderingScope':'Native acknowledgements, stored effects, and final audit details. Upsert-before-serial-exemption and late-failure audit suppression reuse current operation tests. No provider-timeline control was armed.'}
(c.r/'batch-comparison.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
