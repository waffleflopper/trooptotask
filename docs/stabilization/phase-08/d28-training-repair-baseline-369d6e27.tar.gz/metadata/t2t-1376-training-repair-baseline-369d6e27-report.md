# Training repair baseline at 369d6e27

The baseline is FULLY CLOSED. Both selected native cases reproduced a defect. This report does not claim application acceptance.

The tested revision is `369d6e27a14396615204e476b1e432de4fb71071`. Its tree is `a0c82781f6bd95cb50df0d5df5e146f89b4b3fba`.
The candidate is `418ecb5c847885ec1137597600dd976c48bb19909860feb798884c507c0ec21f`.
The sole session was worker 1, session `b55a7945-4a97-437e-b189-13d433abd577`, on `http://127.0.0.1:45649`.
It used Node 24.21.0 and Chromium 152.0.7977.82. All 5,346 tracked input hashes remained unchanged.

## Native observations

| Case | Result | Expected | Actual |
| --- | --- | --- | --- |
| PB01 existing View edit failure | ISSUE | Retain the edited name and column order, show an error, and allow explicit retry. | One controlled `training-views` PUT 503 closed the form and lost the draft. The saved View remained exact. |
| PB02 retired record editor | ISSUE | Keep the Organization B page quiet when a retired Organization A save finishes. | The real `personnel-trainings` POST returned 200 and persisted A's record while held. Native history back admitted B before release. Release showed `Training record saved` on B. B's originals remained exact. |

PB01's healthy View creation and reload established the stable saved ID and column order before the failing edit.
The temporary View was `d9bd37d5-db38-4ee8-9c9e-9698a4a3308f`. It was removed through the native controls.
PB02's temporary completion was `9684e5e5-d799-4da0-ac4b-147e87da038f`.
The completion used October 6, 2026 and Notes `D28 PB02 held 369d6e27`.
Returning to A and reloading acknowledged that exact saved record. Configure controls then removed it with a real DELETE 200.

An unnecessary Escape canceled PB02's first unsaved outer dialog after the date picker had already closed.
No control was armed and no save was attempted at that point. The same selected form was reopened. The raw cancellation note is retained.
No additional native cases or malformed variants were run. The twelve later persistence families remain UNRUN in this baseline.
The lost PB01 draft prevented an in-form retry. A successful repaired retry is not claimed here.

## Restoration and closure

Both pages' inspected network, feedback and export controls were unarmed before cleanup.
`clean-seeds` exited 0. The final read compared only eight selected business sets across A and B.
All fields of all eleven originals were exact, with no extra rows. Both UI-created rows were absent.
The final doctor passed with the same candidate. The original freeze and recovered freeze both passed.

Supported `verify:app cleanup --worker 1` exited 0 at 04:56:28 UTC before the restart interruption.
The app restart interrupted final receipt publication. Recovery inspected actual resource state and preserved the completed native proof.
Recovery did not launch an app, drive a case, rerun doctor, query a provider, run a test or build, or repeat cleanup.

All fourteen bound owned processes were absent. All ten owned ports refused connections.
The five owned containers, one network, two volumes, worker directory and recorded Chromium temporary paths were absent.
All forty-one preexisting container ID, name and state records were exact.
All seven preexisting network records and seventeen preexisting volume records were exact.
No protected database or preexisting resource was changed during recovery.

## Artifact limits

The raw captures remain under `.verification/evidence/verify-trooptotask/d28-training-repair-baseline-369d6e27`.
`recovery-inventory.json` binds every file except itself by byte size and SHA-256.
The named cache receipt binds that inventory and this report.
The inherited six-value exact private scan passed before private configuration was removed.
The recovery pattern scan found no credential patterns in the captured files. This statement does not cover historical tool transcripts.
This is recovered worker proof. The parent must independently accept the expanded artifacts and closure before integration.

The Prove It Works principle changed the closure decision. I checked actual processes, sockets and Docker identities instead of trusting the cleanup receipt alone.
