import json,subprocess,pathlib
base=pathlib.Path('.verification/evidence/verify-trooptotask/d21-operations-final')
for role in ['viewer','platformInactive','platformBilling']:
 for target in ['admin/users','admin/organizations','admin/access-requests']:
  label='denied-'+role+'-'+target.split('/')[-1]
  r=subprocess.run(['python3','.verification/d21-drive.py','control',label,'actor',role,target],capture_output=True,text=True)
  if r.returncode: print(label,r.stdout,r.stderr,flush=True);raise SystemExit(r.returncode)
  j=json.loads((base/(label+'.json')).read_text());page=j['pageId']
  s=subprocess.run(['python3','.verification/d21-drive.py','verify',label+'-snapshot','tool','take_snapshot',json.dumps({'pageId':page})],capture_output=True,text=True)
  print(label,'page',page,'snapshot',s.returncode,' '.join(s.stdout.splitlines()[:3]),flush=True)
  if s.returncode: raise SystemExit(s.returncode)
