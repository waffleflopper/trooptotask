import * as core from '../../../scripts/verification/core.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
const e=path.join(core.repository,'.verification/evidence/verify-trooptotask',process.env.D15_EVIDENCE);
const entries=[];
for(const file of await core.files()) {
 const map=file==='.agents/skills/verify-trooptotask/SKILL.md'||(file.startsWith('.agents/skills/verify-trooptotask/features/')&&file.endsWith('.md'));
 if((file.endsWith('.md')&&!map)||path.basename(file).startsWith('.env'))continue;
 try{entries.push({path:file,sha256:createHash('sha256').update(await fs.readFile(path.join(core.repository,file))).digest('hex')});}
 catch(error){if(error.code!=='ENOENT')throw error;entries.push({path:file,deleted:true});}
}
const {stdout:revision}=await core.execute('git',['rev-parse','HEAD']);
const candidate=await core.candidate();
await fs.writeFile(path.join(e,'prelaunch-input-hashes.json'),JSON.stringify({revision:revision.trim(),candidate,entries},null,2)+'\n');
const args=['run','--silent','verify:app','--','launch','--worker','1'];
await fs.writeFile(path.join(e,'launch-command.json'),JSON.stringify({command:['npm',...args],nonsecretOverrides:{TMPDIR:process.env.TMPDIR}},null,2)+'\n');
try {
 const r=await core.execute('npm',args,{cwd:core.repository,timeout:420000,maxBuffer:16*1024*1024});
 await fs.writeFile(path.join(e,'launch.json'),r.stdout); await fs.writeFile(path.join(e,'launch-stderr.log'),r.stderr);
 const state=JSON.parse(r.stdout);if(state.candidate!==candidate)throw new Error('Launch candidate mismatch');
 console.log(JSON.stringify({revision:revision.trim(),candidate,inputs:entries.length,launch:state}));
}catch(error){await fs.writeFile(path.join(e,'launch-error-stdout.log'),error.stdout||'');await fs.writeFile(path.join(e,'launch-error-stderr.log'),error.stderr||'');throw error;}
