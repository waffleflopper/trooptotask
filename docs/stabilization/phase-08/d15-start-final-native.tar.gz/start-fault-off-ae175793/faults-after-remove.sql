SET statement_timeout='10s'; SET lock_timeout='3s';
SELECT json_build_array(json_build_object('name','t2t_d15_start_1a5b0fbc_62d0e8a5_save', 'table','onboarding_step_progress',
 'function_exists',to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_save()') IS NOT NULL,
 'function_marker',obj_description(to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_save()'),'pg_proc'),
 'function_oid',to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_save()')::oid::text,
 'trigger',(SELECT json_build_object('marker',obj_description(t.oid,'pg_trigger'),'function_oid',t.tgfoid::text)
 FROM pg_trigger t WHERE t.tgrelid='public.onboarding_step_progress'::regclass AND t.tgname='t2t_d15_start_1a5b0fbc_62d0e8a5_save' AND NOT t.tgisinternal)),json_build_object('name','t2t_d15_start_1a5b0fbc_62d0e8a5_delete', 'table','personnel_onboardings',
 'function_exists',to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete()') IS NOT NULL,
 'function_marker',obj_description(to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete()'),'pg_proc'),
 'function_oid',to_regprocedure('public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete()')::oid::text,
 'trigger',(SELECT json_build_object('marker',obj_description(t.oid,'pg_trigger'),'function_oid',t.tgfoid::text)
 FROM pg_trigger t WHERE t.tgrelid='public.personnel_onboardings'::regclass AND t.tgname='t2t_d15_start_1a5b0fbc_62d0e8a5_delete' AND NOT t.tgisinternal)));
