import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';

const raw = process.argv[2] ?? '/home/waffleflops/.cache/t2t-1376-rating-owner/.verification/evidence/verify-trooptotask/d28-rating-feedback-repair';
const read = async (name) => JSON.parse(await fs.readFile(path.join(raw, name), 'utf8'));
const text = async (name) => fs.readFile(path.join(raw, name), 'utf8');
const checks = [];
const check = (name, actual, expected) => { assert.deepEqual(actual, expected, name); checks.push(name); };
const rows = async (name, count) => { const v = await read(name); check(`${name}: count`, v.count, count); check(`${name}: row length`, v.rows.length, count); return v.rows; };
const sorted = (v) => [...v].sort((a, b) => a.id.localeCompare(b.id));
const fields20 = (v, name) => v.forEach(row => check(`${name}: full20 ${row.id}`, Object.keys(row).length, 20));
const orgA = 'ca319b3f-a411-43dc-a2fc-79605fbdbb23';
const orgB = '269887ea-2862-47b8-b8cf-1dfd779bc52b';
const bUrl = `http://127.0.0.1:42185/org/${orgB}/evals`;
const witness = 'ab87a596-2899-4286-b8a0-43f475970f9b';
const target = '0617f129-9423-4ad3-89d4-349cda31b238';
const a9 = await rows('original-A9.json', 9);
const b1 = await rows('original-B1.json', 1);
fields20(a9, 'A9 originals'); fields20(b1, 'B1 original');
const afterCreate = await rows('A-after-create.json', 10);
check('create preserved every original A9 field', sorted(afterCreate.filter(v => v.id !== witness)), sorted(a9));
const created = afterCreate.find(v => v.id === witness);
check('native creation success feedback', (await read('create-feedback-state.json')).entries, [{type:'success',text:'Rating entry added'}]);
check('created witness identity/type/report', [created.id, created.organization_id, created.eval_type, created.report_type], [witness, orgA, 'OER', 'CR']);
check('created witness period', [created.rating_period_start, created.rating_period_end], ['2026-10-05', '2026-10-31']);
fields20([created], 'UI-created witness');
const saveFailure = await rows('active-save-failure-provider.json', 1);
check('active failed PUT did not alter witness', saveFailure, [created]);
for (const [prefix,method,error,draft] of [
  ['active-save','PUT','Failed to update rating entry','D28 current retry draft'],
  ['DELETE-current','DELETE','Failed to delete rating entry. Try again.','D28 current deletion retry draft'],
  ['POST-current','POST','Failed to submit deletion request.','D28 current approval retry draft']
]) {
  check(`${prefix}: actual scoped synthetic503`, (await read(`${prefix}-failure-network.json`)).calls.map(v=>[v.method,v.status]), [[method,503]]);
  check(`${prefix}: useful current error feedback`, (await read(`${prefix}-failure-feedback.json`)).entries, [{type:'error',text:error}]);
  const snapshot=(await read(`${prefix}-failure.json`)).structuredContent.snapshot;
  const nodes=[];function visit(v){nodes.push(v);for(const child of v.children??[])visit(child);}visit(snapshot);
  check(`${prefix}: current editor draft retained`, nodes.some(v=>v.role==='textbox'&&v.name==='Notes'&&v.value===draft),true);
  check(`${prefix}: current editor stays open`, nodes.some(v=>v.role==='dialog'&&v.name==='Edit Rating Entry'),true);
  check(`${prefix}: retry enabled`,nodes.some(v=>v.role==='button'&&v.name==='Save'&&v.disabled!==true),true);
}
const retry = (await rows('active-save-retry-provider.json', 1))[0];
check('active PUT retry persisted draft', retry.notes, 'D28 current retry draft');
check('active PUT retry retained identity/creation', [retry.id, retry.created_at], [created.id, created.created_at]);
const committed = (await rows('PUT-committed-A-provider.json', 1))[0];
check('held PUT committed actual intent in A', committed.notes, 'D28 held repaired A delivery');
check('held PUT retained identity/creation', [committed.id, committed.created_at], [created.id, created.created_at]);
fields20([committed], 'held PUT provider row');
const putBody = await read('PUT-held.network-response');
const snake = Object.fromEntries(Object.entries(putBody).map(([k, v]) => [k.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`), v]));
check('held PUT actual wire response equals full20 provider row', snake, committed);
const putIntent = await read('PUT-held.network-request');
check('held PUT wire request intent', [putIntent.id, putIntent.notes], [witness, committed.notes]);
const a11 = await rows('deletion-original-A11.json', 11);
const b2 = await rows('deletion-original-B2.json', 2);
fields20(a11, 'deletion A originals'); fields20(b2, 'deletion B originals');
check('later B2 contains exact untouched original B1', b2.find(v => v.id === b1[0].id), b1[0]);
const targetOriginal = a11.find(v => v.id === target);
for (const name of ['DELETE-current-failure-provider.json', 'DELETE-held-A-source.json', 'DELETE-A-reloaded-source.json', 'POST-current-failure-provider.json', 'POST-held-A-source.json']) check(`${name}: full20 target unchanged`, await rows(name, 1), [targetOriginal]);
for (const name of ['DELETE-current-failure-request-none.json', 'DELETE-held-A-requests-none.json', 'DELETE-after-release-requests-none.json', 'POST-current-failure-request-none.json', 'UI-witness-request-none.json']) await rows(name, 0);
const wireCases = [
  ['create-wire-business.json', 'POST', '200'],
  ['active-save-retry-wire-business.json', 'PUT', '200'],
  ['PUT-held-wire-business.json', 'PUT', '200'],
  ['DELETE-held-wire-business.json', 'DELETE', '202'],
  ['POST-current-DELETE-wire-business.json', 'DELETE', '202'],
  ['POST-retry-DELETE-wire-business.json', 'DELETE', '202'],
  ['POST-held-wire-business.json', 'POST', '201'],
  ['owner-witness-DELETE-wire-business.json', 'DELETE', '200'],
  ['owner-journal-DELETE-wire-business.json', 'DELETE', '200']
];
for (const [name, method, status] of wireCases) { const v = await read(name); check(`${name}: actual method/status`, [v.method, v.status], [method, status]); check(`${name}: header projection`, [v.requestHeaders, v.responseHeaders], ['[OMITTED HEADER PROJECTION]', '[OMITTED HEADER PROJECTION]']); }
check('actual held DELETE202 body', await read('DELETE-held.network-response'), {requiresApproval: true});
for (const [label, base, count, status] of [['PUT', b1, 1, 200], ['DELETE', b2, 2, 202], ['POST', b2, 2, 201]]) {
  const back = await read(`${label}-native-back.json`);
  check(`${label}: native Back actually admitted B`, back.structuredContent.pages.find(v => v.id === 2).url, bUrl);
  check(`${label}: held before admitted-B delivery`, (await read(`${label}-held-B-network.json`)).held, true);
  const expected = sorted(base);
  for (const name of [`${label}-B-before-release-provider.json`, `${label}-B-after-release-provider.json`, `${label}-B-reloaded-provider.json`]) { const actual = await rows(name, count); fields20(actual, name); check(`${name}: all fields exact`, sorted(actual), expected); }
  for (const name of [`${label}-B-before-release.txt`, `${label}-B-immediate.txt`, `${label}-B-reloaded.txt`]) { const snapshot = await text(name); check(`${name}: canonical B route`, snapshot.split('\n')[0].includes(bUrl), true); check(`${name}: B count`, snapshot.includes(`status "${count} of ${count} shown"`), true); check(`${name}: original foreign workspace`, snapshot.includes('SPC Foreign'), true); check(`${name}: view-only`, /button "(?:Add Entry|Delete|Save)"|dialog "Edit Rating Entry"|alertdialog "Delete this entry\?"/.test(snapshot), false); check(`${name}: no A witness/draft`, /D28 held repaired A delivery|Native Senior|Native Rater|Deletion orgA/.test(snapshot), false); }
  const png = await fs.readFile(path.join(raw, `${label}-B-immediate.png`));
  check(`${label}: immediate PNG magic`, [...png.subarray(0, 8)], [137,80,78,71,13,10,26,10]);
  check(`${label}: observer no success/error feedback`, (await read(`${label}-B-immediate-feedback.json`)).entries, []);
  check(`${label}: response released`, (await read(`${label}-release.json`)).released, true);
  const network = await read(`${label}-delivered-B-network.json`);
  check(`${label}: delivered response status`, [network.held, network.calls.at(-1).status], [false, status]);
  check(`${label}: explicit network restore before reload`, (await read(`${label}-network-explicit-restore.json`)).restored, true);
  check(`${label}: explicit feedback restore before reload`, (await read(`${label}-feedback-explicit-restore.json`)).restored, true);
}
const nativeList = (await read('DELETE-after-release-network-list.json')).structuredContent;
check('retired DELETE202 native request list is complete', [nativeList.pagination.totalPages,nativeList.pagination.hasNextPage], [1,false]);
check('retired DELETE202 native request list contains no approval POST', nativeList.networkRequests.some(v=>v.method==='POST'&&new URL(v.url).pathname.endsWith('/api/deletion-requests')), false);
const pending = (await rows('POST-held-A-pending-request.json', 1))[0];
check('approval pending full13', Object.keys(pending).length, 13);
check('actual held POST201 full13 wire equals persisted request', await read('POST-held.network-response'), pending);
check('pending real A request survived departure unchanged', await rows('POST-after-release-A-pending-request.json', 1), [pending]);
check('approval captured target identity/scope', [pending.resource_id, pending.organization_id, pending.status], [target, orgA, 'pending']);
const intent = await read('POST-held.network-request');
check('approval captured full request intent', intent, {resourceType: pending.resource_type,resourceId:pending.resource_id,resourceDescription:pending.resource_description,resourceUrl:pending.resource_url});
const cancelHttp = await read('request-cancel-ordinary-http.json');check('ordinary requester cancellation actual HTTP200', cancelHttp.status, 200);check('ordinary cancellation actual body', JSON.parse(cancelHttp.body), {success:true});
check('cancelled terminal history retained before seed cleanup', await rows('cancelled-history-before-seed-cleanup.json',1), [{...pending,status:'cancelled'}]);
check('provider cancellation changed only status', await rows('request-cancelled-provider.json',1), [{...pending,status:'cancelled'}]);
check('final A9 all20 originals exact', sorted(await rows('original-A9-before-clean-seeds.json',9)), sorted(a9));
check('final B2 all20 originals and sentinel exact', sorted(await rows('original-B2-before-clean-seeds.json',2)), sorted(b2));
await rows('owner-witness-absent.json',0); await rows('owner-journal-target-absent.json',0);
for (const org of ['A','B']) { const initial = await read(`journal-files-${org}-before-cleanup.json`); const final = await read(`journal-files-${org}-final-before-cleanup.json`); check(`${org}: registered file bytes/hash unchanged before cleanup`, final, initial); const removed = await read(`journal-files-${org}-after-clean-seeds.json`); check(`${org}: exact journal file absent after cleanup`, [removed.files[0].path, removed.files[0].present], [initial.files[0].path,false]); check(`${org}: registered record absent after cleanup`, removed.tables.counseling_records, []); }
for (const name of ['hooks-page2-network-final.json','hooks-page2-feedback-final.json','hooks-page3-network-final.json','hooks-page3-feedback-final.json']) check(`${name}: disarmed`, (await read(name)).armed,false);
check('all journal seed cohorts cleaned', (await read('clean-seeds.json')).cleaned,true);
for (const name of ['Rating-A-after-clean-seeds.json','Rating-B-after-clean-seeds.json','request-history-after-clean-seeds.json','B-journal-request-after-clean-seeds.json']) await rows(name,0);
check('final doctor PASS', (await read('doctor-final.json')).status,'PASS');
check('actual owned cleanup PASS/cleaned', [ (await read('owned-cleanup.json')).status, (await read('owned-cleanup.json')).phase], ['PASS','cleaned']);
const source = await read('source-state-final-closed.json');
check('frozen source revision/tree/candidate', [source.revision,source.tree,source.candidate], ['3f3517facbc3fc7cba5df7fde686935f5d3fccf2','d966ed1e139725c1d14c10f11adca5ed62841f4b','780dc629e1647f3de2766953e7db235e975d65960eeac7d036923c9c247f8870']);
check('clean checkout/closed worker', [source.workingStatus,source.privateWorkerPathPresent,source.closedOnlyAfterCleanupTerminalExit], ['',false,0]);
const before = await read('input-manifest-before.json'); const after = await read('input-comparison-final-closed.json');
check('5092 exact frozen input hashes', after.entries, before.entries);check('input manifest count',after.entries.length,5092);check('no added/missing/changed executable/driving input', [after.added,after.missing,after.changed],[[],[],[]]);
console.log(JSON.stringify({status:'PASS',raw,checks:checks.length,assertions:checks,limits:['PNG pixels and screenshot-before-snapshot execution order require human review of originals; this checker checks PNG format only.','Feedback recorder captures success/error only; info/acknowledgement absence requires immediate native PNG and snapshot review.','Native synthetic503 controls intercept before provider dispatch; they do not prove provider500/rejection behavior.','Offline checker never drives app or changes source/provider.']},null,2));
