import hashlib, json, subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
record = json.loads((root / 'frozen-inputs.json').read_text())
repository = Path.cwd()
copy = Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1/app')
all_paths = set(subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().split('\0')) - {''}
def included(name):
    authoritative = name == '.agents/skills/verify-trooptotask/SKILL.md' or name.startswith('.agents/skills/verify-trooptotask/features/') and name.endswith('.md')
    return not Path(name).name.startswith('.env') and (not name.endswith('.md') or authoritative)
paths = sorted(name for name in all_paths if included(name))
assert paths == [item['path'] for item in record['inputs']]
verdicts = []
for base in [repository, copy]:
    candidate = hashlib.sha256()
    for item in record['inputs']:
        name = item['path']
        path = base / name
        candidate.update(name.encode() + b'\0')
        if path.exists():
            value = path.read_bytes()
            assert len(value) == item['bytes'] and hashlib.sha256(value).hexdigest() == item['sha256'], name
            candidate.update(value + b'\0')
        else:
            assert item.get('deleted'), name
            candidate.update(b'DELETED\0')
    assert candidate.hexdigest() == record['candidate']
    verdicts.append({'directory': str(base), 'inputs': len(paths), 'candidate': candidate.hexdigest(), 'allInputHashesUnchanged': True})
(root / 'final-input-verification.json').write_text(json.dumps(verdicts, indent=2) + '\n')
print('CURRENT and OWNED COPY complete input sets/hashes/digests PASS')
