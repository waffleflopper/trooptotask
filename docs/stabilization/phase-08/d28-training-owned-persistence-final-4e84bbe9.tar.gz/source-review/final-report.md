# D28/#1376 Training source and baseline acceptance

The complete declared deliverable is acceptable for the selected current native integration after one narrative comment deletion. I found no demonstrated behavior, persistence, authority, or metadata defect that requires a source repair before native verification. This is scoped source, archived artifact, and verification-selection acceptance. It is not complete PR acceptance.

| Review axis | Verdict | Findings |
| --- | --- | --- |
| Standards | GO at source scope | No demonstrated correctness, security, architecture, performance, or test-quality defect. |
| Spec | GO at source/baseline/selection scope | The two-port cutover and retained contracts match the settled design. Current integration remains unproved until the selected native run. |
| Comment Sicko | One deletion required | Delete the new narrative comment at `src/features/training/server/trainingCompletionOperations.server.ts:165`. No code reshape or MUST KILL flag. |

I performed the Standards and Spec passes separately as one fresh sequential reviewer. No delegated-review independence or model diversity claim applies. I read the full Poteto skill and its inline Principles index, the Investigation playbook, applicable leaf principles, project engineering/stabilization contracts, testing strategy, DoD, and relevant review roles. The parent prohibited fanout and all application/shared edits. I wrote only this ignored scratch directory. I did not launch an app, browser, build, test suite, database, or native session, and did not use GitHub, network, connectors, or private worktrees.

## Candidate and complete scope

The branch is `stabilization/1376-training-owned-persistence`, based at HEAD `c911e0a114e1425541fa91a7b66db04bd904dc22`. I reviewed all 76 paths in the parent's `root-review-scope.json`: 63 tracked changes and 13 untracked paths. The scope contains 66 existing text files, seven deleted text paths, and three binary archives. The full tracked diff is 159,857 bytes. I read the changed tracked contents, current new files, deleted implementations/tests, root Person editor repair/test, affected recipe/docs hunks, and all three archive packages. Unrelated inherited portions of large mixed ledgers were outside the semantic review.

`entry-inventory.json` identifies every scoped path with byte count and SHA-256, or a deleted marker. `exit-inventory.json` proves the same 76 paths stayed identical through this review. `snapshot-stability.json` records zero entry/exit differences. The entry inventory SHA-256 is `5af2de587387ab4e169fb1a6da511341a87237b0314a972f018e1c8a3ebd2a75`; the full tracked diff SHA-256 is `c29173ff3a65999dd16c6157876bb503e77139026c1101359b8ffa6f8b563895`.

The implementation's executable candidate remains `52ef5289737349d6867346bf488184680d3218abb7439448c3dcf7ca54377202`. The three root status-paragraph changes describe pending work. They do not create native proof. I compared the 59 stage source hashes and 59 protected UI/store/export/render hashes to their original inventories with no differences. The Person repair retains its original source binding. See `source-original-binding-verification.json`.

## Standards findings

The new Catalog adapter and Completion adapter capture the admitted ordinary request client and canonical Organization ID. The interfaces at `src/features/training/contracts.ts:267` and `:307` expose exactly 17 Catalog and ten Completion methods. Consumer contexts request narrow Picks. I found no caller-selected Organization, generic table/filter/result method, admin acquisition, or fallback on these ordinary ports.

The mapping preserves the complete saved shapes and existing spelling: 20 Type keys, seven View keys, and ten Completion keys. Type metadata retains `organization_id` and `created_at`, with no invented `updated_at`. View metadata retains `createdBy`, `createdAt`, `updatedAt`, and `organization_id`. Completion metadata retains `organization_id`, `created_at`, and `updated_at`. Present NULL arrays normalize to empty arrays and present NULL flags to false; missing properties stay absent. Timing, import, and rank-reference NULL values retain their existing meaning. Adapter tests use literal expected keys/values and installed SDK behavior rather than importing production mapping as an oracle.

I traced the operations and caller wiring in the changed routes, Dashboard, readiness, Personnel export, Starter configuration, settings rank references, and request factories. `ordinary-port-callers.txt` records 109 matching lines; `purpose-and-direct-training-tables.txt` records 47 lines. The removed Entity and generic Training interface/helper symbol search is empty, with its successful no-match exit recorded in `caller-search-receipts.json`. The client store table names and separately owned support/audit/deletion/archive providers are expected retained uses, not incomplete ordinary cutovers. The generic facade for later owners remains an explicit remainder.

Create on an existing completion pair preserves the pair ID and date behavior. Direct patches preserve the settled malformed-known-field behavior. Completed batch upsert occurs at `trainingCompletionBatch.server.ts:123`, before the serial exemption rechecks and patches at `:136`, with the final audit after successful completion. An exemption failure can leave completed writes and earlier exemption effects intact while preventing later effects and final audit. The implementation and tests preserve this partial-effect contract and omitted existing certificate behavior. No transaction or migration was added.

Workspace and report assembly retain seven parallel source branches. `trainingReportsQuery.server.ts:68` uses Promise.all rather than serial request waterfalls. Readiness admits the Person before loading Training facts. Personnel export consumes the four ordinary facts and retains an empty Training sheet for Training-none. The paging adapters discard accumulated data on a later-page error instead of presenting a truncated success. I reviewed the read volume and parallel structure; I did not measure or claim a performance improvement.

Onboarding Training references remain a separate admitted path, with lazy privileged acquisition, 500-row paging, 100-Person chunks, four concurrent chunks, and joined Organization/Group scope. Approved deletion, type-name audit, support count, and raw archive retain independent purpose authority. The ordinary adapters do not acquire those privileges.

The root Person editor repair at `PersonTrainingEditor.svelte:96` reports save errors only for the current component lifetime and Person. Its effect preserves same-Person dirty drafts while refreshing saved data. The interaction tests prove draft retention, retry payload, closed lifetime suppression, Person switch behavior, and Cancel restoration at the component boundary. The existing 47-test repair evidence and native 503/retry/reload/Cancel artifact remain separately bound to their original candidate. I found no reason to repeat the retired #1562 eight-failure repair acceptance.

The new provider tests, memory fixtures, batch/error tests, and exact authority test prove independently stated boundary behavior. The three exact feature test-support registrations and authority registration do not introduce a cycle or governance allowance. I found no tautological or harmful duplicate test that requires pruning in this scope.

## Comment Sicko finding

At `src/features/training/server/trainingCompletionOperations.server.ts:165`, delete:

```ts
// Direct patches retain the existing unvalidated known-field behavior.
```

The nearby update construction already expresses the accepted behavior. This is narration about our own code and does not meet the keep list. Delete the comment only; changing the malformed-known-field semantics would violate the settled contract. This hygiene finding does not block native integration and does not invalidate behavior evidence.

I inspected 42 scoped leading comment blocks or lines. One new comment needs deletion; 41 unchanged blocks or lines were skipped under the stated scope rule. Actual application comment deletions are zero because this review is read-only. MUST KILL flags are zero. Added suppressions are zero. The touched-file recommendation names only the Completion operations file. `comment-sicko-receipt.json` records these counts. Counts describe the scoped leading-comment scan, not every lexical comment inside all files.

## Archive integrity and actual artifact acceptance

I expanded all three packages into fresh scratch directories and checked complete exact relative-path sets, uniqueness, every payload size, and every SHA-256. All 2,271 payloads passed. Their combined expanded payload size is 50,673,933 bytes. `archive-entry.json`, `archive-verification.json`, and the three path lists are the receipts.

| Archive | Compressed bytes | Payloads | SHA-256 |
| --- | ---: | ---: | --- |
| `d28-training-persistence-baseline-c911e0a1.tar.gz` | 11,261,465 | 1,886 | `b1596733109432ec15f79030a0f31bbc44de9439433d3ecaeaead4dfa2be4fcf` |
| `d28-training-person-save-focused-93ab5146.tar.gz` | 985,557 | 101 | `4c5951c1e1a852b64bc1cd5b809ef70d76c8b20efdf3d9ff490d04fda68bd4ec` |
| `d28-training-persistence-supplement-4f9ff79a.tar.gz` | 4,064,710 | 284 | `bd9c3fabe930a50b081e370a7633e653484c2c927d2d7fc803ad6061a96e0f97` |

I read the actual relevant wire bodies, feedback snapshots, saved rows, comparisons, workbook XML, PDF, selected screenshots, and session closure receipts. I did not accept report prose or embedded PASS booleans as the only evidence. My bounded script independently parsed all 22 XLSX files. All five supplement books match their recorded reader cells. It derived the Dense 1,990 affected rows in exact order from literal fixture rules, labels, IDs, and dates without importing production report calculations. Status counts are 730 Not Done and 315 in each of the four expiration categories. It also checked normal, Short, empty View, and zero-People summaries as distinct cases.

The focused Person artifacts show a failed dispatch with the saved row unchanged, visible error with draft notes/certificate retained, a real 200 retry retaining the same ID/dates, reload, and restoration of every original value except `updated_at`. The supplement's actual held/failure/retry snapshots retain the previously loaded page and show the 503 feedback. The A-to-B snapshot after delayed A release still shows only Organization B's one Person and Foreign Private Training. These remain historical client/control observations, not observations of the new ports.

I independently compared all fields of the supplement's eight original row sets and two original Groups. All 2,081 journaled temporary IDs are absent from the archived post-cleanup rows; archived journals are empty. The actual closed-session receipts support closure. The original baseline's cleanup/restoration limitations remain separate and are not overwritten by later supplement restoration.

The five-page Dense Letter landscape PDF SHA-256 is `d5c2f24243be02dd3507119e51020379daa29e40f7198ea8e92502a18958b5e2`. All five fresh rasters exactly match both archived raster sets. I inspected every Dense page and the continuation header crops at original detail. Title, Organization, date/horizon context, continuation table headers, final Type, total/N/A, and margins are intact. The former page-five header FAIL was an observation error. Its original report remains unchanged, with the separate correction receipt preserved. I made no CSS change or app/session run. This result covers that exact five-page input, not every print variant.

The supplement's 253 original baseline payloads and 28 adjudication payloads remain byte-identical to their independent inventories. `artifact-content-verification.json`, `pdf-render-verification.json`, and `source-original-binding-verification.json` contain the checks and exact hashes. `artifact-review-scope.json` names 13 archived PNGs inspected at original detail and one additional fresh render inspected. All 82 archived PNGs have integrity coverage; 69 did not receive fresh visual inspection. I did not semantically interpret every one of the 2,117 archived JSONs or every historical log.

I scanned 2,169 text files and 317 workbook XML/rels members for JWT and token URL patterns, with zero matches. `sanitization-scan.json` records the scope. This is not exhaustive secret detection, all-pixel OCR, or confidential-data review of every screenshot. Synthetic names, IDs, and loopback ports remain. Earlier #1550/#1562 archives were not newly extracted; their accepted original bindings are reuse context only.

## Proof reuse and pending current verification

The original 64-group baseline retains 36 PASS, one product FAIL, three control FAIL, and 24 UNRUN. The focused Person repair and supplement do not rewrite those outcomes into one new native PASS. Baseline `c911e0a1`/`590fe5b7`, Person `93ab5146`, and supplement `4f9ff79a` keep their original candidate, actor, input, day, wire, source, and resource bindings. The baseline's terminal native-control failure, Offline mandatory-allowlist failure and associated lazy-module UNRUN, deferred rank edges, Starter's lack of native UI, OS print/signout limits, and other stated unrun cases remain honest.

I read the implementation's actual focused logs. The original run records 29 suites/250 PASS plus two fixture failures; the correction records three suites/21 PASS. Operations record four suites/45 PASS. Adapters/request/source record four suites/30 PASS, including 13 adapter tests. Authority records one PASS. Types record zero errors and zero warnings. Governance retains 157 findings without regression, and its rule tests record two suites/22 PASS. Touched lint/format/diff receipts pass. These runs overlap; I did not sum them or invent one green aggregate. Earlier failed fixture assumptions, the accepted exemption bug correction, and the repaired dependency cycle remain in the logs. I ran none of these suites anew.

The proposed six-part native selection is sufficient and proportionate for the changed request/provider wiring. CRUD with real response/SQL comparison, Completion identity/nullable/certificate/batch effects, ordinary scoped/none/foreign actors, paged detail/filter/full workbook, Dense and empty distinctions, and one pass through affected reverse integrations cover integration that source/provider tests cannot establish. Dense comparisons must check exact IDs/dates beyond the provider page, not just counts, and use independently derived current fixture expectations.

For the intentional provider rejection, use a duplicate Type name during selected Catalog CRUD and then a real correction/retry. The existing Organization/name unique constraint in `supabase/migrations/20260413001158_remote_schema.sql:2856` supplies a concrete ordinary provider rejection. That proves Catalog error-to-UI/retry on the new path. Repeating the unchanged controlled frontend 503 solely because the ports changed is unnecessary; retain its original Person/control proof and the Completion installed-SDK/write/partial-effect error tests. This refinement requires no source change or wholesale replay.

Reuse unchanged editor/store/render/print/export layout/control proof at exact original source/input bindings. Repeating all 64 cases or every paper/theme variant would not add distinct persistence coverage. A new commit, review round, or session alone does not invalidate prior proof. If the selected run exposes a failure, rerun that failure and only adjacent checks justified by the repair.

Current native execution, production build, required exact-head CI, and hosted review/release gates are still pending. No exact-head CI, merge readiness, current-native PASS, or complete issue acceptance is claimed. After Training, #1376 still includes separately owned ordinary Onboarding and residual settings cutovers and the final generic-facade caller/removal census. D29/D30 are excluded. No migration is proposed or needed here.

## Applied principles and handoff

Migrate callers then delete legacy APIs drove the reverse-caller census and same-wave facade removal review. Type system discipline and boundary discipline drove the exact method counts, narrow Picks, captured request authority, and saved NULL/omission checks. Test behavior, not implementation drove the literal-key, independent workbook, failure-state, and partial-effect review. Prove it works drove complete package integrity and kept new native/build/CI proof pending. Explain the number kept original outcomes, overlapping test runs, Dense row totals, and visual-review limits separate. Minimize reader load favored the existing small provider/mapping structure and produced no optional abstraction or style churn. I applied Unslop to this report.

The single worker's terminal handoff releases source/shared-file ownership to root. Root can delete the accepted comment, record the small final difference, and proceed with the selected current native integration under the repository workflow.
