# #1504 final acceptance v1 (owned browser, PR1511)

## Verdict

**#1504 has one blocker.** Print brief PDF capture failed on this candidate, so no print journey could produce a PDF. The native Print brief click does invoke print (`beforeprint` count 1). `print save` then blocks before rendering, on the first call and on the one bounded retry. Every other required journey passed against independently counted fixture facts.

The defect is in the integrated verification transport, not in product code. It still blocks the acceptance criterion "Print brief produces a clean printout with the filters stated (verify-app evidence)". Two visual findings and one keyboard finding are listed below. None of them blocks acceptance.

## Run identity

- HEAD `2e3aea52ad01e33e173b769f285b0ab6103547d7`, base `a59c6c92`.
- Worker 1, candidate `3c5c3154c89d03781d701ad70518b6338395baa25aa55937c57d06bea11ee787`.
- Origin `http://127.0.0.1:33931`, session `b4853547-1f21-457b-9c3d-325985de2f67`, Chromium 152.0.7977.82 Arch Linux.
- Doctor PASS before driving (receipt `000-doctor`) and at the end (`429-doctor-final`): same candidate, revision and session.
- Org A is `6caba7d8…` and Org B is `42da95d7…`.
- Fixture day 2026-10-04. Original completion 2026-09-27 → 2027-09-27. Expired 2024-10-04 → 2025-10-04. Warning 2025-10-19 → 2026-10-19 (15 days). Horizon ends: 90 days → 2027-01-02, 30 → 2026-11-03, 180 → 2027-04-02.
- Starting state: viewport 1905×2053, `data-theme` light, `mode-watcher-mode=system`, no `theme` localStorage key, no sidebar cookie. `trainingConfigure` had no preference or progress rows.

All artifacts are under `.verification/evidence/verify-trooptotask/1504-final-v1/accept/`:

- `receipts/index.jsonl` holds 565 receipts (name, description, argv, exit code, time), with `NAME.stdout` and `NAME.stderr` beside each.
- `expectations.md` holds the independent expectations, written before driving.
- `notes.md` holds the defect note.

Nonzero receipts are kept, not dropped:

- Two stale-UID clicks (`042`, `065`), each repeated with a fresh UID.
- One evaluate argument repaired once (`342` → `343`).
- One mistyped doctor call (`428`); `429` is the real final doctor.
- `wait_for` timeouts on matrix accessible names (`044`, `056`, `081`, `118`, `340`, `399`, `419`). In each case the next snapshot established the state.
- The two print-save failures (`135`, `138`).

## Coverage

| # | Path | Result |
|---|---|---|
| 1 | Original report, server first paint, cell and focus drill-downs | PASS |
| 2 | Dated two-row CSV import and dated briefing/drill-downs | PASS |
| 3 | Filters, URL reload, held/failed refresh, detail failure, late-detail races | PASS |
| 3a | Print of failed-refresh state and filtered no-applicable state | **FAIL (blocked by print save defect)** |
| 4 | `training-pages` seed counts, pagination, page failure/Retry, 100 rows, full-scope export | PASS |
| 5 | Native Excel exports (unfiltered, Alpha, failure/Retry) | PASS |
| 6 | Print brief: native invocation | PASS (`beforeprint`=1) |
| 6 | Print brief PDFs (light, dark, Alpha with detail) | **FAIL (blocked by print save defect)** |
| 6 | Other page's print-media effect (read-only) | PASS |
| 7 | 1440/1024/390 in light and dark, keyboard focus | PASS with findings V1–V3 |
| 7 | Wide-print and ~1920 collapsed-sidebar forecast print | **UNAVAILABLE (print save defect)**; screen capture taken |
| 8 | View, rosterScoped, Empty, viewer denial, Foreign | PASS |
| 9 | Matrix, Personnel readiness, Person workbook, Dashboard | PASS (spot-check) |
| 10 | Restoration and final doctor | PASS, with two preference-key limitations |

## Blocker P1: print save cannot run on the owned worker

**Observation.** `print save 2 'http://127.0.0.1:33931/org/6caba7d8…/training/reports' …/print-failed-refresh.pdf` exits 2 with "Map control blocked: Native page list has no structured pages." (receipts `135` and retry `138`). Native `list_pages` (receipt `137`) lists exactly one matching page, page 2. The `print state` read taken before the save shows `before:1, after:0` (receipt `134`), so the native Print brief click did invoke `window.print()`. No PDF exists.

**Root cause (read-only source inspection, falsifiable).**

- `scripts/verification/print-capture.mjs:147` requires `result.structuredContent.pages`.
- `scripts/verification/daemon.mjs` (around line 233) starts `chrome-devtools-mcp` 1.10.1 without `--experimentalStructuredContent`. That option defaults to `false` in `node_modules/chrome-devtools-mcp/build/src/config/mcp-options.js:65`.
- `build/src/ToolHandler.js:280` attaches `result.structuredContent` only when the flag is set.
- `print-capture.test.mjs` passes because its fixtures mock `structuredContent`. The implementation report already labeled live transport/PDF proof as unrun.

**Falsification.** After a correction, `print save` on a loaded report page returns a PDF instead of this message.

**Dependent proof not run.** None of these could be produced:

- the unfiltered dated brief PDF in light and in dark;
- the Alpha brief with detail open;
- the failed-refresh PDF (the native state was captured: alert, Retry, previous numbers);
- the filtered no-applicable PDF;
- the wide-print case;
- the 1920 collapsed-sidebar forecast print.

No page-by-page PDF inspection was possible. The forecast print-clipping risk is still open: at 1920 with the sidebar collapsed, the screen forecast SVG measures 1436 px wide (`334`, `p7-1920-collapsed-light.png`). That width is wider than landscape paper, but I have no print rendering to judge whether it clips. Root should correct the transport, restart the worker, and rerun journey 6 plus the print parts of 3 and 7.

## 1. Original report (trainingConfigure)

- **Matrix** (`p1-matrix.*`): Able Required Current, Able Targeted Not Done, Baker/Unassigned Required Not Done, Targeted N/A for Baker/Unassigned, Optional N/A for all.
- **Report via the visible Reports link:** 3 soldiers, 25% stays at 25% by 2 Jan, "Nothing lapses before 2 Jan.", Ready 1, expired 0, not recorded 3, lapse 0.
- **Grid:** Bravo 0, Unassigned 0, Alpha 50 (Required 100, Targeted 0). Total Required 33, Total Targeted 0.
- **Type risk:** Required 2/0 above Targeted 1/0.
- **Focus** (my count: two standing gaps, scored 50 then 25):
  - "Verification Required Training — the standing gap": 2 soldiers, 67% of the Organization, "Bravo and Unassigned hold more than half", what-if 25% → 75%.
  - The Targeted gap: 1 soldier, 33%, Alpha, what-if 25% → 50%.
- **Load requests:** client navigation loaded only `reports/__data.json`. The reload loaded only the document plus the notification count. Neither ran an `api/training-reports` summary request (`017`, `021`).
- **Server first paint:** the server HTML, with scripts stripped, contains the Bottom line, every grid cell name and the Focus title and chip (`p1-first-paint-facts.json`).
- **Total Required cell:** `detail?scope=cell&type=<req>` with no `row`. Baker and Unassigned, both Not Done. The cell reads `…, selected`, focus moves to `training-affected-soldiers`, and the page URL stays bare.
- **Alpha × Targeted:** `row=<alpha>`, Able Not Done.
- **Focus link:** `scope=focus&focus=gap%3A<typeId>`, a type key with no completion ID. 2 rows for 2 distinct soldiers. `aria-current=true` is on the link.

## 2. Dated import

- **Preview:** the CSV used the literal fixture dates (`p2-import.csv`). It showed 2 valid rows and wrote nothing (row count stayed 1).
- **Import:** Inserted 2, Updated 0, Errors 0 (`POST …/batch` 200).
- **New IDs:** `4fdcda50-c6af-44ea-ae77-f0804d3caabe` (Able Targeted 2025-10-19 → 2026-10-19, "Verification warning") and `f4a6d59a-e8f5-4060-bf90-04be8a552a9d` (Baker Required 2024-10-04 → 2025-10-04).
- **Matrix after reload:** "15d left" and "Expired 365d ago".

Dated report:

- **Bottom line:** 50% falls to 25%, "loses 25 points in 90 days". Ready 2, expired 1, not recorded 1, lapse 1.
- **Forecast:** 50% through 18 Oct, then 25% from the week ending 25 Oct (1 lapse). No cliff, because 1 lapse is fewer than 5.
- **Grid:** Alpha 100/50, Alpha × Targeted "drops 100 points". Total Required 33, Total Targeted 100.
- **Type risk:** Required 2/0 above Targeted 0/1.
- **Focus:** the Required standing gap (25% → 75%), then "Alpha — Verification Targeted Training": "Alpha falls from 100% to 50% by 2 Jan.", "ALL RENEWED · Alpha 2 Jan forecast 50% → 100%". No wave area, which is correct.
- **Drill-downs:**
  - Total Required lists Unassigned Not Done first, then Baker "Expired 365d ago", Oct 4, 2025, No.
  - Alpha × Targeted and the row focus link (`focus=row%3Agroup%3A<alpha>`) both give Able, "15d left", Oct 19, 2026, Yes.
- **Screenshots:** full briefing `p2-report-dated-full.png` and regions `p2-typerisk.png` and `p2-focus.png`. All text comes from templates and there are no free-text inputs.

## 3. Filters and recovery

I recorded the expected figures before each change and used Clear filters between independent cases.

| Filter | Result |
|---|---|
| Alpha | 1 soldier, 100% → 50%, one summary GET, no navigation, `?group=<A>` |
| Alpha + Required | 100%/100%, "Nothing drops more than 1 point" |
| + 30 days | BY 3 NOV |
| + Rows by MOS | 68W row |
| Focus View | Targeted column before Required, same 50/25 |
| MOS 68W | 2 soldiers, 67% → 33% |
| Duty role NCO | 2 soldiers, 0%, expired 1, not recorded 1 |
| SPC | 3 soldiers, 50/25 |
| + 180 days | BY 2 APR |
| + Rows by Duty role | NCO 0, then Medic 100 with ▼100 |

- **Reload:** reloading `?group=<A>&types=<req>&horizon=30&rowsBy=mos` restored every label (Alpha, Types: 1, 30 days, MOS) and the report from the document alone (`083`–`086`).
- **Failed refresh:** `arm-fail training-reports`, then choose Bravo. The page shows "Unable to update the briefing… (503). Showing the last briefing that loaded." with Retry. The numbers stay at 50/25, the Group control reverts to All groups, and the URL stays bare. After restore, Retry loaded `?group=<Bravo>`.
- **Held refresh:** with Alpha held, the briefing and URL stay Bravo, the Group control shows the pending Alpha, and "Updating briefing" is announced. Export Excel during the hold requested `export?group=<Bravo>`, and its workbook says Scope Bravo with Group filter Bravo (`held-export.xlsx`). Release showed Alpha.
- **Detail failure:** "Unable to load affected soldiers… (503)" with Retry. No table and no count are shown. Retry loaded Able.
- **Late-detail races, both PASS:**
  - A held focus detail followed by Clear filters: the late release did not reopen detail (`p4-after-late-release`).
  - A held Total Required detail followed by Alpha × Targeted: the late release did not replace Alpha × Targeted (`p4-race2-after`).

## 4. Pagination (seed `c42b2731`, after the dated import)

- **Seeded report:** 29 soldiers, 6% → 3%, Ready 2, expired 1, not recorded 28, lapse 1. Alpha Required 4%, Targeted 50%.
- **Total Required, page 1:** "Rows 1–25 of 28".
- **Next:** I held the `page=2` request, and page 1 stayed shown while it loaded. Page 2 showed 26–28: temp #25, Unassigned, Baker expired. The pages cover 28 unique requirements with no duplicates.
- **Failed Previous:** "…could not be loaded (503). Showing the page that loaded before." The range stays "Rows 26–28 of 28". Retry loaded rows 1–25.
- **100 rows:** "Rows 1–28 of 28" (`pageSize=100`).
- **New scope** (Alpha × Required): starts on page 1 with 100 still selected, 26 rows.
- **Export with that detail open:** Requirements holds 30 unique rows (28 Required, plus temp #1 Targeted Not Done, plus Able Targeted Yes). Summary shows 29 soldiers, 31 applicable, 6/3.
- **Cleanup:** `clean-seeds` cleaned up, and the reload returned to 3 soldiers at 50/25.

## 5. Workbooks

All files are named `training-report-2026-10-04.xlsx` with the xlsx MIME type, came from the native button, and were decoded independently (`*-decoded.json`).

| File | Bytes | SHA-256 (prefix) | Contents |
|---|---|---|---|
| `dated-unfiltered.xlsx` | 11859 | `257fb8d5c86f9cec` | Sheets in exact order Summary, Forecast, Hot spots, Focus, Requirements. Summary: 50/25/goal 90/drop 25, counts 2/4/1/1/1 and all 8 filter labels. Forecast: today plus 13 buckets ending 2027-01-02. Requirements: Unassigned Not Done; Baker Expired 2025-10-04; Able "15d left" 2026-10-19, lapse 2026-10-20, Yes. Exported with Total Required detail open. |
| `dated-alpha.xlsx` | 11552 | `c09756fb120b414f` | Scope and Group filter Alpha. Requirements holds only Able Targeted. Exported with another detail open (Alpha × Required, 0 rows). |
| `seeded-detail-open.xlsx` | 12579 | `324ab556ebab1e61` | 30 full-scope rows. |
| `held-export.xlsx` | 11516 | `f6b6be1389aa6196` | Bravo, the shown briefing. |
| `export-retry.xlsx` | 11553 | `072977db26f05c6d` | After a synthetic 503: alert "Unable to export the workbook (503)" with Retry, no Blob captured, no toast. Visible Retry produced 5 sheets. |

## 6. Print

- **Native invocation:** observed (`134`). PDFs: blocker P1.
- **Other pages (read-only):** on the unchanged Training matrix, the 23 loaded print-media rules match 0 elements. The report rules are all scoped to `[data-print-report="training"]` (`343`). Pagination and alert actions are hidden by those rules in source only; actual print rendering is unproven.

## 7. Visual and keyboard

Each width had a native interaction (1440 cell click, 1024 cell click, 390 focus link) and screenshots in light and dark (`p7-*`). Text wraps cleanly and the lower sections are legible in both themes. Keyboard checks:

- A focus ring shows on a grid cell, and Enter opens its detail.
- Shift+Tab reaches "View 1 soldier", and Enter opens the candidate and focuses Affected soldiers.
- Detail Retry receives a visible focus ring at 390 in dark.

The lower layout matches the Paper parent artboard's structure: two-column Type risk and Focus, numbered areas, chips and links.

Findings:

- **V1, minor.** At 1024 with the sidebar expanded, the Hot-spot grid overflows its container (scrollWidth 839 vs 720). The Today and 2 Jan columns sit beyond horizontal scroll even with only two types; the container is `overflow-x:auto`. At 390, horizontal scrolling of the grid and table is expected and works.
- **V2, cosmetic.** The what-if chips are monochrome. The mock colors the before/after values red/green.
- **V3, keyboard.** After a successful keyboard Retry in Affected soldiers, focus drops to `<body>` because the Retry button unmounts (`329`).
- **Wide print.** A many-column print was not exercised. The fixture has only two required types, and print is blocked anyway. No temporary catalog types were created.

## 8. Access

- **trainingView:** report at 50/25, native export with 5 sheets and 3 Requirements (`view-export.xlsx`, 11859 bytes, `e3ec26b1…`).
- **rosterScoped:** 1 soldier at 100/50, Alpha only. Native export holds only Able Targeted (`07647c8c…`).
- **trainingEmpty:** 0 soldiers, "No applicable requirements.", Export Excel disabled.
- **viewer:** the route shows "403 You don't have permission to view this page."
- **trainingForeign:** Org B only, 1 Foreign soldier, no A names or types. Native export holds only Foreign data (`acf34d1b…`).

Direct authenticated GETs (API proof, separately labeled):

| Actor | Request | Status / result |
|---|---|---|
| rosterScoped | Bravo summary | 200, scope Bravo, 0 soldiers |
| rosterScoped | Foreign group | 200, normalized to own scope (1 soldier) |
| rosterScoped | Bravo-row detail, foreign-type detail, Required gap focus | 404 |
| rosterScoped | Bravo export | 200, empty Requirements |
| rosterScoped | all of the above | no Baker/Unassigned/Foreign identifiers |
| trainingEmpty | API export | 5 sheets, Soldiers 0, applicable 0, blank percentages, empty Requirements |
| trainingEmpty | `group=Alpha` | 0 soldiers, not Organization scope |
| viewer | page, summary, detail, export | all 403 |
| Foreign | A group | normalized to B scope |
| Foreign | A type detail and focus | 404 |
| Foreign | A group/type export | Foreign-only |
| Foreign | A endpoints | 404 "Organization not found" |

No mutation probes were run, and no RLS or remote proof is claimed.

## 9. Retained consumers

- **Matrix:** the dated cells and the restored original cells were correct after each reload.
- **Personnel (rosterManager):**
  - Able: "1 due · Verification Targeted Training 15d left."
  - Baker: "Verification Required Training expired 365d ago."
  - Baker's Availability, Critical Tasks and Rating Scheme cards read "Unavailable … could not be loaded" for this actor. I noted this but did not assess it.
- **Person workbook:** Able's native Export records gave `SPC_Able_Synthetic-export-2026-10-04.xlsx` (9383 bytes, `8b1e2b24…`, observe 200). Its Training Records sheet holds Targeted 2025-10-19/2026-10-19 "Verification warning" and Required 2026-09-27/2027-09-27.
- **Dashboard:** "33% training current", "1 personnel with expired training" (Bravo), "1 training items expiring soon". This is its distinct currency meaning; I did not require it to match the report's 50%. The What's New modal was left open to avoid a preference write.
- **Not run:** Organization raw export and Onboarding completion-existence. Both are unchanged and covered at a lower level.

## 10. Restoration

- **Imported completions:** both removed through the matrix editor (Delete → "Delete Training Record" → Delete), each DELETE 200. My first confirm click targeted a nonexistent label and did nothing; the receipt is kept.
- **Final readback:** these sets are byte-identical to root's untouched originals (`421-final-*`):
  - `personnel_trainings` A (1 row, `c072729e…`) and B (0 rows);
  - `training_types` A and B;
  - `training_views` A and B;
  - `organizations` A and B;
  - `trainingConfigure` preferences.
- **Final report:** after reload, the matrix and report are back to 25%/25%, 1/0/3/0.
- **Seeds:** cleaned.
- **Observers:** network, export, print and feedback were restored on pages 2–8; each reports nothing still armed.
- **Viewport and theme:** viewport 1905×2053 restored, theme back to light through the visible toggle, sidebar expanded through the visible toggle.
- **Limitations:**
  - The visible controls leave `localStorage.theme="light"` where no key existed before; the `system` mode key is unchanged.
  - They also leave cookie `sidebar:state=true` where none existed before. The visual state matches the original in both cases.
- **Sensitive file:** `sensitive-flag-for-root-redaction/p1-reload-document.network-response` contains serialized synthetic tokens and needs root's value-only redaction. No receipt or snapshot matched a token pattern.

Final doctor PASS on the same candidate. The worker is returned to root for clean-seeds, cleanup and process-absence proof; I ran no cleanup.
