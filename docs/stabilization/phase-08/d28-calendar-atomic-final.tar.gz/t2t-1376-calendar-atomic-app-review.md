# D28 Calendar atomic removal app review

Comment review PASS. Source, boundary, and corrected test review PASS for the selected app slice. The original three-case test finding was accepted and removed. This is an independent read-only review, not native, provider, SQL, CI, or release acceptance.

The first reviewer output was exactly `Yes... Ha ha ha... Yes!`. The reviewed base is `origin/main` at `4d5f8bfb5723752788f96c1666e2c12d50b47682`. Scope covers ten tracked changed paths and three new app/test paths. It excludes unrelated existing comments and the SQL worker's unfinished migration. No service, browser, database query, test command, external network action, source edit, or child agent was used. Only this report was written.

## Scoped comments and suppressions

Zero comments were added. Zero lint or TypeScript suppressions were added. Two narration comments were deleted from `availabilityBatch.server.ts`. They described the old reference lookup and one-round-trip mutation that the new code now expresses directly.

Deletion count is zero by this reviewer. The candidate already removes two comments. Restored comments, reruns, MUST KILL flags, accepted keep exceptions, encoding offers, encodings, and unenforced comment constraints are all zero. Existing comments outside changed hunks were inspected only for context and were not judged.

No architecture sketch or application edit is needed for the comment result.

## App result

The two-method `CalendarAvailabilityRemovalPort` in `contracts.ts:80` expresses this deliverable's current owned need. `findPersonnelIds` and `deleteIds` have no table-name or caller-supplied Organization parameter. `createSupabaseCalendarAvailabilityRemovalPort` captures one ordinary client and one Organization at construction. The direct Calendar public server seam exports the factory.

The delete operation now receives `CalendarAvailabilityRemovalPorts` without a generic store. It preserves the existing raw 500-ID input cap, authoritative Calendar and Person policy, `{deleted:number}`, and successful `availability.bulk_deleted` audit. `availabilityBatch.server.ts:86` and 89 remove both generic URL-shaped calls from the shipped delete path.

The adapter issues deduplicated reference GETs with at most 100 saved IDs each. At the operation's 500-ID cap, `Promise.all` overlaps at most five ordinary queries. A failed query prevents policy settlement and mutation. The simple fixed-ID query needs no 1,000-row pagination because one primary-key filter can select at most 100 rows. It returns distinct Person IDs before the existing policy check.

`deleteIds` sends one RPC POST with the captured Organization and complete raw ID array. It has no mutation loop, retry, fallback, or admin client. The ordinary mutation boundary accepts only an integer in the declared range. Malformed acknowledgment throws before the operation emits a success audit. Expected SQL capability and argument failures become safe caller messages and status values through the existing HTTP boundary. Other provider errors retain HTTP 500 concealment.

`createRequestAvailabilityRemovalContext` in `requestContexts.server.ts:493` contains only auth, audit, the existing admitted privileged read-only Personnel roster collaborator, and the ordinary removal provider. The DELETE route selects this context. POST retains its prior context and use case. This narrow provider can remain useful after the private full Calendar owner adopts it. There is no new generic facade or compatibility fallback.

The in-memory binding preserves existing tests' broad raw-reference policy check and actual deletion/count behavior. It does not establish ordinary SQL RLS visibility. The existing scoped denial test remains intact. Direct SQL proof must still establish the real provider's hidden/missing/foreign subset behavior.

The network-control correction observes DELETE `body.ids` separately from POST `body.records`. It retains raw count and duplicate IDs and leaves the real response intact. The added helper test protects exactly that behavior. The maintained Bulk Remove recipe now requires native review, Back no effects, 500-entry removal/reload, failure/retry, complete rows, and cleanup ordering.

## Actionable test finding

`src/features/calendar/availabilityRemovalPersistence.server.test.ts:75-78` calls three arranged fake replies 0, 1, and 2 "actual count" behavior for repeated or duplicate deletion. The fixture performs no deletion. These tests assert only that the provider returns the number its fake HTTP response supplies. They prove neither duplicate effects nor replay, and they conflict with the repository's prohibition on asserting only an arranged stub value.

Disposition REWRITE or DELETE. A narrow rewrite can exercise `deleteAvailabilityBatch` with the real adapter, assert the public count and successful audit, and name the behavior accepted scalar acknowledgment mapping. Avoid a replay claim. Actual repeated deletion is already proven by the new route test's stored state. The disposable SQL proof must own duplicate and visible-subset counts. Retaining all three arranged scalar cases alone adds no distinct deletion protection.

This is a preparation/test issue, not a demonstrated product defect. No production change is requested. The parent was notified with this exact bounded correction.

## Retained test coverage

The installed-SDK transport test at lines 47-63 is KEEP. Its independent contract requires all 500 references, safe bounded read URLs, one fixed RPC mutation path, and exact Organization/ID serialization. The fake server rejects oversized read filters and any incorrect method/path/authority. An old long-URL delete or lost input fails. Internal helper reshaping would survive.

The late read-failure test at lines 65-73 is KEEP. It exercises the actual delete operation with the real SDK adapter. A fifth read error must produce no POST and no success audit. This protects the no-mutation boundary, rather than incidental read order.

The malformed-acknowledgment cases at lines 80-91 are KEEP. They cover distinct invalid provider classes and use the actual operation to prove no successful audit and no retry/fallback. Null, string, negative, fractional, and out-of-range values can disagree with the implementation.

The safe SQL error-mapping cases at lines 93-100 are KEEP. They prove two independently specified classifications and conceal private provider detail. Their exact method assertion protects the single mutation attempt. They are not SQL enforcement proof.

The route suite is KEEP. It runs real admission and application orchestration against actual in-memory rows. It proves Calendar-only access, 500 deletions, replay zero, unrelated and foreign preservation, exact audit counts, denied access before persistence selection, raw unique/duplicate 501 caps, and unchanged Add note persistence. A mutation, scope, or cap regression fails at the appropriate cheap boundary. The in-memory store does not replace SQL admission/RLS proof.

The helper test is KEEP. It calls the real installed network wrapper and proves duplicate ID/count capture while preserving the actual response. This fixes a control defect that otherwise obscures fresh native request proof.

## Evidence and remaining gates

The parent reports 63 selected app suites with 526 passing tests, types with zero errors/warnings, governance 159 retained findings, and 28 passing network-control tests. This reviewer did not rerun them or inspect their raw logs, so these counts are attributed rather than independently executed.

Current-main native 500-ID failure and exact A506/B1 no-effects are parent-reported baseline evidence. The prior private cutover's A508/B1 failure remains its separate tuple. Fresh final native, disposable migration replay, direct ordinary RPC/RLS effects, rollback proof, full required checks/build, expanded evidence acceptance, exact-head CI, and completed bot reviews remain required. The unfinished SQL worker is outside this source review and is not a missing-migration finding.

The resulting PR must stop before merge for Robert's manual remote operation. No remote database access is authorized. The private 85-path Calendar cutover, phases 8-10, Training's eight lower failures and twelve unrun native families, Personnel's selected four-port cutover, Onboarding, residual settings, and final facade removal remain #1376 work. This app review grants no whole-issue or private-cutover acceptance.

## Reviewed bindings

All hashes are SHA256 of the actual bytes read during review.

| Path | Bytes | SHA256 |
| --- | ---: | --- |
| `.agents/skills/verify-trooptotask/features/bulk-status.md` | 9804 | `b16b0668228bb5b11e5d46453ecc1d3c970e4973015a753bcce29d7bc233a4b3` |
| `.agents/skills/verify-trooptotask/helpers/network-control.mjs` | 5301 | `08c1f295013230ff0fec493f25f94d2a745236336c280022640a03ee24d234c0` |
| `.agents/skills/verify-trooptotask/helpers/network-control.test.mjs` | 17579 | `b84525c50eb9ab4394976a3abf16923a4afb9ec7f36c73d5e8fc6d7c9ff330ed` |
| `src/features/calendar/availabilityBatch.server.ts` | 2911 | `25c1787dc8f3254672f63c9a321ce4e3dbbcfcc3b5488ab9cb5f7d88e4b8d592` |
| `src/features/calendar/contracts.ts` | 2242 | `d8ee3ec5356e6599aed00df1a3025008162ad3696a371f4c6f72cabc72d1f8e7` |
| `src/features/calendar/index.server.ts` | 2653 | `b4098df5b0315553c927a7e3baa0b68e5f66b9d8d35657f93102e6f1b7dea684` |
| `src/lib/server/adapters/inMemory.ts` | 56028 | `09bd930fe8e2bebc2881c3133ab7627606f9b19a6f93a47f289ad8c35db94f9c` |
| `src/lib/server/adapters/requestContexts.server.ts` | 24793 | `b69ef882666773025c808c082160a877d65e2f91f676380962432df808d0fab0` |
| `src/lib/server/core/useCases/calendarPolicy.ts` | 4154 | `b1be3eeb41fe40cb3ff67da0a13b5369b7d5c48ae44aee94c54384bb17777a22` |
| `src/routes/org/[orgId]/api/availability/batch/+server.ts` | 1272 | `643729b97c2ad18c0e97e02eea4de369bc56cd3e5062ccd9a393280637d12f72` |
| `src/features/calendar/availabilityRemovalPersistence.server.ts` | 1595 | `78140ac88f43793fe50648b8d8874ea7d24cc06e6b4c510b07fcd0d896782a63` |
| `src/features/calendar/availabilityRemovalPersistence.server.test.ts` | 5012 | `ff86c12a985b4411e29f1b5d988ee9fac76d8a183b71af023b5469799fdd9358` |
| `src/routes/org/[orgId]/api/availability/batch/server.test.ts` | 4529 | `cd59950c8d03678e3a45b83b82a20e8b2487d99f1d78fe18bcff93b1afd95d1b` |

Fix Root Causes confirms that the app removes both long-URL sites. The Testing strategy's behavioral bar changes the three arranged-scalar cases from deletion proof to a required narrow correction. No applied principle expands this review's authority.

## Accepted correction readback

The parent removed all three arranged scalar assertions. The reviewer read the actual corrected file in full. No production code changed. The corrected test file is 4,778 bytes with SHA256 `7c23e7dbf7bbef12e381df980b3d6738548f43c3b56085f2eb7417f15f925440`. All twelve other source, control, test, and recipe bindings remain exactly unchanged from the table above. The table preserves the initial review tuple rather than silently replacing it.

The test finding is resolved. Duplicate/count SQL effects remain explicitly assigned to the real disposable database proof. Actual in-memory replay and preserved unrelated/foreign rows retain their meaningful route protection. The parent reports a focused rerun in progress, which is not a completed result in this receipt.

The network-control update and its real response/duplicate-ID test were read in full. The wrapper records JSON IDs only for availability batch DELETE within the added condition. The recipe uses a fresh 501-Person cohort with one Person unselected during Add, then expects 500 saved matches during Remove. It preserves Back no effects, synthetic failure draft, and explicit retry requirements.

Final app-source verdict is GO with zero remaining actionable findings. Comment/suppression verdict remains GO. SQL, final native, current-candidate checks, expanded acceptance, exact-head CI, bot review, and the manual migration stopping point remain separate required gates. No whole-issue or full private Calendar cutover acceptance is granted.
