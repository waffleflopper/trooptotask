import json,sys,datetime
from pathlib import Path
p=Path(sys.argv[1]);checks=[]
def data(n):return json.loads((p/(n+'.json')).read_text())
def rows(n):return {r['id']:r for r in data(n)['rows']}
def txt(n):return '\n'.join(c.get('text','') for c in data(n)['content'] if c['type']=='text')
def check(label,a,b):
 assert a==b,(label,a,b)
 checks.append(label)
def stamp(v):return datetime.datetime.fromisoformat(v.replace('Z','+00:00'))
s=data('seed');i=s['ids'];base=rows('before-personnel');foreign=rows('before-foreign')
tables=['leader_notes','personnel_follow_ups','counseling_records','personnel_documents','personnel_trainings','personnel_ict_completions']
check('before exact synthetic A count',len(base),7);check('before B count',len(foreign),1)
for phase in ['edit-approval-failed','edit-retry','edit-pending','direct-edit-failed','restored','restored-reload']:
 check(phase+' exact Person fields (draft not saved)',rows(phase+'-personnel'),base)
check('approval failure zero pending raw read',data('edit-approval-failed-requests')['rows'],[])
requests=data('edit-retry-requests')['rows'];check('one request for original ID',[(r['resource_id'],r['status']) for r in requests],[(i['duplicateAlpha'],'pending')])
check('409 retains same exact pending request',data('edit-pending-requests')['rows'],requests)
for phase,draft in [('edit-approval-failed','Unsaved archive recovery duty'),('direct-edit-failed','Unsaved direct archive duty')]:
 t=txt(phase+'-visible');check(phase+' retains Edit', 'dialog "Edit Personnel"' in t,True)
 check(phase+' retains entered draft','value="'+draft+'"' in t,True)
check('approval acknowledged closes editor','dialog "Edit Personnel"' in txt('edit-retry-visible'),False)
check('approval reload retains active Person',s['duplicateName']+', Synthetic' in txt('edit-pending-reload-visible'),True)
for phase in ['direct-edit-failed']:
 check(phase+' foreign unchanged',rows(phase+'-foreign'),foreign)
 check(phase+' note sentinel unchanged',rows(phase+'-control'),rows('before-control'))
 for table in tables:check(phase+' '+table+' unchanged',rows(phase+'-'+table),rows('before-'+table))
held=rows('direct-edit-held-personnel');T=held[i['person']]['archived_at'];assert T
expected={k:dict(v) for k,v in base.items()};expected[i['person']]['archived_at']=T
check('held response Person persisted exact archive only',held,expected)
check('release no duplicate Parent effect',rows('direct-edit-archived-personnel'),held)
hv=txt('direct-edit-held-after-escape')
check('held Escape retains editor','dialog "Edit Personnel"' in hv,True);check('held Escape retains confirmation','alertdialog "Archive Personnel"' in hv,True)
for label in ['Save Changes','Cancel','Archive']:
 check('pending editor disabled '+label,'button "'+label+'" disableable disabled' in hv,True)
check('held draft not saved','value="Editable after failed direct archive"' in hv,True)
check('release closes editor','dialog "Edit Personnel"' in txt('direct-edit-retry-visible'),False)
check('archive reload absent target',s['name']+', Synthetic' in txt('direct-edit-retry-reload-visible'),False)
check('restore reload target active',s['name']+', Synthetic' in txt('restore-manager-reload-visible'),True)
active={'leader_notes':i['noteActive'],'counseling_records':i['counselingActive'],'personnel_documents':i['documentActive'],'personnel_follow_ups':i['followOpen']}
for table in tables:
 b=rows('before-'+table);got=rows('direct-edit-held-'+table);restored=rows('restored-'+table)
 expected={k:dict(v) for k,v in b.items()}
 if table in active:
  k=active[table];expected[k]['archived_at']=T
  if table=='personnel_follow_ups':expected[k]['status']='archived'
  if 'updated_at' in expected[k]:
   assert stamp(got[k]['updated_at'])>=stamp(b[k]['updated_at'])
   expected[k]['updated_at']=got[k]['updated_at']
 check('archive '+table+' exact event/history',got,expected)
 check('release '+table+' no extra effect',rows('direct-edit-archived-'+table),got)
 expected={k:dict(v) for k,v in b.items()}
 if table in active and 'updated_at' in expected[active[table]]:
  k=active[table];assert stamp(restored[k]['updated_at'])>=stamp(got[k]['updated_at'])
  expected[k]['updated_at']=restored[k]['updated_at']
 check('restore '+table+' exact history/IDs',restored,expected)
for phase in ['direct-edit-held','direct-edit-archived','restored']:
 check(phase+' foreign unchanged',rows(phase+'-foreign'),foreign)
 check(phase+' note sentinel unchanged',rows(phase+'-control'),rows('before-control'))
check('release captured actual success',data('direct-edit-retry-feedback')['entries'],[{'type':'success','text':'Personnel archived'}])
for phase,code in [('edit-approval-failed',503),('edit-retry',201),('edit-pending',409),('direct-edit-failed',503),('direct-edit-retry-held',200),('direct-edit-retry-released',200)]:
 check(phase+' one matched request status',[r['status'] for r in data(phase+'-network')['calls']],[code])
check('response held after persistence',data('direct-edit-retry-held-network')['held'],True)
check('response released',data('direct-edit-retry-released-network')['held'],False)
known={i[x] for x in ['person','duplicateAlpha','duplicateBravo','archivedDuplicate']}
check('cleaned original A exact rows',rows('cleaned-personnel'),{k:v for k,v in base.items() if k not in known})
check('cleaned B exact rows',rows('cleaned-foreign'),foreign)
check('pending request preserved until teardown',data('cleaned-requests')['rows'],requests)
for name in ['doctor-start','doctor-final','cleanup']:check(name+' PASS',data(name)['status'],'PASS')
check('doctors same tested revision',data('doctor-final')['revision'],data('doctor-start')['revision'])
check('doctors same tested digest',data('doctor-final')['candidate'],data('doctor-start')['candidate'])
print(json.dumps({'result':'PASS','checks':len(checks),'event':T,'labels':checks},indent=2))

