import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';

const directory = '.verification/evidence/verify-trooptotask/1503-final-chart-v4';
const file = 'training-report-2026-10-03-medic-required.xlsx';
const bytes = await fs.readFile(`${directory}/downloads/${file}`);
const sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
assert.equal(bytes.length, 6806);
assert.equal(sha256, '3ddf65ac3a791abe9a680be9127cfa6a476644ad3f6833dcf3db02a263c134ec');
const workbook = new ExcelJS.Workbook();
await workbook.xlsx.load(bytes);
assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Training Report']);
const sheet = workbook.worksheets[0];
const rows = Array.from({ length: sheet.rowCount }, (_, index) =>
  Array.from({ length: sheet.columnCount }, (_, column) => sheet.getRow(index + 1).getCell(column + 1).value));
assert.deepEqual(rows, [
  ['Name', 'Rank', 'MOS', 'Duty Role', 'Group', 'Verification Required Training'],
  ['Able, Synthetic', 'SPC', '68W', 'Medic', 'Alpha', 'Current (2027-09-26)']
]);
process.stdout.write(JSON.stringify({ status: 'PASS', proof: 'Root offline inspection of actual visible-button Blob artifact; not independent browser execution', file, bytes: bytes.length, sha256, sheet: sheet.name, rows }, null, 2) + '\n');
