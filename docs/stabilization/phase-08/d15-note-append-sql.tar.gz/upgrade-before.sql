BEGIN;
INSERT INTO auth.users(id, email)
SELECT ('d1505000-0000-4000-8000-' || lpad(n::text, 12, '0'))::uuid,
  'onboarding-note-upgrade-' || n || '@example.test' FROM generate_series(1, 7) n;
INSERT INTO public.organizations(id, name, created_by) VALUES
('d1505000-0000-4000-8000-000000000101', 'Note Alpha', 'd1505000-0000-4000-8000-000000000001'),
('d1505000-0000-4000-8000-000000000102', 'Note Foreign', 'd1505000-0000-4000-8000-000000000001');
INSERT INTO public.groups(id, organization_id, name) VALUES
('d1505000-0000-4000-8000-000000000201', 'd1505000-0000-4000-8000-000000000101', 'Alpha'),
('d1505000-0000-4000-8000-000000000202', 'd1505000-0000-4000-8000-000000000101', 'Bravo');
INSERT INTO public.organization_memberships (
  organization_id, user_id, role, member_preset, capability_overrides, access_scope_kind, access_scope_group_ids
) SELECT 'd1505000-0000-4000-8000-000000000101'::uuid,
  ('d1505000-0000-4000-8000-' || lpad(actor::text, 12, '0'))::uuid,
  'member'::public.organization_role, 'viewer',
  jsonb_build_object('onboarding', capability, 'personnel', CASE WHEN actor=4 THEN 'operate' ELSE 'none' END,
    'training', 'none', 'calendar', 'none'), scope_kind,
  CASE WHEN actor=5 THEN ARRAY['d1505000-0000-4000-8000-000000000201']::uuid[] ELSE ARRAY[]::uuid[] END
FROM (VALUES (1,'operate','organization'), (2,'configure','organization'),
  (3,'view','organization'), (4,'none','organization'), (5,'operate','groups'),
  (6,'operate','groups'), (7,'operate','organization')) a(actor,capability,scope_kind);
INSERT INTO public.organization_memberships (
  organization_id,user_id,role,member_preset,capability_overrides,access_scope_kind,access_scope_group_ids
) VALUES ('d1505000-0000-4000-8000-000000000102','d1505000-0000-4000-8000-000000000001',
  'member','viewer','{"onboarding":"operate","personnel":"none","training":"none","calendar":"none"}',
  'organization',ARRAY[]::uuid[]);
INSERT INTO public.personnel(id,organization_id,group_id,rank,first_name,last_name,slug) VALUES
('d1505000-0000-4000-8000-000000000301','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000201','SPC','Alpha','Note','note-alpha'),
('d1505000-0000-4000-8000-000000000302','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000202','SPC','Bravo','Note','note-bravo'),
('d1505000-0000-4000-8000-000000000303','d1505000-0000-4000-8000-000000000101',NULL,'SPC','Unassigned','Note','note-unassigned'),
('d1505000-0000-4000-8000-000000000304','d1505000-0000-4000-8000-000000000102',NULL,'SPC','Foreign','Note','note-foreign');
INSERT INTO public.personnel_onboardings(id,organization_id,personnel_id,status,started_at,completed_at,cancelled_at) VALUES
('d1505000-0000-4000-8000-000000000701','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000301','in_progress','2030-01-01T00:00:00Z',NULL,NULL),
('d1505000-0000-4000-8000-000000000702','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000302','in_progress','2030-01-01T00:00:00Z',NULL,NULL),
('d1505000-0000-4000-8000-000000000703','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000303','in_progress','2030-01-01T00:00:00Z',NULL,NULL),
('d1505000-0000-4000-8000-000000000704','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000301','completed','2030-01-01T00:00:00Z','2030-01-03T00:00:00Z',NULL),
('d1505000-0000-4000-8000-000000000705','d1505000-0000-4000-8000-000000000101','d1505000-0000-4000-8000-000000000301','cancelled','2030-01-01T00:00:00Z',NULL,'2030-01-03T00:00:00Z'),
('d1505000-0000-4000-8000-000000000706','d1505000-0000-4000-8000-000000000102','d1505000-0000-4000-8000-000000000304','in_progress','2030-01-01T00:00:00Z',NULL,NULL);
INSERT INTO public.onboarding_step_progress (
  id,organization_id,onboarding_id,step_name,step_type,sort_order,completed,current_stage,stages,notes,active
) SELECT ('d1505000-0000-4000-8000-' || lpad(step_id::text,12,'0'))::uuid,
  CASE WHEN step_id=807 THEN 'd1505000-0000-4000-8000-000000000102' ELSE 'd1505000-0000-4000-8000-000000000101' END::uuid,
  ('d1505000-0000-4000-8000-' || lpad(parent_id::text,12,'0'))::uuid,
  step_name,step_type,step_id-800,true,current_stage,
  CASE WHEN step_type='paperwork' THEN '["Draft","Reviewed","Filed"]'::jsonb ELSE NULL END,
  CASE WHEN step_id=808 THEN '{"unexpected":"object"}'::jsonb ELSE
    '[{"text":"Original saved note","timestamp":"2030-01-01T00:00:00Z","userId":"d1505000-0000-4000-8000-000000000002","extra":{"retained":[1,true,null]}}]'::jsonb END,active
FROM (VALUES (801,701,'Orientation','checkbox',NULL::text,true),
  (802,701,'Paperwork','paperwork','Reviewed',true),
  (803,704,'Completed retained work','checkbox',NULL,false),
  (804,705,'Cancelled retained Training','training',NULL,false),
  (805,702,'Bravo work','checkbox',NULL,true),
  (806,703,'Unassigned work','checkbox',NULL,true),
  (807,706,'Foreign work','checkbox',NULL,true),
  (808,701,'Malformed saved notes','checkbox',NULL,true)) s(step_id,parent_id,step_name,step_type,current_stage,active);

CREATE SCHEMA upgrade_fixture;
CREATE VIEW upgrade_fixture.saved_rows AS
  SELECT 'parent'::text table_name,id,to_jsonb(p) row_data FROM public.personnel_onboardings p
  UNION ALL SELECT 'progress',id,to_jsonb(p) FROM public.onboarding_step_progress p
  UNION ALL SELECT 'personnel',id,to_jsonb(p) FROM public.personnel p;
CREATE TABLE upgrade_fixture.note_before AS SELECT * FROM upgrade_fixture.saved_rows;
DO $$ BEGIN
  IF to_regprocedure('public.append_onboarding_step_note(uuid,uuid,text)') IS NOT NULL
    THEN RAISE EXCEPTION 'New append function must be absent before populated upgrade'; END IF;
END; $$;
COMMIT;
