import json,pathlib,sys,uuid,re
import native_driver as d
S=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
label,page,session_id,org_key,family,method,body,*target=sys.argv[1:]
assert re.fullmatch(r'[A-Za-z0-9_-]+',label), 'Use an alphanumeric/hyphen/underscore label'
assert str(uuid.UUID(session_id))==session_id
state=json.loads((S/'session.json').read_text())
assert state['id']==session_id and state['repository']==str(pathlib.Path.cwd()) and state['worker']=='1' and state['phase']=='running'
doctor=d.call(label+'-doctor',['doctor'])
assert doctor['status']=='PASS' and doctor['session']==session_id and doctor['origin']==state['origin'] and doctor['candidate']==state['candidate']
fixture=json.loads((S/'fixtures.json').read_text())
assert org_key in ['orgA','orgB'] and int(page)>0
organizations=[]
for key in ['orgA','orgB']:
 rows=d.call(label+'-canonical-'+key,['rows','organizations',key],True)['rows']
 assert len(rows)==1 and rows[0]['id']==fixture['ids'][key]
 organizations.append(dict(id=rows[0]['id'],segment=rows[0]['url_slug'] or rows[0]['id']))
input=dict(origin=doctor['origin'],org=fixture['ids'][org_key],organizationSegment=next(x['segment'] for x in organizations if x['id']==fixture['ids'][org_key]),organizations=organizations,family=family,method=method,body=json.loads(body),targetId=target[0] if target else None)
function=pathlib.Path(__file__).with_suffix('.mjs').read_text().replace('export async function request','async function request',1)
result=d.evaluate(label,'async () => { '+function+'; return request('+json.dumps(input)+'); }',int(page))
print(d.txt(result))
