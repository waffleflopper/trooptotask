SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_parent_delete_fault_dd2bba08() RETURNS trigger LANGUAGE plpgsql AS $d15$
BEGIN
  IF OLD.id = '1aab72bc-9167-4a3b-b4d3-e7fc91df3556'::uuid AND OLD.organization_id = 'bcc91ccd-0ade-4c1f-84c0-ec8fd9604116'::uuid THEN
    RAISE EXCEPTION USING ERRCODE = 'P0001', MESSAGE = 't2t-d15 intentional owned seed parent-delete fault';
  END IF;
  RETURN OLD;
END;
$d15$;
COMMENT ON FUNCTION public.t2t_d15_parent_delete_fault_dd2bba08() IS 't2t-d15 project=t2t-verify-719c704a6c3e421eb4037390 seed=1aab72bc-9167-4a3b-b4d3-e7fc91df3556';
CREATE TRIGGER t2t_d15_parent_delete_fault_dd2bba08 BEFORE DELETE ON public.personnel_onboardings FOR EACH ROW
WHEN (OLD.id = '1aab72bc-9167-4a3b-b4d3-e7fc91df3556'::uuid AND OLD.organization_id = 'bcc91ccd-0ade-4c1f-84c0-ec8fd9604116'::uuid)
EXECUTE FUNCTION public.t2t_d15_parent_delete_fault_dd2bba08();
COMMENT ON TRIGGER t2t_d15_parent_delete_fault_dd2bba08 ON public.personnel_onboardings IS 't2t-d15 project=t2t-verify-719c704a6c3e421eb4037390 seed=1aab72bc-9167-4a3b-b4d3-e7fc91df3556';
COMMIT;
SELECT json_build_object('event', 'fault-install-committed');
