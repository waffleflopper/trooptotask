SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_parent_delete_fault_e3a30a5a() RETURNS trigger LANGUAGE plpgsql AS $d15$
BEGIN
  IF OLD.id = '2917cbea-a576-4d58-b124-376003114601'::uuid AND OLD.organization_id = '278b5950-3fde-4744-b4cc-e46534f9009d'::uuid THEN
    RAISE EXCEPTION USING ERRCODE = 'P0001', MESSAGE = 't2t-d15 intentional owned seed parent-delete fault';
  END IF;
  RETURN OLD;
END;
$d15$;
COMMENT ON FUNCTION public.t2t_d15_parent_delete_fault_e3a30a5a() IS 't2t-d15 project=t2t-verify-3cebaa16cfc14abb82983af6 seed=2917cbea-a576-4d58-b124-376003114601';
CREATE TRIGGER t2t_d15_parent_delete_fault_e3a30a5a BEFORE DELETE ON public.personnel_onboardings FOR EACH ROW
WHEN (OLD.id = '2917cbea-a576-4d58-b124-376003114601'::uuid AND OLD.organization_id = '278b5950-3fde-4744-b4cc-e46534f9009d'::uuid)
EXECUTE FUNCTION public.t2t_d15_parent_delete_fault_e3a30a5a();
COMMENT ON TRIGGER t2t_d15_parent_delete_fault_e3a30a5a ON public.personnel_onboardings IS 't2t-d15 project=t2t-verify-3cebaa16cfc14abb82983af6 seed=2917cbea-a576-4d58-b124-376003114601';
COMMIT;
SELECT json_build_object('event', 'fault-install-committed');
