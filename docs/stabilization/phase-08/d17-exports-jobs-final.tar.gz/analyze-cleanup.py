import json,pathlib,hashlib,subprocess
p=pathlib.Path(__file__).parent
load=lambda n:json.loads((p/(n+'.stdout')).read_text())
rows=lambda stage,t,o:{r['id']:r for r in load(f'{stage}-{t}-{o}')['rows']}
artifact=load('retention-artifact-seed');personnel=load('retention-personnel-seed');onboard=load('retention-onboarding-seed')
ids={}
for t in artifact['rows']:ids.setdefault(t['table'],set()).update(x['row']['id'] for x in t['records'])
ids.setdefault('personnel',set()).update(x['row']['id'] for x in artifact['parents'])
for t in personnel['rows']:ids.setdefault(t['table'],set()).update(t['ids'])
ids.setdefault('personnel_onboardings',set()).update(x['id'] for x in onboard['packets'])
ids.setdefault('onboarding_step_progress',set()).update(x['id'] for x in onboard['progress'])
checks=[]
for t,seedIds in ids.items():
 for org in ['orgA','orgB']:
  actual=rows('cleanup',t,org);assert not set(actual).intersection(seedIds),(t,org)
  original={i:r for i,r in rows('retention-before',t,org).items() if i not in seedIds}
  assert actual==original,(t,org)
  checks.append({'table':t,'org':org,'seedIdsAbsent':True,'originalFieldsExactlyUnchanged':True,'remainingOriginalCount':len(actual)})
for t in ['organizations','groups','personnel','personnel_onboardings','onboarding_step_progress']:
 for org in ['orgA','orgB']:assert rows('cleanup',t,org)==rows('before',t,org),(t,org)
frozen=json.loads((p/'frozen-inputs.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==frozen['revision']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for name,digest in frozen['files'].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest['sha256'],name
out={'passed':True,'checks':checks,'organizationProfileAll11ExactlyUnchanged':True,'originalGroupsPersonnelPacketsProgressExactlyUnchanged':True,'recordedSeedIdCount':sum(len(v)for v in ids.values()),'allTrackedInputsUnchanged':len(frozen['files'])}
(p/'cleanup-seed-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
