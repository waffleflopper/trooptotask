#!/usr/bin/env python3
"""Fresh native Calendar views and minimal public marker projection for the two actors."""
import json,os,subprocess,sys
from pathlib import Path
stage=sys.argv[1];run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');b=Path('.verification/evidence/verify-trooptotask')/run
for role,label in [('calendarLane','wide'),('calendarScoped','scoped')]:
 page=json.loads((b/('actor-'+role+'-stdout.json')).read_text())['pageId'];tag='calendar-'+stage+'-'+label
 subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/action.py','reload',str(page),tag+'-persisted'],check=True,stdout=subprocess.DEVNULL)
 for kind,file in [('loader','public-loader.js'),('dom','calendar-dom.js')]:
  args={'pageId':page,'function':Path('.verification/tmp/d15-consumers-worker2',file).read_text(),'waitForStableDom':False}
  subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','tool',tag+'-'+kind,'evaluate_script',json.dumps(args)],check=True,stdout=subprocess.DEVNULL)
 print(tag,'captured')
