SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.onboarding_step_progress
WHERE organization_id = '0c8be8f3-1fe7-4e61-9132-346f7cf43df0'::uuid AND id = '90b3b00f-01b9-4abe-aeea-a5ecc0aa1c06'::uuid AND onboarding_id = 'ad841c2b-1858-4839-9688-24d640cfd417'::uuid AND template_step_id IS NULL AND step_name = 'Orientation' AND step_type = 'checkbox' AND completed AND active AND current_stage IS NULL AND training_type_id IS NULL AND stages IS NULL AND notes = '[{"text": "Legacy retained work 6966be3b", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "e74d364c-3dc9-498a-b223-4fdf0c5c67e2"}]'::jsonb
FOR UPDATE;
SELECT json_build_object('event', 'ready');
