SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p) FROM (SELECT id, organization_id, personnel_id, template_id, started_at,
 completed_at, cancelled_at, status FROM public.personnel_onboardings WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND id = '314c092f-7c4e-41d7-939d-331a4a7e3090'::uuid) p), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND id = '69b4b33b-d063-41ac-9216-8cdbb8ff6bd3'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM (SELECT id, organization_id, onboarding_id, template_step_id,
 step_name, step_type, training_type_id, stages, sort_order, completed, current_stage, notes, active FROM public.onboarding_step_progress
 WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND onboarding_id = '314c092f-7c4e-41d7-939d-331a4a7e3090'::uuid) s), '[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM (SELECT id, organization_id, name FROM public.onboarding_templates
 WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND id IN ('b44da219-5a1d-4589-af5c-a567b03fe970'::uuid,'c1b3d462-cb3e-4b19-9db5-4d0941c1bc7e'::uuid)) t), '[]'::json),
 'definitions', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM (SELECT id, organization_id, template_id, name, step_type, training_type_id, stages, sort_order
 FROM public.onboarding_template_steps WHERE organization_id = '5834cb8a-c291-4ae0-95f3-91ad67b3f22f'::uuid AND template_id IN ('b44da219-5a1d-4589-af5c-a567b03fe970'::uuid,'c1b3d462-cb3e-4b19-9db5-4d0941c1bc7e'::uuid)) t), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
