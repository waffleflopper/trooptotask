import fs from 'node:fs/promises';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { createConnection } from 'node:net';
import {
	execute,
	readJSON,
	writeJSON,
	processIdentity,
	stopOwnedProcess,
	sleep
} from '../../scripts/verification/core.mjs';
import {
	scratch,
	admit,
	checkpoint,
	ownedEnvironment,
	validatePreviewInfo,
	validateRunBinding,
	requireThat,
	sameProcess,
	servePortState,
	resolveExecutable,
	capturePreviewHelper,
	reconcileSpawnedHelper,
	safeStartupCode,
	finishOwnedCleanup
} from './transport.mjs';

const command = process.argv[2] ?? 'help';
const latestPath = path.join(scratch, 'latest.json');
const leasePath = path.join(scratch, 'live-lease');
const say = (result) => console.log(JSON.stringify(result, null, 2));
let launchedHelper;
let interrupted = false;
for (const signal of ['SIGINT', 'SIGTERM'])
	process.on(signal, () => {
		interrupted = true;
		if (launchedHelper)
			void stopOwnedProcess(launchedHelper).catch(() => {
				process.exitCode = 2;
			});
	});
async function loadRun() {
	const latest = await readJSON(latestPath);
	requireThat(/^[0-9a-f-]{36}$/.test(latest.sessionId), 'RUN_POINTER');
	const runDirectory = path.join(scratch, 'runs', latest.sessionId);
	const binding = await readJSON(path.join(runDirectory, 'binding.json'));
	validateRunBinding(binding);
	requireThat((await fs.realpath(runDirectory)) === runDirectory, 'RUN_POINTER');
	requireThat(binding.runDirectory === runDirectory && binding.sessionId === latest.sessionId, 'RUN_POINTER');
	return binding;
}
async function runningProcesses(binding) {
	const helper = (await readJSON(path.join(binding.runDirectory, 'helper.json'))).identity;
	const sidecar = await readJSON(path.join(binding.runDirectory, 'sidecar.json'));
	requireThat(
		sidecar.phase === 'running' &&
			sidecar.sessionId === binding.sessionId &&
			sidecar.origin === binding.preview.url &&
			sidecar.buildDigest === binding.buildDigest &&
			sidecar.sourceDigest === binding.sourceDigest &&
			sidecar.adapterDigest === binding.adapterDigest &&
			sameProcess(helper, sidecar.helper) &&
			sameProcess(helper, await processIdentity(helper.pid)) &&
			sameProcess(sidecar.sidecar, await processIdentity(sidecar.sidecar.pid)),
		'SIDECAR_NOT_OWNED'
	);
	const children = (await fs.readFile(`/proc/${helper.pid}/task/${helper.pid}/children`, 'utf8'))
		.trim()
		.split(/\s+/)
		.filter(Boolean)
		.map(Number);
	let forwarding;
	for (const pid of children) {
		const identity = await processIdentity(pid);
		const args = identity?.command.split('\0').filter(Boolean) ?? [];
		if (
			JSON.stringify(args.slice(-3)) ===
			JSON.stringify(['serve', `--tcp=${binding.preview.public_port}`, `tcp://127.0.0.1:${binding.preview.local_port}`])
		)
			forwarding = identity;
	}
	requireThat(forwarding && sameProcess(helper, await processIdentity(helper.pid)), 'FORWARDING_NOT_OWNED');
	const forwardingPath = path.join(binding.runDirectory, 'forwarding.json');
	try {
		requireThat(sameProcess((await readJSON(forwardingPath)).identity, forwarding), 'FORWARDING_CHANGED');
	} catch (error) {
		if (error.code !== 'ENOENT') throw error;
		await writeJSON(forwardingPath, { identity: forwarding });
	}
	return { helper, sidecar, forwarding };
}
async function externalEndpoint(binding) {
	const response = await fetch(binding.preview.url + '/auth/login', {
		redirect: 'error',
		signal: AbortSignal.timeout(5000)
	});
	await response.body?.cancel();
	requireThat(response.ok && response.headers.get('X-T2T-1503-Session') === binding.sessionId, 'EXTERNAL_ENDPOINT');
}
async function serveState(port) {
	try {
		return servePortState(JSON.parse((await execute('tailscale', ['serve', 'status', '--json'])).stdout), port);
	} catch {
		throw Object.assign(new Error('SERVE_STATUS'), { code: 'SERVE_STATUS' });
	}
}
async function listenerOpen(port) {
	return new Promise((resolve) => {
		const socket = createConnection({ host: '127.0.0.1', port });
		const finish = (open) => {
			socket.destroy();
			resolve(open);
		};
		socket.once('connect', () => finish(true));
		socket.once('error', (error) => finish(error.code !== 'ECONNREFUSED'));
		socket.setTimeout(1000, () => finish(true));
	});
}
async function check(binding) {
	binding ??= await loadRun();
	const doctor = await checkpoint(binding);
	const { helper, sidecar, forwarding } = await runningProcesses(binding);
	await externalEndpoint(binding);
	const serve = await serveState(binding.preview.public_port);
	requireThat(serve.present && !serve.funnel, 'PRIVATE_SERVE_UNAVAILABLE');
	const receipt = {
		status: 'PASS',
		checkedAt: new Date().toISOString(),
		repository: binding.repository,
		worker: binding.worker,
		sessionId: binding.sessionId,
		candidate: binding.candidate,
		revision: binding.revision,
		primaryOrigin: doctor.origin,
		externalOrigin: binding.preview.url,
		sourceDigest: binding.sourceDigest,
		buildDigest: binding.buildDigest,
		adapterDigest: binding.adapterDigest,
		cookiePrefix: binding.cookiePrefix,
		nativeHTTPS: true,
		browserProviderRoute: false,
		sourceControlPreload: false,
		appCopy: binding.appCopy,
		supervisor: binding.supervisor,
		originalApp: binding.appProcess,
		starter: binding.starter,
		helper,
		forwarding,
		sidecar: sidecar.sidecar,
		localPort: binding.preview.local_port,
		publicPort: binding.preview.public_port
	};
	await writeJSON(path.join(binding.runDirectory, 'checkpoint.json'), receipt);
	return receipt;
}
async function start() {
	const binding = await admit();
	await fs.mkdir(scratch, { recursive: true, mode: 0o700 });
	await fs.chmod(scratch, 0o700);
	await fs.mkdir(leasePath, { mode: 0o700 });
	let child, spawnedHelper, helperLaunch, startupCode;
	try {
		binding.starter = await processIdentity(process.pid);
		binding.runDirectory = path.join(scratch, 'runs', binding.sessionId);
		await fs.mkdir(path.dirname(binding.runDirectory), { recursive: true, mode: 0o700 });
		await fs.mkdir(binding.runDirectory, { mode: 0o700 });
		const environment = await ownedEnvironment(binding);
		const helperArgs = ['--project', binding.appCopy];
		const launcher = await resolveExecutable('tailscale-preview', environment.PATH);
		helperLaunch = {
			launcher,
			script: await fs.realpath(launcher),
			envExecutable: await fs.realpath('/usr/bin/env'),
			pythonExecutable: await fs.realpath(await resolveExecutable('python3', environment.PATH)),
			args: [
				...helperArgs,
				'run',
				'tls',
				'--',
				process.execPath,
				path.join(scratch, 'sidecar.mjs'),
				path.join(binding.runDirectory, 'binding.json')
			]
		};
		binding.helperLaunch = helperLaunch;
		let allocation;
		try {
			allocation = JSON.parse((await execute(launcher, [...helperArgs, 'info'], { cwd: binding.appCopy })).stdout);
			await execute(launcher, [...helperArgs, 'cert'], { cwd: binding.appCopy });
		} catch {
			throw Object.assign(new Error('PREVIEW_HELPER'), { code: 'PREVIEW_HELPER' });
		}
		binding.preview = validatePreviewInfo(allocation, binding.appCopy);
		await checkpoint(binding);
		await writeJSON(path.join(binding.runDirectory, 'binding.json'), binding);
		await writeJSON(latestPath, { sessionId: binding.sessionId });
		const log = await fs.open(path.join(binding.runDirectory, 'private-helper.log'), 'a', 0o600);
		try {
			child = spawn(launcher, helperLaunch.args, {
				cwd: binding.appCopy,
				env: environment,
				stdio: ['ignore', log.fd, log.fd]
			});
			child.completion = new Promise((resolve, reject) => {
				child.once('exit', resolve);
				child.once('error', reject);
			});
			child.completion.catch(() => {});
		} finally {
			await log.close();
		}
		spawnedHelper = await processIdentity(child.pid);
		requireThat(spawnedHelper, 'HELPER_START');
		await writeJSON(path.join(binding.runDirectory, 'spawned-helper.json'), { identity: spawnedHelper });
		launchedHelper = await capturePreviewHelper(spawnedHelper, helperLaunch);
		await writeJSON(path.join(binding.runDirectory, 'helper.json'), { identity: launchedHelper });
		const deadline = Date.now() + 75000;
		for (;;) {
			requireThat(!interrupted && child.exitCode === null && !child.signalCode, 'PREVIEW_EXITED');
			try {
				await runningProcesses(binding);
				await externalEndpoint(binding);
				break;
			} catch {
				requireThat(Date.now() < deadline, 'PREVIEW_NOT_READY');
				await sleep(500);
			}
		}
		say(await check(binding));
		const exitCode = await child.completion;
		await writeJSON(path.join(binding.runDirectory, 'stopped.json'), {
			phase: 'stopped',
			exitCode,
			stoppedAt: new Date().toISOString(),
			sessionId: binding.sessionId,
			helperGone: !sameProcess(launchedHelper, await processIdentity(launchedHelper.pid))
		});
		process.exitCode = exitCode === 0 || exitCode === 130 || interrupted ? 0 : 2;
	} catch (error) {
		startupCode = safeStartupCode(error);
	}
	await finishOwnedCleanup(
		startupCode,
		[
			async () => {
				if (binding.runDirectory) {
					try {
						await stopOwnedProcess((await readJSON(path.join(binding.runDirectory, 'forwarding.json'))).identity);
					} catch (error) {
						if (error.code !== 'ENOENT') throw error;
					}
				}
			},
			async () => {
				if (launchedHelper) await stopOwnedProcess(launchedHelper);
				else if (spawnedHelper) await reconcileSpawnedHelper(spawnedHelper, helperLaunch);
			}
		],
		() =>
			fs.rmdir(leasePath).catch((error) => {
				if (error.code !== 'ENOENT') throw error;
			})
	);
}
async function stop() {
	const binding = await loadRun();
	let helper, sidecar, forwarding, spawned;
	try {
		helper = (await readJSON(path.join(binding.runDirectory, 'helper.json'))).identity;
	} catch (error) {
		if (error.code !== 'ENOENT') throw error;
	}
	try {
		sidecar = (await readJSON(path.join(binding.runDirectory, 'sidecar.json'))).sidecar;
	} catch (error) {
		if (error.code !== 'ENOENT') throw error;
	}
	try {
		forwarding = (await readJSON(path.join(binding.runDirectory, 'forwarding.json'))).identity;
	} catch (error) {
		if (error.code !== 'ENOENT') throw error;
	}
	await finishOwnedCleanup(null, [
		() => stopOwnedProcess(forwarding),
		async () => {
			if (helper) await stopOwnedProcess(helper);
			else {
				try {
					spawned = (await readJSON(path.join(binding.runDirectory, 'spawned-helper.json'))).identity;
				} catch (error) {
					if (error.code !== 'ENOENT') throw error;
				}
				if (spawned) await reconcileSpawnedHelper(spawned, binding.helperLaunch);
			}
		},
		() => stopOwnedProcess(sidecar),
		() => stopOwnedProcess(binding.starter)
	]);
	const spawnedRemaining = spawned && (await processIdentity(spawned.pid));
	requireThat(
		!sameProcess(helper, helper && (await processIdentity(helper.pid))) &&
			!sameProcess(sidecar, sidecar && (await processIdentity(sidecar.pid))) &&
			!sameProcess(forwarding, forwarding && (await processIdentity(forwarding.pid))) &&
			(!spawnedRemaining || spawnedRemaining.state === 'Z' || spawnedRemaining.start !== spawned.start),
		'CLEANUP_INCOMPLETE'
	);
	for (const name of ['carrier.json', 'private-navigate.json', 'private-fill.json'])
		await fs.unlink(path.join(binding.runDirectory, name)).catch((error) => {
			if (error.code !== 'ENOENT') throw error;
		});
	await fs.rmdir(leasePath).catch((error) => {
		if (error.code !== 'ENOENT') throw error;
	});
	const serve = await serveState(binding.preview.public_port);
	requireThat(
		!serve.present && !serve.funnel && !(await listenerOpen(binding.preview.local_port)),
		'TRANSPORT_RESOURCES_REMAIN'
	);
	return {
		status: 'PASS',
		phase: 'stopped',
		sessionId: binding.sessionId,
		helperGone: true,
		sidecarGone: true,
		forwardingGone: true,
		publicPort: binding.preview.public_port,
		localPort: binding.preview.local_port,
		localListenerGone: true,
		serveMappingGone: true
	};
}
async function stage() {
	const binding = await loadRun();
	await check(binding);
	const capability = randomBytes(32).toString('hex');
	const expiresAt = Date.now() + 120000;
	await writeJSON(path.join(binding.runDirectory, 'carrier.json'), {
		sessionId: binding.sessionId,
		role: 'orgOwner',
		capability,
		expiresAt
	});
	await writeJSON(path.join(binding.runDirectory, 'private-navigate.json'), {
		expression: `location.replace(${JSON.stringify(binding.preview.url + '/__t2t_1503_fill/' + capability)})`
	});
	await writeJSON(path.join(binding.runDirectory, 'private-fill.json'), {
		expression: `(() => {
			const raw = window.name; window.name = '';
			let actor; try { actor = JSON.parse(raw); } catch { return { filled: false }; }
			const email = document.querySelector('#email'), password = document.querySelector('#password');
			if (!email || !password || location.pathname !== '/auth/login' ||
				location.origin !== ${JSON.stringify(binding.preview.url)}) return { filled: false };
			for (const [element, value] of [[email, actor.email], [password, actor.password]]) {
				Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(element, value);
				element.dispatchEvent(new Event('input', { bubbles: true }));
				element.dispatchEvent(new Event('change', { bubbles: true }));
			}
			actor = null; return { filled: Boolean(email.value && password.value), carrierCleared: window.name === '' };
		})()`
	});
	return {
		status: 'PASS',
		role: 'orgOwner',
		expiresAt,
		privateRunDirectory: binding.runDirectory,
		note: 'At this origin’s visible login page, read private-navigate.json in memory; exclude its capability from public captures. Then read private-fill.json, fill only, and click Sign In natively.'
	};
}

try {
	requireThat(process.argv.length <= 3, 'ARGUMENTS');
	if (command === 'help')
		console.log(
			'Scratch 1503 Mac transport: node .verification/mac-preview-1503/command.mjs start|check|stage|stop\nFixed owned worker 1. Start stays foreground. No app build/provider/browser launch. See README.md.'
		);
	else if (command === 'start') await start();
	else if (command === 'check') say(await check());
	else if (command === 'stage') say(await stage());
	else if (command === 'stop') say(await stop());
	else requireThat(false, 'COMMAND');
} catch (error) {
	const receipt = { status: 'BLOCKED', code: safeStartupCode(error) };
	if (error?.startupCode) receipt.startupCode = error.startupCode;
	if (error?.cleanupCodes) receipt.cleanupCodes = error.cleanupCodes;
	say(receipt);
	process.exitCode = 2;
}
