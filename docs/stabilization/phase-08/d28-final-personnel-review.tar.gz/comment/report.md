# Final D28 comment review

For the next maintainer, four scoped comment deletions remove narration while four fixture API comments retain their operation semantics. No application edits were performed.

The base is `ad0cea51e9b790d27c794f47ac8a80bf471a6ff9`. The review covers the WIP diff and actual new source files in the supplied 82-path inventory. There are 61 existing source files, 12 prose or configuration files, seven removed source files, and two binary evidence archives. The current source scanner found 45 comment blocks. Eight intersect added lines or belong to new files. The remaining 37 blocks are unchanged context.

Proposed deletion count is **4 comment blocks, 15 source lines**. Performed deletion count is **0**. There are **4 justified keeps, 5 source lines**. There are **0 MUST KILL flags** and **0 scoped suppressions**. These are comment-policy judgments. This review establishes no application behavior defect.

## Proposed deletions

### C1 at `src/lib/server/adapters/inMemory.ts:28`

The proposed deletion includes lines 28 through 39. The edited block is a module banner and export inventory. It is detached from a public declaration and repeats names, return types, and fixture setup. It does not define a public operation contract or a foreign constraint.

Exact source text follows.

```ts
/**
 * In-memory implementations of all port interfaces, used in unit and integration tests.
 *
 * Key exports:
 * - `createInMemoryDataStore()` — FixtureRowStore with a `.seed(table, rows)` method for
 *   pre-populating test data. Supports filters, sorting, pagination, and range filters.
 * - Individual port builders (`createTestAuthContext`, `createTestAuditPort`, etc.) for
 *   tests that only need specific ports.
 *
 * Group scoping works automatically from `auth.scopeSet`. Critical Tasks latest-read
 * consumers supply their owned adapter through `criticalTasksReadModelFactory`.
 */
```

### C2 at `src/lib/server/adapters/test-support/inMemoryRows.types.ts:10`

The proposed deletion includes lines 10 through 10. The comment labels the rangeFilters property and repeats its declared comparison operators. It does not define bounds, coercion, or another API guarantee. The public-contract exception does not protect a property label.

Exact source text follows.

```ts
	/** Range filters for date/numeric queries */
```

### C3 at `src/lib/server/adapters/test-support/scopedFixtureRows.ts:147`

The proposed deletion includes lines 147 through 147. The following bindings directly show every write operation passing through to inner. This is narration of visible code. No foreign constraint or public contract applies.

Exact source text follows.

```ts
		// Write operations pass through unchanged
```

### C4 at `src/lib/storage/contracts.ts:1`

The proposed deletion includes lines 1 through 1. The interface name and methods already identify the abstraction. The import claim describes the project architecture rather than the behavior promised by StoragePort. No issue link, foreign constraint, or operation contract applies.

Exact source text follows.

```ts
/** Abstracts file storage operations — business logic never imports Supabase storage */
```

## Justified keeps

These are doc comments on the module's exported fixture API. The public API contract exception applies to callers of that module. This does not claim that the fixture API is a production provider boundary.

### K1 at `src/lib/server/adapters/test-support/inMemoryRows.types.ts:8`

`FixtureFindOptions.isNull` qualifies as a public API contract. The boolean value selects NULL versus NOT NULL. That meaning is absent from Record<string, boolean>. The implementation at src/lib/server/adapters/inMemory.ts:484 tests shouldBeNull and chooses row[key] == null versus row[key] != null. This proves the stated caller contract.

Exact source text follows.

```ts
	/** Null-check filters: { archived_at: true } means IS NULL, false means IS NOT NULL */
```

### K2 at `src/lib/server/adapters/test-support/inMemoryRows.types.ts:12`

`FixtureFindOptions.ilikeFilters` qualifies as a public API contract. The comment specifies case-insensitive LIKE matching and shows the accepted percent wildcard. Record<string, string> does not encode that string grammar. The implementation at src/lib/server/adapters/inMemory.ts:492 translates percent and underscore, then creates a regex with the i flag. This proves the stated wildcard and case behavior for the shown pattern. This review does not certify complete SQL LIKE equivalence.

Exact source text follows.

```ts
	/** Case-insensitive LIKE filters: { title: '%search%' } */
```

### K3 at `src/lib/server/adapters/test-support/inMemoryRows.types.ts:14`

`FixtureFindOptions.range` qualifies as a public API contract. The comment defines zero-based indices and an inclusive upper bound. The number fields do not encode either convention. The implementation at src/lib/server/adapters/inMemory.ts:541 passes range.from and range.to + 1 to Array.slice. This proves the caller contract.

Exact source text follows.

```ts
	/** Pagination range (0-indexed, inclusive) */
```

### K4 at `src/lib/server/adapters/test-support/inMemoryRows.types.ts:42`

`FixtureRowStore.updateById` qualifies as a public API contract. The comment defines primary-key-only selection and explicitly excludes organization_id scoping. The implementation at src/lib/server/adapters/inMemory.ts:639 selects a row by row.id alone. It contrasts with update at line 628, which includes the organization column. The exported fixture method documents its actual selection contract. No production authorization bypass is alleged.

Exact source text follows.

```ts
	/** Update a row by primary key only, without organization_id scoping.
	 *  Use for tables like `organizations` where the row IS the org. */
```

## Suppression audit

The full current source inventory and prose/configuration inventory contain no `eslint-disable`, `@ts-ignore`, `@ts-expect-error`, `@ts-nocheck`, `svelte-ignore`, `prettier-ignore`, `istanbul ignore`, or `c8 ignore` directive. No rule lookup or suppression disposition is required. No scoped IMPORTANT or do-not-remove claim required further tracing.

## Scope and skips

The seven removed source files are not new refactor scope. Their comments disappear with their existing removals. The two `.tar.gz` evidence files are binary archives and were not opened as source. Markdown prose and JSON configuration were scanned for embedded comment or suppression directives. Their substantive prose is outside this comment review. The 37 unchanged source comment blocks are not proposed deletions or new refactor targets.

No code reshape is requested. The proposed deletions narrate visible code or structure. None establishes an in-scope own-code surprise that requires a MUST KILL target. The kept updateById selection semantics are intentional exported fixture API behavior and are not a guilty symbol.

## Execution receipt

The review used the generic-agent portable Comment Sicko persona. It remained read-only for source, docs, and tests. The only write is this report in the exclusive scratch directory. No app, database, test service, build, network, connector, GitHub operation, commit, or PR operation ran. Private originals and credentials were not opened.

The parent reported that the native app was closed and saved evidence accepted before dispatch. This review does not independently claim native app execution or runtime verification. The parent owns all dispositions, repairs, and current-head checks.

The model and effort are inherited. Their exact served values were not exposed to this worker. Fast tier is unverified. Inherited model selection is not model diversity. No children were spawned. The how and no-comments skills were read. Their nested-delegation and application-edit steps were skipped because the parent explicitly forbids both. The report uses the parent's required finding format instead of the Investigation playbook's default explanation shape.

Type System Discipline shaped the API-comment judgments. The boolean interpretation, wildcard grammar, and inclusive index convention are not represented by the declared scalar types. Prove It Works shaped verification. Each keep was checked against the actual implementation, and exact source text supplied every finding. Build the Lever shaped coverage. A repeatable TypeScript scanner replaced a line-pattern-only comment scan. Parent report-only ownership prevents a separate helper file, so the scanner is included below. Unslop and technical-writing shaped the report prose.

throughput checkpoint: n/a, read-only investigation.

## Coverage reproduction

Run the following read-only scanner from the repository root. It uses the installed TypeScript package and the parent's supplied inventory. It does not start services or write files. At this reviewed WIP state, it returns 45 source comment blocks and eight touched blocks.

```sh
node - <<'JS'
const ts = require('typescript');
const fs = require('fs');
const cp = require('child_process');
const paths = JSON.parse(fs.readFileSync('/home/waffleflops/.cache/t2t-1376-final-personnel-implementation-ad0cea51-20261008/comment-review-paths.json', 'utf8'));
let blocks = 0;
let touched = 0;
for (const path of paths) {
	if (!/\.(ts|mjs)$/.test(path) || !fs.existsSync(path)) continue;
	const source = fs.readFileSync(path, 'utf8');
	const diff = cp.execFileSync('git', ['diff', '--unified=0', 'ad0cea51e9b790d27c794f47ac8a80bf471a6ff9', '--', path], { encoding: 'utf8' });
	const tracked = cp.spawnSync('git', ['ls-files', '--error-unmatch', path], { stdio: 'ignore' }).status === 0;
	const added = new Set();
	for (const match of diff.matchAll(/^@@ -[^ ]+ \+(\d+)(?:,(\d+))? @@/gm)) {
		const start = Number(match[1]);
		const count = match[2] === undefined ? 1 : Number(match[2]);
		for (let line = start; line < start + count; line++) added.add(line);
	}
	const scanner = ts.createScanner(ts.ScriptTarget.Latest, false, ts.LanguageVariant.Standard, source);
	for (let token = scanner.scan(); token !== ts.SyntaxKind.EndOfFileToken; token = scanner.scan()) {
		if (token !== ts.SyntaxKind.SingleLineCommentTrivia && token !== ts.SyntaxKind.MultiLineCommentTrivia) continue;
		blocks++;
		const start = source.slice(0, scanner.getTokenPos()).split('\n').length;
		const text = scanner.getTokenText();
		const end = start + text.split('\n').length - 1;
		const changed = !tracked || Array.from({ length: end - start + 1 }, (_, index) => start + index).some(line => added.has(line));
		if (changed) {
			touched++;
			process.stdout.write(`${path}:${start}-${end}\n${text}\n\n`);
		}
	}
}
process.stdout.write(`ALL_SOURCE_COMMENT_BLOCKS ${blocks}\nTOUCHED_COMMENT_BLOCKS ${touched}\n`);
JS
```

## Supplied path inventory

Every supplied path appears below with its coverage classification.

- `.agents/skills/verify-trooptotask/features/personnel-records-lifecycle.md`. prose/configuration, embedded directive scan.
- `.agents/skills/verify-trooptotask/helpers/artifact-http.mjs`. source, comment and suppression scan.
- `.agents/skills/verify-trooptotask/helpers/artifact-http.test.mjs`. source, comment and suppression scan.
- `docs/architecture/ARCHITECTURE.md`. prose/configuration, embedded directive scan.
- `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md`. prose/configuration, embedded directive scan.
- `docs/architecture/CURRENT_OWNERSHIP.md`. prose/configuration, embedded directive scan.
- `docs/architecture/DRIFT_LEDGER.md`. prose/configuration, embedded directive scan.
- `docs/architecture/GOVERNANCE_BASELINE.json`. prose/configuration, embedded directive scan.
- `docs/architecture/adrs/0004-v1-provider-boundary-contract.md`. prose/configuration, embedded directive scan.
- `docs/stabilization/EVIDENCE.md`. prose/configuration, embedded directive scan.
- `docs/stabilization/TODO.md`. prose/configuration, embedded directive scan.
- `docs/stabilization/phase-08/d28-final-persistence-baseline-recovery.tar.gz`. binary evidence, skipped.
- `docs/stabilization/phase-08/d28-final-persistence-baseline.tar.gz`. binary evidence, skipped.
- `docs/stabilization/phase-08/d28-final-personnel-persistence.md`. prose/configuration, embedded directive scan.
- `docs/stabilization/phase-08/d28-residual-settings-persistence.md`. prose/configuration, embedded directive scan.
- `scripts/check-governance.mjs`. source, comment and suppression scan.
- `scripts/module-boundaries.json`. prose/configuration, embedded directive scan.
- `src/features/critical-tasks/server/criticalTasksReadPorts.server.ts`. source, comment and suppression scan.
- `src/features/critical-tasks/server/criticalTasksReportsQuery.server.ts`. source, comment and suppression scan.
- `src/features/critical-tasks/server/inMemoryCriticalTasksReadModel.server.ts`. source, comment and suppression scan.
- `src/features/onboarding/server/onboardingPersistence.test-support.server.ts`. source, comment and suppression scan.
- `src/features/personnel/artifactWrites.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/artifactWrites.server.ts`. source, comment and suppression scan.
- `src/features/personnel/awardTracking.server.ts`. source, comment and suppression scan.
- `src/features/personnel/contracts.ts`. source, comment and suppression scan.
- `src/features/personnel/fileUploadLifetime.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/index.server.ts`. source, comment and suppression scan.
- `src/features/personnel/leaderNotes.server.ts`. source, comment and suppression scan.
- `src/features/personnel/leaderNotes.testHelper.ts`. source, comment and suppression scan.
- `src/features/personnel/ordinaryExportRead.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/ordinaryExportRead.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelArchiveCascade.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelArtifactContext.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelArtifactPersistence.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelArtifactRow.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelCounselingRecords.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelDocuments.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelExport.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelExtendedInfo.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelFollowUps.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelLifecycle.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelOwnedPersistence.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelPersistence.test-support.server.ts`. source, comment and suppression scan.
- `src/features/personnel/personnelSheetPersistence.ts`. source, comment and suppression scan.
- `src/features/personnel/rankCatalogOperations.server.test.ts`. source, comment and suppression scan.
- `src/features/personnel/rankCatalogOperations.server.ts`. source, comment and suppression scan.
- `src/features/personnel/rankCatalogPersistence.ts`. source, comment and suppression scan.
- `src/features/personnel/rankCatalogSeed.server.ts`. source, comment and suppression scan.
- `src/features/personnel/supabasePersonnelArtifactReadPersistence.server.ts`. source, comment and suppression scan.
- `src/features/personnel/supabasePersonnelSheetPersistence.server.ts`. source, comment and suppression scan.
- `src/features/personnel/supabaseRankCatalogPersistence.server.ts`. source, comment and suppression scan.
- `src/features/personnel/test-support/personnelProvider.server.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/dashboardRequestContext.server.test.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/featureRequestContexts.server.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/inMemory.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/membershipAdmission.test.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/persistenceContract.test.ts`. removed source, skipped.
- `src/lib/server/adapters/personnelArtifacts.test.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/personnelLeaderNotes.test.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/requestContexts.server.test.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/requestContexts.server.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/scopeRules.ts`. removed source, skipped.
- `src/lib/server/adapters/scopedDataStore.test.ts`. removed source, skipped.
- `src/lib/server/adapters/scopedDataStore.ts`. removed source, skipped.
- `src/lib/server/adapters/supabaseDataStore.test.ts`. removed source, skipped.
- `src/lib/server/adapters/supabaseDataStore.ts`. removed source, skipped.
- `src/lib/server/adapters/supabaseStorage.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/test-support/fixtureScopeRules.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/test-support/inMemoryRows.types.ts`. source, comment and suppression scan.
- `src/lib/server/adapters/test-support/scopedFixtureRows.ts`. source, comment and suppression scan.
- `src/lib/server/core/ports.ts`. removed source, skipped.
- `src/lib/server/core/useCases/calendarScope.ts`. source, comment and suppression scan.
- `src/lib/server/personnelArchiveBatchDelivery.test.ts`. source, comment and suppression scan.
- `src/lib/storage/contracts.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/deletion-requests/+server.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/getting-started/+server.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.test.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/personnel/batch/server.test.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/sign-in-rosters/rosterTestContexts.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/api/starter-configuration-packs/[packId]/apply/server.test.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/personnel/[personnelSlug]/page.server.test.ts`. source, comment and suppression scan.
- `src/routes/org/[orgId]/settings/settingsRequestContexts.server.ts`. source, comment and suppression scan.
