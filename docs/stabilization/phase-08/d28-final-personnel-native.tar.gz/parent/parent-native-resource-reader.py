import argparse, hashlib, json, re, subprocess
from pathlib import Path
p = argparse.ArgumentParser()
p.add_argument('raw',type=Path)
p.add_argument('private_preflight',type=Path)
a = p.parse_args()
def output(cmd):return subprocess.check_output(cmd,text=True)
def signature(x):
    return {k:x[k] for k in ['Id','Name','Created','Config','HostConfig']} | {'Mounts':sorted(x['Mounts'],key=lambda m:m['Destination']),'Pid':x['State']['Pid'],'StartedAt':x['State']['StartedAt'],'Networks':x['NetworkSettings']['Networks']}
def digest(x):return hashlib.sha256(json.dumps(signature(x),sort_keys=True,separators=(',',':')).encode()).hexdigest()
owned=json.loads((a.raw/'precleanup-owned-resources.json').read_text())
assert len(owned['ownedGroupMembers']) == 21 and len(owned['ports']) == 9 and len(owned['ownedContainers']) == 5
for x in owned['ownedGroupMembers']:assert not (Path('/proc')/str(x['pid'])).exists(), x['pid']
listeners=output(['ss','-ltnp'])
for port in owned['ports']:assert not re.search(':'+str(port)+r'\s',listeners),port
ids=output(['docker','ps','-aq']).split()
cs=json.loads(output(['docker','inspect',*ids])) if ids else []
before=json.loads((a.private_preflight/'preexisting-container-inspect.json').read_text())
bm,cm={x['Id']:x for x in before},{x['Id']:x for x in cs}
assert len(bm) == 41 and bm.keys() == cm.keys()
pairs=[]
for identity,x in bm.items():
    assert signature(x) == signature(cm[identity]),identity
    pairs.append({'id':identity,'beforeSHA256':digest(x),'afterSHA256':digest(cm[identity])})
for x in owned['ownedContainers']:assert x['Id'] not in cm
sets={}
for kind,cmd in [('networks',['docker','network','ls','--no-trunc','--format','{{json .}}']),('volumes',['docker','volume','ls','--format','{{json .}}'])]:
    previous=[json.loads(l) for l in (a.private_preflight/('pre-'+kind+'.jsonl')).read_text().splitlines()]
    current=[json.loads(l) for l in output(cmd).splitlines()]
    assert sorted(previous,key=str) == sorted(current,key=str)
    sets[kind]=len(current)
network_ids=output(['docker','network','ls','--no-trunc','-q']).split()
volume_names=output(['docker','volume','ls','-q']).split()
assert not set(owned['ownedNetworks']) & set(network_ids)
assert not set(owned['ownedVolumes']) & set(volume_names)
assert not Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1').exists()
def endpoints(s):return sorted({line.split()[3] for line in s.splitlines()[1:] if len(line.split())>3})
assert endpoints((a.private_preflight/'pre-listeners.txt').read_text()) == endpoints(listeners)
assert sets == {'networks':7,'volumes':17}
print(json.dumps({'status':'PASS','numericPIDPathsAbsent':21,'ownedPortsAbsent':9,'ownedContainersAbsent':5,'ownedNetworkAbsent':1,'ownedVolumesAbsent':2,'workerDirectoryAbsent':True,'exactPreexistingContainerSet':41,'completeContainerSignatures':pairs,'exactPreexistingSets':sets,'exactTCPendpoints':len(endpoints(listeners)),'privateEnvNotEmitted':True},indent=2))
