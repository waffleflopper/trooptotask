import fs from 'node:fs/promises';
import path from 'node:path';
import { createClient } from '@supabase/supabase-js';
import { repository, sessionPath, readJSON } from '../../../../scripts/verification/core.mjs';
import { selectAllSupabaseRows } from '../../../../src/lib/server/supabasePagination.server.ts';
const session=sessionPath('1');
const state=await readJSON(path.join(session,'session.json'));
if(state.repository!==repository || state.phase!=='running') throw new Error('Owned running worker required');
const config=await readJSON(path.join(session,'provider.json'));
const target=new URL(config.API_URL);
if(target.protocol!=='http:' || target.hostname!=='127.0.0.1') throw new Error('Owned loopback provider required');
const seed=await readJSON(path.join(repository,'.verification/evidence/verify-trooptotask/retention-baseline/seed-1001.json'));
const orgId=seed.retained.find(p=>p.last_name.endsWith('active')).organization_id;
const requests=[];
const client=createClient(config.API_URL,config.SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false},global:{fetch:async(input,init)=>{
 const url=new URL(typeof input==='string'?input:input instanceof URL?input.href:input.url);
 const response=await fetch(input,init);
 requests.push({method:init?.method??'GET',table:url.pathname.split('/').at(-1),status:response.status,urlBytes:Buffer.byteLength(url.href),organizationScoped:url.searchParams.get('organization_id')==='eq.'+orgId});
 return response;
}}});
const read=()=>selectAllSupabaseRows((from,to)=>client.from('personnel').select('id,archived_at').eq('organization_id',orgId).lt('archived_at','2001-01-01T00:00:00Z').order('id').range(from,to));
const before=await read();
if(before.length!==1001 || before.some(p=>!seed.expiredIds.includes(p.id))) throw new Error('Exact owned large fixture required');
// Mirrors the existing adapter's actual SDK request, without changing application source.
const result=await client.from('personnel').delete().eq('organization_id',orgId).in('id',seed.expiredIds).select('id');
const after=await read();
const output={scope:'direct existing SDK deletion shape, provider proof only; no application cron success claim',revision:state.revision,candidate:state.candidate,before,mutation:{status:result.status,error:result.error,returnedCount:result.data?.length??null},after,requests};
await fs.writeFile(path.join(repository,'.verification/evidence/verify-trooptotask/retention-baseline/direct-large-delete.json'),JSON.stringify(output,null,2)+'\n');
process.stdout.write(JSON.stringify({before:before.length,mutation:output.mutation,after:after.length,requests},null,2)+'\n');
