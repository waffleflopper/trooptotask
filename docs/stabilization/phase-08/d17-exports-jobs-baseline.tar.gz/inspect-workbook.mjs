import fs from 'node:fs/promises';
import path from 'node:path';
import ExcelJS from 'exceljs';
const dir=path.dirname(new URL(import.meta.url).pathname);
const workbook=new ExcelJS.Workbook();await workbook.xlsx.readFile(path.join(dir,'owner.xlsx'));
const parsed={sheets:[]};
for(const sheet of workbook.worksheets){const rows=[];sheet.eachRow({includeEmpty:false},row=>rows.push(row.values.slice(1)));parsed.sheets.push({name:sheet.name,rows});}
await fs.writeFile(path.join(dir,'owner-workbook-decoded.json'),JSON.stringify(parsed,null,2)+'\n');
const fixture=JSON.parse(await fs.readFile(path.join(dir,'fixture.stdout'),'utf8'));
for(const id of [fixture.ids.orgB,fixture.ids.personForeign,fixture.ids.groupForeign,fixture.ids.onboardingForeignTemplate])if(JSON.stringify(parsed).includes(id))throw new Error('Foreign sentinel in workbook: '+id);
console.log(JSON.stringify({decodedSheets:parsed.sheets.length,foreignKnownSentinelsExcluded:true,rawOrganizationSheets:parsed.sheets.filter(s=>s.name.startsWith('Raw - Organization')).map(s=>({name:s.name,dataRows:s.rows.length-1}))},null,2));
