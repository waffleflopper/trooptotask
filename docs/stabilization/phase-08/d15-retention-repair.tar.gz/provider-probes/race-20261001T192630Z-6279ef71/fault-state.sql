SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'function', (SELECT json_build_object('marker', obj_description(p.oid, 'pg_proc')) FROM pg_proc p
              JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public' AND p.proname = 't2t_d15_parent_delete_fault_21332722' AND p.pronargs = 0),
 'trigger', (SELECT json_build_object('marker', obj_description(t.oid, 'pg_trigger')) FROM pg_trigger t
             WHERE t.tgrelid = 'public.personnel_onboardings'::regclass AND t.tgname = 't2t_d15_parent_delete_fault_21332722' AND NOT t.tgisinternal),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger t WHERE t.tgrelid = 'public.personnel_onboardings'::regclass
                         AND t.tgname LIKE 't2t_d15_parent_delete_fault_%' AND NOT t.tgisinternal));
