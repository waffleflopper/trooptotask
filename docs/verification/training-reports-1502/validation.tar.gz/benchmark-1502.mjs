import { createServer } from 'vite';
import { performance } from 'node:perf_hooks';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

const before = process.argv.includes('--before-concentration-fix');
const source = readFileSync('src/features/training/utils/trainingBriefing.ts', 'utf8');
const countPass = `	const counts = new Map<string, number>();
	for (const entry of entries) {
		const key = entry.requirement.rowKey;
		counts.set(key, (counts.get(key) ?? 0) + 1);
	}
`;
if (!source.includes(countPass)) throw new Error('Concentration count pass changed');
const projectedSource = source.replace(countPass, '').replace('count: counts.get(row.key) ?? 0', 'count: entries.filter((entry) => entry.requirement.rowKey === row.key).length');
console.log(JSON.stringify({ mode: before ? 'pre-fix source projection' : 'final source', sourceSha256: createHash('sha256').update(before ? projectedSource : source).digest('hex'), node: process.version }));
const server = await createServer({ server: { middlewareMode: true }, appType: 'custom', plugins: [{
	name: 'owned-concentration-before-probe', enforce: 'pre',
	transform(code, id) {
		if (before && id.endsWith('/trainingBriefing.ts')) return projectedSource;
	}
}] });
try {
	const { buildTrainingBriefing } = await server.ssrLoadModule('/src/features/training/utils/trainingBriefing.ts');
	for (const [people, types, groups, distinctRoles] of [[150, 20, 6, false], [4000, 25, 50, false], [2048, 20, 50, true]]) {
		const personnel = Array.from({ length: people }, (_, index) => ({
			id: `p${index}`, rank: 'SGT', lastName: `Person${index}`, firstName: 'Synthetic',
			mos: `MOS${index % 20}`, clinicRole: `Role${distinctRoles ? index : index % 10}`,
			groupId: `g${index % groups}`, groupName: `Group${index % groups}`
		}));
		const selectedTypes = Array.from({ length: types }, (_, index) => ({
			id: `t${index}`, name: `Training${index}`, description: null, expirationMonths: 12,
			warningDaysYellow: 60, warningDaysOrange: 30, appliesToRoles: [], appliesToMos: [], appliesToRanks: [],
			excludedRoles: [], excludedMos: [], excludedRanks: [], color: '#000000', sortOrder: index,
			expirationDateOnly: false, canBeExempted: false, exemptPersonnelIds: [], isOptional: false
		}));
		const records = distinctRoles ? [] : personnel.flatMap((person, personIndex) => selectedTypes.flatMap((type, typeIndex) => {
			if ((personIndex + typeIndex) % 10 === 0) return [];
			return [{ id: `r${personIndex}-${typeIndex}`, personnelId: person.id, trainingTypeId: type.id,
				completionDate: '2025-09-29', expirationDate: (personIndex + typeIndex) % 3 === 0 ? '2026-10-22' : '2027-09-29',
				notes: null, certificateUrl: null }];
		}));
		const input = { personnel, types: selectedTypes, records, filters: {}, horizonDays: 180,
			asOf: '2026-09-29', goalPercent: 90, rowsBy: distinctRoles ? 'role' : 'group', scopeName: 'Synthetic benchmark' };
		for (let warmup = 0; warmup < 2; warmup++) buildTrainingBriefing(input);
		const samples = [];
		let model;
		for (let sample = 0; sample < 5; sample++) {
			const start = performance.now();
			model = buildTrainingBriefing(input);
			samples.push(Number((performance.now() - start).toFixed(2)));
		}
		const sorted = [...samples].sort((a, b) => a - b);
		console.log(JSON.stringify({ people, types, groups, distinctRoles, applicable: model.bottomLine.today.applicable,
			ready: model.bottomLine.today.ready, lapsing: model.bottomLine.lapsing, horizonDays: 180,
			milliseconds: samples, medianMs: sorted[2], serializedBytes: Buffer.byteLength(JSON.stringify(model)) }));
	}
} finally {
	await server.close();
}
