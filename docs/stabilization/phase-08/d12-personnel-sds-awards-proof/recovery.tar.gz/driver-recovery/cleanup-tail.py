import json,re
from pathlib import Path
from flow import call,tool,snapshot,shot,base
from http import flags
seed=json.loads((base/'seed-lifecycle.json').read_text());page=json.loads((base/'owner-page.json').read_text())['pageId']
s=snapshot('tail-roster-link-before',page);m=re.findall(r'uid=([^ ]+) link "Personnel" ',s)
assert len(m)==1,m
tool('tail-roster-link-open','click',{'pageId':page,'uid':m[0]});tool('tail-roster-native-settled','wait_for',{'pageId':page,'text':['Add Person'],'timeout':15000})
s=snapshot('tail-roster-native-after',page);shot('tail-roster-native-after',page)
assert '/personnel"' in s and 'Able, Synthetic' in s and 'Baker, Synthetic' in s and seed['name'] not in s
f=flags('tail-roster-cleared-ack-ids',page);assert any(m['ids']==[] for m in f['matches'])
tool('tail-roster-confirm-reload','navigate_page',{'pageId':page,'type':'reload'});tool('tail-roster-reload-settled','wait_for',{'pageId':page,'text':['Add Person'],'timeout':15000})
s=snapshot('tail-roster-reload-after',page);shot('tail-roster-reload-after',page);assert 'Able, Synthetic' in s and 'Baker, Synthetic' in s and seed['name'] not in s
(base/'native-restored-roster-check.json').write_text(json.dumps({'result':'PASS','observations':['Native Personnel link plus explicit Add Person settling wait reaches actual /personnel roster with original Able/Baker and no seeded Person','Same native roster after reload','Actual public acknowledgement ID projection empty after clear/seed cleanup'],'priorScratchFailure':'final-restoration-cleanup-command.json/.log/.stderr and original finish.py preserved. tail-native-original-roster snapshot is Dashboard, not roster; initial consumer-native-roster snapshot also Dashboard after prior native link. Earlier roster-arrival wording is superseded by this actual settled /personnel proof; actual switch actor roster screenshots remain separate valid evidence.','appChanges':False},indent=2)+'\n')
call('final-doctor-after-seed-cleanup','app','doctor')
info=json.loads((base/'info.json').read_text());state=json.loads((Path(info['session'])/'session.json').read_text());public={k:{x:v for x,v in state.get(k,{}).items() if x in ['pid','start','state']} for k in ['supervisor','appProcess','mcpProcess','browserProcess']};(base/'owned-processes-before-disposal.json').write_text(json.dumps(public,indent=2)+'\n')
call('owned-cleanup','app','cleanup')
