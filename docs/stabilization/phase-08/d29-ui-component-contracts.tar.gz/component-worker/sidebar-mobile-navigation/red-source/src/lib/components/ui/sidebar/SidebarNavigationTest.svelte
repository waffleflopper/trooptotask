<script lang="ts">
	import * as Sidebar from './index.js';
	import SidebarNavigationContent from './SidebarNavigationContent.svelte';

	let { cancelNavigation = false }: { cancelNavigation?: boolean } = $props();
</script>

<Sidebar.Provider>
	<SidebarNavigationContent {cancelNavigation} />
</Sidebar.Provider>
