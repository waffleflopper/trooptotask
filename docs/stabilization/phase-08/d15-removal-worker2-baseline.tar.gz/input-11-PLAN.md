# Worker 2 removal provider baseline: frozen driving selection

Preparation revision: `696875aa743fed288ce9cb4895b53e65006c3a77` (root application
unchanged from merged #1484). Worker 2 runs in the same frozen coordinator
checkout, with its separate owned worker directory/provider/browser. Do not
switch its shared HEAD/branch; preserve all older branches and evidence. Only
repo verify:app native browser/control commands and
the accepted provider helper may execute after coordinator go. No product edits,
fixture edits, schema changes, migration, production or maintenance database.

## Inputs and launch

These ignored recorder sources and this plan remain in this frozen checkout's
`.verification/tmp/d15-removal-provider/` directory. On the exact clean prep
revision, set `D15_EVIDENCE=d15-removal-worker2-baseline`,
`TMPDIR=/home/waffleflops/.cache/t2t-d15-tmp`, `PYTHONDONTWRITEBYTECODE=1`.

```
python3 .verification/tmp/d15-removal-provider/drive.py freeze prelaunch 696875aa743fed288ce9cb4895b53e65006c3a77
python3 .verification/tmp/d15-removal-provider/drive.py app info info
python3 .verification/tmp/d15-removal-provider/drive.py app launch launch
python3 .verification/tmp/d15-removal-provider/drive.py app doctor doctor
python3 .verification/tmp/d15-removal-provider/drive.py app tools tools
python3 .verification/tmp/d15-removal-provider/resources.py before
python3 .verification/tmp/d15-removal-provider/baseline.py initialize
```

Freeze is an offline file/revision/digest operation, not a service launch. Its
manifest binds byte copies of the actual skill/recipes, controller, network/
feedback/request/fixture/provider helper, environment/core/daemon/fixture setup,
and every ignored recorder input. Notify coordinator exact manifest/revision/
digest/hashes before launch. Check actual available memory before the second
owned build; preserve unavailable launch outcomes and cleanup any created worker.
Each recorder command includes `--worker 2`. No direct browser connection,
one-off evaluation, app handler invocation, hidden UI state edit or grant change.

Resource before capture occurs while worker 2 is running and retains full exact
five container IDs, two volume names, one network full ID/name, config hash,
session/candidate/project, and actual safe Docker command/raw-output inventories.
The eight original A/B business rowsets (Personnel, Training, packet, progress)
are captured BEFORE ANY SEED. Four extra template/definition rowsets protect the
native clone's source. Original-row comparison excludes nothing: both cohorts
and every native-created row must be absent before comparison.

Only two normal UI authentication sessions: `onboardingConfigure` for assignment/
temporary template prep and the overlap; `onboardingOperate` for native Remove.
Both are Onboarding-only with true fixture grants. Reuse their recorded page and
browser context; do not reauthenticate between phases. Native snapshot and
screenshot observations remain separate from privileged setup/readbacks/API.

## Fresh fault cohort

```
python3 .verification/tmp/d15-removal-provider/baseline.py fault-prepare
python3 .verification/tmp/d15-removal-provider/baseline.py fault-install
python3 .verification/tmp/d15-removal-provider/baseline.py fault-remove
python3 .verification/tmp/d15-removal-provider/baseline.py fault-off-retry
python3 .verification/tmp/d15-removal-provider/baseline.py fault-clean
```

This first legacy cohort is assigned canonical Verification Onboarding A through
the actual Assign Template modal. Its original Reviewed/incomplete Paperwork is
inactive; completed inactive Orientation/Historic remain. Capture authoritative
original/fresh IDs, notes and reload before provider fault installation.
The accepted provider capture returns the actual absolute prepared file, which
is consumed unchanged by fault-on/off. No Group/slug, note, stage or completion
editing is allowed on this provider target.

Native Remove is selected from a fresh Operate snapshot after an observe-only
network control reload and rendered feedback arm. Require actual server 500,
visible error/retained row and exact provider snapshot equality. Retain the native
network list and use its actual DELETE request ID with the recorder's `tool`
`get_network_request` call, supplying requestFilePath/responseFilePath inside
this run. That special recorder saves business body files plus tool exit/error/
hash metadata and discards all tool text containing credential headers. Preserve
the tool's enforced `.network-request` / `.network-response` filename suffixes;
read the actual files before granting complete-body credit.

Fault-off must retain exact marked function/trigger catalog absence BEFORE any
retry or seed cleanup. Restore first hooks; real native retry uses a fresh
observe-only control, actual 200/full body, exact target absence, same completed
inactive work and native reload. Restore feedback/network; clean helper seeds
and independently read back absence for every original/fresh ID. Original full
A/B rowsets must exactly match before a fresh cohort.

## Fresh linked inactive wait cohort

```
python3 .verification/tmp/d15-removal-provider/baseline.py wait-prepare
python3 .verification/tmp/d15-removal-provider/wait.py --page ACTUAL_CONFIGURE_PAGE --seed ABSOLUTE_WAIT_SEED --prepared ABSOLUTE_RETURNED_PREPARED
python3 .verification/tmp/d15-removal-provider/baseline.py wait-readback
python3 .verification/tmp/d15-removal-provider/baseline.py wait-clean
```

Wait preparation creates ONE native canonical clone, renames it to
`D15 Removal Matching TAG`, and edits only its Paperwork definition name to exact
`Paperwork`; its type and Submitted/Reviewed/Filed stages stay unchanged.
Duplicate/rename/step edit and native reload/provider IDs are separately saved.
Native Assign Template adopts the original Paperwork row normally; ordinary
native Switch Template back to unchanged canonical Verification Onboarding A
makes that linked row inactive normally. Preserve all original work/notes/IDs.
Neither helper nor recorder edits active, Person fields or work to force a winner.

Wait freezes exact POST reconciliation and DELETE bodies under the durable run
before launching the accepted provider holder. After HOLDING it starts only the
ordinary Configure switch-back; after the independently observed
RECONCILIATION_WAITING checkpoint it starts only the ordinary DELETE. Accept
actual transitive chain ordering and exact holder absence from the provider
helper, not from request dispatch order. Complete HTTP status/business bodies
come from the shared page capture. Pending or failed transport/body capture is
inconclusive; never navigate, reload, change actor or restore capture while
pending. The recorder drains all started work even after an unavailable probe.

After both settle, preserve raw RPC result (especially the original row's active
flag), actual DELETE outcome, exact current parent/progress, retained original
notes/work/IDs and fresh native reload. Expected boundary: if reconciliation
reactivates/commits the original row before DELETE can persist, the now-active
row survives and deletion explicitly rejects. The recorder labels observations
unclassified; actual source/provider/response agreement decides PASS/FAIL.
Do not claim a race from source or a desired winner from queuing alone.

## Cleanup and truthful gaps

Delete only the captured native temporary template visibly and confirm all its
captured definition IDs absent. Clean exact helper cohorts, prove all original
and ordinary-generated progress IDs absent, compare original 12 rowsets exactly,
and retain final doctor. Then:

```
python3 .verification/tmp/d15-removal-provider/drive.py app owned-disposal cleanup
python3 .verification/tmp/d15-removal-provider/resources.py after
```

Exact post-disposal inventories prove absence for every original container ID,
volume name and network ID regardless of rename, the exact project suffix, and
the private worker directory. Preserve complete allocator namespace raw commands/
outputs too; worker 1 may still exist, so do not require global namespace empty
until both owners dispose. No raw Docker inspect secrets are exported.

Fresh UID helpers refuse missing/ambiguous accessible controls. A missing portal
option, changed native tool schema, settling timeout or body capture mismatch is
a driving evidence gap, not product failure. Preserve the first failed operation;
use only a separately recorded normal native correction authorized by the skill
(fresh snapshot, focused keyboard/visible choice), without editing frozen inputs
or assuming persistence. Preserve any source-independent actual product failure.
Write readable RUN.md with revision/digest/role/timeline/capture gaps and actual
cleanup limits. Notify root both final directories/counts before packaging. Both
baseline workers must be disposed before any application repair begins.
