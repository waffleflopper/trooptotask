from d17_policy_final_support import *
p=json.load(open(RUN/'actor-owner-policies.json'))['pageId']
rows('org-a-original');rows('org-b-original','orgB');snapshot('owner-policies-start',p)
step('retention12-fill',p,'fill','spinbutton','Retention period',12)
step('retention12-save',p,'click','button','Save','region:Archive Retention')
step('retention12-reload',p,'reload');rows('org-a-retention12')
step('archives12',p,'click','link','Archives');step('archives12-reload',p,'reload');screen('archives12',p)
step('return-policies',p,'click','link','Policies')
for key,value,input_name,region in [('retention',24,'Retention period','Archive Retention'),('warning',90,'Warning lead time','Loss Warning Window')]:
 control(key+'-fail-arm','network','arm-fail',p,'organization/settings');control(key+'-feedback-arm','feedback','arm',p)
 step(key+'-fail-fill',p,'fill','spinbutton',input_name,value)
 step(key+'-fail-save',p,'click','button','Save','region:'+region)
 control(key+'-fail-feedback','feedback','state',p);control(key+'-fail-network','network','state',p);rows(key+'-failed-row')
 control(key+'-fail-restore','network','restore',p);control(key+'-feedback-restore','feedback','restore',p)
 step(key+'-retry',p,'click','button','Save','region:'+region);step(key+'-retry-reload',p,'reload');rows(key+'-retry-row')
step('warning-fraction-fill',p,'fill','spinbutton','Warning lead time',30.6);step('warning-fraction-save',p,'click','button','Save','region:Loss Warning Window');step('warning-fraction-reload',p,'reload');rows('warning-fraction-row')
step('retention-invalid-fill',p,'fill','spinbutton','Retention period',0);step('warning-invalid-fill',p,'fill','spinbutton','Warning lead time',366);snapshot('invalid-disabled-full',p);step('invalid-discard-reload',p,'reload')
proc=subprocess.run(['python3',str(RUN.parent/'d17-policy-baseline-b6a1/api-probes.py'),str(RUN),str(p)],capture_output=True,text=True,timeout=300);(RUN/'api-matrix-command.txt').write_text(proc.stdout+proc.stderr);assert proc.returncode==0
step('api-after-reload',p,'reload');rows('api-after-full')
seed=control('seed-personnel-lifecycle','seed','personnel-lifecycle');print(json.dumps(seed),flush=True)
