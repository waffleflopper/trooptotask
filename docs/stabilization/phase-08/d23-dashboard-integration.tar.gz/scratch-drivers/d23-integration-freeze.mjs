import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { files, candidate } from '../../scripts/verification/core.mjs';
const out = '.verification/evidence/verify-trooptotask/d23-dashboard-integration';
const entries = [];
for (const file of await files()) {
  const map = file === '.agents/skills/verify-trooptotask/SKILL.md' || (file.startsWith('.agents/skills/verify-trooptotask/features/') && file.endsWith('.md'));
  if ((file.endsWith('.md') && !map) || path.basename(file).startsWith('.env')) continue;
  try { const data = await fs.readFile(file); entries.push({path:file,sha256:createHash('sha256').update(data).digest('hex')}); }
  catch (e) { if(e.code !== 'ENOENT') throw e; entries.push({path:file,deleted:true}); }
}
await fs.writeFile(out+'/tested-input-manifest.json', JSON.stringify({revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),candidate:await candidate(),entries},null,2)+'\n');
await fs.writeFile(out+'/tested-tracked.patch',execFileSync('git',['diff','HEAD','--binary']));
console.log(JSON.stringify({candidate:await candidate(),entries:entries.length}));
