#!/usr/bin/env bash
# usage: fetchxlsx.sh NAME PATH OUTFILE  (uses $P) READ-ONLY authenticated GET; bytes returned base64 and written locally
E=.verification/evidence/verify-trooptotask/1504-final-v4/accept
F='async () => { const r=await fetch(__PATH__,{credentials:"same-origin"}); const b=new Uint8Array(await r.arrayBuffer()); let s=""; for (const x of b) s+=String.fromCharCode(x); return {status:r.status, ct:r.headers.get("content-type"), cd:r.headers.get("content-disposition"), b64:btoa(s)}; }'
J=$(python3 -c 'import json,sys;print(json.dumps({"pageId":int(sys.argv[2]),"function":sys.argv[1].replace("__PATH__",json.dumps(sys.argv[3]))}))' "$F" "$P" "$2")
MAXOUT=10 $E/t.sh "$1" "READ-ONLY authenticated export GET (API proof, not native download): $2" evaluate_script "$J" >/dev/null
python3 - "$E/receipts/$1.stdout" "$3" <<'PY'
import sys,json,re,base64,hashlib
t=open(sys.argv[1]).read(); d=json.loads(t[t.find('{'):]); m=d['structuredContent']['message']; j=json.loads(re.search(r'```json\n(.*)\n```',m,re.S).group(1))
b=base64.b64decode(j['b64']); open(sys.argv[2],'wb').write(b)
print(json.dumps({"status":j['status'],"ct":j['ct'],"cd":j['cd'],"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}))
PY
