# D26 final AppShell Web source design (read-only investigation)

Baseline 162e41abbc4cc621fc2d2500ed4acf53a46c843d; no source edits, services, tests or browser execution. Source observations below are not new live evidence. This census is independently recomputed from current source, not treated as a completed candidate diff.

## Smallest complete outcome

AppShell owns one scope-bound Web composition (navigation/chrome/What's New/leave/modal visibility) and consumes its existing portable/server reads. Delivery keys that complete composition by admitted account + Organization + stable session metadata; same-scope route navigation preserves it. Identity AccountPreferencesProvider remains inside that lifetime and preserves latest unsaved preferences across same-scope navigation. Keep current independent first paint/deferred split, initial preference seed behavior, focus-refresh thresholds and lazy modals. No hydration registry, feature-to-AppShell imports, compatibility shims, dependency permissions or migration.

Use current actual needs: owner shell component plus owned chrome/lifetime state and private navigation/changelog views. A narrow public AppShell UI action context is justified only for Dashboard Delivery's current auto-What's-New request once its screen model is ready. The other routes already inherit data.shell and can directly project it into feature-owned inputs; they need no universal OrgContext replacement. Retain shared primitives/styles. Theme/toasts remain neutral UI ownership.

Feedback cannot be directly imported by AppShell under the current graph: Delivery injects a Feedback-modal rendering snippet/callback into the shell. Feedback owns submission and an onDestroy/current-instance fence; Shell owns opening/closing, captures its scope/page context, and resets it on scope retirement. Account and leave actions retain existing form routes/policy. What's New stores last seen by account (current key), handles unavailable/throwing storage without breaking close, and has no global open bit.

## Access and caller composition

Do not turn features' orgContext imports into AppShell imports. TrainingPageAccess (training/contracts.ts:195), RatingSchemePageAccess (rating-scheme/contracts.ts:17), CalendarPageAccess (CalendarPageContext.svelte.ts:36), and OnboardingPageAccess (OnboardingPageContext.svelte.ts:82) are nearest legitimate patterns. Personnel needs its own consumed input (scopeSet, orgUrlSegment, feature-decision callback); Critical Tasks needs its own decision input with explicit org data where used. Calendar's Assignment Planner/Bulk/Settings and ICT library/detail receive props from their routes.

Preserve exact current client-advisory mapping from orgContext.svelte.ts:136-165 to existing Access policyEvaluator/client-advisory and explainPolicyReasonCode. Use one production Access seam at src/lib/access/clientAccess.ts exporting ClientAffordance, ClientAccessFacts, and createClientAccess(facts | accessor). Facts contain only membershipRole, capabilityMap and scopeSet; preserve existing absent-map owner/admin configure/member none and absent-scope organization defaults here. Expose only consumed role/capability/scope getters, hasCapability, isResourceInScope and the two advisory callbacks. This is justified by current multi-owner decisions and must not receive AppShell identity/routing data, a provider or Svelte state. Delivery binds getters/current admitted data and projects only what each caller consumes. Full maps/scope remain reactive on same-identity grant refresh. Preserve unscoped vs Organization vs Group resources, missing lane=none, explicit owner/admin maps, peer/foreign/empty-group behavior and Governance decisions independent of feature capabilities. Client data never becomes command authority.

The Shared orgContextBuilder currently imports an AppShell-private product module. Delete it. The current fixture has 14 distinct caller files and 15 import statements (OnboardingInteraction imports it twice). Owner tests can use production createClientAccess plus createCapabilityMap and their own plain orgId/orgUrlSegment fields; no public test factory is needed. No Shared->AppShell/Access workaround or public test export solely to retain old imports. Delete trivial removed role-getter tests; retain actual capability/Group/governance decisions at the Access boundary and interactions with narrow feature inputs.

## Scope/session and late callers

Header switcher currently has only segment equality (TopHeader.svelte.ts equivalent lines151-165), no rejection catch, and unguarded finally: stale A after A-B-A can be admitted and an old completion can alter loading. Count/list/write protection has generation/scope, but scope omits explicit account and component activity (lines84,168-294). New instances/dispose must suppress every late state, navigation and toast after each await, including JSON parsing; recover current failures on explicit reopen without request loops. Retain existing notification list-vs-bulk sequencing and failed read behavior.

Root org layout currently keeps Feedback boolean and global What's New across scope changes (lines34-42,133-145); Header keeps leave dialog/YES and sidebar state. Retire these together by scope. Close the mobile drawer on actual completed in-app navigation/menu selection and test real settled Escape/focus; baseline Escape was unverified, not proved defective. Existing public Sidebar.useSidebar can be called by an owner child below Sidebar.Provider; prefer that small actual composition over broad primitive changes/admin scope expansion. Do not key on pathname, tokens, session object or array identity.

Current ordinary Sign Out is unenhanced POST /auth/logout with303 '/', destroying Organization layout. user:org key + onDestroy covers that path and different-account rerender. For same-user/same-org session replacement delivered in place, recommend one narrow Identity server read returning opaque stable metadata from the already hook-verified session; existing mfaGate.server.ts:41-61 validates user/sub/session_id. No provider lookup or authorization change. Same session_id across token refresh retains shell/saver; changed binding replaces them. No claim of instantaneous detection of cross-tab cookie change before new admitted data arrives.

BulkStatusPage.svelte:100-106 is the direct caller whose mutable org accessor currently prevents late global range merge. Fixed props must add destruction/instance fencing before merge. mergeCalendarRangeIntoStores replaces another Organization's stores if invoked late. A-B-A needs the instance fence too. AssignmentPlanner already cancels CalendarRangeCoordinator in effect cleanup. Onboarding context #isCurrent includes disposed/org/store version and the route disposes; retain. Streamed Personnel/Calendar/Evals/Training views have cleanup cancellation; #await routes rely on component destruction. Personnel/Training contexts do not use mutable OrgContext as an async fence.

ICT library saveTask only has org equality (315-331), and archive/restore update retired local UI after await; add component active fencing where changing these callers. Its error is formError, not a global toast (clarifies an earlier shorthand message). ICT detail delegates completion writes to existing store/modal; no mutable-accessor late guard exists there. FeedbackModal.svelte:49-54 emits success/error after unmount and must guard. AnnouncementBanner already has account generation/onDestroy; AccountPreferencesState already has dispose/activity protection. The generic createStore organizationVersion increments only when org ID differs (createStore.svelte.ts:124-128): equal-org actor/session store replay is an unproven adjacent hypothesis requiring a targeted witness before broad store changes or stronger claims; do not silently count org equality as actor isolation.

## Dead state and retained boundaries

Remove help singleton, HelpPanel + its tests/root render: no production opener exists. No live guide route/file is present. Remove Calendar markCalendarVisited (258-268), its call (calendar route148), and now-unused browser/storage imports: one writer and no reader. Retain Dashboard-owned support/starter-pack refresh and the six-field Getting Started API, Identity progress/save/SQL, historical false rows, account-wide announcement dismissal and all existing authorization. No visible Getting Started checklist is to be invented. Existing inactive checklist getters are already Dashboard-owned, not AppShell ambient debt; avoid expanding the cutover into an unrelated model rewrite.

Old physical paths to disappear: lib/components/{TopHeader.svelte,TopHeader.test.ts,OrgNavIcon.svelte,WhatsNewModal.svelte,orgNavigation.ts,orgNavigation.test.ts}; lib/data/changelog.ts; lib/stores/{orgContext.svelte.ts,orgContext.svelte.test.ts,whatsNew.svelte.ts,help.svelte.ts}; lib/test-support/orgContextBuilder.ts; lib/components/ui/{HelpPanel.svelte,HelpPanel.test.ts}. Move current live behaviors/tests to owner paths, delete globals/dead code and old wrappers. Reconcile owner files/public seam declarations without graph permissions. Update current ownership + shell/switch/communications recipes and the owning receipt.

## Cheapest meaningful proof

Keep existing Header notification recovery, count/list/write stale cases, navigation/breadcrumb tests and feature permission/Group tests through new inputs. Add current-owner tests for: held old switcher response after A-B-A; rejection/finally from retired instance; same-org different account/session and identical-ID replacement; refresh-stable session metadata; failed switcher reopen retry; count/list/write overlap; Feedback late success and late failure after destruction/current retry; leave YES/modal reset across scope; mobile navigation closure/keyboard/focus; per-account What's New auto/manual close/storage failure; two independent SSR compositions without browser/global leakage; Bulk range completion after unmount and A-B-A. Fault-injection negatives should establish reproduction at these boundaries, not assert file moves.

Affected native baseline/final: nonzero contrasting A/B counts and positive switcher payloads, held responses through native A-B-A; account/profile/leave cancellation/role visibility; Feedback held success/failure through real scope retirement with exact saved rows; What's New once-account/manual/reload; mobile Home/Training switching and settled drawer close; representative narrow-input routes for all six lanes, Group-scoped/empty/none controls; Training/Calendar preference/no-refetch/latest-intent and cross-feature preservation regressions; ordinary logout/login distinctly labeled. Existing communications fixture supports notificationSwitch/peer/global banners. Strong same-document actor/session replacement and precise debounce/source races remain lower-level unless an actual supported native path is observed; don't equate destroyed hooks or separate contexts with released late responses.

Historical server/CAS/SQL proof can be reused only for byte-unchanged owned operations/routes. Full current DoD/build/CI, completed clean bots, source/expanded artifact independent acceptance and final integrated issue acceptance remain before any Closes #1374. Hosted policy parity stays unverified; do not infer it from local SQL or reported manual migration.

## Exact existing caller census

72 existing legacy owner/consumer source-test paths, plus four component Delivery callers = 76 existing paths. This is not a final diff count. Necessary additions/modifications also include FeedbackModal and its new behavior test, consumed feature contracts/barrels, Identity metadata seam/tests/root binding if adopted, Access advisory seam/tests/fixture replacement, owning manifest/current docs/recipes/evidence, and new owner files. A final implementation census must count those actual chosen paths.

- `src/features/app-shell/autoShowWhatsNew.ts`
- `src/features/app-shell/index.ts`
- `src/features/calendar/components/AssignmentPlannerPage.svelte`
- `src/features/calendar/components/AssignmentPlannerPage.test.ts`
- `src/features/calendar/components/BulkStatusPage.svelte`
- `src/features/calendar/components/BulkStatusPage.test.ts`
- `src/features/calendar/components/CalendarPageView.svelte.test.ts`
- `src/features/calendar/components/CalendarSettingsPage.svelte`
- `src/features/calendar/components/CalendarSettingsPage.test.ts`
- `src/features/calendar/contexts/CalendarPageContext.svelte.ts`
- `src/features/calendar/contexts/CalendarPageContext.test.ts`
- `src/features/critical-tasks/components/IctPersonnelDetailPage.svelte`
- `src/features/critical-tasks/components/IctPersonnelDetailPage.test.ts`
- `src/features/critical-tasks/components/IctTaskLibraryPage.svelte`
- `src/features/critical-tasks/components/IctTaskLibraryPage.test.ts`
- `src/features/critical-tasks/utils/criticalTasksPolicy.ts`
- `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts`
- `src/features/onboarding/contexts/OnboardingPageContext.svelte.test.ts`
- `src/features/personnel/components/PersonnelModals.test.ts`
- `src/features/personnel/components/PersonnelPageView.svelte.test.ts`
- `src/features/personnel/contexts/PersonnelPageContext.svelte.test.ts`
- `src/features/personnel/contexts/PersonnelPageContext.svelte.ts`
- `src/features/rating-scheme/components/RatingSchemePageView.svelte.test.ts`
- `src/features/rating-scheme/contexts/RatingSchemePageContext.test.ts`
- `src/features/training/components/TrainingPageView.test.ts`
- `src/features/training/contexts/TrainingPageContext.svelte.test.ts`
- `src/lib/components/OrgNavIcon.svelte`
- `src/lib/components/TopHeader.svelte`
- `src/lib/components/TopHeader.test.ts`
- `src/lib/components/WhatsNewModal.svelte`
- `src/lib/components/orgNavigation.test.ts`
- `src/lib/components/orgNavigation.ts`
- `src/lib/components/ui/HelpPanel.svelte`
- `src/lib/components/ui/HelpPanel.test.ts`
- `src/lib/data/changelog.ts`
- `src/lib/stores/help.svelte.ts`
- `src/lib/stores/orgContext.svelte.test.ts`
- `src/lib/stores/orgContext.svelte.ts`
- `src/lib/stores/whatsNew.svelte.ts`
- `src/lib/test-support/orgContextBuilder.ts`
- `src/routes/+layout.svelte`
- `src/routes/org/[orgId]/(dashboard)/+page.svelte`
- `src/routes/org/[orgId]/+layout.svelte`
- `src/routes/org/[orgId]/calendar/+page.svelte`
- `src/routes/org/[orgId]/calendar/assignments/+page.svelte`
- `src/routes/org/[orgId]/calendar/assignments/page.svelte.test.ts`
- `src/routes/org/[orgId]/calendar/bulk/+page.svelte`
- `src/routes/org/[orgId]/calendar/page.svelte.test.ts`
- `src/routes/org/[orgId]/calendar/settings/+page.svelte`
- `src/routes/org/[orgId]/critical-tasks/+page.svelte`
- `src/routes/org/[orgId]/critical-tasks/[personnelId]/+page.svelte`
- `src/routes/org/[orgId]/critical-tasks/[personnelId]/page.svelte.test.ts`
- `src/routes/org/[orgId]/critical-tasks/critical-tasks-page.svelte.test.ts`
- `src/routes/org/[orgId]/critical-tasks/library/+page.svelte`
- `src/routes/org/[orgId]/critical-tasks/reports/+page.svelte`
- `src/routes/org/[orgId]/evals/+page.svelte`
- `src/routes/org/[orgId]/evals/page.svelte.test.ts`
- `src/routes/org/[orgId]/onboarding/+page.svelte`
- `src/routes/org/[orgId]/onboarding/history/+page.svelte`
- `src/routes/org/[orgId]/onboarding/history/page.svelte.test.ts`
- `src/routes/org/[orgId]/onboarding/page.svelte.test.ts`
- `src/routes/org/[orgId]/onboarding/templates/+page.svelte`
- `src/routes/org/[orgId]/onboarding/templates/page.svelte.test.ts`
- `src/routes/org/[orgId]/personnel/+page.svelte`
- `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.svelte`
- `src/routes/org/[orgId]/personnel/import/+page.svelte`
- `src/routes/org/[orgId]/personnel/page.svelte.test.ts`
- `src/routes/org/[orgId]/personnel/personnelEditArchive.test.ts`
- `src/routes/org/[orgId]/training/+page.svelte`
- `src/routes/org/[orgId]/training/reports/+page.svelte`
- `src/routes/org/[orgId]/training/reports/training-reports-page.svelte.test.ts`
- `src/routes/org/[orgId]/training/training-page.svelte.test.ts`
- `src/routes/org/[orgId]/training/types/+page.svelte`
- `src/routes/org/[orgId]/training/types/training-types-page.svelte.test.ts`
- `src/routes/org/[orgId]/training/views/+page.svelte`
- `src/routes/org/[orgId]/training/views/training-views-page.svelte.test.ts`
