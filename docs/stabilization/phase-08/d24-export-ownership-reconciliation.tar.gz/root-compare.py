import json
from pathlib import Path

p = Path(__file__).resolve().parent
read = lambda name: json.loads((p / name).read_text())
owner = read('owner.json')
admin = read('admin.json')
stored = read('feedback-stored.json')
assert stored == read('feedback-reloaded.json') == read('feedback-final.json')
assert read('feedback-b-before.json') == read('feedback-b-final.json')
assert owner['betaFeedback'] == stored['rows']
assert admin['betaFeedback'] == []
for payload in [owner, admin]:
    assert len(payload['sectionInventory']) == 38
    assert len(payload['sections']) == 38
    for key, rows in payload['sections'].items():
        assert payload[key] == rows
memberships = read('memberships-a.json')['rows']
ids = read('fixture.json')['ids']
actors = {
    role: next(row['user_id'] for row in memberships if row['id'] == ids[role + 'Membership'])
    for role in ['orgOwner', 'orgAdmin']
}
assert stored['rows'][0]['user_id'] == actors['orgOwner']
records = read('lifecycle-final.json')['rows']
assert len(records) == 3
for name, prefix, role in [('owner.json', 'owner-json', 'orgOwner'), ('owner.xlsx', 'owner-xlsx', 'orgOwner'), ('admin.json', 'admin', 'orgAdmin')]:
    saved = read(prefix + '-save.json')
    assert saved['bytes'] == (p / name).stat().st_size
    requests = read(prefix + '-network-state.json')['calls']
    assert len(requests) == 1 and requests[0]['status'] == 200
    matches = [row for row in records if row['file_size_bytes'] == saved['bytes']]
    assert len(matches) == 1
    row = matches[0]
    assert row['status'] == 'completed'
    assert row['org_id'] == ids['orgA'] and row['requested_by'] == actors[role]
    assert row['created_at'] and row['completed_at'] and row['file_path'] is None
assert read('lifecycle-b-final.json')['rows'] == []
assert sorted(read('lifecycle-owner-reloaded.json')['rows'], key=lambda row: row['id']) == sorted([row for row in records if row['requested_by'] == actors['orgOwner']], key=lambda row: row['id'])
print(json.dumps({'status': 'PASS', 'actualFiles': 3, 'sectionsPerJson': 38, 'ownerFeedbackSavedFields': len(stored['rows'][0]), 'adminPeerFeedbackRows': 0, 'exactCompletedLifecycleRows': 3}, indent=2))
