from pathlib import Path
import re
root=Path('/home/waffleflops/.cache/t2t-d13-server-cut')
uc=root/'src/lib/server/core/useCases'
owner=root/'src/features/personnel'
registry=(uc/'personnelArtifactLifecycle.ts').read_text()
def part(start,end):return registry[registry.index(start):registry.index(end)]
rows={
'CounselingRecordRow':part('export interface CounselingRecordRow','export interface PersonnelDocumentRow'),
'PersonnelDocumentRow':part('export interface PersonnelDocumentRow','export interface FollowUpRow'),
'FollowUpRow':part('export interface FollowUpRow','export interface PersonnelArtifactSpec')}
fileName=part('function fileNameFromPath','export function mapCounselingRow')
maps={
'Counseling':part('export function mapCounselingRow','export function mapDocumentRow'),
'Document':part('export function mapDocumentRow','export function mapFollowUpRow'),
'FollowUp':part('export function mapFollowUpRow','const binaryArchivePatch')}
for k in maps:maps[k]=maps[k].replace('export function','function')
context='''import { POLICY_ACTION_CATALOG } from '$lib/access/policyEvaluator';
import { policyResourceForGroup, requireFeaturePolicy } from '$lib/access/index.server';
import { fail } from '$lib/errors';
import type { PersonnelArtifactWriter } from './contracts';
import type { CounselingRecordRow } from './personnelCounselingRecords.server';
import type { PersonnelDocumentRow } from './personnelDocuments.server';
import type { FollowUpRow } from './personnelFollowUps.server';

export interface PersonnelArtifactsContext {
 actor: Parameters<typeof requireFeaturePolicy>[0]['auth'] & { userId: string; orgId: string };
 scope: { requireGroupAccess(personnelId: string): Promise<void> };
 audit: NonNullable<Parameters<typeof requireFeaturePolicy>[0]['audit']>;
 persistence: {
  findPersonnelGroup(personnelId: string): Promise<string | null | undefined>;
  listCounselingRecords(personnelId: string, options: { archived: boolean; limit?: number }): Promise<CounselingRecordRow[]>;
  listDocuments(personnelId: string, options: { archived: boolean; limit?: number }): Promise<PersonnelDocumentRow[]>;
  listFollowUps(personnelId: string, options: { archived: boolean; limit?: number }): Promise<FollowUpRow[]>;
  findDocument(personnelId: string, documentId: string): Promise<PersonnelDocumentRow | null>;
 };
 writerFor(personnelId: string): Promise<PersonnelArtifactWriter>;
 contributorLabels(userIds: string[]): Promise<Map<string, string>>;
 documentStorageCapBytes(): Promise<number>;
 createDocumentSignedUrl(filePath: string, expiresInSeconds: number): Promise<string>;
}

// The same request context is shared by the three Dashboard reads. Cache rejection
// as well as admission, and keep write admission independent from sensitive reads.
const accessCache = new WeakMap<PersonnelArtifactsContext, Map<string, Promise<void>>>();

export async function requirePersonnelArtifactAccess(ctx: PersonnelArtifactsContext, personnelId: string, purpose: 'read' | 'write'): Promise<void> {
 let cache = accessCache.get(ctx);
 if (!cache) { cache = new Map(); accessCache.set(ctx, cache); }
 const key = `${ctx.actor.orgId}:${personnelId}:${purpose}`;
 let check = cache.get(key);
 if (!check) {
  check = requireAccessUncached(ctx, personnelId, purpose);
  cache.set(key, check);
 }
 return check;
}

async function requireAccessUncached(ctx: PersonnelArtifactsContext, personnelId: string, purpose: 'read' | 'write'): Promise<void> {
 const groupId = await ctx.persistence.findPersonnelGroup(personnelId);
 if (groupId === undefined) fail(404, 'Personnel record not found');
 await requireFeaturePolicy({ auth: ctx.actor, audit: ctx.audit },
  purpose === 'read' ? POLICY_ACTION_CATALOG.personnel.readSensitiveRecords : POLICY_ACTION_CATALOG.personnel.manageRecords,
  policyResourceForGroup(groupId), 'personnel', personnelId);
 await ctx.scope.requireGroupAccess(personnelId);
}

export async function personnelArtifactWriter(ctx: PersonnelArtifactsContext, personnelId: string): Promise<PersonnelArtifactWriter> {
 await requirePersonnelArtifactAccess(ctx, personnelId, 'write');
 return ctx.writerFor(personnelId);
}

export function resolveContributorLabel(labels: Map<string, string>, value: string | null | undefined): string {
 if (!value) return 'Unknown leader';
 return labels.get(value) ?? value;
}
'''
(owner/'personnelArtifactContext.server.ts').write_text(context)
for family,row,short in [('personnelCounselingRecords','CounselingRecordRow','Counseling'),('personnelDocuments','PersonnelDocumentRow','Document'),('personnelFollowUps','FollowUpRow','FollowUp')]:
 s=(uc/(family+'.ts')).read_text()
 s=s.replace("from '$features/personnel/personnel-detail.types'", "from './contracts'")
 s=s.replace("import type { UseCaseContext } from '$lib/server/core/ports';\n",'')
 s=re.sub(r"import \{\n.*?\} from './personnelArtifactLifecycle';", "import { personnelArtifactWriter, requirePersonnelArtifactAccess, resolveContributorLabel, type PersonnelArtifactsContext } from './personnelArtifactContext.server';",s,count=1,flags=re.S)
 s=s.replace('UseCaseContext','PersonnelArtifactsContext').replace('ctx.auth.','ctx.actor.')
 s=s.replace('loadPersonnelContributorLabels(ctx, [row.uploaded_by])','ctx.contributorLabels(row.uploaded_by ? [row.uploaded_by] : [])')
 s=s.replace('loadPersonnelContributorLabels(ctx, [row.created_by])','ctx.contributorLabels([row.created_by])')
 s=s.replace('export const personnelFollowUp','const personnelFollowUp')
 s=rows[row]+s
 # Place imports first; formatter sorts whitespace only. TS permits interfaces before imports.
 marker='return listArtifacts(ctx, PERSONNEL_'+{'Counseling':'COUNSELING_RECORD','Document':'DOCUMENT','FollowUp':'FOLLOW_UP'}[short]+'_SPEC, personnelId, { limit, archived: options.archived });'
 method={'Counseling':'listCounselingRecords','Document':'listDocuments','FollowUp':'listFollowUps'}[short]
 col='created_by' if short=='FollowUp' else 'uploaded_by'
 s=s.replace(marker,f'''await requirePersonnelArtifactAccess(ctx, personnelId, 'read');
 const rows = await ctx.persistence.{method}(personnelId, {{ archived: !!options.archived, limit }});
 const labels = await ctx.contributorLabels(rows.flatMap(row => row.{col} ? [row.{col}] : []));
 return rows.map(row => map{short}Row(row, labels));''')
 if short=='Document':
  s=s.replace('export const DEFAULT_PERSONNEL_DOCUMENT_STORAGE_CAP_BYTES = 100 * 1024 * 1024;\n','')
  s=re.sub(r'interface OrganizationDocumentSettingsRow \{.*?\}\n\n','',s,flags=re.S)
  s=re.sub(r'async function loadDocumentStorageCapBytes\(.*?\n\}\n\n','',s,flags=re.S)
  s=s.replace('loadDocumentStorageCapBytes(ctx)','ctx.documentStorageCapBytes()')
  s=s.replace('await requirePersonnelArtifactReadAccess(ctx, input.personnelId);',"await requirePersonnelArtifactAccess(ctx, input.personnelId, 'read');")
  s=s.replace("await ctx.store.findOne<PersonnelDocumentRow>('personnel_documents', ctx.actor.orgId, {\n\t\tid: input.documentId,\n\t\tpersonnel_id: input.personnelId\n\t})",'await ctx.persistence.findDocument(input.personnelId, input.documentId)')
  s=s.replace('ctx.storage.createSignedUrl(PERSONNEL_DOCUMENTS_BUCKET, document.file_path, 300)','ctx.createDocumentSignedUrl(document.file_path, 300)')
 if short in ['Counseling','Document']:
  singular='CounselingRecord' if short=='Counseling' else 'Document'
  table='counseling_records' if short=='Counseling' else 'personnel_documents'
  noun='Counseling record' if short=='Counseling' else 'Document'
  plural='counseling records' if short=='Counseling' else 'documents'
  idfield='recordId' if short=='Counseling' else 'documentId'
  audit='counseling_record' if short=='Counseling' else 'document'
  kind='counseling' if short=='Counseling' else 'document'
  s=s[:s.index('export async function archivePersonnel'+singular)]
  s+=f'''async function load{short}ForWrite(ctx: PersonnelArtifactsContext, personnelId: string, id: string) {{
 const writer = await personnelArtifactWriter(ctx, personnelId);
 const row = await writer.find<{row}>('{table}', id);
 if (!row) fail(404, '{noun} not found');
 return {{ writer, row }};
}}

export async function archivePersonnel{singular}(ctx: PersonnelArtifactsContext, input: {{ personnelId: string; {idfield}: string }}): Promise<Personnel{singular}> {{
 const {{ writer, row: existing }} = await load{short}ForWrite(ctx, input.personnelId, input.{idfield});
 if (existing.archived_at) fail(409, '{noun} is already archived');
 const row = await writer.update<{row}>('{table}', input.{idfield}, {{ archived_at: new Date().toISOString() }});
 ctx.audit.log({{ action: 'personnel.{audit}.archived', resourceType: 'personnel', resourceId: input.personnelId }});
 return map{short}Row(row, await ctx.contributorLabels(row.uploaded_by ? [row.uploaded_by] : []));
}}

export async function restorePersonnel{singular}(ctx: PersonnelArtifactsContext, input: {{ personnelId: string; {idfield}: string }}): Promise<Personnel{singular}> {{
 const {{ writer }} = await load{short}ForWrite(ctx, input.personnelId, input.{idfield});
 const row = await writer.update<{row}>('{table}', input.{idfield}, {{ archived_at: null }});
 ctx.audit.log({{ action: 'personnel.{audit}.restored', resourceType: 'personnel', resourceId: input.personnelId }});
 return map{short}Row(row, await ctx.contributorLabels(row.uploaded_by ? [row.uploaded_by] : []));
}}

export async function deletePersonnel{singular}(ctx: PersonnelArtifactsContext, input: {{ personnelId: string; {idfield}: string }}): Promise<void> {{
 const {{ writer, row }} = await load{short}ForWrite(ctx, input.personnelId, input.{idfield});
 if (!row.archived_at) fail(409, 'Archive {plural} before deleting them');
 await writer.delete('{table}', input.{idfield});
 {'if (row.file_path) ' if short=='Counseling' else ''}await writer.removeFile('{kind}', row.file_path);
 ctx.audit.log({{ action: 'personnel.{audit}.deleted', resourceType: 'personnel', resourceId: input.personnelId }});
}}
'''
 else:
  s=s.replace("return deleteArtifact(ctx, PERSONNEL_FOLLOW_UP_SPEC, { personnelId: input.personnelId, id: input.followUpId });", '''const writer = await personnelArtifactWriter(ctx, input.personnelId);
 const row = await writer.find<FollowUpRow>('personnel_follow_ups', input.followUpId);
 if (!row) fail(404, 'Follow-up not found');
 if (row.status !== 'archived') fail(409, 'Archive follow-ups before deleting them');
 await writer.delete('personnel_follow_ups', input.followUpId);
 ctx.audit.log({ action: 'personnel.follow_up.deleted', resourceType: 'personnel', resourceId: input.personnelId });''')
 s+='\n'+(fileName if short!='FollowUp' else '')+maps[short]
 (owner/(family+'.server.ts')).write_text(s)
 # Existing meaningful family cases are moved, changing only context binding.
 t=(uc/(family+'.test.ts')).read_text().replace("from './"+family+"'", "from './"+family+".server'")
 t="import { personnelArtifactsContext } from '$lib/server/adapters/httpAdapter';\n"+t
 fns=re.findall(r'export async function (\w+)\(',s)
 for fn in fns:t=re.sub(r'\b'+fn+r'\((\w+),',lambda m:fn+'(personnelArtifactsContext('+m[1]+'),',t)
 (owner/(family+'.server.test.ts')).write_text(t)
# Archived operation owns the remaining four-family aggregation.
s=(uc/'personnelArchivedArtifacts.ts').read_text()
s=s.replace("from '$features/personnel/personnel-detail.types'","from './contracts'").replace("import type { UseCaseContext } from '$lib/server/core/ports';","import type { PersonnelArtifactsContext } from './personnelArtifactContext.server';")
for family in ['personnelCounselingRecords','personnelDocuments','personnelFollowUps']:s=s.replace("from './"+family+"'", "from './"+family+".server'")
s=s.replace("from '$features/personnel/index.server'","from './leaderNotes.server'").replace('ctx: UseCaseContext','ctx: PersonnelArtifactsContext')
(owner/'personnelArchivedArtifacts.server.ts').write_text(s)
t=(uc/'personnelArchivedArtifacts.test.ts').read_text()
for family in ['personnelCounselingRecords','personnelDocuments','personnelFollowUps','personnelArchivedArtifacts']:t=t.replace("from './"+family+"'","from './"+family+".server'")
t="import { personnelArtifactsContext } from '$lib/server/adapters/httpAdapter';\n"+t
for fn in ['listPersonnelArchivedArtifacts','deletePersonnelFollowUp','restorePersonnelFollowUp','deletePersonnelCounselingRecord','restorePersonnelCounselingRecord','deletePersonnelDocument','restorePersonnelDocument']:
 t=t.replace(fn+'(ctx,',fn+'(personnelArtifactsContext(ctx),')
(owner/'personnelArchivedArtifacts.server.test.ts').write_text(t)
# Canonical portable shapes replace private detail DTO declarations, with no re-export shim.
detail=owner/'personnel-detail.types.ts'
s=detail.read_text()
portable=s[s.index('export interface PersonnelCounselingRecord'):s.index('export interface PersonnelArchivedArtifactsPageData')]
union=s[s.index('export type PersonnelArchivedArtifact ='):s.index('export type PersonnelReadinessLaneTone')]
s=s.replace(portable,'').replace(union,'')
names=['PersonnelCounselingRecord','PersonnelDocument','PersonnelFollowUpStatus','PersonnelFollowUp','PersonnelArchivedArtifact']
s="import type { "+', '.join(names)+" } from './contracts';\n"+s
# Status is referenced only inside its canonical Follow-up definition.
s=s.replace('PersonnelFollowUpStatus, ','')
detail.write_text(s)
contracts=owner/'contracts.ts'
c=contracts.read_text().replace("import type { OrganizationRankCatalogEntry } from './rankCatalogContracts';", "import type { OrganizationRankCatalogEntry } from './rankCatalogContracts';\nimport type { PersonnelLeaderNote } from './personnelLeaderNote.types';")
c+='\n/** Portable sensitive Personnel artifact responses; raw export rows remain separate. */\n'+portable+union
contracts.write_text(c)
# Move DTO imports only, preserving all other private page/workspace type imports.
for p in (root/'src').rglob('*'):
 if p.suffix not in ['.ts','.svelte'] or p==detail:continue
 text=p.read_text()
 pattern=r'import type \{([^}]+)\} from ([\'\"])([^\'\"]*personnel-detail.types)\2;'
 def relocate(m):
  imported=[n.strip() for n in m[1].split(',') if n.strip()]
  portableNames=[n for n in imported if n in names]
  if not portableNames:return m[0]
  privateNames=[n for n in imported if n not in names]
  result="import type { "+', '.join(portableNames)+" } from '$features/personnel/contracts';"
  if privateNames:result+="\nimport type { "+', '.join(privateNames)+" } from '"+m[3]+"';"
  return result
 text=re.sub(pattern,relocate,text)
 if text!=p.read_text():p.write_text(text)
# Public owner exports: only consumed operation, input, row and context contracts.
public=(owner/'index.server.ts').read_text()
public+='''\nexport type { PersonnelArtifactsContext } from './personnelArtifactContext.server';
export {
 listPersonnelCounselingRecords, createPersonnelCounselingRecord, archivePersonnelCounselingRecord,
 restorePersonnelCounselingRecord, deletePersonnelCounselingRecord
} from './personnelCounselingRecords.server';
export type { CounselingRecordRow, PersonnelCounselingRecordInput } from './personnelCounselingRecords.server';
export {
 listPersonnelDocuments, createPersonnelDocument, createPersonnelDocumentDownloadUrl,
 archivePersonnelDocument, restorePersonnelDocument, deletePersonnelDocument
} from './personnelDocuments.server';
export type { PersonnelDocumentRow, PersonnelDocumentInput, PersonnelDocumentDownloadInput } from './personnelDocuments.server';
export {
 listPersonnelFollowUps, createPersonnelFollowUp, setPersonnelFollowUpStatus, updatePersonnelFollowUp,
 archivePersonnelFollowUp, restorePersonnelFollowUp, deletePersonnelFollowUp
} from './personnelFollowUps.server';
export type { FollowUpRow } from './personnelFollowUps.server';
export { listPersonnelArchivedArtifacts } from './personnelArchivedArtifacts.server';
'''
(owner/'index.server.ts').write_text(public)
# Two retained retention owners switch private bucket imports to their current family owners.
for name in ['personnelArtifactRetention.server.ts','personnelRetention.server.ts']:
 p=owner/name;s=p.read_text()
 for family in ['personnelCounselingRecords','personnelDocuments']:s=s.replace("'$lib/server/core/useCases/"+family+"'","'./"+family+".server'")
 p.write_text(s)
# Delivery callers use the narrow binder; Dashboard constructs it once.
for p in (root/'src/routes').rglob('*.ts'):
 s=p.read_text()
 if not any("$lib/server/core/useCases/"+family in s for family in ['personnelCounselingRecords','personnelDocuments','personnelFollowUps','personnelArchivedArtifacts']):continue
 s=re.sub(r"from '\$lib/server/core/useCases/personnel(?:CounselingRecords|Documents|FollowUps|ArchivedArtifacts)'", "from '$features/personnel/index.server'",s)
 s="import { personnelArtifactsContext } from '$lib/server/adapters/httpAdapter';\n"+s
 functions=['listPersonnelCounselingRecords','createPersonnelCounselingRecord','archivePersonnelCounselingRecord','restorePersonnelCounselingRecord','deletePersonnelCounselingRecord','listPersonnelDocuments','createPersonnelDocument','createPersonnelDocumentDownloadUrl','archivePersonnelDocument','restorePersonnelDocument','deletePersonnelDocument','listPersonnelFollowUps','createPersonnelFollowUp','setPersonnelFollowUpStatus','updatePersonnelFollowUp','archivePersonnelFollowUp','restorePersonnelFollowUp','deletePersonnelFollowUp','listPersonnelArchivedArtifacts']
 dashboard=p==root/'src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts'
 for fn in functions:s=s.replace(fn+'(ctx,',fn+('('+'artifactContext,' if dashboard else '(personnelArtifactsContext(ctx),'))
 if dashboard:
  s=s.replace('const extendedInfo = readPersonnelExtendedInfo(ctx, personnelId);','const artifactContext = personnelArtifactsContext(ctx);\n\tconst extendedInfo = readPersonnelExtendedInfo(ctx, personnelId);')
  s=s.replace('// Artifact use cases keep their own authorization boundary. The shared helper caches\n\t\t// the repeated Personnel access check per request context so these dashboard panels\n\t\t// do not each reload the same Personnel row.', '// The three owned artifact reads share one request-local authorization context.')
 p.write_text(s)
# Remove dead entity and obsolete UCs once all current direct callers are moved.
for family in ['personnelCounselingRecords','personnelDocuments','personnelFollowUps','personnelArtifactLifecycle','personnelArchivedArtifacts']:
 for ext in ['.ts','.test.ts']:(uc/(family+ext)).unlink()
for f in ['src/lib/server/entities/counselingRecord.ts','src/lib/server/entities/counselingRecord.test.ts','src/lib/server/counselingRecordMapping.test.ts']:(root/f).unlink()
p=root/'src/lib/server/entities/index.ts';s=p.read_text();s='\n'.join(line for line in s.splitlines() if 'counselingRecord' not in line)+'\n';p.write_text(s)
