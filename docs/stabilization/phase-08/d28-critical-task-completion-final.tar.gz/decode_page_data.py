import json
from pathlib import Path

root = Path(__file__).resolve().parent

def decode(table, index=0, seen=None):
    if index < 0:
        return None
    seen = set() if seen is None else seen
    if index in seen:
        return {'reference': index}
    seen = seen | {index}
    value = table[index]
    if isinstance(value, dict):
        return {key: decode(table, reference, seen) for key, reference in value.items()}
    if isinstance(value, list):
        if value and isinstance(value[0], str):
            if value[0] == 'Promise':
                return {'promise': decode(table, value[1], seen)}
            if value[0] == 'Date':
                return {'date': value[1]}
            return {'tag': value[0], 'values': value[1:]}
        return [decode(table, reference, seen) for reference in value]
    return value

def critical_lane(filename):
    capture = json.loads((root / filename).read_text())
    assert capture['status'] == 200 and capture['redactedSlots'] == 2
    promise_ids = []
    for record in capture['records']:
        for node in record.get('nodes', []):
            if not node or not isinstance(node.get('data'), list):
                continue
            table = node['data']
            for index, value in enumerate(table):
                if isinstance(value, dict) and 'criticalTasks' in value and 'availability' in value:
                    promise_ids.append(decode(table, value['criticalTasks'])['promise'])
    assert len(promise_ids) == 1
    result = next(record for record in capture['records'] if record.get('id') == promise_ids[0])
    field = 'data' if 'data' in result else 'error'
    return {'promiseId': result['id'], 'resultKind': field, 'projection': decode(result[field])}

owner = critical_lane('owner-personnel-page-data.json')
roster = critical_lane('roster-personnel-page-data.json')
assert owner['resultKind'] == 'data' and owner['projection']['label'] == 'Critical Tasks' and owner['projection']['value'] == '100%'
assert owner['projection']['detail'] == '2 of 2 applicable ICT tasks ready. 1 task expiring soon. No tasks need attention.'
assert roster['resultKind'] == 'error' and roster['projection'] == {'message': 'Internal Error'}
assert 'Unavailable' in (root / 'roster-critical-tasks-denied.txt').read_text()
capture = json.loads((root / 'owner-dashboard-page-data.json').read_text())
assert capture['status'] == 200 and capture['redactedSlots'] == 2
summaries = []
for record in capture['records']:
    table = record.get('data', [])
    for index, value in enumerate(table):
        if isinstance(value, dict) and 'overallReadinessPercent' in value and 'readyCount' in value:
            summaries.append(decode(table, index))
assert len(summaries) == 1
summary = summaries[0]
assert summary['overallReadinessPercent'] == 60 and summary['readyCount'] == 3 and summary['applicableCount'] == 5
result = {'ownerPersonnel': owner, 'personnelOnly': roster, 'dashboardSummary': summary, 'dashboardVisibleCriticalTasksCard': False, 'credentialSlotsRedactedBeforePersistence': 6}
(root / 'reverse-consumer-verdicts.json').write_text(json.dumps(result, indent=2) + '\n')
print('Decoded independent ordinary Personnel and Dashboard projections PASS')
