import json,subprocess,sys,pathlib,os
root=pathlib.Path(__file__).parent
phase=sys.argv[1]
assert phase in ('original','seeded','final','cleaned')
tables=['personnel','personnel_follow_ups','counseling_records','personnel_documents','leader_notes','personnel_trainings','personnel_ict_completions','rating_scheme_entries','availability_entries']
summary=[]
os.environ['TMPDIR']='/home/waffleflops/.cache/t2t-d13-context-root-tmp'
for org in ['orgA','orgB']:
 for table in tables:
  p=subprocess.run(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1','rows',table,org],text=True,capture_output=True)
  (root/f'{phase}-{org}-{table}.json').write_text(p.stdout)
  if p.returncode: raise RuntimeError(p.stderr)
  x=json.loads(p.stdout)
  summary.append({'organization':org,'table':table,'count':x['count']})
(root/f'{phase}-collections.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'phase':phase,'collections':len(summary),'rows':sum(x['count'] for x in summary)}))
