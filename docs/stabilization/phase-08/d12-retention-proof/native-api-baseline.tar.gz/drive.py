import json,subprocess,sys,re,pathlib
root=pathlib.Path('/home/waffleflops/.cache/t2t-1360-retention')
name,kind,*args=sys.argv[1:]
if not re.fullmatch(r'[a-zA-Z0-9_-]+',name):raise SystemExit('Unsafe evidence name')
base=['node','scripts/verification/cli.mjs'] if kind=='native' else ['node','.agents/skills/verify-trooptotask/helpers/control.mjs']
command=base+args+['--worker','1']
run=subprocess.run(command,cwd=root,capture_output=True,text=True)
folder=root/'.verification/evidence/verify-trooptotask/retention-baseline'
(folder/(name+'.json')).write_text(run.stdout)
(folder/(name+'.stderr')).write_text(run.stderr)
(folder/(name+'.command.json')).write_text(json.dumps({'command':command,'exit':run.returncode},indent=2)+'\n')
try:
 data=json.loads(run.stdout)
 if kind=='helper' and args[0] in ['seed','retention','rows']:
  if args[0]=='seed': print(json.dumps({k:v for k,v in data.items() if k not in ['files','expiredIds','rows']},indent=2))
  elif args[0]=='rows': print('Captured',args[1:],'rows',data.get('count',data.get('rows',[]).__len__()))
  elif args[1]=='files': print('Captured objects',len(data['files']),'present',sum(x['present'] for x in data['files']))
  else: print(run.stdout)
 else: print(run.stdout[:20000])
except (ValueError,KeyError,IndexError): print(run.stdout[:20000])
print(run.stderr[-1200:]);raise SystemExit(run.returncode)
