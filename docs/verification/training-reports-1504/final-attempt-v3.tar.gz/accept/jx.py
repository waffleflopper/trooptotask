import sys,json,re
t=sys.stdin.read()
i=t.find('{')
try:
    d=json.loads(t[i:]); m=d.get('structuredContent',{}).get('message') or d['content'][0]['text']
except Exception: print(t[:3000]); sys.exit()
x=re.search(r'```json\n(.*)\n```',m,re.S)
print(x.group(1) if x else m[:4000])
