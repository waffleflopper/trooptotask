import importlib.util,json,pathlib,sys
p=pathlib.Path('scripts/verification/environment.py').resolve();spec=importlib.util.spec_from_file_location('owned_environment',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/80ad0b6c7cddb4c6/worker-1');m.status(session);state,workdir,env=m.owned(session)
def q(sql):return json.loads(m.execute(['docker','exec','supabase_db_'+state['project'],'psql','-U','postgres','-d','postgres','-At','-v','ON_ERROR_STOP=1','-c',sql],workdir,env))
fks=q("select json_agg(json_build_object('table',c.relname,'column',a.attname)) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum=k.conkey[1] where k.contype='f' and k.confrelid='public.organizations'::regclass and n.nspname='public';")
r=pathlib.Path('.verification/evidence/verify-trooptotask/d17-settings-baseline');fixture=json.loads((r/'fixture.json').read_text());x={'project':state['project'],'organizations':{}}
ident=lambda v:'"'+v.replace('"','""')+'"'
for org in ['orgA','orgB']:
 oid=fixture['ids'][org];data={}
 for fk in fks:
  table,col=fk['table'],fk['column'];data[table]=q(f"select json_build_object('count',count(*),'ids',coalesce(json_agg(id order by id),'[]'::json)) from public.{ident(table)} where {ident(col)}='{oid}'::uuid;")
 x['organizations'][org]={'id':oid,'tables':data}
x['storage_objects']=q("select coalesce(json_agg(json_build_object('id',id,'bucket',bucket_id,'path',name) order by id),'[]'::json) from storage.objects;")
(r/(sys.argv[1]+'.json')).write_text(json.dumps(x,indent=2)+'\n');print(sys.argv[1], {org:sum(v['count'] for v in d['tables'].values()) for org,d in x['organizations'].items()},'file metadata:',len(x['storage_objects']))
