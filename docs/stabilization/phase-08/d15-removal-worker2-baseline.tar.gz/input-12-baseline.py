"""Fixed native fault/wait preparation stages; stop on missing/ambiguous controls."""
import json
from pathlib import Path
import sys
from drive import E, ROOT, app, click, control, fill, native, original_rows, provider, reload, rows, save, screenshot, snapshot


def read(name):
    return json.loads((E / name).read_text())


def actor(kind="configure"):
    return read(kind + "-actor-stdout.json")


def board(who, tag):
    native("navigate_page", {"pageId": who["pageId"], "type": "url", "url": who["origin"] + who["path"]}, tag + "-navigate")
    snapshot(who["pageId"], tag + "-board")


def open_packet(page, seed, tag):
    click(page, "button", "SM SPC " + seed["person"]["last_name"] + ", Synthetic", tag + "-packet", prefix=True)


def select_template(page, label, template_name, tag):
    click(page, "combobox", label, tag + "-open-select")
    click(page, "option", template_name, tag + "-option")


def assignment(page, seed, template_name, tag, switch=False):
    action = "Switch Template" if switch else "Assign Template"
    click(page, "button", action, tag + "-open")
    select_template(page, "New Template" if switch else "Template", template_name, tag)
    screenshot(page, tag + "-filled")
    click(page, "button", action, tag + "-submit")
    snapshot(page, tag + "-saved")
    screenshot(page, tag + "-saved")
    rows("personnel_onboardings", "orgA", tag + "-parent", "id", seed["packets"][0]["id"])
    saved = rows("onboarding_step_progress", "orgA", tag + "-progress", "onboarding_id", seed["packets"][0]["id"])
    save(tag + "-saved-progress-ids.json", [row["id"] for row in saved])
    reload(page, tag + "-persistence")
    open_packet(page, seed, tag + "-persistence")
    snapshot(page, tag + "-persistence-open")
    screenshot(page, tag + "-persistence-open")


def native_remove(page, seed, tag):
    control(["network", "arm-observe", str(page), "onboarding-steps"], tag + "-network-arm")
    open_packet(page, seed, tag)
    control(["feedback", "arm", str(page)], tag + "-feedback-arm")
    screenshot(page, tag + "-before")
    click(page, "button", "Remove", tag)
    snapshot(page, tag + "-after")
    screenshot(page, tag + "-after")
    control(["feedback", "state", str(page)], tag + "-feedback-state")
    control(["network", "state", str(page)], tag + "-network-state")
    native("list_network_requests", {"pageId": page}, tag + "-native-network")
    rows("onboarding_step_progress", "orgA", tag + "-progress", "onboarding_id", seed["packets"][0]["id"])


def restore_remove(page, tag):
    control(["feedback", "restore", str(page)], tag + "-feedback-restore")
    control(["network", "restore", str(page)], tag + "-network-restore")


def clean_cohort(seed, ordinary_ids, tag):
    control(["clean-seeds"], tag + "-clean-seeds")
    targets = [("personnel", seed["person"]["id"]), ("personnel_onboardings", seed["packets"][0]["id"])]
    targets += [("onboarding_step_progress", value) for value in sorted(set(ordinary_ids + [row["id"] for row in seed["progress"]]))]
    result = [{"table": table, "id": value, "rows": rows(table, "orgA", tag + "-absence-" + str(index), "id", value)}
              for index, (table, value) in enumerate(targets)]
    save(tag + "-exact-id-absence.json", result)
    assert all(not item["rows"] for item in result), "Cleanup left a captured ID"


def main(phase):
    if phase == "initialize":
        app("doctor", "initial-doctor")
        control(["fixture"], "fixture")
        original_rows("original-before")
        control(["actor", "onboardingConfigure", "onboarding"], "configure-actor")
        control(["actor", "onboardingOperate", "onboarding"], "operate-actor")
        snapshot(actor()["pageId"], "configure-initial")
        snapshot(actor("operate")["pageId"], "operate-initial")
    elif phase == "fault-prepare":
        seed = control(["seed", "onboarding-legacy"], "fault-seed")
        page = actor()["pageId"]
        reload(page, "fault-configure-fresh")
        open_packet(page, seed, "fault-legacy")
        assignment(page, seed, "Verification Onboarding A", "fault-assign")
        provider("capture", E / "fault-seed-stdout.json", "fault-capture")
    elif phase == "fault-install":
        provider("fault-on", E / "fault-seed-stdout.json", "fault-install",
                 Path(read("fault-capture-stdout.json")["prepared"]))
    elif phase == "fault-remove":
        native_remove(actor("operate")["pageId"], read("fault-seed-stdout.json"), "fault-native-remove")
        provider("capture", E / "fault-seed-stdout.json", "fault-after-failure")
        before = read("fault-capture-stdout.json")
        after = read("fault-after-failure-stdout.json")
        unchanged = json.loads(Path(before["prepared"]).read_text())["snapshot"] == json.loads(Path(after["prepared"]).read_text())["snapshot"]
        save("fault-unchanged-after-failure.json", {"unchanged": unchanged,
             "before": before["prepared"], "after": after["prepared"], "httpOutcomeMustBeReadSeparately": True})
        assert unchanged, "Provider business rows changed during the intentional fault"
    elif phase == "fault-off-retry":
        seed, page = read("fault-seed-stdout.json"), actor("operate")["pageId"]
        provider("fault-off", E / "fault-seed-stdout.json", "fault-off",
                 Path(read("fault-capture-stdout.json")["prepared"]))
        restore_remove(page, "fault-first")
        native_remove(page, seed, "fault-real-retry")
        restore_remove(page, "fault-retry")
        reload(page, "fault-retry-persistence")
        open_packet(page, seed, "fault-retry-persistence")
        snapshot(page, "fault-retry-persistence-open")
        screenshot(page, "fault-retry-persistence-open")
        target = next(row["id"] for row in seed["progress"] if row["step_name"] == "Paperwork")
        assert not rows("onboarding_step_progress", "orgA", "fault-retry-target-absence", "id", target)
    elif phase == "fault-clean":
        seed = read("fault-seed-stdout.json")
        clean_cohort(seed, read("fault-assign-saved-progress-ids.json"), "fault")
        after = original_rows("original-after-fault")
        assert after == read("original-before-rowsets.json"), "Original rows were not restored before next cohort"
    elif phase == "wait-prepare":
        seed = control(["seed", "onboarding-legacy"], "wait-seed")
        who, page = actor(), actor()["pageId"]
        board(who, "wait-fresh")
        click(page, "link", "Templates", "wait-templates")
        before = rows("onboarding_templates", "orgA", "wait-templates-before")
        click(page, "button", "Duplicate Verification Onboarding A", "wait-duplicate")
        after = rows("onboarding_templates", "orgA", "wait-templates-after-duplicate")
        added = [row for row in after if row["id"] not in {row["id"] for row in before}]
        assert len(added) == 1, "Native duplicate did not produce one distinct template"
        clone = added[0]
        name = "D15 Removal Matching " + seed["tag"]
        save("wait-native-clone-initial.json", clone)
        click(page, "button", "Edit " + clone["name"], "wait-rename-template")
        fill(page, "Name", name, "wait-rename-template")
        click(page, "button", "Save", "wait-rename-template-save")
        click(page, "button", "Edit Verification Paperwork", "wait-edit-paperwork")
        fill(page, "Name", "Paperwork", "wait-edit-paperwork")
        click(page, "button", "Save Changes", "wait-edit-paperwork-save")
        screenshot(page, "wait-matching-template")
        definitions = rows("onboarding_template_steps", "orgA", "wait-matching-definitions", "template_id", clone["id"])
        save("wait-native-template-manifest.json", {"id": clone["id"], "name": name, "definitionIds": [row["id"] for row in definitions]})
        reload(page, "wait-template-persistence")
        screenshot(page, "wait-template-persistence")
        board(who, "wait-assign-entry")
        open_packet(page, seed, "wait-legacy")
        assignment(page, seed, name, "wait-assign")
        assignment(page, seed, "Verification Onboarding A", "wait-switch-away", switch=True)
        provider("capture", E / "wait-seed-stdout.json", "wait-capture")
    elif phase == "wait-readback":
        drained = read("wait-drained-outcomes.json")
        assert drained["allSettled"], "No navigation while pending"
        seed, page = read("wait-seed-stdout.json"), actor()["pageId"]
        rows("personnel_onboardings", "orgA", "wait-final-parent", "id", seed["packets"][0]["id"])
        saved = rows("onboarding_step_progress", "orgA", "wait-final-progress", "onboarding_id", seed["packets"][0]["id"])
        save("wait-all-ordinary-progress-ids.json", sorted(set(read("wait-assign-saved-progress-ids.json")
             + read("wait-switch-away-saved-progress-ids.json") + [row["id"] for row in saved])))
        reload(page, "wait-final-persistence")
        open_packet(page, seed, "wait-final-persistence")
        snapshot(page, "wait-final-persistence-open")
        screenshot(page, "wait-final-persistence-open")
        save("wait-readback-limit.json", {"outcome": "UNCLASSIFIED", "nativeReloadSeparateFromApiResponses": True})
    elif phase == "wait-clean":
        seed, page, manifest = read("wait-seed-stdout.json"), actor()["pageId"], read("wait-native-template-manifest.json")
        board(actor(), "wait-clean-board")
        click(page, "link", "Templates", "wait-clean-templates")
        click(page, "button", "Delete " + manifest["name"], "wait-clean-delete-template")
        click(page, "button", "Delete", "wait-clean-delete-confirm")
        reload(page, "wait-clean-template-persistence")
        screenshot(page, "wait-clean-template-persistence")
        assert not rows("onboarding_templates", "orgA", "wait-template-absence", "id", manifest["id"])
        for index, value in enumerate(manifest["definitionIds"]):
            assert not rows("onboarding_template_steps", "orgA", "wait-definition-absence-" + str(index), "id", value)
        clean_cohort(seed, read("wait-all-ordinary-progress-ids.json"), "wait")
        after = original_rows("original-after-all")
        assert after == read("original-before-rowsets.json"), "Original A/B rows changed"
        app("doctor", "final-doctor")
    else:
        raise SystemExit("Unknown fixed baseline phase")


if __name__ == "__main__":
    main(sys.argv[1])
