import hashlib,json,re,datetime
from pathlib import Path
r=Path(__file__).parent
load=lambda n:json.loads((r/n).read_text())
sections={'counselingRecords':('counseling_records','Counseling Records'),'leaderNotes':('leader_notes','Leader Notes'),'personnelFollowUps':('personnel_follow_ups','Personnel Follow-ups'),'personnelDocuments':('personnel_documents','Personnel Documents')}
raw=load('organization.json');sheets={s['name']:s for s in load('organization-workbook-readback.json')['sheets']};personSheets={s['name']:s for s in load('person-workbook-readback.json')['sheets']}
people={p['id']:p for p in load('before-export-orgA-personnel.json')['rows']}
label=lambda p:f"{p['rank']} {p['last_name']}, {p['first_name']}"
normalize=lambda v: None if v in (None,'') else v
objects=lambda s:[{h:normalize(row[i] if i<len(row) else None) for i,h in enumerate(s['headers'])} for row in s['rows']]
canonical=lambda rows:sorted(rows,key=lambda x:json.dumps(x,sort_keys=True))
fieldHeader=lambda key:' '.join(w.capitalize() for w in key.split('_'))
results={}
for key,(table,title) in sections.items():
 expected=load(f'before-export-orgA-{table}.json')['rows'];foreign=load(f'before-export-orgB-{table}.json')['rows'];assert len(foreign)==1
 assert canonical(raw['sections'][key])==canonical(expected),(key,'raw JSON rows')
 assert raw[key]==raw['sections'][key],(key,'retained top-level projection')
 entry=next(x for x in raw['sectionInventory'] if x['key']==key);assert entry['rowCount']==len(expected) and entry['table']==table
 assert not {x['id'] for x in foreign}&{x['id'] for x in raw['sections'][key]}
 ws=sheets['Raw - '+title];headers=set(ws['headers']);assert headers=={fieldHeader(k) for x in expected for k in x},(key,'raw columns')
 assert canonical(objects(ws))==canonical([{fieldHeader(k):normalize(v) for k,v in x.items()} for x in expected]),(key,'raw workbook values')
 readable=[]
 for x in expected:
  v={'Person':label(people[x['personnel_id']])}
  if table=='counseling_records':v.update({'Date Conducted':x['date_conducted'],'Subject':x['subject'],'Key Points':x['key_points'],'Plan Of Action':x['plan_of_action'],'Status':x['status'],'Notes':x['notes']})
  elif table=='leader_notes':v.update({'Author':x['author'],'Text':x['text'],'Created At':x['created_at'],'Archived At':x['archived_at']})
  elif table=='personnel_follow_ups':v.update({'Title':x['title'],'Notes':x['notes'],'Due Date':x['due_date'],'Status':x['status'],'Created At':x['created_at'],'Completed At':x['completed_at'],'Archived At':x['archived_at']})
  elif table=='personnel_documents':v.update({'Title':x['title'],'File Name':x['file_path'].rsplit('/',1)[-1],'File Size Bytes':x['file_size_bytes'],'Content Type':x['content_type'],'Uploaded By':x['uploaded_by'],'Created At':x['created_at'],'Archived At':x['archived_at']})
  readable.append({k:normalize(v) for k,v in v.items()})
 assert canonical(objects(sheets[title]))==canonical(readable),(key,'readable workbook values')
 results[key]={'sameOrganizationRawRowsExact':len(expected),'rawWorkbookRowsExactWithBlankNullCells':len(expected),'readableRowsMatchStoredValuesAndPersonLabels':len(readable),'foreignSentinelIdExcluded':foreign[0]['id']}
assert list(personSheets)==['Personnel Info','Training Records','Counseling Records','Availability History']
pid='d49c2003-397f-4796-bfb0-fe47046a3c86';person=people[pid]
info={x['Field']:x['Value'] for x in objects(personSheets['Personnel Info'])}
assert all(info[k]==v for k,v in {'Rank':'SPC','Last Name':person['last_name'],'First Name':'Synthetic','MOS':'68W','Duty Role':'Medic','Group':'Alpha','ETS':None,'PCS / DEROS':None,'Archived At':None}.items())
expectedCounsel=[x for x in load('before-export-orgA-counseling_records.json')['rows'] if x['personnel_id']==pid]
expected=[{'Date':x['date_conducted'],'Subject':x['subject'],'Key Points':normalize(x['key_points']),'Plan of Action':normalize(x['plan_of_action']),'Status':x['status'],'Follow-Up Date':normalize(x['follow_up_date']),'Notes':normalize(x['notes'])} for x in expectedCounsel]
assert canonical(objects(personSheets['Counseling Records']))==canonical(expected)
assert objects(personSheets['Training Records'])==[{'Training Type':'Verification Required Training','Completed Date':'2026-09-14','Expiration Date':None,'Notes':None}]
assert objects(personSheets['Availability History'])==[]
exportRows=load('exports-after-excel.json')['rows'];jsonRows=load('exports-after-json.json')['rows'];assert len(jsonRows)==1 and len(exportRows)==2
assert load('exports-foreign-after-all.json')['rows']==[]
metadata={}
for name,file,net in [('organization-json','organization.json','organization-json-network.json'),('organization-excel','organization.xlsx','organization-excel-network.json'),('person-workbook','person.xlsx','person-workbook-network.json')]:
 saved=load(name+'-save.json');data=(r/file).read_bytes();assert saved['bytes']==len(data) and saved['sha256']==hashlib.sha256(data).hexdigest()
 call=load(net)['calls'];assert len(call)==1 and call[0]['status']==200
 assert call[0]['contentDisposition']==f'attachment; filename="{saved["filename"]}"' and call[0]['contentType']==saved['mimeType']
 metadata[file]=saved
 if name!='person-workbook':
  rows=jsonRows if name=='organization-json' else [x for x in exportRows if x['id']!=jsonRows[0]['id']]
  assert len(rows)==1;row=rows[0];assert row['status']=='completed' and row['file_size_bytes']==len(data) and row['requested_by']=='a6429a4e-0b73-4f1e-a87d-54c85cd8ad82' and row['file_path'] is None
  assert datetime.datetime.fromisoformat(row['completed_at'])>=datetime.datetime.fromisoformat(row['created_at'])
old={x['id'] for x in load('audit-before-export.json')['rows']};audits=[x for x in load('audit-after-exports.json')['rows'] if x['id'] not in old]
assert {x['action'] for x in audits}=={'export.created','export.excel_created','personnel.exported'} and len(audits)==3
assert all(x['user_id']=='a6429a4e-0b73-4f1e-a87d-54c85cd8ad82' for x in audits)
assert {x['resource_id'] for x in audits}=={pid,*[x['id'] for x in exportRows]}
out={'artifactSections':results,'personWorkbook':{'fourExistingSheets':list(personSheets),'counselingRows':len(expected),'includesIndependentArchivedHistory':True,'trainingRowExact':True,'availabilityEmptyForDedicatedPerson':True},'downloads':metadata,'completedOrganizationExportIds':[x['id'] for x in exportRows],'newSuccessAuditIds':[x['id'] for x in audits],'limits':'Workbook blank cells normalize null/empty; raw JSON retains typed values. Organization completion updates are best-effort; these two actual statuses are completed. Native owner downloads and ordinary B setup are separate. No broader D24 acceptance.'}
(r/'export-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'artifactRawAndReadableRows':{k:v['sameOrganizationRawRowsExact'] for k,v in results.items()},'foreignSentinelsExcluded':4,'organizationLifecyclesCompleted':2,'personSheets':list(personSheets),'successAudits':3}))
