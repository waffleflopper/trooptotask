SET statement_timeout='10s'; SET lock_timeout='3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_start_1a5b0fbc_62d0e8a5_save ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.t2t_d15_start_1a5b0fbc_62d0e8a5_save();
DROP TRIGGER IF EXISTS t2t_d15_start_1a5b0fbc_62d0e8a5_delete ON public.personnel_onboardings;
DROP FUNCTION IF EXISTS public.t2t_d15_start_1a5b0fbc_62d0e8a5_delete();
COMMIT;
SELECT json_build_object('removed',true);
