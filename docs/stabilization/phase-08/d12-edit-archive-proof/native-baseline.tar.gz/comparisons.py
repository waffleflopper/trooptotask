import json,sys,datetime
from pathlib import Path
p=Path(sys.argv[1]); checks=[]
def data(name): return json.loads((p/(name+'.json')).read_text())
def rows(name): return {r['id']:r for r in data(name)['rows']}
def check(label,actual,expected):
 assert actual==expected,(label,actual,expected)
 checks.append(label)
def modified(base,changes={},removed=()):
 return {k:dict(v,**changes.get(k,{})) for k,v in base.items() if k not in removed}
def text(name):
 d=data(name);return '\n'.join(c.get('text','') for c in d['content'] if c['type']=='text')
def stamp(x): return datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
s=data('seed'); ids=s['ids']; base=rows('before-personnel'); foreign=rows('before-foreign')
tables=['leader_notes','personnel_follow_ups','counseling_records','personnel_documents','personnel_trainings','personnel_ict_completions']
check('A baseline identities',len(base),7);check('B baseline identities',len(foreign),1)
for phase in ['edit-approval-failed','edit-retry','edit-pending']:
 check(phase+' Person fields',rows(phase+'-personnel'),base)
 check(phase+' foreign unchanged',rows(phase+'-foreign'),foreign)
 check(phase+' control unchanged',rows(phase+'-control'),rows('before-control'))
 for table in tables:check(phase+' '+table+' unchanged',rows(phase+'-'+table),rows('before-'+table))
check('failed approval observed no request (transcript excerpt; raw file unavailable)',data('edit-approval-failed-provider-observation')['observed']['count'],0)
request=data('edit-retry-requests')['rows'];check('approval one pending request',[(r['resource_id'],r['status']) for r in request],[(ids['duplicateAlpha'],'pending')])
check('pending replay exact same request',data('edit-pending-requests')['rows'],request)
check('Edit failure closes unexpectedly','dialog "Edit Personnel"' in text('edit-approval-failed-visible'),False)
check('Edit reopen lost draft', 'textbox "Duty Role" value="Medic"' in text('edit-reopen-lost-draft'),True)
check('direct failure closes unexpectedly','dialog "Edit Personnel"' in text('direct-edit-failed-visible'),False)
check('direct failed Person fields',rows('direct-edit-failed-personnel'),base)
br=rows('direct-edit-retry-personnel');bt=br[ids['duplicateBravo']]['archived_at'];assert bt
check('direct archived only selected Person',br,modified(base,{ids['duplicateBravo']:{'archived_at':bt}}))
check('cancel permanent unchanged',rows('permanent-cancel-personnel'),br)
check('detail failure Person unchanged',rows('detail-failed-personnel'),br)
check('permanent failed Person unchanged',rows('permanent-failed-personnel'),br)
for phase in ['detail-failed','permanent-failed']:
 for table in tables:check(phase+' '+table+' unchanged',rows(phase+'-'+table),rows('before-'+table))
 check(phase+' foreign',rows(phase+'-foreign'),foreign);check(phase+' control',rows(phase+'-control'),rows('before-control'))
removed=(ids['archivedDuplicate'],)
permanent=modified(br,removed=removed)
check('permanent removed exact ID',rows('permanent-retry-personnel'),permanent)
check('permanent removal reload persisted',rows('permanent-retry-reload-personnel'),permanent)
a=rows('detail-archived-personnel'); t=a[ids['person']]['archived_at'];assert t
check('detail parent exact fields',a,modified(permanent,{ids['person']:{'archived_at':t}}))
active={'leader_notes':ids['noteActive'],'counseling_records':ids['counselingActive'],'personnel_documents':ids['documentActive'],'personnel_follow_ups':ids['followOpen']}
for table in tables:
 b=rows('before-'+table); got=rows('detail-archived-'+table); restored=rows('detail-restored-'+table)
 expected={k:dict(v) for k,v in b.items()}
 if table in active:
  k=active[table];expected[k]['archived_at']=t
  if table=='personnel_follow_ups':expected[k]['status']='archived'
  if 'updated_at' in expected[k]:
   assert stamp(got[k]['updated_at'])>=stamp(b[k]['updated_at'])
   expected[k]['updated_at']=got[k]['updated_at']
 check('detail archive '+table+' exact event/history',got,expected)
 expected={k:dict(v) for k,v in b.items()}
 if table in active and 'updated_at' in expected[active[table]]:
  k=active[table];assert stamp(restored[k]['updated_at'])>=stamp(got[k]['updated_at'])
  expected[k]['updated_at']=restored[k]['updated_at']
 check('detail restore '+table+' exact history',restored,expected)
 for phase in ['end']:check(phase+' '+table,rows(phase+'-'+table),expected)
check('detail owner restore Person',rows('detail-restored-personnel'),permanent)
restoredbase=modified(base,removed=removed)
for phase in ['direct-edit-restored','operate-permanent-valid-denied','review-failed','approved-restored','end']:
 check(phase+' exact active Person fields',rows(phase+'-personnel'),restoredbase)
reviewed=rows('review-approved-personnel');rt=reviewed[ids['duplicateAlpha']]['archived_at'];assert rt
check('review approved only requested Person',reviewed,modified(restoredbase,{ids['duplicateAlpha']:{'archived_at':rt}}))
check('review failure retains pending request',data('review-failed-requests')['rows'],request)
check('review success same approved request',data('review-approved-requests')['rows'],[dict(request[0],status='approved')])
check('final foreign unchanged',rows('end-foreign'),foreign);check('final control unchanged',rows('end-control'),rows('before-control'))
known={ids[x] for x in ['person','duplicateAlpha','duplicateBravo','archivedDuplicate']}
check('cleaned original A rows',rows('cleaned-personnel'),{k:v for k,v in base.items() if k not in known})
check('cleaned original B rows',rows('cleaned-foreign'),foreign)
check('approved request not broadly deleted',data('cleaned-requests')['rows'],[dict(request[0],status='approved')])
for phase,code in [('edit-approval-failed',503),('edit-retry',201),('edit-pending',409),('direct-edit-failed',503),('direct-edit-retry',200),('detail-failed',503),('detail-retry',200),('permanent-failed',503),('permanent-retry',200),('review-failed',503),('review-approved',200)]:
 check(phase+' actual matched response',[r['status'] for r in data(phase+'-network')['calls']],[code])
for name in ['doctor-start','doctor-final','cleanup']:check(name+' PASS',data(name)['status'],'PASS')
check('doctor tested revision unchanged',data('doctor-final')['revision'],data('doctor-start')['revision'])
check('doctor tested digest unchanged',data('doctor-final')['candidate'],data('doctor-start')['candidate'])
print(json.dumps({'result':'PASS for captured comparisons; two declared UI draft-loss failures preserved','checks':len(checks),'labels':checks,'detail_event':t,'direct_event':bt,'approved_event':rt},indent=2))

