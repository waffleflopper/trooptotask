import json,pathlib,sys,subprocess
c=pathlib.Path(__file__).parent;sys.path.insert(0,str(c));import native_driver as d
run=json.loads((c/'run.json').read_text())
def full(label):
 subprocess.run(['python3',str(c/'full-rows.py'),label,run['session']],check=True)
 return json.loads((d.E/(label+'.json')).read_text())['rows']
def loaded(label):return json.loads(json.loads((d.E/(label+'.json')).read_text())['stdout'])
def names(r,role):return [n.get('name') for n in d.walk(r['structuredContent']['snapshot']) if n.get('role')==role]
def rankwire(label,page=2):
 r=d.tool(label+'-requests','list_network_requests',{'pageId':page,'resourceTypes':['fetch','xhr'],'includePreservedRequests':True})
 x=[a for a in r['structuredContent']['networkRequests'] if '/settings/ranks?' in a['url'] and a['method']=='POST'];assert x
 return d.tool(label,'get_network_request',{'pageId':page,'reqid':x[-1]['requestId']})
def fill(label,fields,page=2):
 r=d.snap(label+'-before',page);nodes=list(d.walk(r['structuredContent']['snapshot']));out=[]
 for role,name,value in fields:
  matches=[n for n in nodes if n.get('role')==role and n.get('name')==name];assert len(matches)==1,(role,name,len(matches));out.append({'uid':matches[0]['id'],'value':value})
 return d.tool(label,'fill_form',{'pageId':page,'elements':out})
def artifact_button(label,title,button,page=2):
 r=d.snap(label+'-before',page);ns=list(d.walk(r['structuredContent']['snapshot']));indices=[i for i,n in enumerate(ns) if n.get('role') in ['heading','StaticText'] and n.get('name')==title];assert len(indices)==1,(title,indices)
 choices=[n for n in ns[indices[0]+1:] if n.get('role')=='button' and n.get('name')==button];assert choices,(title,button)
 (d.E/(label+'-target.json')).write_text(json.dumps({'exactTitleOrText':title,'followingAction':button,'nativeUID':choices[0]['id']},indent=2))
 return d.tool(label,'click',{'pageId':page,'uid':choices[0]['id']})
