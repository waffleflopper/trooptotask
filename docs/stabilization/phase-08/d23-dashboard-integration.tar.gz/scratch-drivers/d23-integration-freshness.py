import importlib.util,re,json
spec=importlib.util.spec_from_file_location('capture','.verification/tmp/d23-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
actor=m.call('helper','actor',['trainingConfigure','training'],'actor-training-configure.json');page=actor['pageId']
def snap(page,label):
 x=m.native('take_snapshot',{'pageId':page},label+'.json');return '\n'.join(c.get('text','')for c in x['content'])
def click(page,label,role,name,last=False):
 t=snap(page,label+'-before');modal=re.search(r'uid=(\S+) button "Got it"',t)
 if modal:
  m.native('click',{'pageId':page,'uid':modal[1]},label+'-dismiss.json');t=snap(page,label+'-dismissed')
 uids=re.findall(r'uid=(\S+) '+role+r' "'+re.escape(name)+r'"',t)
 if not uids:raise RuntimeError('Missing '+name)
 m.native('click',{'pageId':page,'uid':uids[-1 if last else 0]},label+'-click.json')
click(page,'training-targeted','button','Able Verification Targeted Training: Expired 10d ago')
t=snap(page,'training-targeted-dialog');assert 'dialog "Edit Training Record"' in t
click(page,'training-delete','button','Delete')
t=snap(page,'training-delete-confirm');assert 'alertdialog "Delete Training Record"' in t
click(page,'training-delete-explicit','button','Delete',last=True)
m.native('navigate_page',{'pageId':page,'type':'reload'},'training-deleted-reload.json');snap(page,'training-deleted-reloaded')
rows=m.call('helper','rows',['personnel_trainings','orgA'],'training-deleted-rows.json')
ids=json.loads((m.out/'fixture.json').read_text())['ids'];seed=json.loads((m.out/'seed-dashboard.json').read_text())
deleted=next(r['id']for b in seed['batches']if b['table']=='personnel_trainings'for r in b['rows']if r['personnel_id']==ids['personA'] and r['training_type_id']==ids['trainingTargeted'])
assert not any(r['id']==deleted for r in rows['rows'])
original=json.loads((m.out/'original-orgA-personnel_trainings.json').read_text())
current=next(r for r in rows['rows']if r['id']==ids['trainingCurrent']);assert current==next(r for r in original['rows']if r['id']==ids['trainingCurrent'])
(m.out/'native-deletion-readback.json').write_text(json.dumps({'deletedSeedId':deleted,'absent':True,'originalCurrentUnchanged':True},indent=2)+'\n')
m.capture(2,'training-deleted');t=snap(2,'training-deleted-native');assert 'StaticText "33%"' in t
click(2,'onboarding-source','link','Onboard');m.native('navigate_page',{'pageId':2,'type':'reload'},'onboarding-source-reload.json')
t=snap(2,'onboarding-source-reloaded');assert '33%' in t
click(2,'onboarding-return-home','link','Home')
m.call('helper','dashboard-access',['dashboardView','no-training'],'training-absent-change.json');m.capture(2,'training-absent-snapshot')
t=snap(2,'training-absent-native');assert 'StaticText "67%"' in t
m.call('helper','dashboard-access',['dashboardView','restore'],'training-restored-change.json');m.capture(2,'training-restored-truth')
t=snap(2,'training-restored-native');assert 'StaticText "33%"' in t
m.call('helper','rows',['onboarding_step_progress','orgA'],'step-progress-after-deletion.json')
click(2,'personnel-consumer','link','Personnel');snap(2,'personnel-consumer-observed');click(2,'personnel-return','link','Home');m.capture(2,'consumer-return')
print('Native seeded deletion, source pipeline and authority snapshots captured',flush=True)
