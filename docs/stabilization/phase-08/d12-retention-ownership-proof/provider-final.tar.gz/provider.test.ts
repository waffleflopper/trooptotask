import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createClient } from '@supabase/supabase-js';
import { beforeAll, afterAll, describe, expect, it } from 'vitest';
import { cleanupArchivedRecords } from '$lib/server/core/useCases/archiveRetention';
import { createSupabaseDataStore } from '$lib/server/adapters/supabaseDataStore';
import { createSupabaseStorageAdapter } from '$lib/server/adapters/supabaseStorage';
import { bindLeaderNoteDataSource } from '$lib/server/adapters/leaderNoteDataSource';
import { createSupabaseAssignmentTypeRetention } from '$features/calendar/index.server';
import { createSupabasePersonnelRetentionSource } from '$features/personnel/index.server';
import { readRetentionFiles } from '../../../../.agents/skills/verify-trooptotask/helpers/personnel-retention.mjs';
import { processIdentity } from '../../../../scripts/verification/core.mjs';

const run = promisify(execFile);
const root = process.cwd();
const evidence = path.join(root, '.verification/evidence/verify-trooptotask/retention-provider-final');
const write = (name, value) => fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2) + '\n');
const read = async (file) => JSON.parse(await fs.readFile(file, 'utf8'));
const tables = ['personnel', 'personnel_documents', 'counseling_records', 'leader_notes', 'personnel_follow_ups', 'rating_scheme_entries', 'personnel_trainings', 'personnel_ict_completions', 'notifications'];
const NOW = new Date('2026-05-30T12:00:00.000Z');
const CUTOFF = '2025-05-30T12:00:00.000Z';
let session, fixture, client, store, storage, original;
let requests = [];
let phase = 'ownership';
let fault = null;
const recordedFiles = [];
const summary = [];

async function helper(label, ...args) {
 const command = ['.agents/skills/verify-trooptotask/helpers/control.mjs', '--worker', '2', ...args];
 try {
  const result = await run(process.execPath, command, { cwd: root, maxBuffer: 4000000 });
  await write(label + '-helper.json', { command: ['node', ...command], exit: 0, stdout: result.stdout, stderr: result.stderr });
  return JSON.parse(result.stdout);
 } catch (error) {
  await write(label + '-helper.json', { command: ['node', ...command], exit: error.code, stdout: error.stdout, stderr: error.stderr });
  throw error;
 }
}

async function rows() {
 const out = {};
 for (const table of tables) {
  out[table] = {};
  for (const organization of ['orgA', 'orgB']) {
   out[table][organization] = await store.findMany(table, fixture.ids[organization], undefined, { orderBy: [{ column: 'id', ascending: true }] });
  }
 }
 return out;
}

async function snapshot() {
 const owned = await read(path.join(session, 'verify-trooptotask-owned.json'));
 return { rows: await rows(), objects: (await readRetentionFiles(client, owned)).files };
}

function checked(result) {
 if (result.error) throw new Error('Synthetic provider operation failed: ' + result.error.message);
 return result.data;
}

function expectRetained(before, after, seed) {
 for (const table of tables) {
  expect(after.rows[table].orgB).toEqual(before.rows[table].orgB);
 }
 const retainedIds = seed.retained.filter((person) => person.organization_id === fixture.ids.orgA).map((person) => person.id);
 for (const id of retainedIds) {
  expect(after.rows.personnel.orgA.find((person) => person.id === id)).toEqual(before.rows.personnel.orgA.find((person) => person.id === id));
 }
 for (const file of before.objects.filter((file) => !file.personnelId || seed.retained.some((person) => person.id === file.personnelId))) {
  expect(after.objects.find((candidate) => candidate.bucket === file.bucket && candidate.path === file.path)).toEqual(file);
 }
 // All original rows are independently read and retained exactly.
 for (const table of tables) {
  for (const originalRow of original[table].orgA) {
   expect(after.rows[table].orgA.find((row) => row.id === originalRow.id)).toEqual(originalRow);
  }
 }
}

function expectEvaluation(before, after, seed, removedIds) {
 const prior = before.rows.rating_scheme_entries.orgA.find((row) => row.id === seed.ratingId);
 const current = after.rows.rating_scheme_entries.orgA.find((row) => row.id === seed.ratingId);
 expect(current).toBeDefined();
 if (!removedIds.includes(seed.expiredIds[0])) {
  expect(current).toEqual(prior);
  return;
 }
 const keys = ['rater_person_id', 'senior_rater_person_id', 'intermediate_rater_person_id', 'reviewer_person_id'];
 for (const key of keys) expect(current[key]).toBeNull();
 const withoutEffects = (row) => Object.fromEntries(Object.entries(row).filter(([key]) => !keys.includes(key) && key !== 'updated_at'));
 expect(withoutEffects(current)).toEqual(withoutEffects(prior));
 expect(Date.parse(current.updated_at)).toBeGreaterThanOrEqual(Date.parse(prior.updated_at));
}

beforeAll(async () => {
 const info = await read(path.join(evidence, 'info.json'));
 const allocation = await read(path.join(evidence, 'allocation.json'));
 session = info.session;
 const state = await read(path.join(session, 'session.json'));
 const provider = await read(path.join(session, 'provider.json'));
 const identity = await processIdentity(state.supervisor.pid);
 expect(state.repository).toBe(root);
 expect(state.worker).toBe('2');
 expect(state.phase).toBe('running');
 expect(identity.start).toBe(state.supervisor.start);
 expect(identity.command).toBe(state.supervisor.command);
 const url = new URL(provider.API_URL);
 expect(url.protocol).toBe('http:');
 expect(url.hostname).toBe('127.0.0.1');
 expect(Number(url.port)).toBe(allocation.ports['api.port']);
 fixture = await read(path.join(session, 'fixtures.json'));
 client = createClient(provider.API_URL, provider.SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
  global: {
   fetch: async (input, init) => {
    const address = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url);
    const method = init?.method ?? (input instanceof Request ? input.method : 'GET');
    const startedPhase = phase;
    const inFilter = address.searchParams.get('personnel_id') ?? address.searchParams.get('id');
    const targetedIds = inFilter?.startsWith('in.(') ? inFilter.slice(4, -1).split(',') : [];
    const table = address.pathname.split('/').at(-1);
    const command = startedPhase.endsWith('-command');
    const manifest = ['personnel_documents', 'counseling_records'].includes(table) && address.searchParams.has('personnel_id');
    const confirmation = table === 'personnel' && address.searchParams.has('id');
    const discovery = table === 'personnel' && !address.searchParams.has('id');
    const observation = { phase: startedPhase, method, pathname: address.pathname,
     query: Object.fromEntries([...address.searchParams].filter(([key]) => ['select','organization_id','id','personnel_id','archived_at','offset','limit','order','status','ict_task_id'].includes(key))),
     targetedIds, organizationScoped: address.searchParams.get('organization_id') === 'eq.' + fixture.ids.orgA,
     urlBytes: Buffer.byteLength(address.href), status: null };
    if (command && fault) {
     const blocked = (fault.mode === 'manifest-doc' && table === 'personnel_documents' && manifest && targetedIds.includes(fault.lateId)) ||
      (fault.mode === 'manifest-counseling' && table === 'counseling_records' && manifest && targetedIds.includes(fault.lateId)) ||
      (fault.mode === 'confirmation-failure' && confirmation && targetedIds.includes(fault.lateId)) ||
      (['discovery-failure','parent-discovery-failure'].includes(fault.mode) && discovery && Number(address.searchParams.get('offset') ?? 0) === 1000);
     if (blocked) {
      observation.controlledRejection = fault.mode;
      requests.push(observation);
      throw new Error('Controlled ' + fault.mode);
     }
     if (table === 'delete_expired_personnel' && method === 'POST') {
      const body = JSON.parse(String(init.body));
      expect(body.p_org_id).toBe(fixture.ids.orgA);
      expect(body.p_cutoff).toBe(CUTOFF);
      expect([...body.p_candidate_ids].sort()).toEqual([...fault.candidateIds].sort());
      const forwarded = fault.mode === 'partial' ? body.p_candidate_ids.filter((id) => id === fault.firstId) : fault.mode === 'zero' ? [] : fault.mode === 'rpc-reject' ? ['not-a-valid-uuid'] : body.p_candidate_ids;
      observation.rpc = { organizationId: body.p_org_id, cutoff: body.p_cutoff, requestedIds: body.p_candidate_ids, forwardedIds: forwarded };
      init = { ...init, body: JSON.stringify({ ...body, p_candidate_ids: forwarded }) };
     }
    }
    const response = await fetch(input, init);
    observation.status = response.status;
    if (!response.ok) observation.errorBody = (await response.clone().text()).slice(0, 1500);
    requests.push(observation);
    return response;
   }
  }
 });
 store = createSupabaseDataStore(client);
 storage = createSupabaseStorageAdapter(client);
 await helper('initial-clean', 'clean-seeds');
 original = await rows();
 await write('original-rows.json', original);
});

afterAll(async () => {
 fault = null;
 await helper('final-clean', 'clean-seeds');
 phase = 'final-original-read';
 const final = await rows();
 await write('final-original-rows.json', final);
 expect(final).toEqual(original);
 await write('scenario-summary.json', summary);
 await write('recorded-files.json', recordedFiles);
});

describe('Owned real provider Personnel retention final', () => {
 for (const mode of ['healthy', 'partial', 'confirmation-failure', 'storage-document-failure', 'storage-counseling-failure', 'zero', 'manifest-doc', 'manifest-counseling', 'rpc-reject', 'discovery-failure', 'parent-discovery-failure', 'cutoff', '1001', 'dense']) {
  it(mode, async () => {
   requests = [];
   phase = mode + '-setup';
   console.log('START scenario ' + mode);
   const large = ['1001','confirmation-failure','manifest-doc','manifest-counseling','discovery-failure','parent-discovery-failure'].includes(mode);
   const seed = await helper(mode + '-seed', 'seed', mode === 'dense' ? 'personnel-retention-dense' : large ? 'personnel-retention-1001' : 'personnel-retention');
   recordedFiles.push(...seed.files);
   let before, after, result, error;
   const attempts = [];
   const boundaries = [];
   try {
    if (mode === 'cutoff') {
     checked(await client.from('personnel').update({ archived_at: CUTOFF }).eq('organization_id', fixture.ids.orgA).eq('id', seed.expiredIds.at(-1)));
     checked(await client.from('personnel').update({ archived_at: seed.expiredAt }).eq('organization_id', fixture.ids.orgB).eq('id', seed.retained.find((person) => person.organization_id === fixture.ids.orgB).id));
    }
    phase = mode + '-before';
    before = await snapshot();
    for (const object of before.objects) {
     expect(object.present).toBe(true);
     expect(object.observedSize).toBe(object.size);
     expect(object.observedSha256).toBe(object.sha256);
    }
    const candidateIds = before.rows.personnel.orgA.filter((row) => row.archived_at !== null && Date.parse(row.archived_at) < Date.parse(CUTOFF)).map((row) => row.id);
    fault = { mode, candidateIds, lateId: [...candidateIds].sort().at(-1), firstId: seed.expiredIds[0] };
    const parentOnlyPaths = new Set(['personnel_documents','counseling_records'].flatMap((table) => before.rows[table].orgA.filter((row) => seed.expiredIds.includes(row.personnel_id) && (row.archived_at === null || Date.parse(row.archived_at) >= Date.parse(CUTOFF))).map((row) => row.file_path)));
    const failedBucket = mode === 'storage-document-failure' ? 'personnel-documents' : mode === 'storage-counseling-failure' ? 'counseling-files' : null;
    const scopedStorage = {
     ...storage,
     async remove(bucket, paths) {
      if (bucket === failedBucket && paths.some((candidate) => parentOnlyPaths.has(candidate))) {
       boundaries.push({ fault: mode, bucket, action: 'parent file removal before forwarding', paths });
       throw new Error('Controlled ' + mode);
      }
      boundaries.push({ bucket, action: 'real file removal', paths });
      await storage.remove(bucket, paths);
      boundaries.push({ bucket, action: 'real file removal completed', paths });
     }
    };
    phase = mode + '-command';
    try {
     const personnel = createSupabasePersonnelRetentionSource(client, scopedStorage);
     if (mode === 'parent-discovery-failure') {
      result = await personnel.deleteExpired(fixture.ids.orgA, CUTOFF);
     } else {
      result = await cleanupArchivedRecords({
       store, storage: scopedStorage, personnel,
       leaderNotes: bindLeaderNoteDataSource(store),
       assignmentTypes: createSupabaseAssignmentTypeRetention(client),
       notifications: { async notifyAdmins(orgId, actorId, payload) { attempts.push({ orgId, actorId, payload }); } }
      }, [{ id: fixture.ids.orgA, retentionMonths: 12 }], { now: NOW });
     }
    } catch (caught) { error = { name: caught.name, message: caught.message }; boundaries.push({ action: 'operation rejected after awaited Storage outcomes' }); }
    fault = null;
    phase = mode + '-after';
    after = await snapshot();
    const remaining = after.rows.personnel.orgA.filter((row) => seed.expiredIds.includes(row.id)).map((row) => row.id).sort();
    const removed = seed.expiredIds.filter((id) => !remaining.includes(id));
    const observation = { mode, fixedNow: NOW.toISOString(), cutoff: CUTOFF, seed, before, boundaries, result: result ?? null, error: error ?? null, notificationPortAttempts: attempts, after, discoveredParentCount: before.rows.personnel.orgA.filter((row) => row.archived_at !== null && Date.parse(row.archived_at) < Date.parse(CUTOFF)).length, remainingCandidateIds: remaining, independentlyConfirmedDeletedParentIds: removed, requests };
    await write(mode + '-observations.json', observation);
    summary.push({ mode, error: error ?? null, result: result ?? null, remainingParents: remaining.length, confirmedDeletedParents: removed.length, notificationPortAttempts: attempts.length });
    expectRetained(before, after, seed);
    expectEvaluation(before, after, seed, removed);
    if (mode.endsWith('failure') || mode.startsWith('manifest-')) {
     expect(error?.message).toContain('Controlled ' + mode);
     expect(result).toBeUndefined();
     expect(attempts).toEqual([]);
    } else if (mode === 'rpc-reject') {
     expect(error?.message).toContain('invalid input syntax for type uuid');
     expect(attempts).toEqual([]);
     const rejected = requests.find((request) => request.rpc);
     expect(rejected.status).toBe(400);
     expect(rejected.errorBody).toContain('22P02');
    } else {
     expect(error).toBeUndefined();
    }
    const expectedRemoved = ['partial', 'cutoff'].includes(mode) ? [seed.expiredIds[0]] : ['zero', 'manifest-doc', 'manifest-counseling', 'rpc-reject', 'discovery-failure', 'parent-discovery-failure'].includes(mode) ? [] : seed.expiredIds;
    expect(removed.sort()).toEqual([...expectedRemoved].sort());
    for (const table of ['personnel_documents', 'counseling_records', 'leader_notes', 'personnel_follow_ups']) {
     expect(after.rows[table].orgA.filter((row) => removed.includes(row.personnel_id))).toEqual([]);
    }
    for (const file of before.objects.filter((file) => seed.expiredIds.includes(file.personnelId))) {
     const child = before.rows[file.bucket === 'personnel-documents' ? 'personnel_documents' : 'counseling_records'].orgA.find((row) => row.id === file.rowId);
     const expiredChild = child.archived_at !== null && Date.parse(child.archived_at) < Date.parse(CUTOFF);
     const keep = mode === 'parent-discovery-failure' || (!expiredChild && (mode === 'confirmation-failure' || file.bucket === failedBucket || !removed.includes(file.personnelId)));
     const observed = after.objects.find((candidate) => candidate.bucket === file.bucket && candidate.path === file.path);
     if (keep) expect(observed).toEqual(file);
     else expect(observed.present).toBe(false);
    }
    if (mode === 'parent-discovery-failure') expect(after).toEqual(before);
    if (mode === '1001') {
     const mutation = requests.filter((request) => request.rpc);
     expect(mutation).toHaveLength(1);
     expect(mutation[0].rpc.forwardedIds).toHaveLength(1001);
     expect(mutation[0].status).toBe(200);
    }
    if (mode === 'dense') {
     for (const table of ['personnel_documents','counseling_records']) {
      expect(before.rows[table].orgA.filter((row) => row.personnel_id === seed.expiredIds[0] && row.archived_at === null).length).toBeGreaterThanOrEqual(1001);
      expect(requests.some((request) => request.phase === mode + '-command' && request.pathname.endsWith('/' + table) && request.query.personnel_id && Number(request.query.offset) >= 1000 && request.status === 200)).toBe(true);
     }
     for (const type of ['document','counseling']) {
      const markerId = seed.pageMarkerIds[type];
      const marker = seed.files.find((file) => file.rowId === markerId);
      expect(marker).toBeDefined();
      expect(before.objects.find((file) => file.rowId === markerId).present).toBe(true);
      expect(after.objects.find((file) => file.rowId === markerId).present).toBe(false);
     }
    }
    for (const request of requests.filter((request) => request.phase === mode + '-command' && request.targetedIds.length)) {
     expect(request.urlBytes).toBeLessThan(8192);
     expect(request.targetedIds.length).toBeLessThanOrEqual(100);
     expect(request.organizationScoped).toBe(true);
    }
    if (failedBucket) {
     const otherBucket = failedBucket === 'personnel-documents' ? 'counseling-files' : 'personnel-documents';
     const rejectedAt = boundaries.findIndex((boundary) => boundary.action.startsWith('operation rejected'));
     const completedAt = boundaries.findLastIndex((boundary) => boundary.bucket === otherBucket && boundary.action === 'real file removal completed' && boundary.paths.some((candidate) => parentOnlyPaths.has(candidate)));
     expect(completedAt).toBeGreaterThanOrEqual(0);
     expect(completedAt).toBeLessThan(rejectedAt);
    }
    if (result) {
     expect(result.families.find((family) => family.key === 'personnel').deletedCount).toBe(expectedRemoved.length);
     expect(result.deletedCount).toBe(expectedRemoved.length + 2);
     expect(attempts).toHaveLength(1);
     expect(attempts[0].payload.type).toBe('archive_auto_deleted');
     expect(attempts[0].payload.message).not.toContain('MapRetention');
    }
    console.log('PASS scenario ' + mode + ' removed=' + removed.length + ' capturedSummary=' + attempts.length);
   } finally {
    fault = null;
    await write(mode + '-requests.json', requests);
    await helper(mode + '-cleanup', 'clean-seeds');
    phase = mode + '-cleanup-read';
    const cleanedRows = await rows();
    await write(mode + '-cleaned-rows.json', cleanedRows);
    expect(cleanedRows).toEqual(original);
    const cleanedFiles = await readRetentionFiles(client, { seeded: [{ files: seed.files }] });
    await write(mode + '-cleaned-files.json', cleanedFiles);
    expect(cleanedFiles.files.every((file) => file.present === false)).toBe(true);
   }
  });
 }
});
