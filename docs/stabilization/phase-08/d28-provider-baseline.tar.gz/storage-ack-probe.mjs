import { createClient } from '@supabase/supabase-js';
import { createSupabaseStorageAdapter } from '../../../../src/lib/server/adapters/supabaseStorage.ts';
const client = createClient('http://storage.invalid', 'synthetic-key', {
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  global: { fetch: async (input, init) => Response.json(new Request(input, init).method === 'DELETE' ? [] : {}) }
});
const storage = createSupabaseStorageAdapter(client);
const observations = [];
try {
  await storage.remove('counseling-files', ['org-a/sign-in-rosters/roster-a/scan.pdf']);
  observations.push({ case: 'empty deletion acknowledgment', expected: 'reject unconfirmed existing-object removal', observed: 'resolved', result: 'FAILED' });
} catch { observations.push({ case: 'empty deletion acknowledgment', result: 'PASS' }); }
try {
  const url = await storage.createSignedUrl('counseling-files', 'org-a/sign-in-rosters/roster-a/scan.pdf', 60);
  observations.push({ case: 'missing signed path', expected: 'reject malformed provider acknowledgment', observed: url, result: 'FAILED' });
} catch { observations.push({ case: 'missing signed path', result: 'PASS' }); }
console.log(JSON.stringify({ boundary: 'Actual SDK with finite synthetic HTTP responses. No network, RLS or native proof.', observations }, null, 2));
process.exitCode = observations.some(row => row.result === 'FAILED') ? 1 : 0;
