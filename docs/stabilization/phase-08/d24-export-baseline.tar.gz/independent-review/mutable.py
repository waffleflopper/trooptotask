import json,collections
from pathlib import Path
P=Path('.verification/evidence/verify-trooptotask/d24-export-baseline');O=Path('.verification/tmp/d24-artifact-review');load=lambda n:json.loads((P/n).read_text());issues=[];checks=[]
def rawrows(artifact,title):
 s=next(x for x in json.loads((O/(artifact+'-expanded.json')).read_text())['sheets'] if x['name']==title)
 keys=[h.lower().replace(' ','_') for h in s['headers']]
 return [dict(zip(keys,row+[None]*(len(keys)-len(row)))) for row in s['rows']]
for label,artifact,pre,after in [('owner-json','owner-a','source-before-data_exports-A.json','owner-json-lifecycle-after.json'),('owner-excel','owner-a','before-owner-excel-data_exports.json','owner-excel-lifecycle-after.json'),('admin-json','admin-a','before-admin-json-data_exports.json','admin-json-lifecycle.json'),('admin-excel','admin-a','before-admin-excel-lifecycle.json','admin-excel-lifecycle.json')]:
 rows=load(artifact+'.json')['sections']['dataExports'] if label.endswith('json') else rawrows(artifact,'Raw - Data Export Records')
 before=load(pre)['rows'];post=load(after)['rows'];previous={r['id']:r for r in before};current={r['id']:r for r in rows};new=[r for r in post if r['id'] not in previous]
 if len(new)!=1 or set(current)!=set(previous)|{new[0]['id']}:issues.append({'artifact':label,'error':'lifecycle_snapshot_id_set'})
 for rid,row in previous.items():
  if current.get(rid)!=row:issues.append({'artifact':label,'error':'earlier_lifecycle_values','id':rid})
 if new:
  saved=new[0];snapshot=current.get(saved['id'],{})
  if snapshot.get('status')!='processing' or snapshot.get('file_size_bytes') is not None or snapshot.get('completed_at') is not None:issues.append({'artifact':label,'error':'generation_time_processing_snapshot'})
  if any(snapshot.get(k)!=saved[k] for k in ['id','org_id','requested_by','created_at','file_path']):issues.append({'artifact':label,'error':'same_saved_lifecycle_identity'})
 checks.append({'artifact':label,'previous_completed_rows_retained':len(previous),'same_saved_new_id':new[0]['id'] if new else None,'artifact_snapshot_status':current.get(new[0]['id'],{}).get('status') if new else None,'after_status':new[0]['status'] if new else None})
for artifact,pre,isbook in [('owner-a','source-before-audit_logs-A.json',False),('owner-a','before-owner-excel-audit_logs.json',True)]:
 rows=rawrows(artifact,'Raw - Audit Logs') if isbook else load(artifact+'.json')['sections']['auditLogs'];expected=load(pre)['rows'];actual={r['id']:r for r in rows}
 if set(actual)!={r['id'] for r in expected}:issues.append({'artifact':'owner-excel' if isbook else 'owner-json','error':'audit_source_id_set'})
 for r in expected:
  a=actual.get(r['id'],{})
  if isinstance(a.get('details'),str):a['details']=json.loads(a['details'])
  if a!=r:issues.append({'artifact':'owner-excel' if isbook else 'owner-json','error':'literal_audit_source','id':r['id']})
 checks.append({'artifact':'owner-excel' if isbook else 'owner-json','exact_stored_audit_rows':len(expected)})
for artifact in ['owner-a','admin-a']:
 payload=load(artifact+'.json');rows=rawrows(artifact,'Raw - Notifications');expected=payload['sections']['notifications']
 if rows!=expected:issues.append({'artifact':artifact,'error':'notifications_workbook_saved_fields'})
 feedback=rawrows(artifact,'Raw - Beta Feedback') if payload['sections']['betaFeedback'] else []
 if feedback!=payload['sections']['betaFeedback']:issues.append({'artifact':artifact,'error':'feedback_workbook_saved_fields'})
result={'issues':issues,'checks':checks,'admin_empty_audit_disposition':'Current SQL SELECT policy is Org owners can read own audit logs, also Platform-admin. Ordinary admin lacks this read, so empty admin JSON/workbook Audit is expected; owner positive source set proves actual stored records.'}
(O/'mutable-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
