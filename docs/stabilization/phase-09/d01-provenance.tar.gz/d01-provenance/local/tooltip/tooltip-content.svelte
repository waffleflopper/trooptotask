<script lang="ts">
	import { Tooltip as TooltipPrimitive } from 'bits-ui';
	import { cn } from '$lib/utils.js';
	import TooltipPortal from './tooltip-portal.svelte';
	import type { ComponentProps } from 'svelte';
	import type { WithoutChildrenOrChild } from '$lib/utils.js';

	const uid = $props.id();

	let {
		ref = $bindable(null),
		id = uid,
		class: className,
		sideOffset = 0,
		side = 'top',
		children,
		child: customChild,
		arrowClasses,
		portalProps,
		...restProps
	}: TooltipPrimitive.ContentProps & {
		arrowClasses?: string;
		portalProps?: WithoutChildrenOrChild<ComponentProps<typeof TooltipPortal>>;
	} = $props();
</script>

<TooltipPortal {...portalProps}>
	<TooltipPrimitive.Content
		bind:ref
		{id}
		data-slot="tooltip-content"
		{sideOffset}
		{side}
		class={cn(
			'data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs has-data-[slot=kbd]:pr-1.5 **:data-[slot=kbd]:relative **:data-[slot=kbd]:isolate **:data-[slot=kbd]:z-50 **:data-[slot=kbd]:rounded-sm bg-foreground text-background z-50 w-fit max-w-xs origin-(--bits-tooltip-content-transform-origin)',
			className
		)}
		{...restProps}
	>
		{#snippet child({ props, wrapperProps, open })}
			{#if customChild}
				{@render customChild({ props: { ...props, id, role: 'tooltip' }, wrapperProps, open })}
			{:else}
				<div {...wrapperProps}>
					<div {...props} {id} role="tooltip">
						{@render children?.()}
						<TooltipPrimitive.Arrow>
							{#snippet child({ props })}
								<div
									class={cn(
										'size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground z-50',
										'data-[side=top]:translate-x-1/2 data-[side=top]:translate-y-[calc(-50%+2px)]',
										'data-[side=bottom]:-translate-x-1/2 data-[side=bottom]:-translate-y-[calc(-50%+1px)]',
										'data-[side=right]:translate-x-[calc(50%+2px)] data-[side=right]:translate-y-1/2',
										'data-[side=left]:-translate-y-[calc(50%-3px)]',
										arrowClasses
									)}
									{...props}
								></div>
							{/snippet}
						</TooltipPrimitive.Arrow>
					</div>
				</div>
			{/if}
		{/snippet}
	</TooltipPrimitive.Content>
</TooltipPortal>
