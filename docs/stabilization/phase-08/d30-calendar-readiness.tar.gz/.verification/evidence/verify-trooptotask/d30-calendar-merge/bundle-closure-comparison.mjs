import { readFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import path from 'node:path';
function sizes(root) {
	const out = path.join(root, '.svelte-kit/output/client');
	const m = JSON.parse(readFileSync(path.join(out, '.vite/manifest.json'), 'utf8'));
	const cache = new Map();
	const gz = (f) => cache.get(f) ?? (cache.set(f, gzipSync(readFileSync(path.join(out, f))).length), cache.get(f));
	const res = {};
	for (const k of Object.keys(m).filter((k) => k.startsWith('.svelte-kit/generated/client-optimized/nodes/'))) {
		const src = readFileSync(path.join(root, k), 'utf8');
		const comp = src.match(/src\/routes\/[^"']+/)?.[0] ?? k;
		const seen = new Set();
		const walk = (key) => { if (!m[key] || seen.has(key)) return; seen.add(key); (m[key].imports ?? []).forEach(walk); };
		walk(k);
		let t = 0; for (const f of new Set([...seen].map((x) => m[x].file))) t += gz(f);
		res[comp] = t;
	}
	return res;
}
const a = sizes(process.argv[2]), b = sizes(process.argv[3]);
let n = 0; let maxGrowth = 0; const rows = [];
for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) {
	const d = (b[k] ?? 0) - (a[k] ?? 0);
	rows.push({route:k,base:a[k],candidate:b[k],delta:d}); maxGrowth = Math.max(maxGrowth,d);
	if (Math.abs(d) > 300) { n++; }
}
console.log(JSON.stringify({nodes:Object.keys(b).length,over300:n,maxGrowth,rows}, null, 2));
