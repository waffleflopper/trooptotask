# 1502 final live verification (review sub-agent)
Browser: T3 shared preview tab_3 (own thread; parent's tab_2 not addressable from this thread). Not native. Browser version not observable via preview.
Origin: http://localhost:44775 via environment-port 44775. Worker 1. Candidate 8a87a9fa…109d. Fixture day 2026-10-03.
Login: trainingConfigure via visible form (#email/#password typed, Sign In clicked) -> /org/<orgA>. Credentials not archived.

## 1. Baseline
- Matrix (01-matrix-before.png): Able Required Current 09/2027; Able Targeted Not Done; Baker/Unassigned Required Not Done; Baker/Unassigned Targeted N/A; Optional N/A all.
- rows-before.json: exactly one row 45334c2f… Able/Required 2026-09-26 / 2027-09-26, notes null, cert null.
- Reports via visible Reports link (02-reports-before.png): "25% across 3 personnel"; 1 Current / 0 Expired / 0 Expiring / 3 Not Done; Required card 33 (3 personnel, 2 not done); Targeted 0 (1 personnel, 1 not done); Group Alpha 50% / Bravo 0% / Unassigned 0%; Personnel Detail 3 of 3 (Able, Baker, Unassigned). No B/Foreign rows. PASS.

## 2. Visible Import
- CSV (approved header) pasted into "CSV data": Rank,Last Name,First Name,Training Type,Date / Status,Expiration Date,Notes / SPC,Baker,Synthetic,Verification Required Training,2024-10-03,2025-10-03,note1502final / SPC,Able,Synthetic,Verification Targeted Training,2025-10-18,2026-10-18,note1502final
- Note: importer maps only Last/First/Type/Date/Notes; Rank and Expiration Date columns are ignored; expiry was derived from type validity and matched the literal expected dates.
- Preview (03-import-preview.png): "3 rows loaded" (header row counted in that chip), 2 valid, 2 selected, Source rows 2/3 Ready, checkboxes enabled+checked.
- Clicked dialog Import (04-import-result.png): "Import complete INSERTED 2 UPDATED 0 EXEMPTED 0 ERRORS 0". Batch POST 200 (import-batch-network.json).
- Provider readback rows-after-import.json: 3 rows; original 45334c2f unchanged; new 5462ac10 Baker/Required 2024-10-03/2025-10-03 note1502final; new 7469487c Able/Targeted 2025-10-18/2026-10-18 note1502final. PASS.

## 3. Reload facts
- Matrix after Done + navigation reload (05-matrix-after-reload.png): Able Required "09/2027 CURRENT"; Able Targeted "10/2026 15D LEFT" (aria "15d left", orange Expiring); Baker Required "EXPIRED 365D AGO"; Unassigned Required Not Done; Baker/Unassigned Targeted N/A; Optional N/A.
- Reports after full navigation reload (06-reports-after-reload.png): "50% across 3 personnel"; 1 Current / 1 Expired / 1 Expiring / 1 Not Done (4 applicable); Required card 33 "1 expired 1 not done"; Targeted card 100 "1 expiring"; compliance Required 33% "1 exp", Targeted 100%; Group Alpha 100% / Bravo 0% / Unassigned 0%; detail 3 of 3: Able 09/2027 CURRENT + 10/2026 15D LEFT; Baker EXPIRED 365D AGO; Unassigned NOT DONE. PASS.

## 4. Export (actual button "Export"; prompt's "Export Excel" label does not exist on this page)
- Hooks armed; clicked visible Export; request 200, Content-Disposition training-report-2026-10-03.xlsx; Blob captured via download anchor filename training-report-2026-10-03.xlsx, 6999 bytes, sha256 a897a3fe…3024 (export-network.json, training-report.xlsx). Hooks restored.
- ExcelJS (training-report-cells.json): single sheet "Training Report" 4 rows x 8 cols. Headers Name,Rank,MOS,Duty Role,Group,Verification Required/Targeted/Optional Training.
  - Able, SPC, 68W, Medic, Alpha | "Current (2027-09-26)" | "15d left (2026-10-18)" | "N/A"
  - Baker, SPC, 11B, NCO, Bravo | "Expired 365d ago (2025-10-03)" | "N/A" | "N/A"
  - Unassigned, SPC, 68W, NCO, (null) | "Not Done" | "N/A" | "N/A"
  - No Foreign row/type, no B facts. Distinct Current / Expiring("15d left") / Expired / Not Done / N/A cells.
  - Limit: workbook carries saved EXPIRATION dates only; completion dates (2026-09-26, 2025-10-18, 2024-10-03) are not workbook columns (matches recipe: "uses saved expiration dates"). Completion dates proven by provider readback and API response instead.

## 5. Alpha filter
- Clicked "Filter by group" → option "Alpha" (07-reports-alpha-filter.png): "100% across 1 personnel"; 1 Current / 0 Expired / 1 Expiring / 0 Not Done; Required 100 (1 personnel), Targeted 100 "1 expiring"; Personnel Detail "1 of 3 personnel" with only Able (09/2027 CURRENT, 10/2026 15D LEFT). PASS.
- Observation (pre-existing UI, not 1502 scope): after Alpha selection the "Report filters" group a11y name became "Report filters, 1 active" though Status/Training type were unchanged; Group Readiness card hidden when a group filter is active.

## 6. Restore through visible record editor
- Matrix cell "Baker Verification Required Training: Expired 365d ago" → Edit Training Record (Completion Oct 3, 2024; EXPIRATION 2025-10-03; STATUS Expired; notes note1502final) (08-editor-baker-before-delete.png) → Delete → alertdialog "Delete Training Record / Are you sure…" → Delete. Cell became Not Done, dialogs closed.
- Matrix cell "Able Verification Targeted Training: 15d left" → editor (Completion Oct 18, 2025; EXPIRATION 2026-10-18; STATUS Expiring; note1502final) → Delete → confirm Delete.
- Provider rows-after-restore.json: count 1, exactly 45334c2f… Able/Required 2026-09-26/2027-09-26 notes null cert null; JSON rows IDENTICAL to rows-before.json.
- Reload matrix (09-matrix-final.png): Able Required Current, Able Targeted Not Done, Baker/Unassigned Required Not Done, others N/A. Reload Reports (10-reports-final.png): 25% across 3 personnel, 1 Current / 0 / 0 / 3 Not Done, Required 33, Targeted 0, Alpha 50%.
- Hooks: __mapExport and __mapNetwork absent after reload; all installed hooks were explicitly restored before navigation. Browser left signed in as trainingConfigure in T3 preview tab_3 on Reports (parent owns lifecycle).

## Source/template/trail review (read-only)
- trainingBriefing.ts/types matched the chosen interpretations: exact integer thresholds (bandFor, dropAlert lost*100>=10*n, cliff best>=5 && best*10>=lapsing*4, "More than half" via 2x>lapsing); null/none for empty denominator; lapseOffset=daysUntilExpiration+1 with end-inclusive horizon; overlap measured against the union of selected entries; standing gap triggers at notReady*5>=applicable and its sentence uses distinct not-ready Soldiers/population; wave biggest-hit uses the lapse rate across the whole horizon for the dominant types; wave month uses the earliest of tied most-common months; model returns band keys only, with no colors.
- Templates match issue 1502 literally, including plural "soldiers" for 1 and the em-dash titles.
- Paper S8-1 copy is an illustrative mock that differs from the approved templates (it uses "SHARP or EO", "expire together", "already expired", "3–23 Nov" compressed ranges, "(20)" row counts and an extra "worst lines" clause). The code follows the issue, not Paper. This is a 1503 note, not a defect in 1502.
- 1502-decisions.tsv: the cited evidence exists (1502-baseline/*, 1502-validation gate/build/benchmark logs). "1502-model-grounding-v1" and "review_1502" are named only in observations.md/review-source.md, so they are task names rather than standalone artifacts. The benchmark ms figures are the writer's offline numbers; they were not re-run or promoted here.
