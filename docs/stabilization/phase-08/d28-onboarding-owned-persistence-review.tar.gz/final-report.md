# D28/#1376 Onboarding independent source and expanded-artifact acceptance

Standards **GO**. Spec **GO**. Comment Sicko **GO**. No consequential finding or required correction. These verdicts cover this complete ordinary Onboarding deliverable and its recorded evidence, not publication, exact-head CI or merge acceptance.

This was one fresh, sequential generic-agent artifact/source review. I independently read the changes and adjudicated existing observations; I did not execute the application, browser, tests, build or database, use a connector/network, read private credential originals, or obtain model diversity. Poteto, project t2t-engineer and the complete portable Comment Sicko instructions governed the review. Shared files were read-only; outputs are confined to this ignored directory.

## Exact scope and input binding

Base is `f064ae099ab4354cca9c87792f5167a9b3c54230`, branch `stabilization/1376-onboarding-owned-persistence`. The complete actual no-rename path set is 68: 66 text/deleted paths and two archives. Every entry and exit hash/size/deletion matches the parent's frozen inventory; actual tracked-diff plus untracked path sets also match exactly. `entry-scope.json` and `exit-scope.json` give all 68 bindings. Nine deleted paths remain absent. The complete tracked patch, all new source/test files, relevant full functions, deleted contents, recipe/governance/doc hunks and the local prepared PR body were reviewed. The remaining unchanged bodies retain preparation applicability; this is not a new review of all old Training artifacts or the entire repository.

All 61 implementation-scope paths match the final native source inventory, including deletions. The seven later materials are only four existing status records, the new Onboarding record and two evidence archives. Source/recipe/governance inputs are not rebound to later prose. The worker and parent initial/midrun/final receipts retain 5,358 input hashes, nine deletions and the five original controls plus two destination controls. Those captured full-input checks are distinct from my independently recomputed 68-path scope check.

## Standards

The 16 Catalog and ten Workflow methods are fixed owner operations, captured from the admitted ordinary request client and canonical Organization. Contracts expose domain facts and narrow Picks; callers cannot choose tables, columns, filters, arbitrary result types, caller Organization or an administrative provider. Request contexts bind the two providers after admission. The existing five purpose ports, Calendar markers, raw archive and retention paths remain separate.

I traced Catalog CRUD/reorder/duplicate, Workflow query/policy/progress/lifecycle/resync prerequisites, Dashboard, Getting Started, Starter configuration and request/test factory consumers. Removed exports, three Entities and copied generic store interfaces have no remaining source/script consumers. The shared Entity helper/test/guide removal is justified by the same zero-consumer result, not a new framework replacement. Governance removes only deleted scan targets and registers the exact request test and three test-support files; no permission allowance, cycle waiver or blanket exclusion was added. The actual governance receipt retains 155 findings without regression and the rule selection passes 72 tests.

Performance remains bounded: workspace/reference branches begin concurrently; nested progress stays one packet query; paged SDK and raw reads append a unique ID order before ranges; existing primary name/sort ordering is retained. Saved nested progress still uses its existing sort-order semantics. Serial reorder, duplicate parent-before-steps, deletion audit-before-dependent cleanup and batches of 25 keep their existing partial effects. No new RPC, administrative bypass, per-row reference waterfall, transactional claim or extra ordinary port appears.

## Spec and meaningful lower proof

Template/Step responses preserve five/ten saved fields, including nullable Template `createdAt` and Step `organization_id`/`created_at` spellings. Packet/history responses preserve eight parent and twelve nested fields; saved progress acknowledgements preserve the actual six fields `id/onboardingId/stepName/stepType/completed/currentStage`. Missing nullable packet/progress values, nonarray notes, legacy authorless note items and default active behavior match the retained contract. Supplied-field patches distinguish omission from explicit null; type normalization and immutable IDs/Organization/timestamps are retained.

I read the installed-SDK tests and controlled provider, request-boundary test, changed lower/route/reverse tests and actual failed/passing logs. Seven SDK tests cover literal 1,001-row identities, page-order drift, metadata/null shapes, first/late errors, ordinary binding and saved mutation results. The four raw archive failures are genuine unstable paging failures; all ten reader tests then pass, preserving unknown raw fields and late-error rejection. Fifteen existing delivery checks cover the independent export consumers. The two relocated request tests exercise admitted request construction and the real error wrapper, concealing a provider's status-shaped error as generic 500 while stored rows/audit remain unchanged.

The partial-effects selection proves saved parent retention when duplicate steps fail, saved deletion/audit before dependent failure, and serial reorder behavior. Its two earlier fixture-construction failures remain separate from the corrected three-test green receipt. Lifecycle, progress/routes, query/raw and reverse selections preserve their distinct scopes. I do not add overlapping selections into a single green total. Transform, fixture, stale assertion, governance, boundary-layer and types failures remain recorded; final types are 0 errors/0 warnings and touched lint/format/diff pass. These are worker-run receipts, not reviewer-run tests.

## Fresh archive and actual observation acceptance

Both archives were freshly extracted here with guarded regular, unique, normalized relative entries. Exact member sets, inventory path sets, sizes and SHA-256 match every one of the 1,104 payloads; each archive has one additional root inventory member.

| Archive | Bytes | Payloads | SHA-256 |
| --- | ---: | ---: | --- |
| baseline-f064 | 1,456,863 | 704, including 689 raw files | `a4df1d1fb5641714b7278824949ed7c0b63cd8e62f3318a963a9ab7cdfda480b` |
| final-f24f55f8 | 2,368,233 | 400, including 347 raw files | `229c16b92c255b015ae83d7595ea505d3b06174a81e9ebee48fc9d07c9a1019e` |

`archive-integrity.json` and the two independent payload inventories contain exact filenames/hashes/sizes. Archive integrity alone was not treated as behavioral proof.

Baseline candidate `f7e62e0530b33b4d51413b7c85a64ecbd6bbb01e86fe7c458a885326e54b13d0` retains its five selected batches and session `06f5d37a-b3c2-49f2-b124-da85e36822a4`. Final candidate `f24f55f867d58bbd8327bdfceb5ca68d7bec393ec3aff29005e88920be94cf48` retains four focused groups and session `84cdad0c-ec29-4b87-afed-97116d855a29`, origin 34989, Node 24.21.0/Chromium 152.0.7977.82, literal 2026-10-07.

I inspected actual action/snapshot/request bodies and full SQL, not just PASS summaries. Independently decoded the actual sanitized streamed History expressions in isolated bounded data readers. Baseline's three Templates/eight definitions/five parents/21 nested rows and final's three/nine/five/21 match every literal projected SQL value and key. Final Document 271 is the captured original 48,912-byte response, not a resend; sanitized HTML is 48,082 bytes. Matching those feature values does not certify unrelated SSR-auth content.

Final saved clear/Training-restoration and checkbox/paperwork acknowledgements match SQL at the correct time. Start retains packet/three progress identities and current Training completion; the same Person's older History snapshot retains its false Training state. Cancel/reopen/complete keep all progress and note fields; the one authenticated API note is separately identified. Dashboard's visible bracket is zero → one at 33% → zero. Catalog deletion preserves packet/progress content with only the four expected definition-reference nulls. All five denial comparisons preserve every field in 26 business rowsets, with audit effects separate; scoped false/true readbacks correct the earlier intermediate observation gap. Starter is authenticated API proof: two Types, one Template, four definitions, seven corresponding audits; reapply preserves all 28 rowsets exactly. It earns no Starter UI credit.

All 15 PNGs (four baseline, eleven final) were viewed at original detail: initial Catalog, two baseline failure drafts, both History notes, created/final Catalog, Start inputs, packet progress, four Dashboard states, scoped active and empty active. Exact image filenames/dimensions/hashes are in `source-binding-visual-sanitation.json`. This verifies those visible states, not every interaction, layout variant or pixel. No new PDF scope exists.

## Restoration, closure and limits

I independently recomputed all 118 original rows across 28 A/B table sets in both runs: complete field/key/timestamp equality. Observed generated/helper IDs are absent (57 baseline, 41 final). Seven Starter business rows plus 49 baseline/35 final audits remain truthfully separate until whole provider disposal; this is not all-table-count equality.

Final exact doctor/container/network/mount identifiers match the resource ledger. Archived physical closure and the read parent comparator establish 24 physical process identities, nine ports, five containers, one full network ID, two mounted volumes and worker-directory absence. Baseline binds 22 process numbers/nine ports/five containers and network name/label/mount absence, retaining its unavailable historical full network ID. Supported cleanup, final doctor and source/control freeze receipts remain distinct from these actual physical checks. Parent comparisons retain all 41 preexisting complete Config/HostConfig/destination-sorted Mounts/PID/start/Networks, and original seven network/17 volume records. I read the comparator and sanitized outcomes, not forbidden private Docker Env originals; I did not perform a new live closure query. Whole-machine network/volume/TCP equality FAILs and unrelated additions remain historical observations without causal attribution or an unowned-lifetime claim.

My independent JWT-pattern scan finds zero hits in all 704/400 public payloads (700/389 UTF-8 payloads respectively). Exact-known-value scans are the separately bound worker/parent receipts; I did not read private values. Credential-bearing originals are excluded. This is no exhaustive credential, OCR, tool-transcript or SSR-safety certification. The disposable synthetic token exposure in a failed parser/tool transcript remains explicit. Native nullable Template date remains UNRUN; lower SDK null and the source Unknown branch do not earn native-null rendering credit. Other preserved help/capture/aria-date/wrong-start/wrong-note/Reopen/output-path/parser failures remain failed attempts, not product successes or silently deleted history.

Reviewer-only inventory/path/partition/reader mistakes and truncations are retained in `reviewer-read-limitations.json`; corrected readers operate on unchanged payloads. They include wrong temporal SQL snapshots, wrong assumed progress keys, omission of Starter audit effects and local reader variable/path mistakes. None changed source or evidence.

## Comment Sicko, grouping and handoff

Required comment deletions: **0**. MUST KILL flags: **0**. Restorations/encodings: **0**. New comments or suppressions: **0**. Two scan candidates are URL literals in `test-support/onboardingProvider.server.ts`, not comments. Unchanged comments retain their prior scope and are not individually relitigated; retired comments leave with deleted unused modules. No application code was touched by this pass.

The whole ordinary owner/caller/removal wave and related raw paging repair belong together. Recipes and records correctly distinguish public DTOs from full raw schemas, native from authenticated API/readback, old and current candidates, and pending release gates. The prepared PR body clearly shows 16/10 ports and uses `Refs #1376`, with no issue-closing claim. The Training integration prose matches the separately accepted head c001/merge f064/tree 993 binding without reopening Training verification.

The selected baseline and four current groups are sufficient for this seam. Matching earlier failure/draft/retry/lifetime, purpose RPC/concurrency/retention/export and Training/Personnel/Calendar proof retains its original binding; lower SDK/partial/error/paging checks complement representative current integration. No consequential uncovered behavior warrants another manual matrix, export campaign, PDF replay or source test execution here.

Independent source/expanded acceptance is complete. Full intended CLI review, mandatory current-head CI/build and completed clean hosted review remain parent release gates. No migration is introduced. #1376 remains open for residual settings, generic Personnel rank/callers and final shared facade removal; D29/D30 are excluded.

**Sole reviewer ownership RELEASED.**
