# D28/#1376 main integration and focused review repair

The bounded source/lower stage is complete. Ownership is released to root. Exact accepted main is locally merged, all ten ordinary paging reads have stable unique order, both hosted findings are adjudicated, and focused current checks pass. No app, native browser, production build or provider was launched. No push, PR/thread write, archive, remote database, existing-local reset or private worktree action occurred.

## Exact source and merge

Branch `stabilization/1376-training-owned-persistence`. Previous clean local head `1c9d1e0760b73f1c8f70b88ac4c18c81667ba1df` retained root's stale Entity documentation repair. Merged exact actual main `837a43508d31ab4f82da8e3235382d708f065ead`, tree `ec2486ac2d700d92a0b341882e30c74556768e85`, in authorized local merge commit `74c351ab391c8e3d955984653306bd1e270bab74`. Its two parents are the previous local head and exact main above. No force-push, rebase or publication occurred.

Three conflicts were real (`merge-initial.log`). ApprovedTrainingDeletion retains owned direct deletes and pending-review admission, imports shared `fail`, and does not resurrect two Entities. CompletionOperations retains narrow domain ports/contexts and validation/current malformed-known patch semantics, removes the local duck-typed fail, and imports shared `fail`. Raw Training export retains its separate fixed-table complete select* purpose and imports shared `RequestFailure`; no copied catalog store returns. CompletionBatch, global inMemory and rank route auto-merged cleanly; their diffs were inspected. Batch uses shared `fail`, inMemory preserves Training's narrow fixtures and all accepted main recognized errors, rank actions import shared `toActionFailure`.

Six source overlaps were reconciled. The other 52 changed main paths are byte-exact accepted main, including deleted settingsActionFailure. `merge-census-corrected.json` proves this. The first comparator incorrectly used git show on a deleted path, which yielded default HEAD commit output. `merge-census.json` preserves that observation; only the comparator changed to git cat-file blob.

Four repair/test paths remain intentionally uncommitted for root to inspect and commit after acceptance:

- `src/features/training/server/trainingCatalogPersistence.server.ts` adds six ID tie orders.
- `src/features/training/server/trainingCompletionPersistence.server.ts` adds four ID orders.
- `src/features/training/server/trainingPersistence.server.test.ts` upgrades the existing ten page/late-error cases to exact independently numbered identities under tied sorts and provider page-order drift; existing label expectation now uses stable ID order.
- `src/lib/server/adapters/trainingRequestContext.server.test.ts` adds two operation-to-delivery failure checks through public Training exports and the existing narrow fixture.

Stage diff against prior local head has 62 paths, comprising 58 accepted main changes and these four repairs. Complete PR diff against actual main has 77 paths and zero nonignored untracked files. No unrelated main path, ledger, archive or maintained recipe was edited by the worker. `source-caller-census.json` records all paths/statuses. `final-source-freeze.json` binds 5357 tracked paths, merge head and uncommitted binary patch SHA256 `e9587faf8d98144e1a46b16cfba61ac94402bdffeb268511e949a8997f945a84`. This is a source/lower binding, not a newly launched verify:app candidate. The old native candidate4e84 is explicitly reused only for matching behavior.

## Paging finding PRRT_kwDORLALT86p_vye

Actionable and repaired. Postgres may use different physical row orders for separate page queries when no unique ordering is given. Reversing page2 provider order exposed the specific failure through installed Supabase SDK2.106.1. Each read returned duplicate row0000 and omitted row1000. This is controlled SDK/provider-boundary proof, not an assertion that the prior live database happened to reorder rows.

All six Catalog contracts are covered: listTypes, listViews, listTypeLabels, listRankApplicabilityReferences, listExistingTypeNames, listTypeImportReferences. All four Completion contracts are covered: listCompletions, listPairReferences, listPersonReadinessFacts, listPersonExportFacts. Production adds `order('id', { ascending: true })` immediately before range. listTypes retains sort_order first; listViews retains name first. No select projection, filter, count, write payload or domain signature changes. No new query framework, port, page loop, N+1 or fake provider abstraction.

Existing ten parameterized behavioral cases now use 1001 literal numbered facts. Tied Type sort_order and tied View names expose missing tie order. Every projection carries an independently expected identity, including rank arrays, names and readiness/export Type IDs. The existing provider's page-order drift control is reused. Each case also proves later-page errors reject instead of returning partial success. Existing metadata, ordinary credentials, primary sorting, counts, single-row semantics and CRUD tests remain.

Original regression and current repair receipts are preserved:

```text
paging-before-fix.log
Test Files  1 failed (1)
Tests       10 failed | 3 skipped (13)

focused-first.log
Test Files  9 passed (9)
Tests       127 passed (127)
```

`paging-before-source-hashes.json` preserves pre-repair adapters/test binding. `paging-after-first.log` preserves the remaining stale insertion-order label expectation FAIL, while all ten newly strengthened paging cases passed. The label assertion was corrected to the explicit new stable ID order, not removed or weakened.

## Certificate finding PRRT_kwDORLALT86p_vyp

Disproved for the actual installed SDK and completed-import path. No upsert or provider-fixture repair was made. The claim confuses missing values within selected input columns with a whole column absent from the completed batch payload.

Installed PostgrestQueryBuilder2.106.1 sets the upsert URL's columns to the union of array payload keys. `trainingCompletedRow` uniformly supplies organization_id, personnel_id, training_type_id, completion_date, expiration_date, notes and updated_at. It supplies neither certificate_url, id nor created_at. `certificate-sdk-probe.mjs` executes the actual mapper plus installed SDK without network/provider creation and records this exact wire contract in `certificate-sdk-wire.json`. The probe is wire observation, not stored-state proof. The primary [PostgREST14.3 conflict-update implementation](https://github.com/PostgREST/postgrest/blob/v14.3/src/PostgREST/Query/QueryBuilder.hs#L112-L128) constructs conflict assignments from insert columns only. This source supports the mechanism; no claim is made that14.3 was the earlier runtime provider version.

Actual stored proof is stronger. Re-read native repeated and mixed CSV imports at candidate `4e84bbe9bbf70f956c4ca4df1cf50ae3c3c617c3ada4bb6ad29e80dc210d0307`, closed session `095a61ab-0d40-49dc-81f6-33ea2b12dd25`. Both native request bodies omit certificateUrl; both acknowledge200. Returned full10 fields equal SQL. Saved record `7519577b-6647-4218-836f-c7c37284203b`, created_at `2026-10-07T15:07:49.355756+00:00` and certificate `https://example.test/d28-ordinary` remain unchanged in both. The repeat updates date/notes and the mixed import completes one row plus a separate exemption. The original evidence was not overwritten.

Exact raw binding `.verification/evidence/verify-trooptotask/d28-training-twoport-final-native-20261007/` contains `dated-created-sql.json`, `repeat-batch-wire.json`, `repeat-annual-record-sql.json`, `mixed-batch-wire.json`, `mixed-annual-record-sql.json`, `batch-comparison.json`. Their hashes, exact bodies/rows and current SDK source/version are in new `certificate-disposition.json`. Root's existing closed archive `docs/stabilization/phase-08/d28-training-owned-persistence-final-4e84bbe9.tar.gz` preserves that run. No new archive was produced.

The current test fixture's Object.assign gives the correct effect for these uniform seven-column completed rows. It is not claimed to simulate arbitrary heterogeneous upserts. Changing this working path to separate updates/RPC/N+1 would contradict observed retained certificate and existing identity behavior without a demonstrated need. Generic missing/default documentation alone does not overturn actual wire/SQL facts.

The optional inconclusive80% docstring metric is not a project requirement. No narrative comments/docstrings were added to chase it.

## Shared error trust and focused checks

Shared RequestFailure is intended app authority. Provider Error status/name fields are not. Completion/Batch fail imports preserve deliberate400/404 messages through the actual delivery boundary. Catalog validation still throws Svelte HttpError and policy admission still uses the shared accepted policy failure path. Raw unsupported-table400 now uses shared class identity. Type/View/Completion mappings, public saved20/7/10 keys, omission/NULL, dates/certificate and audit/policy timing remain unchanged.

Two new composition tests verify real Completion missing-id400, absent-resource404 and Batch empty-records400 through `rethrowOrWrap`, plus a provider Error shaped like404 becoming generic500 while full saved record and audit remain unchanged. They belong in existing delivery-owned trainingRequestContext test and call public Training exports. Initial placement in a Training test violated the module boundary. `governance-final.log` preserves two159-finding private/undeclared failures. The test was moved to its actual owner, without a manifest change or broad waiver. `governance-relocated.log` passes with the original157 retained findings. The temporary Training test edit was removed exactly; application source was not changed to accommodate the test.

Validation ran on Node24.21.0, with no app/build:

| Check | Result and receipt |
|---|---|
| Focused adapters/request, CompletionOperations/Batch, approved deletion, raw archive, shared handle/load and rank action suites | 9 suites/127 tests PASS, `focused-first.log` |
| Initial added boundary placement | 3 suites/22 selected tests PASS,43 skipped by explicit filter, `error-boundary-focused.log`; invalid ownership was subsequently repaired |
| Current relocated Training authority/error composition | 1 suite/3 tests PASS, `error-boundary-relocated.log`, including the two new boundary cases |
| Current types | 0 errors/0 warnings, `types-relocated-final.log` |
| Current governance | Regression PASS,157 retained findings, `governance-relocated.log` |
| Merge overlap lint/format and current four-file lint/format | PASS, `lint-first.log`, `format-first.log`, `lint-relocated-final.log`, `format-relocated-final.log` |
| Working diff and complete PR diff whitespace | PASS, `diff-check-final.log` |
| SDK completed upsert wire and prior native/SQL reinspection | PASS, `certificate-sdk-wire.json`, `certificate-disposition.json` |

The checks overlap and are not summed into one misleading total. Current composition combines the unchanged passing focused suites with the two now correctly owned tests. Governance first failed solely because merge was staged but HEAD still behind origin/main; `governance-first.log` remains. After authorized local merge, `governance-second.log` passed. Intermediate type/lint/format/test failures and the corrected census comparator remain intact. No source/check allowance or assertion was relaxed to hide unexpected behavior. Required full current-head CI is still root's later gate.

## Caller census and separate-purpose limit

`actual-caller-census.txt` and `source-caller-census.json` record actual production/direct/reverse use. Exactly17 Catalog and10 Completion methods remain, capturing admitted request Supabase client plus canonical Org once. No Training Entity symbol, copied generic Catalog/Completion store or obsolete TrainingCompletionWriteContext remains in src. All three Entity modules and old catalog reader are absent. The other retired Training seams and exports remain deleted from the published cohesive cutover; no merge resurrected them.

Training routes/queries/operations/batch/workspace/reports, Dashboard, Personnel readiness/four-column export, GettingStarted, Starter, rank applicability, Onboarding references and purpose consumers retain their migrated ownership. Generic shared facade stays only for later owners. Narrow request contexts, seven parallel report/workspace source branches, separately admitted/lazy Onboarding references, policy before reads/writes, configure hard-delete versus202 approval, countnull→0 and saved name-race/single semantics remain unchanged. No D29/D30, later Onboarding/settings ownership or redesign was introduced.

One concrete preexisting limit remains for independent grouping adjudication. `createSupabaseTrainingExportReader(...).listRows(table)` still pages its select* archive without explicit unique order. It is a separate Organization export purpose, not an eleventh ordinary port method. Its captured client/Org and fixed three-table authority remain intact. Actual consumer `createRequestOrganizationExportContext` constructs archiveReaders.training. `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.ts` uses it for trainingTypes, personnelTrainings and trainingViews; the data-export manifest declares those sections. `trainingArchiveExportRead.server.test.ts` currently proves full saved metadata/foreign exclusion across fixed pages, first/late errors, null response and unsupported-table rejection. These passing proofs do not establish stability under changing physical order. This limit is not normalized as stable or silently repaired.

If the independent reviewer judges the same mechanism consequential and closely related under the grouping rule, the minimal adjacent fix is one `order('id', { ascending: true })` on that existing raw builder, plus upgrading its existing three table cases to use provider page-order drift and assert all1001 exact saved rows, followed by those archive tests and the existing delivery archive boundary test if needed. Keep complete select* metadata/authority and later-error proof. No broad native export matrix, provider/RPC framework, table expansion or new ordinary port is needed. Root explicitly owns that scope choice after this handoff.

## Proposed native and reuse

`proposed-final-native-selection.md` proposes only one Dense native report plus whole workbook. Actual provider completeness/order now merits a focused adjacent live check because query ordering changed. At matching112 People/24 Type/PFC/MOS68V/90 inputs, independently verify1902 saved Completions and1990 workbook rows, exact IDs/order/dates and2632/1272/642/730/630/630 facts. Fresh literal IDs/day/roles and real requests must be recorded. No app is launched until root accepts the proposal.

Native error replay is not automatically needed. The earlier native Catalog duplicate rejection was an untrusted Error without status, generic500 under both boundaries. Catalog route/mapping/UI is unchanged, so the prior genuine provider error/draft/correction/retry remains matching. Recognized deliberate Completion400/404 and Batch400 now have current composition proof; recognized403 policy and foreign404 native bodies retain prior matching proof. Main's tightened trust is covered by current shared tests and provider-spoof composition, not a new rare native matrix.

`protected-native-source-reuse.json` proves all59 protected UI/store/utility files byte-exact against4e84. Retain prior native CRUD, metadata, record/batch/certificate, scope/None/foreign, normal26 paging/filter/whole workbook, empty distinctions, reverse consumers and exact print artifact/layout bindings. Retain root93ab Person editor47 tests/native503 retry/reload/Cancel and#1562 lifetime proof. Original baseline36PASS/1 productFAIL/3 controlFAIL/24UNRUN and supplement4f9ff79a/73 tests remain original observations. No fresh PDF, paper/theme sweep,64-case or six-part repeat. Historical Offline/lazy emulation FAIL/UNRUN, absent native Starter Apply and deferred rank edges remain explicit.

Matching earlier250/21/45/30/authority/type/governance/current native/workbook/print/restoration receipts retain their original bindings; no wholesale rerun or independent acceptance is claimed. Current focused checks cover the main overlap and affected paging/error seams. Root reviews the actual source diff and evidence, decides the raw archive adjacency, then owns final proposed native stage, packaging, independent reviews, exact-head CI and publication. PR1565 and issue#1376 are not declared merged or complete.

## Decisions, limits and release

`selection.md` and append-only `decisions.tsv` preserve the how/model/throughput choices. Boundary Discipline keeps class-based intended failure trust and puts delivery tests with their owner. Test Behavior checks exact numbered projection facts and stored effects. Laziness retains the settled ports, primary sorts and ten simple ID additions, rejecting unsupported upsert rework. Prove It Works binds certificate disposition to actual wire/full saved SQL and failure-to-pass paging evidence. Sequence Verifiable Units separates merge, reproduction, fix and affected checks. No model diversity, nested delegation or independent self-review is claimed; sequential parent bounds override default fanout. No new comments were introduced; precommit direct diff/lint/format cleanup substitutes for unavailable deslop, and root owns independent CommentSicko/review.

No owned app/native/build/session/resources were created in this stage. All lower commands terminated. Existing closed worker1 directory is absent, and the prior real native closure receipt remains bound to4e84. No controls, grants, UI fields, synthetic provider rows or preexisting resources were changed here. No packaging occurred. Ownership is now released to root with the four dirty repairs preserved.
