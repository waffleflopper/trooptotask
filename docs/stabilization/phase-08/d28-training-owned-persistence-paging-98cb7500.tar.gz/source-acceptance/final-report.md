# D28/#1376 PR #1565 main integration and grouped repair acceptance

Current source, accepted-main integration, grouped paging repairs and the amended native proposal are acceptable. I found no consequential source or coverage defect requiring another repair or an expanded native selection. This is independent read-only source/evidence review, not independent live execution, multiple-model review, current native PASS, exact-head CI acceptance or complete PR acceptance.

| Axis | Verdict | Required next work |
| --- | --- | --- |
| Standards | GO at current source/lower-evidence scope | No source repair or additional lower check requested. |
| Spec | GO at current source and proposal scope | Run the proposed single Dense native report/full workbook after the accepted candidate is frozen. |
| Comment Sicko | GO | No new scoped comments, suppression or MUST KILL finding. |

I retain the original full portable Poteto, project contracts, Principles, review roles and NoComments readings. Standards and Spec were assessed separately by the same sole sequential reviewer. I wrote only this new ignored scratch directory. I did not spawn delegates, edit shared files, launch app/browser/build/tests/native, query databases/resources, use GitHub/network/connectors, or touch private worktrees. The earlier full source, 2,271 baseline payloads, 811 final payloads and two-document correction acceptance are reused at their original exact bindings.

## Exact current scope and integration

Authoritative accepted main is `837a43508d31ab4f82da8e3235382d708f065ead`. Local merge `74c351ab391c8e3d955984653306bd1e270bab74` has exactly parents `1c9d1e0760b73f1c8f70b88ac4c18c81667ba1df` and that main. I verified both parents from local Git objects. This is not a new review of all of #1564.

The complete current diff against that main contains **79 no-rename paths: 68 existing text files, seven deleted text paths and four unchanged accepted archives**. Thus the complete text/deleted scope is 75. Git's inferred CatalogRead-test-to-CatalogMemory-test rename presents 78 entries; both removal and addition are included in this review inventory. Worker reports' 77/78 counts are historical presentation counts, superseded by the actual no-rename census and root's explicit correction. No path is dropped to reconcile them.

Exactly nine paths are dirty above the merge: six source/test repairs and three root records. The six-source binary patch exactly matches worker SHA-256 `cbcc28127d927f424439ce954ee7c20cd845016824d8b21dd2fe5c8e1a046a9f`. All 5,354 other tracked hashes match the worker's 5,357-path final freeze; only the three declared root records differ. All 52 nonoverlapping changed-main paths, including deleted markers, independently match accepted main. The six overlap resolutions retain Training's owned seam and shared failure trust. No unresolved merge path remains.

I read both full worker reports, both native proposals, complete current scope and caller censuses, merge resolutions, six repair diffs/current functions/tests, three record deltas, focused failure/correction evidence and six actual original certificate artifacts. Fresh substantive source review covers eleven unique source/test paths: the six merge overlaps plus six dirty repairs, with the raw reader common to both. Contextual reading includes the accepted shared error boundary/class, retained provider/pagination and request wiring, relevant Organization JSON/workbook delivery tests and installed SDK upsert implementation. Unchanged material is hash-reused rather than mechanically reread.

Entry and exit inventories retain every one of the 79 scoped paths exactly. Inventory SHA-256 is `8183c59f817c24ed21ac0182a31c59bada61b32f05793aace518c4a9826c4f34`. `entry-inventory.json`, `exit-inventory.json`, `snapshot-stability.json`, `current-scope.json`, `dirty.diff`, `merge-overlaps.diff` and `independent-merge-reuse-verification.json` give exact paths, sizes, hashes, parents and comparisons. All four accepted archive hashes and all 59 protected UI/store/utility hashes remain exact. No archive was newly expanded or PDF rerendered.

## Standards: retained whole Training seam

Current contracts still expose exactly 17 Catalog and ten Completion methods. I independently counted their actual declarations and confirmed all direct/reverse uses in the current caller search. The three Training Entities, old Catalog reader, copied Catalog/Completion store symbols and obsolete write context remain absent. The complete same-wave owner/caller/removal work survives the merge; later owners' generic facade is still an explicit remainder.

Both ordinary adapters capture the admitted request SDK client and canonical Organization once. Consumers retain narrow domain Picks. There is no caller Organization, generic ordinary table/filter/result API, privileged fallback or third ordinary port. The raw archive remains a separate fixed-three-table purpose reader, captured from the same admitted ordinary request client/Organization. Privileged pending-deletion and admitted/lazy Onboarding references retain separate authority. The merge preserves pending-review admission before privileged deletion and does not resurrect Entity deletion paths.

Contracts, mapper, seven parallel report/workspace source branches, Person-first readiness admission, four-fact Personnel export and separate Onboarding reference implementation are byte-exact to the prior acceptance inventory. Complete saved 20/7/10 field sets and metadata spelling, present NULL/missing-property distinctions, absence of Type `updated_at`, dates, identity and certificate omission remain unchanged. Batch policy checks precede reads/writes; completed upsert precedes serial exemption rechecks/patches and final audit. Late nontransactional partial effects retain their original contract and accepted tests. Direct patches retain their existing malformed-known-field semantics. No migration or transactional redesign was added.

Shared accepted-main `fail`/`RequestFailure` replaces local duck-typed intended errors in Completion operations/Batch and approved deletion. Raw unsupported-table errors use the shared class. Current delivery trusts actual app-created failures and Svelte HttpErrors/redirects, while provider status/name decorations supply no authority. Rank actions use shared `toActionFailure`; global inMemory preserves the Training fixtures and accepted main failure identities. Full overlap diffs and affected functions demonstrate these are reconciliations of the existing contracts, not an ordinary authority bypass or a later owner cutover.

No new request waterfall, N+1, provider/RPC framework, projection expansion, admin acquisition or governance allowance appears. Sorting by the indexed unique ID adds a stable secondary/primary order to existing page requests; the number of queries and parallel assembly are unchanged. No measured performance improvement is claimed.

## Paging finding and cohesive raw adjacency

Hosted thread `PRRT_kwDORLALT86p_vye` is valid and repaired. All six Catalog page loops and four Completion loops now add ascending ID order immediately before range. Types keep `sort_order` first; Views keep `name` first. Estimated count and existence probes are not multi-page enumerations and need no extra order.

The existing installed-SDK fixture changes physical ordering between page queries before applying the requested sort. Ten current cases use 1,001 independently numbered identities; tied Type sort order and View names expose the missing tie-breaker. Every narrow projection carries an independently expected identity (names, rank-array values or Type IDs where row IDs are not projected). Exact expected sequences prove completeness and ordering, not merely length or an implementation call. Each case also rejects a later-page error rather than returning accumulated success. Existing saved metadata, scope, CRUD, count/null and single-row proofs remain.

The raw Training archive has the same demonstrated defect and belongs in this cohesive Training PR under the grouping rule. All three existing table cases originally duplicate `saved-0001` and omit `saved-1001`. Production adds exactly one ID order on its existing `select('*')`/Organization/range builder. The fixed `training_types`, `personnel_trainings`, `training_views` whitelist, ordinary credentials, rejection-before-access and complete saved rows remain intact. No DTO normalization is introduced: NULL values, malformed historical notes 17, retained identities/timestamps and unknown nested metadata survive.

The strengthened three cases assert all 1,001 full saved objects in exact independent ID order under page drift, foreign exclusion and empty Organization behavior. Existing first/late rejection, error-free NULL response and unsupported-table boundaries remain. This is a meaningful provider-boundary regression, not a new fake-provider abstraction or production-mapper oracle.

The actual Organization request context binds that reader; actual delivery calls the three declared Training sections. The two selected existing delivery tests construct the request readers through installed SDK and verify complete literal raw Training fields in both JSON and workbook output, with foreign exclusion under legacy/retired commercial schema fixtures. Their single-row projection purpose is distinct from the three 1,001-row archive paging tests. Together they cover query paging and downstream raw fidelity without redundant UI geometry or broad unrelated export testing.

## Certificate warning: actual bounded counterproof

Hosted thread `PRRT_kwDORLALT86p_vyp` is disproved for the actual completed-import path. I did not dismiss a data-loss claim from test-fixture behavior alone. I independently reread all six named original raw artifacts and compared their bytes/hashes to both worker disposition and my prior expanded acceptance. They remain exact.

Actual native repeat request 511 and mixed request 513 acknowledge 200 and omit certificate fields in every request record. I parsed their actual structured wire bodies and full SQL rows. All ten response fields map exactly to SQL. Both retain saved ID `7519577b-6647-4218-836f-c7c37284203b`, creation timestamp `2026-10-07T15:07:49.355756+00:00` and certificate `https://example.test/d28-ordinary` from the original saved row. Dates/notes update as intended; the mixed request's exemption remains separate. `independent-certificate-adjudication.json` records the actual comparisons and original six hashes.

Installed Supabase/PostgREST SDK versions are 2.106.1. The actual SDK source hash matches the disposition and its array-upsert builder sets `columns` to the union of payload keys. The unchanged completed mapper uniformly supplies seven keys: Organization, Person, Type, completion date, expiration date, notes and updated timestamp. Certificate, ID and creation timestamp are outside that selected column set. The wire-only SDK probe independently shows those exact columns, but is not stored-state proof. A value missing inside an included column is a different case from an entire omitted column. The actual stored native/SQL proof establishes preservation on this path.

PostgREST v14.3 primary-source discussion is supportive mechanism context; I did not fetch it anew or identify it as the earlier provider's runtime version. The current mapper/upsert logic is unchanged apart from page-read ordering elsewhere, and Batch's merge changes only intended error identity. No additional reads, per-row updates, RPC or fixture rewrite is justified. The Object.assign fixture models this uniform-column path, not arbitrary heterogeneous upserts. The optional inconclusive docstring percentage is not a project requirement.

## Actual lower evidence and preserved failures

I inspected the focused logs and result/failure details, not only report booleans. `focused-log-review.json` identifies 21 exact log files by byte count/hash and result lines. The selections overlap and are not summed:

| Evidence | Actual result |
| --- | --- |
| Ordinary paging regression before fix | Ten FAIL; duplicate `row-0000`, missing `row-1000`. |
| Intermediate label assertion | One FAIL/12 PASS; stale insertion-order expectation corrected to explicit stable ID order. |
| Focused affected integration/operations/shared-boundary/rank set | Nine suites/127 PASS. |
| Current relocated authority/error composition | One suite/three PASS, including the two new public-operation/delivery-boundary cases. |
| Raw archive regression before fix | Three FAIL/five filtered skips; duplicate first/missing last full saved row. |
| Current complete raw archive suite | Eight PASS. |
| Selected Organization raw JSON/workbook delivery | Two PASS/six unrelated filtered skips. |
| Types before raw adjacency | Zero errors/zero warnings. |
| Current governance after relocating delivery tests | 157 retained findings, no regression or manifest waiver. |
| Touched lint/format/diff | PASS. |
| Same documentation/incoming-link check | Six changed Markdown formatted, 244 documents link-checked. |

The new composition tests call public Training exports, forward deliberate Completion 400/404 and Batch 400 through the real boundary, and prove a provider Error shaped like 404 becomes generic 500 with the full saved record and audit unchanged. They sit in the existing delivery-owned test. The original misplaced private/undeclared import produced 159 governance findings; relocation returns to 157 without changing application source or waiving ownership.

Original premature merge-ancestor governance FAIL, deleted-path comparator FAIL/correction, stale count labels, failed paging expectations and test-placement errors remain preserved. The raw adjacency supersedes the original worker's declared unordered-reader limit; it does not rewrite the earlier report. Current count79 supersedes historical rename-presentation78. No assertion was relaxed to hide a missing saved row.

Reusing type/governance evidence across the raw adjacency is proportionate: one already-used typed SDK order call, an existing boolean drift control and literal expected rows add no signature, schema, import or owner dependency. Its executable SDK/delivery and touched lint/format proofs cover the demonstrated change. Required full current-head CI remains mandatory; reused local evidence is not represented as a new current-head type/build execution.

## Spec and amended native proposal

The **single Dense/PFC/MOS68V/90-day native report plus complete XLSX is sufficient and proportionate** after the accepted source/control/recipe freeze. Changed ordinary page ordering merits that real-provider adjacency. At fresh literal day/IDs/role inputs, it must independently verify 112 People, 24 Types, all 1,902 saved Completion pairs/dates and all 1,990 canonically ordered affected workbook pairs/dates. Expected facts are 2,632 applicable, 1,272 current ready, 642 horizon ready, 730 missing, 630 expired and 630 lapsing. Fresh date offsets must be derived from the recorded day rather than copied blindly. Same-request supported full-body capture must retain a truncated tool response without substituting another request. Restoration and actual owned closure remain part of that owned run.

Dense crosses the real Completion provider page boundary; current ten SDK cases separately prove all ordinary projections and tied Catalog sorts. A 1,001-Type native matrix or another normal detail/empty/CRUD/reverse sweep would add no distinct required behavior. The three raw SDK paging regressions plus the two actual request-context raw-delivery projections are sufficient for the raw-purpose ordering change. That builder adds the same known ID-order operation while preserving `select('*')`, filters, authority, errors and serializers. No specific uncovered live raw behavior justifies a native Organization archive sweep or an additional live check.

The accepted shared-main trust change has current composed lower proof. The prior real Catalog duplicate was already an untrusted Error without status and generic 500; current boundary keeps that result, while byte-exact route/UI behavior retains the original visible error/draft/correction/retry proof. Deliberate 400/404/Batch400 now have current composition evidence, and shared recognized policy 403/Svelte404 behavior remains the accepted public contract. Provider spoofing is covered at the cheapest actual boundary. No rare-status or controlled 503 replay is required.

All 59 protected UI/store/utility files match the original 4e84 candidate. Retain prior native CRUD/metadata/batch/certificate, ordinary scope/None/foreign, normal/empty/reverse, Person 503/lifetime/retry/Cancel and exact print/PDF proof at their original bindings. No six-part/64-case repeat, new PDF, theme/paper sweep or app writes are justified simply because main merged. If the selected Dense run fails, rerun its failure and only repair-justified adjacent checks.

## Records, remainder, comments and release

The three current record updates accurately distinguish the six-part `4e84` native PASS from later main integration/paging lower evidence and pending fresh Dense follow-up. Their merge/count/failure/certificate/proof-reuse statements match actual source and receipts. Historical CLI/source acceptance is not rebound to the newly merged/repaired candidate. Old 36 PASS/one product FAIL/three control FAIL/24 UNRUN, Offline/lazy and Starter-no-UI limits, cancelled packet/progress/audit history, whole-machine TCP equality FAIL and the bounded sanitation/17-of-30 PNG scope retain their original bindings. No fresh sanitation, pixels, restoration, resource or execution claim is made here.

The Training source/callers/removals and closely related ordinary/raw page-order repair form one cohesive owner wave. #1376 remains open for ordinary Onboarding persistence, residual settings and final shared generic-facade caller/removal acceptance. D29/D30, migration and remote operations remain excluded. No issue-closing or broad later-owner work is implied.

Comment Sicko found zero new scoped source comment lines or suppressions in the six overlap and six repair diffs. Additional deletion recommendations zero; MUST KILL targets zero; application files touched/deleted by reviewer zero. The prior accepted narrative deletion and 41 unchanged leading-comment skips remain historical; unchanged accepted-main comments are not relitigated. `comment-sicko-receipt.json` records the bounded scan, not an all-lexical-comment census.

There are **zero consequential findings** and no source fix or additional lower/native check requested beyond the approved Dense proposal. Fresh selected native execution, its artifact acceptance, full exact-head CI/build and clean completed CLI/hosted review remain separate release gates. No merge-readiness or current-native PASS is claimed.

This terminal report completes the authorized sole-worker review stage and explicitly releases shared-file/source ownership and the freeze to root for the separately owned Dense native and later release work.
