# Owned Storage listing contract inspection

Read-only catalog/image/SDK inspection of the original owned worker. This is not ordinary-user Storage API execution or native UI acceptance. No application requests, DB writes, role changes, service lifecycle calls, remote DB access or full environment exports were used.

Session 2a9948da-1a8b-431b-be75-ad90ce947aaa; project t2t-verify-d13d6e57af6d4c2b9a12fa19; Organization A 01884325-59fd-42b1-a630-434a375abfb2; candidate bd23f0162ba23bc9a17502662c790c3ed17467005683516d83263f1c66b0f1f3. SDK @supabase/storage-js 2.106.1. Storage configured image public.ecr.aws/supabase/storage-api:v1.54.1; actual image ID sha256:09c0f6f63ba79f1fea1917dfa2bc1ada8ef262f3f37a4d9f6c12add27707b0cd.

Guards: scripts/verification/environment.py private_session(session), owned(session), status(session), containers(state,directory,env), then exact repository/worker/session/project/Organization and original running service name/ID checks. Existing guards check private directory, hashed provider config, original local Docker endpoint, provider endpoint hash, labels and original recorded IDs. Private marker contents, credentials and full container environment are withheld.

Commands: guarded docker exec <original-owned-db-id> psql -U supabase_admin -d postgres -X -A -t -v ON_ERROR_STOP=1 -c <SELECT below>, with the existing helper's synthetic local password environment (value omitted). Guarded docker exec <original-owned-storage-id> node -e <fs.readFileSync of the three fixed source paths below, selected line slices>. Node only reads files; it does not import/execute Storage server modules or issue API requests. SDK excerpts are local filesystem reads. An initial psql invocation without the standard synthetic password failed before returning definitions; the corrected read-only invocation succeeded.

```sql
SELECT pg_get_functiondef(p.oid) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='storage' AND p.proname IN ('search','search_v2','list_objects_with_delimiter','get_common_prefix') ORDER BY p.proname,p.oid;
```

## Actual installed catalog definitions

```sql
CREATE OR REPLACE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
AS $function$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$function$

CREATE OR REPLACE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text)
 RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$function$

CREATE OR REPLACE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text)
 RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$function$

CREATE OR REPLACE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text)
 RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$function$


```

## Original Storage image source excerpts

```text

SOURCE /app/dist/http/routes/object/listObjectsV2.js lines 1-98
1: "use strict";
2: var __defProp = Object.defineProperty;
3: var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
4: var __getOwnPropNames = Object.getOwnPropertyNames;
5: var __hasOwnProp = Object.prototype.hasOwnProperty;
6: var __export = (target, all) => {
7:   for (var name in all)
8:     __defProp(target, name, { get: all[name], enumerable: true });
9: };
10: var __copyProps = (to, from, except, desc) => {
11:   if (from && typeof from === "object" || typeof from === "function") {
12:     for (let key of __getOwnPropNames(from))
13:       if (!__hasOwnProp.call(to, key) && key !== except)
14:         __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
15:   }
16:   return to;
17: };
18: var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
19: var listObjectsV2_exports = {};
20: __export(listObjectsV2_exports, {
21:   default: () => routes
22: });
23: module.exports = __toCommonJS(listObjectsV2_exports);
24: var import_database = require("../../../internal/database");
25: var import_migrations = require("../../../internal/database/migrations");
26: var import_config = require("../../../config");
27: var import_operations = require("../operations");
28: const { isMultitenant } = (0, import_config.getConfig)();
29: const searchRequestParamsSchema = {
30:   type: "object",
31:   properties: {
32:     bucketName: { type: "string" }
33:   },
34:   required: ["bucketName"]
35: };
36: const searchRequestBodySchema = {
37:   type: "object",
38:   properties: {
39:     prefix: { type: "string", examples: ["folder/subfolder"] },
40:     limit: { type: "integer", minimum: 1, examples: [10] },
41:     cursor: { type: "string" },
42:     with_delimiter: { type: "boolean" },
43:     sortBy: {
44:       type: "object",
45:       properties: {
46:         column: { type: "string", enum: ["name", "updated_at", "created_at"] },
47:         order: { type: "string", enum: ["asc", "desc"] }
48:       },
49:       required: ["column"]
50:     }
51:   }
52: };
53: async function routes(fastify) {
54:   const summary = "Search for objects under a prefix";
55:   fastify.post(
56:     "/list-v2/:bucketName",
57:     {
58:       schema: {
59:         body: searchRequestBodySchema,
60:         params: searchRequestParamsSchema,
61:         summary,
62:         tags: ["object"]
63:       },
64:       config: {
65:         operation: { type: import_operations.ROUTE_OPERATIONS.LIST_OBJECTS_V2 },
66:         logMetadata: (req) => ({
67:           prefix: req.body.prefix,
68:           limit: req.body.limit,
69:           cursor: req.body.cursor,
70:           sortBy: req.body.sortBy,
71:           with_delimiter: req.body.with_delimiter
72:         })
73:       }
74:     },
75:     async (request, response) => {
76:       if (isMultitenant) {
77:         const { migrationVersion } = await (0, import_database.getTenantConfig)(request.tenantId);
78:         if (migrationVersion && import_migrations.DBMigration[migrationVersion] < import_migrations.DBMigration["search-v2"]) {
79:           return response.status(400).send({
80:             message: "This feature is not available for your tenant"
81:           });
82:         }
83:       }
84:       const { bucketName } = request.params;
85:       const { limit, with_delimiter, cursor, prefix, sortBy } = request.body;
86:       const results = await request.storage.from(bucketName).listObjectsV2({
87:         prefix,
88:         delimiter: with_delimiter ? "/" : void 0,
89:         maxKeys: limit,
90:         cursor,
91:         sortBy
92:       });
93:       return response.status(200).send(results);
94:     }
95:   );
96: }
97: //# sourceMappingURL=listObjectsV2.js.map
98: 

SOURCE /app/dist/storage/object.js lines 475-567
475:   async searchObjects(prefix, options) {
476:     if (prefix.length > 0 && !prefix.endsWith("/")) {
477:       prefix = `${prefix}/`;
478:     }
479:     return this.db.searchObjects(this.bucketId, prefix, options);
480:   }
481:   async listObjectsV2(options) {
482:     const limit = Math.min(options?.maxKeys || 1e3, 1e3);
483:     const prefix = options?.prefix || "";
484:     const delimiter = options?.delimiter;
485:     const cursor = options?.cursor ? decodeContinuationToken(options.cursor) : void 0;
486:     let searchResult = await this.db.listObjectsV2(this.bucketId, {
487:       prefix: options?.prefix,
488:       delimiter: options?.delimiter,
489:       maxKeys: limit + 1,
490:       nextToken: cursor?.startAfter,
491:       startAfter: cursor?.startAfter || options?.startAfter,
492:       sortBy: {
493:         order: cursor?.sortOrder || options?.sortBy?.order,
494:         column: cursor?.sortColumn || options?.sortBy?.column,
495:         after: cursor?.sortColumnAfter
496:       }
497:     });
498:     let prevPrefix = "";
499:     if (delimiter) {
500:       const delimitedResults = [];
501:       for (const object of searchResult) {
502:         let idx = object.name.replace(prefix, "").indexOf(delimiter);
503:         if (idx >= 0) {
504:           idx = prefix.length + idx + delimiter.length;
505:           const currPrefix = object.name.substring(0, idx);
506:           if (currPrefix === prevPrefix) {
507:             continue;
508:           }
509:           prevPrefix = currPrefix;
510:           delimitedResults.push({
511:             id: null,
512:             name: currPrefix,
513:             bucket_id: object.bucket_id
514:           });
515:           continue;
516:         }
517:         delimitedResults.push(object);
518:       }
519:       searchResult = delimitedResults;
520:     }
521:     let isTruncated = false;
522:     if (searchResult.length > limit) {
523:       searchResult = searchResult.slice(0, limit);
524:       isTruncated = true;
525:     }
526:     const folders = [];
527:     const objects = [];
528:     searchResult.forEach((obj) => {
529:       const target = obj.id === null ? folders : objects;
530:       const name = obj.id === null && !obj.name.endsWith("/") ? obj.name + "/" : obj.name;
531:       target.push({
532:         ...obj,
533:         name: options?.encodingType === "url" ? encodeURIComponent(name) : name
534:       });
535:     });
536:     let nextContinuationToken;
537:     let nextCursorKey;
538:     if (isTruncated) {
539:       const sortColumn = cursor?.sortColumn || options?.sortBy?.column;
540:       nextContinuationToken = encodeContinuationToken({
541:         startAfter: searchResult[searchResult.length - 1].name,
542:         sortOrder: cursor?.sortOrder || options?.sortBy?.order,
543:         sortColumn,
544:         sortColumnAfter: sortColumn && sortColumn !== "name" && searchResult[searchResult.length - 1][sortColumn] ? new Date(searchResult[searchResult.length - 1][sortColumn] || "").toISOString() : void 0
545:       });
546:       nextCursorKey = searchResult[searchResult.length - 1].name;
547:     }
548:     return {
549:       hasNext: isTruncated,
550:       nextCursor: nextContinuationToken,
551:       nextCursorKey,
552:       folders,
553:       objects
554:     };
555:   }
556:   /**
557:    * Generates a signed url for accessing an object securely
558:    * @param objectName
559:    * @param url
560:    * @param expiresIn seconds
561:    * @param metadata
562:    */
563:   async signObjectUrl(objectName, url, expiresIn, metadata) {
564:     await this.findObject(objectName);
565:     metadata = Object.keys(metadata || {}).reduce((all, key) => {
566:       if (!all[key]) {
567:         delete all[key];

SOURCE /app/dist/storage/database/knex.js lines 238-327
238:       return query.abortOnSignal(signal);
239:     });
240:     return data;
241:   }
242:   async listObjectsV2(bucketId, options) {
243:     return this.runQuery("ListObjectsV2", async (knex, signal) => {
244:       if (!options?.delimiter) {
245:         const query = knex.table("objects").where("bucket_id", bucketId).select(["id", "name", "metadata", "updated_at", "created_at", "last_accessed_at"]).limit(options?.maxKeys || 100);
246:         const allowedSortColumns = /* @__PURE__ */ new Set(["updated_at", "created_at"]);
247:         const allowedSortOrders = /* @__PURE__ */ new Set(["asc", "desc"]);
248:         const sortColumn = options?.sortBy?.column && allowedSortColumns.has(options.sortBy.column) ? options.sortBy.column : void 0;
249:         const sortOrder = options?.sortBy?.order && allowedSortOrders.has(options.sortBy.order) ? options.sortBy.order : "asc";
250:         if (sortColumn) {
251:           query.orderBy(sortColumn, sortOrder);
252:         }
253:         query.orderBy(knex.raw(`name COLLATE "C"`), sortOrder);
254:         if (options?.prefix) {
255:           query.where("name", "like", `${escapeLike(options.prefix)}%`);
256:         }
257:         if (options?.startAfter && !options?.nextToken) {
258:           query.andWhere(knex.raw(`name COLLATE "C" > ?`, [options.startAfter]));
259:         }
260:         if (options?.nextToken) {
261:           const pageOperator = sortOrder === "asc" ? ">" : "<";
262:           if (sortColumn && options.sortBy?.after) {
263:             query.andWhere(
264:               knex.raw(
265:                 `ROW(date_trunc('milliseconds', ${sortColumn}), name COLLATE "C") ${pageOperator} ROW(COALESCE(NULLIF(?, '')::timestamptz, 'epoch'::timestamptz), ?)`,
266:                 [options.sortBy.after, options.nextToken]
267:               )
268:             );
269:           } else {
270:             query.andWhere(knex.raw(`name COLLATE "C" ${pageOperator} ?`, [options.nextToken]));
271:           }
272:         }
273:         return query.abortOnSignal(signal);
274:       }
275:       let useNewSearchVersion2 = true;
276:       if (isMultitenant) {
277:         useNewSearchVersion2 = await (0, import_migrations.tenantHasMigrations)(this.tenantId, "search-v2");
278:       }
279:       if (useNewSearchVersion2 && options?.delimiter === "/") {
280:         let paramPlaceholders = "?,?,?,?,?";
281:         const sortParams = [];
282:         const hasSortSupport = await (0, import_migrations.tenantHasMigrations)(this.tenantId, "add-search-v2-sort-support") || await (0, import_migrations.tenantHasMigrations)(this.tenantId, "search-v2-optimised");
283:         if (hasSortSupport) {
284:           paramPlaceholders += ",?,?,?";
285:           sortParams.push(
286:             options?.sortBy?.order || "asc",
287:             options?.sortBy?.column || "name",
288:             options?.sortBy?.after || null
289:           );
290:         }
291:         const levels = !options?.prefix ? 1 : options.prefix.split("/").length;
292:         const searchParams = [
293:           options?.prefix || "",
294:           bucketId,
295:           options?.maxKeys || 1e3,
296:           levels,
297:           options?.startAfter || "",
298:           ...sortParams
299:         ];
300:         const result2 = await knex.raw(`select * from storage.search_v2(${paramPlaceholders})`, searchParams).abortOnSignal(signal);
301:         return result2.rows;
302:       }
303:       const result = await knex.raw("select * from storage.list_objects_with_delimiter(?,?,?,?,?,?)", [
304:         bucketId,
305:         options?.prefix,
306:         options?.delimiter,
307:         options?.maxKeys,
308:         options?.startAfter || "",
309:         options?.nextToken || ""
310:       ]).abortOnSignal(signal);
311:       return result.rows;
312:     });
313:   }
314:   async listBuckets(columns = "id", options) {
315:     const data = await this.runQuery("ListBuckets", async (knex, signal) => {
316:       const columnNames = columns.split(",").map((c) => c.trim());
317:       const selectColumns = columnNames.filter((name) => {
318:         return name !== "type";
319:       });
320:       if (columnNames.includes("type")) {
321:         selectColumns.push(knex.raw("'STANDARD' as type"));
322:       }
323:       const query = knex.from("buckets").select(selectColumns);
324:       if (options?.search !== void 0 && options.search.length > 0) {
325:         query.where("name", "ilike", `%${escapeLike(options.search)}%`);
326:       }
327:       if (options?.sortColumn !== void 0) {

```

## Installed SDK excerpts

```text

SOURCE node_modules/@supabase/storage-js/src/lib/types.ts
207: export interface SearchV2Options {
208:   /**
209:    * The number of files you want to be returned.
210:    * @default 1000
211:    */
212:   limit?: number
213: 
214:   /**
215:    * The prefix search string to filter files by.
216:    */
217:   prefix?: string
218: 
219:   /**
220:    * The cursor used for pagination. Pass the value received from nextCursor of the previous request.
221:    */
222:   cursor?: string
223: 
224:   /**
225:    * Whether to emulate a hierarchical listing of objects using delimiters.
226:    *
227:    * - When `false` (default), all objects are listed as flat key/value pairs.
228:    * - When `true`, the response groups objects by delimiter, making it appear
229:    *   like a file/folder hierarchy.
230:    *
231:    * @default false
232:    */
233:   with_delimiter?: boolean
234: 
235:   /**
236:    * The column and order to sort by
237:    * @default 'name asc'
238:    */
239:   sortBy?: SortByV2
240: }
241: 
242: /**
243:  * File object returned by the List V2 API (listV2() method)
244:  * Objects and folders are returned in separate arrays - this type represents
245:  * actual files only. Use SearchV2Folder for folder entries.
246:  */
247: export interface SearchV2Object {
248:   /** File name */
249:   name: string
250:   /** Full object key/path */
251:   key?: string
252:   /** Unique identifier for the file */
253:   id: string
254:   /** Last update timestamp */
255:   updated_at: string
256:   /** Creation timestamp */
257:   created_at: string
258:   /** File metadata including size, mimetype, etc. (null if not yet set) */
259:   metadata: FileMetadata | null
260:   /** @deprecated Last access timestamp */
261:   last_accessed_at: string
262: }
263: 
264: /**
265:  * Folder entry returned by the List V2 API (listV2() method) when using with_delimiter: true
266:  */
267: export interface SearchV2Folder {
268:   /** Folder name/prefix */
269:   name: string
270:   /** Full folder key/path */
271:   key?: string
272: }
273: 
274: export interface SearchV2Result {
275:   hasNext: boolean
276:   folders: SearchV2Folder[]
277:   objects: SearchV2Object[]
278:   nextCursor?: string
279: }

SOURCE node_modules/@supabase/storage-js/src/packages/StorageFileApi.ts
1366:   async listV2(
1367:     options?: SearchV2Options,
1368:     parameters?: FetchParameters
1369:   ): Promise<
1370:     | {
1371:         data: SearchV2Result
1372:         error: null
1373:       }
1374:     | {
1375:         data: null
1376:         error: StorageError
1377:       }
1378:   > {
1379:     return this.handleOperation(async () => {
1380:       const body = { ...options }
1381:       return await post(
1382:         this.fetch,
1383:         `${this.url}/object/list-v2/${this.bucketId}`,
1384:         body,
1385:         { headers: this.headers },
1386:         parameters
1387:       )
1388:     })
1389:   }
1390: 
1391:   protected encodeMetadata(metadata: Record<string, any>) {
1392:     return JSON.stringify(metadata)

```
