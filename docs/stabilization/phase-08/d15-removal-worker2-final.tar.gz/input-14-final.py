"""Worker-2 final native removal stages; phase boundaries permit screenshot inspection."""
import json
import re
import sys
from pathlib import Path
from drive import E, ROOT, app, click, control, fill, native, original_rows, provider, reload, rows, save, screenshot, snapshot
from baseline import actor, board, open_packet, clean_cohort, native_remove, restore_remove


def read(name):
    return json.loads((E / name).read_text())


def choose_template(page, switch, key, tag):
    click(page, "button", "New Template" if switch else "Template", tag + "-popup")
    snapshot(page, tag + "-options")
    screenshot(page, tag + "-options")
    native("press_key", {"pageId": page, "key": key}, tag + "-choice-key")
    native("press_key", {"pageId": page, "key": "Enter"}, tag + "-choice-enter")
    snapshot(page, tag + "-selected")
    screenshot(page, tag + "-selected")
    # Caller inspects this screenshot before running the independent save phase.


def submit_template(page, seed, template_id, switch, tag):
    label = "Switch Template" if switch else "Assign Template"
    text = snapshot(page, tag + "-footer-fresh")
    parts = text.split('dialog "' + label + '"')
    assert len(parts) == 2, "Required modal unavailable; preserve driving gap"
    matches = re.findall(r'uid=(\S+) button "' + label + '"', parts[1])
    assert len(matches) == 1, "Footer unavailable/ambiguous"
    native("click", {"pageId": page, "uid": matches[0], "includeSnapshot": True}, tag + "-submit")
    snapshot(page, tag + "-saved")
    screenshot(page, tag + "-saved")
    business_body(page, "POST", "onboarding-resync", 200, tag)
    expected = {"onboardingId": seed["packets"][0]["id"], "newTemplateId": template_id}
    assert read_body(tag, "request") == expected, "Native selected the wrong actual template"
    parent = rows("personnel_onboardings", "orgA", tag + "-parent", "id", expected["onboardingId"])
    assert parent[0]["template_id"] == template_id
    saved = rows("onboarding_step_progress", "orgA", tag + "-progress", "onboarding_id", expected["onboardingId"])
    save(tag + "-saved-progress-ids.json", [row["id"] for row in saved])
    reload(page, tag + "-persistence")
    open_packet(page, seed, tag + "-persistence")
    snapshot(page, tag + "-persistence-open")
    screenshot(page, tag + "-persistence-open")
    return saved


def read_body(tag, kind):
    path = E / (tag + ".network-" + kind)
    assert path.is_file(), "Missing real business body; no body acceptance"
    return json.loads(path.read_text())


def business_body(page, method, family, status, tag):
    native("list_network_requests", {"pageId": page}, tag + "-network")
    text = (E / (tag + "-network-stdout.json")).read_text()
    matches = re.findall(r"reqid=(\d+) " + method + r" .*?/api/" + family + r" \[" + str(status) + r"\]", text)
    assert len(matches) == 1, "Need one exact real native HTTP outcome before navigation"
    native("get_network_request", {"pageId": page, "reqid": int(matches[0]),
           "requestFilePath": str((E / (tag + ".network-request")).relative_to(ROOT)),
           "responseFilePath": str((E / (tag + ".network-response")).relative_to(ROOT))}, tag + "-body")
    read_body(tag, "request")
    read_body(tag, "response")


def canonical_id():
    # Actual provider readback recorded before any native clone, never an inferred UUID.
    templates = read("original-before-rowsets.json")["orgA"]["onboarding_templates"]
    matches = [row["id"] for row in templates if row["name"] == "Verification Onboarding A"]
    assert len(matches) == 1
    return matches[0]


def prepared(tag):
    return Path(read(tag + "-stdout.json")["prepared"])


def main(phase):
    if phase == "initialize":
        app("doctor", "initial-doctor")
        control(["fixture"], "fixture")
        original_rows("original-before")
        control(["actor", "onboardingConfigure", "onboarding"], "configure-actor")
        control(["actor", "onboardingOperate", "onboarding"], "operate-actor")
        snapshot(actor()["pageId"], "configure-initial")
        snapshot(actor("operate")["pageId"], "operate-initial")
    elif phase == "fault-pick":
        seed = control(["seed", "onboarding-legacy"], "fault-seed")
        page = actor()["pageId"]
        reload(page, "fault-configure-fresh")
        open_packet(page, seed, "fault-legacy")
        click(page, "button", "Assign Template", "fault-assign-open")
        choose_template(page, False, "Home", "fault-assign")
    elif phase == "fault-save-install":
        seed, page = read("fault-seed-stdout.json"), actor()["pageId"]
        submit_template(page, seed, canonical_id(), False, "fault-assign")
        provider("capture", E / "fault-seed-stdout.json", "fault-capture")
        provider("fault-on", E / "fault-seed-stdout.json", "fault-install", prepared("fault-capture"))
    elif phase == "fault-remove":
        seed, page = read("fault-seed-stdout.json"), actor("operate")["pageId"]
        native_remove(page, seed, "fault-native-failure")
        business_body(page, "DELETE", "onboarding-steps", 500, "fault-failure")
        target = next(row["id"] for row in seed["progress"] if row["step_name"] == "Paperwork")
        assert read_body("fault-failure", "request") == {"id": target}
        after = provider("capture", E / "fault-seed-stdout.json", "fault-after-failure")
        unchanged = json.loads(prepared("fault-capture").read_text())["snapshot"] == json.loads(Path(after["prepared"]).read_text())["snapshot"]
        save("fault-unchanged.json", {"fullPreparedSnapshotEqual": unchanged})
        assert unchanged
        feedback = read("fault-native-failure-feedback-state-stdout.json")["entries"]
        save("fault-feedback-observation.json", {"entries": feedback, "expectedReadableError": True})
        assert any(item["type"] == "error" and item["text"].strip() for item in feedback), "Actual rendered error missing"
    elif phase == "fault-off-retry":
        seed, page = read("fault-seed-stdout.json"), actor("operate")["pageId"]
        provider("fault-off", E / "fault-seed-stdout.json", "fault-off", prepared("fault-capture"))
        restore_remove(page, "fault-first")
        native_remove(page, seed, "fault-native-retry")
        business_body(page, "DELETE", "onboarding-steps", 200, "fault-retry")
        assert read_body("fault-retry", "response") == {"success": True}
        restore_remove(page, "fault-retry")
        reload(page, "fault-retry-persistence")
        open_packet(page, seed, "fault-retry-persistence")
        snapshot(page, "fault-retry-persistence-open")
        screenshot(page, "fault-retry-persistence-open")
        saved = rows("onboarding_step_progress", "orgA", "fault-retry-final-progress", "onboarding_id", seed["packets"][0]["id"])
        target = next(row["id"] for row in seed["progress"] if row["step_name"] == "Paperwork")
        assert not any(row["id"] == target for row in saved)
        for original in seed["progress"]:
            if original["id"] == target:
                continue
            actual = next(row for row in saved if row["id"] == original["id"])
            for key in ("completed", "notes", "current_stage", "step_name", "step_type"):
                assert actual[key] == original[key]
        save("fault-real-retry-outcome.json", {"httpStatus": 200, "originalPaperworkAbsent": True, "otherOriginalWorkNotesRetained": True})
    elif phase == "fault-clean":
        clean_cohort(read("fault-seed-stdout.json"), read("fault-assign-saved-progress-ids.json"), "fault")
        assert original_rows("original-after-fault") == read("original-before-rowsets.json")
    elif phase == "wait-template":
        seed = control(["seed", "onboarding-legacy"], "wait-seed")
        page = actor()["pageId"]
        board(actor(), "wait-fresh")
        click(page, "link", "Templates", "wait-templates-navigation")
        before = rows("onboarding_templates", "orgA", "wait-catalog-before")
        click(page, "button", "Duplicate Verification Onboarding A", "wait-native-duplicate")
        after = rows("onboarding_templates", "orgA", "wait-catalog-after-duplicate")
        added = [row for row in after if row["id"] not in {row["id"] for row in before}]
        assert len(added) == 1
        clone, name = added[0], "D15 Removal Matching " + seed["tag"]
        save("wait-native-clone-initial.json", clone)
        snapshot(page, "wait-native-duplicate-after")
        screenshot(page, "wait-native-duplicate-after")
        click(page, "button", "Edit " + clone["name"], "wait-template-editor-open")
        fill(page, "Name", name, "wait-template-name-fill")
        click(page, "button", "Save", "wait-template-name-save")
        click(page, "button", "Edit Verification Paperwork", "wait-paperwork-editor-open")
        fill(page, "Name", "Paperwork", "wait-paperwork-name-fill")
        click(page, "button", "Save Changes", "wait-paperwork-name-save")
        snapshot(page, "wait-matching-template")
        screenshot(page, "wait-matching-template")
        definitions = rows("onboarding_template_steps", "orgA", "wait-matching-definitions", "template_id", clone["id"])
        assert len(definitions) == 3 and len([row for row in definitions if row["name"] == "Paperwork" and row["step_type"] == "paperwork"]) == 1
        save("wait-native-template-manifest.json", {"id": clone["id"], "name": name, "definitionIds": [row["id"] for row in definitions]})
        reload(page, "wait-template-persistence")
        screenshot(page, "wait-template-persistence")
    elif phase == "wait-assign-pick":
        page, seed = actor()["pageId"], read("wait-seed-stdout.json")
        board(actor(), "wait-assign-entry")
        open_packet(page, seed, "wait-legacy")
        click(page, "button", "Assign Template", "wait-assign-open")
        choose_template(page, False, "Home", "wait-assign")
    elif phase == "wait-assign-save-switch-pick":
        page, seed = actor()["pageId"], read("wait-seed-stdout.json")
        saved = submit_template(page, seed, read("wait-native-template-manifest.json")["id"], False, "wait-assign")
        target = next(row for row in seed["progress"] if row["step_name"] == "Paperwork")
        actual = next(row for row in saved if row["id"] == target["id"])
        assert actual["active"] and actual["template_step_id"] in read("wait-native-template-manifest.json")["definitionIds"]
        for key in ("completed", "notes", "current_stage", "step_name", "step_type", "stages"):
            assert actual[key] == target[key]
        click(page, "button", "Switch Template", "wait-switch-open")
        choose_template(page, True, "End", "wait-switch")
    elif phase == "wait-switch-save":
        page, seed = actor()["pageId"], read("wait-seed-stdout.json")
        submit_template(page, seed, canonical_id(), True, "wait-switch-away")
        provider("capture", E / "wait-seed-stdout.json", "wait-capture")
    elif phase == "wait-readback":
        outcomes = read("wait-drained-outcomes.json")
        assert outcomes["allSettled"] and outcomes["completeHttpBodies"], "No navigation without settled full responses"
        seed, page = read("wait-seed-stdout.json"), actor()["pageId"]
        responses = [item["response"] for item in outcomes["requests"]]
        reconciliation = next(item for item in responses if item["request"]["method"] == "POST")
        deletion = next(item for item in responses if item["request"]["method"] == "DELETE")
        target = next(row for row in seed["progress"] if row["step_name"] == "Paperwork")
        rpc = json.loads(reconciliation["body"])
        rpc_target = next(row for row in rpc["steps"] if row["id"] == target["id"])
        parent = rows("personnel_onboardings", "orgA", "wait-final-parent", "id", seed["packets"][0]["id"])
        saved = rows("onboarding_step_progress", "orgA", "wait-final-progress", "onboarding_id", seed["packets"][0]["id"])
        save("wait-all-ordinary-progress-ids.json", sorted(set(read("wait-assign-saved-progress-ids.json") + read("wait-switch-away-saved-progress-ids.json") + [row["id"] for row in saved])))
        reload(page, "wait-final-persistence")
        open_packet(page, seed, "wait-final-persistence")
        snapshot(page, "wait-final-persistence-open")
        screenshot(page, "wait-final-persistence-open")
        actual = next((row for row in saved if row["id"] == target["id"]), None)
        passed = reconciliation["status"] == 200 and deletion["status"] == 409 and rpc_target["active"] is True and actual is not None and actual["active"] is True
        save("wait-observed-outcome.json", {"outcome": "PASS" if passed else "FAIL", "reconciliationHttpStatus": reconciliation["status"], "deleteHttpStatus": deletion["status"], "originalPaperworkSurvivesActive": actual is not None and actual["active"] is True, "nativeReloadSeparateFromOrdinaryRequests": True})
        assert passed, "Observed conditional deletion contract failed; preserve and clean"
        assert parent[0]["template_id"] == rpc["templateId"]
        for original in seed["progress"]:
            saved_original = next(row for row in saved if row["id"] == original["id"])
            for key in ("completed", "notes", "current_stage", "step_name", "step_type", "stages"):
                assert saved_original[key] == original[key]
    elif phase == "wait-clean":
        from baseline import main as original_main
        original_main("wait-clean")
    else:
        raise SystemExit("Unsupported final stage")


if __name__ == "__main__":
    main(sys.argv[1])
