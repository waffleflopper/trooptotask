<script lang="ts">
	import { AlertDialog, DropdownMenu, Popover } from 'bits-ui';
	let { kind, show = true }: { kind: 'popover' | 'menu' | 'alert'; show?: boolean } = $props();
</script>

<button id="outside">outside</button>
{#if show}
	{#if kind === 'popover'}
		<Popover.Root open>
			<Popover.Trigger>t</Popover.Trigger>
			<Popover.Portal><Popover.Content><button id="inner">in</button></Popover.Content></Popover.Portal>
		</Popover.Root>
	{:else if kind === 'menu'}
		<DropdownMenu.Root open>
			<DropdownMenu.Trigger>t</DropdownMenu.Trigger>
			<DropdownMenu.Portal>
				<DropdownMenu.Content>
					<DropdownMenu.Item id="item1">One</DropdownMenu.Item>
					<DropdownMenu.Item id="item2">Two</DropdownMenu.Item>
				</DropdownMenu.Content>
			</DropdownMenu.Portal>
		</DropdownMenu.Root>
	{:else}
		<AlertDialog.Root open>
			<AlertDialog.Portal>
				<AlertDialog.Content><AlertDialog.Title>T</AlertDialog.Title><AlertDialog.Cancel>c</AlertDialog.Cancel></AlertDialog.Content>
			</AlertDialog.Portal>
		</AlertDialog.Root>
	{/if}
{/if}
