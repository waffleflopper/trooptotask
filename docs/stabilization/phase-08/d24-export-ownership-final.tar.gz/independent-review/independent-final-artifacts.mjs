import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const require=createRequire('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/package.json');
const ExcelJS=require('exceljs');
const root=process.argv[2]??'/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-7bc8326b/.verification/evidence/verify-trooptotask/d24-export-ownership-final';
const read=name=>JSON.parse(fs.readFileSync(`${root}/${name}`,'utf8'));
const sections=read('section-inventory.json');
const mutable=new Set(['data_exports','audit_logs','notifications','beta_feedback']);
const allLifecycle=[...read('lifecycle-reloaded.json').rows,...read('lifecycle-b-reloaded.json').rows];
const ownerId=read('feedback-stored.json').rows[0].user_id;
const ids=read('fixture.json').ids;
const mapHeader=header=>({'Duty Role':'clinic_role','PCS / DEROS':'deros','ETS':'ets'}[header]??String(header).toLowerCase().replaceAll(' ','_'));
const sheetRows=sheet=>{
 assert(sheet);const keys=sheet.getRow(1).values.slice(1).map(mapHeader);
 return Array.from({length:Math.max(0,sheet.rowCount-1)},(_,i)=>Object.fromEntries(keys.map((key,j)=>[key,sheet.getRow(i+2).getCell(j+1).value])));
};
let staticCollections=0;let rawFields=0;let readableFields=0;const results=[];
let explicitHttp200Receipts=0;
const receiptMap={
 'owner-initial.json':['owner-json','capture','network'],
 'owner-initial.xlsx':['owner-excel','capture','network'],
 'owner-feedback.json':['owner-feedback-json','capture','network'],
 'owner-feedback.xlsx':['owner-feedback-xlsx','capture','network'],
 'owner-retry.json':['owner-retry','capture','network'],
 'admin.json':['admin-json','capture-state','network-state'],
 'admin.xlsx':['admin-xlsx','capture-state','network-state'],
 'delayed-a.json':['delayed-a','capture-state','held'],
 'switch-b.xlsx':['switch-b-excel','capture-state',null],
};
for(const section of sections)for(const org of ['orgA','orgB'])if(!mutable.has(section.table)){
 assert.deepEqual(read(`before-${org}-${section.table}.json`).rows,read(`after-${org}-${section.table}.json`).rows);staticCollections++;
}
function assertCell(actual,expected,isWorkbook,label){
 if(isWorkbook && expected!==null && typeof expected==='object')actual=JSON.parse(actual);
 if(isWorkbook && expected==='')actual=actual??'';
 assert.deepEqual(actual??null,expected??null,label);
}
const files=['owner-initial.json','owner-initial.xlsx','owner-feedback.json','owner-feedback.xlsx','owner-retry.json','admin.json','admin.xlsx','delayed-a.json','switch-b.xlsx'];
for(const filename of files){
 const org=filename==='switch-b.xlsx'?'orgB':'orgA';const other=org==='orgA'?'orgB':'orgA';
 const isWorkbook=filename.endsWith('.xlsx');const bytes=fs.statSync(`${root}/${filename}`).size;
 const[prefix,captureSuffix,networkSuffix]=receiptMap[filename];
 const capture=read(`${prefix}-${captureSuffix}.json`);const save=read(`${prefix}-save.json`);
 const mime=isWorkbook?'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':'application/json';
 assert.equal(capture.captured,true);assert.equal(capture.bytes,bytes);assert.equal(save.bytes,bytes);
 assert.equal(capture.filename,save.filename);assert.equal(capture.mimeType,mime);assert.equal(save.mimeType,mime);
 assert.equal(save.sha256,createHash('sha256').update(fs.readFileSync(`${root}/${filename}`)).digest('hex'));
 if(networkSuffix){const network=read(`${prefix}-${networkSuffix}.json`);assert.equal(network.calls.length,1);assert.equal(network.calls[0].method,'POST');assert.equal(network.calls[0].status,200);assert.equal(network.calls[0].contentType,mime);assert(network.calls[0].contentDisposition.includes(save.filename));explicitHttp200Receipts++;}
 const record=allLifecycle.find(row=>row.file_size_bytes===bytes);assert(record);
 assert.equal(record.org_id,ids[org]);assert.equal(record.status,'completed');assert(Date.parse(record.completed_at)>=Date.parse(record.created_at));
 let json;let wb;
 if(isWorkbook){wb=new ExcelJS.Workbook();await wb.xlsx.readFile(`${root}/${filename}`);assert.equal(wb.worksheets.length,57);}
 else{json=read(filename);assert.equal(json.organizationId,ids[org]);assert.equal(Object.keys(json.sections).length,38);assert.equal(json.sectionInventory.length,38);}
 let requester;
 for(const [i,section]of sections.entries()){
   const rows=isWorkbook?sheetRows(wb.worksheets[19+i]):json.sections[section.key];
   if(!isWorkbook){assert.deepEqual(json[section.key],rows);assert.equal(json.sectionInventory.find(row=>row.key===section.key).rowCount,rows.length);}
   const source=read(`after-${org}-${section.table}.json`).rows;
   const byId=new Map(source.map(row=>[row.id,row]));
   const foreign=new Set(read(`after-${other}-${section.table}.json`).rows.map(row=>row.id));
   assert.equal(new Set(rows.map(row=>row.id)).size,rows.length);
   let allowed=source;
   if(section.key==='notifications')allowed=source.filter(row=>row.user_id===record.requested_by && Date.parse(row.created_at)<Date.parse(record.created_at));
   if(section.key==='betaFeedback')allowed=source.filter(row=>row.user_id===record.requested_by && Date.parse(row.created_at)<Date.parse(record.created_at));
   if(section.key==='auditLogs')allowed=record.requested_by===ownerId?source.filter(row=>Date.parse(row.timestamp)<Date.parse(record.created_at)):[];
   if(section.key==='dataExports')allowed=source.filter(row=>Date.parse(row.created_at)<=Date.parse(record.created_at));
   assert.deepEqual(new Set(rows.map(row=>row.id)),new Set(allowed.map(row=>row.id)),`${filename}.${section.key}.complete visible IDs`);
   for(const row of rows){
    assert(!foreign.has(row.id));const expected={...byId.get(row.id)};assert(expected.id);
    if(section.key==='dataExports'&&row.id===record.id)Object.assign(expected,{status:'processing',file_size_bytes:null,completed_at:null});
    for(const[key,value]of Object.entries(expected)){assert(key in row);assertCell(row[key],value,isWorkbook,`${filename}.${section.key}.${key}`);rawFields++;}
   }
 }
 if(isWorkbook){
  const people=read(`after-${org}-personnel.json`).rows;const labels=new Map(people.map(person=>[person.id,[person.rank,person.last_name?person.last_name+',':null,person.first_name].filter(Boolean).join(' ').trim()||person.id]));
  const definitions=[['Leader Notes','leader_notes',['author','text','created_at','archived_at']],['Counseling Records','counseling_records',['date_conducted','subject','key_points','plan_of_action','status','notes']],['Personnel Follow-ups','personnel_follow_ups',['title','notes','due_date','status','created_at','completed_at','archived_at']],['Personnel Documents','personnel_documents',['title','file_size_bytes','content_type','uploaded_by','created_at','archived_at']]];
  for(const[sheet,table,fields]of definitions){
   const source=read(`after-${org}-${table}.json`).rows;const rows=sheetRows(wb.getWorksheet(sheet));assert.equal(rows.length,source.length);
   for(let i=0;i<source.length;i++){
    assertCell(rows[i].person,labels.get(source[i].personnel_id)??source[i].personnel_id,true,`${filename}.${sheet}.person`);readableFields++;
    for(const field of fields){assertCell(rows[i][field],source[i][field],true,`${filename}.${sheet}.${field}`);readableFields++;}
    if(table==='personnel_documents'){assert.equal(rows[i].file_name,String(source[i].file_path??'').split(/[\\/]/).at(-1)??'');readableFields++;}
   }
  }
  const personRows=sheetRows(wb.getWorksheet('Personnel'));assert.equal(personRows.length,people.length);
  for(const person of personRows){assert.equal(person.leader_notes??'','');readableFields++;}
 }
 results.push({filename,bytes,requester:record.requested_by,exportId:record.id,organization:org});
}
assert.deepEqual(read('lifecycle-owner-reloaded.json').rows,read('lifecycle-after-client-failures.json').rows);
const pre=new Set(read('lifecycle-after-client-failures.json').rows.map(row=>row.id));const failed=read('lifecycle-source-failure.json').rows.filter(row=>!pre.has(row.id));assert.equal(failed.length,1);assert.equal(failed[0].status,'failed');assert.equal(failed[0].file_size_bytes,null);assert(failed[0].completed_at);
const audits=read('after-orgA-audit_logs.json').rows;assert.equal(audits.filter(row=>row.resource_id===failed[0].id).length,0);
const sourceState=read('source-failure-state.json');assert.equal(sourceState.control.matches,1);assert.equal(sourceState.control.call.status,500);assert.equal(sourceState.control.call.synthetic,true);
assert.equal(read('source-failure-network.json').calls[0].status,500);assert.equal(read('source-failure-capture.json').captured,false);assert.equal(read('source-failure-restored.json').armed,false);
for(const family of ['export','export-excel']){assert.equal(read(`client-${family}-failure-network.json`).calls[0].status,503);assert.equal(read(`client-${family}-failure-capture.json`).captured,false);}
assert.equal(read('delayed-a-held.json').held,true);assert.equal(read('delayed-a-held.json').calls[0].status,200);
const delayed=results.find(row=>row.filename==='delayed-a.json');assert(read('lifecycle-delayed-a-held.json').rows.some(row=>row.id===delayed.exportId&&row.status==='completed'&&row.file_size_bytes===delayed.bytes));
assert.deepEqual(read('feedback-final-reloaded.json').rows,read('feedback-stored.json').rows);
let removedFileWitnesses=0;
for(const org of ['orgA','orgB']){
 const before=read(`artifact-files-${org}-before-cleanup.json`);const after=read(`artifact-files-${org}-after-cleanup.json`);
 assert.equal(before.files.length,4);assert.equal(after.files.length,4);
 assert.deepEqual(new Set(before.files.map(row=>row.path)),new Set(after.files.map(row=>row.path)));
 assert(before.files.every(row=>row.present));assert(after.files.every(row=>!row.present));assert(Object.values(after.tables).every(rows=>rows.length===0));removedFileWitnesses+=after.files.length;
}
assert.deepEqual(read('start-doctor.json'),read('final-doctor.json'));assert.deepEqual(read('final-doctor.json'),read('post-seed-cleanup-doctor.json'));
assert.equal(read('seed-cleanup.json').cleaned,true);assert.equal(read('disposal.json').status,'PASS');
console.log(JSON.stringify({staticCollections,rawFields,readableFields,completedDownloads:results.length,actualArtifactHashReceipts:results.length,explicitHttp200Receipts,removedFileWitnesses,doctorAndDisposal:'PASS',results}));
