import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'd15-overlap'))
from drive import *
import hashlib,importlib.util
control(['clean-seeds'],'clean-seeds-final')
for org in ['orgA','orgB']:
 for table in ['personnel_onboardings','onboarding_step_progress','personnel_trainings']:
  now=control(['rows',table,org],'restored-'+table+'-'+org)['rows'];old=json.loads((E/('original-'+table+'-'+org+'.json')).read_text())['rows'];assert {r['id']:r for r in now}=={r['id']:r for r in old},(org,table)
for mode in ['lifecycle','sequential']:
 seedfile=E/(mode+'-legacy-seed.json')
 if not seedfile.exists():continue
 person=json.loads(seedfile.read_text())['person'];assert control(['rows','personnel','orgA','id',person['id']],'absent-'+mode+'-person')['count']==0
write(E/'restoration-comparison.json',json.dumps({'result':'PASS','scope':'Complete original A/B packet/progress fields including timestamps and selected Training fields','temporaryPersonsRemoved':True},indent=2)+'\n')
private=Path('/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1');ledger=json.loads((private/'verify-trooptotask-owned.json').read_text());assert not ledger['seeded'] and not ledger['grants'];write(E/'ledger-clean.json',json.dumps({'seeded':ledger['seeded'],'grants':ledger['grants']},indent=2)+'\n')
frozen=json.loads((E/'prelaunch-input-hashes.json').read_text());assert all((not (ROOT/r['path']).exists()) if r.get('deleted') else hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in frozen['entries']);write(E/'postrun-input-comparison.json',json.dumps({'result':'PASS','inputs':len(frozen['entries']),'candidate':frozen['candidate'],'revision':frozen['revision']},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('owned_env',ROOT/'scripts/verification/environment.py');env=importlib.util.module_from_spec(spec);spec.loader.exec_module(env);state,workdir,environ=env.owned(env.private_session(str(private)));status=env.status(private);project=state['project'];records=env.containers(state,workdir,environ)
write(E/'owned-provider.json',json.dumps({'project':project,'ports':status['ports'],'config_sha256':state['config_sha256'],'session':str(private),'workdir':str(workdir),'containers':[{'id':c['Id'],'name':c['Name'],'running':c['State']['Running'],'labels':{k:c['Config']['Labels'][k] for k in ['com.supabase.cli.project','com.docker.compose.project']}} for c in records]},indent=2)+'\n')
for action in ['doctor','cleanup']:
 command=['npm','run','--silent','verify:app','--',action,'--worker','1'];write(E/(action+'-final-command.json'),json.dumps(command,indent=2)+'\n');r=subprocess.run(command,text=True,capture_output=True);write(E/(action+'-final.json'),r.stdout);write(E/(action+'-final-stderr.log'),r.stderr);assert r.returncode==0,r.stderr or r.stdout
resources={}
for kind in ['container','volume','network']:
 command=['docker',kind,'ls']+(['-a'] if kind=='container' else [])+['--filter','label=com.supabase.cli.project='+project,'--format','{{json .}}'];write(E/(kind+'-empty-command.json'),json.dumps(command,indent=2)+'\n');r=subprocess.run(command,env=environ,text=True,capture_output=True);assert r.returncode==0,r.stderr;resources[kind]=[json.loads(line) for line in r.stdout.splitlines() if line.strip()];assert not resources[kind]
resources['privateWorkerExists']=private.exists();assert not private.exists();write(E/'owned-project-empty.json',json.dumps({'project':project,'resources':resources},indent=2)+'\n')
print('Full original packets/progress and selected Training restored; temporary Persons absent; frozen inputs unchanged; ledger empty; doctor/disposal pass.',flush=True)
