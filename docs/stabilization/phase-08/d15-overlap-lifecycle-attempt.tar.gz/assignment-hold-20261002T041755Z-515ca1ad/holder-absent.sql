SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE pid = 856 AND backend_start = '2026-10-02 04:17:57.203983+00'::timestamptz AND application_name = 't2t-d15-overlap-87e9d77a8d1f4275a39775704b7c84f0' AND usename = 'supabase_admin' AND datname = 'postgres'));
