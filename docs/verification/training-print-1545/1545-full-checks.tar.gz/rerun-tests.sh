#!/usr/bin/env bash
set -u
cd /home/waffleflops/.cache/t2t-1545-state
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH
export TMPDIR=/home/waffleflops/.cache/t2tp-aknVLp
# Private values in Vite's initial environment hide vi.stubEnv values behind
# $env/dynamic/private. Let unit tests supply their own private configuration.
unset NODE_ENV SUPABASE_SERVICE_ROLE_KEY APP_PUBLIC_ORIGIN PUBLIC_APP_ORIGIN PUBLIC_SITE_URL APP_PUBLIC_ORIGIN_ALLOWLIST ACCOUNT_SETUP_SESSION_SECRET RESEND_API_KEY RESEND_FROM_EMAIL CLEANUP_SECRET CRON_SECRET GITHUB_FEEDBACK_TOKEN
export PUBLIC_SUPABASE_URL=http://127.0.0.1:9
export PUBLIC_SUPABASE_ANON_KEY=synthetic-offline-anon-key
record_dir=.verification/evidence/issue1545-final-state-0860cfd9
cat > .env <<'PUBLIC_ENV'
PUBLIC_SUPABASE_URL=http://127.0.0.1:9
PUBLIC_SUPABASE_ANON_KEY=synthetic-offline-anon-key
PUBLIC_ENV
cp .env "$record_dir/test-public-only.env"
start_time=$(date -u +%FT%TZ)
npm run test > "$record_dir/test-public-only.log" 2>&1
result_code=$?
end_time=$(date -u +%FT%TZ)
line_count=$(wc -l < "$record_dir/test-public-only.log")
printf '%s\t%s\t%s\t%s\t%s\t%s\n' 'npm run test (public-only synthetic environment)' "$result_code" "$line_count" "$start_time" "$end_time" "$record_dir/test-public-only.log" | tee -a "$record_dir/results.tsv"
