BEGIN;
CREATE TEMP TABLE mixed_delete_before AS SELECT 'personnel' AS table_name,id,to_jsonb(p) AS row_data FROM public.personnel p WHERE organization_id IN ('861c9cd0-ef57-43ab-8673-f629df44cd30','c8db31c6-e20a-4055-90b4-b06634f30bc3') UNION ALL SELECT 'entry',id,to_jsonb(r) FROM public.rating_scheme_entries r WHERE organization_id IN ('861c9cd0-ef57-43ab-8673-f629df44cd30','c8db31c6-e20a-4055-90b4-b06634f30bc3');
CREATE TEMP VIEW mixed_delete_current AS SELECT 'personnel' AS table_name,id,to_jsonb(p) AS row_data FROM public.personnel p WHERE organization_id IN ('861c9cd0-ef57-43ab-8673-f629df44cd30','c8db31c6-e20a-4055-90b4-b06634f30bc3') UNION ALL SELECT 'entry',id,to_jsonb(r) FROM public.rating_scheme_entries r WHERE organization_id IN ('861c9cd0-ef57-43ab-8673-f629df44cd30','c8db31c6-e20a-4055-90b4-b06634f30bc3');
DO $fn$ DECLARE rejected boolean := false; constraint_name text;
BEGIN
 BEGIN
  DELETE FROM public.personnel WHERE id='3e3d88c8-b829-4331-bffd-1af477a1983f' AND organization_id='861c9cd0-ef57-43ab-8673-f629df44cd30';
  SET CONSTRAINTS ALL IMMEDIATE;
 EXCEPTION WHEN foreign_key_violation THEN
  GET STACKED DIAGNOSTICS constraint_name = CONSTRAINT_NAME;
  rejected := true;
  RAISE NOTICE 'Mixed legacy local evaluator deletion rejected with 23503 at %', constraint_name;
 END;
 IF NOT rejected THEN RAISE EXCEPTION 'Expected mixed historical links to block local deletion'; END IF;
 IF EXISTS ((SELECT * FROM mixed_delete_current EXCEPT SELECT * FROM mixed_delete_before) UNION ALL (SELECT * FROM mixed_delete_before EXCEPT SELECT * FROM mixed_delete_current)) THEN
  RAISE EXCEPTION 'Rejected deletion changed a saved row';
 END IF;
 RAISE NOTICE 'Both Organizations, every field and rated cascade sentinel are unchanged';
END; $fn$;
ROLLBACK;
