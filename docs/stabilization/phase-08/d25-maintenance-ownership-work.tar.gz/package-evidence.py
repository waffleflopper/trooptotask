from pathlib import Path
import gzip, hashlib, io, json, shutil, subprocess, tarfile, tempfile

repo = Path.cwd()
evidence = repo / '.verification/evidence/verify-trooptotask'
work = evidence / 'd25-ownership-work'
base = '988efcc03259c92157716c1cd6a77b7dba8a8b20'
paths = set(subprocess.check_output(['git', 'diff', '--name-only', base], text=True).splitlines())
paths.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
inputs = {}
for path in sorted(paths):
    if path.endswith('.md') and not path.startswith('.agents/'):
        continue
    if path.endswith('.tar.gz'):
        continue
    source = repo / path
    if not source.is_file():
        inputs[path] = {'deleted': True}
        continue
    target = work / 'frozen-inputs' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    inputs[path] = {'sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
(work / 'source-inputs.json').write_text(json.dumps({'base': base, 'inputs': inputs}, indent=2) + '\n')
for name in ['d25-check.txt', 'd25-governance-green.txt', 'd25-setup-route-green.txt', 'd25-onboarding-discovery-red.txt', 'd25-onboarding-discovery-green.txt', 'd25-coordinator-format.txt', 'd25-current-docs-format.txt', 'd25-coderabbit-help.txt']:
    source = repo / '.verification' / name
    if source.is_file():
        shutil.copyfile(source, work / name)
shutil.copyfile(repo / '.verification/d25-current-issue.json', work / 'issue-at-packaging.json')
shutil.copyfile(Path(__file__), work / 'package-evidence.py')
(work / 'sanitization.json').write_text(json.dumps({'credentialScan': 'No live JWT, Supabase key, setup-token hash, bearer credential or cookie found in payloads.', 'redactions': [], 'syntheticConstants': 'Three Bearer matches in the failing SDK log are the committed synthetic-setup-cron-secret test value. Static postgres and unreachable SDK test keys are synthetic.', 'omissions': ['Private worker provider/session/fixture state and real bearer secrets were never copied.', '__pycache__ and pyc scratch compiler products.'], 'scope': 'Synthetic owned service/provider observations and local SQL logs only.'}, indent=2) + '\n')
runs = {
    'd25-ownership-work': 'd25-maintenance-ownership-work.tar.gz',
    'd25-ownership-database': 'd25-maintenance-ownership-database.tar.gz',
    'd25-ownership-database-attempt': 'd25-maintenance-ownership-database-attempt.tar.gz',
    'd25-ownership-service-preparation': 'd25-maintenance-ownership-preparation.tar.gz',
    'd25-ownership-final': 'd25-maintenance-ownership-final.tar.gz',
}
out = repo / 'docs/stabilization/phase-08'
scratch = repo / '.verification/d25-archive-checks'
scratch.mkdir(parents=True, exist_ok=True)
results = []
for name, archive_name in runs.items():
    root = evidence / name
    payloads = sorted(p for p in root.rglob('*') if p.is_file() and p.name != 'inventory.json' and '__pycache__' not in p.parts and p.suffix != '.pyc')
    inventory = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in payloads}
    inventory_path = root / 'inventory.json'
    inventory_path.write_text(json.dumps(inventory, indent=2) + '\n')
    archive = out / archive_name
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as tar:
        for source in payloads + [inventory_path]:
            data = source.read_bytes()
            item = tarfile.TarInfo(str(source.relative_to(root)))
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            tar.addfile(item, io.BytesIO(data))
    with tempfile.TemporaryDirectory(prefix=name+'-', dir=scratch) as temporary:
        extracted = Path(temporary)
        with tarfile.open(archive) as tar:
            tar.extractall(extracted, filter='data')
        actual = {str(p.relative_to(extracted)) for p in extracted.rglob('*') if p.is_file()}
        assert actual == set(inventory) | {'inventory.json'}, archive_name
        assert json.loads((extracted/'inventory.json').read_text()) == inventory
        for filename, digest in inventory.items():
            assert hashlib.sha256((extracted/filename).read_bytes()).hexdigest() == digest, filename
    results.append({'archive': archive_name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'payloads': len(payloads), 'expandedBytes': sum(p.stat().st_size for p in payloads), 'archiveBytes': archive.stat().st_size, 'freshExtraction': 'PASS'})
(repo / '.verification/d25-packaging-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
