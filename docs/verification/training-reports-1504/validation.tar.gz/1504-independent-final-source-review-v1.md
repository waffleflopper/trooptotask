# Independent final source continuity review for #1504 and PR1511

Pinned source verdict. One P2 source finding remains in the new boundary-focus correction. If the requested affected count shrinks to a single page, the remembered enabled pager is removed rather than disabled, and the guard misses focus recovery. There is also one inherited P3 architecture wording residue. No further actionable executable defect was found in the reconciled current PR, access-policy merge or prior reviewed source continuity. This is not current live or whole-task acceptance.

## Scope, authority and independence

The exact current base is `ee1ca2b275d71cd0b9a51367b58c4754a687a443`. The exact reviewed head is `068348401a486cda9d7af740ea5166cf8df34009`. This head merges ee1 into correction commit `31024cb06b99c46fe10905f8c126bfb9e065fb8d`. Both sides were read from Git blobs. Later changes or live results are not silently included.

This bounded Standards and Spec source lane reuses the complete per-file requirements/consumer review at `2e3aea52ad01e33e173b769f285b0ab6103547d7` against `a59c6c92bba242cde37f15a5d59e6d305e5267ac`, then independently reconciles every current changed path and every changed head/base byte. It also reads the complete previously unreviewed correction and access ownership wave, its affected contracts, reverse consumers and source documentation. It does not repeat the entire unchanged source sweep.

AGENTS.md, t2t-engineer, TESTING.md and the supplied generic Poteto reviewer instructions govern the lane. The parent limits override broader workflow defaults. No delegates, source/test/docs/Git/PR writes, tests, gates, application/service/database/browser actions, connector use or external writes occurred. The sole output is this report. Read-only source/artifact parsing and existing log inspection were used. No image or PDF visual judgment occurred. The reviewer uses the inherited parent model. Source/artifact review is neither independent execution nor model diversity.

The authority remains final #1504 implementation on draft PR1511, followed by readiness/CI/review monitoring only after acceptance. It does not authorize merge, deployment, remote database operation, or advancement of D27 or another stabilization issue.

## Complete census and continuity

The full current `git diff --binary BASE HEAD` is **88,333,052 bytes**, SHA-256 `23e1742077c76ca83c7e06ee5f2c9c036b48186bc229bf46db3759d5186809d6`. The complete current PR census is **139 paths**, **49 added / 86 modified / 4 deleted**, including **19 archives** and **120 text/source paths**. Appendix A records each path's exact base/head bytes/hash, deletion state and coverage disposition. All present working files matched pinned head blobs when the census was taken, and all four deleted paths were absent. No write was made to prove this.

Every prior 137 PR path remains represented with the same change status. The only new PR paths are the archived failed v1 and v2 attempts. **125 head byte/deletion states are unchanged from 2e3**, comprising 104 retained text files, 17 archives and four deleted files. Fourteen current head paths have new bytes or are added. These are exactly the two archives, the three previously reviewed v2 source deltas, the five final correction text paths, and the five overlap paths affected by the access merge. Appendix dispositions avoid treating a prior verdict as fresh execution.

Five base paths changed under the PR since a59. They are the authorization and ownership documents, module boundaries, Organization policy operation and in-memory adapter. Their merged changes preserve both waves. Organization policy keeps the Training goal's integer/range validation, patch mapping and audit fields while consuming the new grant/audit types. The in-memory adapter keeps Training goal reads/write mapping and briefing context while migrating actor types. The ownership documents retain Training's briefing ownership and add Access policy ownership. Module boundaries retain Training public seams while removing the now-deleted generic policy paths. No merge semantic collision was found.

The upstream access wave from a59 to ee1 has **70 physical paths** with rename expansion, **8 added / 49 modified / 13 deleted**. Its complete binary diff is **6,704,016 bytes**, SHA-256 `979b949c0850d53cbfd30f46e6d9ccc5a76fd1d076e3ab3523a3113a7c74b423`. Sixty-five merged paths are byte-identical to current main, including absence for deleted paths; the five overlapping paths are separately inspected above. Appendix B pins all 70 dependency paths. Main added no SQL or Svelte UI file. The two D27 archives are historical upstream evidence containers. Their bytes are pinned, but this lane does not independently expand, visually inspect or reaccept their live contents.

Existing review bindings are preserved.

| Prior report | SHA-256 | Continued scope |
|---|---|---|
| `.verification/1504-independent-cumulative-source-review-v1.md` | `c54fb7fc6588687f14e1af38c5b6e910de1a9e1b619b55ef9ec5470be036bdeb` | Complete 137-path source/spec/consumer review at 2e3/a59. |
| `.verification/1504-independent-final-attempt-v1-artifact-review.md` | `702092b2c8ded6d3a2fce5e4c43d33a6018c9710771dd57636157875662f8fe1` | Expanded original nonprint acceptance observations at 2e3, with missing captures and evidence gaps. |
| `.verification/1504-independent-final-attempt-v2-review.md` | `8493d0819228c9c5d83faa2df0d34da334b2446084fdc5f7665ece05cfec1d2a` | Three correction-source files at 580c24fa, actual v2 structured-page/Retry/print/artifact proof, with P1/K1 open. |

These reports' existing literal counts, source deletions, reverse-consumer mapping and isolation conclusions stay at their original pins. They do not become newly executed whole-candidate proof after a base merge.

## Independently specified contracts still carried forward

The parent #1433 amendments and #1501–1504 requirements remain the expectations, not an implementation report. The earlier review independently derived the denominator from active in-scope people and required applicable pairs; optional, exempt and nonapplicable pairs stay excluded. Completion currency and projected lapse retain their distinct date semantics, including completion-free expiration-only and never-expiring records. Readiness percentages, weekly forecast endpoints, goal projection, total/grid cells, Type risk order and model-only Focus at most three remain defined by the shared model.

Exact cell and Focus drill-downs must rederive filtered requirements, totals and deterministic ordering at the server boundary. Loaded rows/range retain their identity while another page is loading or failed. Retry repeats the attempted page. Page sizes stay 25/100. Late responses and abandoned scopes must not replace newer content or take focus. Export still has the exact five sheets Summary / Forecast / Hot spots / Focus / Requirements, literal values, all filtered affected rows without pagination, and independence from the open detail. Training read/manage/configure, Organization and Group scope, ordinary provider admission, and no global active-Organization store remain firm.

The current base merge does not change the model, report serialization, session lifecycle, workbook builder or report/detail/export algorithms. Personnel Training readiness, Dashboard currency, Person workbook, raw Organization export and Onboarding record-existence consumers remain under their separate retained contracts. The complete earlier reverse census remains applicable to unchanged byte paths; access grant migration does not transfer their domain ownership or broaden authority.

## New pager lifecycle and meaningful test boundary

At pinned `TrainingAffectedSoldiersSection.svelte:50–64`, the displayed result is `shown = $derived(detail.detail)`. `showPage()` remembers the currently focused button and forwards the requested page. The remembered `pager` is deliberately plain nonreactive local state. Setting it does not independently schedule the effect.

The session at `trainingBriefingSession.svelte.ts:130–159` retains the same displayed object during same-scope loading/error and replaces it only for a current accepted result. Installed Svelte's derived equality checks the result identity. Therefore the old displayed result during a held page request does not clear the remembered pager merely because request status changes. When the displayed object changes, the effect runs after DOM updates. For the ordinary boundary where the same connected button becomes disabled, it focuses the region only if that button or BODY remains active. If the user moved to another still-focused control, the guard leaves that control alone, then clears the reference. Middle-page navigation keeps its enabled button. Size radios and filters do not directly set a pager. Initial open/explicit Retry focus and request identity/cancellation are unchanged.

This source lifecycle is coherent for those paths. It has the disconnected-pager edge below. A stale remembered button is not a new authorization or data-response channel; the request IDs still reject stale results. The active BODY exception is a native focus-fixup allowance, not proof of every possible deliberate-blur interaction.

The new test at `TrainingReportsPage.test.ts:338–370` supplies literal 60-row detail pages and verifies middle Next/Previous retain the activated button, last/first pages focus the region, and exact ranges remain 26–50, 51–60, 26–50, 1–25. It exercises the real rendered component/session with fake fetch and asserts user-visible focus/state, so it is meaningful interaction coverage. Its immediately resolved responses do not independently prove held-response timing, native Enter, user focus moving during a held request, or count shrinking until the pager is removed. Those require targeted stable-boundary or fresh native evidence. No copy, dimensions or source-string tests were added for the CSS.

## Print source boundaries and corrected recipe

Pinned `src/app.css:392–399` resets height/min-height/max-height/overflow in print on html, body and ancestors containing the unique Training report marker. Each selector requires `[data-print-report='training']`. It does not select arbitrary descendant content within report cards, and the existing shell-slot display/margin reset remains at lines 401–405. The named landscape page and report page assignment remain unchanged. Other pages without the marker do not match the new selectors. This is a source scope verdict, not a rendered-output or visual verdict.

The former root layout viewport heights provide a supported reason to inspect ancestor constraints, but source alone does not prove that the extra no-applicable page is eliminated. Fresh actual no-applicable and long-report PDFs must resolve P1. No conclusion about legibility, clipping, bands, colors, section splits or row geometry is made here.

The two recipe changes correctly require a fresh document between separate headless print cases, recreate the requested filter/detail/error state before observer arming, and retain zero-event attempts as rendering-only evidence. They preserve the separate native pre-capture beforeprint observation and exact URL/page mapping. The correction records the observed reload workaround without claiming an independently observed dialog cause. It changes future procedure; it is not retroactive proof for v1/v2.

The previously accepted print publication-race correction and v2 structured-content flag are byte-continuous. Control/helper fingerprint and observer input limits have no change in this final correction or access merge.

## Access owner, grant and consumers

The new `OrganizationAccessGrant` carries the same seven readonly fields as old AuthContext and PersonnelRosterActor. Its membership role union, capability map and Group/Organization scope remain the existing domain shapes. This is a portable type contract, not a new client authority input or runtime provider context. PolicyAuditSink is unchanged.

`src/lib/access/serverPolicy.server.ts` owns the previous feature, governance, identity, authoritative evaluation, denial and route/load functions in one server-only module. Its runtime imports are pure Access helpers and the shared failure function; it imports no DataStore, aggregate delivery context, Locals or provider. The public `index.server.ts` now exports the consumed route/load authorization functions from this owner. Existing durable-limit and membership-cache exports keep their prior mechanics.

The shared evaluator itself is byte-identical to 2e3, as are policy audit shape, request membership projection and provider enforcement. Feature policy keeps lane and Group checks with scalar denial audit details; route policy keeps object capability/scope audit details and its current messages. Identity policy keeps own-user matching and 401 for absent admitted identity. Governance supplies the same no-feature-capability/Organization-scope evaluation without relying on caller grant overrides. Public operations remain async. Removing the public override options preserves actual caller behavior. Organization leave previously supplied its own admitted actor ID as the override; it now uses that same admitted actor directly. The operation still checks target membership ownership and owner-transfer requirements.

Every feature context conversion in Appendix B was inspected. Most replace policy-parameter-derived aliases with the same explicit grant or existing field subset and preserve required/optional audit. Training completion/catalog ports keep their narrow stores and Personnel roster collaborator. Completion read/write/batch implementations are byte-identical; they still authorize before provider effects, resolve current Personnel Group resources and bind reads/writes to admitted orgId. Report/detail/export uses the same admitted grant through TrainingCompletionReadContext and retains its concurrent seven-source load and full-filtered export derivation. No extra waterfall, repeated model pass or broader payload is introduced by this merge.

Reverse reads find no executable import of the deleted policy modules or permissions helper, no remaining executable AuthContext alias, and no consumed reference to the removed generic layout/log-only/Personnel lookup/override APIs. Remaining `policyResourceForPersonnel` names belong to the consumed CRUD callback and feature-owned Calendar functions; they are not imports of the deleted generic helper. HTTP route/load adaptation uses the Access public barrel. Personnel roster actor is an alias of the owned grant, with no changed data-provider runtime. Calendar, Critical Tasks, Onboarding, Notifications, identity preferences, governance and starter-configuration callers retain their operation logic apart from the explicitly inspected Organization leave simplification.

The moved policy tests preserve route denial, scope/capability, audit capture and governance load effects. Replacement adapter tests independently specify allowed/denied Group outcomes, asynchronous feature denial order, scalar audit output, governance without feature grants, self-owned versus peer denial and absent identity. Removed internal input-shape, unused-layout/helper and privilege tests do not conceal an identified retained operation. Passing mocks do not establish database grants/RLS or current native operation success.

## Findings

### F1. P2. Removed pager misses focus recovery when affected count shrinks to one page

Pinned `src/features/training/components/TrainingAffectedSoldiersSection.svelte:62–63` restores focus only when the remembered button is disabled, then clears it. The direct shared consumer `src/lib/components/ui/data-table/data-table-pagination.svelte:15` removes its entire nav when totalPages becomes one. Detail is rederived on every request; `trainingReportsQuery.server.ts:172–173` clamps the requested page to the new totalPages.

A falsifiable failure is a focused enabled Next on a two-or-more-page result, followed by a held page request whose real result has at most 25 affected rows. The server returns page 1 / totalPages 1. The nav and activated button are removed. The detached button retains its former disabled=false property, so this effect does not focus the region even when native removal has left activeElement BODY. This reproduces the user-visible focus-loss class that K1 is meant to repair.

Minimal correction. Recover when the remembered activated pager becomes disconnected as well as disabled, while preserving the active-element guard so a different still-focused user control is not disturbed. Keep the pager reference through held loading and clear it once the displayed result settles. Add one behavioral delayed-result case that shrinks to one page and one user-focus-moved negative case at the component boundary. Fresh native boundary proof remains required. This finding is source-derived; no test or browser reproduction was executed by this reviewer. Root was notified immediately.

### F2. P3. Inherited architecture wording still names deleted AuthContext

Pinned `docs/architecture/ARCHITECTURE.md:76` describes application checks using PermissionContext / AuthContext. Current main deletes AuthContext and owns the portable grant as OrganizationAccessGrant. The statement is now a misleading architecture pointer for an engineer tracing current policy. Minimal correction. Name PermissionContext / OrganizationAccessGrant there, or name the Access server-policy seam. The same document's new D27 paragraph already names that owner, so this is a local wording correction, not a product decision.

This residue is inherited byte-for-byte from ee1 and is outside the current PR's changed path set. It has no runtime effect and is not attributed to Training. Root was notified without editing frozen source or recipes.

No additional actionable source, authorization, performance, export-scope, migration or consumer-collision finding was found in this bounded review.

## Saved checks and release limits

Actual saved v4 receipts report all seven commands exit 0. The test log has **689 files / 6,880 tests**. Check has **0 errors / 0 warnings**. Lint has **15 warnings / 0 errors**. Build completes through adapter-vercel with its recorded optional OpenTelemetry dependency/chunk warnings. Governance reports existing debt and passes regression checks. These are inspected root-run receipts, not reviewer-run commands.

| Saved command | Exit | Actual log | SHA-256 |
|---|---|---|---|
| `npm run format` | 0 | `.verification/1504-v4-format.log` | `eb638c692143bbdb84a89de97c5a57229287a4c367a1d4acbfe97d2a80ad2aa9` |
| `npm run format:check` | 0 | `.verification/1504-v4-format-check.log` | `1f2feae27efb734868160931992e538ea6cfc998bc593fdba1ee04875e3e0c15` |
| `npm run lint` | 0 | `.verification/1504-v4-lint.log` | `a4864f93caaa1c41c520fb657ee8fd02a509b34f5e10722c086d65c01369997d` |
| `npm run governance:check` | 0 | `.verification/1504-v4-governance-check.log` | `fa79f6b43cef1dbb815697ce6fff2144c2105ce9b695cd76d6e3f72f784bc398` |
| `npm run check` | 0 | `.verification/1504-v4-check.log` | `f8ae14b6c8ccf1cb89ee4a5d9d74406bdbe4708b1c5853325f456d8bcad1f770` |
| `npm run test -- --maxWorkers=4` | 0 | `.verification/1504-v4-test.log` | `f365b339ffb5183304d87971f21f81b33ff023f2542496b0c97e6a5eebc11409` |
| `npm run build` | 0 | `.verification/1504-v4-build.log` | `bdd235cfbc7dc1173d9771e573abbb5f3c1ba553e8f7eb6053fce4ad9f454729` |

The Training goal migration is unchanged at **484 bytes**, SHA-256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`; all four goal regression SQL files are also byte-identical to 2e3. The current main access wave changes no SQL or UI file. Earlier source/provider reasoning remains applicable, but this lane does not independently run SQL or verify hosted database application.

Current live acceptance is pending. Root's fresh run name is final-v3 on worker 1; it was launching with source frozen when this review was assigned. Its expanded packaged artifacts and final exact restoration/cleanup are not available to this source report. A future artifact acceptance must bind the corrected source pin, exact candidate/session, native held boundary paging both directions, retained radios/filter/Retry focus, user-moved-focus guard and F1 correction/disposition, actual no-applicable one-landscape-page PDF, long-report content and visual review, native invocation counts before capture, workbook/source continuity and affected current access smoke. It must preserve failures and deliberate HTTP/provider proof as separate evidence classes.

Prior v1 retains the absent PDF/Retry BODY failures, two overwritten captures, clipped direct API tails and retained-consumer/actor limits. Prior v2 retains ten PDFs, seven beforeprint=1 invocations versus three beforeprint=0 rendering-only attempts, 31 PDF pages versus 33 page PNGs, the extra portrait/textless page, boundary BODY focus, exact A/B provider restoration and newly added browser keys followed by private-profile destruction. None is retroactively fixed by this source change.

The PR contains a migration. Operator remote application/merge authority remains its existing boundary. This report does not authorize deployment or any remote database action, and does not certify hosted exact-head CI/review or readiness to undraft/publish/merge. Source F1 needs correction or a concrete disposition before calling this final source acceptance clean.

## Appendix A. Complete current PR per-file byte and coverage census

All hashes are SHA-256. R means the exact head bytes or deletion state match the complete earlier 2e3 review. V means the changed head was separately reviewed in the pinned v2 source lane and is unchanged since 580c24fa. F means fresh final correction inspection here. M means fresh access-merge overlap inspection here. A1/A2 mean the exact added archive bytes have the separate expanded v1/v2 reviews above. These are source/artifact coverage dispositions, not fresh live PASS labels.

| Status | Current changed path | Current base bytes / hash | Reviewed head bytes / hash | Coverage |
|---|---|---|---|---|
| M | `.agents/skills/verify-trooptotask/SKILL.md` | 52953 / `a0628bd0843689afc7f4c90f629ce46e6118aaa7357ed5f60c53d4321c7453be` | 55189 / `471508b5d66002281f1ef45d068c3ba5b936b2e3be08deaba1d6d0ff3ffaaf0a` | F |
| M | `.agents/skills/verify-trooptotask/features/critical-tasks-completions-readiness.md` | 16674 / `33c71e2ea8c4135b77da56f408543432010804ee7a199d8b1451f4b0b4eea450` | 16679 / `5d4834c8e763b412e951ca9ea617c0b120515612a274522c89ad6ec05e779ebc` | R |
| M | `.agents/skills/verify-trooptotask/features/organization-settings-destruction.md` | 31526 / `38de35bee1fdc6f677f0981507c572988f2d76dee394c5e5e6e4b1b95b466035` | 32945 / `8305c969f67490db2998a29051159b27afb7541a15628c997fd12f9bf88d3c94` | R |
| M | `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | 25063 / `a6d10e4762cc94f7597ec568bd979c7fae27dfa0c8581560e802f838c4920c83` | 31288 / `1bac6e9b0d338f7d31a68c8e18cb66372bfcdfc59bf2d7cbf2ab2e9af72f28bf` | F |
| M | `.agents/skills/verify-trooptotask/helpers/control.mjs` | 89803 / `e029f4c423d1df5b338ef426010f7944eaaf4fdb9246f47e8b364514bc60e18d` | 90530 / `d426c720af9eed040bbd4827352303e471c576792cf5adfecdd7f02a46af1bda` | R |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.mjs` | absent | 1053 / `05885ab449dc9b15805f159896234890762e2b25770c9e708b675e09a5db0489` | R |
| A | `.agents/skills/verify-trooptotask/helpers/print-observation.test.mjs` | absent | 1743 / `e9a3c9bb5c9ce486d200beae84e7b1a05f4cfa6dd867cc5d891d904c53b2b509` | R |
| M | `.agents/skills/verify-trooptotask/helpers/settings-request.mjs` | 2067 / `ee3ec1d099288bc95b06fade2045d7d0eccd0f1f950f4bce139a1eebb176d4ec` | 2102 / `3542f8b4e90a8204f42ca1d1e790e732b81a15325bd26d0c49a0ddb46b311956` | R |
| M | `CONTEXT.md` | 10727 / `c803c99074f13a9a5fdfa7f55eb7cb423d32ba794678f8c12114f21e37686265` | 11259 / `4637eb30bff5deb8a4b8e52e368787254bd4ac81849349af22fd4d984681534d` | R |
| M | `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` | 80646 / `1c6e630e78bad166f2f000fc8436d96b92078d890caed95415fca5c664f1a600` | 81037 / `9ec1b5604af14618c4c8026a9f07cc45e17d405db964dc116c8bfc18e82e8455` | M |
| M | `docs/architecture/CURRENT_OWNERSHIP.md` | 105803 / `dfd60d28f2f42e8227198b4c3e141f01cff40df11c187300edaa22bba4885c74` | 107351 / `693e719e5f5ba57f3a24e12e801099dc4ea07cd8c1c71d35dab06e563bad78cd` | M |
| M | `docs/architecture/MODULE_CONVENTIONS.md` | 41230 / `e36418312b169e977641a8ce57a8cdc615301f4da8ce2e5b36a775fc078a2c52` | 41230 / `dc323e853c6a32339fb9ca3d6be155c553f8f953ecd8ff277d7203043d67c6bb` | R |
| M | `docs/component-catalog.md` | 80448 / `a1b9bdee11048117962a27fe63549386aa2440bb8260bf7bd37e84cc885a5dde` | 86370 / `270034c569133007691d6a0a3fc9327630b73cbd38a059bf03665ddf40ae954f` | R |
| M | `docs/domain/retained-feature-rules.md` | 3539 / `4973a1afd8dbc0e5828913e9943c6dc044a43cff4e27cada921eea2c13306998` | 8048 / `d83fde06bb80a92c854c64ba6c4718980ce406e7236b6e28c10541db9fdfc99c` | R |
| A | `docs/verification/training-reports-1501/acceptance.md` | absent | 11784 / `06b6904e31ed613c9e832826bc5d02bfadfd68241404132e1bcb18688692644a` | R |
| A | `docs/verification/training-reports-1501/baseline.tar.gz` | absent | 281614 / `0b2f279ddc5b7f22b849cfdb35d6617e9a09c3bca82b369077c7530d6a9a631a` | R |
| A | `docs/verification/training-reports-1501/final.tar.gz` | absent | 537699 / `72ebffdbd185f85f7af876c428c5f127d94320cc09729d83411bec34a9b2ff4a` | R |
| A | `docs/verification/training-reports-1501/validation.tar.gz` | absent | 235881 / `73af61b577db8e4d8144baaaa1d5842fb9afcef89c4c3b1fc7439de7cd727df6` | R |
| A | `docs/verification/training-reports-1502/acceptance.md` | absent | 12101 / `a20f2a7430722f08c336079316cd58705f02306e1760bb76e3533bd2da246049` | R |
| A | `docs/verification/training-reports-1502/baseline.tar.gz` | absent | 182877 / `3f5eed79100b3747453564f95b366eaf66e3c48c7ab1fd72384ddce456c3da2f` | R |
| A | `docs/verification/training-reports-1502/final.tar.gz` | absent | 857125 / `7587454d049dcd8397598fb5537d36410df82e2689524cd1d0d4dd5f43f12626` | R |
| A | `docs/verification/training-reports-1502/validation.tar.gz` | absent | 94200 / `ccc30126735e7e9801314261127e293ae7b336aef96473a4270a9825b13e0df2` | R |
| A | `docs/verification/training-reports-1503/acceptance.md` | absent | 13175 / `afe547eb816c30295b5e4ae21b70a3717a10fa08ede3487ca92e74372b387d8f` | R |
| A | `docs/verification/training-reports-1503/baseline.tar.gz` | absent | 1704184 / `fa83957d99b581bbb93df8b4337f139d827d8df9dfb3e5a8524c099248dee4c9` | R |
| A | `docs/verification/training-reports-1503/final-integration-v8.tar.gz` | absent | 4770012 / `0469994bbce1b9e38229573a55c2f8b704f0f5831783232156b3528a98d4836b` | R |
| A | `docs/verification/training-reports-1503/final-v7.tar.gz` | absent | 16701741 / `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200` | R |
| A | `docs/verification/training-reports-1503/independent-acceptance.md` | absent | 57300 / `cd3e54b63594d997c49af701ebaf306841d95f2b253f7813e6d65b417444dd24` | R |
| A | `docs/verification/training-reports-1503/validation-v8.tar.gz` | absent | 3038956 / `c59b77f146140d46f2879a83e9d3bbf3f97470a7abd9574b4a9e56319995402e` | R |
| A | `docs/verification/training-reports-1503/visual-failure-v2.tar.gz` | absent | 4546927 / `506cdc2433025c1beebec1c8c9cb8e5d779db718498280f604cfd0281c266a5f` | R |
| A | `docs/verification/training-reports-1503/visual-failure-v3.tar.gz` | absent | 3567677 / `973f3cb2fd148afc95784530a38e902a1f0eb16fee3630a3478f4a2c88410299` | R |
| A | `docs/verification/training-reports-1503/visual-failure-v4.tar.gz` | absent | 2911869 / `bf1a94039ba6d48bb56a38ec4c5f1c3221a1746a3d70834221849a45a5403bc7` | R |
| A | `docs/verification/training-reports-1503/visual-failure-v5.tar.gz` | absent | 1696296 / `f316ce2e80ac8f038530c2cf1093b0ac834483face74caa9fb24566dca018d8b` | R |
| A | `docs/verification/training-reports-1503/visual-failure.tar.gz` | absent | 6591417 / `04d94812ab5c1543f3fe783f64dc9a981bae1b9bcdb02cdd15e39130ea3d0925` | R |
| A | `docs/verification/training-reports-1503/visual-unavailable-v6.tar.gz` | absent | 254498 / `8e44e2ba1a5005c74b977816ac1c0e6478fa13e3f2e3e162f99855dcc1ae6ff5` | R |
| A | `docs/verification/training-reports-1504/baseline-v1.tar.gz` | absent | 3741607 / `a29ca4b5220fdd1c500a59a674669bcce310130598a27d3bca419f03e11a3896` | R |
| A | `docs/verification/training-reports-1504/final-attempt-v1.tar.gz` | absent | 8194402 / `0347ab3ccd6e78bc303fe65c8171126e9b0b98d4e9bf108b9cdd4ad33ab85104` | A1 |
| A | `docs/verification/training-reports-1504/final-attempt-v2.tar.gz` | absent | 4659392 / `a7eebee6b56f22187bc73da4b00b07f75f74bae655bd3e65d39b9ba2c72a7c05` | A2 |
| M | `scripts/ci/database.py` | 32516 / `4c5bd8654dbe93baf53e8549abb63d564cfc3b8452b0f1566a858f07b8b8b8ac` | 32698 / `67189f0a4470552476e2b1899a564222f753e66e4c4a556eb4efeece5caab5d1` | R |
| M | `scripts/module-boundaries.json` | 15684 / `77b16eff7296c62c1bc187cd27f3d1aa6785043cc4ee70cc08b48d4bac9ab3e2` | 15700 / `5da0bbe281179860751db7d0f41dce3e044dc514f0e94d5dfeb22ac04abcfe45` | M |
| M | `scripts/verification/daemon.mjs` | 12573 / `0ba956c40b2674c92463fecf985640336fd4caa699b40fe36b3a8b0488e7196c` | 12825 / `ce95182391fda1948594697e8d96bf60e44d7fae04f89f87b143aa4f63fc3bcf` | V |
| A | `scripts/verification/print-capture.mjs` | absent | 14213 / `820e041e5dcab48d98f119cc66dc12cd6710a1291960e99fdce9634412ce7f73` | R |
| A | `scripts/verification/print-capture.test.mjs` | absent | 16744 / `2073c15b6ccd1e454178616dac3b045ddf1a45b0c6452604a06bc54a84770a3c` | R |
| M | `src/app.css` | 11743 / `1189f1a5175b09348c797927c63255cc081127ed9074a082ab3b3dd780933380` | 14610 / `8536b4f70d589435a87181e445ab5a4d5e607e8351d855b049eade028b7683a8` | F |
| M | `src/features/app-shell/components/AppShellHeader.svelte` | 25561 / `bc9ff165ccb54ab45a1d2fe4e6f87c5dff5cbb41c43f04b749e7726e12655f7d` | 25591 / `26bd934d4a9a592ed42c9caf165cd8ae4c00b9df410c1dd12dadbff1117ad4f6` | R |
| M | `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts` | 26177 / `4e000f5138d36ed1f2b4602c29207f7f756c538b3cad0787087727bf3235ac81` | 26235 / `5e982bd1a4f547405009c22444b291259f64744b929007ac4eb5901a79a21a8a` | R |
| M | `src/features/organization/PoliciesSettingsPage.svelte` | 2796 / `dc3f74c6a0bdeef25caec261fc365383a59ef82a0b60bc76a255d409cb8b1a71` | 3806 / `6387821b225c4dc09f17961d45991d1c7f0b6d9ec0117514f4cf99b57adf9a33` | R |
| M | `src/features/organization/PoliciesSettingsSection.svelte` | 3805 / `0566cd2a886032946a7a8d17f2ed354fe69c177f4a5615876e0cc5215a1f01b4` | 5926 / `0a3013074eafa30fc05cc77bafecaec607d0b494e9412904f0e411a588565c4e` | R |
| M | `src/features/organization/policiesSettings.ts` | 1139 / `7656b04954ba08062e259e429cc89310e5e0bded34284bf65d74566e8227b6f3` | 1433 / `cb71f5ee1514d916ad50adaa0dc88158f15bd2de4eeb27a1256a93e60e37fa1d` | R |
| M | `src/features/organization/policiesSettingsState.svelte.test.ts` | 895 / `5f2779f82f58f8efc2e8b40fb7fe258b3ca5dc942f4a1bc9245509473cdc3969` | 995 / `24fdf5cbddc67e146412104144f4298837e1e7b3f86a5a2094590c6c53aef778` | R |
| M | `src/features/organization/policiesSettingsState.svelte.ts` | 2880 / `f818a841b6a9c8e8f17accd5960d26115f47884edd911139b947f1fd62aa3648` | 3836 / `e6d6a86506216a2bebb312b7b8b872ff9b5bbf638072f3937f8311e9b123295e` | R |
| M | `src/features/organization/policiesSettingsTypes.ts` | 734 / `cb36f6765b63e5427e897a96807e313f3781a5915f2103f5bf3a6aa2aab9b737` | 835 / `12c2b6158b1febe38fb9be7bdc335ca71c74b0d4626a7ccbf39d5328a0b81531` | R |
| M | `src/features/organization/policy.server.test.ts` | 6175 / `115d3778e56c8c62f289e50953b86d665f160350b2198fc9bc1af34c23551982` | 7060 / `0aeb4a5034df40434f32b0bcebc878a944496317c82f96cd14f69841329abb43` | R |
| M | `src/features/organization/policy.server.ts` | 2976 / `728eca547ae9ab8000b35044027a358671044b5a0873d34cce3eaf097a7d4868` | 3715 / `f91bbeae6ba9cd95f2f96d6ed1e674130770bb510e03bc08495ae8b9d1129147` | M |
| M | `src/features/organization/policyConstraints.ts` | 281 / `4b68ccb8e75061f74f405de2c1f3f2a01dab9f93034c9d641931904cd60febe3` | 438 / `3277ff269a8b8fa5abc28d1823306d665771c77ccbf5d3b194a733c47b5c459c` | R |
| M | `src/features/organization/policyProvider.server.test.ts` | 4919 / `ef1bb4692e4571a48032040d664c6f52e41d437ac7d2ce1ba7dfde83317b86fc` | 5262 / `b5fb2466ea43355975c8eedf995c5360a6930b0b952d5fecd482e3fdd1dc3751` | R |
| M | `src/features/organization/rawExport.server.test.ts` | 6607 / `1f8cef727e6e061c2f7d8c2efefed4e8952ae42a1e2d300ffc00a3130b255ded` | 6645 / `fcf0e931ef9285590c8ff77750e033a0631fa2956cbad5cf5498e7ceab63e1cb` | R |
| M | `src/features/organization/rawExport.server.ts` | 1505 / `14be4c6a627f64e7f03a5fa774660a87c7b3e90470c0a86c29d5893259cb4261` | 1537 / `24d2c7e8f32f9ff7203ada500cb3fc73ecad4f2cde67d768dbd10364b33980f1` | R |
| M | `src/features/organization/settingsProvider.server.test.ts` | 5618 / `fba1904b7c76697cc19f5c5febc0aae7d3cd082583d8cd5873c283f5f368ca0b` | 6480 / `b23aa3607a1042ae080dba4e77efb2a0b5f24392f79d3cefe7d50394d2cce91b` | R |
| M | `src/features/organization/settingsProvider.server.ts` | 2858 / `60f0eb4fb87232318353fefcd67bd24964dae382db8882f643c259c119ab4270` | 3494 / `db5e7cf7a33b2071d222475a3700547b61dbc45da9d7936fbc84250778536c92` | R |
| M | `src/features/organization/settingsTypes.ts` | 1491 / `e65cdd4e7dc6dd9e4cfd1c681fc323a3929e0e5502e52343f707922913f5c550` | 1907 / `d8122efeaac05752409487c67d598639c9ecf7382578d19b7c5849ab0d01e92b` | R |
| A | `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | absent | 5861 / `8e882b5962e44b20fd4603a1e205403119cafdd9130dfefc700de33296d91c7d` | F |
| A | `src/features/training/components/TrainingFocusSection.svelte` | absent | 2236 / `49ead5898bcbb10cdbd8d7e4f6e88191b0144a0557f44a55989beb4d1aa73ead` | R |
| M | `src/features/training/components/TrainingReportsPage.svelte` | 28371 / `a95b89c1101209258132b08555296486221f3754678a792714dd990781d3ab6e` | 23411 / `702704e314e66ac4e8798b5b76fd3d9a9edaf260e680a8a73f3c273ec8e14dde` | V |
| M | `src/features/training/components/TrainingReportsPage.test.ts` | 12129 / `e94efff64fbdb3558828fabfc9d140220c17478a4c97a4d7fd85428e0c56a4f6` | 16054 / `1e7b5974b39cb6ab75b6f13632e1dfff4af38b7a0a486d7f76886f3a57dc9097` | F |
| A | `src/features/training/components/TrainingTypeRiskSection.svelte` | absent | 2759 / `33dee409eaeed3bc5d8ecabcff388b86ec79a7c4aa0af443e65cf322c2590d56` | R |
| M | `src/features/training/contracts.ts` | 6393 / `74b0222f2333616d6214b65c188114fa1f9251322260cbe1a37e81a1dea31393` | 7148 / `7a9d7f410e94e218b4dc0fe61c7dc2f863e8e4dce53f0381962454617097c821` | R |
| M | `src/features/training/index.server.ts` | 1806 / `dae597605c78ab6d66df284ac3d4f8806da3ad6c4ae3d7d27e2d6ed122e44003` | 1808 / `40b0946bff46984dc7d44f986d35498ead42dbfee78c4c628ca692c87922ab14` | R |
| M | `src/features/training/index.ts` | 1838 / `22814f5177624d0ce514bf05a77c6910d95e6a4e24eb6e8750b03b3604070566` | 1944 / `3c493ea7b65d8478564a8f2c80b5f347f41fb4f0909cc76e626811de113c4ebb` | R |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.test.ts` | absent | 10297 / `9c89254c232bb20c83b75a809b7f6b5821f00666b168ee1bb5f209d884feeb8c` | R |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.ts` | absent | 6735 / `cec6544443d09a1a5d61a06b0b0a6bb1bf5db48fff7a25a0dac36e3ea239105d` | R |
| D | `src/features/training/read-model/trainingReportScreenModel.test.ts` | 7072 / `0833c6639b512d45a127e502813f8b2cd8be73ec853aa4a8d4bbc499a4468d2b` | absent | R |
| D | `src/features/training/read-model/trainingReportScreenModel.ts` | 11919 / `c4a5088e9f71f97f51ad161e95c59a79e491384e90b799c80c2fbf114fbf42f3` | absent | R |
| M | `src/features/training/server/trainingReportsQuery.server.test.ts` | 21143 / `ae7296e37a6fe35980af78c8143b19c3e80006d3a993eea862507557fa18a166` | 16694 / `a255269cc00b9589b8ee66545d2dde546f8262e3f3459ac6cf3015db5e6c4c92` | R |
| M | `src/features/training/server/trainingReportsQuery.server.ts` | 8819 / `9104e1c4bbf89dbb026e35b3c6eaf45ebb18141eef5fc4cdf97f09c6b81ea815` | 7878 / `79b6574e127b89ddad76ed7a0a05dfac26ef2a81ce550d537eab4f0ded05449a` | R |
| A | `src/features/training/utils/briefingFilterLabels.ts` | absent | 1621 / `884489a6cc909c9438bcfc7db9c349f8f704a9f2a527fca8ede9065ce9917b7c` | R |
| A | `src/features/training/utils/briefingReportInput.test.ts` | absent | 2551 / `5aac480a55e0e96837ad4782e56cebbecb9b5b257188bbeb1b430ec59b52084f` | R |
| A | `src/features/training/utils/briefingReportInput.ts` | absent | 3530 / `5b3c49540eb8591151213eaa2be50506a7dc60b78b17dfbc4e7df7a6e6226e9b` | R |
| M | `src/features/training/utils/reportCalculations.test.ts` | 17377 / `63451c4a635c45a0c86174d2c93600f4942c8da2a9dfc45f8e678269a471f828` | 2714 / `74916a25f2e7c32a85b90892a465bfa384891625bbeecc55e7baf54bba792dc2` | R |
| M | `src/features/training/utils/reportCalculations.ts` | 8284 / `57727e42999f235a36c5d7f9eda331cd7b3c22168a56ab78349ceea290cb6b92` | 949 / `2839a3c388902c378985251eb859f8b34447b0236c2f54648b4f6da6310ecef6` | R |
| A | `src/features/training/utils/trainingBriefing.test.ts` | absent | 42695 / `51954b8c21e2e394e7d4007ccc32747e862986d38f65cfaeca5158cd6ad1e184` | R |
| A | `src/features/training/utils/trainingBriefing.ts` | absent | 26284 / `fb6bf3af5c5fd4e4287c8a159fda126eb6fe3247853c02544effc08eb33c6863` | R |
| A | `src/features/training/utils/trainingBriefing.types.ts` | absent | 5125 / `2b6a3b651e78c99f7110c6ffa6a51b51467fc16b79c69311ba2eda30150f94af` | R |
| D | `src/features/training/utils/trainingReportWorkbook.test.ts` | 3144 / `ffd36f90d9c5483a95a8df19a61fdcfaf68a6c308d2ca2302b2d86ac7a1fb4d3` | absent | R |
| M | `src/features/training/utils/trainingReportWorkbook.ts` | 1783 / `3e382722d054c5ff61f1ff7f4db5adeb8c6e2afe128c03710b63e031cc136946` | 6047 / `84ee4e8af3721dce0e1e6fcc981b700ec8684148f6e07a53cb2eb1170ab9a2ff` | R |
| M | `src/features/training/utils/trainingStatus.test.ts` | 10705 / `9c953007ef089524e28bdcf3cd745a8d83f77b760a20c197aaaa12d088364627` | 13373 / `a7f081e6ea5d1878f309bf7b39bbf76ad2ff2acd644646942b9a3174500e39f3` | R |
| M | `src/features/training/utils/trainingStatus.ts` | 7174 / `7efe4a383d5d16256d0e3655cf530f3016f3f2e4fc269e495438ef49377010ec` | 7205 / `ef0ae1f4efdf721a80bf83107c077567bc39369779d87d47f73cba13e92b8cd6` | R |
| M | `src/lib/components/BannerStack.svelte` | 754 / `a6861aad86c4add89ac138dbf336a7fa846977f312c10e3b3704fee459295e8f` | 772 / `9c1f03e3aa25a60e9d8ee5704523a973a4030ed4a34a6308d295ea84f798cc63` | R |
| M | `src/lib/components/ui/readiness-band/ReadinessBand.test.ts` | 1820 / `1c71ada3cae8d2e3521e6bbb1e64cd99e3bbeae9717f35bffd74189dc5253e49` | 2477 / `8cfbe81c63d4678cafb43a25a253424e55409c5b3b29ddc891292853e30afe75` | R |
| M | `src/lib/components/ui/readiness-band/index.ts` | 455 / `8c928f068c118f222c95d3f050989478114fd7c7f2ff04bfb376be862b53f26f` | 503 / `fbc42884b8a9e0edb6c4a57ca8c8fa6805a9724233587c8d6546e109f127a35e` | R |
| M | `src/lib/components/ui/readiness-band/readiness-band-cell.svelte` | 2236 / `c145475e6a0ca89d5cbee723ed47f5eb3d598cb5a08fc9d8844676d6fc00d496` | 4300 / `0d18beafb2e765306a34296cd7c7f03ac8632aabd6062541cd58cb3d5bc56e8e` | R |
| M | `src/lib/components/ui/readiness-band/readiness-band-legend.svelte` | 1208 / `2a02249552a4f5a08761832de72165c48f1b62f49cd7f7db42c8a05ca91e5bfe` | 1532 / `5fe61e364f174547d6c47b6baae963d41b583584d77da2155076f228aff4b3a2` | R |
| M | `src/lib/components/ui/readiness-band/readiness-band-swatch.svelte` | 1756 / `54d0ffe80e6af71a92d74b46a4f7cae09e86a22a62b28e22b527241915ac07b7` | 2743 / `44df84a36ea4f58199c46ee5b63428c70e535da0cc49bd0104bf32851b7b2205` | R |
| M | `src/lib/components/ui/readiness-band/types.ts` | 920 / `cb536e3075f1f2ab359f2f68f5fc5f12a354b370a9c660146cf5b9f0a68dd155` | 1462 / `ad94ec16e0145657a4169005940e55f467668334dda4c9b8f688f52a3280bc42` | R |
| A | `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | absent | 10377 / `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` | R |
| M | `src/lib/components/ui/report-chart/index.ts` | 155 / `ab18d2c16e8011ba6fa85f0991b2191041df646a7775c0ef06066394cdc844d9` | 352 / `1092440911915989fcd94b431998761d4f1d9659417fea254a72087be3b69230` | R |
| M | `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | 1539 / `6bf4a0bda37b67f2332ee38a07ce706070c47e4ed70e592969391b9670306d42` | 2752 / `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` | R |
| A | `src/lib/components/ui/toggle-group/index.ts` | absent | 159 / `5ad8938622bce94f5d3611adbe7e13da8f5cd176f56d3eadeb6a8c8eaa334103` | R |
| A | `src/lib/components/ui/toggle-group/toggle-group-item.svelte` | absent | 958 / `cbde5673054945e9ca4e5d6a588ab9dacffabf38fd4e4d05d3f966165cc82b27` | R |
| A | `src/lib/components/ui/toggle-group/toggle-group.svelte` | absent | 1115 / `1a8ffb1f16373ccc2ad720aaa90e9e44012ba572875d0a544b184f7df868b900` | R |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-actions.svelte` | 5116 / `1f7432f57e778333676a14a9ef48e30f258d3a2e9b7a368d1e6e3187e8c3ceb2` | 5146 / `9edbf5d1eb0a05358266386e856f4e0990cf6b3f3291b70ffd24ca399a179af3` | R |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-select.svelte` | 914 / `54bdec836634a3ecf7c238203cff7db64b92aa445902214f346f18eafb3df394` | 1004 / `d533efc217a5e4e710dbe354f293c8728c13b8db721a90252b632fff631682cb` | R |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar.svelte` | 1895 / `e10d9c435f6b9d8c57137df59c1b8e095afb2867218b191a18945add5b4cf01a` | 2149 / `9c5e79b4f5adc62580aaa6f619f8a823f93e22158a4265ef0ad8bf30a73e6d96` | R |
| M | `src/lib/domain/readinessRollup.ts` | 11082 / `76a223f71a885938a75aaa8bbe83622c6ec8a8496e602a72a3a321c8db413ba4` | 6983 / `737669f8b54d8df5422b0107f6d76e8fbb8fe107980e379e6f95db6cdf985058` | R |
| M | `src/lib/server/adapters/inMemory.ts` | 50261 / `16d8b8ea2947ecf2f9906e2400f641a888a21f06131dfa4c5205c1e4e842d292` | 50952 / `59789a5fd371ad5d525ebced9e5152ead8156f571f5d7a6c27772255a990625a` | M |
| M | `src/routes/org/[orgId]/api/organization/settings/server.test.ts` | 842 / `214c686ad90adac8d99bfbf3125c4a5b1407b6adaab95d4a06d8df5a5f4e8907` | 1685 / `8f23cf37ededa97e0b0d061177d33dab3e12c651e8ae1505a83581ae01838f47` | R |
| M | `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.test.ts` | 36496 / `af58b0602fcfc38b5f3a76dcbd946ff9999750996d06a2aa621579d54b063162` | 36536 / `d693459f995e8ae7f9124c6d5ef92b5ab3b7f9b3b69221cfdef3f7fba49bec1b` | R |
| M | `src/routes/org/[orgId]/api/training-reports/+server.ts` | 976 / `f98a2e0ef9d1820615c04ed012589b285976a0634ff56e201ce3542dbc69e2d8` | 852 / `a4c0df9f571653953281b2acf849ffacdc5eac128c398ac46fd4b1e215bb3467` | R |
| M | `src/routes/org/[orgId]/api/training-reports/detail/+server.ts` | 1005 / `c0085747eca55fa9b453836add1d3e641033199fe187ecf4f1e5267eb8ce202f` | 987 / `06bd97fe5143520927805bb32d55189dc49e3475a867a9d65ca32a45a1de1324` | R |
| M | `src/routes/org/[orgId]/api/training-reports/export/+server.ts` | 1106 / `1aacec7d8494792cfa096c35f2c073a8b9fa47b18fa3deda5aa0aaba93c55249` | 928 / `87411f0be57744195b120f322c5a56f6c3a2b3e0286ab34ed93d2f731d230f87` | R |
| D | `src/routes/org/[orgId]/api/training-reports/export/server.test.ts` | 2655 / `6a19175bf802fece45ef976e5b7e055ce23c464e347a0734173b6754cbfb01ec` | absent | R |
| M | `src/routes/org/[orgId]/api/training-reports/reportInput.ts` | 2462 / `8db44d833ad26609425641798331cc23b161af371f7345647aea966adc33ff0b` | 1981 / `009576da7f537c6f19f46d534af1049a42a0cc449e777ed4ce545dfab6c0e87d` | R |
| M | `src/routes/org/[orgId]/api/training-reports/server.test.ts` | 7225 / `41d00148ce2990060b85485b002a3f246f3804e985b48af8fc9d08f5416dbf69` | 6284 / `d7be28cccb4ce0296dda348a8022af6bc0a8ba2d84de78f64a29dbd351efc2de` | R |
| M | `src/routes/org/[orgId]/settings/policies/page.svelte.test.ts` | 7968 / `ef65c0b53131c3b1a231fb29c364ffc7e7d14a88e700f7d18a984c79d3fabe01` | 9908 / `de92036ae278aa3b98946d85eb37982d58f6e0f21f29a5f3ec532eb83f588866` | R |
| M | `src/routes/org/[orgId]/training/+layout.server.ts` | 898 / `717f8c9370a0a9f35af09875786b496fa54a4535c2a004eb827f28ba3fdf7bec` | 1115 / `21cf76fda470075596c65ff58bc6a8a446daf495e77f166bd96b7f55d7411f87` | R |
| A | `src/routes/org/[orgId]/training/layout.server.test.ts` | absent | 2326 / `8190ea86c9c49900ded8bdc57b1020d19f212906fbe5f97b74a0bc000ca575f3` | R |
| M | `src/routes/org/[orgId]/training/reports/+page.server.ts` | 1483 / `e2d5ff4203667dd3018b4fcdc58bcfb02b7bddedff374854577068d89a11e15a` | 1489 / `e7e6d2836201e64b50178082b5d355b1b4131006de77bb59ce1791a2345c1d2d` | R |
| M | `src/routes/org/[orgId]/training/reports/+page.svelte` | 2971 / `69585013c6574e861944d4f53bbc9e52fe86785b931312d3ac1d48e00ffcc24e` | 402 / `50375452496d62329f492c92d10a38d037105a517a61cb61e525ed66c9529eb1` | R |
| A | `src/routes/org/[orgId]/training/reports/page.server.test.ts` | absent | 2718 / `aeb04d05b65435943fac1d3cbb0c0912bd61ceae8fc684d89a5efa4511c6e947` | R |
| M | `src/routes/org/[orgId]/training/reports/training-reports-page.svelte.test.ts` | 6315 / `454e26ffdecec74dade0f0b9bd85823a08e86af94735d3dae3ab5995086022a3` | 1948 / `7b9fdf08b9557ffeccb6d5d366dbc13ff439a23f374d53a1b6da28cacde8331a` | R |
| M | `supabase/migration-tests/account_preferences_scope_before.sql` | 5876 / `7438cee558af41c21f4138459b09a3a8bd326c73e7503c233ef8449a6ef2eb37` | 5912 / `140eeeb708d3413fe84042bcf0b9cadf917f29c582c929f08be1d211bf170ce5` | R |
| M | `supabase/migration-tests/calendar_unassigned_populated_after.sql` | 4362 / `1d48175a01df6c1ba711e12eaa2433f0d2a577ebf63e4b5642fc2e946b317b1a` | 4398 / `188f6f22c4f4e64041e4432191df15c0448283dd43a787aefa53f2e5a8d6e24e` | R |
| M | `supabase/migration-tests/critical_task_archive_retention_before.sql` | 5463 / `13767461b3688dbe8a5082ccf11f46739f7f76b29c2f6b7d2fbdd9e3f3228262` | 5499 / `5784480a5ec4ce29e5a0184e199c4d3dccb7a0e11851f7ad48f710efac55d2e4` | R |
| M | `supabase/migration-tests/critical_tasks_populated_after.sql` | 3578 / `139c6da432616d1cedc57ec1e7ddd7a5cc722d63b6a74aab014b56069709b2b2` | 3614 / `7bba26199cf6657413f432eeaec45cbc923d13d05bf4c178904320da0d320b8a` | R |
| M | `supabase/migration-tests/deletion_request_cancellation_before.sql` | 11293 / `0d143c23e8fd9587aa35e636ce6da520340067e141f7693d8a5a19e707c776fd` | 11329 / `be3d5381caa3c55c1a6173b82340156ebc8988fcac860cb4f82740e4fb446c5c` | R |
| M | `supabase/migration-tests/organization_file_upload_before.sql` | 3453 / `d6988a65ae71d056af2afa9df708845accb829c5d9402e8d112d7c902f3e1ab9` | 3489 / `ba66b3617a2d6a92ca00d2950fd9b30ae7872eb65e0293cc015a4ba21a3a139e` | R |
| M | `supabase/migration-tests/organization_file_upload_contract.sql` | 12495 / `37e9335a3721aea826ffcb4349d73b460f7cbf2d731c34d8c89a3db4abc66055` | 12531 / `b577e25a5d1534a29dd2bacd10a646c48cd762c98cff943ceaed30dcdfe48619` | R |
| M | `supabase/migration-tests/organization_storage_cleanup_before.sql` | 8646 / `4507f65470cc27d96dec560e57ab8d28379389b697f7fa57008386330aa31eec` | 8682 / `d84ef0838e68cccda4cf04770bc77fec34b2d8675d08cf9e57b8be7a24dc206e` | R |
| M | `supabase/migration-tests/organization_storage_cleanup_contract.sql` | 17809 / `ad1ddb462ebfd921daf4c359411ff223c3122610aa17b9c3ef118b085cb2ba15` | 17845 / `c95a5f1b12952f5feb4bc80b782f4ecab72f48aefaa961891e4a9305ff088ba6` | R |
| M | `supabase/migration-tests/personnel_counseling_file_populated_after.sql` | 6166 / `b4066c8c0bb08180fba72281499e17c0f21f1cfdd79fb9912598ce3ef0074309` | 6202 / `ee8a49873cfe8dc1e376265dfc0c949cc12458208e9431c4f52f7eee7dc5a36b` | R |
| M | `supabase/migration-tests/personnel_extended_info_populated_after.sql` | 3154 / `979dc35437b0fd337ad5555ede774f12e9dfeb11ad4bdd70fc76d7e5ea82a2c6` | 3190 / `b29adbc1a5b198b9b1254264c549bfc67cb8d217d723cf04729919e4a4e122fd` | R |
| M | `supabase/migration-tests/personnel_unassigned_populated_after.sql` | 3075 / `ca86b47ef92e33773ed1686d46eb5e5b95ef484940dfc84e8403b1d1b556ff3a` | 3111 / `86cd11035201bd536e6cf9a06d2da4e2ad7dfbb6e37b247773885671e8f4e7b7` | R |
| M | `supabase/migration-tests/platform_membership_before.sql` | 2925 / `0b475c25ee9ec359836cee983da62c4398842d77790449307cdb4e96bf384e94` | 2961 / `af77afdf7345a31344e2575148f74f52cc725e9bb3bad2ffa2124c46ba3559ea` | R |
| M | `supabase/migration-tests/rating_scheme_populated_after.sql` | 3928 / `48a6791a98461374bb03c128004cd3eb09a2f1db6fa9d28ce0cde5957d3c634e` | 3964 / `67c70b777b71c46cd22a3d2cc9ac997971b14ca01dc80eca02ea8328957229b4` | R |
| A | `supabase/migration-tests/training_readiness_goal_after.sql` | absent | 456 / `9e7ad7b21cf73d8c5924d60cefc16b4e22d6a48a1db5ad1e50d6f8c8f417adc4` | R |
| A | `supabase/migration-tests/training_readiness_goal_before.sql` | absent | 2281 / `00a1fdc4afb86a4e2dcd9930c303aed95f1fb807f00013d333e80c648e36104e` | R |
| A | `supabase/migration-tests/training_readiness_goal_contract.sql` | absent | 4107 / `129eb2e3bfd28381b4fb20b815a7d8ba21a78a54112f53ac39f16ec6f0a8742e` | R |
| A | `supabase/migration-tests/training_readiness_goal_fresh.sql` | absent | 200 / `fce1306b65521fcb23d94a6f0511d94ea4b32d3eb4bcbd467c63a2ed54fa947c` | R |
| M | `supabase/migration-tests/training_record_populated_after.sql` | 3248 / `f61b304538c65e005f1bb3543fc767c3f14f79f5c0c50a8e8a9f07cdf47f0e50` | 3284 / `627c5f6bb7c4334d92d5d9962b1d1278c6dc1aaffec4779b76ef7ecd62df0869` | R |
| A | `supabase/migrations/20261004100618_training_readiness_goal.sql` | absent | 484 / `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962` | R |

## Appendix B. Complete upstream access dependency byte census

Rename expansion gives physical deleted/added paths. Values are the exact ee1 current-main bytes. Identical/absent means the reviewed merge preserves those bytes/deletion state; all five merged overlaps have their actual head hash in Appendix A. Source/contracts/tests/docs were inspected here. The two historical D27 archives are pinned containers rather than independently reaccepted runtime evidence.

| Status | Upstream changed path | ee1 bytes / hash | At reviewed merge |
|---|---|---|---|
| M | `.agents/skills/verify-trooptotask/features/access-context.md` | 6282 / `47f1ed7bf060168bc8426f574d29ed750186bd4cb62563bfcf0672d5876695bf` | identical / absent |
| M | `docs/architecture/ARCHITECTURE.md` | 16115 / `1cabd14782290ed9a568783b5da6a3d38d99c479c3f9458396131eb78b1179cb` | identical / absent |
| M | `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` | 80646 / `1c6e630e78bad166f2f000fc8436d96b92078d890caed95415fca5c664f1a600` | merged; see PR census |
| M | `docs/architecture/CURRENT_OWNERSHIP.md` | 105803 / `dfd60d28f2f42e8227198b4c3e141f01cff40df11c187300edaa22bba4885c74` | merged; see PR census |
| M | `docs/architecture/DRIFT_LEDGER.md` | 38085 / `9817eb17f82df0427df95498efc9a61e523a1fed2b1a3f2fea96568b736a909e` | identical / absent |
| M | `docs/stabilization/EVIDENCE.md` | 602458 / `91008f37aaeb18b526c04c5506d74e7531ec252cb33b470df5ca47c3ff15a03c` | identical / absent |
| M | `docs/stabilization/TODO.md` | 196543 / `b4f737989ce50ac9a2a9b0f6234531f0bffe6cc0d37550c5c04ec85d43ff4fce` | identical / absent |
| M | `docs/stabilization/phase-08/d27-access-baseline.md` | 14990 / `647e626805dc3231bc1980a41d7949191c1e84e3acb9e971610554e6f7816458` | identical / absent |
| A | `docs/stabilization/phase-08/d27-access-policy-baseline.tar.gz` | 2032432 / `65026864c5285a7e3966976a697113dde47fc9156cf18890404526ee05079d51` | identical / absent |
| A | `docs/stabilization/phase-08/d27-access-policy-final.tar.gz` | 2776402 / `cf15619a75d4600705522fd22ba285a6b2e80a84f8eb2e8e26d362291bc858d4` | identical / absent |
| A | `docs/stabilization/phase-08/d27-access-policy.md` | 16494 / `ddd1d261525059aa888d43f18e7bd009b7b029614f8440cb3f286cc20b7472e8` | identical / absent |
| M | `scripts/module-boundaries.json` | 15684 / `77b16eff7296c62c1bc187cd27f3d1aa6785043cc4ee70cc08b48d4bac9ab3e2` | merged; see PR census |
| M | `src/features/critical-tasks/server/ictTasksBatch.server.ts` | 5381 / `7676ba9c5536def34b4799ce1e755ac9ddb6486202e2483522995623c73b4bbf` | identical / absent |
| M | `src/features/critical-tasks/server/personnelIctCompletionPorts.server.ts` | 1553 / `4d16b2823b8ff9c708da894959d7eb4a864831440b1a239f6bd17fb9691d0e34` | identical / absent |
| M | `src/features/deletion-requests/cancelDeletionRequest.server.ts` | 1583 / `af9bd7ecc2061dc400591f53eff0cc0266feead0928c8eaec5964e25d0bca934` | identical / absent |
| M | `src/features/deletion-requests/createDeletionRequest.server.ts` | 3049 / `c0bbaf93b6b46c317ef75a47761e1f8701c692d28ce3fec824dc8fdac2f44b3b` | identical / absent |
| M | `src/features/deletion-requests/deletionRequestReads.server.ts` | 2582 / `6338f906f58b29afe0c45bb8f798e65b9d6428df6c82b2515db99c3251d1e0b7` | identical / absent |
| M | `src/features/deletion-requests/reviewDeletionRequest.server.ts` | 5546 / `d05f3e92f3177db27bc2f273d44536d757d96db923d6717f1fa4ce65a1f5372c` | identical / absent |
| M | `src/features/identity/accountPreferences.server.ts` | 6704 / `5ca8dd8a6f319db675db18c879f7bcc2da5e8d56f50ccffc012b02fc3f357c12` | identical / absent |
| M | `src/features/identity/authorization.server.ts` | 619 / `953626f7efc6b15e0b47866c10ba819ad71fecad46e0bcee792c5d110ad4c204` | identical / absent |
| M | `src/features/notifications/notificationOperations.server.ts` | 3435 / `374118126af44d6ecd70a1994a7674e50e946ac552daf427bed57b252310486e` | identical / absent |
| M | `src/features/onboarding/server/onboardingPorts.server.ts` | 3240 / `959e99d33625813fceae3c568be3faa38359672d5d24f5179a58b11999e9150b` | identical / absent |
| M | `src/features/onboarding/server/onboardingTemplatePorts.server.ts` | 1944 / `398c6800c835d61ea1596389221632cf5cc065905a9e9324ae38b3ac2fd0988a` | identical / absent |
| M | `src/features/organization/destruction.server.ts` | 5055 / `315fc918c1f7b64ad213d8268b525dad8f8ffefb1013e5e197512f1878a12bdd` | identical / absent |
| M | `src/features/organization/memberManagement.server.ts` | 35151 / `f6b71c7352b4c9b903ee025b5a2e8e2a14d4b2507b84b13e878d76e63bace701` | identical / absent |
| M | `src/features/organization/ownershipTransfer.server.ts` | 3975 / `efc9f51817cea9663f2fbe35428889541cde15aa517ac0b3bf8403fb70fcba94` | identical / absent |
| M | `src/features/organization/policy.server.ts` | 2976 / `728eca547ae9ab8000b35044027a358671044b5a0873d34cce3eaf097a7d4868` | merged; see PR census |
| M | `src/features/organization/profile.server.ts` | 3147 / `6639a5226cdda8dfc407e9972641e88c39b872f565e3c21c2ae827be5986dbc3` | identical / absent |
| M | `src/features/personnel/awardTracking.server.ts` | 2867 / `93914adc8b158b221787bfea1429a0dc6d49266a953c1e42679385d09ae6dc94` | identical / absent |
| M | `src/features/personnel/contracts.ts` | 13153 / `279ed40112a9c497ac71987eb927c419f409c6fb05ac7b0eae837cf7b189bcc7` | identical / absent |
| M | `src/features/personnel/groupOperations.server.ts` | 2527 / `47c0499699990cbfc2bb1a07ec8671b1d91be49437c4eb017c60fc07266f8ab5` | identical / absent |
| M | `src/features/personnel/leaderNotes.server.ts` | 6190 / `12a6c6e477c22d7d1a9e8e3fa4bb476d6a4e5805e2c61e2b2ee26f369be81190` | identical / absent |
| M | `src/features/personnel/personnelArtifactContext.server.ts` | 4033 / `f6a807e193f6c026262c4a3b52e763c607811d5894f561b2419ea61c09140bc6` | identical / absent |
| M | `src/features/personnel/personnelBatchContext.server.ts` | 702 / `28d5103a1ee1d35723b7084f5ed07ca1dffe7e76d669742c7a8f859b8335ac2e` | identical / absent |
| M | `src/features/personnel/personnelDetail.server.ts` | 5689 / `13d94d530e2a3a51eb4aa95f94626fc65ff46aafbf043da94ec8b1b3368424de` | identical / absent |
| M | `src/features/personnel/personnelExport.server.ts` | 8324 / `87a8c4fbf5bcc313c83e07c34a87b65e789e53844a9643c9e0b8ca3fc107db0b` | identical / absent |
| M | `src/features/personnel/personnelExtendedInfo.server.ts` | 6935 / `2d524eab2e66843025b19f54a4b8f55c3cb78faca3d39d9802a79cac7902704b` | identical / absent |
| M | `src/features/personnel/personnelLifecycle.server.ts` | 9144 / `8ab1ca8bb3daac88739e7564622a7d24821db8fcddb6bdc6622c3dd67d160dfc` | identical / absent |
| M | `src/features/personnel/personnelRecordOperations.server.ts` | 6179 / `ed00e1ed283c61f080d904b36fd79ff32238a58a88d26ec54ccce439bc7e585e` | identical / absent |
| M | `src/features/personnel/rankCatalogOperations.server.ts` | 25729 / `c2c65b27d75e2ebf6be3470d9f33c6981d9b4b1bbe432c4e42af0dbeffdddc13` | identical / absent |
| M | `src/features/rating-scheme/server/ratingSchemeEntryPorts.server.ts` | 1370 / `b5d7d27052321bf08ad693adb0e7eee8a6929374d255a53fe34f067431ac0d63` | identical / absent |
| M | `src/features/rating-scheme/server/ratingSchemeWorkspaceQuery.server.ts` | 1901 / `9a8b5b65e88b48dc96a9ac3f022651ccc6a6e64d0de8de7c33c904eeb38b8ff4` | identical / absent |
| M | `src/features/training/server/trainingCatalogPorts.server.ts` | 1507 / `c09e06d714bc04f29dbf8e8e8b7e50eaed3c5e187f76746cf956c18a9ba81e56` | identical / absent |
| M | `src/features/training/server/trainingCompletionPorts.server.ts` | 1307 / `1d3172921d0616ee4eb6a8c6baeb812bd6371782b2c5f524daef7e5d209ee380` | identical / absent |
| M | `src/lib/access/index.server.ts` | 728 / `de688118d11541e1ea385f975a8ddd13c4e371b185b981b125ae3435167ec79f` | identical / absent |
| M | `src/lib/access/memberAccessShape.ts` | 6232 / `1e2f8644e33d18b2f9f189c589ffb2e9775aaf6012d076396b61fe447f0c21be` | identical / absent |
| A | `src/lib/access/policyAdapter.server.test.ts` | 4673 / `21b1743aaf9c65043295b749fafa132eeb7312944e645d9759acb175a829baf4` | identical / absent |
| A | `src/lib/access/policyAuthorization.server.test.ts` | 2225 / `964db5bc738e215a5871d32cfb6778521d42c0bcd62ec7ba725fd50560df697a` | identical / absent |
| A | `src/lib/access/policyDenial.server.test.ts` | 4630 / `d2dd5508ae87ed2818f3bd5c39dab1486b9e878950abc5654ee16a3072bb6f16` | identical / absent |
| A | `src/lib/access/routeAuthorization.server.test.ts` | 4774 / `3caa0b3491229e1cf036d1515ef4b90e16aead1848e85ab7306472c9d47a82ab` | identical / absent |
| A | `src/lib/access/serverPolicy.server.ts` | 11033 / `ca9394bade80b820930b692be66d8bb0c63de235c0092bab469d375181434b58` | identical / absent |
| M | `src/lib/server/adapters/httpAdapter.ts` | 38098 / `5063f3102254a352cc8e812e49ea522a2ebf4b671fc71eb3ea30902866541c9d` | identical / absent |
| M | `src/lib/server/adapters/inMemory.ts` | 50261 / `16d8b8ea2947ecf2f9906e2400f641a888a21f06131dfa4c5205c1e4e842d292` | merged; see PR census |
| M | `src/lib/server/core/ports.ts` | 10857 / `99091357160d3bfe43c4e57e7daa122e0bc08295d8ce6f999217676369469486` | identical / absent |
| M | `src/lib/server/core/useCases/calendarPolicy.ts` | 3512 / `a7ae1e115005b354265564f56add2c53b70b6706d075db363274884a7714364e` | identical / absent |
| M | `src/lib/server/core/useCases/crud.ts` | 6295 / `f47fffc436fad33750760e1b5a9ccffa84ee5696c0b787ad6fd22b2c40a0936b` | identical / absent |
| D | `src/lib/server/core/useCases/featurePolicy.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/governancePolicy.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/identityPolicy.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyAdapter.test.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyAdapter.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyAuthorization.test.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyAuthorization.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyDenial.test.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/policyDenial.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/routeAuthorization.test.ts` | absent | identical / absent |
| D | `src/lib/server/core/useCases/routeAuthorization.ts` | absent | identical / absent |
| M | `src/lib/server/core/useCases/starterConfigurationPacks.ts` | 14102 / `876ed51d7b5d7abf4aacce593b971ea9086edf6e48eaf8e84706835aa47e2992` | identical / absent |
| D | `src/lib/server/permissions.test.ts` | absent | identical / absent |
| D | `src/lib/server/permissions.ts` | absent | identical / absent |

