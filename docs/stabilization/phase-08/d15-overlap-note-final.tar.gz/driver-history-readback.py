from drive import *
mode=os.environ['D15_MODE'];assert mode in ['notes','lifecycle'];seed=json.loads((E/(mode+'-legacy-seed.json')).read_text());page=json.loads((E/'notes-history-page.json').read_text())['pageId'];expected=json.loads((E/'notes-outcome.json').read_text()) if mode=='notes' else json.loads((E/'lifecycle-outcome.json').read_text())
def open_packet(tag):
 s=snap(page,tag+'-before');line=next(l for l in s.splitlines() if ' button ' in l and seed['person']['last_name'] in l)
 if not re.search(r'\bexpanded\b',line):click(page,re.search(r'uid=(\S+)',line)[1],tag+'-open')
 return snap(page,tag+'-opened')
for iteration in ['first','reloaded']:
 tag=mode+'-native-'+iteration
 if iteration=='reloaded' or mode=='lifecycle':native('navigate_page',{'pageId':page,'type':'reload'},tag+'-reload')
 s=open_packet(tag)
 if mode=='notes':
  lines=s.splitlines();start=next(i for i,l in enumerate(lines) if 'StaticText "Orientation"' in l);line=next(l for l in lines[start+1:] if 'button "Toggle notes"' in l)
  if not re.search(r'\bexpanded\b',line):click(page,re.search(r'uid=(\S+)',line)[1],tag+'-notes-open')
  s=snap(page,tag+'-notes');assert 'Legacy retained work '+seed['tag'] in s,s
  assert all(marker in s for marker in expected['savedMarkers']),s
  assert all(marker not in s for marker in expected['missingMarkers']),s
 else:
  parent=expected['savedParent'];assert parent['status'].title() in s,s
 screen(page,tag)
write(E/(mode+'-native-readback-outcome.json'),json.dumps({'result':'MATCHES_SAVED_FAILURE' if expected['result']=='FAIL' else 'PASS','scope':'Native History then reload matches separately observed saved API/provider outcome','expectedProductResult':expected['expected'],'lostNoteStillAbsent':mode=='notes' and bool(expected['missingMarkers']),'apiCreationIsSeparate':True},indent=2)+'\n')
print(mode+' native History and reload match the separately observed saved result.',flush=True)
