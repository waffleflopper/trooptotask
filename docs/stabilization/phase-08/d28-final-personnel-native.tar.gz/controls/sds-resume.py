import current as x
import json
d=x.d
seed=json.loads((x.c/'seed.json').read_text())
d.within('lifecycle-person-open-corrected','row','Open SPC '+seed['name']+', Synthetic','button','Details')
d.snap('lifecycle-person-ready')
d.act('sds-open','button','More info')
r=d.snap('sds-form');root=r['structuredContent']['snapshot'];dialogs=[n for n in d.walk(root) if n.get('role')=='dialog' and n.get('name')=='Soldier Data Sheet'];assert len(dialogs)==1
nodes=list(d.walk(dialogs[0]));fields=[('Blood type','O+'),('Marital status','Single'),('Personal phone','555-0103'),('Personal email','sheet@example.invalid'),('Address','1 Test Street'),('BASD','2020-01-02'),('Date of rank','2024-03-04'),('Spouse name','Synthetic Spouse'),('Spouse phone','555-0102'),('Number of dependents','2'),('Children','Alex, 7\nJamie'),('Vehicle color','Blue'),('Vehicle','Synthetic Sedan'),('Plate','VFY1376'),('Civilian education','Associate'),('Military education','BLS\nACLS'),('Emergency contact','Synthetic Contact'),('Relationship','Sibling'),('Emergency phone','555-0101')]
elements=[];mapped=[]
for label,value in fields:
 pos=[i for i,n in enumerate(nodes) if n.get('role')=='StaticText' and n.get('name')==label];assert len(pos)==1,(label,pos)
 n=next(n for n in nodes[pos[0]+1:] if n.get('role') in ['textbox','spinbutton','Date']);elements.append({'uid':n['id'],'value':value});mapped.append({'label':label,'role':n['role'],'uid':n['id'],'value':value})
for label,value in [('Address city','Test City'),('Address state','AK'),('Address ZIP','99501')]:
 ns=[n for n in nodes if n.get('role')=='textbox' and n.get('name')==label];assert len(ns)==1;elements.append({'uid':ns[0]['id'],'value':value});mapped.append({'label':label,'role':'textbox','uid':ns[0]['id'],'value':value})
(d.E/'sds-22-native-mapping.json').write_text(json.dumps(mapped,indent=2))
d.tool('sds-fill-all22','fill_form',{'pageId':2,'elements':elements});d.snap('sds-filled');d.act('sds-save','button','Save');d.wire('sds-save-wire',2,'personnel');x.full('sds-saved-full');d.tool('sds-reload','navigate_page',{'pageId':2,'type':'reload'});d.act('sds-reopen','button','More info');d.snap('sds-reopened');d.shot('sds-reopened');d.act('sds-close','button','Cancel')
