import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
rp=pathlib.Path(__file__).parent/'runtime.json';s=json.loads(rp.read_text());ids=s['fixture']['ids'];t=s['temporaryIds'];org=ids['orgA']
body={'id':t['expiryRecord'],'completionDate':None,'expirationDate':'2026-10-22','notes':'D28 direct patch'}
fn='async()=>{const body='+json.dumps(body)+';const r=await fetch('+json.dumps('/org/'+org+'/api/personnel-trainings')+',{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});return {method:"PUT",body,status:r.status,response:await r.json()}}'
r=d.result_value(d.evaluate('expiry-direct-patch-api',fn,3));assert r['status']==200 and r['response']['id']==t['expiryRecord'] and r['response']['completionDate']==None and r['response']['certificateUrl']=='https://example.test/d28-expiry';d.wire('expiry-direct-patch-wire',3,'personnel-trainings');d.call('expiry-direct-patch-sql',['rows','personnel_trainings','orgA','id',t['expiryRecord']],True)
d.tool('expiry-direct-patch-reload','navigate_page',{'pageId':3,'type':'reload'});d.act_prefix('expiry-warning-reopen','button','Able D28 Ordinary Expiry 20261007:',3);d.snap('expiry-warning-loaded',3);d.shot('expiry-warning-loaded',3);d.act('expiry-warning-close','button','Close',3)
a=d.call('dashboard-actor',['actor','dashboardView','home'],True);s['dashboardPage']=a['pageId'];rp.write_text(json.dumps(s,indent=2));d.snap('dashboard-current',a['pageId']);d.shot('dashboard-current',a['pageId'])
d.evaluate('getting-started-api','async()=>{const r=await fetch('+json.dumps('/org/'+org+'/api/getting-started')+');return {status:r.status,body:await r.json()}}',a['pageId'])
b=d.call('personnel-reverse-actor',['actor','rosterManager','personnel'],True);s['personnelPage']=b['pageId'];rp.write_text(json.dumps(s,indent=2));d.snap('personnel-reverse-list',b['pageId'])
