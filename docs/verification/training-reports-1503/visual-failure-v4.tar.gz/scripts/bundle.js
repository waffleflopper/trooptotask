window.__census = () => {
	const root = document.querySelector('[data-testid=training-briefing-forecast]');
	const svg = root?.querySelector('svg');
	if (!svg) return { error: 'no chart svg' };
	const sr = svg.getBoundingClientRect();
	const rel = (r) => ({ l: +(r.left - sr.left).toFixed(1), r: +(r.right - sr.left).toFixed(1), t: +(r.top - sr.top).toFixed(1), b: +(r.bottom - sr.top).toFixed(1) });
	const hit = (a, b, pad = 0) => a.l < b.r + pad && b.l < a.r + pad && a.t < b.b + pad && b.t < a.b + pad;
	const texts = [...svg.querySelectorAll('text')];
	const goal = texts.find((t) => t.textContent.trim().startsWith('Goal'));
	if (!goal) return { error: 'no goal text' };
	const toScreen = (el, x, y) => { const p = svg.createSVGPoint(); p.x = x; p.y = y; const s = p.matrixTransform(el.getScreenCTM()); return { x: s.x - sr.left, y: s.y - sr.top }; };
	const glyphs = [];
	for (let i = 0; i < goal.getNumberOfChars(); i++) {
		const e = goal.getExtentOfChar(i);
		const a = toScreen(goal, e.x, e.y), b = toScreen(goal, e.x + e.width, e.y + e.height);
		glyphs.push({ ch: goal.textContent[i], l: a.x, r: b.x, t: a.y, b: b.y });
	}
	const gbox = rel(goal.getBoundingClientRect());
	const order = [...svg.querySelectorAll('*')];
	const goalIdx = order.indexOf(goal);
	const cs = getComputedStyle(goal);
	const paths = [...svg.querySelectorAll('path')];
	const lineHits = [], areaInfo = [];
	for (const p of paths) {
		const pc = getComputedStyle(p);
		const isArea = pc.fill !== 'none' && pc.fill !== 'rgba(0, 0, 0, 0)';
		const isLine = !isArea && parseFloat(pc.strokeWidth) >= 2 && pc.stroke !== 'none';
		if (!isLine && !isArea) continue;
		const len = p.getTotalLength();
		const hits = new Set();
		if (isLine) {
			const w = parseFloat(pc.strokeWidth) / 2;
			for (let s = 0; s <= len; s += 0.5) {
				const pt = p.getPointAtLength(s); const q = toScreen(p, pt.x, pt.y);
				glyphs.forEach((g, i) => { if (q.x >= g.l - w && q.x <= g.r + w && q.y >= g.t - w && q.y <= g.b + w) hits.add(i); });
			}
			lineHits.push({ cls: p.getAttribute('class'), drawnBeforeGoal: order.indexOf(p) < goalIdx, glyphsTouched: [...hits].map((i) => glyphs[i].ch).join(''), stroke: pc.stroke });
		} else {
			areaInfo.push({ cls: p.getAttribute('class'), drawnBeforeGoal: order.indexOf(p) < goalIdx, overlapsGoalBox: hit(rel(p.getBoundingClientRect()), gbox) });
		}
	}
	const others = [];
	for (const el of svg.querySelectorAll('rect, circle, text, line')) {
		if (el === goal) continue;
		const b = rel(el.getBoundingClientRect());
		if (b.r - b.l <= 0 && b.b - b.t <= 0) continue;
		const gl = glyphs.filter((g) => { const gg = { l: g.l, r: g.r, t: g.t, b: g.b }; return hit(b, gg); }).map((g) => g.ch).join('');
		if (!gl && !hit(b, gbox)) continue;
		const ec = getComputedStyle(el);
		others.push({ tag: el.tagName, cls: (el.getAttribute('class') || '').slice(0, 60), text: el.tagName === 'text' ? el.textContent : undefined, box: b, glyphsTouched: gl, drawnAfterGoal: order.indexOf(el) > goalIdx, fill: ec.fill, stroke: ec.stroke });
	}
	const cap = root.querySelector('div.mb-1');
	const capBox = cap ? rel(cap.getBoundingClientRect()) : null;
	const endTexts = texts.filter((t) => /^\d+%$/.test(t.textContent.trim()) && !t.closest('.tick, [class*=axis]'));
	const textBoxes = texts.map((t) => ({ v: t.textContent.trim(), b: rel(t.getBoundingClientRect()) }));
	const textOverlaps = [];
	for (let i = 0; i < textBoxes.length; i++) for (let j = i + 1; j < textBoxes.length; j++) if (hit(textBoxes[i].b, textBoxes[j].b)) textOverlaps.push([textBoxes[i].v, textBoxes[j].v]);
	const bars = [...svg.querySelectorAll('rect')].filter((r) => /fill-warning(?!\/10)/.test(r.getAttribute('class') || '')).map((r) => ({ cls: r.getAttribute('class'), b: rel(r.getBoundingClientRect()) }));
	const textOverBars = [];
	for (const t of textBoxes) for (const bar of bars) if (bar.b.b - bar.b.t > 0 && hit(t.b, bar.b)) textOverBars.push([t.v, bar.cls]);
	const outside = textBoxes.filter((t) => t.b.l < -1 || t.b.r > sr.width + 1 || t.b.t < -1 || t.b.b > sr.height + 30).map((t) => t.v);
	const rows = [...root.querySelectorAll('.sr-only tbody tr')].map((tr) => tr.innerText.replace(/\t/g, ' '));
	return {
		svg: { w: +sr.width.toFixed(1), h: +sr.height.toFixed(1) },
		theme: document.documentElement.classList.contains('dark') || document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light',
		url: location.search,
		goal: { text: goal.textContent, anchor: goal.getAttribute('text-anchor'), box: gbox, fill: cs.fill, stroke: cs.stroke, strokeWidth: cs.strokeWidth, paintOrder: cs.paintOrder, linejoin: cs.strokeLinejoin, bg: getComputedStyle(document.body).backgroundColor },
		lineHits, areaInfo, marksNearGoal: others,
		caption: cap ? { text: cap.innerText.replace(/\n/g, ' | '), box: capBox, aboveSvg: capBox.b <= 0 } : null,
		textOverlaps, textOverBars, outside,
		texts: textBoxes.filter((t) => !/^(\d+%|Today.*|\d+ \w{3}|\w{3} \d+)$/.test(t.v) || /%$/.test(t.v)).map((t) => t.v).slice(0, 30),
		srRows: rows
	};
};
'census installed'

window.__compact = (c) => ({
	w: c.svg.w, theme: c.theme, anchor: c.goal.anchor, goalBox: c.goal.box,
	lineThroughGlyphCells: c.lineHits.map((l) => l.glyphsTouched).join(''),
	lineBeforeGoal: c.lineHits.every((l) => l.drawnBeforeGoal), areaBeforeGoal: c.areaInfo.every((a) => a.drawnBeforeGoal),
	laterMarksOnGoal: c.marksNearGoal.filter((m) => m.drawnAfterGoal).map((m) => `${m.tag}:${m.text ?? m.cls}:${m.glyphsTouched}`),
	underGoal: c.marksNearGoal.filter((m) => !m.drawnAfterGoal).map((m) => `${m.tag}:${m.cls.slice(0, 20)}`),
	halo: `${c.goal.strokeWidth}/${c.goal.paintOrder}/${c.goal.linejoin}/${c.goal.stroke === c.goal.bg}`,
	captionAbove: c.caption?.aboveSvg ?? null, caption: c.caption?.text,
	textOverlaps: c.textOverlaps, textOverBars: c.textOverBars, outside: c.outside,
	labels: c.texts.filter((t) => !/^\d+%$/.test(t) || true).join(' '),
	srCount: c.srRows.length, srTail: c.srRows.slice(-2)
});
window.__sweep = async (horizons = [30, 60, 90, 180]) => {
	const out = [];
	for (const h of horizons) {
		const radio = document.querySelector(`[role=radio][aria-label="${h} days"]`) || [...document.querySelectorAll('[role=radio]')].find((r) => r.textContent.trim() === `${h} D`);
		radio.click();
		const t0 = performance.now();
		let ok = false;
		while (performance.now() - t0 < 8000) {
			await new Promise((r) => setTimeout(r, 150));
			const heading = document.querySelector('[data-testid=training-briefing-forecast]')?.closest('section')?.innerText || document.body.innerText;
			if (radio.getAttribute('aria-checked') === 'true' && heading.includes(`NEXT ${h} DAYS`) && !document.querySelector('[aria-busy=true]')) { ok = true; break; }
		}
		await new Promise((r) => setTimeout(r, 300));
		const bl = [...document.querySelectorAll('section')].find((s) => s.innerText.startsWith('Bottom line'))?.innerText.split('\n').filter(Boolean).slice(1, 7).join(' ');
		out.push({ h, stable: ok, url: location.search, bl, ...window.__compact(window.__census()) });
	}
	return out;
};
'sweep installed'

window.__contrast = () => { const cv=document.createElement('canvas'); cv.width=cv.height=1; const x=cv.getContext('2d',{willReadFrequently:true}); const rgb=(c,under)=>{ x.clearRect(0,0,1,1); if(under){x.fillStyle=under; x.fillRect(0,0,1,1);} x.fillStyle=c; x.fillRect(0,0,1,1); return [...x.getImageData(0,0,1,1).data].slice(0,3); }; const L=([r,g,b])=>{const f=v=>{v/=255;return v<=0.03928?v/12.92:((v+0.055)/1.055)**2.4}; return 0.2126*f(r)+0.7152*f(g)+0.0722*f(b);}; const cr=(a,b)=>{const [h,l]=[L(a),L(b)].sort((p,q)=>q-p); return +((h+0.05)/(l+0.05)).toFixed(2);}; const svg=document.querySelector('[data-testid=training-briefing-forecast] svg'); const goal=[...svg.querySelectorAll('text')].find(t=>t.textContent.startsWith('Goal')); const bg=getComputedStyle(document.body).backgroundColor; const gs=getComputedStyle(goal); const band=svg.querySelector('rect[class*="fill-warning/10"]'); const bandFill=band?getComputedStyle(band).fill:null; const line=svg.querySelector('path.path-line'); const rule=[...svg.querySelectorAll('line, path')].find(e=>(e.getAttribute('class')||'').includes('stroke-success')); const B=rgb(bg); const F=rgb(gs.fill,bg); const H=rgb(gs.stroke,bg); const BAND=bandFill?rgb(bandFill,bg):null; const LN=rgb(getComputedStyle(line).stroke,bg); const RU=rule?rgb(getComputedStyle(rule).stroke,bg):null; const tick=[...svg.querySelectorAll('text')].find(t=>t.textContent==='50%'); return {theme:document.documentElement.dataset.theme, bg:B, goalFill:F, halo:H, haloEqualsBg:H.join()===B.join(), goalVsHalo:cr(F,H), goalVsBand:BAND?cr(F,BAND):null, haloVsBand:BAND?cr(H,BAND):null, lineVsBg:cr(LN,B), lineVsHalo:cr(LN,H), rule:RU, ruleVsBg:RU?cr(RU,B):null, tickFill:getComputedStyle(tick).fill, sameAsTick:getComputedStyle(tick).fill===gs.fill, fontSize:gs.fontSize, fontFamily:gs.fontFamily.slice(0,40)}; };
'contrast installed'
