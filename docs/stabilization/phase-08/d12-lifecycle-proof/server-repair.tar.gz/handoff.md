# D12 lifecycle recovery server handoff

Base: 8da72739a9fc25a87d2a927317dbaf26f29cbf49.
Baseline test commit: 490b24203ebb78dd21a1e6a488375c2c15adf28d.
Repair commit: 4f0c557e7f5bbf2174bd5761008309cd69d54e73.
Branch: stabilization/1360-personnel-lifecycle-recovery-server.
Worktree: /tmp/t2t-1360-personnel-lifecycle-recovery-server.
Only tracked changes: src/lib/server/core/useCases/personnel.ts and personnel.test.ts.
No browser, app service, database execution, publication, schema change or ownership cutover was performed.

## Baseline

Production personnel.ts is unchanged in baseline commit. `npm run test -- src/lib/server/core/useCases/personnel.test.ts` exited 1: five failing tests and 28 passing tests. Final authoritative log: baseline-tests.txt; exit: baseline-tests.exit.

Failing cases: approved mixed active/archived completion and success acknowledgement; replay after second-parent pre-persistence failure; replay after late note-effect failure; partial restore loss of parent timestamp and observed subsequent 400; successful in-scope archived replay with hidden Group/foreign targets unchanged.

Passing preservation cases include already-archived view/operate callers' existing per-ID errors/no persisted effects/no new request; healthy one-candidate-read/one-event-cascade budget; final parent-clear failure and retry; pending409 acknowledgement and independent D18 write failure.

The initial test run (baseline-initial-tests.txt) had seven failures because two authority cases incorrectly demanded a new403. Those assertions were corrected to retain the existing per-ID archived error channel before the baseline commit; they earn no defect credit. The strengthened final fixture additionally contains a second Person's note to distinguish T1 and T2 child events.

The first baseline type run omitted PUBLIC_SUPABASE_URL/PUBLIC_SUPABASE_ANON_KEY and emitted ten env-only diagnostics in six files (baseline-types-missing-env.txt, exit1). Rerunning with inert static placeholders passed zero errors/warnings (baseline-types.txt, exit0); no real credentials or service were used.

## Repair and final checks

Bulk keeps one scoped candidate read, deduplication, request/error shapes and active-candidate policy/provider abort behavior. Authorized archived candidates evaluate saved-Group manage/direct-archive eligibility, do not rewrite the parent, receive their original event on residual active artifacts, and are acknowledged in archivedIds. Candidates without direct authority retain already-archived errors and create no new request. IDs are grouped by saved/new timestamp: healthy bulk has one group; interrupted parent-prefix recovery in the test has two distinct groups. Every group still uses the existing batched provider/cascade.

Restore authorizes first and restores only artifacts matching the saved event before clearing the parent. Audit runs only after acknowledged completion. No generic catches, privileged lookups, per-Person artifact waterfall, transaction or concurrent-replay guarantee was introduced.

Final focused run: six files / 98 tests PASS, exit0 in repair-focused-tests.txt. Files: personnel.test.ts, personnelArchivedArtifacts.test.ts, deletionRequests.test.ts, api/personnel/server.test.ts, api/personnel/archive-batch/server.test.ts, api/personnel/permanent/server.test.ts. This retains single/review replay, governance reviewers without Personnel capability, policies and route coverage.

Types: repair-types.txt, exit0, zero errors/warnings. Format: repair-format-check.txt, exit0. Focused ESLint: repair-lint.txt, exit0, no diagnostics. Governance: repair-governance.txt, exit0, 713 existing findings with no regression.

Initial repaired-source focused run also passed98. The first governance run found a new test-only Personnel-to-delivery DataStore import (715 findings; repair-governance-test-edge-failure.txt, exit1). The repair commit replaces that import with a store type inferred from the existing test-context seam; no waiver, manifest or scanner change. All six affected test files, types, lint, formatting and governance were rerun successfully. A final comment clarification describes fresh update acknowledgements precisely; formatting was rechecked afterward.

## Environment and limits

Node v24.21.0, npm11.19.0, Vitest4.1.8. npm ci completed. install.txt retains engine warning (package requests npm11.12.1), existing transitive-package deprecation warnings and install-script warnings for core-js/esbuild. Runtime/check commands nevertheless completed successfully.

Type commands use PUBLIC_SUPABASE_URL=http://127.0.0.1:9 and PUBLIC_SUPABASE_ANON_KEY=verification-only-placeholder; these are inert build declarations and did not start/contact an app or provider. Vitest and svelte-kit sync/check ran sequentially in this isolated worktree.

This is lower-level fake-provider persistence proof only. Native browser/provider verification, independent acceptance, full candidate CI/build and publication remain coordinator-owned. No claim of database RLS execution, stored file bytes, atomic concurrent archive/restore, recovery after every uncertain post-commit response, or whole issue closure. Inputs/expected fixture rows are separately cloned, request reads and update acknowledgements are fresh copies, and faults occur before their rejected write persists.
