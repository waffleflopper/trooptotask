async () => {
  await document.fonts.ready;
  const settle = () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  let root = null;
  for (let i = 0; i < 60; i++) {
    root = document.querySelector('[data-testid=training-briefing-forecast]');
    const s = root?.querySelector('svg.layercake-layout-svg');
    if (s && s.querySelector('circle') && document.querySelector('[aria-busy=true], [data-pending=true]') === null) break;
    await new Promise((r) => setTimeout(r, 50));
  }
  await settle();
  if (!root) return { error: 'no forecast', href: location.href, title: document.title };
  const svg = root.querySelector('svg.layercake-layout-svg') ?? root.querySelector('svg');
  const ctx = document.createElement('canvas').getContext('2d');
  const toScreen = (el, x, y) => new DOMPoint(x, y).matrixTransform(el.getScreenCTM());
  const r1 = (v) => Math.round(v * 10) / 10;
  const box = (b) => b && { l: r1(b.l), t: r1(b.t), r: r1(b.r), b: r1(b.b) };
  const cls = (el) => el.getAttribute('class') ?? '';

  const texts = [...svg.querySelectorAll('text')].map((text) => {
    const value = text.textContent.trim();
    if (!value || text.getNumberOfChars() === 0) return null;
    const cs = getComputedStyle(text);
    ctx.font = `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    const m = ctx.measureText(value);
    const p0 = text.getStartPositionOfChar(0);
    const p1 = text.getEndPositionOfChar(text.getNumberOfChars() - 1);
    const a = toScreen(text, p0.x, p0.y);
    const e = toScreen(text, p1.x, p1.y);
    const ink = { l: a.x - m.actualBoundingBoxLeft, r: a.x + m.actualBoundingBoxRight, t: a.y - m.actualBoundingBoxAscent, b: a.y + m.actualBoundingBoxDescent };
    let role = 'text';
    const c = cls(text);
    if (c.includes('tickLabel')) role = 'yTick';
    else if (text.closest('g')?.getAttribute('class')?.match(/text-(success|warning|destructive|foreground|muted)/) && c.includes('fill-current')) role = 'endValue';
    else if (c.includes('text-xs') && c.includes('fill-foreground')) role = 'startValue';
    else if (c.includes('font-semibold') && c.includes('text-[11px]')) role = 'barCount';
    else if (/goal/i.test(value)) role = 'goalLabel';
    else role = 'xTick';
    return { role, value, font: ctx.font, fill: cs.fill, baseline: r1(a.y), advanceEnd: r1(e.x), ink, el: text };
  }).filter(Boolean);

  const lines = [...svg.querySelectorAll('line')].map((line) => {
    const a = toScreen(line, +line.getAttribute('x1'), +line.getAttribute('y1'));
    const b = toScreen(line, +line.getAttribute('x2'), +line.getAttribute('y2'));
    const c = cls(line);
    const sw = parseFloat(getComputedStyle(line).strokeWidth) || 1;
    const kind = c.includes('stroke-success') ? 'goalRule' : c.includes('grid') ? 'grid' : c.includes('stroke-foreground') ? 'xAxis' : c.includes('tick') ? 'tickStub' : 'line';
    return { kind, x1: a.x, y1: a.y, x2: b.x, y2: b.y, sw, dash: getComputedStyle(line).strokeDasharray, stroke: getComputedStyle(line).stroke };
  }).filter((l) => l.kind !== 'tickStub' && (Math.abs(l.x2 - l.x1) > 0.5 || Math.abs(l.y2 - l.y1) > 0.5));

  const spline = [...svg.querySelectorAll('path')].find((p) => cls(p).includes('stroke-foreground'));
  const area = [...svg.querySelectorAll('path')].find((p) => cls(p).includes('fill-foreground'));
  const splinePts = [];
  if (spline) {
    const len = spline.getTotalLength();
    for (let s = 0; s <= len; s += 0.5) { const p = spline.getPointAtLength(s); const q = toScreen(spline, p.x, p.y); splinePts.push([q.x, q.y]); }
  }
  const circles = [...svg.querySelectorAll('circle')].map((c) => {
    const p = toScreen(c, +c.getAttribute('cx'), +c.getAttribute('cy'));
    return { cx: p.x, cy: p.y, r: +c.getAttribute('r'), fill: getComputedStyle(c).fill };
  });
  const rects = [...svg.querySelectorAll('rect')].map((rc) => {
    const b = rc.getBoundingClientRect();
    return { kind: cls(rc).includes('fill-warning/10') ? 'band' : cls(rc).includes('fill-warning') ? 'bar' : 'rect', l: b.left, t: b.top, r: b.right, b: b.bottom, fill: getComputedStyle(rc).fill };
  });

  const boxGap = (a, b) => {
    const dx = Math.max(b.l - a.r, a.l - b.r, 0);
    const dy = Math.max(b.t - a.b, a.t - b.b, 0);
    if (dx === 0 && dy === 0) return -Math.min(a.r - b.l, b.r - a.l, a.b - b.t, b.b - a.t);
    return Math.hypot(dx, dy);
  };
  const lineGap = (ink, l) => {
    const hz = Math.abs(l.y2 - l.y1) < 0.5;
    if (!hz) return null;
    const lo = Math.min(l.x1, l.x2), hi = Math.max(l.x1, l.x2);
    const half = l.sw / 2;
    const seg = { l: lo, r: hi, t: l.y1 - half, b: l.y1 + half };
    return boxGap(ink, seg);
  };
  const pointGap = (ink, x, y, rad) => {
    const dx = Math.max(ink.l - x, 0, x - ink.r), dy = Math.max(ink.t - y, 0, y - ink.b);
    const inside = dx === 0 && dy === 0;
    return inside ? -rad : Math.hypot(dx, dy) - rad;
  };

  const svgRect = svg.getBoundingClientRect();
  const container = svg.parentElement.getBoundingClientRect();
  const clipAncestors = [];
  for (let el = svg.parentElement; el && el !== document.body; el = el.parentElement) {
    const o = getComputedStyle(el).overflowX + '/' + getComputedStyle(el).overflowY;
    if (!o.startsWith('visible/visible')) clipAncestors.push({ tag: el.tagName, cls: (el.className?.toString?.() ?? '').slice(0, 60), overflow: o, rect: box({ l: el.getBoundingClientRect().left, t: el.getBoundingClientRect().top, r: el.getBoundingClientRect().right, b: el.getBoundingClientRect().bottom }) });
  }
  const clipRect = clipAncestors[0]?.rect;

  const report = (t) => {
    const out = { role: t.role, value: t.value, ink: box(t.ink), baseline: t.baseline, fill: t.fill };
    out.rules = lines.filter((l) => l.kind === 'grid' || l.kind === 'goalRule').map((l) => ({ kind: l.kind, y: r1(l.y1), gap: r1(lineGap(t.ink, l)) })).sort((a, b) => a.gap - b.gap).slice(0, 3);
    out.xAxisGap = r1(Math.min(...lines.filter((l) => l.kind === 'xAxis').map((l) => lineGap(t.ink, l))));
    out.splineGap = splinePts.length ? r1(Math.min(...splinePts.map(([x, y]) => pointGap(t.ink, x, y, 1)))) : null;
    out.dots = circles.map((c) => ({ cy: r1(c.cy), gap: r1(pointGap(t.ink, c.cx, c.cy, c.r)) }));
    out.bars = r1(Math.min(Infinity, ...rects.filter((r) => r.kind === 'bar' && r.b - r.t > 0).map((r) => boxGap(t.ink, r))));
    out.texts = texts.filter((o) => o !== t).map((o) => ({ role: o.role, value: o.value, gap: r1(boxGap(t.ink, o.ink)) })).sort((a, b) => a.gap - b.gap).slice(0, 2);
    out.outsideClip = clipRect ? { l: r1(clipRect.l - t.ink.l), r: r1(t.ink.r - clipRect.r), t: r1(clipRect.t - t.ink.t), b: r1(t.ink.b - clipRect.b) } : null;
    out.outsideSvg = { l: r1(svgRect.left - t.ink.l), r: r1(t.ink.r - svgRect.right), t: r1(svgRect.top - t.ink.t), b: r1(t.ink.b - svgRect.bottom) };
    return out;
  };

  const start = circles[0], end = circles[circles.length - 1];
  const startText = texts.find((t) => t.role === 'startValue');
  const endText = texts.find((t) => t.role === 'endValue');
  const drift = {
    start: startText && start ? r1((start.cy - 8) - startText.baseline) : null,
    end: endText && end ? r1(endText.baseline - (end.cy + 13 + 8.4)) : null
  };
  const textOverlaps = [];
  for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
    const g = boxGap(texts[i].ink, texts[j].ink);
    if (g < 2) textOverlaps.push({ a: texts[i].role + ':' + texts[i].value, b: texts[j].role + ':' + texts[j].value, gap: r1(g) });
  }
  const band = rects.find((r) => r.kind === 'band');
  const plotRight = Math.max(...lines.filter((l) => l.kind === 'grid').map((l) => Math.max(l.x1, l.x2)));
  const caption = root.querySelector('.mb-1');
  const capRect = caption?.getBoundingClientRect();
  const wrapper = root.getBoundingClientRect();
  const textWidths = texts.filter((t) => ['startValue', 'endValue', 'goalLabel'].includes(t.role)).map((t) => {
    const cs = getComputedStyle(t.el);
    const w = t.el.getComputedTextLength();
    ctx.font = `${cs.fontWeight} ${cs.fontSize} "IBM Plex Mono"`; const plex = ctx.measureText(t.value).width;
    ctx.font = `${cs.fontWeight} ${cs.fontSize} monospace`; const mono = ctx.measureText(t.value).width;
    ctx.font = `${cs.fontWeight} ${cs.fontSize} sans-serif`; const sans = ctx.measureText(t.value).width;
    return { v: t.value, rendered: r1(w), plex: r1(plex), monospaceFallback: r1(mono), sansFallback: r1(sans), family: cs.fontFamily, weight: cs.fontWeight };
  });
  const wr = root.getBoundingClientRect();
  return {
    href: location.href, scrollY, docBox: { x: wr.left + scrollX, y: wr.top + scrollY, w: wr.width, h: wr.height }, textWidths,
    status: document.querySelector('[role=status]')?.textContent?.trim() ?? null,
    alert: document.querySelector('[role=alert]')?.textContent?.trim() ?? null,
    bottomLine: document.querySelector('[aria-label="Bottom line"], section[aria-labelledby]')?.innerText?.replace(/\s+/g, ' ').slice(0, 260) ?? null,
    viewport: [innerWidth, innerHeight], theme: document.documentElement.dataset.theme,
    fontsReady: document.fonts.status, plexLoaded600: document.fonts.check('600 12px "IBM Plex Mono"'), plexLoaded400: document.fonts.check('400 11px "IBM Plex Mono"'),
    svg: box({ l: svgRect.left, t: svgRect.top, r: svgRect.right, b: svgRect.bottom }), container: box({ l: container.left, t: container.top, r: container.right, b: container.bottom }),
    wrapper: box({ l: wrapper.left, t: wrapper.top, r: wrapper.right, b: wrapper.bottom }),
    clipAncestors: clipAncestors.slice(0, 2),
    goalRule: lines.filter((l) => l.kind === 'goalRule').map((l) => ({ y: r1(l.y1), x1: r1(l.x1), x2: r1(l.x2), dash: l.dash, stroke: l.stroke, sw: l.sw })),
    grid: lines.filter((l) => l.kind === 'grid').map((l) => r1(l.y1)),
    dots: circles.map((c) => ({ cx: r1(c.cx), cy: r1(c.cy), r: c.r, fill: c.fill })),
    band: band ? { ...box(band), rightVsPlot: r1(band.r - plotRight), fill: band.fill } : null,
    caption: capRect ? { text: caption.innerText.replace(/\s+/g, ' '), box: box({ l: capRect.left, t: capRect.top, r: capRect.right, b: capRect.bottom }), gapToSvgTop: r1(svgRect.top - capRect.bottom), textAlign: getComputedStyle(caption).textAlign } : null,
    bars: rects.filter((r) => r.kind === 'bar').length, barsNonzero: rects.filter((r) => r.kind === 'bar' && r.b - r.t > 0.1).length,
    drift,
    labels: texts.filter((t) => ['startValue', 'endValue', 'goalLabel'].includes(t.role)).map(report),
    xTicks: texts.filter((t) => t.role === 'xTick').map((t) => t.value), yTicks: texts.filter((t) => t.role === 'yTick').map((t) => t.value),
    barCounts: texts.filter((t) => t.role === 'barCount').map((t) => ({ v: t.value, ink: box(t.ink) })),
    textOverlaps,
    srTable: [...root.querySelectorAll('.sr-only tbody tr')].map((tr) => [...tr.children].map((c) => c.textContent.trim()).join('|'))
  };
}
