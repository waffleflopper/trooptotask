# D13 context regression preparation

Detached source base: `303f562af9f470eea69b1d60fdb844501822258e`. Application paths remain unchanged. The only tracked edits are the two component test files in `preparation-report.json`; the generated `.svelte-kit` and `node_modules` symlink stay isolated/ignored.

Final focused command exercised only those two files using inert Supabase placeholders, disabled Vite cache, runner config loading, and scratch TMPDIR. It exited **1**: **2 suites / 57 cases; 36 failed, 21 passed, 0 skipped**. The 19 original cases pass, as do the two new same-context refresh controls. Every final recorded failure starts with an assertion failure; no deferred-stream clone, missing-query exception, happy-dom FileList exception or unhandled exception remains in those failure entries.

## Distinct protection

- Four families on Dashboard and dedicated pages: settled create then unsaved draft/transient rows do not follow another Person or another Organization/Person. File families also cannot post A's logical File for B merely because B enters a title.
- Four families on both surfaces: a deferred A create may finish, but cannot clear B's draft/file, expose A's returned record or hide B's loaded note.
- Dashboard Document and Counseling pickers: a 503 preserves the entered draft/file; successful retry uses the same multipart File and must clear the real picker. Both currently retain one selected file after success.
- Follow-ups: Person switch leaves hand-edit state; late hand-edit cannot clear/adopt into B; late status completion cannot clear B's independent pending action (Dashboard and dedicated page).
- Document Open: late A URL cannot open in B; the current B action still uses its exact current endpoint and opens its B URL (both surfaces).
- Archived: a settled Restore/Delete local override must not hide the next Org/Person's rows; an old deferred Restore/Delete cannot re-enable B's still-pending action. B's own completion still removes only its target, retaining its other archived row.
- Positive controls: same-context dedicated Document refresh retains draft/picker; same-context Dashboard stream refresh retains all four drafts and both actual submitted multipart Files.

## Actual red and evidence limits

All four family drafts and transient saved rows leak after reuse. All deferred create successes erase the new draft and expose A records; the single latest-note preview also hides B. Old hand-edit/status and Archived callbacks alter B state, and A Open callbacks call `window.open(A URL)`. Both Dashboard picker-success cases fail. Eight changed-context file cases observe a second POST despite no new B file selection. These are fake-fetch component outcomes, not native/file/database effects.

Earlier attempts remain in this scratch folder and are not final acceptance. Baseline 1's response clone mistake and baseline 2's happy-dom native validation exception are documented in `preparation-report.json`; final raw results/log are `baseline-final-results.json` / `baseline-final.log`. No skips or product implementation changes were added. Late errors, sign-out/destruction and same-ID Org-only reuse remain unrun here. Native positive B route reuse requires the coordinator's separate actor/fixture work; none is claimed by these tests. No server cancellation, transaction rollback or signed-URL revocation guarantee is imposed.

The exact patch is `d13-context-tests.patch`, SHA-256 `b7f36983ae94f19ca4c1b28017af75c1663951f5014b126d9c3663292aa345b0`. Full checks and live repaired-candidate proof remain with the coordinator after PR1472 merges.
