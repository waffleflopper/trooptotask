# D18 Settings unchanged baseline

Frozen application 110afc52152f27b4391bbb6ee3e0148b308043d2, tree-identical merged bc1cead38579df953b953766b12635f848846744. Node 24.21.0; Chromium 152; candidate 97901b43e10ea8cb00acb3206cecc037f5f67665db39ae4cfcbac1d608f5e432; owned origin 127.0.0.1:34049, session 45db49ad-e431-4649-83d7-f62241b88279. Launch and initial/final doctor PASS; cleanup PASS.

Setup: helper creates twelve temporary source rows and two actual counseling PDFs across A/B. Normal-form deletionRequester sign-in; three supported authenticated HTTP submissions against A Personnel/Training Type/Rating sources return 201. This is prerequisite HTTP setup, not native submission proof. orgSettingsSwitch signs in normally to native Settings/Approvals.

FAILED saved requester identification: persisted requested_by_email is the synthetic requester's email in all three 201 responses; initial and persisted native Settings read shows Unknown requester on all three exact descriptions.

FAILED request-bound draft: native Personnel Deny + fill Personnel-only reason, then Training Type Deny retains that reason. carried-draft.txt records the wrong target and value. No denial was sent with the wrong reason.

PASS synthetic response recovery: corrected Type draft Type denial baseline, exact review 503 injected before dispatch; error feedback appears and draft remains. fail-status.json identifies503; no source/status write was sent for that action.

FAILED pending controls/draft lifetime: exact native Personnel Approve sends real 200, held after server acknowledgment. dishonest-pending-controls.txt shows only that row's Approve disabled while Type Confirm/reason and other review actions remain enabled. Native fill changes Type draft while Personnel response is held. Release clears that unrelated draft and closes Type denial editor. Lost-draft snapshot/screenshot establishes loss, despite Type remaining pending. Provider readback shows Personnel approved/archived, Type and Rating pending, all three B sources unchanged with no requests. Native reload retains 2 pending/Archives 1 and unknown requester.

INCONCLUSIVE real offline transport control: native emulate Offline rejects because the owned browser origin allowlist/blocklist disables network throttling. offline.json preserves tool failure. No review was sent under purported offline conditions and no guard was removed. Separate new narrow synthetic transport rejection and deferred component tests must cover this failure seam; actual connection outage remains unrun.

No Organization-switch or true rejection live proof in this run. Existing all-five native review/denial/source-effect security baseline remains unchanged and separately identified by PR1498; this run does not re-claim it. Malformed/null error-body, stale route/Organization response, refresh failure and server atomicity are not established here.

Every review targets helper-created source IDs; no original fixture mutation was performed. Restored each network hook. clean-seeds reports success and sampled owned Personnel request readback is 0; final doctor uses same candidate/session and owned disposal PASS. Cleanup's ledger-bound command handles all recorded temporary source/request rows/PDFs; no claim of a full original-row-set snapshot is made in this run. No remote or existing local database was accessed. Raw captures are retained through disposal.
