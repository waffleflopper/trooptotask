# D15 unchanged packet baseline

Frozen application e6d467842e6bd2184827faf64540dec2775bbab1; candidate bf3f9d4f222e0ebd5eaa630bf37ed0cfc216e76da99173deeb78f90d20576946. Native owned verify:app worker 1 on October 1, 2026. All sign-in secrets excluded. No artifact redaction was needed; every actor/Organization/Person/row is synthetic. Environment metadata is deliberately whitelisted; private provider and fixture credential files are absent.

Read before/action/after artifacts by common filename prefix; action JSON contains native interaction and resulting snapshots. Snapshots/screenshot and exact provider rows distinguish UI from persistence. API-only results are explicitly named separately. tested-recipe.md preserves the actual driving-map bytes; the maintained recipe later corrects the discovered absent Kanban note editor. That instruction-only clarification is not a new live run.

## Results

- start-able: Operate without Personnel/Training lane started existing Able, Oct 1 date, A template, three fresh snapshots; required Training presence means one complete step. Checkbox completion and Paperwork Submitted -> Reviewed -> Filed -> Reviewed were driven natively. progress-reloaded captures saved 67%. Checkbox reversal was not driven.
- start-fail: POST 503, no new saved row. Start dialog closed, draft lost, no feedback observer entry. FAIL; manually opening a new form is not recovery.
- step-fail: PUT 503, optimistic Filed reverted to Reviewed, exact rows unchanged; no rendered feedback. FAIL for feedback, PASS for rollback.
- complete-fail: PUT 503, packet unchanged in-progress; incomplete-step confirmation closed, no feedback. FAIL.
- cancel-action/history: native cancel retained same packet/progress IDs and appeared in History. operate-api-transitions records API-only reopen200 and attributed note200, duplicate409 and configure-only resync403. Native complete-success confirmed the one-incomplete warning; History and Toggle Notes display retained note and 2/3 final progress alongside the original March3/3 witness.
- view/empty/scoped/no-lane: view detail readonly; Alpha scoped History contains only Alpha; empty History empty; no-lane entry denied. Valid authenticated denied start/lifecycle/step/resync and out-of-Group/unassigned/foreign Person probes returned403/404, with exact whole A packets/progress unchanged. Malformed400 is not claimed as access proof.
- foreign-start: native B actor started B Person using B template with incomplete Training. B stayed view-only for Switch. Foreign packet rows in foreign-packets.json equal hold-unchanged-B-packets.json before visible cancellation.
- hold: real A Baker POST persisted200, response held; native Organization switch to B showed one Foreign card. Released response added Unknown / TEMPLATE DELETED phantom second active card in B. B provider rows unchanged; B reload removed phantom. Native return A displayed saved Baker. FAIL client scope lifetime. Network release preserved underlying real200.
- operate-resync-native: visible Operate Re-sync action returned403. Server permission PASS; exposed configure affordance FAIL.

## Cleanup and limits

Both UI-created active Baker/Foreign packets were cancelled through their visible confirmations, read back with zero active packets in A/B. Able was completed and retained; no packet hard-delete UI exists. All hooks restored, clean-seeds returned no pending helper rows, exact original packet/progress witnesses retained. Final doctor PASS, cleanup PASS and no containers with the exact owned project label remain. Historical rows existed only until disposable provider destruction.

This verification-only outcome does not accept the failed product behaviors. Notes UI addition/failure is unreachable in the current main surface; source-only unused editor claims are excluded. Checkbox reversal, cancel/complete warning dismissal, Add Person, Configure reconciliation/legacy/null references, retention/service faults, Calendar/Dashboard/export reverse observations, permission revocation/multitab races and full SQL acceptance remain later D15 proof. Focused eleven suites/128 tests and seven existing native-control tests cover only their lower-level boundaries.
