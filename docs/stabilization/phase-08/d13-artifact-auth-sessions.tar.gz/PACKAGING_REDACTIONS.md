# Packaging and redactions

This archive was packaged after the run's final doctor, frozen-input checks, seed cleanup and owned disposal. Packaging adds no fresh application proof. The original ignored capture files remain unchanged.

Every original relative filename is retained. Apart from the token query-value replacements listed below, all original payload bytes are preserved exactly; no captures, request inputs, PDFs, screenshots or outcome fields were removed or rewritten. `ARTIFACT_SHA256SUMS` hashes the sanitized expanded payload files and excludes itself.

No additional packaging redactions were necessary. The original HTTP helper had already replaced the signed token in each of `16-download-positive-manager.json`, `16-download-positive-personnelScoped.json` and `16-download-positive-B.json`; each records `redactedValues: 1`. Those original bytes, including their markers, are preserved. Static fake token literals in the captured source patch are unchanged.
