import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { randomBytes } from 'node:crypto';
import { readJSON, writeJSON, processIdentity, sleep } from '../../scripts/verification/core.mjs';
import {
	assertLive,
	checkpoint,
	guardTurn,
	sameProcess,
	requireThat,
	fileDigest,
	cookieMiddleware,
	validatePreviewInfo,
	validateRunBinding,
	safeStartupCode
} from './transport.mjs';

let preview, timer, binding, helper, sidecarIdentity;
let alive = true;
let closing = false;
let bindingOwned = false;
async function shutdown(code) {
	if (closing) return;
	closing = true;
	alive = false;
	clearInterval(timer);
	try {
		preview?.httpServer.closeAllConnections();
		await preview?.close();
		if (binding && sidecarIdentity)
			await writeJSON(path.join(binding.runDirectory, 'sidecar.json'), {
				phase: 'stopped',
				reason: code,
				sidecar: sidecarIdentity,
				helper,
				sessionId: binding.sessionId,
				origin: binding.preview.url,
				stoppedAt: new Date().toISOString()
			});
		if (bindingOwned)
			for (const name of ['carrier.json', 'private-navigate.json', 'private-fill.json'])
				await fs.unlink(path.join(binding.runDirectory, name)).catch((error) => {
					if (error.code !== 'ENOENT') throw error;
				});
	} finally {
		process.exit(code === 'STOPPED' ? 0 : 2);
	}
}
for (const signal of ['SIGTERM', 'SIGINT'])
	process.on(signal, () => {
		void shutdown('STOPPED');
	});

async function relay(req, res) {
	const relayPrefix = '/__t2t_1503_fill/';
	if (!req.url?.startsWith(relayPrefix)) return false;
	const reject = () => {
		res.writeHead(404, { 'Cache-Control': 'no-store' }).end();
		return true;
	};
	if (req.method !== 'GET' || req.headers['sec-fetch-site'] !== 'same-origin') return reject();
	let referer;
	try {
		referer = new URL(req.headers.referer);
	} catch {
		return reject();
	}
	if (referer.origin !== binding.preview.url || referer.pathname !== '/auth/login') return reject();
	let carrier;
	const carrierPath = path.join(binding.runDirectory, 'carrier.json');
	try {
		carrier = await readJSON(carrierPath);
	} catch {
		return reject();
	}
	if (
		carrier.sessionId !== binding.sessionId ||
		carrier.role !== 'orgOwner' ||
		carrier.expiresAt < Date.now() ||
		req.url !== relayPrefix + carrier.capability
	)
		return reject();
	const claimed = path.join(binding.runDirectory, 'claimed-carrier.json');
	try {
		await fs.rename(carrierPath, claimed);
	} catch {
		return reject();
	}
	await fs.unlink(claimed);
	await fs.unlink(path.join(binding.runDirectory, 'private-navigate.json'));
	await assertLive(binding);
	const fixturePath = path.join(binding.session, 'fixtures.json');
	requireThat((await fileDigest(fixturePath)) === binding.fixtureDigest, 'FIXTURE_CHANGED');
	const fixture = await readJSON(fixturePath);
	const actor = fixture.actors.orgOwner;
	requireThat(typeof actor?.email === 'string' && typeof actor?.password === 'string', 'FIXTURE_UNAVAILABLE');
	await assertLive(binding);
	const payload = JSON.stringify(JSON.stringify({ email: actor.email, password: actor.password })).replaceAll(
		'<',
		'\\u003c'
	);
	const nonce = randomBytes(18).toString('base64');
	res.writeHead(200, {
		'Content-Type': 'text/html; charset=utf-8',
		'Cache-Control': 'no-store',
		'Referrer-Policy': 'no-referrer',
		'X-Content-Type-Options': 'nosniff',
		'Content-Security-Policy': `default-src 'none'; script-src 'nonce-${nonce}'; frame-ancestors 'none'`
	});
	res.end(`<!doctype html><script nonce="${nonce}">window.name=${payload};location.replace('/auth/login');</script>`);
	return true;
}

try {
	binding = await readJSON(process.argv[2]);
	validateRunBinding(binding);
	requireThat((await fs.realpath(binding.runDirectory)) === binding.runDirectory, 'RUN_PATH');
	bindingOwned = true;
	const info = validatePreviewInfo(JSON.parse(process.env.TAILSCALE_PREVIEW_INFO), binding.appCopy);
	requireThat(
		JSON.stringify(info) === JSON.stringify(binding.preview) &&
			process.env.APP_PUBLIC_ORIGIN === info.url &&
			process.env.NODE_ENV === 'production',
		'PREVIEW_ENVIRONMENT'
	);
	for (let attempt = 0; ; attempt++) {
		try {
			helper = (await readJSON(path.join(binding.runDirectory, 'helper.json'))).identity;
			break;
		} catch (error) {
			if (error.code !== 'ENOENT' || attempt >= 30) throw error;
			await sleep(100);
		}
	}
	requireThat(
		helper.pid === process.ppid && sameProcess(helper, await processIdentity(process.ppid)),
		'HELPER_CHANGED'
	);
	await checkpoint(binding);
	sidecarIdentity = await processIdentity(process.pid);
	const require = createRequire(path.join(binding.appCopy, 'package.json'));
	const vite = await import(pathToFileURL(require.resolve('vite')).href);
	preview = await vite.preview({
		root: binding.appCopy,
		mode: 'production',
		logLevel: 'silent',
		plugins: [
			{
				name: 't2t-1503-owned-mac-transport',
				enforce: 'pre',
				configurePreviewServer(server) {
					server.middlewares.use(
						cookieMiddleware({
							origin: info.url,
							prefix: binding.cookiePrefix,
							sessionId: binding.sessionId,
							alive: () => alive,
							relay
						})
					);
				}
			}
		],
		preview: {
			host: '127.0.0.1',
			port: info.local_port,
			strictPort: true,
			open: false,
			allowedHosts: [info.hostname],
			cors: false,
			https: { cert: await fs.readFile(info.cert_file), key: await fs.readFile(info.key_file) }
		}
	});
	requireThat(
		preview.config.preview.https && preview.httpServer.address().port === info.local_port,
		'NATIVE_TLS_UNAVAILABLE'
	);
	await checkpoint(binding);
	await writeJSON(path.join(binding.runDirectory, 'sidecar.json'), {
		phase: 'running',
		sessionId: binding.sessionId,
		origin: info.url,
		localPort: info.local_port,
		publicPort: info.public_port,
		nativeHTTPS: true,
		cookiePrefix: binding.cookiePrefix,
		candidate: binding.candidate,
		sourceDigest: binding.sourceDigest,
		buildDigest: binding.buildDigest,
		adapterDigest: binding.adapterDigest,
		sidecar: sidecarIdentity,
		helper,
		startedAt: new Date().toISOString()
	});
	let checking = false;
	timer = setInterval(async () => {
		if (checking || closing) return;
		checking = true;
		try {
			await guardTurn({ ...binding, helper }, () => shutdown('OWNERSHIP_LOST'));
		} finally {
			checking = false;
		}
	}, 1500);
} catch (error) {
	const code = safeStartupCode(error);
	if (bindingOwned) {
		try {
			await writeJSON(path.join(binding.runDirectory, 'startup-failure.json'), {
				phase: 'blocked',
				code,
				sessionId: binding.sessionId,
				recordedAt: new Date().toISOString()
			});
		} catch {
			console.error(JSON.stringify({ status: 'BLOCKED', code: 'START_FAILURE_RECEIPT_UNAVAILABLE' }));
		}
	}
	console.error(JSON.stringify({ status: 'BLOCKED', code }));
	await shutdown(code);
}
