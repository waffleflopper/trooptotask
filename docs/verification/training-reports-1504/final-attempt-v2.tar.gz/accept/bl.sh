#!/usr/bin/env bash
# summarize report snapshot: header line, bottom line, grid buttons, url
f=$1
grep -oE 'StaticText "[^"]*soldiers? · as of[^"]*"' $f | head -1
sed -n '/region "Bottom line"/,/readiness if no one renews"/p' $f | grep StaticText | sed 's/.*StaticText //' | tr '\n' ' '; echo
grep -oE '(button|radio) "[^"]*(ready today|checked)[^"]*"[^\n]*' $f | sed 's/ uid.*//' 
grep -E 'button "(Filter by|Clear filters)|radio .* checked|heading .* level="3"' $f | sed 's/^ *uid=[0-9_]* //'
