#!/usr/bin/env python3
"""Capture a latest ordinary business write before navigation; never persist headers."""
import json,os,re,subprocess,sys
from pathlib import Path
page,tag,method,family=sys.argv[1:5];page=int(page)
assert method in ['POST','PUT','DELETE'] and family in ['personnel-trainings','onboarding']
run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');b=Path('.verification/evidence/verify-trooptotask')/run
fixture=json.loads((b/'fixture-stdout.json').read_text());org=fixture['ids']['orgA']
a={'pageId':page}
subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','tool',tag+'-network-list','list_network_requests',json.dumps(a)],check=True,stdout=subprocess.DEVNULL)
x=json.loads((b/(tag+'-network-list-stdout.json')).read_text());text='\n'.join(c.get('text','') for c in x['content'])
lines=[line for line in text.splitlines() if re.search(r'\b'+method+r' http://127\.0\.0\.1:\d+/org/'+org+'/api/'+family+r' \[',line)]
if not lines:raise SystemExit('No exact native business request')
line=lines[-1];reqid=int(re.search(r'reqid=(\d+)',line).group(1));status=int(re.search(r'\[(\d+)\]',line).group(1))
request=b/(tag+'.network-request');response=b/(tag+'.network-response')
args={'pageId':page,'reqid':reqid,'requestFilePath':str(request),'responseFilePath':str(response)}
subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','network-body',tag+'-native-bodies',json.dumps(args)],check=True,stdout=subprocess.DEVNULL)
record={'worker':2,'pageId':page,'nativeRequestId':reqid,'method':method,'path':'/org/'+org+'/api/'+family,'status':status,'requestBodyFile':str(request),'responseBodyFile':str(response),'requestExists':request.exists(),'responseExists':response.exists()}
with (b/(tag+'-capture.json')).open('x') as f:json.dump(record,f,indent=2)
assert request.exists() and response.exists(),'Business response unavailable; outcome preserved'
record['request']=json.loads(request.read_text());record['response']=json.loads(response.read_text());print(json.dumps(record))
