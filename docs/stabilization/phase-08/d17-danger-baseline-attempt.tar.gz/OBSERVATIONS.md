Unchanged application at 069bf559, candidate d0d1e00f4cb14114f8832db99ae43008cb0d48c3676c0cdbc10def16ee6eae02, session ab735895-abeb-4af2-b0a7-1377b953bc6d, origin http://127.0.0.1:41059, Chromium 152.0.7977.82.

A ownership transferred normally from orgOwner to orgSettingsSwitch, with exact owner/admin membership witnesses. B transfer prerequisite failed: its shared account membership email was null; the actual Danger UI had no eligible member account. The attempted disabled-button click timed out and is preserved. Browser target-lifetime scenario was UNRUN, not passed or reproduced.

A ownership restored through ordinary UI to the same original orgOwner membership; orgSettingsSwitch restored to admin. B name and ownership remained original. Final doctor and owned cleanup PASS; clean-seeds completed. Ordinary transfers add audit/notification facts, so full fixture row equality is not claimed. Fixture correction and a new session are needed before the target-lifetime scenario.
