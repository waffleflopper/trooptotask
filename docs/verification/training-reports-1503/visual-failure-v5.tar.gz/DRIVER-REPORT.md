# 1503 independent chart acceptance v5 report

Driver notes for issue 1503 (parent 1433). These are interpretation, not raw captures. Evidence is in `.verification/evidence/verify-trooptotask/1503-final-chart-v5/driver/` (`png/`, `raw/`, `receipts/`, `downloads/`, `scripts/`). Untruncated tool input and output live in this delegated thread's supported T3 activity. The `raw/*condensed*` files are hand copies of sweep summaries and are labelled as such.

**Overall: FAIL.** The v5 goal-label correction works. A different legibility defect (D4) shows in the exact Goal 95 flat-100 state that failed v4. Do not declare 1503 complete.

## Identity

- Candidate `34438fcf…949f8f`, HEAD `d6a61861`, worker 1 session `34ec9b7e…57fc`, asOf 2026-10-03.
- Doctor and `command.mjs check` PASS at start (05:57Z) and end (06:31Z). Source `c5bcb977…`, output `f8890df8…`, adapter `7d4293a8…` unchanged. Seed lever `1fc8ad6f…` and source patch `0e56ee01…` unchanged.
- T3 preview `tab_3`. UA `Mozilla/5.0 (X11; Linux x86_64) … T3Code(Nightly)/0.0.46-nightly.20261004.2644 Chrome/152.0.7977.130 Electron/44.4.2`. DPR 1. Process date Sat 3 Oct 2026 21:59 AKDT (America/Anchorage). Page asOf "3 Oct 2026". Starting theme dark with localStorage `theme` unset.
- Actor orgOwner. One native login POST at about 05:59:19Z. One native Sign Out at about 06:31Z.

## Transport deviation (blocker for the supplied route)

The exact Mac HTTPS origin `https://omarchy.tail930090.ts.net:18031` returned **403 with an empty body** to the T3 tab. Root cause: the preview browser negotiates HTTP/2. Under Node's HTTP/2 compatibility layer the request carries `:authority` and no `Host`. `transport.mjs` `cookieMiddleware` requires `req.headers.host === expectedHost` and rejects. `curl --http1.1` gets 200 (with `X-T2T-1503-Session`). `curl --http2` gets 403 (`raw/01-transport-h1-vs-h2.txt`). `command.mjs check` passes because Node `fetch` uses HTTP/1.1. I did not edit the adapter.

The T3 preview client was running on this Linux host (X11 UA), not on the Mac. It reached the primary owned origin directly, so I drove `http://localhost:43125` (the same worker and candidate). Consequences:
- Cookie names were the app's original names, not the namespaced transport names.
- The private carrier was not used, and `stage` was never run. I used a one-shot localhost relay (`scripts/one-shot-relay.mjs`, the v4 method). It served once at 05:59:13Z and exited. It set `window.name`. A fill-only evaluate read and cleared `window.name` and filled email and password, returning booleans only. Sign In was then clicked natively. No credential appears in any tool argument, output or evidence file.
- No Mac-browser, Tailscale-route or HTTPS-scheme proof exists from this round.

## Outcome 1 (D3 goal label): PASS for D3. Outcome 1 overall FAIL because of D4.

### D3 (goal label versus plotted marks)
- Prior failures reproduced natively. Goal 85 and 95 were saved through Settings → Policies → Training Readiness, with the toast seen each time.
  - Goal 85, final bucket, 30 D, set with native Types, Duty role and 30 D clicks at 1440 dark. Screen-reader rows end "31 Oct 100% 0 No" and "2 Nov 50% 50 Yes", matching the receipt's lapse date 2026-11-02. The label is 37px from the line and 13px from the band. The turn into the drop, the end dot, "50%" and the bar count "50" are all fully visible (`png/01`, 1440 is 0.889 downscaled; `png/04` 390 light at 1:1).
  - Goal 95, flat 100, with native Duty role Medic and Types Required at 390 dark. The label is 8.8px from the end dot and 12.2px from "100%". The line no longer touches the glyphs (`png/05`).
  - Goal 95, final bucket, 30 D at 390 dark. The turn is unmasked and the label is 13px from the band (`png/06`).
- Labelled measurement sweeps, using in-page client navigation and `radio.click()`, at goals 85 and 95. They cover 1440, 1024 and 390, light and dark (theme set by native Toggle theme clicks), eight states (ordinary, saved view, mixed view plus dedicated role, Cliff, final bucket, flat 100, near-end flat 85 on goal 85, at-goal 85→75) and 30/60/90/180 D. That is 384 chart measurements (`raw/10`, `raw/11`).
  - Minimum gap to any line, area, dot, band, bar or text is **8.0px**. That is the nearEnd end dot sitting exactly on goal 85 (`png/02`). The label never overlaps. Edge slack is 3.6px everywhere. No ancestor clips it.
  - The label box measures 53.2px, against 52.8px from canvas `measureText`. It is vertically centred on the rule, 1.6–1.7px below because of the descender box.
  - The band never overruns the plot (overrun ≤ 0).
- Fonts. Loaded faces include IBM Plex Mono 400/500/600. The goal label computes `"IBM Plex Mono", monospace`, 11px, weight 400. In a reversible probe I set an inline `font-family` and restored it. Generic `monospace`, Courier New and DejaVu Sans Mono all measure 53.2px; sans-serif measures 48.5px and serif 44.3px. None clip. The SVG overflow is `visible`.
- Contrast (canvas-composited computed colours). Light: label 7.31:1 and rule 3.08:1. Dark: label 7.64:1 and rule 6.14:1. Paper's success green as text would be 3.08:1 in light, which supports the earlier muted-text amendment.
- At 1024 and 180 D the plot is 214px. Bars are 5.8px wide. Counts "139" and "50" sit 8.1px apart and both render. Month ticks thin to "Today · 3 Oct", "1 Feb" and "1 Apr" (`png/03`). 180 days needs about 41px per month label and gets about 36px. The v4 240px plot would get about 40px, so it would also thin. The narrowing is real but costs little legibility.

### D4 (new): the goal rule strikes through the end-value label
- In the Goal 95 flat-100 state, the green dashed goal rule passes through the middle of the green end label "100%". At 390 the rule is at y 315.4 and the text spans 310.9–325.9. It happens at every width, theme and horizon (24 of 24 flat-100 measurements; `png/05`, `png/07`). Rule and text are both success green, with 2.37:1 between them in light, so the dashes merge into the glyphs.
- Cause: the end label is placed at `yScale(last) + 10` and is unaware of the goal rule. Whenever the end value sits a few points above the goal, the rule crosses it. This placement predates v5. v5 did not cause it, but v5 did not fix the "Goal 95 flat 100" failure state as a whole.
- This is the same strikethrough legibility class v4 was failed for. No other state at goal 85 or 95 crossed text. Goals 1 and 100 were not run.

### Paper relationship
Paper read-only (file `01M3HXNN6A4S0FTNQ88XS9YJ9X`, artboard S8-1, Annotations frame; `raw/paper-readonly.json`, `png/paper-annotations-scale2.jpg`):
- Paper's "Goal 90%" is 11px IBM Plex Mono 500 in `--color-success`. It is right-aligned in a 120px box at x 620–740 of the 752px frame, above the dashed line's right end, inside the plot.
- v5 keeps the copy, family, size, single line and the right-end association. The label now continues the line horizontally, 13px past its end and centred on it, instead of sitting above it.
- Paper's data (78→66, goal 90) never reaches the goal, so Paper never exercises the conflict.
- I judge this a routine legibility placement, not a product tradeoff. The label reads as a line-end label and stays tied to its rule at every width. The weight (400 vs 500) and colour (muted vs success) differences are the existing amendment.

## Outcome 2 (D1, D2, smoke, export): PASS, with one qualified 390 observation
- D1 used an in-page fetch wrapper that held one summary GET or returned one synthetic 503, with native radio and Retry clicks, at all three widths in both themes (`raw/12`).
  - Pending: "Updating briefing" fills the reserved slot.
  - Error: the alert sits below the toolbar, the radio reverts to the loaded briefing, the URL is unchanged, and a native Retry returns 200 and applies the attempted horizon.
  - Every control hit-tests itself. Nothing moved between steady, pending and error in five of six combinations.
  - At 390 dark, one idle baseline captured right after a theme toggle had Export wrapped to its own row. Later idle and pending measurements had it on the Clear row. The 390 actions row has only 4.3px slack. This matches the prior unresolved "390 Clear/Export shift" and sits outside the chart change. All targets stayed reachable.
- D2: caption bottom is above the SVG top, and there are no text/text or text/bar overlaps and no text outside the SVG in any D1 state.
- Smoke:
  - A full load of a filtered URL made no summary or `__data` request. The SSR HTML already holds 74%, the screen-reader table and the view name, with no Foreign data. The chart SVG renders on the client, as in v4.
  - Each native filter selection made exactly one summary GET.
  - A reload of `?group=Alpha&types=Required` restored the chips and 1% with no summary GET.
  - A native cell click made one detail GET (`scope=cell&row=<Alpha>&type=<At goal 85>`, 200), with no record IDs in the URL. The status read "25 requirements not ready or lapsing by 1 Jan" (15 not ready plus 10 lapsing).
  - No hydration warnings appear in the retained console. The tool truncated 108 older entries.
- Export was triggered by the visible button after native filters and a reload.
  - Request: GET `/export?group=<Alpha>&types=<Required>` returned 200, xlsx, `attachment; filename="training-report-2026-10-03.xlsx"`, `private, no-store`.
  - Response bytes and the Blob handed to download are both 9,431 bytes with sha256 `24bbdd47…2502` (`downloads/training-report-alpha-required.xlsx`).
  - Contents: one sheet, "Training Report". Headers Name, Rank, MOS, Duty Role, Group, Verification Required Training. 101 Alpha rows: Able, Synthetic | SPC | 68W | Medic | Alpha | "Current (2027-09-26)" (equal to `trainingExpires`), plus 100 seeded "Not Done" rows. No Baker or Foreign rows.
- Keyboard and focus-visible were not exercised this round. The prior qualification stands.

## Outcome 3 (contracts): PASS
- The v4→v5 patch differs only in `ReportForecastChart.svelte` and `OnboardingInteraction.svelte.test.ts` (test-only, from the main merge; `raw/03`).
- The chart's only consumer is `TrainingReportsPage.svelte:394`, and its props are unchanged.
- Math matches the receipt: mixed 74→61, final bucket 100→50 with 50 lapses on 2 Nov at 30 D, Cliff 100→50, Rounding 85% (11 of 13 within the dedicated role). Without the role, the 68W filter reads 73%, which is 11 of 15 because the base fixture adds Able and Unassigned.
- Server auth, API failure, race and scoped-actor proof remain v3 candidate-qualified supplements and were not re-executed here.

## Restoration
- The goal was restored to 90 natively (toast at 06:22:12Z). Helper readback of Org A and B rows equals root's `root-organizations-org{A,B}-original.json` exactly (`receipts/`).
- The fetch and createObjectURL hooks were removed, and the saved original references restored. All `__drv5` sessionStorage keys and driver globals were deleted. localStorage `theme` was removed, back to the unset start, and `data-theme` is dark. `window.name` is empty.
- Native Sign Out was followed by navigation to a protected route, which redirected to `/auth/login` (06:31:29Z).
- The worker, transport and seeded rows are left running for root.

## Harness events
- In-page `setTimeout` was heavily throttled because the preview is hidden. I switched to MessageChannel waits.
- The 15s evaluate cap and two transient "no automation host" or "failed on client" errors occurred. All recovered without a page reset.
- One early sweep used too short a client-navigation wait and read stale data. Those rows are discarded, and every reported row comes from reruns.

## Unresolved objections
1. **D4 must be fixed before acceptance.** Keep the end-value label clear of the goal rule. For example, place it on whichever side of the dot the rule is not on, or apply the gutter idea consistently. Then repeat the flat-100 / goal-95 check.
2. **The Mac transport rejects HTTP/2 (Chromium) with 403.** It needs `:authority` handling, or forcing HTTP/1.1, before any Mac-route proof. This round's proof is on the primary origin.
3. The 390 actions row has 4.3px slack and can wrap (prior item).
4. Not run this round: goals 1 and 100, keyboard focus-visible, and the full untruncated console history.
