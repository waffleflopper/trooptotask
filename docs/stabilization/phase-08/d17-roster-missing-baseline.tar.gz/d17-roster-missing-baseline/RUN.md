# Missing old roster scan: failing baseline

The ordinary roster manager could not replace a saved signed scan after its old Storage object had already been removed. The real signed-in-page FormData POST returned HTTP 500. Before/after roster captures are byte-identical and retain the dangling old path; the before/after roster-file scans both contain an empty `files` array. This is a failing baseline, not final behavioral acceptance.

The frozen application base is `0770e7a888b41e99f49c96218485674f927b899e`; candidate `2946084418fc36da5ef3d89a2e680da4d32dd90aa2cdec4a278e4756d2a276d2` adds three verification driving inputs and five documentation changes, with no application or SQL patch. Worker session `026771dc-2079-4010-9e7c-06e9edd533d2` ran at `http://127.0.0.1:43137` in Chromium 152.0.7977.82.

`old-object-removed.json` records acknowledged ordinary removal of the owned synthetic Alpha roster scan and empty two-bucket metadata scans. `replacement-request.json` separately records scoped service SDK `info` for that old path: `StorageApiError`, HTTP status 400, embedded statusCode "404", message "Object not found". Its replacement PDF is 3,192 bytes, SHA-256 `06bb821fed9ad409383add6cad7805308426885d766d35f131ca32d6934a7235`; that exact PDF is included.

Native browser snapshots show the manager's Training page, opening Sign-In Rosters, and expanding Alpha after the failed request; Alpha still shows the old `verification-signed.pdf` label. Replacement itself used the documented narrow `roster-replace` ordinary signed-in-page HTTP helper, not a native file-input upload. The driver reported sole page control and no navigation between the helper's origin check and request. An additional in-request origin check was added later for the final run and is intentionally absent from these recovered baseline driving inputs.

Initial/final doctor receipts and owned cleanup report PASS. Seed cleanup reports `cleaned: true` and `artifactHttpSessionsCleared: true`. Empty Storage metadata scans are recorded as such; they do not independently inspect all physical orphan versions.

All original captures and candidate.patch are preserved byte-for-byte. `driving-inputs` contains the exact baseline SKILL, roster recipe and control helper recovered by applying the frozen patch to the full base in scratch; SOURCE-INPUTS.json records preimage/postimage identities. No current final-run source was substituted. PRIVACY-REVIEW.json records the privacy scan and zero redactions.

INVENTORY.json lists the exact payload filenames, SHA-256 and byte lengths, excluding only itself to avoid a self-hash cycle. After extraction, run `python3 VERIFY-PAYLOAD.py .` from this directory. Packaging verification confirms member set and bytes; it does not add independent live application execution.
