from pathlib import Path
import hashlib, json, os, re, sys

ROOT = Path(__file__).resolve().parents[3]
assert Path.cwd() == ROOT
name = os.environ['D15_EVIDENCE']
assert re.fullmatch(r'd15-overlap-[a-z0-9-]+', name)
E = ROOT / '.verification/evidence/verify-trooptotask' / name
E.mkdir(parents=True, exist_ok=True)
assert E.resolve() == E and E.stat().st_uid == os.getuid()
paths = [
    '.verification/tmp/d15-overlap/launch.mjs',
    '.verification/tmp/d15-overlap/drive.py',
    '.verification/tmp/d15-overlap/overlap.py',
    '.verification/tmp/d15-overlap/provider-hold.py',
    '.verification/tmp/d15-packets/owned-onboarding-http.mjs',
    '.verification/tmp/d15-packets/onboarding-http.mjs',
    *[f'.verification/tmp/d15-lifecycle/{name}.py' for name in
      ['freeze', 'initialize', 'journeys', 'overlap-readback', 'sequential', 'cleanup']]
]
if sys.argv[1:] == ['compare']:
    expected = json.loads((E / 'driving-input-hashes.json').read_text())
    problems = [entry['path'] for entry in expected['entries']
                if hashlib.sha256((ROOT / entry['path']).read_bytes()).hexdigest() != entry['sha256']]
    with (E / 'driving-input-comparison.json').open('x') as output:
        json.dump({'result': 'FAIL' if problems else 'PASS', 'inputs': len(expected['entries']), 'changed': problems}, output, indent=2)
        output.write('\n')
    assert not problems, problems
else:
    assert not sys.argv[1:]
    entries = []
    for relative in paths:
        file = ROOT / relative
        assert file.is_file() and file.resolve() == file
        content = file.read_bytes()
        destination = E / 'driving-inputs' / relative.removeprefix('.verification/tmp/')
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output:
            output.write(content)
        entries.append({'path': relative, 'sha256': hashlib.sha256(content).hexdigest(), 'copy': destination.relative_to(E).as_posix()})
    with (E / 'driving-input-hashes.json').open('x') as output:
        json.dump({'scope': 'Exact ignored normal-session, holder, native driving and cleanup inputs; repository source/recipes separately frozen by launch', 'entries': entries}, output, indent=2)
        output.write('\n')
print('Driving inputs frozen/compared without modifying the application.', flush=True)
