import { createClient } from '@supabase/supabase-js';
import { createSupabaseStorageAdapter } from '../../../../src/lib/server/adapters/supabaseStorage.ts';
const rows = [];
for (const [name, reply, kind, expected] of [
  ['privileged missing key', [], 'remove', 'resolve'],
  ['malformed deletion object', {}, 'remove', 'reject'],
  ['unrequested deletion key', [{name: 'other/key.pdf'}], 'remove', 'reject'],
  ['missing signing path', {}, 'sign', 'reject'],
  ['empty signing token', {signedURL: '/object/sign/counseling-files/org/scan.pdf?token='}, 'sign', 'reject']
]) {
  const client=createClient('http://storage.invalid', 'synthetic-key', {
    auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},
    global:{fetch:async()=>Response.json(reply)}
  });
  const storage=createSupabaseStorageAdapter(client);
  let observed='resolve';
  try { if(kind==='remove') await storage.remove('counseling-files',['org/scan.pdf']);
    else await storage.createSignedUrl('counseling-files','org/scan.pdf',300);
  } catch { observed='reject'; }
  rows.push({name,expected,observed,result:expected===observed?'PASS':'FAIL'});
}
console.log(JSON.stringify({boundary:'Actual SDK with finite no-network HTTP replies; no RLS or UI claim',rows},null,2));
process.exitCode=rows.some(r=>r.result==='FAIL')?1:0;
