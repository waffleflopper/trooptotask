SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_remove_fault_867114fc_ad176e6b() RETURNS trigger LANGUAGE plpgsql SET search_path='' AS $removal$
BEGIN
 RAISE EXCEPTION USING ERRCODE='P0001', MESSAGE='t2t-d15 intentional owned progress-delete fault';
END;
$removal$;
COMMENT ON FUNCTION public.t2t_d15_remove_fault_867114fc_ad176e6b() IS '{"container_id": "479d8ad71759bf0d26f33a1ff84c8f2a2c8ae7877007332ae5954ba5b7e8edb9", "organization_id": "fd7f9741-f1ee-4c59-aab3-3b8a037eabc2", "packet_id": "b67e4df0-8c2b-4d6d-98c4-f8d3e2daa207", "project": "t2t-verify-df6ae04743df4c44ad9b95c4", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "010ec577c6d88a81d82867cd125fd2736c4d466438140fc5b18e826b2222b84e", "session_id": "ad176e6b-d960-49aa-89b7-2f198a96c760", "step_id": "e0084932-64b3-4386-aa87-f184f335dfa6", "worker": "2"}';
CREATE TRIGGER t2t_d15_remove_fault_867114fc_ad176e6b BEFORE DELETE ON public.onboarding_step_progress FOR EACH ROW
WHEN (OLD.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND OLD.onboarding_id='b67e4df0-8c2b-4d6d-98c4-f8d3e2daa207'::uuid
 AND OLD.id='e0084932-64b3-4386-aa87-f184f335dfa6'::uuid) EXECUTE FUNCTION public.t2t_d15_remove_fault_867114fc_ad176e6b();
COMMENT ON TRIGGER t2t_d15_remove_fault_867114fc_ad176e6b ON public.onboarding_step_progress IS '{"container_id": "479d8ad71759bf0d26f33a1ff84c8f2a2c8ae7877007332ae5954ba5b7e8edb9", "organization_id": "fd7f9741-f1ee-4c59-aab3-3b8a037eabc2", "packet_id": "b67e4df0-8c2b-4d6d-98c4-f8d3e2daa207", "project": "t2t-verify-df6ae04743df4c44ad9b95c4", "repository": "/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-f30ee413", "seed_sha256": "010ec577c6d88a81d82867cd125fd2736c4d466438140fc5b18e826b2222b84e", "session_id": "ad176e6b-d960-49aa-89b7-2f198a96c760", "step_id": "e0084932-64b3-4386-aa87-f184f335dfa6", "worker": "2"}';
COMMIT;
SELECT json_build_object('event','fault-installed');
