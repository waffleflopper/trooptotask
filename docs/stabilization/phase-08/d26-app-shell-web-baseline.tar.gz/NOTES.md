# D26 AppShell Web baseline

Unchanged revision 162e41abbc4cc621fc2d2500ed4acf53a46c843d, candidate e379dc632eaddfbcdb8ccb2c164743b304ab9052569234f2ac7a845b431d1df3. Owned production build, synthetic provider and Chromium 152.0.7977.82 at http://127.0.0.1:36635, session747260ec-6dc1-45a7-b617-41b8776ed482. No production provider, personal browser or external Feedback mirror.

The notificationSwitch actor showed A one unread and B one unread; while the real A count response was held, B marked its notification read and showed zero. Releasing A preserved B zero (PASS). Home and Account remained usable during the held optional read.

Holding a real A Feedback POST, then native browser Back to B, retained A's submitting dialog. Release produced the success toast in B (FAIL). Privileged synthetic readback confirms one A-owned Feedback row, no GitHub issue; it persisted until disposable-provider cleanup because no ordinary member delete control exists.

At 390x844, native Home selection left the mobile drawer open. Escape and a later settled snapshot also left it open (FAIL). Read-only rendered layer inspection found an enabled hidden Dashboard tooltip above the drawer. This suggests an Escape interception cause; final proof must establish repaired behavior.

Seven separately signed-in consumer entry captures cover Training, Calendar settings/bulk, ICT library, scoped Personnel, Onboarding and Rating Scheme. These are entry/scoped-render observations, not mutation or authorization proof. Existing lower-level and prior accepted security evidence remain separate.

Retain all captures including inconclusive layer probes53-55. Probe53 had a filename collision; probe54 inspected the Map value rather than its layer key;55 confirmed the value was the close behavior. Correct probes56-57 inspect layer keys and rendered elements. Do not credit53-55 as valid payload evidence.

Network and toast controls were restored. Helper clean-seeds succeeded; readback retained only the UI-created A Feedback described above. Final doctor passed with the same digest and owned cleanup passed. The disposable provider and browser were removed.
