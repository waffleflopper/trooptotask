import json,collections,hashlib,re
from pathlib import Path
P=Path('.verification/evidence/verify-trooptotask/d24-export-baseline');O=Path('.verification/tmp/d24-artifact-review');load=lambda n:json.loads((P/n).read_text());issues=[];checks=[]
sources={p.name[len('source-before-'):-len('-A.json')]:json.loads(p.read_text())['rows'] for p in P.glob('source-before-*-A.json')}
people={r['id']:r for r in sources['personnel']};groups={r['id']:r['name'] for r in sources['groups']};statuses={r['id']:r['name'] for r in sources['status_types']};types={r['id']:r['name'] for r in sources['training_types']};tasks={r['id']:r['title'] for r in sources['ict_tasks']};assignments={r['id']:r for r in sources['assignment_types']}
def person(i):
 r=people.get(i);return ' '.join(str(x) for x in [r.get('rank'),r.get('last_name','')+',',r.get('first_name')] if x) if r else (i or '')
def blank(v):return None if v=='' else v
def pack(rows):return collections.Counter(json.dumps({k:blank(v) for k,v in r.items()},sort_keys=True) for r in rows)
expected={
'Personnel':[{'Rank':r['rank'],'Last Name':r['last_name'],'First Name':r['first_name'],'Mos':r['mos'],'Duty Role':r['clinic_role'],'Group':groups.get(r['group_id'],r['group_id'] or ''),'ETS':r['ets'] or '', 'PCS / DEROS':r['deros'] or '', 'Archived At':r['archived_at'] or '', 'Leader Notes':''} for r in sources['personnel']],
'Calendar':[{'Person':person(r['personnel_id']),'Status':statuses.get(r['status_type_id'],r['status_type_id']),'Start Date':r['start_date'],'End Date':r['end_date'],'Note':r['note'] or ''} for r in sources['availability_entries']],
'Training Records':[{'Person':person(r['personnel_id']),'Training Type':types.get(r['training_type_id'],r['training_type_id']),'Completion Date':r['completion_date'],'Expiration Date':r['expiration_date'],'Notes':r['notes'],'Certificate Url':r['certificate_url']} for r in sources['personnel_trainings']],
'Daily Assignments':[{'Date':r['date'],'Assignee':groups.get(r['assignee_id'],r['assignee_id']) if assignments[r['assignment_type_id']]['assign_to']=='group' else person(r['assignee_id']),'Assignment Type':assignments[r['assignment_type_id']]['name']} for r in sources['daily_assignments']],
'Counseling Records':[{'Person':person(r['personnel_id']),'Date Conducted':r['date_conducted'],'Subject':r['subject'],'Key Points':r['key_points'],'Plan Of Action':r['plan_of_action'],'Status':r['status'],'Notes':r['notes']} for r in sources['counseling_records']],
'Leader Notes':[{'Person':person(r['personnel_id']),'Author':r['author'],'Text':r['text'],'Created At':r['created_at'],'Archived At':r['archived_at']} for r in sources['leader_notes']],
'Personnel Follow-ups':[{'Person':person(r['personnel_id']),'Title':r['title'],'Notes':r['notes'],'Due Date':r['due_date'],'Status':r['status'],'Created At':r['created_at'],'Completed At':r['completed_at'],'Archived At':r['archived_at']} for r in sources['personnel_follow_ups']],
'Personnel Documents':[{'Person':person(r['personnel_id']),'Title':r['title'],'File Name':re.split(r'[/\\]',r['file_path'])[-1],'File Size Bytes':r['file_size_bytes'],'Content Type':r['content_type'],'Uploaded By':r['uploaded_by'],'Created At':r['created_at'],'Archived At':r['archived_at']} for r in sources['personnel_documents']],
'Onboarding Progress':[{'Person':person(r['personnel_id']),'Status':r['status'],'Started At':r['started_at'],'Completed At':r['completed_at'],'Cancelled At':r['cancelled_at']} for r in sources['personnel_onboardings']],
'Critical Task Completions':[{'Person':person(r['personnel_id']),'Task':tasks[r['ict_task_id']],'Completed At':r['completed_at'],'Validation Method':r['validation_method'],'Validated By':r['validated_by'],'Notes':r['notes']} for r in sources['personnel_ict_completions']],
'Rating Scheme':[{'Person':person(r['rated_person_id']),'Eval Type':r['eval_type'],'Report Type':r['report_type'],'Rater':person(r['rater_person_id']) or r['rater_name'],'Senior Rater':person(r['senior_rater_person_id']) or r['senior_rater_name'],'Intermediate Rater':person(r['intermediate_rater_person_id']) or r['intermediate_rater_name'],'Reviewer':person(r['reviewer_person_id']) or r['reviewer_name'],'Rating Period Start':r['rating_period_start'],'Rating Period End':r['rating_period_end'],'Status':r['status'],'Workflow Status':r['workflow_status'],'Notes':r['notes']} for r in sources['rating_scheme_entries']]
}
for artifact in ['owner-a','admin-a']:
 book=json.loads((O/(artifact+'-expanded.json')).read_text())['sheets'];payload=load(artifact+'.json');sheets={s['name']:s for s in book}
 for name,expected_rows in expected.items():
  sheet=sheets[name];selected_keys=list(expected_rows[0]) if expected_rows else []
  actual=[]
  for row in sheet['rows']:
   padded=row+[None]*(len(sheet['headers'])-len(row));m=dict(zip(sheet['headers'],padded));actual.append({k:m.get(k) for k in selected_keys})
  if pack(actual)!=pack(expected_rows):issues.append({'artifact':artifact,'readable_sheet':name,'error':'literal_readable_projection'})
  checks.append({'artifact':artifact,'readable_sheet':name,'rows':len(actual),'fields':selected_keys,'expected_from':'independent stored source rows and recorded identity/label semantics'})
 owner_feedback=load('owner-feedback-source.json');owner_uid=owner_feedback['userId'];admin_uid=next(r['requested_by'] for r in load('admin-json-lifecycle.json')['rows'] if r['id'] not in {x['id'] for x in load('before-admin-json-data_exports.json')['rows']})
 actor_uid=owner_uid if artifact=='owner-a' else admin_uid
 raw_feedback=payload['sections']['betaFeedback'];observed=[r for r in owner_feedback['feedback'] if r['organization_id']==payload['organizationId']]
 if artifact=='owner-a':
  if {r['id'] for r in raw_feedback}!={r['id'] for r in observed}:issues.append({'artifact':artifact,'error':'owner_feedback_ids'})
  for row in observed:
   actual=next((r for r in raw_feedback if r['id']==row['id']),{})
   if any(actual.get(k)!=v for k,v in row.items()):issues.append({'artifact':artifact,'error':'owner_feedback_source_fields'})
 else:
  if raw_feedback:issues.append({'artifact':artifact,'error':'admin_peer_feedback_visible'})
 notification_file='source-before-notifications-A.json' if artifact=='owner-a' else 'before-admin-json-notifications.json';notification_sources=load(notification_file)['rows'];expected_notifications=[r for r in notification_sources if r['user_id']==actor_uid];actual_notifications=payload['sections']['notifications']
 if actual_notifications!=expected_notifications:issues.append({'artifact':artifact,'error':'recipient_visible_notifications'})
 checks.append({'artifact':artifact,'notification_actor':actor_uid,'recipient_rows':len(actual_notifications),'peer_notification_rows_excluded':len(notification_sources)-len(expected_notifications),'feedback_rows':len(raw_feedback),'owner_feedback_source_fields':len(observed[0]) if observed and artifact=='owner-a' else 0,'feedback_unreadback_fields':sorted(set(raw_feedback[0])-set(observed[0])) if raw_feedback and observed else []})
 foreign_rows={r['id'] for f in P.glob('source-before-*-B.json') for r in json.loads(f.read_text())['rows'] if 'id' in r}
 actual_rowids={r['id'] for rows in payload['sections'].values() for r in rows if 'id' in r}
 foreign_labels=['Foreign Private Status','Foreign Private Training','orgB active context d7123984 note','orgB archived context d7123984 note','MapContextForeignd7123984']
 if foreign_rows & actual_rowids:issues.append({'artifact':artifact,'error':'foreign_source_row_ids','ids':sorted(foreign_rows&actual_rowids)})
 if any(x in json.dumps(payload) or x in json.dumps(book) for x in foreign_labels):issues.append({'artifact':artifact,'error':'foreign_private_labels'})
 audits=payload['sections']['auditLogs'];before={r['id']:r for r in sources['audit_logs']}
 if artifact=='owner-a':
  for r in audits:
   if r['id'] in before and r!=before[r['id']]:issues.append({'artifact':artifact,'error':'stored_audit_row_changed'})
  if not set(before)<=set(r['id'] for r in audits):issues.append({'artifact':artifact,'error':'stored_audit_rows_missing'})
result={'issues':issues,'checks':checks,'historic_foreign_reference_disposition':'Three B resource UUIDs appear only in two recorded A-owned seeded Audit rows. Exact raw stored details are preserved; foreign source row IDs and private labels are absent. Blanket identifier absence is false and not the retained raw-Audit contract.','pagination_limit':'training-pages seeds26 Personnel and total Personnel32; no1000-row provider-page boundary was exercised.'}
(O/'readable-and-scope-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'issues':issues,'readable_sheet_checks':len([c for c in checks if 'readable_sheet' in c]),'scope_checks':[c for c in checks if 'notification_actor' in c]}))
