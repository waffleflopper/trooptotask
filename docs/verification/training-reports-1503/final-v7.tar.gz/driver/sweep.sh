#!/usr/bin/env bash
# usage: sweep.sh GOAL THEME "WIDTHS" "STATES" "HORIZONS" SHOT(0|1)
# Native navigate_page to URL-kept state, native emulate viewport, read-only measure, optional full-page screenshot cropped to forecast.
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7; D=$E/driver/d.sh; cd $ROOT
G=$1; TH=$2; WIDTHS=$3; STATES=$4; HS=$5; SHOT=${6:-0}
O=http://127.0.0.1:42057/org/fd246961-a47d-4153-8599-98e413bf9cdb/training/reports
ROLE=BriefingBoundaryc30522a4; VID=9abba8b1-3e91-4fe0-9d81-50346321846a
declare -A Q=(
 [ordinary]="" [view]="view=$VID" [mixed]="view=$VID&role=$ROLE"
 [cliff]="types=83e9e6c4-6d3d-405a-a4e3-0771e7eb13ae" [final]="role=$ROLE&types=2feee423-18f6-4b32-ae4b-9c1f4b856031"
 [flat100]="role=Medic&types=19e0c47c-5a80-46de-83dc-55c1cf356b3d" [nearEnd]="role=$ROLE&types=dbe316e1-423d-4fb6-a270-fe4bd37ceabe"
 [atGoal]="role=$ROLE&types=c1fa81e8-b1ea-4e3c-b6b1-3dfd43a31ed5" [drop9]="role=$ROLE&types=3c282de3-6d8c-415e-aab3-88de7d8dafee"
)
mkdir -p $E/measure/sweep $E/png/sweep
for W in $WIDTHS; do
  $D "emulate-$W" -- npm run --silent verify:app -- tool emulate "{\"pageId\":2,\"viewport\":\"${W}x${VH:-2400}x1\"}" --worker 1 >/dev/null
  for S in $STATES; do for H in $HS; do
    q=${Q[$S]}; [ "$H" != 90 ] && q="${q:+$q&}horizon=$H"
    url="$O${q:+?$q}"; lab="g$G-$TH-$W-$S-$H"
    $D "nav-$lab" -- npm run --silent verify:app -- tool navigate_page "$(jq -cn --arg u "$url" '{pageId:2,type:"url",url:$u}')" --worker 1 >/dev/null || echo "NAVFAIL $lab"
    args=$(jq -n --rawfile f "$E/driver/measure.js" --arg fp "$E/measure/sweep/$lab.json" '{pageId:2,function:$f,filePath:$fp}')
    $D "measure-$lab" -- npm run --silent verify:app -- tool evaluate_script "$args" --worker 1 >/dev/null || echo "MEASFAIL $lab"
    if [ "$SHOT" = 1 ]; then
      $D "shot-$lab" -- npm run --silent verify:app -- tool take_screenshot "{\"pageId\":2,\"fullPage\":true,\"filePath\":\".verification/evidence/verify-trooptotask/1503-final-chart-v7/tmp/full.png\"}" --worker 1 >/dev/null
      geo=$(jq -r '.docBox | "\((.w+16)|floor)x\((.h+8)|floor)+\((.x-8)|floor)+\((.y-4)|floor)"' $E/measure/sweep/$lab.json)
      magick .verification/evidence/verify-trooptotask/1503-final-chart-v7/tmp/full.png -crop "$geo" +repage "$E/png/sweep/$lab.png"
    fi
    echo -n "."
  done; done
done
echo " done $G $TH"
