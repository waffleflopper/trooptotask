export async function request(input) {
 const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
 if (location.origin !== input.origin || !/^http:\/\/127\.0\.0\.1:\d+$/.test(input.origin)) throw Error('Wrong owned origin');
 if (!uuid.test(input.org) || !input.organizations.some(x => x.id === input.org && x.segment === input.organizationSegment) || input.organizations.length !== 2 || !input.organizations.every(x => uuid.test(x.id) && /^[a-z0-9-]+$/.test(x.segment))) throw Error('Wrong synthetic Organization');
 const current = location.pathname.split('/');
 if (current[1] !== 'org' || !input.organizations.some(x => current[2] === x.id || current[2] === x.segment)) throw Error('Use an owned Organization page');
 const body = input.body;
 if (!body || Array.isArray(body) || typeof body !== 'object') throw Error('Body must be an object');
 let path, fields;
 switch (input.family) {
  case 'onboarding-templates':
   if (!['POST','PUT','DELETE'].includes(input.method)) throw Error('Catalog method denied');
   path = 'onboarding-templates'; fields = input.method === 'DELETE' ? ['id'] : ['id','name','description']; break;
  case 'onboarding-template-steps':
   if (!['POST','PUT','DELETE'].includes(input.method)) throw Error('Catalog method denied');
   path = 'onboarding-template-steps'; fields = input.method === 'DELETE' ? ['id'] : ['id','templateId','name','description','stepType','trainingTypeId','stages','sortOrder']; break;
  case 'reorder':
   if (input.method !== 'POST') throw Error('Reorder method denied');
   path = 'onboarding-template-steps/reorder'; fields = ['templateId','orderedStepIds']; break;
  case 'duplicate':
   if (input.method !== 'POST' || !uuid.test(input.targetId)) throw Error('Duplicate target/method denied');
   path = `onboarding-templates/${input.targetId}/duplicate`; fields = []; break;
  case 'getting-started':
   if (input.method !== 'GET') throw Error('GettingStarted method denied');
   path = 'getting-started'; fields = []; break;
  case 'starter-apply':
   if (input.method !== 'POST') throw Error('Starter method denied');
   path = 'starter-configuration-packs/first-week-operations/apply'; fields = []; break;
  default: throw Error('Family denied');
 }
 for (const [key,value] of Object.entries(body)) {
  if (!fields.includes(key)) throw Error('Body field denied');
  if (['stages','orderedStepIds'].includes(key)) {
   if (!(key === 'stages' && value === null) && !(Array.isArray(value) && value.every(x => typeof x === 'string'))) throw Error('Array field denied');
  } else if (value !== null && !['string','number','boolean'].includes(typeof value)) throw Error('Scalar field denied');
 }
 const response = await fetch(`/org/${input.organizationSegment}/api/${path}`, {method:input.method, credentials:'same-origin', redirect:'manual', headers:{'Content-Type':'application/json'}, ...(input.method === 'GET' ? {} : {body:JSON.stringify(body)})});
 return {url:response.url, method:input.method, body, status:response.status, contentType:response.headers.get('content-type'), response:await response.text()};
}
