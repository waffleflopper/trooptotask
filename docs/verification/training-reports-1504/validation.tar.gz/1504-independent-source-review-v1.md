# Independent source review of #1504

The reviewed application delta has no open executable correctness, authorization, or consumer finding. Its tests protect the consequential new behavior at appropriate boundaries. The empty-export recipe defect found during review is corrected. Overall #1504 acceptance still requires the final repository gates, live journey, print evidence, and visual acceptance owned by root and T3 Claude.

This is an independent, nonvisual source review. I did not run tests, a browser, application services, database operations, CI, or connectors. I did not inspect screenshots or judge layout. Artifact reading is not independent execution. This review makes no model-diversity claim.

## Candidate and limits

- Review began at application base `3cc4ec4cd5ae3839c77fdb9da24ab71f29a9551b`, branch `t3code/triage-1433`, with the application changes uncommitted.
- At report time HEAD is `bf7640d735200b48ccd44bea0b994b1789d30cf9`. That intervening commit integrates the separate print-control worker. Its seven helper/script files are outside this application review. Their implementation, tests, and runtime behavior need their own acceptance.
- Application scope is the actual tracked working-tree diff, all four new source files below, and the affected retained consumers. The root's comment-only `src/lib/domain/readinessRollup.ts` header correction and empty-export recipe correction are included.
- Tracked application/docs diff SHA-256 against report-time HEAD is `ae66bf836b4501d42fe512a1f65bf255f39a248765ddc7ed1f9e9692546c3066`. The four new source files are hashed separately because `git diff` does not include untracked files.
- Cumulative consumer comparisons use the intended PR base `6555c3c884801e46bd0fc78a94d698c30ec76d88`. Prior slices #1501 through #1503 are accepted inputs. This report does not repeat their full acceptance or certify their archived execution.
- No source was edited. This report is the only file I wrote. No nested worker was created.

| New source file inspected in full | SHA-256 |
| --- | --- |
| `src/features/training/components/TrainingAffectedSoldiersSection.svelte` | `471bcd2ec691e9788feb623f157b91b0b187d9c0ac887fc57afe1701db9de9f2` |
| `src/features/training/components/TrainingFocusSection.svelte` | `49ead5898bcbb10cdbd8d7e4f6e88191b0144a0557f44a55989beb4d1aa73ead` |
| `src/features/training/components/TrainingTypeRiskSection.svelte` | `33dee409eaeed3bc5d8ecabcff388b86ec79a7c4aa0af443e65cf322c2590d56` |
| `src/features/training/utils/briefingFilterLabels.ts` | `884489a6cc909c9438bcfc7db9c349f8f704a9f2a527fca8ede9065ce9917b7c` |

The normative inputs were `.verification/1504-issue.json` and `.verification/1433-for-1504.json`, including the triage amendments. I read `.verification/1504-server-grounding.md`, `.verification/1504-legacy-consumer-census.json`, and `.verification/1504-implementation-report.md`, then checked actual source and callers rather than adopting the implementation report's assertions.

## Findings

### Resolved P2. The empty-export recipe described the retired workbook

The initial wording at `.agents/skills/verify-trooptotask/features/training-completions-reports.md:49` required a “headers-only workbook” for an authorized empty roster. The new five-sheet contract emits Summary numbers and filters, weekly Forecast rows, Hot spots Total, and Focus empty-state text even with zero applicable requirements. Only Requirements has no data rows. A verifier following the old instruction would incorrectly reject a valid export or remove the required summary information.

The minimal correction was to name the actual five-sheet zero state and keep the no-data assertion on Requirements. Root made that correction during review. I reread line 49 and verified that it now requires zero Soldiers and ready/applicable counts, blank readiness percentages, the empty Forecast and Hot spots Total, Focus empty text, and headers without data in Requirements.

No executable P0, P1, or P2 finding remains in this reviewed scope. I did not find a dangling legacy caller or a changed retained readiness meaning.

## Requirements and trace

| Requirement | Source conclusion and evidence |
| --- | --- |
| Type risk order and totals | `trainingBriefing.ts:402` counts applicable entries per selected type and sorts by not-ready plus lapsing counts descending. `TrainingTypeRiskSection.svelte:12` derives one shared maximum for all bars and renders the model's two literal counts. Zero scale is guarded before calculating a share. The component does not reorder or recalculate the risk model. This is a source conclusion about data and scale computation, not visual acceptance. |
| Model-only Focus, maximum three | `trainingBriefing.ts:594` sorts candidates by recovered requirement count under the common population denominator, then kind/name/key ties. It rejects scores below one point, suppresses overlap of at least half against the union already selected, and stops at three. `TrainingFocusSection.svelte:25` renders the ordered model areas, title, body, chip, link label, and wave first-lapse label verbatim. No free-text field or AI path was added. |
| Exact cell/focus requirements | `trainingBriefing.ts:694` rebuilds the authorized filtered analysis. A cell chooses its row/type and the not-ready-or-lapsing predicate. Focus lookup reruns selection and accepts only an actually selected stable candidate key. Unknown, stale, hidden, or excluded scopes return null and become 404 in `trainingReportsQuery.server.ts:169`. |
| Detail ordering and count | `trainingBriefing.ts:664` sorts not recorded first, expiration ascending with null last, then stable Person/name/type ties. `trainingReportsQuery.server.ts:172` derives the total count before pagination and joins only the page's authorized rows. The table disables client sorting and uses server rows unchanged at `TrainingAffectedSoldiersSection.svelte:69`. |
| Pages 25/100, retry, late answers | `trainingBriefingSession.svelte.ts:113` starts a scope at page one and retains the selected size. A size change resets page one. The request and displayed page are distinct, so failure/retry preserves the displayed scope and range while retry repeats the attempted request. Request IDs and aborts at lines 130 and 186 prevent late responses from replacing current data. A newly displayed briefing cancels detail and clears it at line 174. |
| Export scope and complete Requirements | `trainingReportsQuery.server.ts:185` loads one authorized source for export, builds the briefing and full affected rows, and serializes one workbook. `affectedBriefingRequirements` at `trainingBriefing.ts:683` excludes quiet-ready, optional, exempt, and not-required cells and applies drill-down order. It does not paginate, union selected Focus areas, read the open detail, or fetch its own API. `TrainingBriefingSession.exportHref` at line 66 uses the displayed report input. |
| Exactly five sheets and literal figures | `trainingReportWorkbook.ts:103` creates Summary, Forecast, Hot spots, Focus, and Requirements through the shared workbook utility. Values come from the same model and normalized filters. Weekly rows include today and the short final bucket. Hot spots keeps ordered columns/rows and Total. Focus keeps the rendered templates and the model's before/after numbers, including row-level what-if values. Labels remain native string cells. |
| Permissions and scope | The three route configs retain `training.viewRecords` and private/no-store plus Cookie-vary headers. `loadBriefingSource` at `trainingReportsQuery.server.ts:59` repeats the owned policy gate before its parallel reads. The roster still comes from `PersonnelTrainingRosterPort`, which uses Organization and Group scope before the privileged read at `personnel/trainingRoster.server.ts:18`. Completion rows retain the request-store boundary. No normal Personnel-read substitution or new store was introduced. |
| Print entry and scoping | `TrainingReportsPage.svelte` calls `window.print()` and states filters from the displayed report, using the same filter-label resolver as Summary. The print CSS is scoped to the Training report marker. Shared shell additions are marker attributes only. Print-control implementation and actual print output remain outside this review. |
| Documentation and recipe | Retained-domain rules state the new workbook and detail contract. Component-catalog guidance identifies current shared-table usage. The recipe covers Focus and cell interaction, server pagination and retry, complete downloads, access/reverse consumers, and print. Its empty-export wording is now corrected. |

The fixture arithmetic is independently coherent. Three People with CPR and BLS produce six applicable requirements, four ready today, and two ready at the horizon. Displayed readiness is 67 and 33. The drop is rounded from two of six, so it is 33 rather than subtracting the rounded endpoints. Requirements must be Baker/BLS missing, Baker/CPR expired, Able/BLS lapsing, and Cole/CPR lapsing, in that order. These are literal expectations in `trainingReportsQuery.server.test.ts:337`, not values derived by calling the workbook builder twice.

## Legacy deletion and retained consumers

I repeated the legacy symbol/path search across `src`, `scripts`, current `docs`, `.agents`, and `CONTEXT.md`. The removed screen model, dashboard/pivot calculators, matrix/pivot types, old report contracts, `ReportFilters`, and browser workbook helper have no current caller or export. The new `buildTrainingReportWorkbook` definition and its server caller are the intentional rewritten owner, not a preserved pivot compatibility path.

The current `TrainingReportsPage.svelte` and API `reportInput.ts` were already replaced in place by #1503. They remain required consumers. Deleting those filenames would delete the new page and parser. `filterPersonnel`, its meaningful tests, `TrainingStatusCell`, `cellDisplayText`, and `trainingStatus` remain.

The reverse-consumer check found the following retained meanings:

- Dashboard's `trainingCurrencyPct` at `dashboardScreenModel.svelte.ts:688` still counts distinct delinquent People. Its Training summary still attributes expired/orange-warning People through `trainingSummaryQuery.server.ts:35`. Neither imports the removed report rollup.
- Personnel's Training lane at `personnelTrainingReadiness.server.ts:56` still uses due/missing/overdue requirements and the existing authorized Person loader. The Personnel route consumer has no cumulative code change.
- Person export at `personnelExport.server.ts:135` keeps its separate Training Records sheet with raw completion date, expiration date, and Notes. It does not use the report workbook.
- Raw Organization Training export still uses `trainingExportRead.server.ts`, which returns saved type/completion/view rows through its separately authorized store. The cumulative Organization projection adds the accepted readiness-goal setting without replacing those Training records.
- Onboarding references still use the owned completion-existence port in `onboardingReferences.server.ts`. The Dashboard's completion keys also remain record-existence keys rather than readiness percentages.
- The cumulative `getTrainingStatus` change only adds optional `asOf` and passes it to the existing currency clock. Retained callers continue omitting it. None gained briefing-readiness semantics.

These conclusions are source and consumer evidence. Live retained-consumer proof remains root's responsibility.

## Test adequacy

I read the changed tests and relevant retained coverage. I did not execute them or adopt reported pass counts as independent proof.

| Coverage | Disposition and reason |
| --- | --- |
| Old screen-model, pivot, dashboard, and pivot-workbook tests | DELETE is justified. Their public behavior is retired by the approved new contract and their production callers are gone. Keeping them would protect a compatibility path the issue explicitly removes. |
| `reportCalculations.test.ts` filter cases | KEEP. They exercise the real retained filter against known Person identities, including trimmed rank, any-of multi-selects, empty selection, and AND between facets. They survive a different filter implementation. |
| Pure affected selection and existing briefing model tests | KEEP. Literal requirement rows detect quiet-ready leakage, wrong inclusion/exclusion, missing-first ordering, lapse boundaries, Focus thresholds/ties/overlap, and wrong what-if arithmetic. The independent renewed-record fixture recomputation checks what-if values. |
| Query-level parsed XLSX tests | KEEP. They use real query orchestration and serialize/reparse the actual workbook. The five exact sheets, literal numbers/dates/templates, four affected rows, filtered Alpha subset, more than one page, and formula-looking label string type detect wrong artifacts. They do not mirror the builder or assert geometry. |
| Session request-state tests | KEEP. Fake transport permits controlled failures and out-of-order answers. Assertions prove attempted-page retry, retained displayed data, page-size reset/carry, abort, and ignored late answers through the session's public behavior. |
| Page interaction tests | KEEP. They drive actual controls and prove the Focus URL, selected link, focus destination, status-table columns, Next/page-size requests, retained page during loading, displayed-filter print entry, and unscoped export. Transport fakes do not establish real server data or print output; the server/model and live evidence cover those separate claims. |
| Route policy/privacy tests | KEEP. They call real orchestration with in-memory ports and assert denial and audit outcomes, malformed scope, parser limits, and response headers. They are not RLS proof. |

The new tests add no copy-only change detector, structural snapshot, or geometry assertion. Exact Focus text is an approved fixed-template requirement. Exact worksheet contents are the specified user artifact. URL assertions protect the canonical filter/scope/page contract.

The server workbook coverage currently emphasizes the full fixture and an Alpha filter. It does not independently parse the entire workbook for an empty scoped actor, and its Alpha case only checks Summary and Requirements. Shared source construction and existing canonical-view/filter model tests support the other sheets by source composition. The updated live recipe is the remaining explicit proof for empty/filtered actual downloads and scope isolation. This is a stated coverage limit, not evidence of an implementation defect.

## Performance and ownership

Independent source reads remain parallel. Detail joins only the requested page, and the table introduces no duplicate client sort, whole-roster payload, or client store. Export has one source load and one XLSX serialization, with no request waterfall or loop over detail pages.

The export does analyze its source twice, once for the briefing at `trainingReportsQuery.server.ts:187` and once for affected Requirements at line 188. That repeats pure classification/index work proportional to the filtered roster and selected types. It does not repeat provider requests. I found no measured latency evidence to make this a blocking regression. A future measured export problem can justify a single aggregate conversion; this review does not recommend adding an abstraction merely to satisfy a source-level operation count.

## Missing acceptance evidence

The following remain unproved by this review:

- Final full verification commands and production build for the integrated candidate.
- Actual browser journey for all new sections, cell/focus exact rows, pagination, failed-page retry, filters/reload, and export.
- Actual workbook download and zero/filtered/scoped/foreign outcomes from the authorized live app.
- Organization/session timing, access failures, and affected retained consumer journeys.
- Native Print brief invocation, saved print rendering, clean output, and unchanged printing on another page.
- T3 Claude's visual acceptance, including print appearance. I made no visual judgment.
- Independent acceptance of the separately integrated print-control worker and current-candidate CI/review readiness.

No merge, deployment, remote database action, or publication was performed or authorized by this review.

## Reviewer method and skill limits

I applied local `t2t-engineer`, the repository testing strategy, and the supplied portable Poteto reviewer persona. The throughput checkpoint is `n/a, read-only investigation`. Boundary Discipline kept policy/parser/provider conclusions separate from pure model conclusions. Migrate Callers Then Delete Legacy APIs made the reverse-consumer census part of deletion acceptance. Test Behavior, Not Implementation made literal XLSX and request/interaction outcomes the adequacy test. Technical-writing and unslop guidance shaped this report.

The optional nested Comment Sicko lane was not run. The [no-comments skill](/home/waffleflops/.codex/plugins/cache/pstack-for-codex-local/pstack-for-codex/0.2.0/skills/no-comments/SKILL.md) instructs “Spawn Comment Sicko” and “If no independent agent is available, report the review capability as blocked rather than self-certifying.” The parent explicitly prohibited nested work and edits. That additional comment-specialist capability is therefore unavailable, with no claim that it passed. It does not convert this bounded source review into full or multi-model acceptance.
