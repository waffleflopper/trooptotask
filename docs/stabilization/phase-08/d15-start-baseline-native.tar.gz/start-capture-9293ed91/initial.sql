SET statement_timeout='10s'; SET lock_timeout='3s';
SELECT json_build_object(
 'person', (SELECT json_build_object('id',id,'organization_id',organization_id,'group_id',group_id,
 'rank',rank,'first_name',first_name,'last_name',last_name,'slug',slug,'archived_at',archived_at)
 FROM public.personnel WHERE organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND id='b939d5aa-f16c-422a-a655-d4544897a1df'::uuid),
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND p.personnel_id='b939d5aa-f16c-422a-a655-d4544897a1df'::uuid),'[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 JOIN public.personnel_onboardings p ON p.organization_id=s.organization_id AND p.id=s.onboarding_id
 WHERE p.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND p.personnel_id='b939d5aa-f16c-422a-a655-d4544897a1df'::uuid),'[]'::json),
 'training', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.personnel_trainings t
 WHERE t.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND t.personnel_id='b939d5aa-f16c-422a-a655-d4544897a1df'::uuid),'[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.onboarding_templates t
 WHERE t.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND t.id='b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5'::uuid),'[]'::json),
 'definitions', COALESCE((SELECT json_agg(d ORDER BY d.sort_order,d.id) FROM public.onboarding_template_steps d
 WHERE d.organization_id='b8f2540a-5573-41a5-8c7d-99477869a1cd'::uuid AND d.template_id='b8bc8539-0c13-4a82-ae7a-0dfafa8a61f5'::uuid),'[]'::json));
