SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
DROP TRIGGER IF EXISTS t2t_d15_remove_fault_e8267bd7_ce0cf4d9 ON public.onboarding_step_progress;
DROP FUNCTION IF EXISTS public.t2t_d15_remove_fault_e8267bd7_ce0cf4d9();
COMMIT;
SELECT json_build_object('event','fault-removed');
