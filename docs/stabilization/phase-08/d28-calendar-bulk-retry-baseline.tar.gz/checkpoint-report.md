# D28 Calendar unchanged checkpoint

Status: **ISSUES**. The native 501-Person Add journey reproduces the retry-selection defect and blocks the affected Calendar cutover. The coordinator deliberately stopped broad Calendar verification here to make that independent repair first. This is a partial unchanged baseline, not complete acceptance of the Calendar persistence wave.

## Tested inputs and ownership

- Checkout `/home/waffleflops/.cache/t2t-1376-calendar-owner`, branch `stabilization/1376-calendar-owner`, unchanged revision `51e4a9eb78ac4541b1a323dfbceeb9f3f36523cc`, tree `bf8944d2046584aa91b9d4a81e6ab46bb218c8ff`.
- Candidate `4291aca5871f0d0a9eaf313f5d670658826fa68af2a2ff91f57b1ced6792a92b`. Initial/final doctor PASS and an exact 5,021-file source/input manifest establish no app/helper/recipe changes during this run.
- Worker 2, session `53c17ba0-d827-4900-b97f-4b09f9f1ae9d`, owned origin `http://127.0.0.1:43487`, browser Chromium 152.0.7977.82 Arch Linux, Node 24.21.0 and npm 11.19.0.
- Initial doctor receipt October 6, 2026 02:20 UTC; cleaned receipt 02:38 UTC. Browser date October 5, 2026 in America/Anchorage. Native login actors calendarEmpty, calendarOperate and calendarConfigure are synthetic ordinary sessions.
- All launcher commands used `npm run --silent verify:app -- ... --worker 2`; all fixture/control/readback commands used `node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 2 ...`, with explicit checkout cwd and Node24 PATH. Initial launch used short owned TMPDIR `/home/waffleflops/.cache/t2t-c-tmp` and passed. Its separate production build is evidenced by launch completion in the tool transcript and initial doctor; a standalone retained launch stdout file is unavailable.
- No tracked edits, full test run, separate build, SQL suite, commit, rebase, push, PR or external tracker write. Launch performed its production build. No migration or existing/remote database was touched.

The evidence directory is `/home/waffleflops/.cache/t2t-1376-calendar-owner/.verification/evidence/verify-trooptotask/d28-calendar-baseline`. All filenames below are relative to it. Public fixture IDs and dates are in `fixture.json`; input hashes and tested source revision are in `input-manifest.json`.

## Reproduced Add partial-result failure

Expected: after 500 of 501 requested People succeed, preserve only the failed Person selected, the submitted status/date range/note and retry affordance. A retry must submit that failed Person only, without duplicating the first 500 effects.

Actual unchanged native journey:

1. `seed bulk-501` recorded 501 temporary Alpha People with tag `6e260d3a` (`bulk501-seed.json`). `actor calendarOperate calendar/bulk` returned page 3. The native search `MapChunk6e260d3a` showed exactly 501 and native Select shown selected 501/501.
2. Native controls selected fixture Verification Leave (`fb16695b-1f8c-4daf-bf1d-b1886c823b5e`), start/end October 5, 2026, note `D28 partial 6e260d3a`. Review showed the exact 501 People/date/note. The network control `network arm-fail 3 availability/batch 2` was armed after review and before native Confirm Apply. `feedback arm 3` observed the actual rendered toast.
3. `bulk-network-state.json` records the first real POST with count 500/status 200, then one failed Person/status 503. The second response is deliberately synthetic and undispatched. This proves client recovery behavior, not a real provider outage or provider atomicity.
4. `bulk-partial-effects-orgA.json` contains 500 saved rows. Their exact Person ID set equals the first real request ID set. `bulk-partial-effects-orgB.json` is empty. Failed Person `1c3f798e-2521-4fdf-aec2-dbded6012cd7` has no saved row. `bulk-partial-comparison.json` records these comparisons.
5. The actual error toast says 500 of 501 applied and the one failed Person is still selected (`bulk-feedback-state.json`). The settled native snapshot/screenshot instead show **0 of 504 selected**, a disabled Review & Confirm, cleared note and cleared search. `bulk-partial-after.txt` and `bulk-partial-after.png` establish the loss; the screenshot was inspected. Retry was unreachable without reconstructing the draft, so no retry or 501-row success is claimed.

Native before/action/after artifacts: `bulk-initial.txt`, `bulk-filtered.txt`, `bulk-with-note.txt`, `bulk-selected.txt`, `bulk-review.txt`, `bulk-preconfirm.txt`, their corresponding action JSON, `bulk-confirm-action.json`, and the after captures above. No reload preceded the failed post-action observation.

Supported source cause at the tested revision:

- `src/features/calendar/components/BulkStatusAdd.svelte` handleSubmit correctly clears selection and reselects failed People, then unconditionally invokes onComplete after partial success.
- `src/features/calendar/components/BulkStatusPage.svelte:116` maps onComplete to `invalidate('app:calendar-data')`.
- `src/routes/org/[orgId]/calendar/bulk/+page.svelte:18` resets `calendarBootstrap` to null whenever the stream changes. The pending branch removes BulkStatusPage, then remounts it, losing local Add selection/draft.
- `useDataTableSelection.svelte.ts` maintains its own selected-key set; a roster array update alone does not account for the reset.

Small complete repair proposal, already agreed by the coordinator: invoke Add completion refresh only after every requested Person is acknowledged. Partial success should keep its failed subset and draft while the existing availability store records acknowledged rows. Keep successful Add completion, zero-insert failure and later successful retry behavior truthful. Avoid route-state machinery or changes to Remove/Import.

Nearby source comparison, explicitly not native acceptance:

- BulkStatusRemove invokes completion only after successful removal acknowledgement; no partial Person-selection preservation contract applies to its boolean callback.
- BulkStatusImport preserves a results step and invokes notifyCompleteOnce from Done. It does not unconditionally invalidate inside the partial import attempt.
- Existing store chunk checks and neighboring component tests provide adjacent coverage; the new real Add interaction is the missing boundary. A real Add interaction with two literal People can independently prove failed selection, preserved dates/status/note, retry argument subset, and completion exactly once after full acknowledgement; the native 501 run establishes chunk/effect behavior. No source-shape test or additional browser framework is needed.

Required final repair proof: after partial result, inspect failed Person/dates/status/note and Retry before reload; the single retry must save exactly that failed ID, resulting in 501 unique A rows, unchanged first 500 saved IDs/fields, B0, then reload and cleanup. This checkpoint does not establish those final outcomes.

## Completed unaffected observations

### Explicit-empty Calendar Group availability admission

Actor calendarEmpty's native Calendar page had no Personnel rows (`empty-native.txt`). Separately labeled ordinary HTTP single and batch requests targeted A Able with valid A Leave/date September 14/note `D28 empty unchanged 20261005`. Both returned 403 with `You do not have access to that Calendar scope`, and exact marker reads in A/B were 0/0 (`empty-single-batch.json`, `empty-effects-orgA.json`, `empty-effects-orgB.json`). This exact current path supersedes the recipe's earlier empty-Group availability500 observation only; it does not prove all scope/foreign/no-lane admission paths or UI CRUD.

### Native status create/edit/reload/restore/delete

Actor calendarConfigure entered Calendar Settings (page 4). Created `D28 Calendar baseline status` through Add new type. Its new row `ef8fa550-9d6a-4e77-b86e-50e4fc77a65c` retained its Organization, default colors `#4a4a47`/`#f8f7f4` and sort order 0; reload showed its saved name (`status-created-row.json`, `status-reloaded.txt`, `status-reloaded.png`).

Edited original Leave ID `fb16695b-1f8c-4daf-bf1d-b1886c823b5e` through visible controls to `D28 renamed Leave`, background `#123456`, text `#fedcba`, then saved/reloaded. Same ID, sort order 11 and creation timestamp persisted (`status-edited-row.json`, `status-edited-reloaded.txt`). Restored its exact original name/colors through visible controls, saved and reloaded. Original row, linked Alpha availability row and B foreign status were byte-equivalent JSON before/after (`status-original.json` vs `status-restored.json`; `status-linked-before.json` vs after; `status-foreign-before.json` vs after).

Deleted only the newly created type through visible Delete confirmation, then reloaded; its exact ID is absent (`status-delete-confirm.json`, `status-deleted-row.json`, `status-deleted-native.txt`). Original fixture types were not deleted. This proves these native paths and stored colors/identity, not full status ordering/reset/audit/notification or configuration-denial coverage.

### Native saved Planner reads and temporary Person/Group save/reload/clear

Actor calendarOperate entered Planning → Assignment Planner (page 5), then Previous month. September15 rendered Staff Duty Able, Group Duty Alpha and Retiring Duty Baker. Active controls exclude the archived type. `seeded-planner-dom.json` records actual rendered values; `assignment-seeded-before.json` contains all four A rows including the retained archived assignment.

September22 A/B preflight reads were zero (`assignment-preflight-orgA.json`, B). Used the visible Staff combobox, native fill Able, read-only DOM inspection of actual suggestion, native ArrowDown/Enter. Saved row `2cd1a17b-7cd9-4ae2-ba0b-c9a66877cb0b` has Staff type, Able and September22. Used the visible Group combobox; native ArrowDown selected Bravo, saved row `2233517a-3bb0-41dd-9016-f01c5124846c` has Group type and Bravo. This is recorded as Bravo, without claiming Alpha selection. A rows exactly2/B0 (`assignment-saved-orgA.json`, B; `assignment-saved.png`).

After reload and reopening September, rendered Staff Able and Group Bravo persisted (`assignment-reloaded-dom.json` and `assignment-reloaded-september.json`); exact rows including IDs/timestamps match the pre-reload saved rows (`assignment-reloaded-row.json`). Visibly cleared just the September22 Staff and Group slots, reloaded/reopened September; both selected values were gone (`person-slot-clear.json`, `group-slot-clear.json`, `assignment-cleared-reloaded.json`). Exact A/B date reads are0/0. All four September15 A rows are unchanged (`assignment-seeded-after.json`). Reassignment, date-header modal, Quick Fill, denied hidden-slot409, range retry and report projections remain unrun.

## Disposal and proof limits

- All seed-dependent partial A/B comparisons preceded `clean-seeds`. Restored network and feedback controls on page3 first (`bulk-network-restore.json`, `bulk-feedback-restore.json`). No other hook/grant was armed or edited.
- `bulk-seeds-cleanup.json` reports cleaned. Follow-up exact note reads prove bulk marker absence A0/B0 (`bulk-cleaned-effects-orgA.json`, B).
- The status fixture fields were restored with their original ID; the one UI-created type was visibly deleted. Temporary Planner rows were visibly cleared and exact absence verified before disposal. No original fixture deletion/federal reset occurred.
- Final `clean-seeds` returned cleaned (`final-seeds-cleanup.json`), final doctor PASS matched the initial candidate/origin/session, and exact owned cleanup PASS/phase cleaned (`doctor-final.json`, `cleanup.json`). Proof files remain accessible afterward and git status is clean.
- Text artifacts were inspected and scanned for JWTs, token-bearing URLs and credential headers; no matching secrets were found. Public synthetic IDs/emails and bounded actor/context/origin facts remain. No redaction changed observations. Screenshots contain only synthetic app UI.
- No actual report workbook bytes/download, single-availability same-ID CRUD, bulk Remove/import native cases, special-day null/type/reset, assignment catalog edit/archive, role-grant drift, range failure/hold/retry, provider-sized ordinary reads or Personnel current/history/export reverse-consumer proof was completed. Those entire remaining branches are **UNRUN** and must form the later Calendar provider-wave affected baseline.
- Source caller/design coverage is preserved separately in `/home/waffleflops/.cache/t2t-1376-calendar-design.md`. Source mappings and old SQL/RPC evidence do not substitute for missing current ordinary UI/read/effect paths. Transactional assignment SQL was unchanged and not rerun here.
- Input manifest and payload inventory preserve exact candidate and bytes. Coordinator alone adopts revised recipes after cleanup, creates the durable archive under the task record, independently examines expanded observations and publishes records/PRs. The scratch inventory is archive-ready, not published acceptance.

## Coordinator next action

Inspect this frozen checkpoint, the actual partial screenshot/provider rows and caller chain. Authorize the focused Add callback repair with meaningful interaction test; update the owned bulk recipe for preserved-draft/native one-Person retry before reload. Obtain the heavy slot for a fresh repaired candidate launch only when ready. Complete that non-migration repair PR before resuming the complete Calendar ordinary-persistence wave and its remaining affected baseline. No additional issue or external write is implied.
