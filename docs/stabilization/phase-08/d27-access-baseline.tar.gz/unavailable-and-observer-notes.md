# Preserved attempts

The initial Node26.8.2 production launch failed because adapter-vercel rejects Node26. Owned cleanup passed. Relaunch under Node24.21.0 and npm11.12.1 produced the passing production build and doctor in this run.

T3 preview automation navigated and signed in through a private HTTPS preview of the same owned production build. Snapshot attempts on tabs8 and9 and recordingStart failed with PreviewAutomationExecutionError on client preview-8bd77910776ed8ea70f5199bba559268. Those attempts supply no screenshot or complete journey acceptance. The supplied AGENTS instructions explicitly select owned native browser controls for stabilization; the accepted captures use verify:app Chromium152 and the documented CLI/helpers.

An initial scratch observation assertion incorrectly required an anonymous401. The captured request actually followed the retained redirect to /auth/login, returned public200 and disclosed no saved IDs. The recipe already requires redirect/denial. The corrected offline observer checks redirected=true, the exact sign-in destination and absence of protected IDs. This is a corrected observation assertion, not a product repair or an assertion change to adopt failed product behavior.

## Session-token redactions

Independent acceptance found serialized authenticated session fields in `manager-data.json`, `scoped-data.json` and `viewer-data.json`. Each file now replaces its one `access_token` value and one `refresh_token` value with explicit redaction placeholders. These six replacements preserve response status, redirect flags, JSON structure, Person IDs and scope comparisons. Matching command receipts contain no duplicate token values. The initial sanitation missed these fields; the archive inventory and checksum were rebuilt after correction. All textual payloads were rescanned for JWTs before repackaging.
