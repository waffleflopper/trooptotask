(async () => {
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const measure = () => {
    const root = document.querySelector('[data-testid="training-briefing-forecast"]');
    const svg = root?.querySelector('svg');
    if (!svg) return { chart: null };
    const s = svg.getBoundingClientRect();
    const rel = (r) => [Math.round(r.left - s.left), Math.round(r.top - s.top), Math.round(r.right - s.left), Math.round(r.bottom - s.top)];
    const items = [...svg.querySelectorAll('text')].map((n) => ({ k: 'svg', t: n.textContent.trim(), r: n.getBoundingClientRect(), fill: getComputedStyle(n).fill, cls: (n.getAttribute('class') || '').match(/fill-[\w-]+|text-[\w-]+/g)?.join(' ') })).filter((i) => i.t && i.r.width > 0);
    for (const n of root.querySelectorAll('p, span')) { if (n.closest('svg') || n.closest('table') || n.closest('.sr-only')) continue; const r = n.getBoundingClientRect(); if (r.width > 0 && n.textContent.trim() && !n.querySelector('p,span')) items.push({ k: 'html', t: n.textContent.trim(), r, fill: getComputedStyle(n).color }); }
    const bars = [...svg.querySelectorAll('rect')].map((n) => ({ r: n.getBoundingClientRect(), cls: n.getAttribute('class') || '' })).filter((b) => /fill-warning(?!\/10)/.test(b.cls) && b.r.height > 0);
    const band = [...svg.querySelectorAll('rect')].find((n) => /fill-warning\/10/.test(n.getAttribute('class') || ''));
    const overlaps = [];
    for (let i = 0; i < items.length; i++) {
      for (let j = i + 1; j < items.length; j++) { const a = items[i].r, b = items[j].r; const w = Math.min(a.right, b.right) - Math.max(a.left, b.left), h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top); if (w > 0.5 && h > 0.5) overlaps.push(`${items[i].t}|${items[j].t} ${Math.round(w)}x${Math.round(h)}`); }
      for (const b of bars) { const a = items[i].r; const w = Math.min(a.right, b.r.right) - Math.max(a.left, b.r.left), h = Math.min(a.bottom, b.r.bottom) - Math.max(a.top, b.r.top); if (w > 0.5 && h > 0.5) overlaps.push(`${items[i].t}|bar${JSON.stringify(rel(b.r))} ${Math.round(w)}x${Math.round(h)}`); }
    }
    const svgItems = items.filter((i) => i.k === 'svg');
    const outside = svgItems.filter((i) => i.r.left < s.left - 0.5 || i.r.right > s.right + 0.5 || i.r.top < s.top - 0.5 || i.r.bottom > s.bottom + 0.5).map((i) => i.t);
    const htmlItems = items.filter((i) => i.k === 'html');
    const html = htmlItems.map((i) => `${i.t}@${rel(i.r)}`);
    const htmlOutsideRoot = htmlItems.filter((i) => { const rr = root.getBoundingClientRect(); return i.r.left < rr.left - 0.5 || i.r.right > rr.right + 0.5; }).map((i) => i.t);
    const line = [...svg.querySelectorAll('path')].map((p) => ({ cls: (p.getAttribute('class') || '').slice(0, 60), fill: getComputedStyle(p).fill, stroke: getComputedStyle(p).stroke, dash: getComputedStyle(p).strokeDasharray })).filter((p) => p.cls);
    const goalRule = [...svg.querySelectorAll('line, path')].find((n) => /stroke-success/.test(n.getAttribute('class') || ''));
    const sr = [...root.querySelectorAll('table tbody tr')].map((r) => r.innerText.replace(/\s+/g, ' '));
    const label = (re) => svgItems.filter((i) => re.test(i.t)).map((i) => `${i.t}@${rel(i.r)} ${i.cls ?? ''} ${i.fill}`);
    const ticksY = svgItems.filter((i) => /^(Today|\d+ [A-Z][a-z]{2}$)/.test(i.t)).map((i) => `${i.t}@${rel(i.r)[0]}-${rel(i.r)[2]}`);
    return { svg: [Math.round(s.width), Math.round(s.height)], overlaps, outside, htmlOutsideRoot, html, goal: label(/^Goal/), pct: label(/^\d+%$/).filter((l) => !/@-?\d+,\d+,\d+,\d+ .*muted/.test(l) || true), ticksX: ticksY, bars: bars.map((b) => rel(b.r).join(',') + (b.cls.includes('/40') ? ' dim' : ' emph')), band: band && rel(band.getBoundingClientRect()), barsInsidePlot: bars.every((b) => b.r.bottom <= s.bottom && b.r.top >= s.top), goalRule: goalRule && { cls: goalRule.getAttribute('class'), dash: getComputedStyle(goalRule).strokeDasharray, stroke: getComputedStyle(goalRule).stroke }, paths: line, srRows: sr.length, srLast: sr.slice(-2), srLapse: sr.filter((r) => !/ 0 No$| — —$/.test(r)) };
  };
  const out = { vw: innerWidth, theme: document.documentElement.dataset.theme, docSW: document.documentElement.scrollWidth, states: {} };
  for (const h of window.__horizons ?? [30, 60, 90, 180]) {
    const radio = document.querySelector(`[role=radio][aria-label="${h} days"]`);
    if (radio.getAttribute('aria-checked') !== 'true') { radio.click(); for (let i = 0; i < 40; i++) { await wait(100); if (radio.getAttribute('aria-checked') === 'true' && !document.querySelector('[aria-busy=true]') && document.querySelector('main main').innerText.includes('Bottom line')) break; } await wait(250); }
    const m = document.querySelector('main main').innerText;
    out.states[h] = { url: location.search.replace(/[0-9a-f]{8}-[0-9a-f-]{27}/g, (x) => x.slice(0, 8)), bottom: m.split('Bottom line')[1]?.split('Ready\n')[0].replace(/\n+/g, ' ').trim().slice(0, 220), ...measure() };
  }
  out.docSWAfter = document.documentElement.scrollWidth;
  return out;
})()
