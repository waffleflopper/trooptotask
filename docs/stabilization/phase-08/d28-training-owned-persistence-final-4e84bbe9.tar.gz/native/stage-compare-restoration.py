import json,pathlib
r=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-twoport-final-native-20261007');s=pathlib.Path('/home/waffleflops/.cache/t2t-1376-training-twoport-final-native-20261007')
def read(n):return json.loads(json.loads((r/(n+'.json')).read_text())['stdout'])
comparisons=[]
for org in ['orgA','orgB']:
 for table in ['training_types','training_views','personnel_trainings','personnel','groups','organizations','onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress']:
  before=read('original-'+org+'-'+table)['rows'];after=read('afterclean-'+org+'-'+table)['rows'];current={x['id']:x for x in after};assert all(x==current[x['id']] for x in before),(org,table)
  residual=[x for x in after if x['id'] not in {x['id'] for x in before}]
  if residual:assert org=='orgA' and table in ['personnel_onboardings','onboarding_step_progress'],(org,table,residual)
  comparisons.append({'organization':org,'table':table,'originalRows':len(before),'allCapturedSavedFieldsExactIncludingTimestamps':True,'residualRows':residual})
j= json.loads((r/'precleanup-seed-journal.json').read_text());clean=json.loads((r/'postcleanup-seed-journal.json').read_text());assert not clean['seeded'] and not clean['grants'];absent=[]
for item in j['seeded']:
 ids=set(item['ids']);after=read('afterclean-orgA-'+item['table'])['rows'];assert not ids&{x['id'] for x in after};absent.append({'kind':item['kind'],'table':item['table'],'ids':item['ids'],'countAbsent':len(ids)})
a=json.loads((s/'runtime.json').read_text());temps=a['temporaryIds'];assert all(temps[k] not in {x['id'] for x in read('afterclean-orgA-'+table)['rows']} for k,table in [('annual','training_types'),('expiry','training_types'),('view','training_views'),('datedRecord','personnel_trainings'),('expiryRecord','personnel_trainings'),('alphaRecord','personnel_trainings')])
for x in a['starterInventory']['types']:assert x['id'] not in {v['id'] for v in read('afterclean-orgA-training_types')['rows']}
assert a['starterInventory']['template']['id'] not in {x['id'] for x in read('afterclean-orgA-onboarding_templates')['rows']}
assert not {x['id'] for x in a['starterInventory']['steps']} & {x['id'] for x in read('afterclean-orgA-onboarding_template_steps')['rows']}
p=[x for x in read('afterclean-orgA-personnel_onboardings')['rows'] if x['id']==temps['onboardingPacket']];assert len(p)==1 and p[0]['status']=='cancelled';g=[x for x in read('afterclean-orgA-onboarding_step_progress')['rows'] if x['onboarding_id']==temps['onboardingPacket']];assert g==read('onboarding-derived-progress')['rows']
(r/'restoration-comparison.json').write_text(json.dumps({'status':'PASS','comparisons':comparisons,'all20OriginalRowsetsCapturedFieldsExact':True,'allOriginalTraining20_7_10KeysExact':True,'seededIdsAbsent':sum(x['countAbsent'] for x in absent),'journalCleared':True,'journalAbsence':absent,'uiTrainingIdsAbsent':{k:v for k,v in temps.items() if k!='onboardingPacket'},'starterIdsAbsent':a['starterInventory'],'declaredResidualNativeCancelledPacket':p,'declaredResidualProgress':g,'historyAuditAndSeenPreferenceEffectsRemainUntilOwnedDisposal':True,'noEveryTableExactClaim':True},indent=2));print('PASS20original rowsets exact;2081journaled IDs absent;UI/APITraining config/records absent;cancelled1packet/3progress retained until whole-provider disposal')
