import hashlib,json,subprocess
from pathlib import Path
s=Path('.verification/tmp/d15-closing-verification')
x=json.loads((s/'previous-support.json').read_text());result={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'purpose':'selected source/input applicability, not new historical observation'}
records=[]
for a in x['archives']:
 p=Path('docs/stabilization/phase-08')/a['name'];d=hashlib.sha256(p.read_bytes()).hexdigest()
 if d!=a['sha256']:raise RuntimeError('Prior archive changed')
 bindings=[]
 for b in a['sourceBindings']:
  h=hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()
  bindings.append({'path':b['path'],'recorded':b['recorded'],'current':h,'equal':h==b['recorded']})
 db=[]
 for p,h in a['commonDatabaseInputs']['hashes'].items():
  current=hashlib.sha256(Path(p).read_bytes()).hexdigest()
  if current!=h:raise RuntimeError('Selected prior SQL changed '+p)
  db.append({'path':p,'sha256':current})
 records.append({'archive':a['name'],'sha256':d,'sourceBindings':bindings,'commonDatabaseInputs':db,'limit':'Selected unchanged sources only; full changed Start/adapter/client/global SQL equivalence not claimed'})
result['archives']=records
y=x['lifecycleSuffix'];p='src/features/onboarding/server/onboardingLifecycle.server.ts'
old=subprocess.check_output(['git','show',y['oldRevision']+':'+p])
current=Path(p).read_bytes();marker=y['marker'].encode()
oldTail=old[old.index(marker):];currentTail=current[current.index(marker):]
if oldTail!=currentTail:raise RuntimeError('Lifecycle tail changed')
h=hashlib.sha256(currentTail).hexdigest()
result['lifecycleTail']={'path':p,'marker':y['marker'],'sha256':h,'oldRevision':y['oldRevision'],'equal':True}
(s/'current-reuse.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'head':result['head'],'archives':[{'name':a['archive'],'exactSources':sum(b['equal'] for b in a['sourceBindings']),'sourceCount':len(a['sourceBindings']),'exactPriorSQL':len(a['commonDatabaseInputs'])} for a in records],'exactLifecycleTail':True}))
