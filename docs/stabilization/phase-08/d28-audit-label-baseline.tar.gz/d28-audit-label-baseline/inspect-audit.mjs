import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { unflatten } from 'devalue';

const root = path.resolve(process.argv[2] ?? path.dirname(new URL(import.meta.url).pathname));
const read = (name) => JSON.parse(fs.readFileSync(path.join(root, name + '.json'), 'utf8'));
const text = (name) => fs.readFileSync(path.join(root, name + '.txt'), 'utf8');
const decode = (name) => {
	const capture = read(name);
	assert.equal(capture.status, 200);
	return JSON.parse(capture.body).nodes.filter(Boolean).map((node) => node.type === 'data' ? unflatten(node.data) : node);
};
const page = (name) => decode(name).find((node) => node.logsSettings)?.logsSettings.sections.logs.auditLogPage;
const seed = read('seed');
const excluded = new Set(['auth.login_success', 'auth.login_failure', 'auth.mfa_verify', 'security.rate_limit_violation']);
const expected = read('seeded-a').rows.filter((row) => !excluded.has(row.action)).sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp));
const first = page('owner-data');
assert.equal(first.totalCount, expected.length);
assert.equal(first.last30DaysCount, 105);
assert.equal(first.totalCount, 106);
assert.equal(first.limit, 100);
assert.deepEqual(first.logs.map((row) => row.id), expected.slice(0, 100).map((row) => row.id));
const witness = (key) => first.logs.find((row) => row.id === seed.witnesses[key]);
assert.deepEqual(witness('labels').details, {
	note: '[redacted]', count: 0, email: 's***@example.test',
	title: `Synthetic audit ${seed.tag} 00`, redacted_fields: ['note'],
	personnel: 'SPC Able Synthetic', training_type: 'Verification Required Training', status_type: 'Verification Leave'
});
assert.equal(witness('labels').resourceId, read('fixture').ids.personA);
assert.equal(witness('labels').userId, seed.rows[0].user_id);
assert.equal(witness('system').actor, null);
assert.equal(witness('storedActor').actor, 'Synthetic stored actor');
for (const [key, count] of [['foreignLabels', 2], ['missingLabels', 4]])
	assert.deepEqual(witness(key).details, { count, title: `Synthetic audit ${seed.tag} 0${count}` });
for (const name of ['owner-reload-data', 'owner-retry-data']) assert.deepEqual(page(name), first);
const peer = page('peer-data');
assert.equal(peer.totalCount, 1);
assert.deepEqual(peer.logs.map((row) => row.id), [seed.witnesses.foreign]);
assert.deepEqual(peer.logs[0].details, { title: `Synthetic foreign audit ${seed.tag}` });
for (const [name, status] of [['admin-data', 403], ['member-data', 403], ['owner-foreign-data', 404], ['peer-foreign-data', 404]]) {
	const nodes = decode(name);
	assert(nodes.some((node) => node.type === 'error' && node.status === status), name);
	assert(!nodes.some((node) => node.logsSettings), name);
}
assert(text('owner-logs').includes('Showing the latest 100 of 106 entries'));
assert(text('owner-logs').includes('System'));
assert(text('owner-page2').includes('Page 2 of 4'));
assert(text('owner-search').includes('Synthetic stored actor'));
assert(!text('owner-search').includes('Page 2 of 4'));
assert(text('owner-failed').includes('Error 503'));
assert(text('owner-retry').includes('Audit Log'));
assert(read('failure-state').calls.some((call) => call.status === 503));
assert.equal(read('focused-logs').active.href, `/org/${read('fixture').ids.orgA}/settings/logs`);
for (const organization of ['a', 'b']) {
	assert.deepEqual(read('after-clean-' + organization).rows, read('original-' + organization).rows);
	assert.equal(read('doctor-final').status, 'PASS');
}
assert.equal(read('cleanup').status, 'PASS');
console.log(JSON.stringify({ status: 'PASS', candidate: read('launch').candidate, organizationRows: expected.length, loaded: first.logs.length, labelWitnesses: 5, deniedTargets: 4, nativeNavigationRecovery: true, cleanup: true }));
