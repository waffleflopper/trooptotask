import json,re,sys
from flow import snapshot,tool,call,click,shot,base
PERSON=json.loads((base/'seed-lifecycle.json').read_text())['ids']['person']
FIELDS={'Blood type':'O+','Marital status':'Married','Personal phone':'907-555-0102','Personal email':'synthetic-sds@example.test','Address':'100 Synthetic Way','Address city':'Anchorage','Address state':'AK','Address ZIP':'99501','BASD':'2020-02-03','Date of rank':'2024-06-01','Spouse name':'Synthetic Spouse','Spouse phone':'907-555-0101','Number of dependents':'2','Children':'Avery, 7\nMorgan','Vehicle color':'Gray','Vehicle':'Toyota Tacoma','Plate':'VFY482','Civilian education':'BSN','Military education':' BLC \n\nAir Assault ','Emergency contact':'Synthetic Contact','Relationship':'Sibling','Emergency phone':'907-555-0100'}
EXPECTED={'blood_type':'O+','basd':'2020-02-03','date_of_rank':'2024-06-01','marital_status':'Married','number_of_dependents':2,'children':[{'name':'Avery','age':7},{'name':'Morgan','age':None}],'civilian_education':'BSN','military_education':['BLC','Air Assault'],'emergency_contact_name':'Synthetic Contact','emergency_contact_relationship':'Sibling','emergency_contact_phone':'907-555-0100','spouse_name':'Synthetic Spouse','spouse_phone':'907-555-0101','vehicle_make_model':'Toyota Tacoma','vehicle_plate':'VFY482','vehicle_color':'Gray','personal_email':'synthetic-sds@example.test','personal_phone':'907-555-0102','address_street':'100 Synthetic Way','address_city':'Anchorage','address_state':'AK','address_zip':'99501'}
def fill_values(label,page,values):
 s=snapshot(label+'-before',page)
 s=s[s.rfind('dialog "Soldier Data Sheet"'):]
 items=[]
 for name,value in values.items():
  m=re.findall(r'uid=([^ ]+) (?:textbox|spinbutton|Date) '+re.escape(json.dumps(name))+r'(?: |\n|$)',s)
  if len(m)!=1:
   m=re.findall(r'StaticText '+re.escape(json.dumps(name))+r'\n\s*uid=([^ ]+) (?:textbox|spinbutton|Date)(?: |\n|$)',s)
  if len(m)!=1:raise RuntimeError('Need exact SDS field '+name+', got '+str(m))
  items.append({'uid':m[0],'value':value})
 return tool(label,'fill_form',{'pageId':page,'elements':items})
