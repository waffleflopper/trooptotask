import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';

const [directory] = process.argv.slice(2);
const headers = ['Name', 'Rank', 'MOS', 'Duty Role', 'Group', 'Verification Required Training', 'Verification Targeted Training'];
const able = ['Able, Synthetic', 'SPC', '68W', 'Medic', 'Alpha', 'Current (2027-09-26)', 'Not Done'];
const expected = [
  { file: 'full-small-roster-1.xlsx', sha: '3d4de2869f41df1cf6927150ee093d6c08bab09fd6aae1fbfebef5a914994592', proof: 'Visible mouse download', headers,
    rows: [able, ['Baker, Synthetic', 'SPC', '11B', 'NCO', 'Bravo', 'Not Done', 'N/A'], ['Unassigned, Synthetic', 'SPC', '68W', 'NCO', null, 'Not Done', 'N/A']] },
  { file: 'alpha-required-keyboard-1.xlsx', sha: 'bd57d4c1050b4ab5d58a66d2997641bde4d7f36c89e57e7fd213e09433261873', proof: 'Visible keyboard download', headers: headers.slice(0, 6), rows: [able.slice(0, 6)] },
  { file: 'api-rosterScoped-1.xlsx', sha: 'e13a24f8466fa0aa4a479ebd92320c9d4801ed78c651b05a89e107939ad67176', proof: 'Direct API export of empty Bravo scope', headers, rows: [] },
  { file: 'api-rosterScoped-2.xlsx', sha: '7c1cba498703f754dc0cb10cfb9971d48af3d86d8c61d5a84ad5e446ce3f4683', proof: 'Direct API export of Alpha-only actor scope', headers, rows: [able] },
  { file: 'api-trainingEmpty-1.xlsx', sha: 'e2c9efd5b9e1d4e9c9099341ae8855e11c7468e1c647f64a5826b16e318f7ffe', proof: 'Direct API export of empty actor scope', headers, rows: [] }
];
const observed = [];
for (const item of expected) {
  const bytes = await fs.readFile(`${directory}/downloads/${item.file}`);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), item.sha);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(bytes);
  assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Training Report']);
  const sheet = workbook.worksheets[0];
  const rows = Array.from({ length: sheet.rowCount }, (_, index) =>
    Array.from({ length: sheet.columnCount }, (_, column) => sheet.getRow(index + 1).getCell(column + 1).value));
  assert.deepEqual(rows, [item.headers, ...item.rows]);
  observed.push({ file: item.file, source: item.proof, bytes: bytes.length, sha256: item.sha, sheet: sheet.name, headers: rows[0], rows: rows.slice(1) });
}
process.stdout.write(JSON.stringify({ status: 'PASS', proof: 'Offline artifact inspection, not independent browser execution', observed }, null, 2) + '\n');
