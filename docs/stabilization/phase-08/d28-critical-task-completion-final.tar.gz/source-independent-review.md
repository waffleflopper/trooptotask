# Independent source acceptance — D28 Critical Tasks completion persistence

Standards: **GO for the complete source/selection candidate.**
Spec: **GO for the declared completion-ledger ownership/caller/removal concern.**
Consequential source findings: **0**. Final changed-candidate native/expanded acceptance, required final checks, intended CLI review, publication-head CI/build and completed hosted review remain separate gates. This report does not authorize merge or close #1376.

## Review authority and exact scope

This was a read-only review. No application tests, services, browser, provider/database queries, connectors or network were executed by this reviewer; no repository files were changed. Only this requested portable report was written. Source and saved lower-level evidence were independently inspected; this is neither independent live execution nor model diversity.

Review base is `66a238a8fe9915f5dd3994a7d5d62f71c71f7de8`. Owner implementation `1241ba5debdc64e98fa251ebbadabbc7ce446c78` was integrated as `a53ed80438700da863bcba1eac1d2002511caa51`. The working tree was included: the structural test-support type repair, manifest classification and nine comment-only narration removals, along with all current records. Count is 50 logical changed-file rows, or 51 physical old/new paths when the support-file rename is counted twice: 50 text paths plus the already accepted unchanged-baseline archive. There are 42 logical source/test rows (43 physical source/test paths including both rename endpoints), the manifest, six Markdown records and one binary archive. All deletions, additions and rename endpoints were inspected. The baseline binary acceptance is reused from the separate expanded-baseline review; no repeated final-native acceptance is inferred here.

The tracked base-to-working-tree binary patch has SHA-256 `7c3fd829625121cabaa68dc269bb7283e401a82a7bcc3e46cedc682eb261851a`. The untracked receipt and baseline package are additionally covered by the file hash manifest below. These are a review snapshot, not a claimed future frozen native candidate.

Applied project engineering/retained contracts and Poteto principles: Boundary Discipline for ordinary/privileged and public/private seams; Migrate Callers Then Delete Legacy APIs for the complete caller/removal wave; Test Behavior Not Implementation for literal provider effects and useful denial assertions; Prove It Works for actual red/restored logs and accurate pending gates. The installed portable Comment Sicko rules were applied read-only.

## Standards assessment

- `src/features/critical-tasks/contracts.ts:46` exposes nine named operations and typed completion/reference/pair DTOs. The public port does not accept a table, query, Organization override or provider client. The fixed adapter captures the supplied ordinary client and canonical Organization at construction (`criticalTaskCompletionPersistence.server.ts:12`).
- The private mapper (`personnelIctCompletionMapping.server.ts:17–66`) selects the nine supported fields, keeps timestamp strings and nullable values intact, and permits only the six writable columns. Create defaults nullable details to null. Updates preserve omitted values and explicit null clears while refusing ID, logger, creation-time and Organization spoofing. Supported DTO fields survive; unsupported raw provider columns do not escape this feature seam. Intentional raw backup formats remain in their already accepted owner boundary.
- The adapter uses the fixed completion table and Organization predicate for reads, references and every mutation. Complete pages and whole errors are preserved. Ordered individual history remains date-descending with ID tie order; targeted readiness and paired imports remain unordered; report history retains ID order. First and late provider errors reject the entire required read.
- Report reads keep 50-Person × 50-task windows with at most four simultaneous queries (`criticalTaskCompletionPersistence.server.ts:42–68`). Nested row append preserves deep history without the argument-spread stack failure found during the first run. Empty dimensions make no provider query. Import lookup keeps 50 matched-pair batches, current concurrency, all historical dates and stored-ID deduplication (`:69–84`). It does not add report sorting or falsely promise snapshot isolation or transactional imports.
- Reference/mutation error semantics remain supported behavior (`:85–134`): missing/foreign reference is concealed as null; missing/foreign single update fails; missing/foreign delete remains successful with no effects. Plain provider errors are preserved. This owner intentionally does not add a new identity, single-reply or cardinality policy. Successful short/empty bulk acknowledgment returns acknowledged rows only and does not retry already stored effects.
- Production callers use the owner, including CRUD/import, history, reports/workbooks, Dashboard and targeted Personnel readiness. Real request factories bind the ordinary request client. The privileged Personnel roster remains separately admitted and scoped; it is not used as a completion writer. Request-local Person/reference caching and policy-before-access stay in the existing operations. The latest RPC query shape and SQL are unchanged; its mapping is now private and owned.
- The generic completion entity and its test are deleted together; their schema/default/protected-field behavior is covered at the new owner boundary. The old metadata assertion test is replaced by actual route/operation permission behavior. No compatibility shim or production test-support import remains. The synthetic latest implementation is removed from the production barrel and declared test support with the other memory adapters. The structural `CompletionMemoryStore` fix eliminates the new delivery-boundary type imports without a waiver or runtime change.

## Spec, grouping and consumer assessment

The deliverable is a complete supported ordinary completion-ledger concern: CRUD plus existing old/replacement Person/task/archive/Group guards; matched-pair dated import lookup, fallback and partial outcomes; ordered individual history with archived task references; complete report/workbook/Dashboard history; targeted Personnel readiness; latest-read private mapping; all delivery/test callers and replaced internal API retirement. No ordinary generic completion query or write remains in the traced production consumers. Browser store table/realtime metadata, supported raw backup reads, retention and SQL references are distinct unchanged owners, not missed ordinary generic persistence callers.

CRUD (`personnelIctCompletionOperations.server.ts:102–155`) still admits record permission before reference access, verifies the old history scope/archive/task before replacements, verifies new active Person/Group/task references, and writes audit success after persistence. Prepared deletion preserves delivery UUID validation and the same effect/audit order. Batch import (`ictCompletionsBatch.server.ts:58–136`) authorizes resolved references and completes all required history reads before effects. Same-Person/task/date identity, dated update IDs, bulk-reject-only fallback and partial row errors/counts remain. Successful short acknowledgment is not recast as failed persistence.

The source scope does not omit a closely related completion caller or share a remaining defect that needs a second completion PR. Configuration/settings reads, other domain CRUD/catalog owners and final generic request/store/scope facade removal remain concrete later #1376 concerns. Current feature-owned entity/type names alone are not unresolved debt. Whole-D28 integrated acceptance is still required; D29 mixed utilities and D30 remain blocked. No schema, migration, grant, RLS, timer, date-math or SQL change appears in this candidate.

The two maintained Critical Tasks recipes still select final affected CRUD/import/history/report/reverse/scope journeys. Accepted unchanged-baseline #1542/D11/D10 credit applies only to unchanged scope/lifetime/date/RPC/SQL boundaries. Changed completion provider queries and private mapping require their new lower-level witnesses and fresh final native proof; this source verdict does not transfer historical proof to unexecuted changed paths.

## Test usefulness and actual saved lower-level proof

The new SDK tests use the installed Supabase/PostgREST transport, ordinary authorization headers, literal source rows and finite HTTP responses. They do not replace the query builder or compute expected DTOs through the mapper under test. The fake has a provider-sized 1,000-row cap, finite request-line limit, real mutation effects and separately controlled acknowledgments. These tests prove SDK/client/query/mapping composition, not SQL RLS execution or hosted parity.

`criticalTaskCompletionPersistence.server.test.ts:171–646` independently proves literal nullable/default/protected/timestamp values; four consumers' 1,001-row tails; first/late required-read errors; report completeness/scope/50×50/max-four behavior; 500-pair import completeness and overlap deduplication; reference concealment; cross-tenant write invariance; empty/short acknowledgments; and actual batch rejection fallback, dated identity, partial effects and audit counts. Existing deep 150,150/151,151 report histories and archived reference paging remain meaningful consumers of the SDK owner. The replaced entity test's important validation/default/update behavior is preserved in mapper/SDK tests, rather than retaining metadata copies of retired declarations.

The actual reverse composition witnesses are particularly useful: `dashboardRequestContext.server.test.ts:112` leaves the generic completion store empty and returns completions only through the ordinary SDK transport, while separately enforcing privileged Personnel Organization/Group reads. It verifies admitted Critical-Tasks-only readiness plus empty-scope/forged denial before privileged acquisition. `personnelCriticalTasksRequestContext.server.test.ts:100` likewise supplies completion rows only through the ordinary SDK transport after real lane admission, and proves Personnel-only denial issues no ordinary provider read. These would expose a lost binding that an injected completion fake could hide.

All 37 owner-offline files were inspected, including the mutation runner, manifests, actual failing/restored logs and the owner patch. Eleven controlled faults each fail the behavioral suite, then restore the exact original bytes: tenant removal, page-tail loss, report concurrency/window change, import window expansion, wildcard projection, wrong write tenant, null-clear loss, timestamp precision loss, bulk fallback loss and swallowed required-read errors. Actual first dependency failure (`vitest` unavailable), subsequent first-executed three failures and their resolution are retained. The first executed failure comprises the excluded-history fixture and both deep history argument-spread stack failures. Final/restored owner runs pass 10 suites / 58 tests. Owner formatting/lint/diff evidence also passes.

The owner handoff lists 23 paths (6 additions, 15 modifications, 2 deletions). Of its 21 surviving file hashes, 15 remain byte-identical in the reviewed root. Six differences are completely explained by the local structural test-support type substitution and comment-only deletions in five paths. The actual adapter and mapper retain their fault-restored bytes; batch runtime changes since handoff are only narration deletion. None of the original meaningful fault checks was weakened.

Integrated saved logs, read directly:

- Corrected focused run: 29 suites / 263 tests pass, including actual module-boundary/governance/import accepted/rejected fixtures.
- Types: 0 errors / 0 warnings. Governance: 159 findings, no regression/waiver. Full lint: 0 errors, three unchanged Calendar/Onboarding warnings. Full formatting passes.
- The initial full test command is **failed**: 705 suites pass with 7,008 passing tests; two hydration suites fail before executing tests with system write error `-122`. Its retained result is not called green.
- The owned-temporary-directory retry actually passes those two suites / three tests. This resolves the bounded import/execution problem in that retry; it is not represented as a fresh successful full command. Final required-check disposition remains root-owned.

## Records and comment disposition

All six current Markdown records were inspected. Integrated #1542 credit is correctly scoped to its accepted tree; current completion final-native/CLI/published CI/hosted/merge gates are not claimed complete. Workbook attribution was corrected: native report supplies 20% and one ready of five applicable assignments; the actual workbook independently supplies Overall Readiness 20 and per-Person/task values, with no Ready/Applicable summary rows. This was an optional clarity correction, not a source blocker. No other consequential factual correction remains.

Fresh scoped comment review finds **0 remaining deletion candidates, 0 MUST KILL symbols, 0 new suppressions and 0 introduced skipped tests**. The parent separately removed nine existing narration ranges / 15 lines in five scoped files; their exact diff and before/after hashes were read. SQL ordering explanations describe an externally forced ordering behavior; retained public API docs are permitted. `run-faults.py` contains no comments or suppressions. This reviewer performed 0 deletions, restorations, reruns, rewrites/sketches or encodings, and leaves 0 unresolved comment constraints. Unchanged repository prose/comments outside the declared scope were not audited for cleanup.

## Limits and next acceptance

This GO permits the source cutover to proceed to frozen affected final verification. It is not complete-candidate/native, release, CI or merge acceptance. Final ordinary-user/provider effect proof, actual workbook/screenshots, source-input binding, failure restoration/cleanup and durable artifact integrity still need independent expanded acceptance. No fresh live wide/held/as-of/performance/remote-parity result is claimed. SQL/latest-query behavior and existing permission lifetime tests are reused only while unchanged. #1376 stays open until remaining owners/facades and integrated acceptance are complete.

## Reviewed physical path manifest

Each SHA is the actual current byte hash at report creation; ABSENT marks a deleted/renamed old path. The baseline package was previously expanded and independently accepted, rather than re-executed here.

- `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` — `f3d0476f6d408a59503953644ff35152c8f56ddd5c232101a0ffabba150a27e3`
- `docs/architecture/DRIFT_LEDGER.md` — `390ccd47e5e80b212abfb56ae0af225e24cb8052c199761d14adc776145f7cd1`
- `docs/stabilization/EVIDENCE.md` — `dc15e6902a3e05af6662783c33319aee3b1a4f428deaa58d215aabe5dab18365`
- `docs/stabilization/TODO.md` — `b10630c5bcb63662fc6fc820948ee1fde8dd0c93259638b15ff97006a43aea95`
- `docs/stabilization/phase-08/d28-critical-task-completion-baseline.tar.gz` — `aef3085e4e581ca6ce6248a68ba33798c8667bbde20c9e383a4d97b283b14f23`
- `docs/stabilization/phase-08/d28-critical-task-completion-persistence.md` — `904d05efb07488f76439092d8ff9ee111de6db11b60b65023e1727dcc136df5f`
- `docs/stabilization/phase-08/d28-critical-task-library-persistence.md` — `8833161277ecb939c77e584e2e9ef0f9cee7cef32c5b85b897c9f7fd556c12e9`
- `scripts/module-boundaries.json` — `e953329b739cd3095275a73029701923edeb49ed86a5770c9402b2db909490b5`
- `src/features/critical-tasks/contracts.ts` — `5433d9eb36d86354ac784c6aaeed26879f2726a9d6c99a9a08e1c282a4ed6c97`
- `src/features/critical-tasks/index.server.ts` — `99a2bda32d0a23c24f85ad0252a76421f17a21c79a75ca365dc981bf055d6c9f`
- `src/features/critical-tasks/server/criticalTaskCompletionPersistence.server.test.ts` — `2aa6d5bfca2ec0bf9bb8a4fb8db6114b06fc2951590d1380072b19f7cafe9e95`
- `src/features/critical-tasks/server/criticalTaskCompletionPersistence.server.ts` — `0378e771d1579ccd3b5c32054d1707b881749257fb7cf9e35c37ce2726a090fa`
- `src/features/critical-tasks/server/criticalTaskLibrary.test-support.server.ts` — `ABSENT`
- `src/features/critical-tasks/server/criticalTaskLibraryPersistence.server.test.ts` — `fd27f70b246ece5e9b4b610f0098d3d1d9bbd311569f449e8ee1e676c142d7f0`
- `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.test.ts` — `ed19023d72be4fac9f94e63d730abae0f976414b2b9b5f50af6dd6b6fa5e3512`
- `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.ts` — `4a9e94b0bc70d1fbcfa969cd413e4cfab0289ac202fc0ba47b5f7db26e3e5f1f`
- `src/features/critical-tasks/server/criticalTasksPersistence.test-support.server.ts` — `328b4fb715708c04dc6338f3f51803f21511ba04e1e99e9f598dedc2f4eeb27d`
- `src/features/critical-tasks/server/criticalTasksReadModel.server.test.ts` — `7cd95a8cb2fede3d414162fd32d179c3e2d712a615218b4225bf403fdb99ddd1`
- `src/features/critical-tasks/server/criticalTasksReadModel.server.ts` — `14dee754401534343882bc3da698a092c85792cc265ea0c28f805a161b433879`
- `src/features/critical-tasks/server/criticalTasksReadPorts.server.ts` — `e26b25580d4c3238668f9d57403c1a288881adec7f6ac23ceb41da94c59d1a98`
- `src/features/critical-tasks/server/criticalTasksReportsQuery.server.test.ts` — `2e0749679474ffc93b137dd7386e830bb6aab31fa1d11e51f4485591698c9c58`
- `src/features/critical-tasks/server/criticalTasksReportsQuery.server.ts` — `e22b05b43c188aaad7f9047d58d8fe8795093d5476447ddd44be70ed28cbe07d`
- `src/features/critical-tasks/server/criticalTasksWorkspaceQuery.server.test.ts` — `ced856f3f6e9d50bf3dca94c497c5ca7ba711decc02dc38e5823c5c4e25e1105`
- `src/features/critical-tasks/server/ictCompletionsBatch.server.test.ts` — `78c8757be96bdff8cf52eff0544912dd82f79252eff096c8a9e180a7f5f6b813`
- `src/features/critical-tasks/server/ictCompletionsBatch.server.ts` — `c736b21f5fa118e9327e19d6ddd178eb3f7a411a717b555a576fb93f291c28ed`
- `src/features/critical-tasks/server/ictTaskOperations.server.test.ts` — `17ea6ef64aae00bf2b49c80a608b130ff55fbdfb22a74743a7c49a9f894dade0`
- `src/features/critical-tasks/server/ictTasksBatch.server.test.ts` — `01d34a4eb3a1c188c10a80523c6e59c3da9653d64674a763fb478d60177920ac`
- `src/features/critical-tasks/server/inMemoryCriticalTaskCompletion.server.ts` — `f0772a3a12f47dff6ffa2328f23b342bcd6dabd7a7aa16ac08f1aec4851a9020`
- `src/features/critical-tasks/server/inMemoryCriticalTasksReadModel.server.test.ts` — `6c93cce623390de32aa5d3b6c607b3b034b8530cbde16c38e2322fb714a5e103`
- `src/features/critical-tasks/server/inMemoryCriticalTasksReadModel.server.ts` — `807d28b3a27900dc9116c897c4121b06d01ab8c971b03fb07f83070e024ac7b1`
- `src/features/critical-tasks/server/personnelCriticalTasksReadiness.server.test.ts` — `9878d8e52125e5a7f83a806391670c6ec8d73c8f90fd3725cc4dc36f0498e992`
- `src/features/critical-tasks/server/personnelCriticalTasksReadiness.server.ts` — `9acf468d6d3b6ac9603e3611de06b7ede4561a4ff8fbd57767a153ebce29879c`
- `src/features/critical-tasks/server/personnelIctCompletionEntity.server.test.ts` — `ABSENT`
- `src/features/critical-tasks/server/personnelIctCompletionEntity.server.ts` — `ABSENT`
- `src/features/critical-tasks/server/personnelIctCompletionMapping.server.test.ts` — `e61a3646edd47375c41740340bae527590541e267dee92cfa62d9d876d0270ee`
- `src/features/critical-tasks/server/personnelIctCompletionMapping.server.ts` — `d9a1547fdd18a9b6b7c9d24c00ad863fc9fe1757a3526727cf63d464bd455c7c`
- `src/features/critical-tasks/server/personnelIctCompletionOperations.server.test.ts` — `84cfe7055115a87c1409d9b2470aa06b3308e41f09b14b52bb67529c3cbbc201`
- `src/features/critical-tasks/server/personnelIctCompletionOperations.server.ts` — `ed891cef53c643d14ebaa348096a164f80751b187487a9428f553ee294612927`
- `src/features/critical-tasks/server/personnelIctCompletionPorts.server.ts` — `e96d644e58db63caa5a1462efd7faf16dc54e392bd13bd0f80924f5599876f04`
- `src/lib/server/adapters/dashboardRequestContext.server.test.ts` — `58ea78a60490219e2e64edaa06444595524f904dacf2e9b87b3f69741b3616e1`
- `src/lib/server/adapters/featureRequestContexts.server.ts` — `c370ba776e6c0c60bfc83474f82db5aba8a0bf8b2c33693296cc7bc627a6ad61`
- `src/lib/server/adapters/inMemory.ts` — `8d0015f3afce327241424be1746a12af7b8bb5f30bf51cea9626d0f6c8a4d0f0`
- `src/lib/server/adapters/personnelCriticalTasksRequestContext.server.test.ts` — `f3126029a0ea73e530706a1fa53345b8858c54ce03b1fc3e61f4a285d94cccd7`
- `src/lib/server/adapters/requestContexts.server.ts` — `a6bdc39373d56a922cb64f566675ca8b39732ecf4711f7990bdc40f48752e936`
- `src/routes/org/[orgId]/api/critical-tasks/matrix/export/server.test.ts` — `0f477d640dbc80394e91945830f6f774a2abefdf5a4b4fcfc2d6b725d645de0f`
- `src/routes/org/[orgId]/api/critical-tasks/reports/export/server.test.ts` — `88d2e7642fc8e8fa14cf4c3b2df56d6be5444702684435ceff7db39f48af4aca`
- `src/routes/org/[orgId]/api/critical-tasks/reports/summary/server.test.ts` — `a41cad7cdffbbd570f6608f5de5998f65eddb9974d5589e2ca7839a7790bdfd9`
- `src/routes/org/[orgId]/api/personnel-ict-completions/batch/server.test.ts` — `79b8d8f8f1848e9865c09dbfa86e91eb4c50c4bcf24df1a1aabf286fde658486`
- `src/routes/org/[orgId]/api/personnel-ict-completions/server.test.ts` — `4095f799742e95f19ddb17fc3f193c7ba483e3423b938d5b2a6eb1fc32f327c0`
- `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts` — `2912af330648934458041c5ef448c5db75cb111d68cf3d2055d4ee53a31985ef`
- `src/routes/org/[orgId]/personnel/[personnelSlug]/page.server.test.ts` — `547c878c0a014bce3d80f7d333cc5c4f34ed9d7ea1c21278fcb0870c59f2ba91`

Owner handoff hash differences: `src/features/critical-tasks/server/criticalTasksHistoryQuery.server.test.ts`, `src/features/critical-tasks/server/criticalTasksReadModel.server.test.ts`, `src/features/critical-tasks/server/criticalTasksReportsQuery.server.test.ts`, `src/features/critical-tasks/server/ictCompletionsBatch.server.test.ts`, `src/features/critical-tasks/server/ictCompletionsBatch.server.ts`, `src/features/critical-tasks/server/inMemoryCriticalTaskCompletion.server.ts`.
