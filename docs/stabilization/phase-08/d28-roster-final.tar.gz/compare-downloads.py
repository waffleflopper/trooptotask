import json
from pathlib import Path

root = Path(__file__).parent
source = json.loads((root / 'source-rosters.json').read_text())['rows']
backup = json.loads((root / 'owner-a.json').read_text())['signInRosters']
workbook = json.loads((root / 'excel-rosters.json').read_text())
columns = {
    'Id': 'id', 'Organization Id': 'organization_id', 'Title': 'title',
    'Roster Date': 'roster_date', 'Blank Date': 'blank_date',
    'Separate By Group': 'separate_by_group', 'Sort By': 'sort_by',
    'Personnel Snapshot': 'personnel_snapshot', 'Filter Config': 'filter_config',
    'Signed File Path': 'signed_file_path', 'Created By': 'created_by',
    'Created At': 'created_at', 'Personnel Ids': 'personnel_ids',
    'Scope Group Ids': 'scope_group_ids'
}
nested = {'personnel_snapshot', 'filter_config', 'personnel_ids', 'scope_group_ids'}
excel = []
for values in workbook['rows']:
    row = {}
    for header, value in zip(workbook['headers'], values, strict=True):
        key = columns[header]
        row[key] = json.loads(value) if key in nested and isinstance(value, str) else value
    excel.append(row)

def by_id(rows):
    indexed = {row['id']: row for row in rows}
    assert len(indexed) == len(rows), 'Duplicate roster IDs'
    return indexed

assert len(source) == 1004, 'Expected three original and 1,001 cohort rows'
assert by_id(source) == by_id(backup), 'JSON must retain every raw field and value'
assert by_id(source) == by_id(excel), 'Workbook must retain every raw field and value'
before = json.loads((root / 'before-seed.json').read_text())['rows']
after = json.loads((root / 'after-cleanup-rosters.json').read_text())['rows']
assert len(before) == 3 and by_id(before) == by_id(after), 'Cleanup must preserve all original rows'
foreign = json.loads((root / 'foreign-source-rosters.json').read_text())['rows']
assert not (by_id(source).keys() & by_id(foreign).keys()), 'Foreign roster admitted'
print(json.dumps({'status': 'PASS', 'jsonRows': len(backup), 'workbookRows': len(excel),
                  'originalRowsPreserved': len(after), 'foreignRowsExcluded': len(foreign)}))
