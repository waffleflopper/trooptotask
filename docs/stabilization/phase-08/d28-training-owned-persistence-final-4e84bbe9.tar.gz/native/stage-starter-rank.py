import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
rp=pathlib.Path(__file__).parent/'runtime.json';s=json.loads(rp.read_text());p=s['ownerPage'];org=s['fixture']['ids']['orgA']
d.act('rank-reference-native-open','link','Ranks',p);d.snap('rank-reference-loaded',p);d.shot('rank-reference-loaded',p)
path='/org/'+org+'/api/starter-configuration-packs/first-week-operations/apply'
fn='async()=>{const r=await fetch('+json.dumps(path)+',{method:"POST"});return {method:"POST",path:'+json.dumps(path)+',status:r.status,body:await r.json()}}'
a=d.result_value(d.evaluate('starter-apply-api',fn,p));assert a['status']==200 and len(a['body']['created'])==7 and a['body']['failed']==[],a
for table in ['training_types','onboarding_templates','onboarding_template_steps']:d.call('starter-saved-'+table,['rows',table,'orgA'],True)
b=d.result_value(d.evaluate('starter-reapply-api',fn,p));assert b['status']==200 and b['body']['created']==[] and len(b['body']['skipped'])==7 and b['body']['failed']==[],b
for table in ['training_types','onboarding_templates','onboarding_template_steps']:d.call('starter-reapply-'+table,['rows',table,'orgA'],True)
c=d.result_value(d.evaluate('starter-none-denial-api',fn,s['nonePage']));assert c['status']==403,c
for table in ['training_types','onboarding_templates','onboarding_template_steps']:d.call('starter-denied-'+table,['rows',table,'orgA'],True)
