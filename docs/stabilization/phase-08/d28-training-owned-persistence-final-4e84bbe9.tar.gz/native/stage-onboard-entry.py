import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
rp=pathlib.Path(__file__).parent/'runtime.json';s=json.loads(rp.read_text())
for org in ['orgA','orgB']:
 for table in ['onboarding_templates','onboarding_template_steps','personnel_onboardings','onboarding_step_progress']:d.call('original-'+org+'-'+table,['rows',table,org],True)
a=d.call('onboarding-only-actor',['actor','onboardingConfigure','onboarding/templates'],True);s['onboardingPage']=a['pageId'];rp.write_text(json.dumps(s,indent=2));d.snap('onboarding-only-templates',a['pageId']);d.shot('onboarding-only-templates',a['pageId'])
