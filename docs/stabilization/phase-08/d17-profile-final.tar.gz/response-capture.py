import json,re,subprocess,sys
from pathlib import Path
run=Path(sys.argv[1]); page=int(sys.argv[2]); label=sys.argv[3]; family=sys.argv[4]
def tool(name,args):
 p=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,json.dumps(args),'--worker','1'],capture_output=True,text=True,timeout=60)
 if p.returncode: raise RuntimeError(p.stdout+p.stderr)
 return json.loads(p.stdout)
x=tool('list_network_requests',{'pageId':page,'resourceTypes':['fetch'],'includePreservedRequests':True})
(run/(label+'-network-list.json')).write_text(json.dumps(x,indent=2)+'\n')
s='\n'.join(c.get('text','') for c in x.get('content',[]) if c.get('type')=='text')
lines=[l for l in s.splitlines() if 'POST ' in l and ('settings/general?/'+family) in l]
if len(lines)!=1: raise RuntimeError('Expected one captured action request: '+str(lines))
m=re.search(r'reqid=(\d+)',lines[0]); assert m
body=run/(label+'.network-response')
y=tool('get_network_request',{'pageId':page,'reqid':int(m.group(1)),'responseFilePath':str(body)})
# Header-bearing native output remains private, outside published evidence.
Path('.verification/runtime/'+label+'-private-network-details.json').write_text(json.dumps(y,indent=2)+'\n')
(run/(label+'-capture.json')).write_text(json.dumps({'pageId':page,'requestSummary':lines[0],'responseBodyFile':body.name,'redaction':'Native request/response headers excluded; actual saved response body preserved.'},indent=2)+'\n')
print(lines[0]); print(body.read_text())
