#!/usr/bin/env python3
"""Choose the fixture's literal expired date using native date-picker controls."""
import datetime,json,os,re,subprocess,sys
from pathlib import Path
page,tag=sys.argv[1:3];page=int(page)
run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');b=Path('.verification/evidence/verify-trooptotask')/run
f=json.loads((b/'fixture-stdout.json').read_text());d=datetime.date.fromisoformat(f['dates']['trainingExpiredCompleted'])
def tool(label,name,args):subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/drive.py','tool',label,name,json.dumps(args)],check=True,stdout=subprocess.DEVNULL)
for kind,value in [('month',d.strftime('%b')),('year',str(d.year))]:
 label=tag+'-'+kind;before=b/(label+'-before.txt')
 tool(label+'-before','take_snapshot',{'pageId':page,'filePath':str(before)})
 lines=[l for l in before.read_text().splitlines() if f'combobox "Select a {kind}"' in l];assert len(lines)==1
 uid=re.search(r'uid=([^\s]+)',lines[0]).group(1)
 tool(label+'-fill','fill',{'pageId':page,'uid':uid,'value':value,'includeSnapshot':True})
 tool(label+'-after','take_snapshot',{'pageId':page,'filePath':str(b/(label+'-after.txt'))})
 tool(label+'-screen','take_screenshot',{'pageId':page,'filePath':str(b/(label+'.png')),'fullPage':True})
weekday=d.strftime('%A');month=d.strftime('%B');needle=f'button "{weekday}, {month} {d.day}, {d.year}"'
subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/action.py','click',str(page),tag+'-day',needle],check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'literalCompletion':d.isoformat(),'literalExpiration':f['dates']['trainingExpiredExpires'],'nativeControls':['Select a month','Select a year',needle]}))
