from d17_policy_final_support import *
import hashlib
owner=json.load(open(RUN/'actor-owner-policies.json'))['pageId'];switch=json.load(open(RUN/'actor-switch-policies.json'))['pageId']
for p in [owner,switch]:
 control('network'+str(p)+'-final','network','state',p);control('feedback'+str(p)+'-final','feedback','state',p)
for org in ['a','b']:
 assert json.load(open(RUN/('org-'+org+'-original.json')))['rows']==json.load(open(RUN/('org-'+org+'-restored.json')))['rows']
a=json.load(open(RUN/'loss-person-original.json'))['rows'][0];b=json.load(open(RUN/'loss-person-restored.json'))['rows'][0]
assert {k:v for k,v in a.items() if k!='slug'}=={k:v for k,v in b.items() if k!='slug'}
control('clean-seeds','clean-seeds');person=json.load(open(RUN/'seed-personnel-lifecycle.json'))['ids']['person'];absent=control('owned-seed-absence','rows','personnel','orgA','id',person);assert absent['count']==0
execute('doctor-final',[*NATIVE,'doctor','--worker','1']);before=json.load(open(RUN/'doctor-start.json'));after=json.load(open(RUN/'doctor-final.json'));assert before==after and after['status']=='PASS'
root=pathlib.Path.home()/'.local/state/trooptotask-verification'/hashlib.sha256(str(pathlib.Path.cwd()).encode()).hexdigest()[:16]/'worker-1';state=json.load(open(root/'session.json'));env=json.load(open(root/'environment.json'))
assert state['id']==after['session'] and state['candidate']==after['candidate'] and state['origin']==after['origin'] and state['revision']==after['revision']
public={'session':state['id'],'candidate':state['candidate'],'origin':state['origin'],'controlPort':state['controlPort'],'project':env['project'],'processes':[{'role':role,'pid':state[role]['pid'],'start':state[role]['start']} for role in ['supervisor','appProcess','mcpProcess','browserProcess']],'container_ids':env['container_ids']}
(RUN/'owned-before-cleanup.json').write_text(json.dumps(public,indent=2))
execute('cleanup',[*NATIVE,'cleanup','--worker','1'])
p=subprocess.run(['python3','.verification/runtime/d17-policy-final-disposal.py'],capture_output=True,text=True,timeout=60);(RUN/'owned-disposal-command.txt').write_text(p.stdout+p.stderr);assert p.returncode==0
print('Original rows, dates, controls, seed absence, final doctor and owned cleanup/disposal PASS')
