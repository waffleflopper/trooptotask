import current as x,json
rows=json.loads((x.d.E/'parent-restored-full.json').read_text())['rows']['orgA'];expect={};ids={}
for n,t,f in [('counseling','counseling_records','counseling-records'),('document','personnel_documents','documents'),('follow','personnel_follow_ups','follow-ups'),('note','leader_notes','leader-notes')]:
 original=json.loads((x.c/(n+'.json')).read_text());saved=[a for a in rows[t] if a['id']==original['id']];assert len(saved)==1;row=saved[0];assert row['archived_at'] is None;ids[n]=row['id']
 for key,val in original.items():
  if key=='updated_at':continue
  if n=='follow' and key=='notes':val='Literal follow-up notes edited'
  assert row[key]==val,(n,key,row[key],val)
 expect[n]=row
(x.d.E/'group3-artifact-assertions.json').write_text(json.dumps({'status':'PASS','completeSavedRows':expect,'newArtifactCount':4,'binaryExpectedSize':4159,'binaryExpectedSha256':'05ffcb4e81ebff28114e13d72dc85635b5f6a1177ddaff3d7513465ecfcd4d91','counselingDate':'2026-10-07','nativeFollowupEditCompleteReopen':'PASS','nativeNoteArchiveRestore':'PASS','workbookLiteralComparison':'workbook-literal-comparison.json','pdfDisplayLimit':'Native Open produced PDF viewer with 1/1 and thumbnail; main canvas dark. Stored and native downloaded PDF bytes independently matched. Owned tab 3 closed.'},indent=2))
(x.d.E/'post-observation-nested-rows-control-failure.json').write_text(json.dumps({'status':'FAIL','kind':'task-local observer','failedScript':'finish-observations.py','cause':'Observer assumed flat rows; actual full reader has orgA/orgB then table arrays. No action dispatched. New cleanup driver reads actual nested schema.'},indent=2))
p=json.loads((x.c/'seed.json').read_text());print(list(p))
parent=expect['counseling']['personnel_id']
for n,f in [('counseling','counseling-records'),('document','documents'),('follow','follow-ups'),('note','leader-notes')]:
 body=x.d.E/('cleanup-'+n+'-body.json');body.write_text(json.dumps({'status':'archived'} if n=='follow' else {'action':'archive'}))
 r=x.d.call('cleanup-'+n+'-archive',['artifact-http','orgOwner','orgA',parent,'PATCH',f+'/'+ids[n],str(body)],True);print('archive',n,r.get('status'),flush=True)
 x.full('cleanup-'+n+'-archived-full')
 r=x.d.call('cleanup-'+n+'-delete',['artifact-http','orgOwner','orgA',parent,'DELETE',f+'/'+ids[n]],True);print('delete',n,r.get('status'),flush=True)
 r=x.full('cleanup-'+n+'-deleted-full');assert not any(a['id']==ids[n] for t in r['orgA'].values() for a in t)
x.d.call('cleanup-created-file-absence',['artifact-files','orgA',parent,'counseling',expect['counseling']['file_path'],'document',expect['document']['file_path']],True)
x.d.call('cleanup-maintained-seeds',['clean-seeds'],True)
x.full('restored-original-full')
