SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = '0c8be8f3-1fe7-4e61-9132-346f7cf43df0'::uuid AND p.id = 'ad841c2b-1858-4839-9688-24d640cfd417'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = '0c8be8f3-1fe7-4e61-9132-346f7cf43df0'::uuid AND id = 'adef85dd-6298-44f5-9e7f-cedf3bb823b3'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = '0c8be8f3-1fe7-4e61-9132-346f7cf43df0'::uuid AND s.onboarding_id = 'ad841c2b-1858-4839-9688-24d640cfd417'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
