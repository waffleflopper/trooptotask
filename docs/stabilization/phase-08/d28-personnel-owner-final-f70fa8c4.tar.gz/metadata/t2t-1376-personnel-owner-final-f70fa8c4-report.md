# D28 Personnel owned final native worker proof

Status: **eight selected normal outcomes PASS; ownership FULLY CLOSED**. This is worker evidence, not independent acceptance. Root must independently confirm actual closure before source edits, integration or packaging.

Frozen revision `f70fa8c435809142ece5634becf8958976a12c00`, tree `7010fc2a7baebae8f3c7bd1ba7a01647a83d46bc`. Worker1 session `0652a7e3-93b2-45ea-9bbb-285d2c22cf3e`, candidate `77fcaa6da57ae7353fc82b6b50bb2112d9a44c4b07ee29dfc9a0df6082cf9292`, owned origin `http://127.0.0.1:38189`. One driver, one app worker, native verify:app controls and documented helpers; no source/git/helper/recipe/contract/canonical writes, other app actors or nested delegation.

## Selected results

|ID|Normal outcome|Result|
|---|---|---|
|N01|Manager search/clear, Group/A-Z, saved detail; Alpha reader shows admitted IDs; ordinary viewer mutation403 with exact no effects|PASS|
|N02|Temporary Group pre-dispatch503/current retry, create/rename stable ID, referenced Person then Group deletion/unassignment and reload; Person identity/slug/dates retained|PASS|
|N03|Own pin503/retry/pin/reload/unpin; real A pin200 persisted then held through visible B admission; release leaves B quiet; original and other-user pins restored|PASS|
|N04|Native Person creation and detail edit, canonical rename, stable ID, nullable ETS cleared, DEROS retained and saved reload|PASS|
|N05|Two normal CSV rows imported with exact values; one normal backfill changes only ETS, blank DEROS retained, other imported Person unchanged, saved feedback/reload|PASS|
|N06|Owner archive/Archives/restore exact full row; operate-only DELETE202 leaves active Person and one pending request; owner native reviewPOST200 approves and archives same ID; four UI-created People natively permanently removed|PASS|
|N07|Shared Onboarding Add Person saves active custom A rank/Alpha; new Person selected in outer Member; Cancel creates no packet/progress; Personnel reload retains exact record|PASS|
|N08|Representative Calendar, Training, ICT, Dashboard, Archives, Sign-in draft reads show current Person/Group facts; one actual Person workbook preserves literal fields|PASS|

The operated archive target was temporary ImportB ID `62ddf733-06f8-4814-a733-fb6d759f16b5`; request `f2e9888a-ba47-48a9-a9f0-7fe8ef1df4dd`. Pending/noarchive and approved/archived effects were read independently. No approval retry or cascade/storage/retention matrix was added. Archives subsequently showed zero records after reload, and the active roster showed only original Able/Baker/Unassigned. All four native permanent deletes returned200; no original Person was archived or deleted.

Normal reverse observations include Alpha3/Bravo2/Unassigned2 while all four new People were active; Dashboard6present/7total, Alpha3/3, Bravo1/2 and temporary Person DEROS Oct8; Sign-in draft7included and existing three saved rosters, draft canceled. The workbook contains SPC/D28ImportAf70fa8c4/Synthetic/68W/Medic/Alpha/ETS2027-07-01/DEROS2027-06-01. No performance measurement or complete independent-feature verification is claimed.

## Preservation and closure

Initial selected originals were read once:22 tables ×A/B =44 sets,129 original rows including85 memberships. Focused effects were read between outcomes, followed by exactly one full preclean and one full postclean comparison. All129 original rows retain every captured field; all B sets are exact with no extras. Four temporary People, the temporary Group and every own/other member pin are absent. Existing Onboarding packet/progress are exact and no new packet/progress exists.

The only declared append effects before disposable-provider destruction were one approved request,22 notifications (five pending-approval, one approved,16 permanent-deletion:four recipients for each of four People), and25 expected audit events. Preclean and postclean entire sets are identical:177 final rows. Original audits/notifications/requests remained unchanged. The approved request is intentionally retained until owned database disposal, not manually deleted through privileged SQL. `clean-seeds` exited0; six inspected native pages have all network/hold/feedback/export controls unarmed. Finaldoctor PASS binds the same session/candidate/revision. All2379 frozen source/toolkit/recipe/input hashes, head/tree and driver hash match; git status is clean.

Supported cleanup exited0/PASS. Actual OS/Docker checks confirm18 owned process IDs absent,10 owned ports refused, five containers absent, their one network and two volumes absent, worker directory absent. All49 already-unlinked Chromium `/tmp` file paths are absent and their owning processes are closed. TMPDIR was unset: no exclusive external task TMP directory is claimed. All41 preexisting container IDs/names/states, original networks and original volumes are preserved. No remote database or existing local development database was accessed/reset, and no private owner worktree was written.

## Failed attempts, sanitation and limits

The first default Node26.8.2 production launch was BLOCKED by adapter-vercel's unsupported Node version; no native case was attempted. Its supported cleanup and actual closure passed, preserving41 preexisting containers. The full failed build log was disposed with that failed worker; captured launch failure and observed unsupported-version diagnostic remain separately identified. The successful owned run uses installed Node24.21.0/npm11.19.0 and Chromium152.0.7977.82. Production build and finaldoctor passed; actual runtime executable paths are captured. The Node26 attempt is not relabelled passing.

Three observation-script assertions were corrected without product/input changes: duplicate Group button UID selection; a Calendar heading expectation while the actual initial view was A-Z; and a scratch freeze comparison treating recorded head/tree result objects as strings. Fresh native control selection, actual Calendar Group catalog and all frozen hash/head/tree facts passed. These were driver expectations, not hidden product repairs.

One early scoped page-data capture mistakenly included the synthetic auth session; access/refresh token entries were sanitized with original bytes/hash declared, preserving scope facts. Final scanning found its duplicate structuredContent message and sanitized the same fields there. Postcleanup Docker-ps metadata also included full Command fields capable of containing local provider bootstrap credentials; all41 Command fields were redacted with original/per-command hashes declared, while IDs/names/states remain unchanged. No credential content was published; final credential/JWT scans are clear. See the three sanitation records and privacy receipts. The original capture mistake remains disclosed.

Exactly eight selected outcomes are fresh PASS, with zero selected failures/unrun. Historical52a retains its two ISSUE/oneUNRUN and prior1552 proof stays separately bound; old undispatched503/race proof is not relabelled fresh. Controlled503 proves pre-dispatch UI recovery, not a real provider outage. No dense/500/501/Planner/new held-save/cascade/Storage/retention variants were run. Source/SDK/request/lower checks, exact-headCI/bot review and independent acceptance are separate. Training's eight lower failures/twelve native families unrun and remaining D28 areas are outside this worker's completion claim. D29/D30 remain out of scope.

## Durable raw evidence

/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/.verification/evidence/verify-trooptotask/d28-personnel-owner-final-f70fa8c4

`normal-outcome-ledger.json` records key artifacts for each selected outcome. Full commands/snapshots/provider rows,17 PNGs and one original Blob XLSX survive cleanup. `preclean-original-comparison.json`, `postclean-original-comparison.json`, `declared-audit-notification-checks.json`, `doctor-final.json`, `freeze-final-preclosure.json`, `actual-final-closure.json` and owned identity files are the primary acceptance receipts. `inventory.json` excludes itself and binds the complete file set and hashes; the named JSON receipt binds its checksum and this report.
