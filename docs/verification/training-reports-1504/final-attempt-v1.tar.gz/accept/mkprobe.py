import json,sys
# usage: mkprobe.py PAGE ORG path1 path2 ...  (paths relative to /org/ORG/)
page=int(sys.argv[1]); org=sys.argv[2]; paths=sys.argv[3:]
fn = """async () => { const paths = %s; const out = []; for (const p of paths) { const url = '/org/%s/' + p; try { const r = await fetch(url, { credentials: 'same-origin', redirect: 'manual' }); const ct = r.headers.get('content-type') || ''; let body; if (/json|text/.test(ct)) { body = (await r.text()).slice(0, 4000); } else { const b = new Uint8Array(await r.arrayBuffer()); let s = ''; for (const x of b) s += String.fromCharCode(x); body = 'base64:' + btoa(s); } out.push({ method: 'GET', path: url, status: r.status, contentType: ct, disposition: r.headers.get('content-disposition'), body }); } catch (e) { out.push({ path: url, error: String(e) }); } } return out; }""" % (json.dumps(paths), org)
print(json.dumps({"pageId":page,"function":fn}))
