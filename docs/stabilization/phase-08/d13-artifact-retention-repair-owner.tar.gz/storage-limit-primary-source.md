Reviewed October 1, 2026: https://supabase.com/docs/guides/storage/management/delete-objects

Supabase documents a maximum of 1,000 object paths per remove call. This independently grounds the finite SDK provider prefix cap; its synthetic rejection status is not an observed live-provider status. No remote provider was accessed.
