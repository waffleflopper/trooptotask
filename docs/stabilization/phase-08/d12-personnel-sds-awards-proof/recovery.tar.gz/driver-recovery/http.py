import json,re
from flow import tool,call,base
ORG=json.loads((base/'fixture.json').read_text())['ids']['orgA']
PERSON=json.loads((base/'seed-lifecycle.json').read_text())['ids']['person']
def extract(r):
 s='\n'.join(x.get('text','') for x in r.get('content',[]))
 m=re.search(r'```json\s*([\s\S]*?)```',s)
 if not m:raise RuntimeError('Native evaluation shape changed')
 return json.loads(m[1])
def request(label,page,path,method,body):
 r=tool(label,'evaluate_script',{'pageId':page,'function':'async () => { const path='+json.dumps(path)+'; const r=await fetch(path,{method:'+json.dumps(method)+',headers:{"Content-Type":"application/json"},body:'+json.dumps(json.dumps(body,separators=(',',':')))+'}); return {path,method:'+json.dumps(method)+',status:r.status,body:await r.text()}; }','waitForStableDom':False})
 return extract(r)
def ack(label,page,person=PERSON,org=ORG,value=True):
 return request(label,page,'/org/'+org+'/api/personnel/'+person+'/award-tracking','POST',{'acknowledged':value})
def flags(label,page,route='personnel',org=ORG):
 path='/org/'+org+'/'+(route+'/' if route else '')+'__data.json'
 fn='''async () => {
 const path=PATH; const r=await fetch(path);const text=await r.text();
 if(!r.ok)return{path,status:r.status};
 const matches=[];
 for(const line of text.split('\\n').filter(Boolean)){
  const b=JSON.parse(line);const nodes=(b.nodes??[]).filter(n=>n&&Array.isArray(n.data));
  if(Array.isArray(b.data))nodes.push(b);
  for(const n of nodes){const d=n.data;
   for(const value of d){
    if(value&&typeof value==='object'&&!Array.isArray(value)&&Object.hasOwn(value,'awardTrackingAcknowledgedPersonnelIds')){
     const indexes=d[value.awardTrackingAcknowledgedPersonnelIds];
     matches.push({kind:n.type,ids:Array.isArray(indexes)?indexes.map(i=>d[i]):null});
    }
   }
  }
 }
 return {path,status:r.status,matches};
}'''.replace('PATH',json.dumps(path))
 return extract(tool(label,'evaluate_script',{'pageId':page,'function':fn,'waitForStableDom':False}))
def row(label,person=PERSON,org='orgA'):
 return call(label,'control','rows','personnel_extended_info',org,'personnel_id',person)['rows']
def siblings_equal(a,b,allowed):
 assert set(a)==set(b)
 for k in a:
  if k not in allowed:assert a[k]==b[k],(k,a[k],b[k])
 if b['updated_at']!=a['updated_at']:assert b['updated_at']>=a['updated_at']
