"""Fixed, recoverable Storage DELETE fault on one recorded synthetic counseling PDF.

Real ordinary review HTTP invokes the actual service Storage API. The fault is
privileged disposable setup, not native UI, atomic file deletion or retry proof.
Use --restore REQUEST_ID after interruption; restoration never adopts a replacement
worker/container or drops a definition that differs from its private receipt.
"""
import datetime
import json
import os
import re
import secrets
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from d18_actual_review_wait import OwnedProof, ProofFailure, bounded_execute, public_failure, require
from scripts.verification.environment import canonical_uuid, private_json


def atomic_receipt(path, value):
    descriptor, name = tempfile.mkstemp(prefix=".d18-storage-failure-", suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w") as output:
            json.dump(value, output)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
        descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        temporary.unlink(missing_ok=True)


def control_snapshot(db, name):
    # Include full definitions, comments, target relation and function binding.
    return json.loads(db._execute(f"""SELECT json_build_object(
      'trigger',(SELECT json_build_object('definition',pg_get_triggerdef(t.oid,false),
        'comment',obj_description(t.oid,'pg_trigger'),'enabled',t.tgenabled,
        'internal',t.tgisinternal,'functionSchema',n.nspname,'functionName',p.proname)
        FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid JOIN pg_namespace n ON n.oid=p.pronamespace
        WHERE t.tgrelid='storage.objects'::regclass AND t.tgname='{name}'),
      'function',(SELECT json_build_object('definition',pg_get_functiondef(p.oid),
        'comment',obj_description(p.oid,'pg_proc'),'owner',pg_get_userbyid(p.proowner))
        FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
        WHERE n.nspname='public' AND p.proname='{name}' AND p.pronargs=0));"""))


def create_sql(receipt):
    name = receipt["name"]
    path = receipt["path"]
    marker = receipt["marker"]
    comment = receipt["comment"]
    return f"""CREATE FUNCTION public.{name}() RETURNS trigger LANGUAGE plpgsql SET search_path='' AS $fault$
      BEGIN RAISE EXCEPTION '{marker}'; END $fault$;
      COMMENT ON FUNCTION public.{name}() IS '{comment}';
      CREATE TRIGGER {name} BEFORE DELETE ON storage.objects FOR EACH ROW
        WHEN(OLD.bucket_id='counseling-files' AND OLD.name='{path}') EXECUTE FUNCTION public.{name}();
      COMMENT ON TRIGGER {name} ON storage.objects IS '{comment}';"""


def probe_definition(db, receipt):
    # The definitions are independently read from PostgreSQL, then rolled back.
    # A connection/command interruption is bounded by the local idle timeout.
    name = receipt["name"]
    require(control_snapshot(db, name) == {"trigger": None, "function": None}, "A preexisting fault cannot be adopted")
    query = f"""BEGIN; SET LOCAL idle_in_transaction_session_timeout='15s';
      {create_sql(receipt)}
      SELECT json_build_object(
        'trigger',(SELECT json_build_object('definition',pg_get_triggerdef(t.oid,false),
          'comment',obj_description(t.oid,'pg_trigger'),'enabled',t.tgenabled,
          'internal',t.tgisinternal,'functionSchema',n.nspname,'functionName',p.proname)
          FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid JOIN pg_namespace n ON n.oid=p.pronamespace
          WHERE t.tgrelid='storage.objects'::regclass AND t.tgname='{name}'),
        'function',(SELECT json_build_object('definition',pg_get_functiondef(p.oid),
          'comment',obj_description(p.oid,'pg_proc'),'owner',pg_get_userbyid(p.proowner))
          FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
          WHERE n.nspname='public' AND p.proname='{name}' AND p.pronargs=0));
      ROLLBACK;"""
    expected = json.loads(db._execute(query))
    require(expected["trigger"] is not None and expected["function"] is not None, "Rollback probe did not read both definitions")
    require(control_snapshot(db, name) == {"trigger": None, "function": None}, "Rollback probe left a fault installed")
    return expected


def bound_receipt(proof, receipt, request_id):
    require(receipt.get("version") == 1 and receipt.get("repository") == str(proof.repository)
            and receipt.get("workerSession") == proof.worker["id"]
            and receipt.get("project") == proof.db.project
            and receipt.get("containerId") == proof.db.container_id
            and receipt.get("requestId") == request_id, "Fault receipt belongs to a different original worker/container")
    name = "d18_storage_fail_" + request_id.replace("-", "")
    require(receipt.get("name") == name and bool(re.fullmatch(r"[0-9a-f]{24}", receipt.get("nonce", ""))), "Fault receipt identity changed")
    require(receipt.get("marker") == "Owned synthetic Storage remove rejected " + receipt["nonce"]
            and receipt.get("comment") == f"{proof.db.project}:{proof.worker['id']}:{request_id}:{receipt['nonce']}", "Fault receipt marker/comment changed")
    request = proof.admit_request(request_id, pending=False)
    require(all(request.get(key) == receipt["before"]["request"].get(key)
                for key in ("id", "organization_id", "requested_by", "resource_type", "resource_id")), "Saved request binding changed")
    parent, path = proof.counseling_binding(receipt["before"]["request"], receipt["before"]["source"])
    require(receipt.get("parent") == parent and receipt.get("path") == path, "Receipt file binding changed")
    expected = receipt.get("expected")
    require(isinstance(expected, dict) and expected.get("trigger") is not None and expected.get("function") is not None
            and expected["trigger"].get("comment") == receipt["comment"]
            and expected["function"].get("comment") == receipt["comment"]
            and expected["trigger"].get("functionSchema") == "public"
            and expected["trigger"].get("functionName") == name, "Missing exact rollback-probed definitions")


def restore(proof, receipt_path, receipt):
    bound_receipt(proof, receipt, receipt["requestId"])
    actual = control_snapshot(proof.db, receipt["name"])
    require(all(actual[key] is None or actual[key] == receipt["expected"][key] for key in ("trigger", "function")),
            "Changed or foreign fault definition: no drop was attempted")
    require(actual["trigger"] is None or actual["function"] is not None, "Fault trigger has a foreign function binding")
    receipt["phase"] = "restoring"
    atomic_receipt(receipt_path, receipt)
    name = receipt["name"]
    proof.db._execute(f"""BEGIN; SET LOCAL idle_in_transaction_session_timeout='15s';
      DROP TRIGGER IF EXISTS {name} ON storage.objects;
      DROP FUNCTION IF EXISTS public.{name}(); COMMIT;""")
    restored = control_snapshot(proof.db, name)
    require(restored == {"trigger": None, "function": None}, "Fault removal was not acknowledged")
    receipt["phase"] = "restored"
    atomic_receipt(receipt_path, receipt)
    return restored


def file_observation(proof, name, parent, path):
    value = proof.call(name, "artifact-files", "orgA", parent, "counseling", path, timeout=35)
    matches = [file for file in value.get("files", []) if file.get("bucket") == "counseling-files" and file.get("path") == path]
    require(len(matches) == 1, "Exact recorded file observation is missing")
    return value, matches[0]


def app_log_position(proof):
    path = proof.session / "app.log"
    require(not path.is_symlink() and path.resolve() == path, "Private app log was replaced")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        stat = os.fstat(descriptor)
        require(stat.st_uid == os.getuid() and not stat.st_mode & 0o077, "Use the private owned app log")
        return path, (stat.st_dev, stat.st_ino, stat.st_size)
    finally:
        os.close(descriptor)


def storage_error_observation(proof, position, marker, since):
    path, (device, inode, offset) = position
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        stat = os.fstat(descriptor)
        require((stat.st_dev, stat.st_ino) == (device, inode) and stat.st_size >= offset, "Owned app log changed during proof")
        os.lseek(descriptor, offset, os.SEEK_SET)
        # Logs are inspected privately. Never print/archive their text or credentials.
        text = os.read(descriptor, 256 * 1024).decode("utf-8", errors="replace")
    finally:
        os.close(descriptor)
    adapter_error = any("[http-adapter] Unhandled route error:" in line and "message=Storage remove failed:" in line
                        for line in text.splitlines())
    marker_seen = marker in text
    if not marker_seen:
        # PostgreSQL's actual trigger error is a separate causal observation.
        # Only a boolean is disclosed from potentially credential-bearing logs.
        records = bounded_execute(["docker", "logs", "--since", since, "--tail", "200", proof.db.container_id],
                                  proof.db.workdir, proof.db.environment, timeout=12, include_stderr=True)
        marker_seen = marker in records
    return {"actualAdapterStorageError": adapter_error, "exactFaultMarkerObserved": marker_seen,
            "logTextDisclosed": False}


def main():
    result = {"status": "FAIL", "boundary": "Real ordinary review HTTP and service Storage API; exact privileged disposable trigger fault, not native UI, atomic file deletion or same-request retry proof"}
    proof = receipt_path = receipt = None
    armed = False
    rows = None
    try:
        restoring = len(sys.argv) == 3 and sys.argv[1] == "--restore"
        require(restoring or len(sys.argv) == 3, "Use REQUEST_ID PAGE, or --restore REQUEST_ID")
        request_id = canonical_uuid(sys.argv[2] if restoring else sys.argv[1])
        page = None if restoring else int(sys.argv[2])
        require(restoring or page > 0, "Use a positive owned page")
        proof = OwnedProof()
        receipt_path = proof.session / ("d18-storage-failure-" + request_id + ".json")
        result["requestId"] = request_id
        if restoring:
            receipt = private_json(receipt_path)
            result["restored"] = restore(proof, receipt_path, receipt)
            result.update(status="PASS", restoreOnly=True)
            print(json.dumps(result, indent=2))
            return 0
        if receipt_path.exists() or receipt_path.is_symlink():
            previous = private_json(receipt_path)
            bound_receipt(proof, previous, request_id)
            require(previous.get("phase") == "restored"
                    and control_snapshot(proof.db, previous["name"]) == {"trigger": None, "function": None},
                    "An earlier fault needs explicit --restore before another run")
        request = proof.admit_request(request_id)
        resource_id = canonical_uuid(request["resource_id"])
        org_id = canonical_uuid(request["organization_id"])
        require(request["resource_type"] == "counseling_record", "Use a recorded counseling request")

        def rows():
            return json.loads(proof.db._execute(f"""SELECT json_build_object(
              'request',(SELECT row_to_json(r) FROM (SELECT * FROM public.deletion_requests WHERE id='{request_id}'::uuid AND organization_id='{org_id}'::uuid) r),
              'source',(SELECT row_to_json(r) FROM (SELECT * FROM public.counseling_records WHERE id='{resource_id}'::uuid AND organization_id='{org_id}'::uuid) r));"""))

        before = rows()
        result["before"] = before
        parent, path = proof.counseling_binding(request, before["source"])
        files_before, original_file = file_observation(proof, "storage-fault-" + request_id + "-before-files", parent, path)
        result["filesBefore"] = files_before
        require(original_file.get("present") is True and isinstance(original_file.get("size"), int)
                and original_file["size"] > 0 and bool(re.fullmatch(r"[0-9a-f]{64}", original_file.get("sha256", ""))),
                "Recorded PDF must actually exist with a measured hash before the fault")
        nonce = secrets.token_hex(12)
        receipt = {"version": 1, "repository": str(proof.repository), "workerSession": proof.worker["id"],
                   "project": proof.db.project, "containerId": proof.db.container_id, "requestId": request_id,
                   "name": "d18_storage_fail_" + request_id.replace("-", ""), "parent": parent, "path": path,
                   "nonce": nonce, "marker": "Owned synthetic Storage remove rejected " + nonce,
                   "comment": f"{proof.db.project}:{proof.worker['id']}:{request_id}:{nonce}",
                   "before": before, "fileBefore": original_file, "phase": "prepared"}
        receipt["expected"] = probe_definition(proof.db, receipt)
        # Durable private ownership witness precedes the first committed DDL.
        atomic_receipt(receipt_path, receipt)
        armed = True
        proof.db._execute("BEGIN; SET LOCAL idle_in_transaction_session_timeout='15s'; " + create_sql(receipt) + " COMMIT;")
        require(control_snapshot(proof.db, receipt["name"]) == receipt["expected"], "Installed fault differs from its rollback probe")
        receipt["phase"] = "installed"
        atomic_receipt(receipt_path, receipt)
        result["installedExactFault"] = True
        position = app_log_position(proof)
        since = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="microseconds")
        response = proof.review("storage-fault-" + request_id + "-http", page, request_id, "approve")
        result["http"] = response
        during = rows()
        result["afterFailedRemove"] = during
        files_during, observed_file = file_observation(proof, "storage-fault-" + request_id + "-failed-files", parent, path)
        result["filesAfterFailedRemove"] = files_during
        errors = storage_error_observation(proof, position, receipt["marker"], since)
        result["storageErrorObservation"] = errors
        require(response["status"] == 500, "Real review did not return the expected failure")
        require(errors["actualAdapterStorageError"] and errors["exactFaultMarkerObserved"], "No specific real Storage/fixed-trigger failure was established")
        require(during == before, "Source row or pending request changed after Storage rejection")
        require(observed_file.get("present") is True
                and observed_file.get("size") == original_file["size"]
                and observed_file.get("sha256") == original_file["sha256"], "Actual PDF bytes were not retained unchanged")
        result.update(status="PASS", rowAndPendingStatusUnchanged=True, actualFileBytesUnchanged=True)
    except BaseException as error:
        result["failure"] = public_failure(error)
    finally:
        if armed:
            try:
                result["restored"] = restore(proof, receipt_path, receipt)
                if rows is not None:
                    result["finalReadback"] = rows()
            except BaseException as error:
                result.update(status="FAIL", cleanupFailure=public_failure(error), recovery="Use --restore REQUEST_ID on this same original running worker; the private receipt is preserved")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
