import json,os,pathlib,subprocess
base=pathlib.Path('.verification/evidence/verify-trooptotask/d21-platform-repair')
env=dict(os.environ,PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH'])
def call(args,name):
 r=subprocess.run(['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args],env=env,text=True,capture_output=True)
 (base/(name+'.json')).write_text(r.stdout)
 if r.returncode:raise RuntimeError(r.stderr)
 return json.loads(r.stdout)
for role in ['viewer','platformInactive','platformBilling']:
 a=call(['actor',role,'admin/users'],'actor-denied-'+role)
 p=call(['platform-request',str(a['pageId']),'makeAdmin','organization',json.dumps({'targetUserId':'d249fff6-c4cf-43d5-9808-8d5a9c2b9414'})],'promotion-denied-'+role)
 print(json.dumps({'role':role,'pageId':a['pageId'],'path':a['path'],'promotionStatus':p['status']}),flush=True)
 assert p['status']==403
