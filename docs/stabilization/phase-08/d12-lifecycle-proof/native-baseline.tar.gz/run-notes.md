# Native unchanged lifecycle recovery baseline

Tested revision: 097787b83357d5aac5549ee9a49038666b20cbf6; unchanged production source from 8da72739a9fc25a87d2a927317dbaf26f29cbf49. Candidate c952d341fbe801ef9c8295626b84dc0c92345cebee72f86e250897eb3f56c19b. Production app http://127.0.0.1:36403, worker2/session23aa7277-ae05-4fd8-bb96-6605559e4bee; Chromium152.0.7977.82 Arch Linux, Node24.21.0/npm11.19.0. Launch and both doctors PASS; candidate/revision unchanged throughout. Owned cleanup PASS. Files survived cleanup.

Scope: feature personnel-records-lifecycle step7 bounded bulk/restore recovery. Dedicated Alpha parent plus duplicateBravo (distinct Group labels for owner restore), nine parent artifacts, Training/ICT and unrelated Able note. IDs and exact older timestamp in seed.json. Independently archived four siblings and completed follow-up are no-effect sentinels. Document metadata only: no Storage bytes/download/deletion proof.

Manager native Archive selection names+Groups, select2, confirmation Archive. Scoped synthetic POST503 produced useful 2-person error, cleared selection/mode and changed no rows. Restore hooks; fresh selection2 and native Archive POST200 yielded 2-person success. Reload hid those exact IDs. Active note/counseling/document/open follow-up share saved parent event; open becomes archived. Other history and all original A3/B1 fields unchanged.

Separate ordinary authenticated manager same-ID bulk replay: HTTP200 but no successful IDs, two already-archived errors. This FAILS Robert's selected completion/acknowledgement rule, so is preserved as failed baseline. Already-completed native cascade remained unchanged; actual unfinished persistence is covered by separately retained lower-level faults, not invented native outage proof. Scoped Alpha replay also failed acknowledgement; Bravo concealed. Operate archived replay retains per-ID error/no write/no approval; explicit empty scope has no native Archive affordance and valid batch targets are missing; foreign A request404. Exact provider no-effects readbacks.

Owner native Settings Archives lists selected2 plus independent older duplicate. Synthetic PATCH503 retains all fields with useful feedback; restore hook then native retry200. Restore duplicateBravo natively too; older duplicate remains archived. Manager reload shows original active identities/fields. Event-owned artifacts restored; independently archived/completed rows, Training/ICT/control unchanged. Ordinary repeated active restore400; empty restore404; neither changes rows.

Actual comparisons: field-comparisons.json holds73 exact row-set comparisons; literal-lifecycle-expectations.json holds24 per-row before/archive/restore expectations. Only automatic updated_at for actively changed counseling/document/open-followup excluded from exact meaningful-field equality and recorded explicitly with monotonic check. The active note and every independent/control row remain full-field comparisons. No silent exclusions.

Limits: ids-only native network controls record actual method/status, but count0/ids[] does not prove request payload. Native selected2+exact provider2 effects identify target IDs; separate HTTP capture includes explicit body. No native late-provider partial fault claim, concurrent/transactional guarantee, file-byte lifecycle or whole-issue acceptance.

Pre-action capture operate-no-request.json failed because resource_id isn't an allowed rows filter (exit2); preserved. Corrected orgA-wide deletion_requests read is empty (operate-no-request-corrected.json). No defect/effect credit for that control failure. Artifact analysis uses only readbacks, no provider modifications. Executed artifact analysis comparisons-analysis.txt exits0 and preserves the failed product expectation.

Cleanup: restore hooks before clean-seeds; helper removed only owned seed IDs/dependents; original A3/B1 full fields equal original-a/b. Owner reload Archives0. FinaldoctorPASS and ownedcleanupPASS. No UI-created People or remote/existing local database operations.

Sanitization: synthetic accounts/IDs/names only; captures inspected for credential/token material. No redaction changes required. PNGs visually inspected. This is coordinator-run native/provider proof; independent artifact review is separate.

