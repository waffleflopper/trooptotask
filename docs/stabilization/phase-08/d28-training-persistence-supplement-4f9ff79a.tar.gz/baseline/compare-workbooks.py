import json,pathlib,collections
root=pathlib.Path('.verification/evidence/verify-trooptotask/d28-training-remaining-20261007')
p=json.loads((root/'pages-workbook-rows.json').read_text()); d=json.loads((root/'dense-workbook-rows.json').read_text()); seed=json.loads((root/'print-seed.json').read_text())
assert list(p)==['Summary','Forecast','Hot spots','Focus','Requirements']
assert dict(p['Summary'][1:])['Soldiers']==29
assert dict(p['Summary'][1:])['Applicable requirements']==31
assert len(p['Requirements'])==31
pr=p['Requirements'][1:];assert len({tuple(x[:4]) for x in pr})==30
assert sum(x[1].startswith('MapTraining1b174d53') for x in pr)==27
assert sum(x[3]=='Verification Required Training' for x in pr)==28
assert sum(x[3]=='Verification Targeted Training' for x in pr)==2
expected=[];types=seed['types'];groups=seed['groups'];tag=seed['tag']
for person in range(1,113):
 group=(person-1)//8; slot=(person-1)%8+1
 for index,t in enumerate(types):
  if index==0:
   if person>100: continue
   status,expiry,lapse,flag='Not Done',None,None,'No'
  else:
   if index==23 and group>=7: continue
   if slot>6: continue
   status,expiry,lapse,flag={1:('Not Done',None,None,'No'),2:('Not Done',None,None,'No'),3:('Expired 20d ago','2026-09-17',None,'No'),4:('Expired 5d ago','2026-10-02',None,'No'),5:('10d left','2026-10-17','2026-10-18','Yes'),6:('30d left','2026-11-06','2026-11-07','Yes')}[slot]
  expected.append(['PFC',f'PrintA{tag}{person:03d}, Synthetic',groups[group]['name'],t['name'],status,expiry,lapse,flag])
actual=d['Requirements'][1:]
assert len(expected)==1990
expected.sort(key=lambda r: (r[5] is not None,r[5] or "",r[1],next(i for i,t in enumerate(types) if t["name"]==r[3])))
assert actual==expected
summary=dict(d['Summary'][1:])
for key,value in [('Soldiers',112),('Applicable requirements',2632),('Ready',1272),('Ready today (%)',48),('Ready by 5 Jan (%)',24),('Not ready, expired',630),('Not ready, not recorded',730),('Lapse by 5 Jan',630)]:assert summary[key]==value,(key,summary[key])
receipt={'status':'PASS','boundary':'Actual native workbook contents against literal independent cohort specification. No application calculation imported.','pagesRequirements':30,'denseRequirements':1990,'denseExactRows':True,'denseStatusCounts':dict(collections.Counter(r[4] for r in actual)),'denseFirst':actual[0],'denseLast':actual[-1]}
(root/'workbook-comparison.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
