import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
def read(name):
    return json.loads((root / name).read_text())

assert read('alpha-before-denial.json') == read('alpha-after-denial.json'), 'Denied replacement changed saved row'
assert read('alpha-file-before-denial.json') == read('alpha-file-after-denial.json'), 'Denied replacement changed file'
assert read('viewer-denied-replacement.json')['status'] == 403
page = read('scoped-page-two.json')
assert page['status'] == 200 and page['body']['total'] == 2
assert len(page['body']['rosters']) == 1
assert page['body']['rosters'][0]['title'] == 'Verification Alpha Snapshot'
assert page['body']['rosters'][0]['personnelSnapshot'][0]['firstName'] == 'Prior'
assert read('files-after-failed-upload.json')['files'] == []
assert read('row-after-removal.json')['rows'][0]['signed_file_path'] is None
assert read('files-after-removal.json')['files'] == []
assert len(read('file-before-bearing-delete.json')['files']) == 1
assert read('row-before-bearing-delete.json')['rows'][0]['signed_file_path']
assert read('deleted-row.json')['count'] == 0 and read('deleted-row.json')['rows'] == []
assert read('deleted-files.json')['files'] == []
uploaded = (root / 'generated.pdf').read_bytes()
assert uploaded == (root / 'opened-scan.pdf').read_bytes(), 'Opened scan differs from upload'
assert read('uploaded-files.json')['files'][0]['sha256'] == hashlib.sha256(uploaded).hexdigest()
print(json.dumps({'status': 'PASS', 'scopedTotal': 2, 'viewerDenial': 403,
                  'fileBearingDeletion': 'row and object absent', 'openedPdfBytes': len(uploaded),
                  'openedPdfSha256': hashlib.sha256(uploaded).hexdigest()}))
