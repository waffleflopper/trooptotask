SET statement_timeout = '10s'; SET lock_timeout = '3s';
BEGIN;
CREATE FUNCTION public.t2t_d15_legacy_write_fault_a8f0cefb() RETURNS trigger LANGUAGE plpgsql SET search_path = '' AS $d15$
BEGIN
 IF NEW.id = '81e754a1-532c-4938-a1db-3254a16cecde'::uuid AND NEW.organization_id = '3995a836-b3d3-4d96-aadd-00512ac98a40'::uuid AND NEW.onboarding_id = 'ed483297-52eb-4a25-9dea-a253e4cf4395'::uuid THEN
  RAISE EXCEPTION USING ERRCODE = 'P0001', MESSAGE = 't2t-d15 intentional owned legacy progress fault';
 END IF;
 RETURN NEW;
END;
$d15$;
COMMENT ON FUNCTION public.t2t_d15_legacy_write_fault_a8f0cefb() IS 't2t-d15 project=t2t-verify-f6efecd5eb8e4428b86adafb seed=81e754a1-532c-4938-a1db-3254a16cecde';
CREATE TRIGGER t2t_d15_legacy_write_fault_a8f0cefb BEFORE INSERT OR UPDATE ON public.onboarding_step_progress FOR EACH ROW EXECUTE FUNCTION public.t2t_d15_legacy_write_fault_a8f0cefb();
COMMENT ON TRIGGER t2t_d15_legacy_write_fault_a8f0cefb ON public.onboarding_step_progress IS 't2t-d15 project=t2t-verify-f6efecd5eb8e4428b86adafb seed=81e754a1-532c-4938-a1db-3254a16cecde';
COMMIT;
SELECT json_build_object('event', 'owned-legacy-fault-installed');
