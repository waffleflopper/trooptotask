import {createServer} from '/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/node_modules/vite/dist/node/index.js';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const root='/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93';
const vite=await createServer({root,configFile:false,server:{middlewareMode:true},resolve:{alias:{'$lib':root+'/src/lib','$features':root+'/src/features'}}});
const results=[];
try {
 for(const [file,name] of [['trainingTypeEntity','TrainingTypeEntity'],['trainingViewEntity','TrainingViewEntity'],['personnelTrainingEntity','PersonnelTrainingEntity']]) {
  const entity=(await vite.ssrLoadModule('/src/features/training/server/'+file+'.server.ts'))[name];
  const raw={id:'saved-id',organization_id:'org-a',created_at:null,updated_at:null,created_by:null,notes:null,certificate_url:null,applies_to_roles:null,column_ids:null,is_optional:null};
  const present=entity.fromDb(raw), missing=entity.fromDb({id:'saved-id'});
  assert.equal(present.id,'saved-id'); assert.equal(present.organization_id,'org-a');
  if(name==='TrainingViewEntity') {assert.equal(present.createdBy,null);assert.equal(present.createdAt,null);assert.equal(present.updatedAt,null);assert.deepEqual(present.columnIds,[]);}
  else {assert.equal(present.created_at,null);assert.equal(present.updated_at,null);}
  if(name==='TrainingTypeEntity') {assert.deepEqual(present.appliesToRoles,[]);assert.equal(present.isOptional,false);assert.equal(Object.hasOwn(missing,'appliesToRoles'),false);}
  assert.equal(missing.created_at,undefined);assert.equal(missing.organization_id,undefined);
  const update=entity.toDbUpdate({id:'new-id',name:'Changed',createdBy:'other',createdAt:'bad',updatedAt:'bad'});
  assert.equal(Object.hasOwn(update,'id'),false);assert.equal(Object.hasOwn(update,'created_by'),false);assert.equal(Object.hasOwn(update,'created_at'),false);assert.equal(Object.hasOwn(update,'updated_at'),false);
  results.push({name,present,missing,update});
 }
 const {countTrainingTypes}=await vite.ssrLoadModule('/src/features/training/server/trainingCatalogRead.server.ts');
 assert.equal(await countTrainingTypes({findManyWithCount:async()=>({data:[{id:'saved-id'}],count:null})},'org-a'),0);
 results.push({case:'estimated count null',value:0});
 await fs.writeFile(process.argv[2],JSON.stringify({status:'PASS',boundary:'actual current entity/service modules, offline literal inputs; not native or real provider proof',results},null,2));
 console.log('PASS 3 current entity present/null/missing/read-only mappings and estimated count null.');
} finally {await vite.close();}
