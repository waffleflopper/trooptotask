SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('ed483297-52eb-4a25-9dea-a253e4cf4395'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('81e754a1-532c-4938-a1db-3254a16cecde'::uuid,'210483a9-5e08-42aa-9c3d-8492e148e4e4'::uuid,'f7660772-c9c6-4c5c-98c7-12fe3ad79bc0'::uuid)) s), '[]'::json));
