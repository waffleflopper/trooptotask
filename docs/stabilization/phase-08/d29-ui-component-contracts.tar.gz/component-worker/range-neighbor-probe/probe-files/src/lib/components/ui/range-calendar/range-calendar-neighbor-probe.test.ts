// @vitest-environment happy-dom
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/svelte';
import RangeCalendarNeighborProbe from './RangeCalendarNeighborProbe.svelte';

describe('RangeCalendar neighboring cross-month selection', () => {
	afterEach(cleanup);

	it('retains usable end-date focus when a selected range ends beyond the starting month trailing week', async () => {
		render(RangeCalendarNeighborProbe);
		const start = screen.getByRole('button', { name: /September 30, 2026/ });
		start.focus();
		await fireEvent.keyDown(start, { key: 'Enter' });

		for (const date of [
			/October 1, 2026/,
			/October 2, 2026/,
			/October 3, 2026/,
			/October 4, 2026/,
			/October 5, 2026/,
			/October 6, 2026/,
			/October 7, 2026/,
			/October 8, 2026/,
			/October 9, 2026/,
			/October 10, 2026/
		]) {
			await fireEvent.keyDown(document.activeElement!, { key: 'ArrowRight' });
			const next = await screen.findByRole('button', { name: date });
			await waitFor(() => expect(document.activeElement).toBe(next));
		}

		await fireEvent.keyDown(document.activeElement!, { key: ' ' });
		expect(screen.getByLabelText('Selected start date')).toHaveTextContent('2026-09-30');
		expect(screen.getByLabelText('Selected end date')).toHaveTextContent('2026-10-10');
		expect.soft(document.activeElement).toHaveAccessibleName(/October 10, 2026/);
		expect(screen.queryByRole('button', { name: /October 10, 2026/ })).not.toBeNull();
	});
});
