import json,re,hashlib,datetime,collections
from pathlib import Path
P=Path('.verification/evidence/verify-trooptotask/d24-export-baseline'); O=Path('.verification/tmp/d24-artifact-review')
load=lambda n:json.loads((P/n).read_text())
books={n:json.loads((O/(n+'-expanded.json')).read_text())['sheets'] for n in ['owner-a','admin-a']}
exports={n:load(n+'.json') for n in books};fixture=load('fixture.json');orgA=fixture['ids']['orgA'];orgB=fixture['ids']['orgB'];issues=[];checks=[]
sourceA={x.name[len('source-before-'):-len('-A.json')]:json.loads(x.read_text())['rows'] for x in P.glob('source-before-*-A.json')}
sourceB={x.name[len('source-before-'):-len('-B.json')]:json.loads(x.read_text())['rows'] for x in P.glob('source-before-*-B.json')}
mutable={'data_exports','audit_logs','notifications'}
norm=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
def cellkey(header,keys):
 special={'Duty Role':'clinic_role','PCS / DEROS':'deros','ETS':'ets'}
 if header in special:return special[header]
 match=[k for k in keys if norm(k)==norm(header)]
 return match[0] if len(match)==1 else None
def cell_equal(cell,expected):
 if expected is None:return cell is None or cell==''
 if isinstance(expected,(dict,list)):
  try:return json.loads(cell)==expected
  except (TypeError,ValueError):return False
 return cell==expected
static_tables=[];all_unverified_fields={};foreignids={r['id'] for rows in sourceB.values() for r in rows if 'id' in r}
foreignids-={r['id'] for rows in sourceA.values() for r in rows if 'id' in r}
for name,payload in exports.items():
 inv=payload['sectionInventory']; sections=payload['sections'];book=books[name];raw=[s for s in book if s['name'].startswith('Raw - ')]; wi=book[0]
 if len(inv)!=38 or len(sections)!=38 or len(raw)!=38 or len(book)!=57:issues.append({'artifact':name,'error':'manifest_or_sheet_count','counts':[len(inv),len(sections),len(raw),len(book)]})
 if len({x['key'] for x in inv})!=38:issues.append({'artifact':name,'error':'duplicate_key'})
 if payload['organizationId']!=orgA:issues.append({'artifact':name,'error':'target'})
 for entry in inv:
  key=entry['key'];table=entry['table'];rows=sections[key]
  if entry['rowCount']!=len(rows) or payload.get(key)!=rows:issues.append({'artifact':name,'section':key,'error':'count_or_mirror'})
  if table in sourceA and table not in mutable:
   expected=sourceA[table];actual={r['id']:r for r in rows}
   if set(actual)!={r['id'] for r in expected}:issues.append({'artifact':name,'section':key,'error':'static_id_set'})
   fields=0;unverified=set()
   for e in expected:
    a=actual.get(e['id'],{})
    for k,v in e.items():
     fields+=1
     if a.get(k)!=v or k not in a:issues.append({'artifact':name,'section':key,'id':e['id'],'field':k,'error':'static_literal_value','expected':v,'actual':a.get(k)})
    unverified.update(set(a)-set(e))
   checks.append({'artifact':name,'table':table,'source_rows':len(expected),'fields_compared':fields,'additional_export_fields_without_source_readback':sorted(unverified)})
  for r in rows:
   if table not in mutable:
    for col in ['organization_id','org_id']:
     if col in r and r[col]!=orgA:issues.append({'artifact':name,'section':key,'error':'foreign_org'})
 for sheet,ir in zip(raw,wi['rows']):
  key=ir[4];count=ir[5];rows=sections[key];table=next(x['table'] for x in inv if x['key']==key)
  if len(sheet['rows'])!=count:issues.append({'artifact':name,'section':key,'error':'workbook_inventory_count'})
  if not sheet['rows']:
   if sheet['headers']!=['No records']:issues.append({'artifact':name,'section':key,'error':'empty_sheet_header'})
   continue
  rowkeys=set().union(*(r.keys() for r in rows));mapped=[cellkey(h,rowkeys) for h in sheet['headers']]
  if None in mapped:issues.append({'artifact':name,'section':key,'error':'unmapped_header','headers':sheet['headers'],'keys':sorted(rowkeys)})
  byid={r['id']:r for r in rows};ididx=mapped.index('id');ids=[]
  for cells in sheet['rows']:
   padded=cells+[None]*(len(mapped)-len(cells));rid=padded[ididx];ids.append(rid)
   if rid not in byid:
    if table not in mutable:issues.append({'artifact':name,'section':key,'error':'workbook_unexpected_id','id':rid})
    continue
   original=byid[rid]
   for k,c in zip(mapped,padded):
    if table in mutable or k is None:continue
    if not cell_equal(c,original.get(k)):issues.append({'artifact':name,'section':key,'id':rid,'field':k,'error':'workbook_literal_value','actual':c,'expected':original.get(k)})
  if table not in mutable and set(ids)!=set(byid):issues.append({'artifact':name,'section':key,'error':'workbook_id_set'})
  checks.append({'artifact':name,'raw_sheet':sheet['name'],'table':table,'actual_rows':len(sheet['rows']),'inventory_rows':count,'json_rows':len(rows),'compared_mutable_rows':False if table in mutable else None})
 text=json.dumps(payload);btext=json.dumps(book);leaks=[i for i in foreignids if i in text or i in btext]
 if leaks:issues.append({'artifact':name,'error':'foreign_source_ids','ids':leaks})
 for s in book:
  if s['name']=='Personnel':
   ix=s['headers'].index('Leader Notes')
   if any(len(r)>ix and r[ix] not in [None,''] for r in s['rows']):issues.append({'artifact':name,'error':'legacy_note_nonblank'})
expanded=load('owner-workbook-expanded.json')
if expanded!={'sheets':books['owner-a']}:issues.append({'error':'root_workbook_expansion_disagrees'})
for label in ['owner-json','owner-excel','admin-json','admin-excel']:
 if label=='owner-json':af='owner-a.json';saved='owner-json-saved-after.json';life='owner-json-lifecycle-after.json';before='source-before-data_exports-A.json';network='owner-json-network-after.json';reload='owner-json-lifecycle-reload.json'
 elif label=='owner-excel':af='owner-a.xlsx';saved='owner-excel-saved-after.json';life='owner-excel-lifecycle-after.json';before='before-owner-excel-data_exports.json';network='owner-excel-network-after.json';reload='owner-excel-lifecycle-reload.json'
 elif label=='admin-json':af='admin-a.json';saved='admin-json-saved.json';life='admin-json-lifecycle.json';before='before-admin-json-data_exports.json';network='admin-json-network.json';reload='admin-lifecycle-reload.json'
 else:af='admin-a.xlsx';saved='admin-excel-saved.json';life='admin-excel-lifecycle.json';before='before-admin-excel-lifecycle.json';network='admin-excel-network.json';reload='admin-lifecycle-reload.json'
 b=(P/af).read_bytes();save=load(saved);pre=load(before)['rows'];post=load(life)['rows'];added=[r for r in post if r['id'] not in {r['id'] for r in pre}]
 if len(added)!=1 or len(b)!=save['bytes'] or hashlib.sha256(b).hexdigest()!=save['sha256']:issues.append({'artifact':label,'error':'size_hash_or_lifecycle_delta'})
 for r in added:
  if r['org_id']!=orgA or r['status']!='completed' or r['file_size_bytes']!=len(b) or not r['completed_at']:issues.append({'artifact':label,'error':'lifecycle_facts','row':r})
  rr={x['id']:x for x in load(reload)['rows']}.get(r['id'])
  if rr!=r:issues.append({'artifact':label,'error':'reload_lifecycle_change'})
 net=load(network)
 if len(net['calls'])!=1 or net['calls'][0]['status']!=200:issues.append({'artifact':label,'error':'network_success_receipt'})
 checks.append({'artifact':label,'bytes':len(b),'sha256':save['sha256'],'filename':save['filename'],'new_lifecycle_rows':added,'network':net['calls']})
result={'issues':issues,'checks':checks,'source_tables_A':len(sourceA),'foreign_resource_ids_tested':len(foreignids),'unreadback_tables':[x['table'] for x in exports['owner-a']['sectionInventory'] if x['table'] not in sourceA],'static_table_comparisons':len([x for x in checks if 'fields_compared' in x]),'static_fields_compared':sum(x.get('fields_compared',0) for x in checks),'artifact_file_hashes':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['owner-a.json','owner-a.xlsx','admin-a.json','admin-a.xlsx']}}
(O/'comparison-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['issues','source_tables_A','foreign_resource_ids_tested','unreadback_tables','static_table_comparisons','static_fields_compared']}))
