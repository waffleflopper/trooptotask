<script lang="ts">
	import { cn, type WithElementRef } from '$lib/utils.js';
	import type { Attachment } from 'svelte/attachments';
	import type { HTMLSelectAttributes } from 'svelte/elements';
	import ChevronDownIcon from '@lucide/svelte/icons/chevron-down';

	type NativeSelectProps = Omit<WithElementRef<HTMLSelectAttributes>, 'size'> & {
		size?: 'sm' | 'default';
	};

	let {
		ref = $bindable(null),
		value = $bindable(),
		class: className,
		size = 'default',
		children,
		onchange,
		...restProps
	}: NativeSelectProps = $props();

	const refAttachment: Attachment<HTMLSelectElement> = (node) => {
		ref = node;
		return () => {
			ref = null;
		};
	};
</script>

<div
	class={cn('cn-native-select-wrapper group/native-select relative w-fit has-[select:disabled]:opacity-50', className)}
	data-slot="native-select-wrapper"
	data-size={size}
>
	<select
		{@attach refAttachment}
		bind:value
		data-slot="native-select"
		data-size={size}
		onchange={(event) => {
			onchange?.(event);

			if (!event.defaultPrevented) {
				value = event.currentTarget.value;
			}
		}}
		class="border-input placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 dark:hover:bg-input/50 focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:aria-invalid:border-destructive/50 h-8 w-full min-w-0 appearance-none rounded-lg border bg-transparent py-1 pr-8 pl-2.5 text-sm transition-colors select-none focus-visible:ring-3 aria-invalid:ring-3 data-[size=sm]:h-7 data-[size=sm]:rounded-[min(var(--radius),10px)] data-[size=sm]:py-0.5 outline-none disabled:pointer-events-none disabled:cursor-not-allowed"
		{...restProps}
	>
		{@render children?.()}
	</select>
	<ChevronDownIcon
		class="text-muted-foreground top-1/2 right-2.5 size-4 -translate-y-1/2 pointer-events-none absolute select-none"
		aria-hidden
		data-slot="native-select-icon"
	/>
</div>
