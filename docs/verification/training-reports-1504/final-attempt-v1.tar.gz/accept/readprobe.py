import json,sys,re,base64,os
t=json.load(open(sys.argv[1]))['content'][0]['text']; d=json.loads(re.search(r'```json\s*([\s\S]*?)```',t).group(1))
out=sys.argv[2] if len(sys.argv)>2 else None
for i,x in enumerate(d):
    b=x.get('body') or ''
    if b.startswith('base64:'):
        fn=f"{out}-{i}.xlsx"; open(fn,'wb').write(base64.b64decode(b[7:])); b=f'[xlsx saved {fn}]'
    print(x.get('status'), x['path'].split('/',3)[-1], '|', b[:300].replace('\n',' '))
