import pathlib,json,zipfile,xml.etree.ElementTree as E,hashlib,re
P=pathlib.Path(__file__).parent
load=lambda p:json.loads(p.read_text())
def find(x,key):
 if isinstance(x,dict):
  if key in x:return x[key]
  for v in x.values():
   q=find(v,key)
   if q is not None:return q
 elif isinstance(x,list):
  for v in x:
   q=find(v,key)
   if q is not None:return q
 return None
def read_sheet(f):
 ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
 with zipfile.ZipFile(f) as z:
  strings=[''.join(t.itertext()) for t in E.fromstring(z.read('xl/sharedStrings.xml')).findall('x:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
  names=[n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')];assert len(names)==1
  rows=[]
  for r in E.fromstring(z.read(names[0])).findall('.//x:sheetData/x:row',ns):
   a={}
   for c in r.findall('x:c',ns):
    v=c.find('x:v',ns); val=v.text if v is not None else ''.join(c.find('x:is',ns).itertext()) if c.find('x:is',ns) is not None else ''
    if c.get('t')=='s':val=strings[int(val)]
    a[re.sub('[0-9]','',c.get('r'))]=val
   rows.append([a.get(chr(65+j),'') for j in range(max(ord(k)-64 for k in a))])
  return rows,len(z.namelist())
results=[]
for n in ['baseline','final']:
 d=P/('d28-residual-settings-'+n); orig=load(d/'original-full.json')['rows'];rest=load(d/'after-clean-seeds-full.json')['rows'];saved=load(d/'defaults-saved-full.json')['rows'];total=0;diff=[]
 for org,ts in orig.items():
  for table,rs in ts.items():
   if table=='audit_logs':continue
   total+=len(rs);assert rest[org][table]==rs,(n,org,table)
   for a,b in zip(rs,saved[org][table]):
    for k in set(a)|set(b):
     if a.get(k)!=b.get(k):diff.append([org,table,a['id'],k,a.get(k),b.get(k)])
 assert total==99;assert len(diff)==2 and {x[3] for x in diff}=={'critical_tasks_default_expiration_months','critical_tasks_expiring_soon_warning_days'}
 assert saved['orgA']['organizations'][0]['critical_tasks_default_expiration_months']==18;assert saved['orgA']['organizations'][0]['critical_tasks_expiring_soon_warning_days']==45
 memfile=d/('owner-members-decoded.json' if n=='baseline' else 'owner-members-data-decoded.json'); m=find(load(memfile),'membersSettings')['sections']['members'];source={x['id']:x for x in orig['orgA']['organization_memberships']};assert len(m['rows'])==64
 for x in m['rows']:
  a=source[x['id']];assert [x['organizationId'],x['userId'],x['membershipRole'],x['createdAt']]==[a['organization_id'],a['user_id'],a['role'],a['created_at']]
 assert m['invitations']==[] and m['invitationHistory']==[]
 for x in m['rows']:
  a=source[x['id']];governor=a['role'] in ['admin','owner']
  expectedCaps={k:'configure' for k in ['calendar','personnel','training','criticalTasks','onboarding','ratingScheme']} if governor else a['capability_overrides']
  assert x['access']['capabilityMap']==expectedCaps
  assert x['access']['memberPreset']==('editor' if governor else 'viewer')
  scoped=not governor and a['access_scope_kind']=='groups';ids=a['access_scope_group_ids'] if scoped else []
  assert x['access']['scopeSet']==({'kind':'groups','groupIds':ids} if scoped else {'kind':'organization'})
  assert x['editor']['scopeGroupIds']==ids and x['editor']['scopeKind']==('groups' if scoped else 'organization')

 cand= find(load(d/'owner-danger-data-decoded.json'),'transferOwnershipCandidates') if (d/'owner-danger-data-decoded.json').exists() else find(load(d/'owner-danger-decoded.json'),'transferOwnershipCandidates')
 expected=[{'id':a['id'],'userId':a['user_id'],'email':a['email'],'membershipRole':a['role']} for a in source.values() if a['role']!='owner' and a['user_id'] and a['email'] and a['email'].strip()]
 assert sorted(cand,key=lambda x:x['id'])==sorted(expected,key=lambda x:x['id']);assert len(cand)==3
 a=orig['orgA'];people=sorted(a['personnel'],key=lambda x:(x['last_name'],x['first_name']));tasks=sorted([t for t in a['ict_tasks'] if t['archived_at'] is None],key=lambda t:t['sort_order']);comp={(c['personnel_id'],c['ict_task_id']):c for c in a['personnel_ict_completions']};groups={g['id']:g['name'] for g in a['groups']}
 applicable=[(s,t) for s in people for t in tasks if not t['mos'] or s['mos'] in t['mos']]; assert len(applicable)==5
 ready=[(s,t) for s,t in applicable if (s['id'],t['id']) in comp];assert len(ready)==1
 only=next(iter(comp.values()));assert only['completed_at']=='2026-09-14';assert tasks[0]['expiration_months']==12
 mat=[['Name','Rank','MOS','Duty Role','Group']+[t['task_code']+' '+t['title'] for t in tasks]]
 for s in people:
  row=[s['last_name']+', '+s['first_name'],s['rank'],s['mos'],s['clinic_role'],groups.get(s['group_id'],'')]
  for t in tasks:
   row.append('' if t['mos'] and s['mos'] not in t['mos'] else 'Current (2026-09-14)' if (s['id'],t['id']) in comp else 'Not Recorded')
  while row and row[-1]=='':row.pop()
  mat.append(row)
 report=[['Section','Metric','Value','Subtitle'],['At-Risk Soldiers','Baker, Synthetic','0%','SPC 11B; Bravo; 0 expiring <=45d; No ICT update'],['At-Risk Soldiers','Unassigned, Synthetic','0%','SPC 68W; ; 0 expiring <=45d; No ICT update'],['At-Risk Soldiers','Able, Synthetic','50%','SPC 68W; Alpha; 0 expiring <=45d; 0 days since update'],['Tasks Below Unit Threshold','VERIFY-ICT-ALL Verification All-MOS Critical Task','0%','3 Soldiers need it'],['Tasks Below Unit Threshold','VERIFY-ICT-ALPHA Verification Alpha Critical Task','50%','1 Soldiers need it'],['Summary','Overall Readiness','20%','+20 pts vs 30d'],['Summary','Soldiers Below 70%','3','3 applicable Soldiers'],['Summary','Tasks Expiring <=45d','0','0 Soldiers affected'],['Summary','Tasks Below Threshold','2','Below 70% unit completion']]
 files=sorted(d.glob('*.xlsx'));zips=[]
 for f in files:
  rows,zc=read_sheet(f);assert rows==(mat if 'matrix' in f.name else report),(n,f.name);zips.append({'file':f.name,'sheets':1,'dataRows':len(rows)-1,'zipMembers':zc,'allCellsExact':True})
 dashfile=d/('owner-dashboard-decoded.json' if n=='baseline' else 'owner-dashboard-A-decoded.json');summary=find(load(dashfile),'ictlSummary');assert [summary[k] for k in ['readyCount','applicableCount','overallReadinessPercent','expiringSoonWindowDays']]==[1,5,20,45]
 bfile=d/('switch-B-dashboard-data-decoded.json' if n=='baseline' else 'switch-dashboard-B-decoded.json');bs=find(load(bfile),'ictlSummary');assert [bs[k] for k in ['readyCount','applicableCount','overallReadinessPercent','expiringSoonWindowDays']]==[0,0,0,60]
 audits=len(rest['orgA']['audit_logs']);assert audits==(8 if n=='baseline' else 3) and len(rest['orgB']['audit_logs'])==0
 results.append({'run':n,'fullBusinessRowsets':16,'all99OriginalRowsFieldsKeysTimestampsExact':True,'savedChangesOnly':diff,'membersFullCoreFacts':64,'all64CapabilityAndScopeFactsLiteral':True,'candidatesFullFourFacts':cand,'observedMemberProviderOrder':[x['id'] for x in m['rows']],'SQLOrderNotProviderOracle':True,'literalApplicable':5,'literalReady':1,'AbleReadyApplicable':[1,2],'overrideExpiry':'2027-09-14','workbooks':zips,'dashboardA':[1,5,20,45],'dashboardB':[0,0,0,60],'auditsUntilDisposal':audits})
(P/'semantic-restoration.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k not in ['observedMemberProviderOrder','candidatesFullFourFacts','savedChangesOnly']} for x in results],indent=2))
