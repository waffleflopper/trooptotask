# D29 first implementation native run

Tested source `86f798acc71b9b6297724b848b72bb050c23d3f3`, candidate `aceb7cec59a524d8407e3e339b4e1fb62edf4ce0d5f92e16982f1c08d0f82915`, owned worker 2, origin http://127.0.0.1:36875, session `9bfa89ac-a9de-4d34-ab27-7b839b649856`. Node 24.21.0, npm 11.12.1, Chromium 152.0.7977.82. Normal synthetic manager page 2 and platformReviewer page 3. Organization and fixture identities are recorded in fixture/login/readback JSON. Launch, initial/final doctor and owned cleanup PASS. No seeds or network/provider controls were armed. No save, import or archive mutation was dispatched.

This is a partial passing run with preserved application failures. Later repairs require distinct follow-up proof.

| Contract | Actual observation | Captures |
| --- | --- | --- |
| App tooltip | Home hover and genuine Tab focus expose unique c16, role tooltip and resolving description. Escape dismisses and keeps Home focus. | 004–007, 016–019 |
| App mobile navigation | Current Home closes; focused Home Escape closes and restores Toggle Sidebar; ordinary Personnel navigation closes without retained tooltip. | 023–038 |
| Header tooltip | Genuine Tab focus exposes c6 and correct semantics; Escape keeps trigger focus; hover/pointer activation dismisses. | 043–052 |
| Header keyboard activation | FAILED. With pointer away and keyboard-focused tooltip visibly open, Enter changes light to dark but tooltip remains, changing to Light mode. Theme restored through Enter and Escape. | 116–123, especially 119–121 |
| Personnel dialog and Calendar | Edit contains forward/backward boundary focus. Previous/Next month and actual ArrowLeft/Enter choose October 2, 2026, announce selection, close popover and return focus to ETS. Escape restores original Edit focus; reopening shows absent canceled draft. | 055–079 |
| Archive cancel | Actual Able alertdialog explains history retention. Cancel returns focus to the same Archive control; no modal or stored changes remain. | 080–083 |
| Import errors | Invalid rank/date CSV yields 0 ready / 1 blocked, no import selection, editable fields. Rank pointer/keyboard c481 and ETS keyboard c483 expose unique IDs, role tooltip and matching descriptions. Escape dismisses while retaining Rank focus; Cancel returns to Personnel. | 084–101 |
| Stored Personnel | Privileged readback before versus after cancels is deep-equal for all three original rows, including exact IDs/null ETS/DEROS/active values. This is readback, not native interaction or ordinary authorization proof. | rows-before.json, rows-after-cancels.json |
| Admin tooltip | Normal admitted Users content loads 82 directory accounts, 20 visible rows. Hover Users exposes unique c14, role tooltip and resolving description. Escape dismisses. | 124–130 |
| Admin mobile navigation | FAILED. Current Users activation retains Sidebar modal, and ordinary Dashboard navigation changes actual URL/title/content while modal remains open. Escape separately closes and restores Toggle Sidebar focus. | 134–149, especially 137–138 and 145–146; 139, 143 |
| Final restoration | Manager Personnel is light with zero dialogs/tooltips; desktop viewport restored; final doctor accepts original source/digest and owned cleanup disposes worker 2. | 148–150, final-doctor.json, owned-cleanup.json |

Five PNGs were visually inspected. No further capture redactions were needed; values are synthetic and command outputs omit login credentials.

## Attempt limitations retained

- 003 used an invalid snapshot UID and failed before acting; fresh 004/005 corrected it.
- The action log begins after 001; its standalone snapshot remains preserved.
- 012–015 Shift+Tab initially reached the Organization control rather than Home. The actual Home keyboard proof is 016–019.
- 020 Home navigation opens the legitimate automatic What's New modal. After Escape the stationary Home pointer reopens its tooltip in 022. This is not isolated activation-dismissal proof; the later mobile current/ordinary link observations supply navigation closure.
- 042/052/054 inspected a `dark` CSS class, but the app owns `html[data-theme]`. Those false-class readings supply no theme-mode proof. 102–107 inspect the actual attribute and restore light.
- 108–113 tried keyboard activation without a confirmed open-tooltip precondition. They cannot supersede the valid 119–121 failure.
- 135 supplied pageId as a string, failed input validation and performed no action. Fresh 136 and numeric-pageId 137 corrected it.
- Immediate click/Escape snapshots may retain closing-transition content. Settled follow-up snapshots/DOM observations establish closure. The Admin ordinary navigation failure is independently settled in 146.
- This run does not establish range-calendar/pagination native use, save/import/archive effects, authorization/RLS, latency, production deployment or unrelated feature journeys. Public component contracts and source-aware consumer census own the unconsumed component boundaries.
