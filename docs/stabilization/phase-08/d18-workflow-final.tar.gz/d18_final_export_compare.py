import json,sys
sys.path.insert(0,'.verification');import d18_final as f,d18_ui as v
rows=f.read('211-export-saved-history')['rows'];foreign=f.read('212-export-foreign-history')['rows'];d=json.loads((v.root/'organization.json').read_text());book=f.read('230-excel-raw-deletion-history');sort=lambda xs:sorted(xs,key=lambda x:x['id'])
assert sort(d['deletionRequests'])==sort(rows)
assert sort(d['sections']['deletionRequests'])==sort(rows)
keys=['id','organization_id','requested_by','requested_by_email','resource_type','resource_id','resource_description','resource_url','status','reviewed_by','reviewed_at','denial_reason','created_at']
headers=['Id','Organization Id','Requested By','Requested By Email','Resource Type','Resource Id','Resource Description','Resource Url','Status','Reviewed By','Reviewed At','Denial Reason','Created At']
assert all(set(r)==set(keys) for r in rows) and book['headers']==headers
excel=[dict(zip(keys,row+[None]*(len(keys)-len(row)))) for row in book['rows']];assert sort(excel)==sort(rows)
assert {r['status'] for r in rows}=={'approved','denied','cancelled','pending'}
assert foreign and not(set(r['id'] for r in foreign)&set(r['id'] for r in rows))
assert any(r['status']=='approved' and r['resource_type']=='training_type' for r in rows)
for name in ['217-json-network-state','225-xlsx-network-state']:
 x=f.read(name);assert x['calls'][-1]['status']==200,x
before=f.read('213-data-exports-before')['rows'];after=f.read('231-data-exports-after')['rows'];new=[x for x in after if x['id'] not in {b['id'] for b in before}];assert len(new)==2,new
for ext,name in [('json','219-json-saved'),('xlsx','227-xlsx-saved')]:
 saved=f.read(name);matches=[r for r in new if r['file_size_bytes']==saved['bytes']];assert len(matches)==1 and matches[0]['status']=='completed' and matches[0]['completed_at'],new
result={'observation':'PASS','savedRows':len(rows),'statuses':sorted({r['status'] for r in rows}),'JSON':'both locations exactly match all 13 saved fields','Excel':'Raw - Deletion Requests exactly matches all 13 saved fields','foreignSentinelRowsExcluded':len(foreign),'completedExports':len(new),'downloadBytesMatchLifecycle':True,'missingSourceHistory':'approved Training Type/completion/Rating/Counseling history retained; source absence independently captured'}
(v.root/'233-export-history-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
