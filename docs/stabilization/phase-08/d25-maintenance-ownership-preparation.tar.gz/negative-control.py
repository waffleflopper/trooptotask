import importlib.util,json,pathlib,subprocess
repo=pathlib.Path.cwd()
session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/ced9b3c7d1be5784/worker-1')
spec=importlib.util.spec_from_file_location('owned_environment',repo/'scripts/verification/environment.py')
envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod)
print(json.dumps(envmod.status(session)),flush=True)
state,workdir,environment=envmod.owned(session)
psql=['docker','exec','-i','-e','PGPASSWORD=postgres','supabase_db_'+state['project'],'psql','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
source=(repo/'supabase/migrations/20261003000300_critical_task_archive_retention.sql').read_text().replace('CREATE FUNCTION public.delete_expired_unreferenced_critical_tasks','CREATE OR REPLACE FUNCTION public.delete_expired_unreferenced_critical_tasks')
query="SELECT pg_get_functiondef('public.delete_expired_unreferenced_critical_tasks(uuid,timestamptz)'::regprocedure);"
def run_sql(sql):
 result=subprocess.run(psql+['-t','-A'],cwd=workdir,env=environment,input=sql,capture_output=True,text=True,check=True)
 return result.stdout
original=run_sql(query)
assert 'FOR UPDATE OF task' in source
try:
 run_sql(source.replace('FOR UPDATE OF task','FOR NO KEY UPDATE OF task'))
 result=subprocess.run(['supabase','test','db',str(workdir/'supabase/tests/archive_retention_critical_tasks_concurrency.sql')],cwd=workdir,env=environment,capture_output=True,text=True)
 print(result.stdout);print(result.stderr);print('Negative control exit',result.returncode)
 if result.returncode==0:raise AssertionError('Weaker FK-compatible locking must fail saved-history assertions')
 if '# Failed test 5:' not in result.stdout or '# Failed test 7:' not in result.stdout:raise AssertionError('Expected completion-wait outcome and exact history failures missing')
finally:
 run_sql(source)
 restored=run_sql(query)
 assert original==restored,'Exact RPC definition restoration failed'
 print('Exact accepted RPC definition restored; owned synthetic negative control completed.',flush=True)
