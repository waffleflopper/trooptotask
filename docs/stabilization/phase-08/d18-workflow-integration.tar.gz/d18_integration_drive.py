import sys,json
sys.path.insert(0,'.verification');import d18_ui as v,d18_native as n,d18_final as f
seed=f.read('04-source-seed');src=seed['sources']['orgA'];life=f.read('05-lifecycle-seed');sourceLabel='button "Archive SGT '+src['label']+' personnel, Synthetic"'
v.helper('07-native-source-observe','network','arm-observe','2','deletion-requests')
n.click('08-native-source-open',2,sourceLabel);s=v.snap('09-native-source-dialog',2);print(s.split('alertdialog')[-1],flush=True)
