# D28 / #1376 residual settings independent acceptance

Standards: **GO**. Spec: **GO for the selected five-read deliverable**. Comment Sicko: **HOLD for one accepted stale comment deletion**. No consequential application, authorization, saved-shape, performance, test-quality or artifact discrepancy remains. Overall release acceptance remains conditional on that deletion and the parent's pending current-head release gates.

This is a separate read-only source/artifact review using the inherited generic runtime, not independent live execution or model diversity. I launched no app, service, test, build, database, browser, connector or network operation. I edited only this ignored review directory. Ownership is **RELEASED**, with no pending commands.

## Standards verdict

GO. I read every changed/new implementation source and test, the complete governance manifest, the full new residual record, and complete affected ledger hunks/context. The 27 implementation paths comprise 16 production files, ten tests and one manifest; four parent documentation paths and three archives complete the 34-path physical scope. Repository rules take precedence over heuristic preferences.

The existing Organization reader owns five fixed facts without exposing a table/filter/result/raw-client API. Public DTO exports preserve existing access projection inputs; consumer copies and their old generic settings calls are removed. The concrete CriticalTasks → Organization dependency and exact delivery test registration introduce no waiver. Narrow Picks expose only the facts each consumer needs. No demonstrated smell warrants an extra abstraction, ownership move or unrelated cleanup.

Captured admitted request clients retain ordinary RLS. Purpose setup lookup, privileged roster paths, writes, files and policies retain their separate boundaries. Members loads its three readers, Groups and approvals concurrently, then lazily looks up setup state; only that optional lookup degrades. Critical Tasks workspace reads settings before streams; reports remain parallel; Personnel admission precedes settings. Dashboard disabled access skips the pair, while forged enabled access preserves the existing parallel start and recognized denial. No added production request waterfall, per-row lookup, admin bypass or repeated scalar split appears.

Required type/lint/format/governance evidence is composed from actual lower logs. Full current-head CI, production build, CLI and hosted review are parent gates, not passes from this review. The sole source-comment issue is separately reported below.

## Spec verdict

GO. The independent fixed specification is: “Fixed two-column singular pair one GET .single PGRST116 → null”; “Lists finite DTO 10/15/7/4 cols/all 1000 pages/full failure”; and “Preserve membership/candidate provider order and invite/outbox created_at DESC first delivery.” The implementation matches those requirements.

The pair preserves omission versus present null before unchanged normalization. It lowercases the Organization ID, makes one singular request and throws a plain unexpected Error without provider status/code. The four lists select and explicitly map their finite field sets, exclude foreign/provider extras, preserve optional omission/null, terminate empty/null pages and reject the entire result on later failure. Membership/candidate ordering remains the provider's order; invitations/outbox retain their existing descending creation order. I found no justification to invent a new ID sort.

All three selected consumer operations migrate their five generic semantic reads together, with current direct/reverse request factories and exports accounted for. Nonowners return no ownership candidates before provider acquisition; eligibility remains nonowner + user ID + nonblank email. Current source, installed-SDK tests, real request-factory tests and native/API/SQL artifacts establish the selected outcome at the appropriate boundaries. They do not establish native populated invitation history, native 1001-row paging or a new default-dependent completion expiry; those remain explicitly UNRUN.

Grouping is coherent: the five remaining settings reads share one owner/provider boundary and retained consumers. #1376 stays open for Personnel ranks and final generic facade removal. D29/D30, migrations and purpose-port rewrites are excluded. Existing unrelated defects or optional docstring coverage do not expand this deliverable.

## Comment Sicko verdict

**HOLD only for deletion of one line**: `src/lib/server/adapters/inMemory.ts:1261`, immediately above private `createInMemoryOrganizationSettingsReader`:

`/** Test delivery binding for Organization-owned scalar facts. */`

The changed function now supplies four collections as well as scalar facts. Its substantive extension invalidates this unchanged narrative banner. It defines neither a public API contract nor a foreign dependency constraint. Delete it; the function already makes the behavior clear, so no reshape is necessary.

Required deletions: **1**; reviewer deletions: **0**; restorations: **0**; MUST KILL flags: **0**; encoding changes required: **0**; added source comments: **0**; added suppressions: **0**. Flagged file count: **1**. Three skip categories are recorded in `comment-review.json`: unaffected comments, the retained public construction contract, and Markdown evidence/provenance prose. Unaffected comments were not counted or relitigated. Parent has accepted this deletion after release. Minimum recheck is the changed file's formatting/lint and whitespace check, plus a bounded deletion/hash acceptance; no native replay is indicated.

## Scope and source binding

HEAD/base `080cc16f63930d9d3bad3b54ffa06561d898e5af`; branch `stabilization/1376-residual-settings`. Actual tracked diff plus all nonignored untracked paths equals exactly the declared **34 paths**. All entry/exit paths, sizes and SHA256 values match. Entry and exit inventory SHA256 are both `4952ba31580b0b0ceedc7fb9823ef0132cc1a1d8d93961d3613d46e1b903f7dc`.

All 27 current implementation files also match the final native archived exit inventory. That archive's 5,367 source input records are byte-identical between its captured entry and exit, including .env.example; I compared those public inventories, without reading private environment originals. The complete dirty-path census establishes no extra current source change. Later four documentation records and archive assembly are review/provenance changes, not new native execution.

The complete direct/reverse/removal search is preserved in `caller-removal-census.json`. The old `SettingsInvitationDeliverySourceRow` export is gone; `SettingsAccessSourceRow` is owned in the new DTO module. CriticalTasksReportContext's remaining store exists for the retained Personnel rank catalog and fixture internals, not the migrated settings pair. No selected generic settings consumer remains.

## Archive and actual semantic acceptance

Fresh safe extraction verified **502 exact payload paths/sizes/hashes**, plus three inventory files, totaling **13,413,754 payload bytes**:

| Archive | Payloads / expanded bytes | SHA256 |
| --- | --- | --- |
| baseline | 266 / 5,995,739 | f4dc67d369f67dc895625310f9cb5e0ab642adc07aa53a0b0a1b334e24af0b07 |
| final | 189 / 5,867,621 | 9306885c514aabe15b745da0e551dec2e176cc9a23e41e9df15660d218aab8af |
| checks | 47 / 1,550,394 | 58493d3bd26ef8315bee935339813c9bedfedb47bda2529a08a0134042538e28 |

Integrity alone was not acceptance. `semantic-reader.py` independently uses actual archived full SQL rows, literal fixture data, dates and complete workbook ZIP/XML cells, without importing application calculators. In **both runs** it verifies all 64 member core identity/org/user/role/timestamp facts and literal six-capability/preset/scope facts, three four-field eligible ownership candidates, empty invitations/history, and full restoration of **99 business rows across 16 A/B rowsets**, including every key/value/ID/timestamp. Native saved 18/45 changes only the two Organization settings columns. Native integer restoration is 12/60; separate ordinary authenticated POST restores NULL/NULL, followed by exact full SQL restoration and seed cleanup. No generated/helper/UI temporary IDs remain in the declared business sets.

Literal active-task/MOS applicability gives five requirements and one current completion. Able has 1/2 = 50%; Org A Dashboard has 1/5 = 20% and warning window 45; Org B has 0/0 = 0% and window 60. The dated completion is 2026-09-14 and its task override is twelve months, giving 2027-09-14; this does not prove a newly changed default controls an override-free completion. All **four XLSX files**, all single sheets and every cell match the independent expected **three matrix rows/nine report rows**, including people, ranks, MOS, groups, statuses and KPI/task-gap values. Each workbook has sixteen ZIP members.

I inspected actual native save/restore network bodies and 200 success responses, ordinary nullable restoration, decoded admitted page/data responses, snapshots, downloads and SQL readbacks. Native final request 131 carries exactly 18/45. Nine baseline ordinary denial responses have actual 403 outcomes or SSR error nodes (foreign Organizations are concealed as 404 within HTTP200 data envelopes). All sixteen saved-before versus after-denial business sets match exactly; audit history remains separate. Native member denial and native A→B selection are observed independently from ordinary API/data results. Final B screen shows only the foreign private task and its limited controls. Ordinary Dashboard data is not a native compact Home card or complete native streamed-body claim.

The actual baseline/final native candidates are respectively `18136d871d16812a7ba5ebd15bafbbe4ad8e623e4d618d74d6a40b468fcd8c2b` and `525f5ee4bf4891a3637fbb77e6a1f7b33d769626dd1ea04ef1bb1d5265ee758b`. Historical writer/policy/lifetime/export/math evidence stays at its original bindings. Changed SettingsRead and Personnel readiness hashes are explicitly marked as changed applicability, not rebadged historical execution. Five new producers/factories justified the focused final integration; unchanged UI, writers and broader purposes do not justify a wholesale replay.

## Visual, sanitation and closure bounds

All **ten packaged PNGs** were viewed with the actual image tool at original detail: baseline defaults-saved, owner-able-detail, owner-candidate-visible, owner-danger and owner-members; final defaults-saved, owner-Able-readiness, owner-candidate-popup, owner-members and switch-B-screen. Exact paths/hashes/dimensions are in `source-visual-public-scan.json`. Members screenshots cover a viewport, while all 64 facts are independently decoded; this is not a universal all-pixel or OCR certificate. All four whole workbooks were inspected, not sampled. No PDF is involved.

An independent JWT-shaped byte scan of all expanded public files and all 64 uncompressed XLSX members finds zero hits. The parent final bounded sanitation receipt separately covers seven actually known auth/provider literals across 169 raw files, 162 UTF8 texts and 32 XLSX members; baseline covers its two known literals and redaction slots. I did not request/read the excluded private originals, reproduce literal credentials, or certify universal unknown-secret/transcript sanitation. Baseline unavailable native bodies 253/260 remain unavailable, with no parsing/execution credit.

Actual public physical closure receipts support final owned closure: 21 numeric PIDs, seven groups, nine ports, five containers, full owned network ID, two volumes and worker directory absent. Of 46 captured preexisting containers, 41 complete Config/HostConfig/destination-sorted Mounts/PID/start/Networks signatures retain exact equality; five unowned preexisting containers are absent and five external ones appear. Final whole-machine network/volume/TCP equality **FAIL remains preserved**, distinct from owned closure PASS; it gives no causal lifetime-untouched claim and authorizes no unowned cleanup. Baseline closure retains its separately bound successful whole-machine comparison. Eight baseline and three final legitimate A audit rows remain until owned-provider disposal, B zero; I do not claim all table counts equal. I adjudicated existing receipts, not new live resources.

## Lower proof, failures and remaining gates

Actual lower logs establish initial six suites/45 PASS and SDK one suite/14 PASS. Initial reverse selection had three failures/36 PASS over six suites/39 tests; request-context selection had one failure/two PASS. Corrected selections give four suites/16 PASS, two suites/12 PASS, and final Dashboard four PASS. Selections overlap; they are not summed into a fictional green total or the prompt's approximate 140. Four literal complete-field SDK cases expose 1,001 leaked `provider_private` fields in the deliberate mapper-bypass counterfactual (one FAIL/three PASS), then all four PASS after exact restoration. The first wrong filter selected zero tests and earns no RED/GREEN credit. The pair-specific case PASS demonstrates singular/PGRST116/null/omission/plain error handling. The four readers cover complete 1001 rows, empty/null terminal pages and whole-result late failure using the installed SDK; factories exercise actual captured-client construction and consumer output rather than production-function mirrors.

Governance initially failed for undeclared imports/private DTO/test registration, then passed with 155 retained findings and no waiver. Types pass 0 errors/0 warnings; final affected lint/format/diff pass. Wrong Dashboard no-read assumption, fake transport omissions, obsolete Danger call-trivia and fixture preset failures remain preserved and corrected at their actual boundaries. Baseline control failures and final helper/locator/scratch-key/privacy-path/parser failures are retained, not product fixes or erased passes. My own filename/path/JSON-envelope/denial-chronology reading mistakes are also preserved in `reviewer-read-failures.json` and corrected only in review scratch.

Native populated invitations/outbox, native 1001-row paging, new default-dependent completion expiry, compact Home-card observation and full native streamed bodies remain **UNRUN**. Their omission is proportionate to the selected reader cutover: installed-SDK/literal DTO/error/page tests supply the cheaper relevant boundary; existing unchanged writers, policy, lifecycle and calculators retain matching prior proof. No concrete remaining gap requires another app session. Full current-head CI/build, CLI and hosted review remain mandatory parent gates. The Onboarding #1566 merged ledger provenance is reviewed as prose only and not reopened.

Supporting receipts: `entry-inventory.json`, `exit-inventory.json`, `scope-exit-receipt.json`, `archive-integrity.json`, `semantic-restoration.json`, `wire-denial-reconciliation.json`, `source-visual-public-scan.json`, `lower-log-reconciliation.json`, `caller-removal-census.json`, `comment-review.json` and the finite replayable readers. **Sole-worker ownership RELEASED.**
