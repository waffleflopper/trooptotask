The first direct mutation probe stopped before the SDK mutation because the one-run script treated `selectAllSupabaseRows`’s result envelope as an array. This is a verification-script failure, separate from the reproduced real cron/provider HTTP414. The original script bytes are preserved in `direct-large-delete.failed-pagination-shape.mjs`; the corrected probe uses its documented data/error fields and a distinct fresh seed. The original tool output was not redirected to a raw file; this is a labeled transcript excerpt, not a regenerated capture:

```text
Error: Exact owned large fixture required
    at file:///home/waffleflops/.cache/t2t-1360-retention/.verification/evidence/verify-trooptotask/retention-baseline/direct-large-delete.mjs:23:83
Node.js v24.21.0
```
