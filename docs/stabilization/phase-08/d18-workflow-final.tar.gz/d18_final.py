import json
from pathlib import Path
import d18_ui as v
import d18_native as n
TABLES=['personnel','training_types','personnel_trainings','rating_scheme_entries','counseling_records','deletion_requests','leader_notes','personnel_documents','personnel_follow_ups','personnel_ict_completions']
def read(name):return json.loads((v.root/(name+'.json')).read_text())
def capture(prefix):
 for org in ['orgA','orgB']:
  for table in TABLES:
   r=v.helper(f'{prefix}-{org}-{table}','rows',table,org)
   print(prefix,org,table,r['count'],flush=True)
def file_capture(prefix,seed='04-source-seed'):
 data=read(seed)
 for org in ['orgA','orgB']:
  parent=data['sources'][org]['parent'];path=next(f['path'] for f in data['files'] if '/'+parent+'/' in f['path'])
  v.helper(f'{prefix}-{org}-files','artifact-files',org,parent,'counseling',path)
def api(name,page,action,data,org='orgA'):
 return v.helper(name,'deletion-request',str(page),org,action,json.dumps(data))
def reload(name,page):return v.tool(name,'navigate_page',pageId=page,type='reload')
def seed_requests(prefix,page,seed):
 data=read(seed); result={}
 for kind in ['personnel','personnel_training','training_type','rating_scheme_entry','counseling_record']:
  r=api(prefix+'-'+kind,page,'submit',dict(resourceType=kind,resourceId=data['sources']['orgA'][kind],resourceDescription=prefix+' '+kind,resourceUrl=None))
  assert r['status']==201,(kind,r)
  result[kind]=json.loads(r['body'])
 (v.root/(prefix+'-requests.json')).write_text(json.dumps(result,indent=2)+'\n')
 return result
