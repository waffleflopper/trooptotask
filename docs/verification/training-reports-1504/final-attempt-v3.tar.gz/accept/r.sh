#!/usr/bin/env bash
# usage: r.sh NAME DESCRIPTION -- cmd args...   (refuses reused NAME)
export PATH=/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH TMPDIR=/home/waffleflops/.cache/t2t-1502-tmp NODE_DISABLE_COMPILE_CACHE=1
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
n=$1; d=$2; shift 3
if [ -e $E/receipts/$n.stdout ]; then echo "REFUSED: receipt name $n already used"; exit 1; fi
at=$(date -Is); s=$(date +%s.%N)
out=$("$@" 2>$E/receipts/$n.stderr); rc=$?
e=$(date +%s.%N)
printf '%s' "$out" > $E/receipts/$n.stdout
python3 -c 'import json,sys;print(json.dumps({"name":sys.argv[1],"description":sys.argv[2],"exit":int(sys.argv[3]),"at":sys.argv[4],"seconds":round(float(sys.argv[6])-float(sys.argv[5]),3),"argv":sys.argv[7:],"stdout":"receipts/"+sys.argv[1]+".stdout","stderr":"receipts/"+sys.argv[1]+".stderr"}))' "$n" "$d" $rc "$at" $s $e "$@" >> $E/receipts/index.jsonl
echo "[exit $rc]"; printf '%s\n' "$out" | head -c ${MAXOUT:-6000}; [ -s $E/receipts/$n.stderr ] && { echo "--stderr--"; head -c 2000 $E/receipts/$n.stderr; }
exit 0
