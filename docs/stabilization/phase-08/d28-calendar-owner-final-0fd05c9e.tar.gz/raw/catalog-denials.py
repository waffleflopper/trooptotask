import json,pathlib,subprocess,datetime,hashlib
r=pathlib.Path(__file__).resolve().parent
A='f7083174-e6db-46c5-8fae-8af8d78f2909';B='9aadd391-c41f-4ea7-a880-09832eb2e234'
actors=[('view',5,A),('operate',14,A),('scoped',3,A),('empty',4,A),('scoped-config',20,A),('manager',6,A),('configure-foreign',19,B)]
for actor,page,org in actors:
 for family,body in [('status-types',{'color':'#166534','textColor':'#ffffff','sortOrder':1}),('assignment-types',{'shortName':'DN','assignTo':'personnel','color':'#166534','sortOrder':1}),('special-days',{'date':'2026-09-21','type':'org-closure'})]:
  body['name']='round2-denied-'+actor+'-'+family
  result=subprocess.run(['python3',str(r/'drive-v2.py'),'p03-denial-'+actor+'-'+family,'req',str(page),'POST',f'/org/{org}/api/{family}',json.dumps(body)],capture_output=True,text=True)
  print(result.stdout,result.stderr)
  if result.returncode:raise SystemExit(result.returncode)
result=subprocess.run(['python3',str(r/'drive-v2.py'),'p03-view-put-denial','req','5','PUT',f'/org/{A}/api/status-types',json.dumps({'id':'19998226-900f-4cab-b6ae-83d9a8933cbd','name':'round2-denied-view-update'})],capture_output=True,text=True);print(result.stdout,result.stderr)
