SET statement_timeout = '10s'; SET lock_timeout = '3s';
WITH selected_templates AS (
 SELECT template_id AS id FROM public.personnel_onboardings WHERE organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND id='c973d7bd-307b-4a62-8320-bb0dba51268d'::uuid
 UNION SELECT definition.template_id FROM public.onboarding_template_steps definition
 JOIN public.onboarding_step_progress progress ON progress.template_step_id=definition.id
 WHERE progress.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND progress.id='8950d7f6-e9e5-410d-9ca7-6281769d410b'::uuid AND progress.onboarding_id='c973d7bd-307b-4a62-8320-bb0dba51268d'::uuid
 AND definition.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid
)
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND p.id='c973d7bd-307b-4a62-8320-bb0dba51268d'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id',id,'organization_id',organization_id,'group_id',group_id,
 'rank',rank,'first_name',first_name,'last_name',last_name,'slug',slug,'archived_at',archived_at)
 FROM public.personnel WHERE organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND id='52cbc9b3-f9f3-4627-a4c2-5f2188f5c2e6'::uuid),
 'progress', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.onboarding_step_progress p
 WHERE p.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND p.onboarding_id='c973d7bd-307b-4a62-8320-bb0dba51268d'::uuid), '[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.onboarding_templates t
 WHERE t.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND t.id IN (SELECT id FROM selected_templates)), '[]'::json),
 'definitions', COALESCE((SELECT json_agg(d ORDER BY d.id) FROM public.onboarding_template_steps d
 WHERE d.organization_id='46bb6cff-3364-4cb9-9d4f-c85d9958cf91'::uuid AND d.template_id IN (SELECT id FROM selected_templates)), '[]'::json));
