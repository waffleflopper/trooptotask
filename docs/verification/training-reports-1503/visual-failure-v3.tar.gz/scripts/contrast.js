(() => {
  const cv = document.createElement('canvas'); cv.width = cv.height = 1; const ctx = cv.getContext('2d', { willReadFrequently: true });
  const px = (layers) => { ctx.clearRect(0, 0, 1, 1); for (const c of layers) { if (!c) continue; ctx.fillStyle = '#000'; ctx.fillStyle = c; ctx.fillRect(0, 0, 1, 1); } const d = ctx.getImageData(0, 0, 1, 1).data; return [d[0], d[1], d[2]]; };
  const lum = ([r, g, b]) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return Math.round(((Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05)) * 100) / 100; };
  const hex = (c) => '#' + c.map((v) => v.toString(16).padStart(2, '0')).join('');
  const bgChain = (el) => { const chain = []; for (let e = el; e; e = e.parentElement) { const b = getComputedStyle(e).backgroundColor; if (b && b !== 'rgba(0, 0, 0, 0)' && b !== 'transparent') chain.unshift(b); } return chain; };
  const pageBg = px(bgChain(document.body));
  const cells = [...document.querySelectorAll('[data-slot=readiness-band-cell]')].map((cell) => {
    const cs = getComputedStyle(cell);
    const chain = bgChain(cell);
    const bg = px(chain);
    const fg = px([...chain, cs.color]);
    const row = cell.closest('tr')?.querySelector('th, td')?.textContent.trim().split('\n')[0];
    const out = { label: cell.closest('button')?.getAttribute('aria-label') ?? `${row} N/A`, tier: cell.dataset.tier, text: cell.childNodes[0]?.textContent?.trim(), bg: hex(bg), fg: hex(fg), textRatio: ratio(fg, bg), fontSize: cs.fontSize, fontWeight: cs.fontWeight };
    if (cell.dataset.drop !== undefined) {
      const shadow = cs.boxShadow; const m = shadow.match(/(rgba?\([^)]*\)|oklch\([^)]*\)|lab\([^)]*\)|#[0-9a-f]+)/i);
      const outline = m ? px([...chain, m[1]]) : null;
      const chip = cell.querySelector('.readiness-band-drop'); const ccs = getComputedStyle(chip);
      const chipBg = px([...chain, ccs.backgroundColor]); const chipFg = px([...chain, ccs.backgroundColor, ccs.color]);
      Object.assign(out, { drop: cell.dataset.drop, boxShadow: shadow, outline: outline && hex(outline), outlineVsCell: outline && ratio(outline, bg), chipBg: hex(chipBg), chipFg: hex(chipFg), chipVsCell: ratio(chipBg, bg), chipText: ratio(chipFg, chipBg), chipFontSize: ccs.fontSize });
    }
    return out;
  });
  const horizon = [...document.querySelectorAll('[aria-label="Hot-spot grid"] tbody tr')].map((tr) => { const tds = [...tr.querySelectorAll('td')]; const last = tds.at(-1); const span = last?.querySelector('span') ?? last; if (!span) return null; const chain = bgChain(span); return { row: tr.querySelector('th')?.innerText.split('\n')[0], text: last.innerText.trim(), fg: hex(px([...chain, getComputedStyle(span).color])), ratio: ratio(px([...chain, getComputedStyle(span).color]), px(chain)) }; }).filter(Boolean);
  const legend = [...document.querySelectorAll('[data-slot=readiness-band-legend] *')].filter((e) => e.children.length === 0 && e.textContent.trim()).map((e) => e.textContent.trim());
  const legendAria = document.querySelector('[data-slot=readiness-band-legend]')?.getAttribute('aria-label');
  const swatches = [...document.querySelectorAll('[data-slot=readiness-band-swatch]')].map((s) => ({ tier: s.dataset.tier, bg: hex(px([...bgChain(s)])) }));
  return { theme: document.documentElement.className || document.documentElement.dataset.theme || getComputedStyle(document.documentElement).colorScheme, pageBg: hex(pageBg), cells, horizon, legend, legendAria, swatches, minText: Math.min(...cells.map((c) => c.textRatio)), minOutline: Math.min(...cells.filter((c) => c.outlineVsCell).map((c) => c.outlineVsCell)), minChip: Math.min(...cells.filter((c) => c.chipVsCell).map((c) => c.chipVsCell)) };
})()
