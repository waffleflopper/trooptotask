SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('dfb13a59-c201-4361-8b5f-b86d16509e9c'::uuid,'1aab72bc-9167-4a3b-b4d3-e7fc91df3556'::uuid,'068ab4ff-df70-4c87-a573-b2e3ab4ef838'::uuid,'df2ed80d-31ea-4066-b685-884bcc535231'::uuid,'1a5f3f85-a3e1-4fa4-afef-ebaea807a6a5'::uuid,'5bd829d5-e15d-4d88-89da-c888caece038'::uuid,'7a34a0bd-7244-482a-8cf9-9f2529eac813'::uuid,'339af162-ce10-42db-bfd5-dbf3614b0742'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('1db81966-76a7-4bef-bfc2-9a43100b84fb'::uuid,'044e8fcd-1537-48bd-a5de-f77922c0b8c8'::uuid,'17cd5700-056b-44dc-8211-fc5b52a40021'::uuid,'b8137821-c624-4523-9d75-696e88af744e'::uuid,'73862cc6-0b4c-49ef-b29b-735fac797de0'::uuid,'d07f457a-8b24-4770-8e67-95ae8e724c80'::uuid,'129acb44-b8c9-494c-ab33-d2db53e886cb'::uuid,'0b2dc8be-bc1d-432e-ac7e-250e8de02ecd'::uuid)) s), '[]'::json));
