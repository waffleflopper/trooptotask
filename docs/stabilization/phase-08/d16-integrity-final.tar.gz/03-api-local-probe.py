import json, subprocess
from pathlib import Path
evidence=Path.cwd()/'.verification/evidence/verify-trooptotask/d16-integrity-final'
f=json.loads((evidence/'fixture.json').read_text())['ids']; s=json.loads((evidence/'seed.json').read_text())['ids']; a=json.loads((evidence/'actor-scoped.json').read_text())
setup={'orgId':a['orgId'],'entryId':s['due30'],'rater':f['personB'].upper(),'senior':f['personB'],'intermediate':s['archived'],'reviewer':f['personUnassigned']}
script='''async () => {
 const s=SETUP;
 const body={id:s.entryId,raterPersonId:s.rater,seniorRaterPersonId:s.senior,intermediateRaterPersonId:s.intermediate,reviewerPersonId:s.reviewer,
 raterName:null,seniorRaterName:null,intermediateRaterName:null,reviewerName:null,workflowStatus:'with-reviewer',notes:'API local evaluator witness'};
 const response=await fetch('/org/'+s.orgId+'/api/rating-scheme',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 return {submitted:body,status:response.status,body:await response.json()};
}'''
params={'pageId':a['pageId'],'function':script.replace('SETUP',json.dumps(setup)),'filePath':str(evidence/'03-api-local-evaluators.json'),'waitForStableDom':False}
r=subprocess.run(['npm','run','--silent','verify:app','--','tool','evaluate_script',json.dumps(params)],capture_output=True,text=True,check=True)
(evidence/'03-api-local-action.json').write_text(r.stdout)
result=json.loads((evidence/'03-api-local-evaluators.json').read_text()); print(json.dumps({'status':result['status'],'result_keys':list(result['body'])}))
