from pathlib import Path
import subprocess,sys,json,os,datetime,time
p=Path(__file__).resolve().parent;label=sys.argv[1];argv=sys.argv[2:]
allocation=json.loads((p/'environment-allocation.json').read_text())
assert '--worker' in argv and argv[argv.index('--worker')+1]=='2'
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/f'{label}.stdout').open('wb') as stdout,(p/f'{label}.stderr').open('wb') as stderr:
 r=subprocess.run(argv,stdout=stdout,stderr=stderr,env={**os.environ,'TMPDIR':allocation['TMPDIR']})
(p/f'{label}-command.json').write_text(json.dumps({'command':argv,'cwd':str(Path.cwd()),'revision':allocation['source'],'candidateDigest':allocation['candidateDigest'],'worker':'2','TMPDIR':allocation['TMPDIR'],'startedUTC':started,'durationSeconds':round(time.monotonic()-start,3),'exit':r.returncode},indent=2)+'\n')
print(label,'exit',r.returncode,'seconds',round(time.monotonic()-start,3))
for suffix in ['stdout','stderr']:
 data=(p/f'{label}.{suffix}').read_text()
 print(data)
sys.exit(r.returncode)
