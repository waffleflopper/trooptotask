SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('unused', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = 't2t-d15-overlap-49b5a561e8e04f5a9dba32366c3f2bd9'));
