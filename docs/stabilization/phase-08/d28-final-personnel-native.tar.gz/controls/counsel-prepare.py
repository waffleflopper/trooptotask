import current as x
import json
d=x.d
d.act('counselings-nav','link','Counselings');r=d.snap('counselings-ready');print([(n.get('role'),n.get('name')) for n in d.walk(r['structuredContent']['snapshot']) if n.get('role') in ['textbox','button']][-20:]);d.act('counsel-date-open','button','Counseling date conducted');r=d.snap('counsel-calendar-ready');print([(n.get('role'),n.get('name')) for n in d.walk(r['structuredContent']['snapshot']) if n.get('role') in ['button','combobox']][-45:])
