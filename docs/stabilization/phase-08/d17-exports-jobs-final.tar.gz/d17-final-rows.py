import concurrent.futures,subprocess,sys
stage,*tables=sys.argv[1:]
def read(x):
 table,org=x
 r=subprocess.run(['python3','.verification/run-d17-final.py',f'{stage}-{table}-{org}','helper','rows',table,org],capture_output=True,text=True)
 if r.returncode:print(r.stdout,r.stderr);raise RuntimeError(x)
 print(table,org,'saved')
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:list(pool.map(read,[(t,o)for t in tables for o in ('orgA','orgB')]))
