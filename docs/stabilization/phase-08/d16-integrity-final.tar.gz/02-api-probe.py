import json, subprocess
from pathlib import Path
root=Path.cwd(); evidence=root/'.verification/evidence/verify-trooptotask/d16-integrity-final'
fixture=json.loads((evidence/'fixture.json').read_text()); seed=json.loads((evidence/'seed.json').read_text()); actor=json.loads((evidence/'actor-operate.json').read_text())
print(json.dumps({'fixture_keys':list(fixture),'ids':fixture.get('ids'),'seed_ids':seed.get('ids')}))
script='''async () => {
 const setup = SETUP;
 const fields = ['raterPersonId','seniorRaterPersonId','intermediateRaterPersonId','reviewerPersonId'];
 const endpoint = '/org/'+setup.orgId+'/api/rating-scheme';
 const results = [];
 for (const field of fields) for (const value of [setup.foreign,setup.missing,'not-a-person-id']) {
  for (const method of ['PUT','POST']) {
   const data = method === 'PUT' ? {id:setup.entryId,notes:'Denied evaluator change',[field]:value} : {
    ratedPersonId:setup.rated,evalType:'NCOER',ratingPeriodStart:'2026-01-01',ratingPeriodEnd:'2026-12-31',status:'active',notes:'Denied evaluator create',[field]:value
   };
   const response=await fetch(endpoint,{method,headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
   results.push({field,value,method,status:response.status,body:await response.json()});
  }
 }
 return results;
}'''
setup={'orgId':actor['orgId'],'foreign':fixture['ids']['personForeign'],'missing':'d1600000-0000-4000-8000-000000000099','entryId':seed['ids']['overdue'],'rated':fixture['ids']['personA']}
params={'pageId':actor['pageId'],'function':script.replace('SETUP',json.dumps(setup)),'filePath':str(evidence/'02-api-denials.json'),'waitForStableDom':False}
result=subprocess.run(['npm','run','--silent','verify:app','--','tool','evaluate_script',json.dumps(params)],capture_output=True,text=True,check=True)
(evidence/'02-api-denials-action.json').write_text(result.stdout)
print(result.stdout[:1000])
