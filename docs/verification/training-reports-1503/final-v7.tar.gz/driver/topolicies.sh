#!/usr/bin/env bash
# Visible link path: Organization Settings -> Policies, fresh snapshot UIDs each step.
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7; D=$E/driver/d.sh; cd $ROOT; ts=$(date +%H%M%S)
T() { local l=$1; shift; $D "$l" -- npm run --silent verify:app -- tool "$@" --worker 1; }
T topol-snap0 take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/topol-$ts-0.txt\"}" >/dev/null
u=$(grep 'link "Organization Settings"' $E/snap/topol-$ts-0.txt | head -1 | sed -E 's/.*uid=([0-9_]+).*/\1/')
T topol-settings click "{\"pageId\":2,\"uid\":\"$u\"}" | grep -o 'Page navigated[^"]*'
T topol-snap1 take_snapshot "{\"pageId\":2,\"filePath\":\"$E/snap/topol-$ts-1.txt\"}" >/dev/null
u=$(grep 'link "Policies"' $E/snap/topol-$ts-1.txt | head -1 | sed -E 's/.*uid=([0-9_]+).*/\1/')
T topol-policies click "{\"pageId\":2,\"uid\":\"$u\"}" | grep -o 'Page navigated[^"]*\|Succ[^"]*'
T topol-wait wait_for '{"pageId":2,"text":["Training readiness goal (%)"],"timeout":10000}' >/dev/null
