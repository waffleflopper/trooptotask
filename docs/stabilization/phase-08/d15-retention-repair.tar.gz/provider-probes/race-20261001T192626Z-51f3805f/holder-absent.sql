SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('absent', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE pid = 953 AND backend_start = '2026-10-01 19:26:27.862415+00'::timestamptz AND application_name = 't2t-d15-race-abfd36fc'));
