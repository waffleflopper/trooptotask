from drive import *
page=json.loads((E/'page-id.json').read_text())['pageId']; tag=json.loads((E/'legacy-seed.json').read_text())['tag']
s=snap(page,'mixed-card-before'); click(page,uid(s,'button "SM SPC MapLegacy'+tag),'mixed-card-open')
print(snap(page,'mixed-card-detail')); screen(page,'mixed-card-detail')
native('navigate_page',{'pageId':page,'type':'reload'},'mixed-reload')
s=snap(page,'mixed-reload-list'); click(page,uid(s,'button "SM SPC MapLegacy'+tag),'mixed-reload-card-open')
print(snap(page,'mixed-reload-card-detail')); screen(page,'mixed-reload-card-detail')
