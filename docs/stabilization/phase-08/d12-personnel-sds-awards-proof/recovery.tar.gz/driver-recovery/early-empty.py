from scope_helpers import *
actor=call('early-empty-login','control','actor','personnelEmpty','personnel');page=actor['pageId']
s=snapshot('early-empty-roster',page);shot('early-empty-roster',page);assert seed['name'] not in s and 'No personnel on the active roster' in s
f=flags('early-empty-ack-ids',page);assert any(m['ids']==[] for m in f['matches']),f
denied_batch('early-empty-denied',page,[('alpha',PERSON,ORG,404,404)])
call('early-empty-after-doctor','app','doctor')
tool('early-empty-close','close_page',{'pageId':page})
(base/'early-empty-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'boundary':'Actual normal form actor, native empty roster, publicemptyIDs, realdenied404s plusfull A/B no-effect rows/audits','limit':'Later full-row empty-scope case repeats after SDS data exists; this first check establishes early harness/actualempty admission.'},indent=2)+'\n')
