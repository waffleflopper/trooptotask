SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('unused', NOT EXISTS (SELECT 1 FROM pg_stat_activity WHERE application_name = 't2t-d15-overlap-87e9d77a8d1f4275a39775704b7c84f0'));
