#!/usr/bin/env bash
# usage: print.sh PREFIX NAME  -> arm, native click Print brief, state, save exact URL to pdf/NAME.pdf, restore
E=.verification/evidence/verify-trooptotask/1504-final-v2/accept
p=$1; n=$2
[ -e $E/pdf/$n.pdf ] && { echo "REFUSED pdf exists"; exit 1; }
$E/v.sh "$p-a-print-arm" "print arm ($n)" print arm 2 | tr -d '\n' | head -c 200; echo
$E/snap.sh "$p-b-pre-print" 2 >/dev/null
U=$(grep 'button "Print brief"' $E/snaps/$p-b-pre-print.txt | grep -o 'uid=[0-9_]*' | cut -d= -f2)
$E/t.sh "$p-c-click-print" "native click Print brief ($n)" click "{\"pageId\":2,\"uid\":\"$U\"}" | tr -d '\n' | head -c 200; echo
MAXOUT=800 $E/v.sh "$p-d-print-state" "print state BEFORE save ($n)" print state 2 | tr -d '\n '; echo
URL=$(npm run --silent verify:app -- tool list_pages '{}' --worker 1 | python3 -c "import json,sys;d=json.load(sys.stdin);print([x['url'] for x in d['structuredContent']['pages'] if x['id']==2][0])")
echo "URL=$URL"
MAXOUT=1500 $E/v.sh "$p-e-print-save" "print save exact current URL ($n)" print save 2 "$URL" $E/pdf/$n.pdf | tr -d '\n'; echo
$E/v.sh "$p-f-print-restore" "print restore ($n)" print restore 2 | tr -d '\n' | head -c 200; echo
