SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('absent',NOT EXISTS(SELECT 1 FROM pg_stat_activity WHERE pid=2903 AND backend_start='2026-10-02 09:50:02.075539+00'::timestamptz AND application_name='t2t-d15-removal-67ea4e789df0467085a15fae95983ac4' AND usename='supabase_admin' AND datname='postgres'));
