// @vitest-environment happy-dom
import '@testing-library/jest-dom/vitest';
import { afterEach, describe, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/svelte';
import PaginationTest from './PaginationTest.svelte';

describe('Pagination disabled destinations', () => {
	afterEach(cleanup);

	it('preserves the caller page when a disabled destination is activated by keyboard', async () => {
		render(PaginationTest, { initialPage: 2, usePageWrappers: true, disableWrapperDestinations: true });
		const previous = screen.getByRole('button', { name: 'Page 1' });
		expect.soft(previous).toBeDisabled();
		previous.focus();
		await fireEvent.keyDown(previous, { key: 'Enter' });
		expect.soft(screen.getByLabelText('Current page').textContent).toBe('2');
		expect(screen.getByLabelText('Visible records').textContent).toBe('11-20');
	});
});
