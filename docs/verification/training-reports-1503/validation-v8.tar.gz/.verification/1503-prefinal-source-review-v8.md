# 1503 prefinal nonvisual source review v8

No nonvisual source blocker or new advisory was found in the current integrated cumulative candidate. The actual unique migration order and fresh/populated SQL proof resolve the concrete later-main seam identified in the v7 audit. This is a bounded source verdict: current independent browser proof, expanded current evidence acceptance and publication remain separate. It does not declare #1503 or parent #1433 complete, and makes no appearance, layout, color, font, Paper or focus-appearance judgment.

Only this ignored report is written. No source, services, browser, database, tests, staging, commit, publication or child-agent action was performed. Root owns execution and final integration; the independent T3 Claude driver owns visual/live judgments. t2t-engineer, AGENTS, Testing, Definition of Done, architecture/provider contracts and the original implementation brief/spec govern this review. Same-provider source/artifact reading is not model diversity or independent live execution.

## Exact current binding and complete census

| Item | Actual binding |
| --- | --- |
| Base | `6555c3c884801e46bd0fc78a94d698c30ec76d88` |
| HEAD | `c09b67376abc3936e1b141407c6759b362fe5c6a` |
| `git diff HEAD -- src scripts supabase` | 247,930 bytes; SHA-256 `32708d9529e3554a1c560101db922fb5588f017e7a10e9afdc6db3384049ff07` |
| `git diff HEAD` | 345,358 bytes; SHA-256 `15f3e12bade5e524dafa53d040ea305a491e48b3e0ff46adc4e67f3efe9fc9af` |
| `git diff <base>` ordinary full diff | 536,420 bytes; SHA-256 `e07ca7fbd7caf7accd7e692bc203dda8747d92ce68bb7db348704e15c97b345f` |
| `git diff --binary <base>` full cumulative diff | 3,506,420 bytes; SHA-256 `2777e3e2baf913d2f9eb63d2fee1945d7700bb32b359337a6729bffe5ab20072` |
| Incremental census | 63 entries: 51 modified, 10 added, one deleted, one R100 rename |
| Cumulative census | 108 entries: 81 modified, 26 added, one deleted; 102 text entries and six tracked binary archives |
| Chart bytes | SHA-256 `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` |

These are whole working-tree diffs, including committed 1501/1502 source and uncommitted 1503 changes, rather than a src-only review or staged-only view. Repository mnemonic prefixes are `c/` and `w/`; the literal commands above preserve that configuration. The goal migration appears as an addition against main, and as a 100% rename from the branch's old filename against HEAD. The existing mixed index also contains earlier additions; no index mutation was performed here.

The entire old and current cumulative binary patches were parsed. Every text hunk's old context was checked against its exact base, applied in memory, and the resulting bytes checked against the current file (or deletion). All 102 current text entries passed. After normalizing the goal migration filename, 90 text results are byte-identical to the previously complete accepted v6 review; twelve differ through inherited main integration and the current ledger/release repair. Those unchanged reviews are reused transparently rather than represented as a new execution of their tests. The twelve differing texts and current consumers were examined, and the important admission, query, request lifetime, URL, workbook, model, settings and shared-component contracts were re-grounded in current files. The final census below binds every text entry, deletion and binary boundary. No old-only owned text result disappeared.

The twelve differing results are verification SKILL/control, AUTHORIZATION_AND_PROVIDER_BOUNDARIES, CURRENT_OWNERSHIP, MODULE_CONVENTIONS, the two prior acceptance release paragraphs, database runner, module registry, the Critical Tasks before-ledger and Training goal before/after ledgers. The helper/governance/ownership differences inherited from main remain preserved; the application/chart/model/workbook result bytes are unchanged from the accepted source. Prior v6 full review SHA-256 is `4ead50efef86dfb2a8decd6b4b69b0bda1e51f525efbd0a572ef30f33db23529`; its cumulative patch SHA-256 is `c96a9c1cdcabd6f4db8ba85e90afddf3d63f083e230a6aff15162f029bbc1fda`.

## Retained source and consumer contracts

The scoped implementation still delivers only slice 1503: URL-bound filters, server first paint, Bottom line, Forecast chart, Hot-spot grid, cell-detail request/summary and the retained filtered per-Soldier workbook. The approved pure model from 1502 remains available. Type-risk/Focus sections, full Affected soldiers table, five-sheet export, Print brief and deletion of retained legacy helpers/contracts remain 1504 work. The parent issue's five-sheet/print requirements are not claimed complete by this intermediate source verdict. Original brief, current 1503/1433 snapshots, current domain docs and recipe agree on this boundary.

**Authorization and provider ownership.** Page and all three API configurations require `training.viewRecords`; the query repeats that admission before independent source reads. Personnel's named report roster port owns roster/scope policy; Training does not query foreign Personnel or Organization tables itself. Organization's ordinary request-RLS reader exposes the narrow name/goal method used through `Pick<OrganizationSettingsReader, 'findTrainingBriefingContext'>`. It lowercases the canonical UUID, selects only name/goal, propagates provider errors and returns missing distinctly. The request adapter composes that reader with the existing scoped Training read stores and roster port. The public Training → Organization module edge has an actual current consumer; there is no permission coupling, provider waiver, new admin fallback or scan exclusion. The in-memory mapping matches the contract, while its success does not stand in for RLS proof.

**Filters, loading and payloads.** Seven independent sources begin in `Promise.all`: roster, types, saved views, Training records, rank catalog, group catalog and Organization briefing context. Saved-view ordering precedes optional-type exclusion/Types intersection. Unknown catalog values normalize independently; empty multi-select arrays mean all. The server returns canonical input with options, not raw roster/records/configuration in the summary. Normalized parameters round-trip through view/group/rank/repeated MOS/role/types/horizon/rowsBy. `formatToday` retains the server calendar convention with no new timezone setting. No initial client summary refetch is introduced. Reports alone return `training: undefined` from the Training layout while retaining ready-shell admission/dependency invalidations; Matrix/Types/Views still bootstrap/hydrate normally.

**Request/route lifetime.** `TrainingBriefingSession` owns one Organization's initial report and input. Selection invalidates/aborts the previous request and guards response/error against its sequence even when the transport ignores abort. It returns failed controls to the displayed report and retains the attempted input for Retry; URL and export use the displayed report's canonical input. Detail requests independently abort/guard, are cancelled when the report changes, and are invalidated on disposal. Page route data keys a new component for another delivered report; `onDestroy` disposes the old owner. Clear filters resets the approved defaults. Current tests exercise these actual failure/late-response behaviors, rather than class names or geometry. No live stale-reply race is inferred from source alone.

**Detail and export.** Detail re-derives a cell/focus scope under exactly the same authorized source and filters. Malformed scope is 400, unmatched row/type/focus is 404; a valid quiet cell is empty. Pagination defaults to 25, caps at 100 and clamps the final page before narrow label mapping. Requirements sort missing records first, then date/name/identity; no completion-record IDs enter a page or detail URL. Summary/detail/workbook responses are `private, no-store` with `Vary: Cookie`. Export uses the same population/columns and preserves saved view order, then name ordering independent of detail pagination. The old export test file is removed only with its meaningful denied/download behavior consolidated in the common current route tests. It remains the one-sheet `Training Report` per-Soldier workbook pending 1504, not the future five-sheet output.

**1501/1502 math and reverse meanings.** The ready set remains current/yellow/orange warnings; optional, exempt and not-required requirements are excluded, while expired/not-recorded requirements are not ready. Applicability and stored expiration are resolved by the existing Training clock with optional as-of. A ready requirement lapses the next calendar day after expiration. Weekly/final partial buckets include lapse dates at the horizon end; exact fractions govern bands, worst-first rows, cliff shares, drop threshold and focus ordering before display rounding. The 11/13 witness distinguishes rounded 85 from an exact goal. Row soldier count includes people with no applicable requirements. Focus selects at most three, orders recovered population requirements, suppresses ≥50% union overlap, and retains row versus population what-if denominators. Empty denominator is null in the briefing; retained legacy surface conventions are preserved where still consumed. Shared readiness rollup preserves Critical Tasks' separate applicability/threshold and status meaning; Training's warning/delinquency list remains distinct from ready aggregation. Dashboard, Personnel summaries, Onboarding completion references, Matrix, rank catalog, import/edit and legacy workbook consumers retain their named contracts.

**Organization settings and exports.** Goal validation is strict integer 1–100, separate from legacy rounding of the other policy fields. Partial updates and retired Critical Tasks-field rejection remain. Provider success requires the canonical ID and every submitted normalized value before audit/success; failed/mismatched acknowledgments fail closed. Policies draft/save state retains separate fields, failure drafts and stale-Organization request protection. Organization raw export now retains all twelve profile fields, including the goal. Its downstream moved Data Export workbook/manifest use dynamic raw section keys and therefore retain the new scalar without changing admission, ordered complete pagination or distinct sensitive Personnel export meaning. The actual current `organizationExportWorkbook.server.ts`, manifest, ordinary Identity preference module and App Shell adapter are byte-identical to main base, so their main migrations/moves are not unrelated reversions in this PR diff.

**Shared UI interfaces, without visual judgment.** ReadinessBand retains ramp/compact defaults for Critical Tasks consumers, with opt-in semantic/tile/drop APIs for Training; it consumes the model tier instead of reclassifying rounded numbers. OperationalMatrix still owns the selectable button and supplied accessible label. Shared ReportWorkspace retains card defaults and adds an opt-in briefing variant. WorkspaceToolbar adds optional spacing/disabled handling without changing existing caller defaults; ToggleGroup delegates semantics/value binding to the existing primitive. ReportForecastChart accepts precomputed points/buckets/ticks/goal/band and has one current Training caller. That caller supplies nonempty monotone no-renewal series and valid date strings; the chart's pure label offset changes annotation coordinates only, not percentages/dates/cliff math, response shapes or admission. This statement is a source API/math check, not a placement/legibility/Paper verdict. The screen-reader table exposes dates/ready/lapses/window facts; no actual screen-reader run is inferred.

**Performance and simplicity.** The implementation avoids the Reports matrix bootstrap and duplicate initial summary request, starts independent source reads concurrently, maps narrow summary/detail DTOs and retains one owner per request lifetime. Detail currently re-derives the scoped model and export traverses the filtered population; the approved in-process model and full provider-sized source paging remain, with no new unbounded browser-record payload/cache layer. No benchmark or browser latency claim is made from these static properties. Shared interfaces are optional and have demonstrated consumers; no new dependency package, blanket compatibility layer or generalized framework was introduced. The 30ms Onboarding test cleanup drain preserves main's body-overflow wait and the known older callback cleanup; production Onboarding behavior is unchanged.

## Current migration integration and immutable preservation

The Training migration is now `20261004100618_training_readiness_goal.sql`. Its 484 bytes are exactly the old branch migration, SHA-256 `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962`, with R100 against HEAD. It adds a smallint non-null default 90 and CHECK 1–100. None of the 169 current numeric migration versions collide. Main's progress scope `20261004000100` and Critical Tasks retention `20261004000200` remain unchanged, respectively SHA-256 `5a8684150e0bdd61666d497adc8cbeecd108ddd20ac4476f567cd4c7440b9977` and `0f6a4e55c4f12ce0e0e2c5db8fd8599cb0c304271bd04eceaf5b5bac863d9c3b`.

The runner retains all earlier held migrations, before fixtures and after contracts and adds only the Training goal entries/fresh contract relative to main. Its restoration tuple's CT-before-progress order is not execution order: actual CLI migration order in the populated log is progress scope → CT retention → Training goal. The disposable copy disables legacy seeds, uses separately allocated ports/project IDs and `--include-all`, and runs the actual existing `db:test`/pgTAP/provider probes from that copied context. No existing development or remote database action is claimed.

For every affected old ledger, only the **current view projection** subtracts the new `training_readiness_goal_percent` key from Organization JSON. Before-row tables still capture complete predecessor values and are never rewritten after migration. Existing exact row counts, ID/value/timestamp equality, foreign historical rows, grants/RLS/functions/metadata and denied/retention assertions remain. The new CT current-view projection is the same narrow additive-column treatment. Main's CT after contract is unchanged and still proves invoker/grants, preserved historical mismatch, strict cutoff, referenced-task retention, foreign sentinels and replay zero effects. Main's preference after contract is unchanged and still proves all 14 ordinary scope/preservation outcomes.

The Training before/after fixtures bind the unique new version absent-before/present-after. Its separate goal contract checks type, non-null/default 90, old Organizations' new values, 0/101/null rejection, 1/100 acceptance, member read/denied write, foreign denied read/write, owner/admin allowed updates and only the privileged Organization's persisted change. Those assertions cover the intentionally excluded new field while old-field equality stays exact. Current release paragraphs name 20261004100618 and preserve the original 00100→00200 renumbering as historical context. This remains unreleased and must be applied through the authorized release process before deploying code that selects the column; no remote migration/deployment is claimed.

## Actual root checks and SQL, not execution by this reviewer

All seven commands in `.verification/1503-v8-required-checks.json` have actual exit 0: format, format check, lint, governance, Svelte/types, full tests (`--maxWorkers=4`) and production build. Receipt SHA-256 is `c8146434549c270e63adcc26201e3aea71aac4a0cc2a53a4aaccfa9bf94b6a8e`. Full tests report 687 files / 6,815 tests PASS; the fake-revision fatal line belongs to a negative CI test. Types report zero errors/warnings. Lint reports zero errors and 13 warnings: ten immutable/scratch evidence-script warnings (including copied v7 diagnostics) plus three existing Calendar/Onboarding reactivity warnings. Governance reports 303 historical findings with regression PASS against exact base 6555; existing scan/allowlist/debt scope is not hidden. Build succeeds with existing chunk/plugin timing and optional OpenTelemetry dependency warnings. Counts are gate results, not a substitute for meaningful coverage review.

The actual database result is `.verification/1503-v8-database-result.json`, SHA-256 `9e7014db9e793d5473da8a8feedc0c73097abdfd08ee77cbdf122eee404a2db5`; its complete log SHA-256 is `21f58dc23dfdebca3f335e6860090dab62a3235663be6676e41035adb2fc656a`. It binds current HEAD/base/source patch, Node 24.21.0, Supabase CLI 2.101.0 and Postgres 17.6. Actual isolated fresh replay is 169 migrations / 1,805 reported pgTAP tests; populated replay is 141 predecessor + 28 held migrations, 22 before fixtures, 24 after contracts / 391 reported pgTAP tests, plus retained ordinary provider probes PASS. The inspected actual Training fresh contract has 19 passing TAP outcomes, populated Training 21, CT retention 19 and preference scope 14, with no `not ok`. These are current SQL executions rather than the bounded migration author's static checks or the older v6 replay.

Both own projects, `t2t-ci-db-bvi0mp5y` and `t2t-ci-db-jcwueqxa`, have cleanup logged and structured directory/container/network/volume absence. This reviewer read those records without starting or inspecting services. At source-report preparation, no separate v8 touched-Markdown format/link/anchor/diff log had yet been supplied; root was notified to include those actual documentation checks in final validation. The runtime gates do not silently substitute for those prose checks.

Meaningful retained protection includes domain calendar/weekly-parity and exact-fraction matrices, source canonicalization/authorized roster/order/optional filtering/privacy, page/API denial, detail malformed/stale/pagination and workbook content, no-initial-refetch, late ignored-abort answers, failure/retry/disposal/detail cancellation, route replacement, layout/bootstrap admission, strict goal validation/acknowledgment and SQL/RLS/old-row preservation. No new geometry/appearance test, budget increase, waiver, skipped path or source-spelling mirror was introduced for the chart. Historical status-ranking structural tests already exist and are not represented as acceptance of the chart correction.

## Evidence and final-acceptance limits

The unchanged-chart 684-state matrix remains v7 proof on base 0fa/HEAD 3c0b, candidate 7159…, with exact chart bytes 706cd892…; it is not a new 684-state execution of integrated v8. The completed `.verification/1503-v7-expanded-evidence-audit.md` is SHA-256 `10fdda1c53815b3bdaa76a00aaa4f70ff929fe8658466251f256142eb4dc1a12` and stays unchanged. It records actual successful driver Paper bytes separately from the later artifact judge's Paper timeouts, the nonblocking visual disposition/errata, all 19 CLI failures, four shell failures, the missing derived-image Read, native export bytes and full restoration/cleanup. No routine-placement permission gate is introduced here.

Current root worker/browser smoke is separately bound to candidate `0196ae3f0e438f64565069e6dfc94525a4f1865678b71035fe5a5834a4bcda1d`, session `8f3afad2-9a4d-4eb1-9acd-decfee2122a0`, origin `http://127.0.0.1:33003`. Its independent T3 Claude driver was still active when source review began. No current browser PASS, screenshot judgment, exact cleanup or expanded-package verdict is inferred from launch/seed/doctor. Root's current smoke/validation package must be audited separately after frozen completion.

V3 auth/race/server-fault evidence remains older-candidate supplementary proof. V3/v4 and v5 D4 chart failures stay historical failures; v5's original localhost/cookies deviation after HTTPS HTTP/2 403 cannot become Mac/HTTPS/namespaced proof. V6 remains UNAVAILABLE/UNRUN: its `loginPosts` resource-name count does not establish a login POST, no authenticated session was observed rather than proven impossible, and its Oct 3 saved timestamps make the midnight statement a future warning. V7 native sign-out is newer evidence but does not rewrite v6. Live fallback-font, real provider/server fault, fresh stale-reply race, export failure, every retained consumer/actor, Mac/HTTPS/T3 native browser and actual screen-reader execution are not silently filled by source reading or v7's scoped matrix.

**Source verdict:** PASS with no nonvisual blocker/advisory on the exact bound current source; integration seam resolved and actual current SQL PASS. Current browser/expanded evidence, required prose receipts and final PR acceptance remain root's separate completion work. The subsequent inventory is exhaustive for this review checkpoint and carries historical binary boundaries without converting them to current live evidence.

## Every-path census

The following table binds every cumulative text entry against base 6555. `V6 identical` means exact in-memory reconstructed after-bytes match the complete previously reviewed v6 result (normalizing only the migration filename). `Current delta` names the twelve differing results examined for integration. Deletion is bound to its main-base bytes. This provenance column does not claim any fresh test execution.

| Status | Path | Current bytes SHA-256 (deleted: base bytes) | Review continuity |
| --- | --- | --- | --- |
| M | `.agents/skills/verify-trooptotask/SKILL.md` | `4d3e8b8214bc0d5f4a474d6e87f9324856e2b5f4434e415fb7660260794356f8` | Current delta |
| M | `.agents/skills/verify-trooptotask/features/critical-tasks-completions-readiness.md` | `5d4834c8e763b412e951ca9ea617c0b120515612a274522c89ad6ec05e779ebc` | V6 identical |
| M | `.agents/skills/verify-trooptotask/features/organization-settings-destruction.md` | `8305c969f67490db2998a29051159b27afb7541a15628c997fd12f9bf88d3c94` | V6 identical |
| M | `.agents/skills/verify-trooptotask/features/training-completions-reports.md` | `4b84450b19460bcbd67951fce79afe763f1d7ae4fbc2dc6e110ebbeb922146f0` | V6 identical |
| M | `.agents/skills/verify-trooptotask/helpers/control.mjs` | `76b3050bb7d72dcd16f69546dc50b244ee826f868196700dddc33c4aa1c7f444` | Current delta |
| M | `.agents/skills/verify-trooptotask/helpers/settings-request.mjs` | `3542f8b4e90a8204f42ca1d1e790e732b81a15325bd26d0c49a0ddb46b311956` | V6 identical |
| M | `CONTEXT.md` | `4637eb30bff5deb8a4b8e52e368787254bd4ac81849349af22fd4d984681534d` | V6 identical |
| M | `docs/architecture/AUTHORIZATION_AND_PROVIDER_BOUNDARIES.md` | `962b77b310e625a9cedd9cb35879ef4d3ce0a9e6c561654d6857a264a59ce1ca` | Current delta |
| M | `docs/architecture/CURRENT_OWNERSHIP.md` | `21ab92e02a8f11b9591ea2b8cd5b179a17f98a38cf0be8ab6c2cd6d8f76da097` | Current delta |
| M | `docs/architecture/MODULE_CONVENTIONS.md` | `dc323e853c6a32339fb9ca3d6be155c553f8f953ecd8ff277d7203043d67c6bb` | Current delta |
| M | `docs/component-catalog.md` | `212b62865478b0ec8c626140e1d000405cb6a50abeb0ffac93014ee646b4c0e2` | V6 identical |
| M | `docs/domain/retained-feature-rules.md` | `74b264abedc6e640de118185a6d37563b3e3373abfc64630d8be0b4cd56f687e` | V6 identical |
| A | `docs/verification/training-reports-1501/acceptance.md` | `06b6904e31ed613c9e832826bc5d02bfadfd68241404132e1bcb18688692644a` | Current delta |
| A | `docs/verification/training-reports-1502/acceptance.md` | `a20f2a7430722f08c336079316cd58705f02306e1760bb76e3533bd2da246049` | Current delta |
| M | `scripts/ci/database.py` | `67189f0a4470552476e2b1899a564222f753e66e4c4a556eb4efeece5caab5d1` | Current delta |
| M | `scripts/module-boundaries.json` | `59f282a280ca87a10f78335e7b71ba9a081f36ab8addc159ad3ea39244b85271` | Current delta |
| M | `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts` | `9ab7159097171d74c5feb70067ffd0aa8d6c0e3a5fec4862aa7ddb31868fab5b` | V6 identical |
| M | `src/features/organization/PoliciesSettingsPage.svelte` | `6387821b225c4dc09f17961d45991d1c7f0b6d9ec0117514f4cf99b57adf9a33` | V6 identical |
| M | `src/features/organization/PoliciesSettingsSection.svelte` | `0a3013074eafa30fc05cc77bafecaec607d0b494e9412904f0e411a588565c4e` | V6 identical |
| M | `src/features/organization/policiesSettings.ts` | `cb71f5ee1514d916ad50adaa0dc88158f15bd2de4eeb27a1256a93e60e37fa1d` | V6 identical |
| M | `src/features/organization/policiesSettingsState.svelte.test.ts` | `24fdf5cbddc67e146412104144f4298837e1e7b3f86a5a2094590c6c53aef778` | V6 identical |
| M | `src/features/organization/policiesSettingsState.svelte.ts` | `e6d6a86506216a2bebb312b7b8b872ff9b5bbf638072f3937f8311e9b123295e` | V6 identical |
| M | `src/features/organization/policiesSettingsTypes.ts` | `12c2b6158b1febe38fb9be7bdc335ca71c74b0d4626a7ccbf39d5328a0b81531` | V6 identical |
| M | `src/features/organization/policy.server.test.ts` | `0aeb4a5034df40434f32b0bcebc878a944496317c82f96cd14f69841329abb43` | V6 identical |
| M | `src/features/organization/policy.server.ts` | `ab31c004aa04c695861bbdc2f8c7289cdddc6143a9556abed70cd80b52464852` | V6 identical |
| M | `src/features/organization/policyConstraints.ts` | `3277ff269a8b8fa5abc28d1823306d665771c77ccbf5d3b194a733c47b5c459c` | V6 identical |
| M | `src/features/organization/policyProvider.server.test.ts` | `b5fb2466ea43355975c8eedf995c5360a6930b0b952d5fecd482e3fdd1dc3751` | V6 identical |
| M | `src/features/organization/rawExport.server.test.ts` | `fcf0e931ef9285590c8ff77750e033a0631fa2956cbad5cf5498e7ceab63e1cb` | V6 identical |
| M | `src/features/organization/rawExport.server.ts` | `24d2c7e8f32f9ff7203ada500cb3fc73ecad4f2cde67d768dbd10364b33980f1` | V6 identical |
| M | `src/features/organization/settingsProvider.server.test.ts` | `b23aa3607a1042ae080dba4e77efb2a0b5f24392f79d3cefe7d50394d2cce91b` | V6 identical |
| M | `src/features/organization/settingsProvider.server.ts` | `db5e7cf7a33b2071d222475a3700547b61dbc45da9d7936fbc84250778536c92` | V6 identical |
| M | `src/features/organization/settingsTypes.ts` | `d8122efeaac05752409487c67d598639c9ecf7382578d19b7c5849ab0d01e92b` | V6 identical |
| M | `src/features/training/components/TrainingReportsPage.svelte` | `f341787d7120a3b38625bf85fce359f462f91c5f268ec0e103716fb8ee570dd2` | V6 identical |
| M | `src/features/training/components/TrainingReportsPage.test.ts` | `e2a75d273f54442da1ec5ae362cbeb44b28446cf3adfc6de7ca108ec49584c05` | V6 identical |
| M | `src/features/training/contracts.ts` | `4d7695947daccf08db63c3ed221cfe7dcd4bf67f95435b72b915f5b8518e24d4` | V6 identical |
| M | `src/features/training/index.server.ts` | `40b0946bff46984dc7d44f986d35498ead42dbfee78c4c628ca692c87922ab14` | V6 identical |
| M | `src/features/training/index.ts` | `50a0b857f57ed5d0aee9d8816420ab4bb6b1c6cc8c56c37a12a8fd109d05b1e5` | V6 identical |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.test.ts` | `616d4e8ebf4ae5e6468d2ff850feeadb1403c1909e51ecebd7fe2b8683ad3bb9` | V6 identical |
| A | `src/features/training/read-model/trainingBriefingSession.svelte.ts` | `577a83364fd31004038f44bfb016c6dce0a42bf6f6fe4b6b8a8a038d2a754274` | V6 identical |
| M | `src/features/training/server/trainingReportsQuery.server.test.ts` | `ba315d4c7d19a6bbcd43fad1536f0a6fda485e5d22e3559fbb0167813cde6f95` | V6 identical |
| M | `src/features/training/server/trainingReportsQuery.server.ts` | `8d6470a012579585de122b4f21c47d88c2150450a2340863706617412a79b958` | V6 identical |
| A | `src/features/training/utils/briefingReportInput.test.ts` | `5aac480a55e0e96837ad4782e56cebbecb9b5b257188bbeb1b430ec59b52084f` | V6 identical |
| A | `src/features/training/utils/briefingReportInput.ts` | `5b3c49540eb8591151213eaa2be50506a7dc60b78b17dfbc4e7df7a6e6226e9b` | V6 identical |
| M | `src/features/training/utils/reportCalculations.test.ts` | `0e53c0407fa0d558d9ccee42ef8639c2a823224d9ecc923335639adfea9e7ab3` | V6 identical |
| M | `src/features/training/utils/reportCalculations.ts` | `2341f87b39951f98c08d88cc6cb24453e949537911bc58c7e46d69c3776168e5` | V6 identical |
| A | `src/features/training/utils/trainingBriefing.test.ts` | `f97041cccb2acfcd74b53a237125924bab8616c8023d86105bb67f1d62bd75ed` | V6 identical |
| A | `src/features/training/utils/trainingBriefing.ts` | `6562aa06a28a428b4ed679f1685be40ce4dfe9bd18265365b14564da15165bd5` | V6 identical |
| A | `src/features/training/utils/trainingBriefing.types.ts` | `2b6a3b651e78c99f7110c6ffa6a51b51467fc16b79c69311ba2eda30150f94af` | V6 identical |
| M | `src/features/training/utils/trainingStatus.test.ts` | `a7f081e6ea5d1878f309bf7b39bbf76ad2ff2acd644646942b9a3174500e39f3` | V6 identical |
| M | `src/features/training/utils/trainingStatus.ts` | `ef0ae1f4efdf721a80bf83107c077567bc39369779d87d47f73cba13e92b8cd6` | V6 identical |
| M | `src/lib/components/ui/readiness-band/ReadinessBand.test.ts` | `8cfbe81c63d4678cafb43a25a253424e55409c5b3b29ddc891292853e30afe75` | V6 identical |
| M | `src/lib/components/ui/readiness-band/index.ts` | `fbc42884b8a9e0edb6c4a57ca8c8fa6805a9724233587c8d6546e109f127a35e` | V6 identical |
| M | `src/lib/components/ui/readiness-band/readiness-band-cell.svelte` | `0d18beafb2e765306a34296cd7c7f03ac8632aabd6062541cd58cb3d5bc56e8e` | V6 identical |
| M | `src/lib/components/ui/readiness-band/readiness-band-legend.svelte` | `5fe61e364f174547d6c47b6baae963d41b583584d77da2155076f228aff4b3a2` | V6 identical |
| M | `src/lib/components/ui/readiness-band/readiness-band-swatch.svelte` | `44df84a36ea4f58199c46ee5b63428c70e535da0cc49bd0104bf32851b7b2205` | V6 identical |
| M | `src/lib/components/ui/readiness-band/types.ts` | `ad94ec16e0145657a4169005940e55f467668334dda4c9b8f688f52a3280bc42` | V6 identical |
| A | `src/lib/components/ui/report-chart/ReportForecastChart.svelte` | `706cd892350695097546eba779f989db5df81d8834b92fce2a677cf40ae7b831` | V6 identical |
| M | `src/lib/components/ui/report-chart/index.ts` | `1092440911915989fcd94b431998761d4f1d9659417fea254a72087be3b69230` | V6 identical |
| M | `src/lib/components/ui/report-workspace/report-workspace-section.svelte` | `38c0d2319ce7dc618b7094347a11e6e43e6b0768e304ad68c43e0a4d4bbd0cc8` | V6 identical |
| A | `src/lib/components/ui/toggle-group/index.ts` | `5ad8938622bce94f5d3611adbe7e13da8f5cd176f56d3eadeb6a8c8eaa334103` | V6 identical |
| A | `src/lib/components/ui/toggle-group/toggle-group-item.svelte` | `cbde5673054945e9ca4e5d6a588ab9dacffabf38fd4e4d05d3f966165cc82b27` | V6 identical |
| A | `src/lib/components/ui/toggle-group/toggle-group.svelte` | `1a8ffb1f16373ccc2ad720aaa90e9e44012ba572875d0a544b184f7df868b900` | V6 identical |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-actions.svelte` | `9edbf5d1eb0a05358266386e856f4e0990cf6b3f3291b70ffd24ca399a179af3` | V6 identical |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar-select.svelte` | `d533efc217a5e4e710dbe354f293c8728c13b8db721a90252b632fff631682cb` | V6 identical |
| M | `src/lib/components/ui/workspace-toolbar/workspace-toolbar.svelte` | `9c5e79b4f5adc62580aaa6f619f8a823f93e22158a4265ef0ad8bf30a73e6d96` | V6 identical |
| M | `src/lib/domain/readinessRollup.ts` | `84297b627a86055bdc300597f0b790311bb191472ade3267cb5283957d099293` | V6 identical |
| M | `src/lib/server/adapters/inMemory.ts` | `58fc873491d8f85d85b77b94d84bb4e681599c78a5eaf2f88cc7af4c4d0fc810` | V6 identical |
| M | `src/routes/org/[orgId]/api/organization/settings/server.test.ts` | `8f23cf37ededa97e0b0d061177d33dab3e12c651e8ae1505a83581ae01838f47` | V6 identical |
| M | `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.test.ts` | `d693459f995e8ae7f9124c6d5ef92b5ab3b7f9b3b69221cfdef3f7fba49bec1b` | V6 identical |
| M | `src/routes/org/[orgId]/api/training-reports/+server.ts` | `a4c0df9f571653953281b2acf849ffacdc5eac128c398ac46fd4b1e215bb3467` | V6 identical |
| M | `src/routes/org/[orgId]/api/training-reports/detail/+server.ts` | `06bd97fe5143520927805bb32d55189dc49e3475a867a9d65ca32a45a1de1324` | V6 identical |
| M | `src/routes/org/[orgId]/api/training-reports/export/+server.ts` | `87411f0be57744195b120f322c5a56f6c3a2b3e0286ab34ed93d2f731d230f87` | V6 identical |
| D | `src/routes/org/[orgId]/api/training-reports/export/server.test.ts` | `6a19175bf802fece45ef976e5b7e055ce23c464e347a0734173b6754cbfb01ec` | V6 identical |
| M | `src/routes/org/[orgId]/api/training-reports/reportInput.ts` | `009576da7f537c6f19f46d534af1049a42a0cc449e777ed4ce545dfab6c0e87d` | V6 identical |
| M | `src/routes/org/[orgId]/api/training-reports/server.test.ts` | `347f9792197ca8bfbf69468365b36919ef8c8688b75de8037e21bca3442b1bbe` | V6 identical |
| M | `src/routes/org/[orgId]/settings/policies/page.svelte.test.ts` | `de92036ae278aa3b98946d85eb37982d58f6e0f21f29a5f3ec532eb83f588866` | V6 identical |
| M | `src/routes/org/[orgId]/training/+layout.server.ts` | `21cf76fda470075596c65ff58bc6a8a446daf495e77f166bd96b7f55d7411f87` | V6 identical |
| A | `src/routes/org/[orgId]/training/layout.server.test.ts` | `2feb570963aee002a70f60553adb741513261f66ecd08aa77917e6c1427c947e` | V6 identical |
| M | `src/routes/org/[orgId]/training/reports/+page.server.ts` | `e7e6d2836201e64b50178082b5d355b1b4131006de77bb59ce1791a2345c1d2d` | V6 identical |
| M | `src/routes/org/[orgId]/training/reports/+page.svelte` | `7042fcbb5e4959fc9191669cacefd9419a89ba1701fda912c3df34d9d028850f` | V6 identical |
| A | `src/routes/org/[orgId]/training/reports/page.server.test.ts` | `aeb04d05b65435943fac1d3cbb0c0912bd61ceae8fc684d89a5efa4511c6e947` | V6 identical |
| M | `src/routes/org/[orgId]/training/reports/training-reports-page.svelte.test.ts` | `c0ab4f20a67a7a3cc3d4d0056e872596e12b22efb4252783cc431d31ce893d56` | V6 identical |
| M | `supabase/migration-tests/account_preferences_scope_before.sql` | `140eeeb708d3413fe84042bcf0b9cadf917f29c582c929f08be1d211bf170ce5` | V6 identical |
| M | `supabase/migration-tests/calendar_unassigned_populated_after.sql` | `188f6f22c4f4e64041e4432191df15c0448283dd43a787aefa53f2e5a8d6e24e` | V6 identical |
| M | `supabase/migration-tests/critical_task_archive_retention_before.sql` | `5784480a5ec4ce29e5a0184e199c4d3dccb7a0e11851f7ad48f710efac55d2e4` | Current delta |
| M | `supabase/migration-tests/critical_tasks_populated_after.sql` | `7bba26199cf6657413f432eeaec45cbc923d13d05bf4c178904320da0d320b8a` | V6 identical |
| M | `supabase/migration-tests/deletion_request_cancellation_before.sql` | `be3d5381caa3c55c1a6173b82340156ebc8988fcac860cb4f82740e4fb446c5c` | V6 identical |
| M | `supabase/migration-tests/organization_file_upload_before.sql` | `ba66b3617a2d6a92ca00d2950fd9b30ae7872eb65e0293cc015a4ba21a3a139e` | V6 identical |
| M | `supabase/migration-tests/organization_file_upload_contract.sql` | `b577e25a5d1534a29dd2bacd10a646c48cd762c98cff943ceaed30dcdfe48619` | V6 identical |
| M | `supabase/migration-tests/organization_storage_cleanup_before.sql` | `d84ef0838e68cccda4cf04770bc77fec34b2d8675d08cf9e57b8be7a24dc206e` | V6 identical |
| M | `supabase/migration-tests/organization_storage_cleanup_contract.sql` | `c95a5f1b12952f5feb4bc80b782f4ecab72f48aefaa961891e4a9305ff088ba6` | V6 identical |
| M | `supabase/migration-tests/personnel_counseling_file_populated_after.sql` | `ee8a49873cfe8dc1e376265dfc0c949cc12458208e9431c4f52f7eee7dc5a36b` | V6 identical |
| M | `supabase/migration-tests/personnel_extended_info_populated_after.sql` | `b29adbc1a5b198b9b1254264c549bfc67cb8d217d723cf04729919e4a4e122fd` | V6 identical |
| M | `supabase/migration-tests/personnel_unassigned_populated_after.sql` | `86cd11035201bd536e6cf9a06d2da4e2ad7dfbb6e37b247773885671e8f4e7b7` | V6 identical |
| M | `supabase/migration-tests/platform_membership_before.sql` | `af77afdf7345a31344e2575148f74f52cc725e9bb3bad2ffa2124c46ba3559ea` | V6 identical |
| M | `supabase/migration-tests/rating_scheme_populated_after.sql` | `67c70b777b71c46cd22a3d2cc9ac997971b14ca01dc80eca02ea8328957229b4` | V6 identical |
| A | `supabase/migration-tests/training_readiness_goal_after.sql` | `9e7ad7b21cf73d8c5924d60cefc16b4e22d6a48a1db5ad1e50d6f8c8f417adc4` | Current delta |
| A | `supabase/migration-tests/training_readiness_goal_before.sql` | `00a1fdc4afb86a4e2dcd9930c303aed95f1fb807f00013d333e80c648e36104e` | Current delta |
| A | `supabase/migration-tests/training_readiness_goal_contract.sql` | `129eb2e3bfd28381b4fb20b815a7d8ba21a78a54112f53ac39f16ec6f0a8742e` | V6 identical |
| A | `supabase/migration-tests/training_readiness_goal_fresh.sql` | `fce1306b65521fcb23d94a6f0511d94ea4b32d3eb4bcbd467c63a2ed54fa947c` | V6 identical |
| M | `supabase/migration-tests/training_record_populated_after.sql` | `627c5f6bb7c4334d92d5d9962b1d1278c6dc1aaffec4779b76ef7ecd62df0869` | V6 identical |
| A | `supabase/migrations/20261004100618_training_readiness_goal.sql` | `a46980dac541290102447f9e77c17e25a3b819620e5cb2ca32a9f4441bba6962` | V6 identical |

### Tracked historical binary archives

The six tracked additions below retain 1501/1502 historical evidence. Their exact current archive hashes were checked; full contents were covered by the prior package integrity reviews and are not re-rendered/re-audited or promoted to the current browser run here.

| Path | Bytes | SHA-256 |
| --- | --- | --- |
| `docs/verification/training-reports-1501/baseline.tar.gz` | 281614 | `0b2f279ddc5b7f22b849cfdb35d6617e9a09c3bca82b369077c7530d6a9a631a` |
| `docs/verification/training-reports-1501/final.tar.gz` | 537699 | `72ebffdbd185f85f7af876c428c5f127d94320cc09729d83411bec34a9b2ff4a` |
| `docs/verification/training-reports-1501/validation.tar.gz` | 235881 | `73af61b577db8e4d8144baaaa1d5842fb9afcef89c4c3b1fc7439de7cd727df6` |
| `docs/verification/training-reports-1502/baseline.tar.gz` | 182877 | `3f5eed79100b3747453564f95b366eaf66e3c48c7ab1fd72384ddce456c3da2f` |
| `docs/verification/training-reports-1502/final.tar.gz` | 857125 | `7587454d049dcd8397598fb5537d36410df82e2689524cd1d0d4dd5f43f12626` |
| `docs/verification/training-reports-1502/validation.tar.gz` | 94200 | `ccc30126735e7e9801314261127e293ae7b336aef96473a4270a9825b13e0df2` |

### Untracked 1503 archives at this checkpoint

These eight files are included in the inventory boundary even though git diff does not include them. Baseline and failed/unavailable runs remain separate historical evidence. Previous reviews supply their stated integrity/acceptance limits; only v7 received the new complete expanded audit. No screenshot is viewed here. Root may later add a separately named current smoke/validation package and acceptance prose, which need their own bounded final inventory/evidence pass.

| Path | Bytes | SHA-256 | Boundary |
| --- | --- | --- | --- |
| `docs/verification/training-reports-1503/baseline.tar.gz` | 1704184 | `fa83957d99b581bbb93df8b4337f139d827d8df9dfb3e5a8524c099248dee4c9` | Prior immutable baseline/failure integrity boundary |
| `docs/verification/training-reports-1503/final-v7.tar.gz` | 16701741 | `447f9332647bdbf5e10b782a4b557cf1945318edea6935ee5ed487ae74fe7200` | Current v7 audit; historical old-base scoped PASS |
| `docs/verification/training-reports-1503/visual-failure-v2.tar.gz` | 4546927 | `506cdc2433025c1beebec1c8c9cb8e5d779db718498280f604cfd0281c266a5f` | Prior immutable baseline/failure integrity boundary |
| `docs/verification/training-reports-1503/visual-failure-v3.tar.gz` | 3567677 | `973f3cb2fd148afc95784530a38e902a1f0eb16fee3630a3478f4a2c88410299` | Prior immutable baseline/failure integrity boundary |
| `docs/verification/training-reports-1503/visual-failure-v4.tar.gz` | 2911869 | `bf1a94039ba6d48bb56a38ec4c5f1c3221a1746a3d70834221849a45a5403bc7` | Prior immutable baseline/failure integrity boundary |
| `docs/verification/training-reports-1503/visual-failure-v5.tar.gz` | 1696296 | `f316ce2e80ac8f038530c2cf1093b0ac834483face74caa9fb24566dca018d8b` | V5 expanded audit; D4 FAIL/H2 deviation retained |
| `docs/verification/training-reports-1503/visual-failure.tar.gz` | 6591417 | `04d94812ab5c1543f3fe783f64dc9a981bae1b9bcdb02cdd15e39130ea3d0925` | Prior immutable baseline/failure integrity boundary |
| `docs/verification/training-reports-1503/visual-unavailable-v6.tar.gz` | 254498 | `8e44e2ba1a5005c74b977816ac1c0e6478fa13e3f2e3e162f99855dcc1ae6ff5` | V6 unavailable audit; requested outcomes UNRUN |

The source/scripts/SQL and whole cumulative binary diff were rehashed after this review and still match the exact opening bindings. No application/SQL bytes changed during the read. This closes the source checkpoint; it does not certify later added acceptance prose or current live artifacts.
