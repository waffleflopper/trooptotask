# D28 Calendar Bulk Add: corrected native follow-up

Status: PASS for this bounded retry repair. No new application failure observed. Broad ordinary Calendar persistence verification and cutover remain UNRUN and unauthorized in this run.

## Frozen candidate and environment

- Checkout: /home/waffleflops/.cache/t2t-1376-calendar-owner; branch stabilization/1376-calendar-owner; clean before and after.
- Revision: 0762e004fb950baae19dc3e2de9b1f2af73a21cd.
- Candidate: 81dc865dbef4f0744506a8e2f7c24839de7b086aeb976d5442a4b49641531af1.
- Worker 2 owned session: 75040aaf-5d4f-4a7e-809f-01e00468450b; origin http://127.0.0.1:38353.
- Node 24.21.0/npm 11.19.0; installed Chromium 152.0.7977.82; short owned launch TMPDIR /home/waffleflops/.cache/t2t-c-tmp. Native page clock recorded 2026-10-06T03:17:09.575Z and America/Anchorage, local October 5.
- 5024 executable/driving input entries captured in input-manifest.json. Final equality confirms identical set, bytes/hashes, revision and candidate; git clean. No application, helper, fixture, recipe or provider input edits during proof.
- Initial launch/doctor PASS; final doctor and owned cleanup PASS. Only repository verify:app/native DevTools and its documented helpers were used.

Evidence root: .verification/evidence/verify-trooptotask/d28-calendar-bulk-retry-followup. All paths below are relative to that root. Sanitized synthetic fixture and exact effects are preserved; no credentials or token-bearing responses are included. command-receipt.json records the actual CLI arguments retrospectively from tool calls, not as an automatic shell transcript.

## Inputs and retained contract

Normal calendarOperate sign-in entered Organization A's calendar/bulk route, returned actual page 2 and Organization a000d18a-d17d-47bd-960b-80512bfa4322. Organization B is 799ebf4d-3f88-4c9f-8ddf-1733e1213d59. Helper seed bulk-501 created one fresh cohort tag 6807e8b9, exactly MapChunk6807e8b9000 through MapChunk6807e8b9500. The first Person is 6825bbb2-aaec-4590-b0ed-da43d2e95ab0; suffix500 is 1a241375-5d0f-4cb7-9548-18d31dffbe81. Both checks used native nondefault Verification Training, status e457917a-f0ad-4c00-9757-58446180a39d, October 6–14 inclusive, nine days. Notes distinguish witnesses: D28 zero 6807e8b9 and D28 partial 6807e8b9. A/B marked rows were zero before each check. Original availability contained A6/B1 rows.

The store intentionally continues chunks after a failed request. The prior closed run's incorrect premise that failing request1 of501 causes zero effects remains separately preserved; it is not an app failure or a zero-effect pass. This run follows corrected recipe step5: a separate one-Person zero case, then501 with request2 failed. No batching or product behavior was changed.

## Actual native proof

1. **One-Person zero-save/recovery PASS.** Native exact suffix500 search and Select shown produced1of1, then Review showed the Person, Training, Oct6–14 and zero-case note. One pre-dispatch failure control on ordinal1 produced exactly one one-record POST503 for suffix500. Marked A/B readbacks stayed0/0; feedback was Failed to apply status. The actual confirmation remained on REVIEW with the same Person/type/range/note and enabled Confirm Apply. Controls were restored. Native Confirm Apply on that same draft, with observation only, produced exactly one one-record POST200 for the same ID and one full A row, B0. Row2ed33a5e-8e23-48a0-b39e-ba89c3c1fd76 has the exact Training ID, dates and zero-case note. Successful completion refreshed and cleared the form. This separate-note full-row witness remained unchanged throughout the501 check.

   Proof: zero-search/select-one/review-action.json; zero-before-orgA/orgB.json; zero-before-confirm.png; zero-failed-confirm-action.json; zero-failed-network/feedback/orgA/orgB.json; zero-failed.png; zero-before-retry.txt; zero-retry-confirm/network/feedback; zero-saved-orgA/orgB.json; zero-recovered.png; zero-effects-comparison.json. All actual controls/restores preserved.

2. **501 partial acknowledgment/retained draft PASS.** Native all-tag search and Select shown produced exactly501of501. Reentered the same nondefault Training/date range with the distinct partial note and Review showed501. Ordinal2 failure control produced a literal500-record POST200 followed by a one-record POST503 for suffix500. Exactly500 A rows matched all first-request Person IDs and full submitted Training/date/note/Org values. Failed Person was absent; B0. Earlier zero-case row was byte-for-byte equal. Feedback reported Applied status to500of501people and1failedstillselected. Actual settled native snapshot showed exactly one checked Person, suffix500, retained Training/nine days/Oct6–14/note and enabled Review & Confirm before any reload. Screenshot independently inspected. Read-only corrected role-checkbox DOM confirms the selected label and Note input. Search resets when RosterPicker leaves Review; search retention is not this Add contract.

   Proof: partial-before-orgA/orgB.json; partial-select-all/review-action.json; partial-before-confirm.png; partial-confirm-action.json (transient Applying); partial-network/feedback.json; partial-saved500-orgA/orgB.json; zero-after-partial-orgA.json; partial-after.txt/PNG; partial-retained-dom-corrected.json; partial-effects-comparison.json.

3. **Single-Person retry/exact effects PASS.** Restored failure/feedback hooks, then native Review & Confirm showed only suffix500 with unchanged Training/date/note. Observer captured native Confirm Apply as exactly one one-record POST200 for that failed Person. A now has501 unique partial-note Person IDs, exactly the union of original two submissions. Every first500 full saved row, including row ID/timestamp/fields, remained unchanged. One new partial-note row belongs to suffix500. The separate zero-case full row remained unchanged. B0. Feedback reported Applied status to1person; full success refreshed the form and cleared selection. No reload occurred between the partial result and retry.

   Proof: partial-retry-review-action.json/PNG; partial-retry-confirm-action.json; partial-retry-network/feedback.json; partial-final-orgA/orgB.json; zero-after-retry-orgA.json; retry-effects-comparison.json; partial-recovered.txt/PNG.

4. **Settled reload PASS.** Restored all controls before normal native reload, then drained navigation and captured a settled snapshot and PNG. Full ordinary persisted-effect readbacks show A508 exactly equals all original6 rows plus the separate1 witness plus all501 partial rows; B1 equals its original full row. Every new row is fully unchanged after reload, including timestamps/IDs and fields. This is native reload plus separate provider readback, not a claim that the Add screen lists saved status rows.

   Proof: reloaded-action.json; reloaded-settled.txt/PNG; reloaded-settled-all-orgA/orgB.json; reload-effects-comparison.json. Every seed-dependent comparison was complete before cleanup.

5. **Disposal/input equality PASS.** clean-seeds removed the journaled501 People and their502 dependent UI-created availability rows. Full A/B rows exactly equal original6/1; cohort name absence confirmed from all remaining A Personnel. A native reload now shows0of3, no cohort rows, versus0of504 before cleanup. Final doctor PASS, owned cleanup PASS, all5024 frozen source/driving entries and candidate/revision unchanged, git clean. No original fixture fields, SQL/grants, existing status catalogs or assignment slots were changed.

   Proof: clean-seeds.json; cleaned-all-orgA/orgB.json; cleaned-personnel-orgA.json; disposal-effects-comparison.json; cleaned-visible.txt; doctor-final.json; cleanup.json; input-equality-final.json.

## Instrumentation limits and preserved failures

No failed expectation occurred in the actual corrected application scenarios. Minor driving/read corrections are explicit in instrumentation-limitations.json. Initial actor used an unsupported leading-slash destination and was blocked before sign-in; corrected documented destination succeeded. An initial read-only snapshot was initiated before the actor completed and used anticipated page2; it is excluded from acceptance. Actual actor page2 was then established and zero-initial-settled.txt recaptured. A preliminary read of feedback output while its helper was still pending failed JSON parsing; completed helper was drained and complete final feedback inspected before retry. The original partial Confirm action caught transient Applying, so completed partial-after snapshot/PNG is acceptance. First read-only DOM selectors targeted input checkboxes/textarea and returned empty/omitted fields; corrected role-checkbox/bulkNote capture agrees with the native snapshot. Its date-selector field is empty; actual date acceptance comes from native snapshot/PNG and exact persisted rows. No UI handler/state injection or alternate browser was used. All capture payloads remain preserved, with no failed output disguised as application proof.

## Applicability and remaining work

This bounded follow-up proves ordinary native BulkStatusAdd zero-effect recovery, canonical500-success/one-failure retention, single-failed-Person retry, exact full-row stability, reload and clean disposal for this candidate. The independently meaningful real-child Add interaction and existing chunk/neighboring component checks are separate lower-level evidence already accepted by root. This run does not claim Remove/Import live proof, full app suite/build/CI/hosted-review acceptance, or completion of D28/#1376.

The unchanged baseline's catalog and Person/Group saved-slot checks remain separately applicable only at their recorded input boundary. The initial repaired reverse partial1success/500failure recovery remains preserved separately. Remaining broad Calendar ordinary persistence baseline includes status/special-day configuration, single CRUD/import/remove, scoped/foreign/no-lane denials, range/held/lifetime/read acknowledgment effects, assignment ordinary reference reads, actual report workbook/current-history/export reverse consumers. These remain UNRUN here. No new provider cutover or migration was performed.

Root next action: independently inspect literal request/provider/UI comparisons and portable inventory; integrate/archive records, run required full checks and independent review, and carry the non-migration retry PR through current-head greenCI/completedbots without actionable findings. Then authorize continuation of the remaining complete Calendar provider baseline and implementation. Root alone owns publication, merge and issue tracking.
