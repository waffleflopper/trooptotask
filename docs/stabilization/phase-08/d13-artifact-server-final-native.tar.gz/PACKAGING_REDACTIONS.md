Packaging follows final doctor and owned cleanup. Public synthetic Organization/Person/contributor IDs, complete row fields and recorded file paths remain visible. Binary inputs, PDF downloads and screenshots are exact. Only token values are sanitized; all other original payload bytes are unchanged. Historical failed or inconclusive attempts remain explicit. Packaging is not a fresh live run or independent live execution.

{
  "redactions": [
    {
      "path": "125-document-open-pages.json",
      "originalSha256": "2b866c35ee55ed3221ff7862b9683512645aeeb5867a6c424407456247e9e97f",
      "sanitizedSha256": "f05406ef735e3302e30c79cdb1cdd0aa61c4067e7d0e242ec4abcbbd8681e3e2",
      "jwt": 1,
      "queryToken": 0,
      "bearer": 0
    },
    {
      "path": "140-document-archived-reload.json",
      "originalSha256": "d7bbb1985c1b69ede8408d1388c7d0b22f2cb17a2426aef7aab9707b995a48f0",
      "sanitizedSha256": "7fe9770b1b02d229394e5c6200934a27d7bc13d689bd63b561a9528411f6fbd6",
      "jwt": 1,
      "queryToken": 0,
      "bearer": 0
    },
    {
      "path": "153-note-archived-reload.json",
      "originalSha256": "bf628d5ad5a293133804d7885ec33d5c66ad8ae5f6e13169fd79131036328ef0",
      "sanitizedSha256": "dbf052ac8d3ed41053e524f9d83d8e1682ad7da78463270596585cf3e722c317",
      "jwt": 1,
      "queryToken": 0,
      "bearer": 0
    }
  ]
}
