Preparation attempts preserved separately from product credit:

- dashboard-operate-payload.json initially contains only the native receipt: evaluate_script normalized the requested .txt to .json, colliding with redirected stdout. The corrected data and receipt use different filenames.
- dashboard-operate-payload-data.json requested invalidation11 and returned no Rating chunks. dashboard-response-shapes.json shows the Dashboard/layout nodes skipped. Corrected full invalidation1111 supplies the actual authorized Dashboard chunks.
- The first offline Excel comparison used presentation headers as raw keys and failed TypeError reading undefined id.localeCompare. It did not mutate source or artifacts. Raw headers were inspected; corrected analysis translates the actual20 header spellings to snake-case and uses data_exports.org_id. Its terminal and full expected/observed comparison are separate.
