import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';

const [directory] = process.argv.slice(2);
const headers = ['Name', 'Rank', 'MOS', 'Duty Role', 'Group', 'Verification Required Training', 'Verification Targeted Training'];
const able = ['Able, Synthetic', 'SPC', '68W', 'Medic', 'Alpha', 'Current (2027-09-26)', 'Not Done'];
const expected = [
  { file: 'full-small-roster-mouse.xlsx', sha: '8bb41a2b5fb43697d2210b37afbcda8ca31e8ae6ba3aabc95748e88e807ac9ff', proof: 'Visible mouse download', headers,
    rows: [able, ['Baker, Synthetic', 'SPC', '11B', 'NCO', 'Bravo', 'Not Done', 'N/A'], ['Unassigned, Synthetic', 'SPC', '68W', 'NCO', null, 'Not Done', 'N/A']] },
  { file: 'alpha-required-keyboard.xlsx', sha: 'ae4753b00842fbad0662edeb8773cb0db9e860dfc7d79f8191fcfc01bb7b3270', proof: 'Visible keyboard download', headers: headers.slice(0, 6), rows: [able.slice(0, 6)] },
  { file: 'api-rosterScoped-bravo.xlsx', sha: 'e5affc627daa1490d9de06d60744e4932f1ba0bf4f555493913cc057c7381114', proof: 'Direct API export of empty Bravo scope', headers, rows: [] },
  { file: 'api-rosterScoped-unfiltered.xlsx', sha: '96a6db452cc9576fa6b77565216c6ec6ae0c6c2d77749a6301f7f80e883677a9', proof: 'Direct API export of Alpha-only actor scope', headers, rows: [able] },
  { file: 'api-trainingEmpty-unfiltered.xlsx', sha: '43b1043259f6ec9a371f3989ceba6a0ac59a9b8f23e6692b9f9e6e02217c7e2e', proof: 'Direct API export of empty actor scope', headers, rows: [] }
];
const observed = [];
for (const item of expected) {
  const bytes = await fs.readFile(`${directory}/downloads/${item.file}`);
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), item.sha);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(bytes);
  assert.deepEqual(workbook.worksheets.map((sheet) => sheet.name), ['Training Report']);
  const sheet = workbook.worksheets[0];
  const rows = Array.from({ length: sheet.rowCount }, (_, index) =>
    Array.from({ length: sheet.columnCount }, (_, column) => sheet.getRow(index + 1).getCell(column + 1).value));
  assert.deepEqual(rows, [item.headers, ...item.rows]);
  observed.push({ file: item.file, source: item.proof, bytes: bytes.length, sha256: item.sha, sheet: sheet.name, headers: rows[0], rows: rows.slice(1) });
}
process.stdout.write(JSON.stringify({ status: 'PASS', proof: 'Offline artifact inspection, not independent browser execution', observed }, null, 2) + '\n');
