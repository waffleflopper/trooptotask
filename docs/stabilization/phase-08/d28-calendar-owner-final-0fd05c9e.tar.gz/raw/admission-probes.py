import pathlib,json,sys,subprocess
r=pathlib.Path(__file__).resolve().parent;fixture=json.loads((r/'010-fixture.out').read_text());ids=fixture['ids'];label,page,mode,*targets=sys.argv[1:];q=[]
def req(method,path,body=None):q.append({'method':method,'path':path,'body':body})
if mode=='range':
 for org in targets:req('GET',f'/org/{ids[org]}/api/calendar-range?rangeStart=2026-09-14&rangeEnd=2026-09-16')
elif mode=='deny':
 for person in targets:
  org='orgB' if person=='personForeign' else 'orgA';status='statusForeign' if org=='orgB' else 'statusLeave';body={'personnelId':ids[person],'statusTypeId':ids[status],'startDate':'2026-09-14','endDate':'2026-09-14','note':label+'-'+person}
  req('POST',f'/org/{ids[org]}/api/availability',body);req('POST',f'/org/{ids[org]}/api/availability/batch',{'records':[body]})
elif mode=='foreign-status':
 body={'personnelId':ids['personA'],'statusTypeId':ids['statusForeign'],'startDate':'2026-09-14','endDate':'2026-09-14','note':label};req('POST',f'/org/{ids["orgA"]}/api/availability',body);req('POST',f'/org/{ids["orgA"]}/api/availability/batch',{'records':[body]})
elif mode=='classification':
 for name in ['availabilityForeign','00000000-0000-4000-8000-000000000001']:
  id=ids.get(name,name);req('PUT',f'/org/{ids["orgA"]}/api/availability',{'id':id,'statusTypeId':ids['statusLeave'],'startDate':'2026-09-14','endDate':'2026-09-14','note':label})
 req('PUT',f'/org/{ids["orgA"]}/api/availability',{'id':ids['availabilityAlpha'],'personnelId':ids['personB'],'statusTypeId':ids['statusLeave'],'startDate':'2026-09-14','endDate':'2026-09-14','note':label})
else:raise ValueError(mode)
fn='async () => { const results=[]; for (const request of '+json.dumps(q)+') {const options={method:request.method};if(request.body!==null){options.headers={"Content-Type":"application/json"};options.body=JSON.stringify(request.body)}const response=await fetch(request.path,options);results.push({submitted:request,status:response.status,body:await response.text()});} return results;}'
subprocess.run(['python3',str(r/'drive-v2.py'),label,'eval',page,fn],check=True)
