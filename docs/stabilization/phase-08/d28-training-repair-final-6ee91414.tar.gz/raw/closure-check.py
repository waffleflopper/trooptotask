import datetime,json,pathlib,socket,subprocess,hashlib,re
p=pathlib.Path(__file__).resolve().parent
root=p.parents[3]
def read(n):return json.loads((p/n).read_text())
def run(args):return subprocess.check_output(args,text=True).strip()
def dump(n,x):(p/n).write_text(json.dumps(x,indent=2)+'\n')
own=read('owned-environment-identity.json');session=read('owned-session-identity.json');pre=read('resources-before.json');proc=read('owned-process-identities-preclosure.json');mounts=read('owned-container-mount-network-identities.json')
ids=run(['docker','ps','-aq','--no-trunc']).splitlines();containers=[]
if ids:
 containers=[json.loads(x) for x in run(['docker','inspect','--format','{"id":{{json .Id}},"name":{{json .Name}},"state":{{json .State.Status}},"networks":{{json .NetworkSettings.Networks}},"mounts":{{json .Mounts}}}',*ids]).splitlines()]
networks=[json.loads(x) for x in run(['docker','network','ls','--no-trunc','--format','{{json .}}']).splitlines()]
volumes=[json.loads(x) for x in run(['docker','volume','ls','--format','{{json .}}']).splitlines()]
dump('resources-after.json',{'containers':containers,'networks':networks,'volumes':volumes})
checks=[]
for old in proc['processes']:
 q=pathlib.Path('/proc')/str(old['pid'])/'stat';present=q.exists();start=None
 if present:
  stat=q.read_text();start=stat[stat.rfind(')')+2:].split()[19]
 checks.append({'pid':old['pid'],'originalStart':old['start'],'present':present,'actualStart':start,'originalProcessAbsent':not present or start!=old['start']})
ports=read('bound-sockets-preclosure.json')['ports'];portchecks=[]
for port in ports:
 with socket.socket() as s:
  s.settimeout(.3);result=s.connect_ex(('127.0.0.1',port))
 portchecks.append({'port':port,'connectResult':result,'refused':result==111})
ss=run(['ss','-lntp']);socketlines=[l for l in ss.splitlines() if any(re.search(r':'+str(port)+r'\b',l) for port in ports)]
ownednames={x['name'] for x in mounts};ownednet={k for x in mounts for k in x['networks']};ownedvol={m['Name'] for x in mounts for m in x['mounts'] if m['Type']=='volume'}
cb={x['id']:x for x in containers};nb={x['ID']:x for x in networks};vb={x['Name']:x for x in volumes}
def canonical_container(x):
 if x is None:return None
 return {**x,'mounts':sorted(x['mounts'],key=lambda m:(m['Destination'],m['Source']))}
pc=[{'id':x['id'],'name':x['name'],'state':x['state'],'exact':canonical_container(cb.get(x['id']))==canonical_container(x)} for x in pre['containers']]
pn=[{'id':x['ID'],'name':x['Name'],'exact':nb.get(x['ID'])==x} for x in pre['networks']]
pv=[{'name':x['Name'],'exact':vb.get(x['Name'])==x} for x in pre['volumes']]
x={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'supportedCleanup':read('cleanup-final.json'),'processes':checks,'ports':portchecks,'socketLines':socketlines,'ownedContainersAbsent':all(x not in cb for x in own['container_ids']),'ownedContainerNamesAbsent':not ownednames.intersection(x['name'] for x in containers),'ownedNetworksAbsent':not ownednet.intersection(n['Name'] for n in networks),'ownedVolumesAbsent':not ownedvol.intersection(vb),'ownedWorkerDirectoryAbsent':not pathlib.Path(own['session']).exists(),'preexistingContainers':pc,'preexistingNetworks':pn,'preexistingVolumes':pv}
x['PASS']=all(c['originalProcessAbsent'] for c in checks) and all(c['refused'] for c in portchecks) and not socketlines and all(x[k] for k in ['ownedContainersAbsent','ownedContainerNamesAbsent','ownedNetworksAbsent','ownedVolumesAbsent','ownedWorkerDirectoryAbsent']) and all(c['exact'] for c in pc+pn+pv)
dump('actual-closure.json',x)
f=read('freeze-before.json');files=run(['git','ls-files','-z','--cached','--others','--exclude-standard']).split('\0');names={n for n in files if n and (root/n).is_file()};changed=[n for n,h in f['files'].items() if not (root/n).is_file() or hashlib.sha256((root/n).read_bytes()).hexdigest()!=h]
z={'changed':changed,'fileSetExact':names==set(f['files']),'inputCount':len(f['files']),'head':run(['git','rev-parse','HEAD']),'tree':run(['git','rev-parse','HEAD^{tree}']),'status':run(['git','status','--short'])};z['PASS']=not changed and z['fileSetExact'] and z['head']==f['head'] and z['tree']==f['tree'] and z['status']==f['status'];dump('freeze-after-cleanup.json',z)
print(json.dumps({'closurePASS':x['PASS'],'freezePASS':z['PASS'],'processes':len(checks),'ports':len(portchecks),'containers':len(mounts),'networks':len(ownednet),'volumes':len(ownedvol),'preexistingCounts':[len(pc),len(pn),len(pv)]}))
