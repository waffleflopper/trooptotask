window.__STATES = {
	ordinary: '',
	view: 'view=d5faffe6-67c1-4368-80ef-b4ac185757f9',
	mixed: 'view=d5faffe6-67c1-4368-80ef-b4ac185757f9&role=BriefingBoundaryacde5f6c',
	cliff: 'types=41a31da3-0f38-46e8-9df1-c491537aaf00',
	finalbucket: 'role=BriefingBoundaryacde5f6c&types=b4f06d13-e268-4e4d-b4e7-586eeb6b9816',
	flat100: 'role=Medic&types=75fb00cb-e32b-4ed3-b439-6d638e9514b3',
	nearEnd: 'mos=68W&role=BriefingBoundaryacde5f6c&types=f0f77e42-bf0d-4dc2-a3b0-a8edc7c0d120',
	atGoal: 'types=f6db63c5-b5f2-4742-abaa-337f5a0f72c7'
};
window.__go = async (qs) => {
	const a = document.createElement('a');
	a.href = location.pathname + (qs ? '?' + qs : '');
	a.setAttribute('data-drv', 'nav');
	document.body.appendChild(a);
	a.click();
	a.remove();
	await window.__wait(() => location.search === (qs ? '?' + qs : '') && window.__settled(), 10000);
	await new Promise((r) => setTimeout(r, 300));
};
window.__all = async (names) => {
	const rows = [];
	for (const n of names) {
		try {
			await window.__go(window.__STATES[n]);
			rows.push(...(await window.__sweep(n)));
		} catch (e) {
			rows.push({ state: n, error: String(e) });
		}
	}
	return rows;
};
