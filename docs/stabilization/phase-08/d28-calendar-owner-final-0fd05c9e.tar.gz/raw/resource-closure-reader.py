import pathlib,json,os,datetime,socket,shutil,sys,subprocess
r=pathlib.Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
worker=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/27bc5b973581bdf4/worker-1')
ready=json.loads((r/'owned-ready-session-projection.json').read_text());env=json.loads((r/'owned-environment-projection.json').read_text())
def process(pid):
 p=pathlib.Path('/proc')/str(pid)
 try:
  s=(p/'stat').read_text().split(') ',1)[1].split();return {'pid':pid,'state':s[0],'group':int(s[2]),'start':s[19]}
 except FileNotFoundError:return None
if sys.argv[1]=='before':
 saved={k:ready[k] for k in ['supervisor','appProcess','mcpProcess','browserProcess']}
 groups={x['group'] for x in saved.values()};members=[]
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  x=process(int(p.name))
  if not x:continue
  try:boundProfile=str(worker).encode() in (p/'cmdline').read_bytes()
  except FileNotFoundError:boundProfile=False
  if x['group'] in groups or boundProfile:members.append(x)
 obj={'timestamp':now(),'worker':str(worker),'exists':worker.exists(),'processes':members,'savedIdentities':saved,'providerProject':env['project'],'ownedPorts':sorted(set([37063,33341,*env['ports'].values()]))}
 (r/'resource-before-cleanup.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({'ownedProcesses':len(members),'workerExists':worker.exists(),'ownedPorts':obj['ownedPorts']}));sys.exit(0)
before=json.loads((r/'resource-before-cleanup.json').read_text());obj={'timestamp':now(),'worker':str(worker),'workerAbsent':not worker.exists(),'processes':[],'ports':[]}
for p in before['processes']:
 actual=process(p['pid']);obj['processes'].append({'before':p,'actual':actual,'ownedIdentityAbsent':actual is None or actual['start']!=p['start'],'procAbsent':actual is None})
for port in before['ownedPorts']:
 with socket.socket() as s:
  s.settimeout(1);e=s.connect_ex(('127.0.0.1',port));obj['ports'].append({'port':port,'connectError':e,'connectionRefused':e==111})
b=lambda f:[json.loads(x) for x in (r/f).read_text().splitlines() if x.strip()]
old=b('005-docker.out');running=b('closure-docker-running.out');allc=b('closure-docker-all.out');oldids={(x['ID'],x['Names']) for x in old};newids={(x['ID'],x['Names'])for x in running}
obj['containers']={'preExistingRunningUnchanged':oldids==newids,'missing':sorted(oldids-newids),'new':sorted(newids-oldids),'ownedProjectRemaining':[{'id':x['ID'],'name':x['Names'],'state':x['State']}for x in allc if before['providerProject'] in x.get('Labels','') or before['providerProject'] in x.get('Names','')]}
obj['resourceClosed']=obj['workerAbsent']and all(x['ownedIdentityAbsent']for x in obj['processes'])and all(x['connectionRefused']for x in obj['ports'])and obj['containers']['preExistingRunningUnchanged']and not obj['containers']['ownedProjectRemaining']
(r/'resource-closure.json').write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps({k:v for k,v in obj.items() if k not in ['processes','ports']}));assert obj['resourceClosed'], 'Resource closure failed; temporary directory retained'
tmp=json.loads((r/'tmp-binding.json').read_text())['path'];assert tmp=='/tmp/t2c-c9mqzeu2';tp=pathlib.Path(tmp);assert not tp.is_symlink()and tp.is_dir();st=tp.stat();assert st.st_uid==os.getuid()and st.st_mode&0o777==0o700
shutil.rmtree(tp);end={'timestamp':now(),'path':tmp,'removedAfterResourceClosure':True,'absent':not tp.exists()};(r/'tmp-closure.json').write_text(json.dumps(end,indent=2)+'\n');print(json.dumps(end));assert end['absent']
