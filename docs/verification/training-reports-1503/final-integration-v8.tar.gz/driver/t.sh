# source me: T LABEL TOOL JSON ; H LABEL helper-args...
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-integration-v8/driver; D=$E/d.sh; cd $ROOT
T() { local l=$1; shift; $D "$l" -- npm run --silent verify:app -- tool "$@" --worker 1; }
H() { local l=$1; shift; $D "$l" -- node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1 "$@"; }
# S LABEL -> snapshot file path in $SNAP
S() { SNAP=$E/snap/$1.txt; T "snap-$1" take_snapshot "{\"pageId\":2,\"filePath\":\"$SNAP\"}" >/dev/null; }
# C LABEL GREP-PATTERN : fresh snapshot, click first match
C() { S "$1-pre"; local uid; uid=$(grep -m1 -E "$2" "$SNAP" | sed -E 's/^ *uid=([0-9_]+).*/\1/'); [ -n "$uid" ] || { echo "NO MATCH $2"; return 1; }; echo "click $uid: $(grep -m1 -E "$2" "$SNAP" | sed 's/^ *//')"; T "click-$1" click "{\"pageId\":2,\"uid\":\"$uid\"}" | grep -o 'Successfully[^"\\]*\|Error[^"\\]*' ; }
P() { T "shot-$1" take_screenshot "{\"pageId\":2,\"filePath\":\"$E/png/$1.png\"${2:+,$2}}" | grep -o 'Took[^"\\]*\|Saved[^"\\]*\|Error[^"\\]*'; }
