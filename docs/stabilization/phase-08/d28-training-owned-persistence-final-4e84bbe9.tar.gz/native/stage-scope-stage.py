import sys,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent));import native_driver as d
rp=pathlib.Path(__file__).parent/'runtime.json';s=json.loads(rp.read_text());ids=s['fixture']['ids'];temp=s['temporaryIds'];temp['alphaRecord']='aa1c68c8-7873-441c-bd63-b843332c2b0a';rp.write_text(json.dumps(s,indent=2))
def rows(label):
 for org in ['orgA','orgB']:
  for table in ['personnel_trainings','training_types']:d.call(label+'-'+org+'-'+table,['rows',table,org],True)
def request(label,page,org,method,suffix,body=None):
 path='/org/'+org+'/api/'+suffix
 fn='async()=>{const path='+json.dumps(path)+',method='+json.dumps(method)+',body='+json.dumps(body)+';const r=await fetch(path,{method,headers:body?{"Content-Type":"application/json"}:{},...(body?{body:JSON.stringify(body)}:{})});return {path,method,body,status:r.status,response:await r.text()}}'
 value=d.result_value(d.evaluate(label,fn,page));assert value['status'] in [403,404],value
 return value
rows('denial-before')
results=[]
results.append(request('scope-other-put',5,ids['orgA'],'PUT','personnel-trainings',{'id':temp['datedRecord'],'notes':'DENIED other group'}))
results.append(request('scope-other-delete',5,ids['orgA'],'DELETE','personnel-trainings',{'id':temp['datedRecord']}))
results.append(request('scope-mixed-denial',5,ids['orgA'],'POST','personnel-trainings/batch',{'records':[{'personnelId':ids[p],'trainingTypeId':temp['annual'],'completionDate':'2026-10-06','status':'completed','notes':'DENIED mixed scope'} for p in ['personA','personB']]}))
a=d.call('none-actor',['actor','viewer','training'],True);s['nonePage']=a['pageId'];rp.write_text(json.dumps(s,indent=2));d.snap('none-route',a['pageId']);d.shot('none-route',a['pageId'])
results.append(request('none-report-read',a['pageId'],ids['orgA'],'GET','training-reports'))
results.append(request('none-create-denial',a['pageId'],ids['orgA'],'POST','personnel-trainings',{'personnelId':ids['personUnassigned'],'trainingTypeId':temp['annual'],'completionDate':'2026-10-07'}))
results.append(request('none-patch-denial',a['pageId'],ids['orgA'],'PUT','personnel-trainings',{'id':temp['alphaRecord'],'notes':'DENIED no training'}))
results.append(request('none-batch-denial',a['pageId'],ids['orgA'],'POST','personnel-trainings/batch',{'records':[{'personnelId':ids['personA'],'trainingTypeId':temp['annual'],'completionDate':'2026-10-06','status':'completed'}]}))
f=d.call('foreign-actor',['actor','trainingForeign','training'],True);s['foreignPage']=f['pageId'];rp.write_text(json.dumps(s,indent=2));d.snap('foreign-route',f['pageId']);d.shot('foreign-route',f['pageId'])
results.append(request('foreign-id-put-denial',f['pageId'],ids['orgB'],'PUT','personnel-trainings',{'id':temp['datedRecord'],'notes':'DENIED foreign id'}))
results.append(request('foreign-person-create-denial',f['pageId'],ids['orgB'],'POST','personnel-trainings',{'personnelId':ids['personA'],'trainingTypeId':temp['annual'],'completionDate':'2026-10-07'}))
rows('denial-after')
def read(n):return json.loads(json.loads((d.E/(n+'.json')).read_text())['stdout'])
for org in ['orgA','orgB']:
 for table in ['personnel_trainings','training_types']:
  assert read('denial-before-'+org+'-'+table)['rows']==read('denial-after-'+org+'-'+table)['rows'],(org,table)
(d.E/'denial-comparison.json').write_text(json.dumps({'status':'PASS','kind':'authenticated HTTP separately from native positive/UI','requests':results,'fullRowsUnchanged':['orgA/personnel_trainings','orgB/personnel_trainings','orgA/training_types','orgB/training_types']},indent=2))
