#!/bin/bash
# t.sh NAME TOOL JSON
n=$1; t=$2; j=$3
/tmp/v5r.sh "$n" npm run --silent verify:app -- tool "$t" "$j" --worker 1
