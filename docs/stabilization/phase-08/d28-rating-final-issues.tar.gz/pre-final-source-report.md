# D28 Rating private source checkpoint

Status is READY FOR ROOT REVIEW. The private source cutover is complete in `/home/waffleflops/.cache/t2t-1376-rating-owner`, based on `51e4a9eb78ac4541b1a323dfbceeb9f3f36523cc`. There is no commit, push, PR, merge, migration or database operation. Root supplied the public contract, exports, central/reverse wiring, test factory injection, wrapper and module manifest; those remain root-owned. Heavy work is paused.

## Source result

`ratingSchemePersistence.server.ts` captures the request-authenticated Supabase client and Organization. Seven fixed methods own workspace, write reference, Person readiness, estimated count, create, update and delete. Workspace uses complete end/id ascending pages; readiness uses complete end/id descending pages and its five-field projection. Reference uses its five-field projection, `.single()` and only PGRST116-to-null. Count retains id/estimated/range0..0/null-to-zero. No added Personnel read, privileged client, query option, arbitrary table input or response-row spread exists in the production owner ports.

`ratingSchemeEntryMapping.server.ts` replaces the generic entity with the unchanged input validation and explicit provider/domain mapping. The saved projection contains exactly20 supported fields, including readonly `organization_id`, `created_at` and `updated_at` with exact timestamp strings. Create optional values default to null; patch retains omitted versus explicit-null values and excludes protected fields. Accepted nullable string report/workflow inputs remain accepted. Empty strings in required Person/date fields and optional strings map to provider null after existing validation, preserving provider rejection rather than adding validation. The row type is private and fixed; it has no unknown-column index signature or generic bag-to-domain cast.

Entry operations, workspace, readiness, read count and approved deletion consume domain `ratingScheme` methods. Policy, all four evaluator rules, case-insensitive unchanged historical links, audit and notification order remain. Empty evaluator IDs are treated as clears before reference validation. Approved deletion uses the bound ordinary factory delete after review policy and pending-request binding. It preserves idempotence and DELETE204 zero-effect behavior under ordinary RLS; it does not add affected-row acknowledgment or atomic coordinator claims.

The private memory factory uses the actual shared memory store and maps fixed domain values. Its deleteWhere implementation supplies the ordinary idempotent delete contract. Root's supplied test-support wrapper injects this factory through the central ratingSchemeFactory option. Production exports do not expose this fake.

Replaced `ratingSchemeEntryEntity.server.ts`, its test file, `ratingSchemeEntryPorts.server.ts` and `ratingSchemeReadPorts.server.ts` are deleted. No old names remain in src. The old validation behavior is now independently covered through exported operation schemas and SDK requests/results; retained operation/workspace/readiness/count/approved-effect tests continue through owned dependencies. Dashboard due and raw Organization export projection/orchestration were not changed. Only the same-file count signature changed in the latter owner source.

The exclusive private diff has19 paths, including5 new files and4 deletions. `.verification/evidence/d28-rating-source-checkpoint/owned-source.patch` and `owned-source-manifest.json` capture exact current private bytes and deletion facts, excluding root's wrapper/shared work. Root may inspect/copy these files and delete the listed obsolete paths. Baseline artifacts remain untouched and identify their original tested candidate.

## Actual checks

The first SDK/schema/count selection passes3 files/33tests. The complete Rating server selection passes9 files/96tests. SDK checks use the installed client against controlled unreachable REST replies and assert ordinary supplied authority, exact20-field mapping/timestamps, fixed projections, complete1001-row/tied-date ordering, readiness scope/order/projection, first/later page rejection, PGRST116 classification, estimated count, create defaults/protected-field exclusion, nullable string codes, omitted/null patch behavior, required-empty provider rejection, failed writes/missing update, idempotent ordinary delete and revoked-RLS simulated zero effects. These are SDK/query tests, not live provider enforcement. The retained actual database/browser provenance and later integrated native proof remain distinct.

Targeted Prettier and ESLint passed the owned present files; git diff --check passes. Integrated `npm run check` initially found1 error/0warnings in a new test's inferred response-header union. An explicit Record<string,string> annotation corrected that test-only type; the same check now passes0errors/0warnings. Runtime output and assertions did not change, so the96-test result applies to the erased annotation. Both type-check attempts are preserved. Prettier/lint ran before this annotation and are not relabelled later executions.

Every npm/node check used Node24.21.0/npm11.19.0 in the explicit isolated checkout. Type checking used these documented synthetic offline overrides exactly: PUBLIC_SUPABASE_URL=http://127.0.0.1:9, PUBLIC_SUPABASE_ANON_KEY=synthetic-anon-key, SUPABASE_SERVICE_ROLE_KEY=synthetic-service-role-key. No actual credentials or provider connection were used. Check logs and exact statuses are in `.verification/evidence/d28-rating-source-checkpoint/`.

Full suite, full production build, final native run, complete independent source/artifact acceptance and PR review/CI/merge gates are UNRUN/PENDING at this checkpoint. Root owns reverse tests and final integration. No source-review bot or independent comment review is self-certified. Root can begin inspection now; Calendar has the heavy slot after the completed type check. The next authorized step for this worker is coordinator-directed final verification after integration review.

## Exact private path list

| Status | Path |
| --- | --- |
| modified | `src/features/rating-scheme/server/approvedRatingSchemeDeletion.server.test.ts` |
| modified | `src/features/rating-scheme/server/approvedRatingSchemeDeletion.server.ts` |
| added | `src/features/rating-scheme/server/inMemoryRatingSchemePersistence.server.ts` |
| modified | `src/features/rating-scheme/server/personnelRatingSchemeReadiness.server.test.ts` |
| modified | `src/features/rating-scheme/server/personnelRatingSchemeReadiness.server.ts` |
| deleted | `src/features/rating-scheme/server/ratingSchemeEntryEntity.server.test.ts` |
| deleted | `src/features/rating-scheme/server/ratingSchemeEntryEntity.server.ts` |
| added | `src/features/rating-scheme/server/ratingSchemeEntryMapping.server.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeEntryOperations.server.test.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeEntryOperations.server.ts` |
| deleted | `src/features/rating-scheme/server/ratingSchemeEntryPorts.server.ts` |
| added | `src/features/rating-scheme/server/ratingSchemeEntryValidation.server.test.ts` |
| added | `src/features/rating-scheme/server/ratingSchemePersistence.server.test.ts` |
| added | `src/features/rating-scheme/server/ratingSchemePersistence.server.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeRead.server.test.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeRead.server.ts` |
| deleted | `src/features/rating-scheme/server/ratingSchemeReadPorts.server.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeWorkspaceQuery.server.test.ts` |
| modified | `src/features/rating-scheme/server/ratingSchemeWorkspaceQuery.server.ts` |

The checked owner-server test scope contains these nine files.

- `src/features/rating-scheme/server/approvedRatingSchemeDeletion.server.test.ts`
- `src/features/rating-scheme/server/personnelRatingSchemeReadiness.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemeEntryOperations.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemeEntryValidation.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemeExportRead.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemePersistence.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemeRead.server.test.ts`
- `src/features/rating-scheme/server/ratingSchemeWorkspaceQuery.server.test.ts`
- `src/features/rating-scheme/server/supportReadProvider.server.test.ts`

Executed focused command was `npm run test -- src/features/rating-scheme/server --maxWorkers=2`. Earlier bounded command selected `ratingSchemePersistence.server.test.ts`, `ratingSchemeEntryValidation.server.test.ts` and `ratingSchemeRead.server.test.ts`, also with maxWorkers2. Integrated types used `npm run check`. Targeted formatter/linter selected modified and newly added present private server files, excluding the root-owned wrapper. Git removal inspection searched all of `src` for RatingSchemeEntryEntity, ratingSchemeEntryEntity, ratingSchemeEntryPorts and ratingSchemeReadPorts and returned zero hits. Private test-support memory operations remain intentional; production operation/workspace/readiness/count/approved-effect consumers contain no generic store methods.
