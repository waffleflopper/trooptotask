#!/usr/bin/env bash
# usage: print.sh PREFIX NAME (uses $P) -> arm, native click Print brief, state BEFORE save, save exact current URL, restore
E=.verification/evidence/verify-trooptotask/1504-final-v4/accept
p=$1; n=$2
[ -e $E/pdf/$n.pdf ] && { echo "REFUSED pdf exists"; exit 1; }
$E/v.sh "$p-a-print-arm" "print arm ($n)" print arm $P | tr -d '\n ' | head -c 200; echo
$E/snap.sh "$p-b-pre-print" >/dev/null
U=$(grep 'button "Print brief"' $E/snaps/$p-b-pre-print.txt | head -1 | grep -o 'uid=[0-9_]*' | cut -d= -f2)
MAXOUT=120 $E/t.sh "$p-c-click-print" "native click Print brief ($n)" click "{\"pageId\":$P,\"uid\":\"$U\"}" | tr -d '\n'; echo
MAXOUT=800 $E/v.sh "$p-d-print-state" "print state BEFORE save ($n)" print state $P | tr -d '\n '; echo
$E/t.sh "$p-e-list-pages" "native list_pages for exact URL ($n)" list_pages '{}' >/dev/null
URL=$(python3 -c "import json,sys;t=open(sys.argv[1]).read();d=json.loads(t[t.find('{'):]);print([x['url'] for x in d['structuredContent']['pages'] if x['id']==int(sys.argv[2])][0])" $E/receipts/$p-e-list-pages.stdout $P)
echo "URL=$URL"
MAXOUT=1500 $E/v.sh "$p-f-print-save" "print save exact current URL ($n)" print save $P "$URL" $E/pdf/$n.pdf | tr -d '\n'; echo
$E/v.sh "$p-g-print-restore" "print restore ($n)" print restore $P | tr -d '\n ' | head -c 200; echo
