"""Fixed rollback-only CHECK semantics probe on this run's verified disposable DB.
This is privileged provider proof, not ordinary authorization or native interaction.
"""
import json
from pathlib import Path
from scripts.verification.environment import (
    private_session, ReviewFailureDatabase, review_failure_receipt,
    check_review_failure_constraints, canonical_uuid,
)

session = private_session('/home/waffleflops/.local/state/trooptotask-verification/c4eec7e87409ed9d/worker-1')
database = ReviewFailureDatabase(session)
control = review_failure_receipt(session, database)
assert control and control['phase'] == 'armed'
request_id = canonical_uuid(control['request_id'])
sibling_id = canonical_uuid('9ace8e77-1fe2-4caa-92df-0295e25c6772')
before = database.snapshot(request_id)
assert check_review_failure_constraints(before, control)
assert before['request']['status'] == 'pending'
output = database._execute(f"""
 BEGIN;
 SET LOCAL statement_timeout = '10s';
 SET LOCAL lock_timeout = '5s';
 DO $probe$
 DECLARE rejected boolean := false; failed_constraint text; code text;
 BEGIN
   BEGIN
     UPDATE public.deletion_requests SET status = 'approved' WHERE id = '{request_id}'::uuid;
   EXCEPTION WHEN check_violation THEN
     GET STACKED DIAGNOSTICS failed_constraint = CONSTRAINT_NAME, code = RETURNED_SQLSTATE;
     IF failed_constraint <> '{control['constraint']}' OR code <> '23514' THEN
       RAISE EXCEPTION 'Unexpected approval rejection';
     END IF;
     rejected := true;
   END;
   IF NOT rejected THEN RAISE EXCEPTION 'Target approval was not rejected'; END IF;
   UPDATE public.deletion_requests SET status = 'denied' WHERE id = '{request_id}'::uuid;
   IF NOT FOUND THEN RAISE EXCEPTION 'Denied probe did not target one saved request'; END IF;
   UPDATE public.deletion_requests SET status = 'cancelled' WHERE id = '{request_id}'::uuid;
   IF NOT FOUND THEN RAISE EXCEPTION 'Cancelled probe did not target one saved request'; END IF;
   UPDATE public.deletion_requests SET status = 'approved' WHERE id = '{sibling_id}'::uuid;
   IF NOT FOUND THEN RAISE EXCEPTION 'Sibling probe did not target one saved request'; END IF;
 END $probe$;
 SELECT json_build_object(
   'targetDeniedAllowed', true, 'targetCancelledAllowed',
   (SELECT status = 'cancelled' FROM public.deletion_requests WHERE id = '{request_id}'::uuid),
   'siblingApprovedAllowed',
   (SELECT status = 'approved' FROM public.deletion_requests WHERE id = '{sibling_id}'::uuid),
   'targetApprovedRejectedCode', '23514');
 ROLLBACK;
""")
result = json.loads(output)
assert result['targetCancelledAllowed'] and result['siblingApprovedAllowed']
after = database.snapshot(request_id)
assert after == before, 'The rollback-only probe changed saved target/constraint state'
print(json.dumps({'boundary': 'Privileged owned CHECK semantics; no ordinary authorization or source effect claim',
                  'before': before, 'observed': result, 'after': after, 'rollbackPreserved': True}, indent=2))
