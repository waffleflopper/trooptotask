import json,subprocess,socket,os,shutil
from pathlib import Path
from urllib.parse import urlsplit
from flow import base
allocation=json.loads((base/'start-allocation.json').read_text());processes=json.loads((base/'owned-processes-before-disposal.json').read_text());endpoint=json.loads((base/'owned-docker-endpoint.json').read_text())['endpoint'];assert endpoint.startswith('unix:///')
environment=os.environ.copy()
for key in ['DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:environment.pop(key,None)
environment['DOCKER_HOST']=endpoint
project=allocation['project'];resources={}
commands={'container':['docker','ps','--all','--filter','label=com.supabase.cli.project='+project,'--format','{{.ID}} {{.Names}}'],'volume':['docker','volume','ls','--filter','label=com.supabase.cli.project='+project,'--format','{{.Name}}'],'namedVolume':['docker','volume','ls','--filter','name='+project,'--format','{{.Name}}']}
for key,cmd in commands.items():
 p=subprocess.run(cmd,capture_output=True,text=True,env=environment);resources[key]={'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};assert p.returncode==0 and p.stdout.strip()==''
ports={}
for port in [urlsplit(allocation['appOrigin']).port,*allocation['providerPorts'].values()]:
 with socket.socket() as s:s.settimeout(.5);code=s.connect_ex(('127.0.0.1',port))
 ports[str(port)]={'connectExit':code};assert code!=0
assert len(ports)==9
processStatus={}
for key,before in processes.items():
 if not before.get('pid'):continue
 path=Path('/proc')/str(before['pid'])/'stat'
 if path.exists():
  rest=path.read_text().rsplit(') ',1)[1].split();state,start=rest[0],rest[19];same=str(before.get('start'))==start
  processStatus[key]={'pid':before['pid'],'recordedStart':before.get('start'),'currentStart':start,'state':state,'sameOwnedIdentityAlive':same and state not in ['Z','X']};assert not processStatus[key]['sameOwnedIdentityAlive']
 else:processStatus[key]={'pid':before['pid'],'recordedStart':before.get('start'),'absent':True}
session=Path(allocation['session']);assert not session.exists()
tmp=Path(allocation['tmpdir']);assert str(tmp)=='/home/waffleflops/.cache/vw1r' and tmp.resolve()==tmp and tmp.parent==Path('/home/waffleflops/.cache') and not tmp.is_symlink() and tmp.stat().st_uid==os.getuid()
entries=sorted(str(p.relative_to(tmp)) for p in tmp.rglob('*'));assert all(p.lstat().st_uid==os.getuid() for p in tmp.rglob('*'))
shutil.rmtree(tmp);assert not tmp.exists()
record={'status':'OWNED_DISPOSAL_PASS','project':project,'localDockerEndpoint':endpoint,'resources':resources,'ports':ports,'privateSessionAbsent':True,'ownedProcessIdentities':processStatus,'tmpdir':{'path':str(tmp),'newExclusiveTaskDirectory':True,'entriesBeforeRemoval':entries,'absent':True,'guard':'Only recorded new task-specificvw1r removed after maintainedownedcleanup, no matching ownedprocess and exactnineports closed. Pre-existingvw1 and globaltemp untouched.'},'rowCleanup':'Maintained clean-recorded-seeds.json PASS plus all-cleanup-row-check.json literal24collection restoration; finaldoctors PASS before andafter seed cleanup.'}
(base/'independent-disposal.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'project':project,'ninePortsClosed':len(ports),'TMPDIRAbsent':True}))
