# #1504 final v7 owned native acceptance (narrow action/preload round)

Binding: head `8cdd5310cba49fb2782ccd9da0af39ea8b9c5106`, candidate `adab9515aab5c4d0e8c4809125788b137b4c3fc538f581bd9a8eb55a6c01614e`, origin `http://127.0.0.1:38327`, session `175e46b6-bbc7-4ff8-8555-00e0d167c893`, worker 1, Chromium 152.0.7977.82. Doctor PASS before the drive (`drive/001-doctor`) and after it (`drive/189-final-doctor`). Governance stays BLOCKED behind main `49cacc66`. This report is local owned-branch proof only. It does not accept the whole issue or the current-main candidate.

Evidence lives in `.verification/evidence/verify-trooptotask/1504-final-v7/drive/`. There are 210 unique receipts (`NNN-name.json` with argv, exit, start and end, plus `.stdout`/`.stderr`), and the wrapper is saved as `drive-receipt-wrapper.sh`. Every receipt exited 0 with empty stderr except three intentional settle waits (`160-settle`, `163-settle`, `176-settle`). Each of those waited 1.5 to 2 s for a marker that does not exist and exited 2 with "Timed out". They are bounded settle windows, not driver errors. There were no driver errors and no tool repairs.

Every action used native `click`, `hover`, `press_key`, `navigate_page` or `resize_page`. Lines marked "read-only probe" are `evaluate_script` reads of `document.activeElement`, `aria-busy`, checked radios, `[role=status]`/`[role=alert]` and attributes. They never invoke handlers or change state.

## Results

| Path | Result |
| --- | --- |
| 1. Doctor and baseline server paint | PASS |
| 2. Toolbar Clear, held (pointer) plus Tab-away no-steal | PASS |
| 3. Empty-panel Clear, held (Enter) at 1440 and 390 | PASS (visual note V1) |
| 4. Export failure, Enter Retry held, XLSX, pointer Retry plus Tab-away, normal Export | PASS (focus note F1) |
| 5. Focus link hover preload and click detail; reload; active radio Space | PASS (hover AVAILABLE) |
| 6. Restoration and final doctor | PASS |

### 1. Baseline
- `trainingConfigure` signed in through the actor helper (page 2). A native click on the Training `Reports` link loaded the page through `reports/__data.json` (req 139). No `api/training-reports` request ran on load (`007`).
- Bottom line 25% ready today, Ready 1, expired 0, not recorded 3, Lapse 0. Alpha 50%, Required Total 33%, Targeted Total 0% (`006-reports-baseline.txt`).
- Viewport 1905×2053, DPR 1, light theme, sidebar expanded, localStorage held only mode-watcher keys (`004`). Root originals for the 5 A/B tables and preferences were saved before the drive. No helper or UI write happened before the baseline.

### 2. Toolbar Clear
- Native 30 days, then Rows by MOS. URL became `?horizon=30&rowsBy=mos` with legitimate requests 143 and 144. Exactly one `Clear filters` existed, in the header actions outside the briefing (`013`).
- Pointer click on the toolbar Clear while `network arm-hold 2 training-reports` was active (`014`, `015`). While held (`016`, `018`, `019`), the Clear button was removed and focus was on `section#training-briefing` ("Training readiness briefing", tabindex -1) with `aria-busy=true`. Status read "Updating briefing" and the radios already showed 90 days and Group. The URL honestly stayed at the loaded `?horizon=30&rowsBy=mos`.
- Release (`020`). The region kept focus with `aria-busy=false`, the URL returned to canonical `/reports`, and 25%, 1/0/3/0, Alpha 100/0 and Total 33/0 were restored (`022`, `024`). One canonical request, req 145, with no extras (`025`).
- Follow-on (`028`–`040`): recreated 30/MOS, re-armed the hold and clicked Clear. The region was focused while held. A native Tab while held moved focus to the "MOS" radio (`035`), and after release focus stayed on MOS (`038`, `039`). No focus steal.
- Qualified (existing N1): Tab out of the region lands on the roving "MOS" radio, which is no longer checked. The shared toggle is unchanged.

### 3. Empty-panel Clear (`trainingEmpty`, page 3, no provider writes)
- Default shows "No applicable requirements." with Export Excel disabled. A native 30 days created two Clear buttons. Toolbar 21_0 sat outside the region and panel 21_1 sat inside it (`046`).
- Resized to 1440×900. A native Tab put focus on panel Clear 21_1 (`050`). Hold armed (`053`), then native Enter (`054`).
- While held (`055`, `056`, `057`), both Clear buttons were removed and the region was focused and busy. Status read "Updating briefing" and 90 days was checked.
- Release (`059`). The region kept focus, the URL was `/reports`, and the page showed "No applicable requirements." / "No soldier is required to hold the configured training." No percentage appeared anywhere, and Export Excel stayed disabled (`061`–`064`). One canonical request, 134.
- Repeated at 390×844 (`067`–`083`) with the same focus and busy results and request 136. Screenshots were inspected: `052`/`057`/`064` (1440) and `073`/`077`/`081` (390). The pages are legible, show no truncation and keep the controls reachable.
- Viewport restored to 1905×2053 (`084`). Empty-actor preferences were `[]` before and after (`041`, `086`, identical).
- V1, visual note: the focused briefing region matches `:focus-visible` but its computed `outline-style` is `none` with no box-shadow (`062`), so the region shows no visible focus indicator. This styling pre-exists the round, which made no style change. It is reported, not fixed.

### 4. Export failure, Retry and workbook
- `arm-fail 2 training-reports/export` plus `export arm 2`, then one native pointer click on Export Excel (`088`–`096`). A synthetic 503 produced the alert "Unable to export the workbook / The workbook could not be exported (503). / Retry". No Blob was captured (`095`), and Export Excel kept focus.
- Swapped to `arm-hold` on the same family (`097`, `098`). Nine native Tabs reached Retry (`101`), then native Enter (`102`).
- While held (`103`–`107`), Retry and the alert were unmounted and focus was on the briefing region. The button showed "Exporting..." disabled. Exactly one real `GET api/training-reports/export` returned 200 (req 149) and was held. No Blob was captured yet (`106`).
- Release (`109`). The region kept focus, the alert was gone and normal Export Excel was restored (`111`, `114`). The Blob was captured (`113`).
- Workbook saved as `115-training-report-retry.xlsx`. Filename `training-report-2026-10-04.xlsx`, MIME `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, Content-Disposition attachment, 11763 bytes, SHA-256 `dbf468e122b9e53f318a157d15833518c928fb07af7de0d5f02305d965d77076`.
- Sheets in order: Summary, Forecast, Hot spots, Focus, Requirements (`118-*`).
  - Summary: 25/25%, goal 90, Ready 1, applicable 4, expired 0, not recorded 3, Lapse 0, and all 8 `Filter:` rows on defaults.
  - Forecast: 4 Oct through 2 Jan, with a short final week "28 Dec – 2 Jan".
  - Hot spots: Bravo, Unassigned, Alpha 100/0 (50) and Total 33/0 (25).
  - Focus: the two on-screen sentences and what-ifs.
  - Requirements: exactly Able Targeted, Baker Required and Unassigned Required, all Not Done. Able Required (ready), Optional, N/A and foreign rows are absent.
- Second failure (`119`–`138`): a fresh 503 alert, then a native pointer click on Retry under hold. The region was focused while held. A native Tab moved focus to the "MOS" radio before release, and after the real 200 export focus stayed on MOS (`135`, `137`). Blob 11764 bytes, SHA-256 `99bdd5e7e34cf55b17e25fb40e83897ba04af6f4bea6550ba4ccf1dae159ccf7`. Only `docProps/core.xml` differs from the first workbook.
- Normal Export (`141`–`150`): `arm-observe` plus capture, then a native pointer click. Real 200, Blob 11764 bytes, no error.
- F1, actual focus: focus ended on BODY, both immediately after the click and after settling. The button is `disabled={exporting || …}` while exporting (source unchanged since `3cc4ec4c`), so Chromium drops focus from the disabled button. The handler does not force focus to the region. This is the pre-existing normal-button behavior the round intentionally retained, recorded honestly. In the synthetic-503 case the button kept focus because the failure resolved before dispatch.
- No `data_exports` rows exist for A (`186`, count 0). All controls were restored (`116`, `117`, `139`, `140`, `151`, `152`).

### 5. Focus link preload
- From the defaults, native 30 days then MOS rewrote the URL to `?horizon=30&rowsBy=mos` (requests 152, 153).
- The full request list before hovering ended at req 153 (`157`). Read-only context: both Focus links carry `data-sveltekit-preload-data="off"` and `href="#training-affected-soldiers"` with no `aria-current` (`158`).
- Native `hover` was available. After hovering "View 2 soldiers" (6_164) and waiting 2 s, the list still ended at 153 (`161`). After hovering "View 1 soldier" (6_169) and waiting 2 s, it still ended at 153 (`164`). That is zero `reports/__data.json` requests and zero `api/training-reports` summary requests.
- Native click on 6_164 produced exactly one new request (`167`, `170`): req 154 `GET api/training-reports/detail?horizon=30&rowsBy=mos&scope=focus&focus=gap:<trainingRequired>`, status 200.
- The `Affected soldiers` section (`#training-affected-soldiers`) took focus. The status line read "Verification Required Training — the standing gap: 2 requirements not ready or lapsing by 3 Nov." The table showed Rows 1–2 of 2, Baker (Bravo) and Unassigned, both Required and Not Done.
- "View 2 soldiers" had `aria-current="true"`. No grid cell was selected. The URL kept `?horizon=30&rowsBy=mos` with no hash or record ID (`168`, `169`). No duplicate page data followed.
- Native reload: SSR document req 155 plus the shell count only, with no summary API. The page showed 30 days and MOS checked, 25%, and the detail closed (`171`–`173`).
- Native pointer click and then Space on the already-checked 30 days radio sent no new request, and the radios stayed 30 days and MOS (`174`–`178`).

### 6. Restoration
- Native toolbar Clear returned page 2 to `/reports` with 90 days and Group (`180`–`183`). Page 2 is at 1905×2053, light theme, sidebar expanded, with mode-watcher storage only. Page 2 was never resized.
- Page 3 is at `/reports` defaults, 1905×2053.
- `rows` for organizations, personnel, personnel_trainings, training_types and training_views (A and B) and `trainingConfigure` preferences are byte-identical to the root originals (`184-*`, `185`). Empty-actor preferences are unchanged.
- No seed was created. There were no UI rows, print or observer use, and no feedback hooks. Network on pages 2 and 3 reports `armed:false` (`187`, `188`). Export capture was restored.
- Final doctor PASS with the same binding (`189`). The run is returned uncleaned to root. Root owns readback, cleanup, packaging and independent acceptance.

## Limits
- This round re-proves only the 8cdd5310 action, focus and preload delta. Earlier print/PDF, nullable-matrix, seeded-pagination and consumer acceptance is composed from v6, not re-run here. No PDF or print was produced in this round.
- `network state` reported `count: 0` and `ids: []` for these GET families. Request uniqueness comes from the native `list_network_requests` reqids, not the helper count.
- The "exactly one export GET" claim depends on the native list. The synthetic 503s fail before dispatch and never appear there. Visual judgment covers only the six empty-state screenshots and the held toolbar shot.
- Concrete notes for root: V1 (no visible focus ring on the programmatically focused briefing region) and F1 (normal Export success leaves focus on BODY). Both pre-exist this delta, and neither was introduced by it.
