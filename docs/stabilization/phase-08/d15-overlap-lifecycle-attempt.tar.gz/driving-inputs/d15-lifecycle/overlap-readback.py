from journeys import *

try:
    seed = json.loads((E / 'lifecycle-legacy-seed.json').read_text())
    outcome = json.loads((E / 'lifecycle-outcome.json').read_text())
    require(outcome['result'] == 'PASS', outcome)
    responses = [json.loads((E / ('lifecycle-response-' + label + '.json')).read_text()) for label in ['A', 'B']]
    require(sorted(response['status'] for response in responses) == [200, 409], responses)
    parent, progress = parent_rows(seed, 'lifecycle-authoritative')
    winner = next(response for response in responses if response['status'] == 200)
    require(isinstance(winner['body'], dict) and {'id', 'status', 'completedAt', 'cancelledAt'} <= winner['body'].keys(), winner)
    require(winner['body']['id'] == parent['id'] and winner['body']['status'] == parent['status'], winner)
    require(winner['body']['completedAt'] == parent['completed_at'] and winner['body']['cancelledAt'] == parent['cancelled_at'], winner)
    terminal(parent, parent['status'])
    if parent['status'] == 'completed':
        require(winner['body'].get('incompleteCount') == sum(row['active'] and not row['completed'] for row in progress), winner)
    write(E / 'lifecycle-authoritative-response-outcome.json', json.dumps({'result': 'PASS',
        'statuses': [response['status'] for response in responses], 'scope': 'Winning ordinary response equals authoritative saved parent status/dates; waiting stale request reports 409',
        'actorIds': [response['actorId'] for response in responses], 'parent': parent}, indent=2) + '\n')
    history(seed, parent['status'], 'lifecycle-native-history')
    print('Actual competing transitions: one 200, one 409; matching saved dates and native History/reload pass.', flush=True)
except BaseException as error:
    write(E / 'lifecycle-readback-failure.json', json.dumps({'result': 'FAIL' if isinstance(error, ObservedFailure) else 'INCONCLUSIVE',
        'reason': type(error).__name__, 'message': str(error), 'action': 'Preserve every observed outcome and finish exact owned cleanup'}, indent=2) + '\n')
    raise
