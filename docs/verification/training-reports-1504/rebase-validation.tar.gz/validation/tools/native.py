import json, os, pathlib, subprocess, sys
root=pathlib.Path('.verification/evidence/verify-trooptotask/rebase-1511')
name, data, receipt=sys.argv[1:]
env=dict(os.environ, PATH='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH'])
r=subprocess.run(['npm','run','--silent','verify:app','--','tool',name,data],capture_output=True,text=True,env=env)
p=root/receipt
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(r.stdout)
if r.returncode: print(r.stderr); print(r.stdout); sys.exit(r.returncode)
x=json.loads(r.stdout)
for c in x.get('content',[]):
 if c.get('type')=='text': print(c['text'])
