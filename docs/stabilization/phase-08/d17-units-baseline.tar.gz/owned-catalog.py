import contextlib, hashlib, importlib.util, io, json, subprocess
from pathlib import Path
from urllib.request import Request, ProxyHandler, HTTPRedirectHandler, build_opener
REPOSITORY=Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-c1e9d360')
EXPECTED={'session':'b8ac14db-09d5-4f21-be38-69ca997473bd','candidate':'c82cede223ff6e4afe8908ba4d390a52a920e4f63a826e27d0a1b6194ab7e447','origin':'http://127.0.0.1:46337','revision':'430484386c27966d43c7f9aa6f2aedf38f97ed89'}
def require(value,message):
 if not value: raise RuntimeError(message)
key=hashlib.sha256(str(REPOSITORY).encode()).hexdigest()[:16]
session=Path.home()/'.local/state/trooptotask-verification'/key/'worker-1'
spec=importlib.util.spec_from_file_location('owned_environment',REPOSITORY/'scripts/verification/environment.py')
environment=importlib.util.module_from_spec(spec);spec.loader.exec_module(environment)
session=environment.private_session(session)
with contextlib.redirect_stdout(io.StringIO()):
 state,directory,env=environment.owned(session)
 require(state['repository']==str(REPOSITORY),'Foreign repository owns provider')
 environment.status(session)
 records=environment.containers(state,directory,env)
worker=json.loads((session/'session.json').read_text())
require(worker['repository']==str(REPOSITORY) and worker['worker']=='1' and worker['phase']=='running','Inactive or foreign worker')
require(worker['id']==EXPECTED['session'] and worker['candidate']==EXPECTED['candidate'],'Original baseline binding changed')
supervisor=worker['supervisor'];process=Path('/proc')/str(supervisor['pid']);stat=(process/'stat').read_text()
require(stat[stat.rfind(')')+2:].split()[19]==str(supervisor['start']) and (process/'cmdline').read_text()==supervisor['command'],'Supervisor identity changed')
class NoRedirect(HTTPRedirectHandler):
 def redirect_request(self,*unused): return None
require(type(worker['controlPort']) is int and 1024<=worker['controlPort']<=65535,'Invalid owned control port')
request=Request(f"http://127.0.0.1:{worker['controlPort']}",data=b'{"command":"doctor"}',method='POST',headers={'Authorization':'Bearer '+worker['token'],'Content-Type':'application/json'})
with build_opener(ProxyHandler({}),NoRedirect()).open(request,timeout=30) as response:
 doctor=json.loads(response.read(1048576))
 require(response.status==200 and response.headers.get('X-T2T-Session')==EXPECTED['session'] and doctor.get('status')=='PASS' and all(doctor.get(k)==v for k,v in EXPECTED.items()),'Frozen original doctor did not pass')
dbs=[r for r in records if r['Name']=='/supabase_db_'+state['project'] and r['State']['Running'] and r['Id'] in state['container_ids']]
require(len(dbs)==1,'Original owned database unavailable')
query="""BEGIN READ ONLY;
SET LOCAL statement_timeout = '15s';
SELECT json_build_object(
 'units', to_regclass('public.units')::text,
 'relations', (SELECT coalesce(json_agg(json_build_object('schema',n.nspname,'name',c.relname,'kind',c.relkind,'rls',c.relrowsecurity) ORDER BY c.relname),'[]'::json) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND (lower(c.relname)='units' OR c.relname IN ('groups','organizations'))),
 'policies', (SELECT coalesce(json_agg(json_build_object('table',tablename,'name',policyname,'command',cmd,'roles',roles,'using',qual,'check',with_check) ORDER BY tablename,policyname),'[]'::json) FROM pg_policies WHERE schemaname='public' AND (lower(tablename)='units' OR tablename='groups')),
 'migration_versions', (SELECT coalesce(json_agg(version ORDER BY version),'[]'::json) FROM supabase_migrations.schema_migrations)
);
ROLLBACK;"""
command=['docker','exec','-i','-e','PGPASSWORD=postgres',dbs[0]['Id'],'psql','-X','-q','-A','-t','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
result=subprocess.run(command,input=query,text=True,capture_output=True,cwd=directory,env=env,timeout=30)
require(result.returncode==0,'Owned readonly query failed; private diagnostics withheld')
catalog=json.loads(result.stdout.strip())
print(json.dumps({'binding':{**EXPECTED,'repository':str(REPOSITORY),'worker':'1','project':state['project'],'database_container_id':dbs[0]['Id']},'doctor':doctor,'catalog':catalog}))
