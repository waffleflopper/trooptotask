# #1504 final v5 native acceptance: mandatory selection correction

Driver: Claude Opus 5.5 test sub-agent, worker 1, no nested agents. This is a bounded native run for the selection correction at `a586bf50`. It does not re-certify v1–v4 coverage or whole-issue acceptance. Root owns independent acceptance.

## Binding

| Field | Value |
| --- | --- |
| Head / base | `a586bf50289e92d995d0c1a681f9178030a10f61` / `ee1ca2b275d71cd0b9a51367b58c4754a687a443` |
| Candidate | `6ec840d5d0cb5da2ccd7ce9d8658a1a6f32c965969c24af0672d36cee8404468` |
| Origin / session | `http://127.0.0.1:41021` / `24967de1-ca66-456b-87dc-d17c39503eda` |
| Browser | Chromium 152.0.7977.82 Arch Linux, `/usr/bin/chromium`, not provisioned |
| Actor | `trainingConfigure`, Organization A `0ae5d810…`, page 2 |
| Doctor | Start `000-doctor` PASS and final `180-doctor-final` PASS. Both exactly match the binding. |
| Evidence | `.verification/evidence/verify-trooptotask/1504-final-v5/driver/` (680 files, `receipts.jsonl` with 311 unique receipts), plus `training-report-30-mos.xlsx`, `training-brief-30-mos.pdf` and `pdf-pages/` |

Fixture literals came from root's `root-public-fixture.json`. Today is `2026-10-04`. `trainingExpires` is `2027-09-27`. The 90-day horizon ends 2 Jan 2027 and the 30-day horizon ends 3 Nov 2026. Original state: viewport 1905×2053, DPR 1, light, `mode-watcher-mode=system`, no sidebar cookie, empty preferences/progress (`004`, `002`).

Labels used here. **Native** means a native DevTools click, press_key, resize or navigate. **Observation** means read-only `evaluate_script`, `take_snapshot` or `list_network_requests`. **Helper** means a documented `control.mjs` network, export or print command. "Request list" means native `list_network_requests` for fetch/xhr, filtered to `training-reports` and `__data`.

## Verdicts

| # | Path | Verdict |
| --- | --- | --- |
| 1 | Baseline facts, default controls, Required Total detail, no duplicate summary load | **PASS** |
| 2 | Click and Space on each already-selected control (25, Horizon 90, Rows by Group), asserted after every activation | **PASS** (6/6) |
| 3 | 100 change, re-activate 100, back to 25, Horizon 30, Rows by MOS, re-activate 30/MOS, reload | **PASS** |
| 4 | Held selection, failed selection, briefing Retry, detail 503 Enter Retry | **PASS on selection/URL/request semantics.** Finding F1: focus falls to BODY after briefing Retry. |
| 5 | Native Export Excel at 30/MOS with a narrow 11B detail open | **PASS** (driver double click noted) |
| 6 | Native Print brief at 30/MOS with 11B detail | **PASS with minor layout finding F3** |
| 7 | 1440 and 390 screenshots with native control interaction, chart recovery after print | **PASS.** Finding F2: stale cell outline after detail closes. Note N1: roving tab stop. |
| 8 | Restore controls/viewport/route; provider rows and preferences; final doctor | **PASS** |

No source, test, documentation, helper, recipe, SQL, Git, service or provider writes were made. No UI rows were created. Root owns cleanup and the worker was not cleaned.

## 1. Baseline

- `006` native click on Reports. The request list (`008-net`) shows only `training/__data.json` and `training/reports/__data.json`. No `/api/training-reports` summary request ran on load.
- Snapshot `009`: 3 soldiers, as of 4 Oct 2026. Bottom line 25% ready today, stays 25% by 2 Jan, "Nothing lapses before 2 Jan." Ready 1, expired 0, not recorded 3, lapse 0. Grid Bravo 0%, Unassigned 0%, Alpha 50% (Required 100, Targeted 0). Total Required 33%, Targeted 0%, row 25%/25%. Forecast has 14 points from 4 Oct to 2 Jan, all 25%.
- Default checked state: 90 days and Group (`008-state`).
- `011` native click on Total Required. One request: `detail?scope=cell&type=486400b0…` [200]. The table lists Baker (Bravo) and Unassigned, both Not Done with "-" expiry and No lapse. Status reads "2 requirements not ready or lapsing by 2 Jan." Range is Rows 1–2 of 2. 25 is checked and 100 unchecked. Focus is on `SECTION#training-affected-soldiers` (`013`).
- Screenshots: `010-initial-full.png`, `015-detail-section.png`, `016-detail-viewport.png`. I inspected `016`. It shows the full lower region, the selected Total Required outline and the detail table.

## 2. Already-selected controls, one activation per assertion

Each row has a before state, one native action, then after state, request list and snapshot (`NNN-before-*`, `NNN-action`, `NNN-after-*`). The request list stayed at three entries throughout (both `__data` plus detail reqid 143). The URL stayed `/reports`.

| Receipt | Action | Checked after | Focus after | New request |
| --- | --- | --- | --- | --- |
| `020` | Click "25 rows per page" | 25 on, 100 off | 25 radio | none |
| `021` | Space on 25 | 25 on, 100 off | 25 radio | none |
| `022` | Click "90 days" | 90 on, others off | 90 radio | none |
| `023` | Space on 90 | 90 on | 90 radio | none |
| `024` | Click "Group" | Group on | Group radio | none |
| `025` | Space on Group | Group on | Group radio | none |

The detail stayed open with Rows 1–2 of 2 through all six actions. In every after state exactly one option per group was checked, and no group ended with nothing selected.

Roving arrows (`026`, `027`): ArrowRight moved focus to MOS while Group stayed checked and no request ran. ArrowLeft returned focus to Group. Focus and checked state are independent.

## 3. Real changes and re-activation

| Receipt | Action | Result |
| --- | --- | --- |
| `030` | Click 100 | One request `detail?…&pageSize=100` (reqid 144) [200]. Rows 1–2 of 2. 100 on, 25 off. Focus on the 100 radio. |
| `031`, `032` | Click 100, then Space on 100 | 100 stays checked. No new request (reqid 144 is still last). |
| `033` | Click 25 | One request (reqid 145) without pageSize. 25 checked. |
| `034` | Click 30 days | `api/training-reports?horizon=30` (146) [200]. URL `?horizon=30`. 30 checked. The detail closes by design because the input changed. |
| `035` | Click MOS | `?horizon=30&rowsBy=mos` (147) [200]. URL `?horizon=30&rowsBy=mos`. Bottom line 25%→25% by 3 Nov with 1/0/3/0. Forecast points 4 Oct, 11/18/25 Oct, 1 Nov and 3 Nov (short last bucket). Grid rows 11B (1 soldier, Required 0%, Targeted —, 0/0) and 68W (2 soldiers, Required 50%, Targeted 0%, 33%/33%). Total 33/0, 25%/25%. |
| `036`–`039` | Click MOS, Space MOS, click 30, Space 30, each asserted separately | 30 and MOS stay checked. No request after reqid 147. URL unchanged. |
| `040`–`044` | Native reload | URL kept. 30 and MOS checked. "NEXT 30 DAYS", "BY 3 NOV", 11B/68W rows. The request list after reload has no `/api/training-reports` call, and the only reports request is the document (reqid 148), so the report is server-derived. |

## 4. Held and failed selection

Contract from source (`trainingBriefingSession.svelte.ts`): while loading, `selected` is the attempted input and the URL stays on the displayed report. On failure, `selected` reverts to the displayed input. Retry re-selects the attempted input.

- **Hold** (`051` helper `arm-hold training-reports`, `052` native click 180). While held: 180 checked, MOS checked, URL still `?horizon=30&rowsBy=mos`. The briefing still shows "NEXT 30 DAYS"/"BY 3 NOV" with the "Updating briefing" status. Helper state shows `held:true`. This matches the contract: the controls show the attempt and the briefing plus URL show what is loaded. Screenshot `054-held-viewport.png`.
- `055` native Tab moved focus to the Group radio. `057` release. `058`: URL `?horizon=180&rowsBy=mos`, focus still on Group (no steal), no alert. `060` restore.
- **Failure** (`061` arm-fail, `063` native click Duty role). The helper records one 503. The alert reads "Unable to update the briefing. The briefing could not be updated (503). Showing the last briefing that loaded. Retry". Radios revert to MOS (Duty role unchecked) and 180 stays checked. URL is unchanged at `?horizon=180&rowsBy=mos`. Focus stays on Duty role. Screenshot `065-fail-viewport.png`.
- `066` restore, `067` native click Retry: request `?horizon=180&rowsBy=role` (269) [200]. URL `?horizon=180&rowsBy=role`. Duty role checked. Grid rows NCO and Medic. **Focus is BODY** (F1).
- Second check (`070`–`075`): arm-fail, native click Group, one Shift+Tab to Retry, restore, native Enter. Request `?horizon=180` (270), Group checked, URL `?horizon=180`. **Focus is BODY again** (F1).
- **Detail 503** (`081` arm-fail detail, `082` native click Total Required). The alert reads "Unable to load affected soldiers (503). Retry". Focus is on SECTION. Radios 180/Group/25 stay canonical.
- `083` restore, `084` arm-hold detail, two Tabs (25 radio, then Retry), `087` native Enter. While held: focus on SECTION, loading, no alert, request reqid 271 [200] held. After `089` release: focus still on SECTION, Rows 1–2 of 2, radios 180/Group/25 canonical. `091` restore.

## 5. Export at 30/MOS with narrow detail

- `101`/`102` restore 30 and MOS (reqids 272, 273). `103` click 11B × Required. Detail request `…&scope=cell&row=11B&type=…` (274). Rows 1–1 of 1: Baker, Bravo, Not Done.
- `104` network arm-observe `training-reports/export`, `105` export arm, `106` native click Export Excel. **Driver error:** my command sent two native clicks (`106-click-export` and `106-click-export-native`). The observer recorded two export GETs, both 200 with `attachment; filename="training-report-2026-10-04.xlsx"` and the xlsx MIME. This was driver-caused, not product behavior.
- `107` export state: captured, 11428 bytes, filename `training-report-2026-10-04.xlsx`. `109` save to `training-report-30-mos.xlsx`, SHA-256 `b1986bf8300ae4107ff91450851b01b76a1e6aae09ffcd106fdd1ef454299ac6` (matches `sha256sum`). `110`/`111` restore both.
- Sheet order read from the zip's `workbook.xml` (`113`): Summary, Forecast, Hot spots, Focus, Requirements. Exactly five.
- **Summary** (`112-wb-Summary`): As of 2026-10-04, Horizon end 2026-11-03, goal 90, ready 25/25, drop 0, Ready 1, applicable 4, expired 0, not recorded 3, lapse 0. Filters are All training, All groups, All ranks, MOS All, Duty role All, Types "All required (2)", **Horizon "30 days", Rows by "MOS"**.
- **Forecast**: 2026-10-04 (today), then buckets ending 10-11, 10-18, 10-25 and 11-01, then a short 2 Nov – 3 Nov bucket ending 2026-11-03. All 1 ready at 25% with 0 lapses.
- **Hot spots**: header MOS. Rows 11B (1, 0, null Targeted, 0/0), 68W (2, 50, 0, 33/33) and Total (3, 33, 0, 25/25). This matches the screen.
- **Focus**: two areas with the on-screen sentences and 3 Nov what-ifs (25→75, 25→50).
- **Requirements**: exactly three Not Done rows: Able Targeted (Alpha), Baker Required (Bravo), Unassigned Required (no group). There is no Able Required row, no Optional, N/A or Foreign row. The workbook covers the full filtered briefing, not just the 11B detail. I counted these independently from the fixture: Required applies to all three people and only Able has it current; Targeted applies only to Able, who has none.

## 6. Native print brief

- `120` reload, `123` reopen 11B detail (reqid 397, Rows 1–1 of 1, focus SECTION). `124` print arm (before 0, after 0). `125` native click Print brief. `126` print state **before 1, after 0**, saved before capture. `127` print save of the exact URL `…/training/reports?horizon=30&rowsBy=mos` gave a new PDF of 174542 bytes, SHA-256 `dbc2175e4d7f0266aee06111a757298dcb387e353e9a558b1fe26368b35971c8`. `128` restore.
- `pdfinfo`: 4 pages, all letter landscape (792×612). Rendered to `pdf-pages/brief-1..4.png` at 80 dpi. I inspected each page visually.
  - **p1**: title, subtitle "Verification Organization A · 3 soldiers · as of 4 Oct 2026", filter line "Filters · View: All training · Group: All groups · Rank: All ranks · MOS: All · Duty role: All · Types: All required (2) · Horizon: 30 days · Rows by: MOS", Bottom line 25%→25% by 3 Nov, 1/0/3/0. The lower 40% of the page is blank because the next section is kept whole.
  - **p2**: Forecast "NEXT 30 DAYS" (0–100%, Goal 90%, 25% line, Today · 4 Oct / 1 Nov / 3 Nov), then the MOS grid with legend, semantic red bands, 11B selected outline, and Today/3 Nov columns.
  - **p3**: Type risk (Required 2/0, Targeted 1/0) and both Focus areas with what-if chips and no "View" links. Then the Affected soldiers eyebrow, heading, status and "Rows 1–1 of 1".
  - **p4**: the table header and the single Baker row. Nothing else. No trailing blank page and no portrait page.
- No sidebar, header bar, toolbar, header actions, Rows by or Rows per page radios, Focus links, pagination, Retry or toasts appear. Text search of `brief.txt` for control labels finds only the filter line's "Rows by: MOS" and "Forecast · Next 30 days".
- Console (`130`, preserved over the last 3 navigations): the LayerCake "Target div has zero or negative width" warning (×2) and roughly 13 "`<rect>` attribute width: A negative value" errors (≈−5.978) recurred. I cannot attribute them to a specific navigation or print. The PDF chart and the later on-screen chart (`144`) rendered correctly. I make no clean-console claim. The other entries are known local 404s for Vercel insights scripts and preload warnings.
- This PDF proves print rendering. It does not prove a system dialog or physical printing.

## 7. Viewports

- **1440×900** (`140` native resize). `142` native click 60 days: one request `?horizon=60&rowsBy=mos` (398), 60 checked, focus on the 60 radio. The chart is 748 px wide. Screenshot `144-1440-h60.png` (inspected) shows a 60-day forecast to 3 Dec, Bottom line by 3 Dec, and 60 D selected. This shows the chart and controls recover after print.
- **390×844** (`150`). The document is 390 wide with no page-level horizontal overflow. `153` native click Group: request `?horizon=60` (399), Group checked. Screenshot `154-390-group-full.png` (viewport only, because the app scrolls inside a container): the Rows by chips are legible and Group shows as a white selected chip. The grid scrolls horizontally inside its container (Targeted column off-screen). `155` ArrowRight then screenshot `156-390-focus-mos-unchecked.png`: an orange focus ring on MOS, clearly distinct from the checked Group chip. `158` ArrowLeft back, with no request.

## 8. Restoration

- `160` resize to 1905×2053. `162` native click 90 days: URL `/reports`, 90 and Group checked, no Clear filters button. `163`: theme unchanged (`mode=system`, no html class), original localStorage keys only, no `__map*` globals. Every network, export and print control was explicitly restored (`060`, `066`, `074`, `083`, `091`, `110`, `111`, `128`). The feedback observer was not used. Theme and sidebar were never toggled.
- `170` native click on the Training breadcrumb. The final URL is `/org/0ae5d810…/training`, the starting route.
- Provider readbacks `172-rows-*` for `personnel_trainings`, `training_types`, `training_views` and `organizations` in A and B are **byte-identical** to root's `root-*-original.json` files. `173-prefs-after` is byte-identical to `root-trainingConfigure-preferences-original.json`. No UI rows were created.
- `180-doctor-final` PASS with the exact binding. The worker is returned to root without cleanup.

## Findings

**F1 (P3, keyboard/a11y, briefing-level Retry; not part of the selection correction).** After a successful briefing Retry, focus lands on `<body>`. Both pointer click (`067`) and native Enter (`075`) reproduce it: the focused Retry button unmounts when the alert clears. The detail Retry correctly keeps focus on its section, so this is the briefing-level counterpart of the earlier detail fix. The attempted selection, URL and request are all correct. A minimal fix would move focus to a stable target on explicit briefing Retry, such as the attempted control or the briefing region. To falsify: native Enter on briefing Retry, then require a non-BODY focus while loading and after.

**F2 (P3, visual, briefing selected-cell outline).** After a cell's detail is closed by a horizon change, the previously clicked 11B cell keeps its dashed "selected" outline (`144`). At that point `data-selected="true"` is still on that TD and there is no detail region (`147`). The accessible name correctly drops ", selected". Cause: `src/lib/components/ui/operational-matrix/root.svelte:41-43` returns `selectedCell ?? internalSelectedCell`. When `TrainingReportsPage` passes `selectedCell={undefined}` (detail idle, or a Focus-link scope), the primitive falls back to its internal click memory. The primitive is unchanged on this branch, and the briefing is the consumer that turns its controlled value undefined. Visual and accessibility state disagree, so a sighted user sees a selection with no open detail. I did not test whether this stale outline also prints when the detail is closed.

**F3 (P3, print layout).** In the 30/MOS brief with a one-row 11B detail, the Affected soldiers heading, status and range end page 3, and the one-row table is alone on page 4. The section would fit on one page. This is the same family as v4's 25-row note, now shown for a section that easily fits. Content is complete and legible.

**N1 (observation, likely pre-existing and not established as a regression).** The roving tab stop on the radio groups does not follow the checked option. After reload, Rows by has `tabIndex 0` on unchecked Group while MOS is checked (`042`), and native Tab landed on Group (`055`). Horizon showed the same pattern at baseline (30 had tab stop 0 while 90 was checked). The WAI-ARIA radio pattern expects Tab to reach the checked radio. This comes from Bits UI ToggleGroup roving focus. I did not check it against base.

**Driver notes.** `106` sent two Export Excel clicks (driver error, both exports 200, one Blob saved). Receipt `145-sel` exited 2 with an `INCONCLUSIVE` evaluate error (`getComputedStyle` on a non-element). It was a read-only inspection and `147-dsel` replaced it. All other 309 receipts exited 0. Receipt names are unique.

## Not established here

The many-type print, a second detail/cohort, Organization/session races, the full Onboarding and consumer journeys, dark-mode print, the unchanged-page rendered print, RLS, release and remote all remain outside this round. v4 print, pager and focus proofs are separate historical continuity. This run supports the selection correction's native behavior at `a586bf50`. It does not certify wider #1504 scope.

## Secrets

No auth tokens, cookies or credentials were printed or saved. A filename/content scan of `driver/` for token, password and auth-cookie patterns found nothing. No files are flagged for root redaction.
