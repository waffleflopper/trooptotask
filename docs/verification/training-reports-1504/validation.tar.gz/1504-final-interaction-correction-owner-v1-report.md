# 1504 final interaction correction owner v1

Base HEAD a799b5a4 (source a586bf50). Working-tree source edits only. No Git mutation, browser, service, network or SQL action. Evidence is in `.verification/1504-final-interaction-correction-owner-v1/`: `red.log`, `green.log`, `suites.log`, `svelte-check.log`, `lint-format.log`, `source.diff`, `diffstat.txt`.

## Files

- `src/lib/components/ui/operational-matrix/root.svelte`
- `src/features/training/components/TrainingReportsPage.svelte`
- `src/features/training/components/TrainingReportsPage.test.ts`
- `src/features/training/components/TrainingAffectedSoldiersSection.svelte`

`context.ts`, `types.ts`, `OperationalMatrix.test.ts`, `OperationalMatrixTest.svelte` and `src/app.css` are unchanged.

## F1. Focus after the report-level Retry

Cause. `session.retry()` sets the request to `loading`. The error alert is rendered only while the request is `error`, so it unmounts on the next tick and takes the focused Retry button with it. Focus fell to `<body>`. The briefing region was also inside the data-only `{:else}` branch, so a retried filter that comes back as no data would remove a focus target too.

Fix. This reuses the detail Retry seam. `focusDetail()` became `focusSection(id)`. `retryBriefing()` calls `session.retry()` and then focuses `#training-briefing` after `tick()`. `ReportWorkspace.Root` (region "Training readiness briefing", `aria-busy` while loading) now wraps the no-types, no-applicable-requirements and briefing branches. It has `id`, `tabindex={-1}` and `outline-none`. The region therefore exists while loading and after any outcome, and focus is never moved after the response. If the user moves focus while the request is held, nothing takes it back. Normal filter and horizon changes do not move focus.

Layout. The no-data `State` now sits inside the Root's `flex flex-col gap-4` section. It is the only child there, so spacing is unchanged. Root adds `bg-background text-foreground`, which matches the page.

## F2. Controlled "no cell selected"

Consumer census of `OperationalMatrix.Root`:

| Consumer | `selectedCell` | Mode |
| --- | --- | --- |
| `IctReadinessMatrixTable.svelte` | omitted | uncontrolled |
| `IctMatrix.svelte` | omitted | uncontrolled |
| `TrainingMatrix.svelte` | omitted | uncontrolled |
| `OperationalMatrixTest.svelte` | always an identity | controlled |
| `TrainingReportsPage.svelte` | identity or none | controlled, needed none |

No consumer reads `context.selectedCell()` directly. Cells read it through `isCellSelected`.

Cause. Training passed `undefined` for idle or focus scope. Root used `selectedCell ?? internalSelectedCell`, so an `undefined` value fell back to the remembered click. The `td` kept `data-selected` and its dashed outline, while Training's own aria label (computed from its prop) dropped ", selected".

Chosen semantics. The prop is `selectedCell?: OperationalMatrixCellIdentity | null`. Omitted or `undefined` means uncontrolled: the root remembers the last click, as before. `null` means controlled with no cell selected. An identity means controlled with that cell selected. Root resolves `selectedCell === undefined ? internalSelectedCell : (selectedCell ?? undefined)`. The context type is unchanged. Training's `selectedCell` derived value returns `null` unless a cell scope is open. That covers idle, a focus scope, and a closed detail after a horizon or filter change. No fake ID, remount key, local mirror or aria-only branch was added. `readOnly` and `disabled` behavior is untouched.

## F3. Print fragmentation of the affected-soldiers detail

Ownership. `src/app.css` applies `break-inside: avoid` to `[data-print-report=training] [data-print-section]` and `tr`. Bottom line, Forecast, Hot spots, Type risk and Focus all carry `data-print-section`. `TrainingAffectedSoldiersSection` did not. Its heading, status and range block was therefore free to end page 3 while the table started page 4.

Fix. I added `data-print-section` to the detail's `ReportWorkspace.Section`. This is the same rule its siblings use. No CSS, constants or geometry changed.

Hypothesis, not yet proven natively. In Chromium a `break-inside: avoid` block that fits on a fresh page moves there whole, so the short one-row detail should print heading and table together on one page. A block taller than a page cannot avoid a break, so the 25-row and 100-row detail should still fragment between rows, because the `tr` rule is unchanged. One accepted side effect is possible: the 25-row detail may now start on a new page, leaving blank space below Type risk and Focus on the previous page. I cannot judge from source whether that is acceptable. It needs a native PDF.

## Tests (red then green)

New tests in `TrainingReportsPage.test.ts` use the real page and deferred `fetch` promises. The expected outcomes are literal roles, names and attributes.

1. Retrying a failed Rows by refresh moves focus to region "Training readiness briefing" while it is `aria-busy="true"`. After the MOS table arrives, the region is `aria-busy="false"` and still focused. Red: focus was `<body>`.
2. A retried refresh that returns no training types shows "No training types configured." and focus stays on the region. Red: `<body>`.
3. No-steal negative. Moving focus to the "30 days" radio while the retry is held leaves focus there after the response. This passed before the fix as well. It guards against a post-response autofocus implementation and is not a reproduction.
4. Open the Alpha × CPR cell, then change the horizon to 30 days. The detail closes, the cell's label has no "selected", the cell has no `data-selected`, and no element has `[data-selected]`. Red: `data-selected` stayed true.
5. Open the Alpha × CPR cell, then a Focus link. The link has `aria-current="true"`, no `[data-selected]` remains, and no button name ends with ", selected". Red: one stale selected `td`.

The run before the fix had 4 failed and 17 passed (`red.log`). After the fix, the page and the operational-matrix suites pass 30 of 30 (`green.log`). The existing primitive tests are unchanged and pass, including the controlled-identity harness and the uncontrolled consumers' suites.

## Checks

- `vitest run src/features/training src/features/critical-tasks src/lib/components/ui`: 93 files, 661 tests passed.
- `svelte-check --threshold error`: 0 errors, 0 warnings.
- `eslint` and `prettier --check` on the four changed files: clean.

Root owns the full gates and the production build. I did not run them.

## Unresolved and boundaries

- The Training recipe needs an update outside my path set. `.agents/skills/verify-trooptotask/features/training-completions-reports.md` step 5 says "Restore, choose `Retry` and require the attempted filters and their briefing." It should also require focus on the "Training readiness briefing" region after the report-level Retry, and that the selected outline clears when a horizon or filter change or a Focus link replaces a cell drill-down. AGENTS asks for recipe updates alongside behavior changes. I did not edit it because it is outside my exclusive set.
- `component-catalog.md` still describes the print rule accurately, so it needs no change.
- The briefing region uses `outline-none`, like the detail section, so a programmatic focus shows no ring. Screen readers announce the labelled region. This matches the existing detail Retry seam and is not new.
- N1, the Bits UI roving tabstop: my change does not touch the toggle groups, and I did not investigate it.

## Native proof required (root, fresh owned run)

1. Report Retry. Fail a Rows by change with a 503, restore, and activate Retry by both click and Enter. Focus should be on the briefing region while loading and after the 200. In a separate run, move focus to a horizon radio while the request is held and confirm it is not stolen. Also confirm no extra requests and the committed URL.
2. Selection. Click the Required 11B cell to open the detail, then change the horizon. The detail should close, the dashed outline should disappear, the cell's accessible name should drop "selected", and no `[data-selected]` should remain. Repeat with cell → Focus link. Also confirm that clicking a cell still shows the outline and opens the correct scope.
3. Print. Produce native landscape PDFs for (a) the 30/MOS one-row 11B detail, where heading, status, range and table should share a page with no blank or truncated page, and (b) the 25-row detail and the 100-row multipage detail, which should have no header-only fragment and no truncated or missing rows, with rows unsplit. Judge whether the blank space before a detail that moved to a new page is acceptable. If it is not, the alternative is to drop the section-level rule and keep only the heading block with the table (`break-after: avoid` on the section header). That needs either a shared Section hook or a scoped selector in `app.css`.
4. Regression. Check the a586 toggle bindings (25/90/Group/100/30/MOS), the 53ab print chrome, pager focus and detail Retry, the five-sheet workbook, and the no-data briefing state's layout and print with the new wrapping Root.
