#!/usr/bin/env python3
"""Fixed native configure deletion from the visible selected consumer Training cell."""
import json,os,re,subprocess,sys
from pathlib import Path
page,tag,status=sys.argv[1:4];page=int(page)
assert status in ['Current','Expired']
run=os.environ.get('D15_RUN','d15-consumers-worker2-baseline');b=Path('.verification/evidence/verify-trooptotask')/run
seed=json.loads((b/'consumer-seed-stdout.json').read_text());name=seed['people'][0]['last_name']
def call(script,*args,show=False):
 r=subprocess.run(['python3','.verification/tmp/d15-consumers-worker2/'+script,*args],capture_output=True,text=True,check=True)
 if show:print(r.stdout)
def tool(label,name,args):call('drive.py','tool',label,name,json.dumps(args))
call('action.py','click',str(page),tag+'-open',f'button "{name} Verification Required Training: {status}')
call('action.py','click',str(page),tag+'-confirm','button "Delete"')
before=b/(tag+'-save-before.txt');tool(tag+'-save-before','take_snapshot',{'pageId':page,'filePath':str(before)})
s=before.read_text();tail=s.split('alertdialog "Delete Training Record"',1)[1];line=next(l for l in tail.splitlines() if 'button "Delete"' in l);uid=re.search(r'uid=([^\s]+)',line).group(1)
tool(tag+'-save-click','click',{'pageId':page,'uid':uid,'includeSnapshot':True})
tool(tag+'-save-after','take_snapshot',{'pageId':page,'filePath':str(b/(tag+'-save-after.txt'))})
tool(tag+'-save-screen','take_screenshot',{'pageId':page,'filePath':str(b/(tag+'-save.png')),'fullPage':True})
call('capture-write.py',str(page),tag,'DELETE','personnel-trainings',show=True)
call('action.py','reload',str(page),tag+'-persisted')
