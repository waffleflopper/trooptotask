#!/usr/bin/env python3
"""Frozen worker-2 native observation wrapper. No application internals or provider SQL."""
import json, os, re, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
assert Path.cwd().resolve()==ROOT
os.environ['TMPDIR']='/home/waffleflops/.cache/t2t-d15-tmp'
RUN=os.environ.get('D15_RUN','d15-consumers-worker2-baseline')
assert re.fullmatch(r'd15-consumers-worker2-(baseline|final)',RUN)
E=ROOT/'.verification/evidence/verify-trooptotask'/RUN
E.mkdir(parents=True,exist_ok=True)
def save(name,value):
    assert re.fullmatch(r'[A-Za-z0-9_.-]+',name)
    p=E/name
    with p.open('x') as f: f.write(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')
    return p
mode,tag=sys.argv[1:3]
assert re.fullmatch(r'[A-Za-z0-9_.-]+',tag)
if mode=='app':
    args=sys.argv[3:]; cmd=['npm','run','--silent','verify:app','--',*args,'--worker','2']
elif mode=='control':
    args=sys.argv[3:]; cmd=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','2',*args]
elif mode=='tool':
    tool=sys.argv[3]; args=json.loads(sys.argv[4])
    assert tool!='get_network_request', 'Use network-body mode: credential-bearing headers never saved'
    if 'filePath' in args:
        dest=Path(args['filePath']); assert dest.parent==Path('.verification/evidence/verify-trooptotask')/RUN
        assert not (ROOT/dest).exists()
    cmd=['npm','run','--silent','verify:app','--','tool',tool,json.dumps(args),'--worker','2']
elif mode=='network-body':
    args=json.loads(sys.argv[3]); tool='get_network_request'
    for key in ['requestFilePath','responseFilePath']:
        if key in args:
            dest=Path(args[key]); assert dest.parent==Path('.verification/evidence/verify-trooptotask')/RUN
            assert not (ROOT/dest).exists()
    cmd=['npm','run','--silent','verify:app','--','tool',tool,json.dumps(args),'--worker','2']
else: raise SystemExit('unknown mode')
save(tag+'-input.json',{'mode':mode,'worker':2,'command':cmd,'TMPDIR':os.environ['TMPDIR']})
r=subprocess.run(cmd,capture_output=True,text=True)
if mode=='network-body':
    # Tool text contains secret headers. Save only requested business body files plus booleans.
    save(tag+'-result.json',{'exitCode':r.returncode,'isError':bool(re.search(r'"isError"\s*:\s*true',r.stdout)), 'bodyFileArguments':args})
    print(json.dumps({'exitCode':r.returncode,'bodyFileArguments':args}))
else:
    save(tag+'-stdout.json',r.stdout); save(tag+'-stderr.txt',r.stderr)
    print(r.stdout)
if r.returncode: raise SystemExit(r.returncode)
if re.search(r'"isError"\s*:\s*true',r.stdout): raise SystemExit('native tool error preserved')
