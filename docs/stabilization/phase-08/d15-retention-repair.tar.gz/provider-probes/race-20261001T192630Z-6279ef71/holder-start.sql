SET application_name = 't2t-d15-race-21332722';
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
UPDATE public.personnel_onboardings SET status = 'cancelled', cancelled_at = '2026-10-01T19:26:32.252249+00:00'::timestamptz
WHERE id = '60adab62-28c5-4ac1-8392-f0dad30afd75'::uuid AND organization_id = '278b5950-3fde-4744-b4cc-e46534f9009d'::uuid
  AND status = 'cancelled' AND cancelled_at = '2000-01-01T12:00:00+00:00'::timestamptz AND completed_at IS NULL
RETURNING json_build_object('event', 'updated', 'id', id, 'status', status, 'cancelled_at', cancelled_at);
SELECT json_build_object('event', 'holder-ready', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
