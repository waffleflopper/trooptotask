import json
from flow import call,tool,snapshot,click,shot,base
from http import row,ack,PERSON,siblings_equal
from sds import fill_values
page=json.loads((base/'owner-page.json').read_text())['pageId']
assert ack('existing-failure-ack-set',page)['status']==200
before=row('existing-failure-before')[0]
auditBefore=call('existing-failure-audit-before','control','rows','audit_logs','orgA')['rows']
click('existing-failure-open',page,'More info');fill_values('existing-failure-fill',page,{'Emergency phone':'907-555-0166'})
call('existing-failure-arm','control','network','arm-fail',str(page),'personnel/'+PERSON+'/extended-info')
call('existing-failure-feedback-arm','control','feedback','arm',str(page))
click('existing-failure-submit',page,'Save');s=snapshot('existing-failure-draft',page);shot('existing-failure-draft',page)
assert '907-555-0166' in s and 'Synthetic request failure' in s
net=call('existing-failure-network','control','network','state',str(page));assert len(net['calls'])==1 and net['calls'][0]['status']==503
call('existing-failure-feedback','control','feedback','state',str(page));call('existing-failure-feedback-restore','control','feedback','restore',str(page))
after=row('existing-failure-after')[0];assert before==after
auditAfter=call('existing-failure-audit-after','control','rows','audit_logs','orgA')['rows'];assert auditBefore==auditAfter
call('existing-failure-restore','control','network','restore',str(page));click('existing-failure-retry',page,'Save')
retry=row('existing-failure-retry-row')[0];siblings_equal(before,retry,{'emergency_contact_phone','updated_at'});assert retry['emergency_contact_phone']=='907-555-0166' and retry['award_tracking_acknowledged_at']==before['award_tracking_acknowledged_at']
tool('existing-failure-reload','navigate_page',{'pageId':page,'type':'reload'});click('existing-failure-reloaded-open',page,'More info');s=snapshot('existing-failure-reloaded-form',page);shot('existing-failure-reloaded-form',page);assert '907-555-0166' in s;click('existing-failure-reloaded-close',page,'Cancel')
(base/'existing-failure-check.json').write_text(json.dumps({'result':'PASS','boundary':'Native controlled pre-request503; real complete28-field before/after row and audits, actual native retry/reload','before':before,'afterFailure':after,'afterRetry':retry,'limits':'Pre-request fault does not claim partial-provider-persistence recovery; lower-level real stored-state failure tests remain distinct.'},indent=2)+'\n')
