# Independent artifact retention SDK probe

This ignored probe imports unchanged `cleanupArchivedRecords`, `createSupabaseDataStore`, `createSupabaseStorageAdapter` and `bindLeaderNoteDataSource`. The real Supabase SDK uses an in-memory finite REST fetch boundary; no service, browser, SQL, Storage provider or remote request was used. The two active parent identities are sentinels; the parent source explicitly returns zero and proves no SQL/cascade behavior.

Run from the repository root:

```sh
npm exec vitest -- run --config .verification/evidence/verify-trooptotask/d13-artifact-retention-sdk-probe/probe.config.ts
```

The scratch config merges the root plugins/aliases and overrides the include to this one probe. Its 15-second test timeout accommodates the unchanged installed SDK's GET/503 backoff (1, 2 and 4 seconds); it changes no application or SDK retries. `worker-runtime.log` records Node 24.21.0 and Supabase/PostgREST/Storage 2.106.1, Vitest 4.1.8.

Four large cases populate one artifact family each with 1,001 expired A rows on an active parent. Active/recent/cutoff-equal A and active/recent B controls remain; Follow-ups also have completed history. File cases use finite synthetic bytes for every file-bearing row plus an unrelated object. Fixed time is October 1, 2026 at 12:00 UTC with 36-month settings; equality is October 1, 2023 at 12:00 UTC. This is controlled fixed-time proof, not live cron cutoff equality.

All four still expect successful removal of every expired ID/file, the full 1,001 count, unchanged retained rows/bytes and URLs at most 8,192 bytes. All four fail: discovery receives 1,000 rows followed by one, but deletion submits all 1,001 UUIDs in one URL and the boundary refuses HTTP 414 before mutation. Exact URL sizes are 39,162 (Follow-ups), 39,160 (Counseling), 39,161 (Documents) and 39,154 (Notes). Rows/files remain unchanged and no success notification is sent. The 1,000-row representation cap is enforced for reads and deletion responses, but the URL failure prevents observing a large mutation response/count; no separate count-truncation defect is claimed.

Six small file cases pass, covering both file-bearing families and database delete, confirmation read and Storage removal failures. Earlier Follow-up deletion persists. A rejected file-row delete retains that row and all bytes; confirmation/Storage failures occur after durable target-row deletion and leave its bytes. Every case stops before later Notes/parent work and sends no success notification. Confirmation/503 receipts preserve the actual four requests with retry counts 0–3.

`worker-probe.log` is the final formatted-input run: four failed large expectations, six passed failure boundaries. `worker-probe-initial.log` preserves the first run, including two default-five-second timeout failures; it is not the final verdict. `worker-summary.log` is a compact derivative of the final ten receipts. Every `PROBE_RECEIPT=` line in the raw logs is complete JSON with finite before/after row sets, object paths/bytes/hashes, requests recorded before the URL guard, status/error, parent calls and notifications. SDK headers/credentials are omitted; all identifiers and bytes are synthetic. Lint/format logs are separate checks. Tracked application source remains unchanged. Actual SQL/Storage/native verification belongs to the coordinator's separate owned runs.
