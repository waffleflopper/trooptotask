import pathlib,subprocess,json,datetime,os,sys
ROOT=pathlib.Path("/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93")
E=ROOT/".verification/evidence/verify-trooptotask/d28-training-repair-baseline-369d6e27"
os.environ["PATH"]="/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:"+os.environ["PATH"]
def run(label,kind,args):
 cmd=(["npm","run","--silent","verify:app","--"] if kind=="cli" else ["node",".agents/skills/verify-trooptotask/helpers/control.mjs"])+list(args)+["--worker","1"]
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);(E/(label+".json")).write_text(r.stdout);(E/(label+".stderr")).write_text(r.stderr)
 with (E/"commands.jsonl").open("a") as f:f.write(json.dumps({"time":datetime.datetime.now(datetime.timezone.utc).isoformat(),"argv":cmd,"exit":r.returncode,"label":label})+"\n")
 if r.returncode:raise RuntimeError((label,r.returncode,r.stderr))
 return json.loads(r.stdout)
if __name__=="__main__":
 label,kind,*args=sys.argv[1:];x=run(label,kind,args);print(json.dumps(x))
