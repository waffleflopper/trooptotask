import sys,json
sys.path.insert(0,'.verification');import d18_ui as v,d18_final as f
for page in [2,3,4,5,6]:
 for family in ['network','feedback','export']:
  v.helper(f'234-restore-page-{page}-{family}',family,'restore',str(page))
 v.helper(f'235-clear-page-{page}-network','network','state',str(page))
 v.helper(f'235-clear-page-{page}-feedback','feedback','state',str(page))
v.helper('236-check-constraint-clear','deletion-review-failure','state')
f.capture('237-before-cleanup')
v.helper('238-owned-seed-cleanup','clean-seeds')
f.capture('239-after-cleanup')
seeds=['04-source-seed','61-wait-source-seed','62-storage-source-seed','150-fresh-counsel-wait-seed']
ids={x for name in seeds for org in ['orgA','orgB'] for x in f.read(name)['sources'][org].values()};ids.update(f.read('87-lifecycle-seed')['ids'].values())
comparisons=[]
for org in ['orgA','orgB']:
 for table in f.TABLES:
  before=f.read(f'original-{org}-{table}')['rows'];after=f.read(f'239-after-cleanup-{org}-{table}')['rows'];sort=lambda rs:sorted(rs,key=lambda x:x['id'])
  assert sort(before)==sort(after),(org,table,'original values differ')
  assert not any(r.get('id') in ids or r.get('resource_id') in ids for r in after),(org,table,'recorded temporary target remains')
  comparisons.append({'organization':org,'table':table,'originalRows':len(before),'exactOriginalValues':'PASS','temporaryTargetsAbsent':True})
for i,name in enumerate(seeds):
 prefix='240-after-cleanup-cohort-'+str(i+1);f.file_capture(prefix,name)
 for org in ['orgA','orgB']:
  result=f.read(prefix+'-'+org+'-files');assert not any(x.get('exists') for x in result.get('files',[])),result
result={'observation':'PASS','originalSets':len(comparisons),'recordedTemporarySourceArtifactIds':len(ids),'realPdfPathsAbsent':8,'allRequestHistoryMatchesOriginal':True,'comparisons':comparisons}
(v.root/'241-cleanup-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
v.call('242-final-doctor','tool','doctor');v.call('243-owned-disposal','tool','cleanup');print('PASS final doctor and owned disposal',flush=True)
