# Calendar baseline packaging notes

The original run is preserved byte for byte, including its case-ledger status/reason fields. This supplement binds the phase-level ledger descriptions to specific observations. It does not change statuses or supply new native proof.

Independent acceptance is Standards GO and Spec GO with P03-14 and P05-13 retained as owner-deferred ISSUE observations. The accepted baseline is not final cutover verification.

P09-07 proves a direct authenticated 403 and native reload Access Restricted. In-app navigation after revocation was not observed. The fresh final-candidate run must add that normal navigation leg.

The final complete row capture precedes final clean-seeds. Before cleanup, all temporary seed IDs were absent and restored memberships matched. The later owned journal is empty, but no complete post-clean-seeds row readback exists. No post-cleanup row equality is inferred.

The derived __pycache__/resource-closure-reader.cpython-314.pyc is retained and declared as a reader artifact. It supplies no behavioral proof. The single prior privacy-redacted 404 remains a declared projection, not an exact original capture. Native body and attachment capture limits remain in the unchanged report.

raw-inventory.json is the original raw inventory under a packaging-specific name. inventory.json describes every expanded payload, including the unmodified raw files and five packaging metadata documents. Root packaging does not rerun the app.

| Case | Specific expanded observations |
| --- | --- |
| P01-01 | `p01-september.out`, `p01-lane-range.out`, `p01-september-shot.png` |
| P01-02 | `p01-scoped-range.out`, `p01-scoped-reload-after.out` |
| P01-03 | `p01-empty-range.out`, `p01-empty-prev.out` |
| P01-04 | `p01-view-snapshot.out` |
| P01-05 | `p01-march.out`, `p01-history-range.out` |
| P01-06 | `p01-view-denials.out` |
| P01-07 | `p01-manager-denials.out` |
| P01-08 | `p01-scoped-denials.out` |
| P01-09 | `p01-empty-denials.out` |
| P01-10 | `p01-lane-foreign-denials.out` |
| P01-11 | `p01-lane-foreign-status.out` |
| P01-12 | `p01-lane-foreign-range.out`, `p01-positive-b-range.out` |
| P01-13 | `p01-lane-classification.out` |
| P01-14 | `p01-identity-patch.out` |
| P06-01 | `p06-status-run.out`, `p06-status-response-projection.json`, `p06-status-workbook.out`, `status-days.xlsx` |
| P06-02 | `p06-forecast-run.out`, `p06-forecast-response-projection.json`, `p06-forecast-workbook.out`, `availability-forecast.xlsx` |
| P06-03 | `p06-tempo-run.out`, `p06-tempo-response-projection.json`, `p06-tempo-workbook.out`, `personnel-tempo.xlsx` |
| P06-04 | `p06-assignment-run.out`, `p06-assignment-response-projection.json`, `p06-assignment-workbook.out`, `assignment-coverage.xlsx` |
| P06-05 | `p06-readiness-run.out`, `p06-readiness-response-projection.json`, `p06-readiness-workbook.out`, `group-readiness.xlsx` |
| P06-06 | `p06-native-history-shot.png`, `p06-native-three-month.out`, `p06-native-three-month-shot.png`, `p01-history-range.out` |
| P07-01 | `p07-manager-personnel.out`, `p07-manager-baker.out` |
| P07-02 | `p07-manager-view-grant.out`, `p07-manager-view-reload-after.out` |
| P07-03 | `p07-manager-grant-restore.out`, `p07-manager-none-reload-after.out`, `manager-none-history.xlsx` |
| P07-04 | `p07-manager-able.out`, `able-history.xlsx`, `p07-history-cell-comparison.json` |
| P07-05 | `p07-baker-export.out`, `baker-history.xlsx`, `p07-history-cell-comparison.json` |
| P07-06 | `p07-alpha-able-correct.out`, `alpha-able-history.xlsx`, `p07-alpha-denied-baker.out`, `p07-alpha-denied-foreign.out`, `p07-empty-person-export-correct.out`, `p07-alpha-history-comparison.json` |
| P07-07 | `p07-person-failure-trigger.out`, `p07-person-failure-source-state.out`, `p07-person-failure-blob-state.out` |
| P07-08 | `p07-json-native.out`, `owner-a.json`, `p07-json-calendar-comparison.json` |
| P07-09 | `p07-excel-native.out`, `owner-a.xlsx`, `p07-excel-calendar-comparison-v2.json` |
| P07-10 | `p07-b-json-native.out`, `owner-b.json`, `p07-owner-denied-b.out` |
| P07-11 | `p07-lifecycle-comparison.json`, `p07-final-read-comparison.json` |
| P07-12 | `p07-fail-native.out`, `p07-fail-source-state.out`, `p07-fail-export-state.out`, `p07-after-failure-comparison.json` |
| P07-13 | `p07-explicit-retry-native.out`, `owner-a-retry.json`, `p07-after-retry-comparison.json` |
