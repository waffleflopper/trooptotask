#!/usr/bin/env bash
# usage: ev.sh NAME DESC 'JSFUNCTION'  read-only evaluate on $P
E=.verification/evidence/verify-trooptotask/1504-final-v3/accept
J=$(python3 -c 'import json,sys;print(json.dumps({"pageId":int(sys.argv[2]),"function":sys.argv[1]}))' "$3" "$P")
MAXOUT=${MAXOUT:-12000} $E/t.sh "$1" "READ-ONLY: $2" evaluate_script "$J"
