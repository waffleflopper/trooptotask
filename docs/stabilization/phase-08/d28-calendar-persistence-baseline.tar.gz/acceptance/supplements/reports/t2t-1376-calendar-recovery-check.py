import hashlib
import json
import socket
import subprocess
from pathlib import Path

repo = Path('/home/waffleflops/.cache/t2t-1376-calendar-persistence-owner')
proof = repo / '.verification/evidence/verify-trooptotask/d28-calendar-persistence-baseline'
output = Path('/home/waffleflops/.cache/t2t-1376-calendar-recovery-check.json')
tables = ['status_types', 'assignment_types', 'special_days', 'availability_entries', 'daily_assignments', 'personnel']
manifest = json.loads((proof / 'input-manifest.json').read_text())
tracked = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=repo).decode().split('\0')
selected = []
for name in sorted(set(filter(None, tracked))):
    driving = name == '.agents/skills/verify-trooptotask/SKILL.md' or (name.startswith('.agents/skills/verify-trooptotask/features/') and name.endswith('.md'))
    if (name.endswith('.md') and not driving) or Path(name).name.startswith('.env'):
        continue
    selected.append(name)
assert selected == [entry['file'] for entry in manifest['entries']]
candidate = hashlib.sha256()
for entry in manifest['entries']:
    payload = (repo / entry['file']).read_bytes()
    assert len(payload) == entry['bytes'], entry['file']
    assert hashlib.sha256(payload).hexdigest() == entry['sha256'], entry['file']
    candidate.update(entry['file'].encode() + b'\0' + payload + b'\0')
assert candidate.hexdigest() == manifest['candidate']
revision, tree = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=repo).decode().splitlines()
assert revision == manifest['revision'] and tree == manifest['tree']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)

old_fixture = json.loads((proof / 'fixture.json').read_text())
new_fixture = json.loads((proof / 'restart-fixture.json').read_text())
old_names = {value: key for key, value in old_fixture['ids'].items()}
new_names = {value: key for key, value in new_fixture['ids'].items()}
assert old_names.keys().isdisjoint(new_names.keys())
comparisons = []
for table in tables:
    for org in ['A', 'B']:
        original = json.loads((proof / f'original-{table}-{org}.json').read_text())['rows']
        before = json.loads((proof / f'pre-destructive-{table}-{org}.json').read_text())['rows']
        actual = json.loads((proof / f'post-destructive-{table}-{org}.json').read_text())['rows']
        regenerated = json.loads((proof / f'fresh-restoration-{table}-{org}.json').read_text())['rows']
        original_by_id = {row['id']: row for row in original}
        assert original_by_id == {row['id']: row for row in before}, (table, org, 'pre-destructive')
        removed = {
            'status_types': '8e154ef9-6825-4fc1-9789-c3079127bf0a',
            'availability_entries': 'dec4e900-5871-4e1b-a305-a91dcc384cab',
            'assignment_types': 'a9330e13-f9e3-43dd-bd02-ea80ff4395ba',
            'daily_assignments': '402e8c8d-f8f9-4b24-b057-576a63be1c51',
        }
        if org == 'A' and table == 'special_days':
            actual_by_id = {row['id']: row for row in actual}
            closure_id = old_fixture['ids']['closureA']
            holiday_id = old_fixture['ids']['holidayCustom']
            assert actual_by_id[closure_id] == original_by_id[closure_id]
            assert holiday_id not in actual_by_id
            assert len(actual) == 45 and sum(row['type'] == 'federal-holiday' for row in actual) == 44
        else:
            expected = {key: row for key, row in original_by_id.items() if org == 'B' or key != removed.get(table)}
            assert expected == {row['id']: row for row in actual}, (table, org, 'post-destructive')
        normalized_sets = []
        for rows, names in [(original, old_names), (regenerated, new_names)]:
            normalized = []
            for row in rows:
                mapped = {}
                for key, value in row.items():
                    if key in ['created_at', 'updated_at']:
                        continue
                    if isinstance(value, str):
                        mapped[key] = names.get(value, value)
                    elif isinstance(value, list):
                        mapped[key] = [names.get(item, item) if isinstance(item, str) else item for item in value]
                    else:
                        mapped[key] = value
                normalized.append(mapped)
            normalized_sets.append(sorted(normalized, key=lambda row: row['id']))
        assert normalized_sets[0] == normalized_sets[1], (table, org, 'regenerated-semantics')
        comparisons.append({'table': table, 'org': org, 'originalCount': len(original), 'postDestructiveCount': len(actual), 'freshCount': len(regenerated), 'preDestructiveFullRowsExact': True, 'postDestructiveOnlyDeclaredEffects': True, 'freshNamedRelationsAndNonGenerationFieldsExact': True})

federal_expected = json.loads((proof / 'federal-reset-corrected-independent-expectations.json').read_text())['expected']
federal_saved = json.loads((proof / 'federal-reset-saved-A.json').read_text())['rows']
federal_reloaded = json.loads((proof / 'federal-reset-reloaded-A.json').read_text())['rows']
assert sorted((row['date'], row['type']) for row in federal_saved if row['type'] == 'federal-holiday') == sorted((row['date'], row['type']) for row in federal_expected)
assert {row['id']: row for row in federal_saved} == {row['id']: row for row in federal_reloaded}
assert len(federal_expected) == 44

bulk_saved = json.loads((proof / 'bulk-two-person-comparison.json').read_text())['newFullRows']
original_a = json.loads((proof / 'original-availability_entries-A.json').read_text())['rows']
original_b = json.loads((proof / 'original-availability_entries-B.json').read_text())['rows']
failure_a = json.loads((proof / 'bulk-remove-real-failure-A.json').read_text())['rows']
failure_b = json.loads((proof / 'bulk-remove-real-failure-B.json').read_text())['rows']
assert {row['id']: row for row in failure_a} == {row['id']: row for row in original_a + bulk_saved}
assert failure_b == original_b
requests = json.loads((proof / 'bulk-remove-real-failure-network.json').read_text())['structuredContent']['networkRequests']
request = [item for item in requests if item['requestId'] == 1746]
assert request == [{'requestId': 1746, 'method': 'GET', 'url': 'http://127.0.0.1:36689/org/undefined/api/calendar-range?rangeStart=2026-10-14&rangeEnd=2026-10-14', 'status': '404', 'selectedInDevToolsUI': False}]
snapshot = (proof / 'bulk-remove-temp-settled.txt').read_text()
assert 'Unable to load status entries for the selected date range. Try again.' in snapshot
assert 'Verification Organization A' in snapshot and '2 of 3 selected' in snapshot

old_doctor = json.loads((proof / 'pre-restart-doctor-final.json').read_text())
new_doctor = json.loads((proof / 'fresh-doctor-final.json').read_text())
assert old_doctor['status'] == new_doctor['status'] == 'PASS'
assert old_doctor['candidate'] == new_doctor['candidate'] == manifest['candidate']
assert old_doctor['session'] == 'cf2eff63-4fdd-4d62-8b58-81e73d4a68fa'
assert new_doctor['session'] == '12fb3ad5-815d-41a9-9357-014d85d0ba8c'
cleanup = json.loads((proof / 'fresh-cleanup.json').read_text())
assert cleanup['status'] == 'PASS' and cleanup['phase'] == 'cleaned'
assert not Path('/home/waffleflops/.local/state/trooptotask-verification/100db5631cfc8c68/worker-2').exists()
ports = []
for port in [36689, 39625]:
    with socket.socket() as client:
        client.settimeout(1)
        code = client.connect_ex(('127.0.0.1', port))
    assert code != 0, port
    ports.append({'port': port, 'listening': False, 'connectResult': code})

inventory = []
for file in sorted(proof.rglob('*')):
    if file.is_file():
        data = file.read_bytes()
        inventory.append({'file': str(file.relative_to(proof)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
receipt = {
    'status': 'PASS for recovery integrity and closure only; baseline remains ISSUES',
    'revision': revision, 'tree': tree, 'candidate': manifest['candidate'],
    'inputEntriesRecomputed': len(manifest['entries']), 'gitClean': True,
    'originalRowsBeforeDestructiveOperations': comparisons,
    'regeneration': {'oldAndNewFixtureUuidSetsDisjoint': True, 'namedFixtureRelationsCompared': len(comparisons), 'excludedFreshGenerationFields': ['created_at', 'updated_at'], 'originalUuidOrTimestampRestorationClaim': False},
    'federalReset': {'actual44DateTypePairsMatchCorrectedIndependentExpectation': True, 'all45FullRowsRetainedAfterReload': True, 'initialIndependentMemorialDayMistakeStillPreserved': True},
    'bulkRemoveFailure': {'request': request[0], 'AFullRowsUnchanged': 8, 'BFullRowsUnchanged': 1, 'dependentRemovalReview': 'BLOCKED'},
    'closure': {'oldSession': old_doctor['session'], 'freshSession': new_doctor['session'], 'bothFinalDoctorsPass': True, 'documentedRestartVerifiedFromSource': 'scripts/verification/cli.mjs cleanup awaits PASS before launch', 'freshCleanup': cleanup, 'workerDirectoryAbsent': True, 'originalAppPorts': ports},
    'rawEvidenceUnchanged': {'payloads': len(inventory), 'bytes': sum(item['bytes'] for item in inventory), 'png': sum(item['file'].endswith('.png') for item in inventory), 'xlsx': sum(item['file'].endswith('.xlsx') for item in inventory), 'entries': inventory},
    'scopeLimits': ['No new native execution', 'No independent model diversity', 'No SQL/RLS/atomicity credit', 'No tracked source edits', 'Report closure addendum missing before recovery'],
}
output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ['originalRowsBeforeDestructiveOperations', 'rawEvidenceUnchanged']}, indent=2))
print(json.dumps({key: value for key, value in receipt['rawEvidenceUnchanged'].items() if key != 'entries'}))
