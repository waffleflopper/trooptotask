import contextlib,hashlib,importlib.util,io,json,pathlib,sys
sys.dont_write_bytecode=True
repository=pathlib.Path.cwd().resolve()
spec=importlib.util.spec_from_file_location('owned_environment',repository/'scripts/verification/environment.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
session=m.private_session(pathlib.Path.home()/'.local/state/trooptotask-verification'/hashlib.sha256(str(repository).encode()).hexdigest()[:16]/'worker-1')
with contextlib.redirect_stdout(io.StringIO()):
 m.status(session);state,workdir,env=m.owned(session);records=m.containers(state,workdir,env)
assert state['repository']==str(repository)
db=[record for record in records if record['Name']=='/supabase_db_'+state['project'] and record['State']['Running']]
assert len(db)==1
worker=json.loads((session/'session.json').read_text());assert worker['phase']=='running' and worker['repository']==str(repository)
def q(sql):return json.loads(m.execute(['docker','exec',db[0]['Id'],'psql','-X','-U','postgres','-d','postgres','-At','-v','ON_ERROR_STOP=1','-c',sql],workdir,env))
fks=q("select json_agg(json_build_object('table',c.relname,'column',a.attname,'on_delete',k.confdeltype)) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum=k.conkey[1] where k.contype='f' and k.confrelid='public.organizations'::regclass and n.nspname='public';")
r=repository/'.verification/evidence/verify-trooptotask/d17-destruction-v3-final'
fixture=json.loads((r/'fixture.json').read_text())
x={'project':state['project'],'session':worker['id'],'candidate':worker['candidate'],'organizations':{}}
ident=lambda v:'"'+v.replace('"','""')+'"'
for org in ['orgA','orgB']:
 oid=fixture['ids'][org];data={}
 for fk in fks:
  table,col=fk['table'],fk['column'];data[table]=q(f"select json_build_object('count',count(*),'ids',coalesce(json_agg(id order by id),'[]'::json),'rows',coalesce(json_agg(to_jsonb(t) order by id),'[]'::json)) from public.{ident(table)} t where {ident(col)}='{oid}'::uuid;")
 x['organizations'][org]={'id':oid,'tables':data,'parent_rows':q(f"select coalesce(json_agg(to_jsonb(t)),'[]'::json) from public.organizations t where id='{oid}'::uuid;")}
x['organization_foreign_keys']=fks
x['storage_objects']=q("select coalesce(json_agg(json_build_object('id',id,'bucket',bucket_id,'path',name,'version',version) order by id),'[]'::json) from storage.objects;")
x['delete_audit']=q(f"select coalesce(json_agg(to_jsonb(t) order by id),'[]'::json) from public.audit_logs t where action='org.deleted' and resource_id='{fixture['ids']['orgA']}';")
mode=sys.argv[1];assert mode in ['cascade-pre-fault','cascade-pre-delete','cascade-partial-delete','cascade-after-delete','cascade-pre-stepup','cascade-after-stepup']
(r/(mode+'.json')).write_text(json.dumps(x,indent=2)+'\n')
if not mode.startswith('cascade-pre-'):
 before=json.loads((r/('cascade-pre-fault.json' if mode=='cascade-partial-delete' else ('cascade-pre-stepup.json' if mode=='cascade-after-stepup' else 'cascade-pre-delete.json'))).read_text());known={}
 for org,d in before['organizations'].items():
  known[org]={}
  for table,v in d['tables'].items():
   ids=v['ids'];condition='false' if not ids else 'id in ('+','.join("'"+i+"'::uuid" for i in ids)+')'
   rows=q(f"select coalesce(json_agg(to_jsonb(t) order by id),'[]'::json) from public.{ident(table)} t where {condition};")
   known[org][table]={'before_count':v['count'],'remaining_count':len(rows),'remaining_rows':rows,'all_values_unchanged':rows==v['rows']}
 (r/('recorded-ids-'+mode+'.json')).write_text(json.dumps(known,indent=2)+'\n')
print(json.dumps({'mode':mode,'row_counts':{org:sum(v['count'] for v in d['tables'].values()) for org,d in x['organizations'].items()},'storage_metadata_count':len(x['storage_objects']),'delete_audit_count':len(x['delete_audit'])}))
