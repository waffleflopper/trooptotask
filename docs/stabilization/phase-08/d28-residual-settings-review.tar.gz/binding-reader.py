import pathlib,json,hashlib,re,subprocess,zipfile,struct
P=pathlib.Path(__file__).parent; R=pathlib.Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93')
load=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
entry=load(P/'entry-inventory.json')
final=P/'d28-residual-settings-final'; base=P/'d28-residual-settings-baseline'
a=load(final/'metadata/entry-source-inventory.json');b=load(final/'metadata/exit-source-inventory.json');assert a==b
bound={x['path']:x for x in b};current=[x for x in entry if x['path'].startswith(('src/','scripts/'))]
assert len(current)==27
for x in current:assert bound[x['path']]==x,(x,bound[x['path']])
observations=[];jwt=[];xls=[];png=[];parsefail=[]
pat=re.compile(rb'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+')
for d in [base,final,P/'d28-residual-settings-checks']:
 for f in sorted(d.rglob('*')):
  if not f.is_file():continue
  data=f.read_bytes(); rel=str(f.relative_to(P))
  if pat.search(data):jwt.append(rel)
  if f.suffix=='.json':
   try:
    j=json.loads(data[data.index(b"{"):] if f.name=="candidate-info.json" else data)
    if isinstance(j,dict) and 'command' in j:
     observations.append({'file':rel,'exit':j.get('exit'),'command':j['command'][:9]})
   except Exception as e:parsefail.append([rel,type(e).__name__])
  if f.suffix=='.xlsx':
   with zipfile.ZipFile(f) as z:
    for name in z.namelist():
     if pat.search(z.read(name)):jwt.append(rel+'!'+name)
    xls.append({'file':rel,'membersScanned':len(z.namelist()),'bytes':len(data),'sha256':sha(data)})
  if f.suffix=='.png':
   assert data[:8]==b'\x89PNG\r\n\x1a\n'
   w,h=struct.unpack('>II',data[16:24]);png.append({'file':rel,'dimensions':[w,h],'bytes':len(data),'sha256':sha(data),'viewedOriginalDetail':True})
print({"jwtPaths":jwt,"parseFailures":parsefail,"PNGs":len(png),"XLSX":len(xls)})
assert not jwt and not parsefail and len(png)==10 and len(xls)==4
out={'sourceInputsEntryExitEqual':len(a),'current27ImplementationFilesMatchNativeExit':True,'implementationInputs':current,'parsedCommandObservations':len(observations),'commandExitNonzero':[x for x in observations if x['exit'] not in [0,None]],'jsonParseFailures':parsefail,'publicJWTMatches':jwt,'scanLimit':'JWT-shaped literal bytes only; no access to excluded private known-secret originals or universal/transcript/OCR claim','workbookMembers':xls,'visuals':png,'visualBounds':'All ten packaged native PNGs actually viewed at original detail; Members viewport is a sample, full64 facts independently decoded; no all-pixel privacy certificate.'}
(P/'source-visual-public-scan.json').write_text(json.dumps(out,indent=2)+'\n')
(P/'all-command-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['implementationInputs','visuals','commandExitNonzero','workbookMembers']},indent=2))
