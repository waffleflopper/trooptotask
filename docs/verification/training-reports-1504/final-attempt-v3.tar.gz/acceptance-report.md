# #1504 final acceptance v3 (owned browser, PR1511)

## Verdict

**FAIL. One blocker: P1 is not fixed, and it now also affects long briefs.** Every Print brief PDF captured in this run ends with a blank portrait page.

- The K1 keyboard focus fix holds with real Enter and held real responses.
- Retry focus, the dated import, the five-sheet workbook, the access spot-check after the #1527 merge, the reverse consumers and restoration all pass.

Following the stopping rule, I took the required P1 captures and one bounded census, then stopped all print-appearance claims that depend on the print stylesheet. This lane certifies only its own live observations. It does not certify the whole task or the source review.

## Identity

- HEAD `068348401a48`, base `ee1ca2b275d7`, worker 1, candidate `cf12aef2…2f0c0d`.
- Origin `http://127.0.0.1:34391`, session `4ff43aa1-0899-40fd-9d53-9fe519862f7e`, Chromium 152.0.7977.82 Arch Linux.
- Doctor PASS at start (`000`) and at the end (`327`), with the same candidate, revision and session.
- Root's untouched originals (`root-*-original.json`) were read before any action. `expectations.md` was written before driving.
- Actor `trainingConfigure` (page 2), Org A `426de6e0…`. Fixture day 2026-10-04; the 90-day horizon ends 2027-01-02.
- Starting state: 1905×2053, `data-theme=light`, `mode-watcher-mode=system`, empty `mode-watcher-theme`, no readable sidebar cookie, preferences `[]`.
- Native `list_pages` returned `structuredContent.pages` (`001`, `328`).

Evidence lives in `.verification/evidence/verify-trooptotask/1504-final-v3/accept/`:

- `receipts/index.jsonl` holds **415 unique receipts**. Each records argv, exit code, time and seconds, with stdout/stderr files.
- Three receipts are nonzero (exit 2). Each was repaired once:
  - `149-wait`: Arrow keys move roving focus in the bits toggle group without selecting. Enter then selected (`154`–`157`).
  - `269-wait`: a text-match miss. The snapshot shows the matrix loaded.
  - `288-click`: empty UID, because the Personnel detail is a page, not a panel. Repaired via the Roster link (`291`–`296`).
- One more misstep produced a 0 exit code. `068`: Shift+Tab ×2 landed on the `25` radio, so that Enter was a no-op: no request, range unchanged. Repaired with a single Tab (`074`).
- Other folders: `snaps/`, `shots/`, `pdf/`, `pdfpages/` (each page rendered at 70 dpi, plus `.info.txt` and `.txt`), and `xlsx/` with decoded JSON alongside each workbook.
- Labels: "READ-ONLY" receipts are rendered or request observations, and `probe`/`fetchxlsx` receipts are ordinary authenticated GETs. Both are kept separate from native interaction.
- No token-bearing file was found (scan for access/refresh tokens, `sb-*-auth-token` and Bearer). Nothing is flagged for redaction.

## Results by path

| # | Path | Result |
|---|---|---|
| 1 | Original report, native cell and focus-link activation, lower-section screenshot | PASS |
| 2 | Dated CSV import, readback, dated briefing and detail, native 5-sheet workbook | PASS |
| 3 | K1 boundary focus, held loading, no-steal, page/initial 503 Retry, 25/100 radios, horizon | PASS |
| 4 | P1 empty Bravo+Targeted print | **FAIL** (blank portrait page 2); census UNAVAILABLE |
| 5 | Loaded 25-row print | **FAIL** (blank portrait page 6); content pages acceptable |
| 5 | Other prints (dated light/dark, Alpha with detail, failed refresh, 1920 collapsed, dark empty) | NOT RUN (stopped as dependent on P1) |
| 5 | 1440/1024/390 keyboard Retry→region, post-print recovery | PASS |
| 6 | Access after main merge (view, scoped, empty, no-lane, foreign) | PASS |
| 7 | Matrix, Personnel cards, Person workbook, Dashboard | PASS for available lanes |
| 8 | Restoration and final doctor | PASS |

## 1. Original report

- **Matrix (`004`):**
  - Able: Required Current, Targeted Not Done.
  - Baker and Unassigned: Required Not Done, Targeted N/A.
  - Optional is N/A for all three.
- **Reports via the visible link (`005`–`007`):**
  - "3 soldiers"; 25% stays 25%; Ready 1, expired 0, not recorded 3, lapse 0.
  - Grid: Bravo 0, Unassigned 0, Alpha 50%; Total Required 33, Total Targeted 0.
  - Type risk: Required 2/0 above Targeted 1/0.
- **Load requests (`008`):** only the page `__data.json` loaded the report. There was no `training-reports` summary fetch, so no duplicate load.
- **Total Required cell (`009`–`012`):** `scope=cell&type=144a0d89…`. Rows were Baker and Unassigned, both Not Done, "Rows 1–2 of 2". `activeElement` was `SECTION#training-affected-soldiers`.
- **Focus link "View 1 soldier" (`014`–`018`):** `scope=focus&focus=gap%3Af97043a4…` returned Able Not Done, and focus went to the SECTION.
- **Screenshot:** `shots/p1-original-cell-detail-full.png`.

## 2. Dated import

- **CSV:** `p2-import.csv` with literal dates: Baker Required 2024-10-04 and Able Targeted 2025-10-19.
- **Preview (`027`):** 2 valid rows, 2 selected. Provider count stayed 1 (`028`).
- **Import (`030`–`034`):** batch POST 200 for both Person IDs. Result: Inserted 2, Updated 0, Exempted 0, Errors 0.
- **New IDs (`039`):**
  - Baker Required `7df5c11b-5c20-4fa4-a209-77269860fd5c`: 2024-10-04 → 2025-10-04.
  - Able Targeted `f7637031-4d59-4dc7-a304-747a86f01528`: 2025-10-19 → 2026-10-19.
- **Matrix after reload (`038`):** Able Targeted "15d left", Baker Required "Expired 365d ago".
- **Dated briefing (`042`):**
  - 50% → 25%, with "loses 25 points"; Ready 2, expired 1, not recorded 1, lapse 1.
  - Alpha × Targeted is 100% and "drops 100 points".
  - Type risk: Required 2/0 above Targeted 0/1.
- **Required Total detail (`045`):** Unassigned Not Done first, then Baker "Expired 365d ago", Oct 4, 2025.
- **Alpha × Targeted (`048`):** Able, 15d left, Oct 19, 2026, Yes.
- **Native export with Alpha × Targeted open (1 row) (`050`–`057`):**
  - GET 200; `training-report-2026-10-04.xlsx`; xlsx MIME; 11859 bytes; SHA `1f08175e…e55d`.
  - Sheets are exactly Summary, Forecast, Hot spots, Focus, Requirements.
  - Requirements has exactly 3 rows: Unassigned Not Done; Baker Expired 2025-10-04; Able 15d left 2026-10-19 / 2026-10-20 / Yes. So the open detail did not narrow the export.
  - This is a proportional smoke test, not a repeat of every v1 variant.

## 3. Pagination, focus and Retry (seed `bca355c4`)

- **Seed:** 26 People, first ID `6d241e8d…` (`058`).
- **Briefing after reload (`061`):** "29 soldiers", 6% → 3%, Ready 2, expired 1, not recorded 28, lapse 1.
- **Required Total (`062`–`065`):** "Rows 1–25 of 28" (MapTraining…00–24).
- **K1 Next to the last page (Enter, response held):**
  - While held (`077`): focus on Next, `aria-busy=true`, "Loading page 2", honest range "Rows 1–25 of 28".
  - After release (`081`): focus on `SECTION#training-affected-soldiers`, "Rows 26–28 of 28", Next disabled.
  - Page 2 rows (`082`): MapTraining…25, Unassigned, Baker. Pages 1 and 2 hold 28 rows with no duplicate or omission.
- **K1 Previous to page 1 (Enter, held):**
  - While held (`089`): focus on Previous, "Loading page 1", range "Rows 26–28".
  - After release (`092`): focus on SECTION, "Rows 1–25 of 28".
- **No-steal case:** Enter on Next was held; Shift+Tab then moved focus to the `25` radio (`100`). After release (`103`), focus stayed on the `25` radio and the page changed to 26–28.
- **Page-change 503:** Enter on Previous got a 503 (`109`–`113`). The alert read "could not be loaded (503). Showing the page that loaded before." The range stayed "Rows 26–28 of 28" and focus stayed on Previous.
  - Shift+Tab reached Retry. Enter with the response held (`118`–`124`): focus was on the SECTION while held, at "Loading page 1".
  - After success: SECTION focus, "Rows 1–25", and the retried request was page 1 (`125`). The synthetic 503 is client-side, so the DevTools list shows only real requests.
- **Initial 503 on Total Targeted (`128`–`143`):** focus on the SECTION; Tab, Tab reached Retry. Enter with the response held kept focus on the SECTION ("Loading affected soldiers"). After success: 2 rows (MapTraining…00 Not Done; Able 15d left), with SECTION focus.
- **Rows per page:** Enter on `100` showed "Rows 1–28 of 28" with focus on the `100` button. Enter on `25` showed "Rows 1–25" with focus on `25` (`154`–`161`).
- **Horizon:** Enter on 180 changed the URL to `?horizon=180` with focus on the `180 D` button; the detail closed. Back to 90 restored an empty query with focus on `90 D` (`163`–`171`).
- **Middle page:** not live; this fixture has only two pages.
- **Seeds:** `clean-seeds` ran and the page reloaded (`178`–`181`). Dated 3-soldier numbers were restored.

## 4–5. Print

The procedure was the same for each case: reload; rebuild the state; `print arm`; native click Print brief; `print state` before save; `print save` of the exact URL from `list_pages` into a new PDF; restore.

### seeded-25-row-detail-light.pdf

- Run `177`; `beforeprint=1` before save; 263343 bytes; SHA `e06321eb…`. Pages are in `pdfpages/seeded-25-row-detail-light-*` and the montage.
- **Pages 1–5** are 792×612 landscape.
  - Page 1: title, subtitle, and the full Filters line beneath the title, followed by the Bottom line.
  - Page 2: Forecast (ticks, Goal 90%, 6%/3% labels, lapse bar) and the Hot-spot grid (legend, ▼50 markers, selected-cell outline).
  - Page 3: Type risk, both Focus areas, and the Affected soldiers heading with its status and "Rows 1–25 of 28".
  - Pages 4–5: 19 and 6 table rows (…00–18 and …19–24), with no clipping.
- No sidebar, header, toolbar, actions, Rows by, page-size radios, Focus links, pagination or Retry appear.
- **Page 6 is 612×792 portrait and fully blank (0 non-white pixels).**
- Historical comparison, read-only: v2's 25-row PDF (`1504-final-v2/accept/pdf/seeded-page1-25rows-light.pdf`) had 5 landscape pages and no blank page. This indicates a regression on long briefs in the current candidate, which includes the polish commit `31024cb0`.

### empty-bravo-targeted-light.pdf

- Filters were set with visible controls: Group Bravo by keyboard in the listbox, and the Targeted type checkbox (`182`–`196`). The empty state read "No applicable requirements for these filters."
- Then reload and print (`197`–`199`): `beforeprint=1`; 70508 bytes; SHA `a90430ac…`.
- **Page 1** is 792×612 and complete: title, "1 soldier · as of 4 Oct 2026", the line "FILTERS · VIEW: ALL TRAINING · GROUP: BRAVO · … · TYPES: VERIFICATION TARGETED TRAINING · HORIZON: 90 DAYS · ROWS BY: GROUP" beneath the title, and the empty message. No app controls appear.
- **Page 2 is 612×792 portrait and blank (0 non-white pixels). P1 persists.**

### Census (bounded, read-only, `200`–`208`)

- **Print-layout heights: UNAVAILABLE.**
  - I installed a passive `matchMedia('print')` change and `beforeprint`/`afterprint` recorder, then natively clicked Print brief (no PDF).
  - Only `beforeprint` fired, under screen media (`print:false`). Chromium never exposed print layout to page script.
  - The recorded values are screen heights only: html, body, `.app`, `sidebar-wrapper` and `sidebar-inset` are all 2053; `#main-content` 1997; report root 373.5.
- **CSSOM census:** the polish rules are loaded. They reset height, min/max-height and overflow on `html:root:has(report)`, `body:has(report)` and `body:has(report) :has(report)`, plus display:block on the three shell slots.
- **Hypothesis for the correction owner, not a fix:** a static, in-flow `SECTION.svelte-11sbg57` is a sibling after `.app`, outside the report root. It is 1905 wide and 0 high, `display:block` and visible, and is likely the toast/notifications region. As in-flow content after the named `training-brief` page, it could force an unnamed default (portrait) page. I made no fix and changed no state.

### Not run, and why

The following were not run, because the stopping rule halts appearance claims that depend on the failing print layout:

- dark empty;
- dated unfiltered light and dark;
- Alpha with open detail;
- the retained failed-refresh alert;
- the 1920 collapsed-sidebar forecast.

Their omission and legibility verdicts await the corrected candidate. Also not run: rendered print of an unchanged page (not certified), and many-type coverage.

### Post-print recovery (`209`–`213`)

- Native Clear filters on the same document restored the full dated briefing; the chart rendered with SVG paths (`shots/post-print-recovery-clear-filters.png`).
- Console messages were limited to the CSP/Vercel-insights 404 noise and one preload warning. There were no LayerCake warnings.
- That document was the empty state, which has no chart, so it **does not qualify** the earlier print-time LayerCake warnings. They remain retained, not cleared.

### Width observations (`214`–`232`)

- At 390×844, 1024×768 and 1440×900: a cell click with a 503 armed, then Tab, Tab to Retry, then Enter. Afterwards focus was on `SECTION#training-affected-soldiers`, "Rows 1–2 of 2", with no alert.
- Screenshots: `shots/k-*-retry-focused.png`, `k-*-region-after-retry.png` and the montage. At 390 the table scrolls inside its container.
- The viewport was restored to 1905×2053.

## 6. Access after main merge #1527

This section separates the visible UI from ordinary authenticated GETs (`probe`).

- **trainingView (page 3):**
  - Visible: the dated A report, 50%/25%, with Export and Print.
  - API: A summary, detail (Baker and Unassigned) and export all 200. B summary and export return a concealed 404 ("Organization not found").
  - Native download: GET 200; 11858 bytes; SHA `c01df296…`; 5 sheets; the 3 dated Requirements.
- **rosterScoped (page 4):**
  - Visible: "1 soldier", 100% → 50%, Ready 2, lapse 1; Alpha and Total cells only; no Baker, Unassigned or Bravo text.
  - API, with A summary/detail/export at 200:
    - Required cell: 0 rows.
    - Explicit `group=Bravo`: 0 soldiers, and its detail has 0 rows.
    - `row=Bravo`: concealed 404 "Training report scope not found".
    - Foreign Group key: normalized to the owned Alpha scope (1 soldier), not B.
    - B: 404.
  - API workbooks (read-only bytes, not native downloads):
    - Default: Requirements lists Able only (SHA `8c1bd632…`).
    - Bravo: Scope "Bravo", 0 soldiers, 0 requirements (SHA `c88fd6da…`). The Group label is visible as a catalog label.
- **trainingEmpty (page 5):**
  - Visible: "0 soldiers", "No applicable requirements.", Export Excel disabled. The disabled button is not a native download.
  - API: summary at 0 soldiers; detail 0 rows; `group=Alpha` stays at 0.
  - API export: 5 ordered sheets, Soldiers 0, Hot spots Total 0, Focus empty text, and Requirements with headers only (SHA `45cf9da6…`).
- **viewer, no Training lane (page 6):**
  - Visible: "403 You don't have permission to view this page."
  - API: summary, detail and export all return 403 "requires Training can view".
  - `__data.json` returns HTTP 200 with the report node `{type:error,status:403}` and no briefing or names.
- **trainingForeign (page 7):**
  - Visible: B only ("1 soldier", Foreign Private Training 0%); no A names or types.
  - API: B summary/detail return 200 with Foreign only. A summary, detail and export return a concealed 404. A Required type on B returns 404. An A group on B normalizes to B's own scope.
  - Native B download: 11468 bytes, SHA `d91de386…`, Foreign row only, 5 sheets.
  - HTTP status: the helper observer binds Org A only, so it was not used. The native DevTools request list on the B page records `GET /org/<B>/api/training-reports/export [200]` (`267`).
- **Not covered:** no completion mutation probes, RLS checks or remote claims were made. A hidden affordance is reported separately from the server responses above.

## 7. Retained consumers

- **Training matrix:** visible after reload as trainingConfigure (`038`, `324`) and as rosterManager (`270`), showing the dated cells.
- **rosterManager → Personnel:**
  - Able Details shows Training "1 due · Verification Targeted Training 15d left."
  - Baker Details shows "1 due · Verification Required Training expired 365d ago."
  - The Availability lane on Able's page read "Availability could not be loaded." This is outside Training scope and recorded only as an observation; it was not investigated.
- **Person workbook (native Export records):** GET 200, `SPC_Able_Synthetic-export-2026-10-04.xlsx`, 9386 bytes, SHA `5627a4ea…`.
  - Sheets: Personnel Info, Training Records, Counseling Records, Availability History. This is a distinct workbook, not a report workbook.
  - Training Records: Required 2026-09-27 / 2027-09-27, and Targeted 2025-10-19 / 2026-10-19 "Verification v3 warning".
- **Dashboard (rosterManager Home):** "1 personnel with expired training · Bravo (1)", "1 training items expiring soon", and "33% training current · 1 expired · 1 expiring". This is a distinct currency meaning from the report's 50%.
- **Not run:**
  - A Personnel reader without Training access.
  - Onboarding and raw Organization export write journeys, and the whole feature map. Their implementations are unchanged and covered only by lower-level tests.

## 8. Restoration

- **Visible deletes as trainingConfigure:** Baker Required and Able Targeted were each removed through Delete → "Delete Training Record". Each DELETE returned 200 (`306`–`321`).
- **Readback after the first delete** shows only `abc75aa0` and `f7637031`. After reload, the matrix matches the original exactly (`324`).
- **Controls:** every network, export and print control was restored. Seeds were cleaned (`178`). Horizon is 90, filters are cleared, and the viewport is 1905×2053.
- **Theme and storage:** light, `mode-watcher-mode=system`, empty theme key, no sidebar cookie. These match the start; theme and sidebar were never changed.
- **Final readbacks (`326-*`) equal root originals exactly** for all of these:
  - `personnel_trainings` A and B (`abc75aa0` unchanged, B empty);
  - `training_types` A and B;
  - `training_views` A and B;
  - `organizations` A and B;
  - trainingConfigure preferences (`[]`).
- **Final doctor PASS** with the exact candidate and session (`327`).
- **Not stopped:** the worker is returned to root. Signed-in actor pages 2–8 remain open for root's cleanup.

## Remaining blockers and limits

1. **P1 (blocker):** every Print brief PDF captured here ends with a blank portrait page, short or long.
   - This is a regression on long briefs versus v2.
   - Print-layout heights could not be observed passively; a CSSOM census and one screen-mode sibling observation are recorded.
   - This needs a correction owner and fresh print proof, including the remaining print cases listed in "Not run, and why".
2. **Historical continuity:** v1 and v2 limits still stand. The full-map Onboarding/raw Organization write flows, Organization/session races, many-type print and unchanged-page rendered print remain unrun.
3. **Print-time LayerCake console warnings:** not qualified by this run.
4. **Unexplained observation:** "Availability could not be loaded" on the rosterManager Personnel detail. It is outside the #1504 contracts and was not investigated.
