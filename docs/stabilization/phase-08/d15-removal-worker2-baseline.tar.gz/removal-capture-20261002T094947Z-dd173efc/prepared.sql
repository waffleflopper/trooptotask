SET statement_timeout = '10s'; SET lock_timeout = '3s';
WITH selected_templates AS (
 SELECT template_id AS id FROM public.personnel_onboardings WHERE organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND id='034a793a-540b-4999-8c88-dddd4b0e00ff'::uuid
 UNION SELECT definition.template_id FROM public.onboarding_template_steps definition
 JOIN public.onboarding_step_progress progress ON progress.template_step_id=definition.id
 WHERE progress.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND progress.id='1645827e-32a5-4a61-9eec-8a2947d9978e'::uuid AND progress.onboarding_id='034a793a-540b-4999-8c88-dddd4b0e00ff'::uuid
 AND definition.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid
)
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND p.id='034a793a-540b-4999-8c88-dddd4b0e00ff'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id',id,'organization_id',organization_id,'group_id',group_id,
 'rank',rank,'first_name',first_name,'last_name',last_name,'slug',slug,'archived_at',archived_at)
 FROM public.personnel WHERE organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND id='0d756bb2-3ca2-4d02-af7a-909e3803e0ea'::uuid),
 'progress', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.onboarding_step_progress p
 WHERE p.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND p.onboarding_id='034a793a-540b-4999-8c88-dddd4b0e00ff'::uuid), '[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.onboarding_templates t
 WHERE t.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND t.id IN (SELECT id FROM selected_templates)), '[]'::json),
 'definitions', COALESCE((SELECT json_agg(d ORDER BY d.id) FROM public.onboarding_template_steps d
 WHERE d.organization_id='fd7f9741-f1ee-4c59-aab3-3b8a037eabc2'::uuid AND d.template_id IN (SELECT id FROM selected_templates)), '[]'::json));
