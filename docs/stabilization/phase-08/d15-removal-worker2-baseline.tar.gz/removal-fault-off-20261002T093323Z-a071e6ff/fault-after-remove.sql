SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'function_marker', obj_description(to_regprocedure('public.t2t_d15_remove_fault_a1a5b24e_ad176e6b()'), 'pg_proc'),
 'function_exists', to_regprocedure('public.t2t_d15_remove_fault_a1a5b24e_ad176e6b()') IS NOT NULL,
 'trigger', (SELECT json_build_object('marker',obj_description(t.oid,'pg_trigger'),
 'function_oid',t.tgfoid::text) FROM pg_trigger t WHERE t.tgrelid='public.onboarding_step_progress'::regclass
 AND t.tgname='t2t_d15_remove_fault_a1a5b24e_ad176e6b' AND NOT t.tgisinternal),
 'function_oid', to_regprocedure('public.t2t_d15_remove_fault_a1a5b24e_ad176e6b()')::oid::text,
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal
 AND tgrelid IN ('public.onboarding_step_progress'::regclass,'public.personnel_onboardings'::regclass)
 AND tgname LIKE 't2t_d15_%'));
