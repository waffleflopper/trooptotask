#!/usr/bin/env bash
# usage: hires.sh LABEL W QUERY  -> native emulate WxH x2, native navigate, measure, DPR2 screenshot cropped to forecast
ROOT=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e
E=$ROOT/.verification/evidence/verify-trooptotask/1503-final-chart-v7; D=$E/driver/d.sh; cd $ROOT
lab=$1; W=$2; q=$3; O=http://127.0.0.1:42057/org/fd246961-a47d-4153-8599-98e413bf9cdb/training/reports
mkdir -p $E/png/hires $E/measure/hires
$D "emulate2-$lab" -- npm run --silent verify:app -- tool emulate "{\"pageId\":2,\"viewport\":\"${W}x2400x2\"}" --worker 1 >/dev/null
$D "nav-$lab" -- npm run --silent verify:app -- tool navigate_page "$(jq -cn --arg u "$O${q:+?$q}" '{pageId:2,type:"url",url:$u}')" --worker 1 >/dev/null
args=$(jq -n --rawfile f "$E/driver/measure.js" --arg fp "$E/measure/hires/$lab.json" '{pageId:2,function:$f,filePath:$fp}')
$D "measure-$lab" -- npm run --silent verify:app -- tool evaluate_script "$args" --worker 1 >/dev/null
$D "shot-$lab" -- npm run --silent verify:app -- tool take_screenshot "{\"pageId\":2,\"filePath\":\"$E/tmp/hi.png\"}" --worker 1 >/dev/null
geo=$(jq -r '.docBox | "\((.w+16)*2|floor)x\((.h+8)*2|floor)+\((.x-8)*2|floor)+\((.y-4)*2|floor)"' $E/measure/hires/$lab.json)
magick $E/tmp/hi.png -crop "$geo" +repage "$E/png/hires/$lab.png"; echo "png/hires/$lab.png"
