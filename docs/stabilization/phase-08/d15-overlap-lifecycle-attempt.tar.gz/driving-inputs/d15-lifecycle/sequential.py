from journeys import *

try:
    seed = control(['seed', 'onboarding-legacy'], 'sequential-legacy-seed')
    packet = seed['packets'][0]['id']
    before = saved_rows('sequential-before')
    # Valid known owned target, ordinary view/empty/foreign identities; malformed requests are not access evidence.
    for role in ['onboardingView', 'onboardingEmpty', 'onboardingForeign']:
        response = ordinary(role, 'onboarding', {'id': packet, 'status': 'cancelled'}, 'sequential-denied-' + role)
        require(response['status'] in [403, 404], response)
    denied_after = saved_rows('sequential-denied-after')
    require(not compare_rows(before, denied_after), compare_rows(before, denied_after))
    native_transition(seed, 'cancelled', 'sequential-native-cancel')
    history(seed, 'cancelled', 'sequential-cancelled-history')
    cancelled, progress = parent_rows(seed, 'sequential-before-reopen')
    response = ordinary('onboardingOperate', 'onboarding', {'id': packet, 'status': 'in_progress'}, 'sequential-api-reopen')
    require(response['status'] == 200, response)
    reopened, retained = parent_rows(seed, 'sequential-after-reopen')
    terminal(reopened, 'in_progress')
    require(retained == progress, 'Reopen changed saved step work/notes/timestamps')
    require(response['body'] == {'id': packet, 'status': 'in_progress', 'cancelledAt': None, 'completedAt': None}, response)
    page = control(['actor', 'onboardingOperate', 'onboarding'], 'sequential-reopened-native-actor')['pageId']
    for iteration in ['first', 'reloaded']:
        if iteration == 'reloaded':
            native('navigate_page', {'pageId': page, 'type': 'reload'}, 'sequential-reopened-native-reload')
        snapshot = snap(page, 'sequential-reopened-native-' + iteration)
        require(seed['person']['last_name'] in snapshot, snapshot)
        screen(page, 'sequential-reopened-native-' + iteration)
    native_transition(seed, 'completed', 'sequential-native-complete')
    history(seed, 'completed', 'sequential-completed-history')
    terminal_before = saved_rows('sequential-terminal-before')
    for status in ['completed', 'cancelled', 'in_progress']:
        response = ordinary('onboardingOperate', 'onboarding', {'id': packet, 'status': status}, 'sequential-invalid-' + status)
        require(response['status'] == 400, response)
    after = saved_rows('sequential-final')
    require(not compare_rows(terminal_before, after), compare_rows(terminal_before, after))
    require(not compare_rows(before, after, packet), compare_rows(before, after, packet))
    write(E / 'sequential-outcome.json', json.dumps({'result': 'PASS', 'scope': 'Native Cancel and incomplete-step Complete confirmations, API Reopen, saved History/reloads, valid ordinary denials and invalid terminal repeats',
        'dismissalsHaveNoWrites': True, 'onlyTargetStatusDatesChanged': True,
        'reopenIsAPIOnly': True, 'wholeIssueRemaining': True}, indent=2) + '\n')
    print('Valid Cancel → API Reopen → incomplete-step Complete, denials and terminal repeats pass.', flush=True)
except BaseException as error:
    write(E / 'sequential-driver-failure.json', json.dumps({'result': 'FAIL' if isinstance(error, ObservedFailure) else 'INCONCLUSIVE', 'reason': type(error).__name__,
        'message': str(error), 'action': 'Preserve observations and finish owned cleanup; no automatic mutation retry'}, indent=2) + '\n')
    raise
