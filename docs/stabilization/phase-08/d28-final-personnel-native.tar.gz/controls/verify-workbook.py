import current as x
import json,zipfile,xml.etree.ElementTree as X,re,hashlib
p=x.d.E/'personnel-records.xlsx';seed=json.loads((x.c/'seed.json').read_text());ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(p) as z:
 for n in z.namelist():assert not n.startswith('/') and '..' not in __import__('pathlib').PurePosixPath(n).parts;z.read(n)
 strings=[''.join(n.itertext()) for n in X.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
 names=[n.attrib['name'] for n in X.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',ns)];assert names==['Personnel Info','Training Records','Counseling Records','Availability History']
 sheets=[]
 for i,width in enumerate([2,4,7,3],1):
  rows=[]
  for r in X.fromstring(z.read(f'xl/worksheets/sheet{i}.xml')).findall('s:sheetData/s:row',ns):
   cells={}
   for c in r.findall('s:c',ns):
    ref=re.match('[A-Z]+',c.attrib['r'])[0];index=0
    for a in ref:index=index*26+ord(a)-64
    v=c.find('s:v',ns);value=v.text if v is not None else None
    if c.attrib.get('t')=='s':value=strings[int(value)]
    if c.attrib.get('t')=='inlineStr':value=''.join(c.find('s:is',ns).itertext())
    cells[index-1]=None if value=='' else value
   assert max(cells,default=-1)<width;rows.append([cells.get(k) for k in range(width)])
  sheets.append(rows)
info=[['Field','Value'],['Rank','SPC'],['Last Name',seed['name']],['First Name','Synthetic'],['MOS','68W'],['Duty Role','Medic'],['Group','Alpha'],['ETS',None],['PCS / DEROS',None],['Archived At',None],['Emergency Contact Name','Synthetic Contact'],['Emergency Contact Relationship','Sibling'],['Emergency Contact Phone','555-0101'],['Spouse Name','Synthetic Spouse'],['Spouse Phone','555-0102'],['Vehicle Make/Model','Synthetic Sedan'],['Vehicle Plate','VFY1376'],['Vehicle Color','Blue'],['Personal Email','sheet@example.invalid'],['Personal Phone',None],['Address','1 Test Street, Test City, AK, 99501'],['Leader Notes',None]]
training=[['Training Type','Completed Date','Expiration Date','Notes'],['Verification Required Training','2026-09-14',None,None]]
counselHeader=['Date','Subject','Key Points','Plan of Action','Status','Follow-Up Date','Notes'];new=['2026-10-07',x.run['tag']+' counseling',None,None,'completed',None,'Literal counseling summary'];historical=[['2026-09-14',kind+' counseling '+seed['tag'],None,None,'draft',None,None] for kind in ['Active','Archived']]
assert sheets[0]==info and sheets[1]==training and sheets[2][0]==counselHeader and sheets[2][1]==new and sorted(sheets[2][2:],key=lambda r:r[1])==sorted(historical,key=lambda r:r[1]) and sheets[3]==[['Status','Start Date','End Date']]
assert [len(s)-1 for s in sheets]==[21,1,3,0]
(x.d.E/'workbook-literal-comparison.json').write_text(json.dumps({'status':'PASS','xlsxSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'sheets':names,'allObservedCells':dict(zip(names,sheets)),'expectedLiteralInfo':info,'expectedLiteralTraining':training,'expectedLiteralCounseling':[counselHeader,new,*historical],'expectedLiteralAvailability':[['Status','Start Date','End Date']],'comparison':'Complete values, headers, sheet set and new-first date order. Historical tied rows compared as literal rows. No counts-only acceptance.','contactAndAddressInputs':14,'dataRows':[21,1,3,0],'blankSemantics':'Absent/empty XLSX cells normalize to null.','availabilityScope':'Owner export of this same Person has no seeded availability; not an ordinary Calendar-none permission proof.','legacyLeaderNotes':'Blank retained; separate artifact notes have no additional sheet.'},indent=2));print('Complete four-sheet literal comparison PASS')
