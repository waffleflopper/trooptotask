# D12 #1360 redacted bulk conflict lower-level baseline

Base: f58d9891409427afea52183da6ee1e65e622860b. Isolated worker /tmp/t2t-1360-personnel-batch-redacted; production source unchanged for baseline.

Independently specified expected behavior: a scoped Alpha actor may import valid Alpha rows whose canonical URL is already held by hidden Bravo; only the colliding URL advances numerically. Preserve unrelated planned URLs, hidden full rows and unique Person IDs. Recover acknowledged subset results with original submitted indices; no uncertain-write retry or false no-effect promise. Isolated candidate attempts are bounded at three; failed attribution/sub-batch probes are separately counted. Healthy 500 rows require one bulk call. The declared preimplementation performance budget is at most 24 insert calls for 500 valid rows with one hidden collision and an available next suffix.

Provider model: read returns fresh copies of Alpha-only rows; write validates the entire statement's Organization uniqueness before any persistence, then returns fresh acknowledged copies. Named conflict DETAIL is null, undefined or empty. An injected lost response happens after singleton persistence, independently proving unconfirmed rather than failed-no-effect behavior. These are offline controlled reproductions, not PostgreSQL/RLS proof.

Root native a760 scoped two-row bulk returned generic HTTP500 saving neither. Root's sanitized app log confirms the exact named unique constraint; it does not expose DETAIL. Therefore actual absent DETAIL is inferred, not observed raw metadata. Lower-level baseline establishes the supported missing/null/empty case is broken.

Node24.21.0; npm11.19.0; Vitest4.1.8. Dependencies installed offline with npm ci --offline --ignore-scripts (0 vulnerabilities); existing package requires npm11.12.1 and installer reports EBADENGINE warning for11.19.0. No services/browser/database/remote calls.

Command: PUBLIC_SUPABASE_URL=http://127.0.0.1:1 PUBLIC_SUPABASE_ANON_KEY=offline-anon-key npm test -- src/features/personnel/personnelBatch.server.test.ts src/features/personnel/personnelSlug.server.test.ts src/lib/server/adapters/supabaseDataStore.test.ts
Result: exit1; 8 failed /44 passed across3 files. All eight redacted recovery cases throw the named constraint before delivering results; adapter null metadata and existing detailed candidate protection pass. Complete output: /tmp/t2t-1360-personnel-batch-redacted-baseline.txt. Baseline-only commit follows in worker Git history.
