SELECT json_build_object('event', 'identity', 'pid', pg_backend_pid(),
 'backend_start', (SELECT backend_start::text FROM pg_stat_activity WHERE pid = pg_backend_pid()));
BEGIN;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '3s';
SET LOCAL idle_in_transaction_session_timeout = '90s';
SELECT json_build_object('event', 'locked', 'id', id) FROM public.onboarding_step_progress
WHERE organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND id = '44b5158a-f36a-476b-abf3-29dce711c33c'::uuid AND onboarding_id = '1932420d-b8fa-4c4d-999b-65563125fdd0'::uuid AND template_step_id IS NULL AND step_name = 'Orientation' AND step_type = 'checkbox' AND completed AND active AND current_stage IS NULL AND training_type_id IS NULL AND stages IS NULL AND notes = '[{"text": "Legacy retained work 76b599cf", "timestamp": "2000-01-01T12:00:00.000Z", "userId": "edbe6a5a-2227-4ff0-86b6-9aac8d0e8b0c"}]'::jsonb
FOR UPDATE;
SELECT json_build_object('event', 'ready');
