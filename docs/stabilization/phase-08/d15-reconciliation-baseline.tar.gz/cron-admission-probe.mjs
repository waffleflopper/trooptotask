import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const session = '/home/waffleflops/.local/state/trooptotask-verification/a366bf80061ca8bc/worker-1';
const root = '.verification/evidence/verify-trooptotask/d15-reconciliation-baseline';
const state = JSON.parse(await fs.readFile(session + '/session.json', 'utf8'));
assert.equal(state.repository, process.cwd());
assert.equal(state.phase, 'running');
assert.equal(state.id, '8b50919d-2e94-4189-bc91-a8e80525cb94');
assert.equal(state.origin, 'http://127.0.0.1:44353');
const credential = JSON.parse(await fs.readFile(session + '/archive-cleanup.json', 'utf8'));
const url = new URL('/api/cleanup-expired-onboardings', state.origin);
const results = [];
for (const mode of ['missing', 'wrong', 'run']) {
	const headers = mode === 'missing' ? {} : { authorization: 'Bearer ' + (mode === 'wrong' ? 'synthetic-incorrect-secret' : credential.secret) };
	await fs.writeFile(root + '/admission-' + mode + '-input.json', JSON.stringify({ method: 'GET', url: url.href, redirect: 'manual', authorization: mode === 'run' ? 'owned generated credential withheld' : mode === 'wrong' ? 'Bearer synthetic-incorrect-secret' : null }, null, 2) + '\n');
	const response = await fetch(url, { headers, redirect: 'manual', signal: AbortSignal.timeout(30000) });
	results.push({ mode, status: response.status, location: response.headers.get('location'), body: await response.text() });
}
await fs.writeFile(root + '/cron-admission-results.json', JSON.stringify(results, null, 2) + '\n');
console.log(JSON.stringify(results));
