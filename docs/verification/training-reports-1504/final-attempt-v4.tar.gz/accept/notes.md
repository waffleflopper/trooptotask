NEW IDS: baker-required a6436f5f-acb5-4c17-9f69-ecbd5c919c57 ; able-targeted 3cebfc94-d159-4493-ae7a-d2c03ee8c6d3 (receipt 038)
MISSTEP 088: Clear filters UID extraction matched two buttons ("33_26 33_41") -> click failed; filters stayed Bravo+Targeted.
  Consequence: pdf/dated-unfiltered-dark.pdf (093, beforeprint=1) is MISLABELED: it is a second native-invoked EMPTY Bravo+Targeted DARK render (1 landscape page). Kept as-is; counted as an empty-dark repeat, not the unfiltered case. Repaired at 094+ with corrected file name dated-unfiltered-dark-r1.
OBS 139-142: Toggle Sidebar collapse wrote cookie sidebar:state=false but after native reload the sidebar rendered expanded (data-state=expanded). Outside #1504; recreated collapse after reload (143).
STEP5 cohort1 c984f780: focus on Next before clean (182)
FINDING 235-236: native click on already-checked '25 rows per page' toggle clears its checked state (snapshot shows neither 25 nor 100 checked) with no request; table remains 25/page. Also explains unchecked radios after edges 1/2 (my focus-only clicks 175/207). Minor a11y state mismatch.
295: first Alt+T after toast expiry (toastsLeft 0) -> focus stayed on Save; repaired once at 296+
301: toast present but Alt+T focus stayed on Save: modal Edit dialog open (focus trap confound). One bounded attempt 302+: Save(fail)->Cancel->Alt+T.
MISSTEP 337-338: confirm UID grep empty -> confirm click failed (no DELETE, calls []). Repaired 344+.
