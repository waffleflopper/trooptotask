import pathlib,json,sys,datetime
r=pathlib.Path(__file__).resolve().parent
before,after,kind=sys.argv[1:];tables=json.loads((r/'original-table-selection.json').read_text())
status={'status_types':{'ea93747a-6f76-497f-913b-cd8c78c552d5'},'availability_entries':{'31af3880-2e18-4b4a-a43f-435471c4b310'}}
assignment={'assignment_types':{'78455c53-855d-4525-8533-4b16cefeb8cb'},'daily_assignments':{'7ec3ab0c-d085-4d90-b7ce-88c2ef1bc192'}}
federal={'special_days':{'bfa45a6b-b3de-4b8f-ba86-727ec02ae1a4'}}
expected={'status':status,'assignment':assignment,'federal':federal}[kind];out={'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':before,'after':after,'kind':kind,'checks':{},'changes':[]}
def rows(p,t,o):return json.loads((r/f'{p}-{t}-{o}.out').read_text())['rows']
for t in tables:
 for o in ['orgA','orgB']:
  b={x['id']:x for x in rows(before,t,o)};a={x['id']:x for x in rows(after,t,o)};removed=set(b)-set(a);added=set(a)-set(b);changed=[{'before':b[k],'after':a[k]}for k in set(a)&set(b)if a[k]!=b[k]];want=expected.get(t,set())if o=='orgA'else set();allowadded=o=='orgA'and(t in ['notifications','audit_logs']or(kind=='federal'and t=='special_days'))
  out['checks'][f'exactEffect-{t}-{o}']=removed==want and not changed and (not added or allowadded)
  if removed or added or changed:out['changes'].append({'table':t,'organization':o,'removed':[b[k]for k in sorted(removed)],'added':[a[k]for k in sorted(added)],'changed':changed})
admins={x['user_id']for x in rows(before,'organization_memberships','orgA')if x['role']in ['owner','admin']}
new=lambda t:[x for c in out['changes']if c['table']==t and c['organization']=='orgA'for x in c['added']]
if kind in ['status','assignment']:
 ns=new('notifications');title='Status Type Deleted'if kind=='status'else'Assignment Type Deleted';out['checks']['exactAdminNotifications']=len(ns)==len(admins)and {x['user_id']for x in ns}==admins and all(x['title']==title and x['type']=='config_type_deleted'for x in ns)
if kind=='status':
 audit=new('audit_logs');out['checks']['exactStatusAudit']=len(audit)==1 and audit[0]['action']=='status_type.deleted'and audit[0]['resource_id']=='ea93747a-6f76-497f-913b-cd8c78c552d5'
if kind=='federal':
 ns=[x for x in rows(after,'special_days','orgA')if x['type']=='federal-holiday'];expect=json.loads((r/'p10-independent-holiday-expectations-v2.json').read_text())['expected'];proj=lambda x:(x['date'],x['name'],x['type']);out['checks']['exact44FederalDatesNamesTypes']=len(ns)==44 and sorted(map(proj,ns))==sorted(map(proj,expect));out['actualFederalRows']=ns
out['allChecksPass']=all(out['checks'].values());(r/(after+'-independent-comparison.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'allChecksPass':out['allChecksPass'],'failed':[k for k,v in out['checks'].items()if not v],'changes':[{k:(len(v)if isinstance(v,list)else v)for k,v in c.items()}for c in out['changes']]}));sys.exit(0 if out['allChecksPass']else 1)
