from drive import *
page=json.loads((E/'page-id.json').read_text())['pageId']; tag=json.loads((E/'legacy-seed.json').read_text())['tag']
s=snap(page,'cleanup-close-card-before'); click(page,uid(s,'button "Close"'),'cleanup-close-card')
s=snap(page,'cleanup-templates-nav-before'); click(page,uid(s,'link "Templates"'),'cleanup-templates-nav')
s=snap(page,'cleanup-A-before'); click(page,uid(s,'button "Delete D15 Assignment Race A '+tag+'"'),'cleanup-A-open')
print(snap(page,'cleanup-A-confirm'))
