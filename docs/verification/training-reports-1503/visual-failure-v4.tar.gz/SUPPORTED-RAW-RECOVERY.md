# Supported raw recovery after failed v4

Root recovered 303 actual preview tool input/output records from the task's durable T3 activity through `t3_thread_read`. Truncated items were continued by their exact itemId/textOffset until complete. No private host or provider session store was accessed. The unchanged input/output JSON text is saved under `supported-raw/`; the source thread, original timeline positions/item IDs, tool names and update times are indexed in `supported-raw-index.json`.

`SUPPORTED-RAW-AUDIT.json` records every recovered byte hash. Root parsed every complete JSON, bound its tool name to the unique index and scanned all records for credential patterns with no matches. This verifies actual record recovery and packaging integrity, not a passing UI verdict. Existing screenshots, scripts, workbook and old driver notes retain their original bytes.

The earlier `raw/tool-log.jsonl` remains hand-transcribed/condensed. Its qualification in `NOTES.md`, `DRIVER-REPORT.md` and `ROOT-CLOSEOUT.md` applies to that original file. It does not apply to the separately recovered supported raw records. These new records preserve all observed successes, tool failures, unconfirmed sign-out and the remaining failed goal95 case. Failed visual acceptance remains failed.

This recovery augments the same closed candidate361e8c6f/sessionb78667b7 run. It is not another live execution. The initial unpublished 94-payload archive and fresh extraction remain in ignored scratch; the durable archive is repackaged with these additional observations and a new inventory/hash, with all original94payloadbytes preserved.
