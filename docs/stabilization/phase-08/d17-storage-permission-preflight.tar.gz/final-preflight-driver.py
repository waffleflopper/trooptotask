import importlib.util, json, shutil, signal, tempfile, uuid, tomllib, sys
from pathlib import Path
fresh="--fresh" in sys.argv
repo=Path("/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-c1e9d360")
spec=importlib.util.spec_from_file_location("database",repo/"scripts/ci/database.py")
db=importlib.util.module_from_spec(spec);spec.loader.exec_module(db)
def interrupted(signum, frame): raise SystemExit(128+signum)
for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupted)
workdir=Path(tempfile.mkdtemp(prefix="t2t-d17-storage-preflight-"))
project="t2t-d17-preflight-"+uuid.uuid4().hex[:12]
config=tomllib.loads((repo/"supabase/config.toml").read_text())
held=db.reserve_ports(len(list(db.port_fields(config))))
env=db.local_docker_environment(repo);started=False;runner_started=False
runner="supabase_pgprove_"+project
try:
 ports=[s.getsockname()[1] for s in held]
 db.prepare_project(repo,workdir,project,ports)
 for f in Path("/tmp/d17-storage-draft").glob("*.sql"):
  if not f.name.startswith("2026"):shutil.copy2(f,workdir/"supabase/migration-tests"/f.name)
 print(json.dumps({"project":project,"directory":str(workdir),"ports":ports,"base": "fc463830", "scope":"populated current predecessor plus drafted owner Storage permission; SQL metadata only"}),flush=True)
 for s in held:s.close()
 started=True
 db.run(["supabase","start","--exclude",db.EXCLUDED_SERVICES],workdir,quiet=True,environment=env)
 container="supabase_db_"+project
 psql=["docker","exec","-e","PGPASSWORD=postgres",container,"psql","-U","supabase_admin","-d","postgres","-v","ON_ERROR_STOP=1"]
 db.run([*psql,"-c","SHOW server_version;","-c","ALTER SYSTEM SET supautils.hint_roles = '';","-c","SELECT pg_reload_conf();"],workdir,environment=env)
 if not fresh: db.run([*psql[:2],"-i",*psql[2:]],workdir,environment=env,input_text=(workdir/"supabase/migration-tests/organization_storage_cleanup_before.sql").read_text())
 shutil.copy2("/tmp/d17-storage-draft/20261002001000_organization_storage_cleanup.sql",workdir/"supabase/migrations/20261002001000_organization_storage_cleanup.sql")
 db.run(["supabase","migration","up","--local","--yes"],workdir,environment=env)
 runner_started=True
 for repetition in range(2 if fresh else 1):
  db.run(["docker","run","--rm","--name",runner,"--network","supabase_network_"+project,"--mount",f"type=bind,src={workdir / 'supabase'},dst=/tests,readonly","-e","PGHOST=db","-e","PGPORT=5432","-e","PGUSER=postgres","-e","PGPASSWORD=postgres","-e","PGDATABASE=postgres",db.PG_PROVE_IMAGE,"pg_prove","--verbose","/tests/migration-tests/organization_storage_cleanup_"+("fresh" if fresh else "after")+".sql"],workdir,environment=env)
 print("D17 targeted populated SQL preflight passed.",flush=True)
finally:
 for s in held:s.close()
 for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,signal.SIG_IGN)
 if runner_started:db.run(["docker","rm","--force",runner],workdir,quiet=True,check=False,environment=env)
 if started:db.run(["supabase","stop","--project-id",project,"--no-backup"],workdir,environment=env)
 shutil.rmtree(workdir)
 print("Cleaned exact disposable project "+project,flush=True)
