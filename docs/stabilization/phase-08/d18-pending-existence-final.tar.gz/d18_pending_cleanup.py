import sys,json,uuid
sys.path.insert(0,'.verification');import d18_ui as v,d18_final as f
seed=f.read('03-source-seed');ids={value for sources in seed['sources'].values() for key,value in sources.items() if key!='label'};assert len(ids)==12 and all(str(uuid.UUID(value))==value for value in ids)
for page in [2,3]:
 for family in ['network','feedback']:v.helper(f'20-restore-{page}-{family}',family,'restore',str(page))
clear=v.helper('21-check-clear','deletion-review-failure','state');assert clear['phase']=='clear' and clear['armed'] is False
r=v.helper('22-owned-source-cleanup','clean-seeds');assert r['cleaned'] is True
f.capture('23-after-cleanup');comparisons=[]
for org in ['orgA','orgB']:
 for table in f.TABLES:
  sort=lambda rows:sorted(rows,key=lambda r:r['id']);before=f.read('original-'+org+'-'+table)['rows'];after=f.read('23-after-cleanup-'+org+'-'+table)['rows'];assert sort(before)==sort(after),(org,table)
  assert not any(row.get('id') in ids or row.get('resource_id') in ids for row in after),(org,table)
  comparisons.append({'organization':org,'table':table,'exactOriginalProjection':'PASS','temporarySourceTargetHistoryAbsent':True})
f.file_capture('24-after-cleanup-pdf','03-source-seed');paths=[]
for org in ['orgA','orgB']:
 r=f.read('24-after-cleanup-pdf-'+org+'-files');parent=seed['sources'][org]['parent'];expected=next(file['path'] for file in seed['files'] if '/'+parent+'/' in file['path']);assert len(r['files'])==1 and r['files'][0]['path']==expected and r['files'][0]['present'] is False and all(rows==[] for rows in r['tables'].values());paths.append(expected)
(v.root/'25-cleanup-comparison.json').write_text(json.dumps({'status':'PASS','temporaryCanonicalSourceArtifactIdsAbsent':12,'allTargetingRequestHistoryAbsent':True,'originalProjectionSetsExact':20,'actualRecordedPdfPathsAbsent':paths,'comparisons':comparisons},indent=2)+'\n')
v.call('26-final-doctor','tool','doctor');assert f.read('01-launch')==f.read('26-final-doctor')
v.call('27-owned-disposal','tool','cleanup');assert f.read('27-owned-disposal')['status']=='PASS';print('PASS12UUID/targetingrequestabsence20originalsets2actualPDFabsence frozen doctor and disposal',flush=True)
