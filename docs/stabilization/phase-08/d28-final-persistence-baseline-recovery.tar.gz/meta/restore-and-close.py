import pathlib,json,hashlib,subprocess,sys
c=pathlib.Path(__file__).parent;sys.path.insert(0,str(c));import native_driver as d
e=d.E
seed=json.loads(json.loads((e/'lifecycle-seed.json').read_text())['stdout'])['ids'];ids=set(seed.values())
ledger=json.loads((e/'generated-cleanup-ledger.json').read_text());temporary=ids|set(ledger['nativeCreated'].values())|set(ledger['sds'])
before=json.loads((c/'original-full-private-full.json').read_text())['rows'];after=json.loads((c/'restored-full-private-full.json').read_text())['rows'];comparisons=[];count=0
for org,ts in before.items():
 for table,rows in ts.items():
  if table=='audit_logs':continue
  original=[r for r in rows if r['id'] not in ids];count+=len(original)
  assert original==after[org][table],(org,table)
  assert not any(r['id'] in temporary for r in after[org][table]),(org,table,'temporary retained')
  comparisons.append(dict(organization=org,table=table,originalRows=len(original),status='PASS'))
assert count==27
(e/'restoration-assertions.json').write_text(json.dumps(dict(status='PASS',fullOriginalRows=count,businessComparisons=comparisons,temporaryIDs=sorted(temporary),readerExcludedCriticalTaskId=seed['criticalTask'],criticalTaskCleanup='Recorded journal/helper clean-seeds receipt; table outside finite 13-table reader',auditRows={org:len(ts['audit_logs']) for org,ts in after.items()},chronology='First full capture after INSERT-only seed and before native writes; original 27 derived by exact journal ID exclusion, not a live preseed capture',allCapturedFieldsKeysTimestampsExact=True,storageCleanup='cleanup-stored-files receipt',remainingUntilDisposal='21 legitimate orgA audit rows'),indent=2))
entry=json.loads((c/'entry-source-inventory.json').read_text());out=[]
for row in entry:
 p=pathlib.Path(row['path']);data=p.read_bytes();out.append(dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert out==entry,'Tracked input drift'
controls=json.loads((c/'control-copy-inventory.json').read_text());print('control inventory shape',type(controls).__name__)
for file,expected in [('native_driver.py','9476223fea40d15058176a725171973d9bd271135f96128d9d9b3271722ad4df'),('full-rows.py','30780f00044a03c619f0a27177af76c4e0c9ff50a2766a2afffc11dab8a04260'),('resource-receipt.py','3cdd99e5a59f56e152c891224b98c31db29f29f542d8f6838494d0e4cb69813b')]:assert hashlib.sha256((c/file).read_bytes()).hexdigest()==expected
(e/'final-freeze.json').write_text(json.dumps(dict(status='PASS',trackedCount=len(entry),sourceInventorySha256=hashlib.sha256((c/'entry-source-inventory.json').read_bytes()).hexdigest(),controlsExact=3,candidate='7d8da9bf96bb7af41c7f9d7e848aef87085d88c3b9daed35195923c9f912ac4d',gitStatus=subprocess.check_output(['git','status','--short'],text=True)),indent=2))
d.call('final-helper-state',['state'],True)
d.call('final-doctor',['doctor'])
subprocess.run(['python3',str(c/'resource-receipt.py'),'before'],check=True)
d.call('owned-cleanup',['cleanup'])
subprocess.run(['python3',str(c/'resource-receipt.py'),'after'],check=True)
