import importlib.util,json,pathlib,sys
p=pathlib.Path('scripts/verification/environment.py').resolve();spec=importlib.util.spec_from_file_location('owned_environment',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/80ad0b6c7cddb4c6/worker-1');m.status(session);state,workdir,env=m.owned(session)
def q(sql):return json.loads(m.execute(['docker','exec','supabase_db_'+state['project'],'psql','-U','postgres','-d','postgres','-At','-v','ON_ERROR_STOP=1','-c',sql],workdir,env))
fks=q("select json_agg(json_build_object('table',c.relname,'column',a.attname,'on_delete',k.confdeltype)) from pg_constraint k join pg_class c on c.oid=k.conrelid join pg_namespace n on n.oid=c.relnamespace join pg_attribute a on a.attrelid=c.oid and a.attnum=k.conkey[1] where k.contype='f' and k.confrelid='public.organizations'::regclass and n.nspname='public';")
r=pathlib.Path('.verification/evidence/verify-trooptotask/d17-settings-followup');fixture=json.loads((r/'fixture.json').read_text());x={'project':state['project'],'organizations':{}}
ident=lambda v:'"'+v.replace('"','""')+'"'
for org in ['orgA','orgB']:
 oid=fixture['ids'][org];data={}
 for fk in fks:
  table,col=fk['table'],fk['column'];data[table]=q(f"select json_build_object('count',count(*),'ids',coalesce(json_agg(id order by id),'[]'::json),'rows',coalesce(json_agg(to_jsonb(t) order by id),'[]'::json)) from public.{ident(table)} t where {ident(col)}='{oid}'::uuid;")
 x['organizations'][org]={'id':oid,'tables':data}
x['organization_foreign_keys']=fks
x['storage_objects']=q("select coalesce(json_agg(json_build_object('id',id,'bucket',bucket_id,'path',name) order by id),'[]'::json) from storage.objects;")
(r/(sys.argv[1]+'.json')).write_text(json.dumps(x,indent=2)+'\n');print(sys.argv[1], {org:sum(v['count'] for v in d['tables'].values()) for org,d in x['organizations'].items()},'file metadata:',len(x['storage_objects']))

if sys.argv[1] == 'cascade-after-delete':
 before=json.loads((r/'cascade-pre-delete.json').read_text());known={}
 for org,d in before['organizations'].items():
  known[org]={}
  for table,v in d['tables'].items():
   ids=v['ids'];condition='false' if not ids else 'id in ('+','.join("'"+i+"'::uuid" for i in ids)+')'
   rows=q(f"select coalesce(json_agg(to_jsonb(t) order by id),'[]'::json) from public.{ident(table)} t where {condition};")
   known[org][table]={'before_count':v['count'],'remaining_count':len(rows),'remaining_rows':rows,'all_values_unchanged':rows == v['rows']}
 (r/'recorded-ids-after-delete.json').write_text(json.dumps(known,indent=2)+'\n')
 print('Exact previously recorded IDs:',{org:sum(v['remaining_count'] for v in d.values()) for org,d in known.items()})
