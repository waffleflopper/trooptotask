// Scratch-only coordinator runner. It does not execute unless explicitly passed --execute.
// Never retries requests. Uses only documented owned helper commands and captures both streams.
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { buildPlan, tables, families } from './plan.mjs';
const [mode, configFile] = process.argv.slice(2);
if (!['--plan', '--execute'].includes(mode) || !configFile) throw new Error('Use --plan CONFIG or, after coordinator approval, --execute CONFIG.');
const config = JSON.parse(await fs.readFile(configFile, 'utf8'));
const plan = buildPlan();
if (mode === '--plan') {
  console.log(JSON.stringify({ config, requests: plan.filter(s => s.kind === 'request').length, steps: plan }, null, 2));
  process.exit(0);
}
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
if (!['1', '2'].includes(config.worker) || !/^[a-f0-9]{64}$/.test(config.candidateDigest)) throw new Error('Supply exact worker and complete frozen candidate digest.');
if (!config.tag || /[<>]/.test(config.tag) || config.defaultCapBytes !== 104857600) throw new Error('Supply a unique tag and preserve the verified 100 MiB fixture cap.');
if (!uuid.test(config.organizationIds?.orgA) || !uuid.test(config.organizationIds?.orgB) || !uuid.test(config.alphaGroupId)) throw new Error('Supply public current Organization A/B and Alpha Group UUIDs.');
if (Object.values(config.people).some(id => !uuid.test(id)) || new Set(Object.values(config.people)).size !== 5) throw new Error('Supply five distinct current fixture/seed Person UUIDs.');
const repo = await fs.realpath(config.repository);
const evidenceBase = await fs.realpath(path.join(repo, '.verification/evidence/verify-trooptotask'));
const run = path.resolve(repo, config.runDirectory);
if (!run.startsWith(evidenceBase + path.sep)) throw new Error('Run must remain inside the owned evidence root.');
await fs.mkdir(run, { recursive: true, mode: 0o700 });
if (await fs.realpath(run) !== run) throw new Error('Use a real run directory, not an alias.');
try { await fs.access(path.join(run, 'runner-started.json')); throw new Error('This runner is single-use; review existing outcomes, never blindly rerun mutations.'); }
catch (error) { if (error.code !== 'ENOENT') throw error; }
const write = (name, value) => fs.writeFile(path.join(run, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
await write('runner-started.json', { boundary: 'Direct ordinary HTTP plus separately identified privileged readback; no native or SQL claim.', startedAt: new Date().toISOString(), config, plan });
const executedSources={};
for(const name of ['run.mjs','plan.mjs']) { const bytes=await fs.readFile(new URL('./'+name,import.meta.url)); await fs.writeFile(path.join(run,'executed-'+name),bytes,{flag:'wx',mode:0o600}); executedSources[name]={bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}; }
await write('runner-source-manifest.json',executedSources);
const state = { ...config, created: {} };
const knownPaths = Object.fromEntries(Object.keys(config.people).map(key => [key, new Map()]));
const snapshots = {};
const statuses = {};
const createFacts=[];
const globalCalls=[];
const mutationCalls=[];
const set = (key, value) => { const keys=key.split('.'); let into=state; for(const part of keys.slice(0,-1)) into=into[part]??={}; into[keys.at(-1)]=value; };
const get = (key) => key.split('.').reduce((value, part) => value?.[part], state);
const resolve = (value) => typeof value === 'string' ? value.replace(/\$\{([^}]+)\}/g, (_, key) => { const v=get(key); if(v===undefined) throw new Error('Missing plan value: '+key); return v; }) : Array.isArray(value) ? value.map(resolve) : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).map(([key,v])=>[key,resolve(v)])) : value;
function canonical(value) {
  function normalize(item, arrayKind, container) {
    if(Array.isArray(item)) {
      if(arrayKind) {
        const keyed=new Map();
        for(const entry of item) {
          if(!entry || typeof entry!=='object' || Array.isArray(entry)) throw new Error('Invalid '+arrayKind+' observation');
          let key;
          if(arrayKind==='rows') {
            if(typeof entry.id!=='string' || !entry.id) throw new Error('Row observation requires an exact ID');
            key=entry.id;
          } else {
            if(typeof entry.bucket!=='string' || !entry.bucket || typeof entry.path!=='string' || !entry.path) throw new Error('File observation requires exact bucket/path');
            key=JSON.stringify([entry.bucket,entry.path]);
          }
          if(keyed.has(key)) throw new Error('Duplicate '+arrayKind+' observation key: '+key);
          // Retain every entry field. Arrays inside raw row data remain ordered;
          // only provider observation sets have stable-key comparison semantics.
          keyed.set(key,normalize(entry,null,false));
        }
        return Object.fromEntries([...keyed].sort(([a],[b])=>a.localeCompare(b)));
      }
      return item.map(entry=>normalize(entry,null,false));
    }
    if(item && typeof item==='object') return Object.fromEntries(Object.keys(item).sort().map(key=> {
      const child=item[key];
      const kind=container && Array.isArray(child) ? key==='files'?'files':key==='rows'||tables.includes(key)?'rows':null : null;
      return [key,normalize(child,kind,container)];
    }));
    return item;
  }
  return JSON.stringify(normalize(value,Array.isArray(value)?'rows':null,true));
}
const assert = (ok, message) => { if (!ok) throw new Error(message); };
async function call(name, args, doctor = false) {
  // Each helper's owned() check itself GETs /auth/login. Reserve three catchall
  // calls for an artifact (doctor + normal-session confirmation + target), one
  // for readback/doctor, and a separate admission for POST/DELETE. The estimates
  // are conservative for cached POST/DELETE; no provider/app limits are changed.
  const artifact=args[0]==='artifact-http';
  const cost=artifact?3:1;
  const mutation=artifact && ['POST','DELETE'].includes(args[4]);
  for(;;) {
    const now=Date.now();
    while(globalCalls[0]?.at<=now-60000) globalCalls.shift();
    while(mutationCalls[0]<=now-60000) mutationCalls.shift();
    const globals=globalCalls.reduce((sum,entry)=>sum+entry.cost,0);
    if(globals+cost<=52 && (!mutation || mutationCalls.length<25)) break;
    const next=Math.min(globals+cost>52?globalCalls[0].at+60000:Infinity,mutation && mutationCalls.length>=25?mutationCalls[0]+60000:Infinity);
    console.log(name+' pacing before its first attempt');
    await new Promise(done=>setTimeout(done,Math.max(1,Math.min(60000,next-now+25))));
  }
  globalCalls.push({at:Date.now(),cost}); if(mutation) mutationCalls.push(Date.now());
  const command = doctor ? [path.join(repo, 'scripts/verification/cli.mjs'), 'doctor', '--worker', config.worker] : [path.join(repo, '.agents/skills/verify-trooptotask/helpers/control.mjs'), '--worker', config.worker, ...args];
  await fs.appendFile(path.join(run, 'commands.jsonl'), JSON.stringify({ name, args: doctor ? ['doctor'] : args, startedAt: new Date().toISOString() })+'\n');
  const result = await new Promise((done, reject) => {
    const process = spawn(globalThis.process.execPath, command, { cwd: repo, stdio: ['ignore', 'pipe', 'pipe'] });
    const stdout=[], stderr=[];
    process.stdout.on('data', chunk=>stdout.push(chunk)); process.stderr.on('data', chunk=>stderr.push(chunk));
    process.on('error',reject);
    process.on('close',(code,signal)=>done({ code, signal, stdout:Buffer.concat(stdout), stderr:Buffer.concat(stderr) }));
  });
  await fs.writeFile(path.join(run,name+'.stdout.json'),result.stdout,{flag:'wx',mode:0o600});
  await fs.writeFile(path.join(run,name+'.stderr.txt'),result.stderr,{flag:'wx',mode:0o600});
  await write(name+'.process.json',{exitCode:result.code,signal:result.signal,finishedAt:new Date().toISOString()});
  if (result.code !== 0) throw new Error(name+' exited '+result.code+'; inspect both preserved streams. No target-status credit or retry.');
  let output; try { output=JSON.parse(result.stdout.toString('utf8')); } catch { throw new Error(name+' did not return complete JSON; raw bytes retained.'); }
  return output;
}
async function inputs() {
  const inputDirectory=path.join(run,'inputs'); await fs.mkdir(inputDirectory,{recursive:true,mode:0o700});
  const validPath=path.resolve(repo,config.files.validPdf);
  const realValid=await fs.realpath(validPath);
  assert(realValid.startsWith(run+path.sep),'Coordinator must place the original valid synthetic PDF in this run before execution.');
  const original=await fs.readFile(realValid);
  assert(original.subarray(0,4).toString()==='%PDF' && original.length<10485760,'Provide the actual small synthetic PDF, not a fabricated upload result.');
  async function padded(relative, bytes) {
    const target=path.resolve(repo,relative); assert(target.startsWith(inputDirectory+path.sep),'Generated input must remain in this run input directory.');
    const file=await fs.open(target,'wx',0o600);
    try { await file.write(original); const chunk=Buffer.alloc(1024*1024); for(let position=original.length;position<bytes;position+=chunk.length) await file.write(chunk.subarray(0,Math.min(chunk.length,bytes-position))); }
    finally { await file.close(); }
  }
  await padded(config.files.exactTenMiBPdf,10485760); await padded(config.files.oversizePdf,10485761);
  const spoof=path.resolve(repo,config.files.spoofPdf); assert(spoof.startsWith(inputDirectory+path.sep),'Spoof input must remain in this run.');
  await fs.writeFile(spoof,'This synthetic input deliberately lacks the declared PDF signature.\n',{flag:'wx',mode:0o600});
  const manifests={}; for(const [key,relative] of Object.entries(config.files)) { const file=await fs.readFile(path.resolve(repo,relative)); manifests[key]={path:relative,bytes:file.length,sha256:createHash('sha256').update(file).digest('hex')}; }
  await write('input-manifest.json',manifests); return manifests;
}
async function snapshot(name, compare) {
  const result={tables:{},parents:{},files:{}};
  for(const organization of ['orgA','orgB']) {
    result.tables[organization]={};
    for(const table of tables) result.tables[organization][table]=await call(name+'-'+organization+'-'+table,['rows',table,organization]);
    result.parents[organization]=await call(name+'-'+organization+'-personnel',['rows','personnel',organization]);
  }
  for(const [person,id] of Object.entries(config.people)) {
    const args=['artifact-files',person==='foreign'?'orgB':'orgA',id];
    for(const [filePath,kind] of knownPaths[person]) args.push(kind,filePath);
    const files=await call(name+'-files-'+person,args); result.files[person]=files;
    for(const file of files.files) knownPaths[person].set(file.path,file.bucket==='counseling-files'?'counseling':'document');
  }
  canonical(result); // Reject duplicate/missing observation keys in every phase.
  snapshots[name]=result; await write(name+'-snapshot.json',result);
  await write(name+'-recorded-paths.json',Object.fromEntries(Object.entries(knownPaths).map(([person,paths])=>[person,[...paths]])));
  if(compare) {
    const before=snapshots[compare]; assert(before,'Missing comparison snapshot '+compare);
    assert(canonical(result.tables)===canonical(before.tables),name+' changed complete artifact rows relative to '+compare);
    assert(canonical(result.parents)===canonical(before.parents),name+' changed Personnel parents relative to '+compare);
    if(name!=='32-final-originals') assert(canonical(result.files)===canonical(before.files),name+' changed recorded files relative to '+compare);
    else {
      for(const person of Object.keys(config.people)) {
        const initial=new Map(before.files[person].files.map(file=>[file.path,file]));
        for(const file of result.files[person].files) {
          if(initial.has(file.path)) assert(canonical(file)===canonical(initial.get(file.path)),'Original file changed: '+file.path);
          else assert(file.present===false,'Created file retained after ordinary cleanup: '+file.path);
        }
      }
    }
    await write(name+'-comparison.json',{status:'PASS',before:compare,after:name,completeRowsAndParentsEqual:true,recordedFileBoundary:'Exact recorded paths only; no claim about unreferenced objects outside these paths.'});
  }
  if(name==='02-created') {
    const initial=snapshots['00-initial'];
    assert(canonical(result.parents)===canonical(initial.parents),'Artifact creation changed Personnel parents');
    for(const organization of ['orgA','orgB']) for(const table of tables) {
      const added=createFacts.filter(({step})=>step.organization===organization && (step.endpoint[0]==='follow-ups'?'personnel_follow_ups':step.endpoint[0]==='documents'?'personnel_documents':'counseling_records')===table).map(({output})=>output.body.id);
      const baseline=initial.tables[organization][table].rows;
      assert(added.every(id=>!baseline.some(row=>row.id===id)),'Create returned an original artifact ID');
      const after=result.tables[organization][table].rows;
      assert(after.length===baseline.length+added.length && canonical(after.filter(row=>!added.includes(row.id)))===canonical(baseline),'Create changed original rows or produced extra rows');
    }
    for(const {step,output} of createFacts) {
      const family=step.endpoint[0], table=family==='follow-ups'?'personnel_follow_ups':family==='documents'?'personnel_documents':'counseling_records';
      const row=result.tables[step.organization][table].rows.find(item=>item.id===output.body.id);
      assert(row?.organization_id===config.organizationIds[step.organization] && row.personnel_id===step.person && row.archived_at===null,'Created raw identity/archive differs: '+step.name);
      assert(row.title===step.body.title,'Created raw title differs: '+step.name);
      if(family==='follow-ups') assert(row.notes===step.body.notes && row.due_date===step.body.dueDate && row.created_by===output.actorId && row.status==='open' && row.completed_at===null,'Created Follow-up fields differ');
      else {
        const prefix=family==='documents'?config.organizationIds[step.organization]+'/personnel/'+step.person+'/documents/':config.organizationIds[step.organization]+'/counseling-records/'+step.person+'/';
        assert(row.uploaded_by===output.actorId && row.file_path.startsWith(prefix),'Created file contributor/path differs');
        if(family==='documents') assert(row.file_size_bytes===inputManifest.validPdf.bytes && row.content_type==='application/pdf','Created Document metadata differs');
        else assert(row.subject===step.body.title && row.summary===step.body.summary && row.notes===step.body.summary && row.date_conducted===step.body.dateConducted && row.status==='completed','Created Counseling fields differ');
        const person=Object.keys(config.people).find(key=>config.people[key]===step.person);
        const file=result.files[person].files.find(item=>item.path===row.file_path);
        assert(file?.present && file.size===inputManifest.validPdf.bytes && file.sha256===inputManifest.validPdf.sha256,'Created actual file bytes/hash differ');
      }
    }
  }
  const capParent=result.parents.orgA.rows.find(row=>row.id===config.people.cap);
  if(['00-initial','24-alpha-deleted'].includes(name)) {
    assert(capParent?.archived_at===null && capParent?.group_id===config.alphaGroupId && capParent?.organization_id===config.organizationIds.orgA,'Cap parent must be active in Organization A/Alpha.');
    assert(result.tables.orgA.personnel_documents.rows.filter(row=>row.personnel_id===config.people.cap).length===0,'Cap Person must have zero document rows, including archived rows.');
  }
  if(name==='27-cap-full') {
    const docs=result.tables.orgA.personnel_documents.rows.filter(row=>row.personnel_id===config.people.cap);
    assert(docs.length===10 && docs.every(row=>row.archived_at===null && row.file_size_bytes===10485760),'Require ten active exact-size cap rows.');
    assert(docs.reduce((sum,row)=>sum+row.file_size_bytes,0)===104857600,'Require exactly 100 MiB active metadata.');
    assert(result.files.cap.files.length===10 && result.files.cap.files.every(file=>file.present && file.size===10485760 && file.sha256===inputManifest.exactTenMiBPdf.sha256),'Require ten actual cap objects with exact input bytes/hash.');
    await write('cap-boundary-persistence.json',{status:'PASS',activeRows:docs.length,activeBytes:104857600,actualObjects:10,input:inputManifest.exactTenMiBPdf});
  }
  if(['18-archived','24-alpha-deleted'].includes(name)) {
    for(const family of families) {
      const table=family==='follow-ups'?'personnel_follow_ups':family==='documents'?'personnel_documents':'counseling_records';
      const id=get('created.alpha.'+family); const row=result.tables.orgA[table].rows.find(row=>row.id===id);
      if(name==='24-alpha-deleted') assert(!row,'Deleted primary artifact remained: '+family);
      else {
        assert(row?.personnel_id===config.people.alpha,'Primary identity changed: '+family);
        assert(name==='18-archived'?Boolean(row.archived_at):row.archived_at===null,'Wrong lifecycle event: '+family);
        if(family==='follow-ups') assert(row.status===(name==='18-archived'?'archived':'open') && row.completed_at===null,'Follow-up status/completion lifecycle differs');
      }
    }
    const original=new Map(snapshots['02-created'].files.alpha.files.map(file=>[file.path,file]));
    for(const file of result.files.alpha.files) {
      const prior=original.get(file.path); assert(prior,'Unrecorded primary file');
      if(name==='24-alpha-deleted' && !snapshots['00-initial'].files.alpha.files.some(old=>old.path===file.path)) assert(!file.present,'Deleted primary file remained');
      else assert(file.present===prior.present && file.size===prior.size && file.sha256===prior.sha256,'Lifecycle changed actual file bytes');
    }
  }
  if(name==='13-follow-url-identity') {
    const before=snapshots['11-after-denials']; const id=get('created.alpha.follow-ups');
    for(const organization of ['orgA','orgB']) for(const table of tables) {
      const strip = rows=>rows.map(row=>row.id===id?Object.fromEntries(Object.entries(row).filter(([key])=>!['title','notes','due_date','updated_at'].includes(key))):row);
      assert(canonical(strip(result.tables[organization][table].rows))===canonical(strip(before.tables[organization][table].rows)),'Contradictory PATCH body changed another row');
    }
  }
  console.log(name+' snapshot preserved'+(compare?' and comparison PASS':''));
}
let inputManifest;
try {
  const doctor=await call('doctor-initial',[],true);
  assert(doctor.status==='PASS' && doctor.candidate===config.candidateDigest,'Frozen owned doctor/candidate mismatch.');
  inputManifest=await inputs();
  for(const unresolved of plan) {
    if(unresolved.kind==='snapshot') { await snapshot(unresolved.name,unresolved.compare); continue; }
    const step=resolve(unresolved);
    const args=['artifact-http',step.role,step.organization,step.person,step.method,step.endpoint.join('/')];
    if(step.body) { const filename='input-'+step.name+'.json'; await write(filename,step.body); args.push(path.relative(repo,path.join(run,filename))); }
    const output=await call(step.name,args);
    statuses[output.status]=(statuses[output.status]??0)+1;
    await fs.appendFile(path.join(run,'api-actions.jsonl'),JSON.stringify({name:step.name,args,expectedStatus:step.expectedStatus,status:output.status})+'\n');
    assert(output.status===step.expectedStatus,step.name+' expected '+step.expectedStatus+' but observed '+output.status+'; stop without retry.');
    if(step.capture) { assert(uuid.test(output.body?.id),'Created result lacks exact artifact UUID'); createFacts.push({step,output}); set(step.capture,output.body.id); await fs.writeFile(path.join(run,'created-state.json'),JSON.stringify(state.created,null,2)+'\n',{mode:0o600}); }
    if(step.method==='PATCH' && output.status===200) assert(output.body?.id===step.endpoint[1] && output.body.personnelId===step.person,'PATCH did not return its URL-bound artifact');
    if(step.expectedIdentity) assert(Object.entries(step.expectedIdentity).every(([key,value])=>output.body?.[key]===value),'PATCH did not preserve URL-bound identity');
    console.log(step.name+' HTTP '+output.status);
  }
  const finalDoctor=await call('doctor-final',[],true); assert(finalDoctor.status==='PASS' && finalDoctor.candidate===config.candidateDigest,'Final owned doctor/candidate mismatch.');
  await write('runner-summary.json',{status:'PASS',statusCounts:statuses,ordinaryArtifactRequests:Object.values(statuses).reduce((a,b)=>a+b,0),created:state.created,boundary:'Ordinary HTML-authenticated artifact HTTP; privileged rows/recorded-files readbacks. No native, SQL/RLS-concurrency, external Storage-open or unknown-orphan claim.',remainingCoordinatorObligations:'Review receipts, frozen-input hashes, clean-seeds/cache cleanup, final disposal, packaging and independent acceptance.'});
} catch(error) {
  await write('runner-stopped.json',{status:'FAILED_OR_BLOCKED',message:error.message,finishedAt:new Date().toISOString(),statusCounts:statuses,created:state.created,noMutationRetries:true,requiredNextStep:'Review raw stdout/stderr and current rows/files. Do not rerun this runner; coordinator must choose targeted recorded-ID cleanup.'});
  console.error(error.message); process.exitCode=1;
}
