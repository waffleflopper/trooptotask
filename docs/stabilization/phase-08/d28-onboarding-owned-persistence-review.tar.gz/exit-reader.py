import pathlib,json,hashlib,re,struct
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93');entry=json.loads((p/'entry-scope.json').read_text());out=[]
for x in entry:
 f=repo/x['path'];a={'path':x['path'],'deleted':not f.exists(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None,'bytes':f.stat().st_size if f.is_file() else 0};a['entryExact']=all(a[k]==x.get(k) for k in ['deleted','sha256','bytes']);out.append(a)
assert all(x['entryExact'] for x in out);(p/'exit-scope.json').write_text(json.dumps(out,indent=2)+'\n')
s=json.loads((p/'final-expanded/source/source-inventory-final.json').read_text());by={x['path']:x for x in s['files']};binding=[]
for x in entry:
 if x['path'] in by and x['sha256']==by[x['path']]['sha256'] and x['bytes']==by[x['path']]['bytes']:binding.append(x['path'])
 elif x['deleted']:assert x['path'] in s['deleted'];binding.append(x['path'])
extras=[x['path'] for x in entry if x['path'] not in binding];assert all(x.startswith('docs/') for x in extras)
visual=[];scan=[];pat=re.compile(rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}')
for run in ['baseline','final']:
 root=p/(run+'-expanded');total=0;texts=0;hits=[]
 for x in json.loads((root/'archive-inventory.json').read_text())['entries']:
  b=(root/x['path']).read_bytes();total+=1
  try:b.decode('utf8');texts+=1
  except UnicodeDecodeError:pass
  if pat.search(b):hits.append(x['path'])
 for f in root.rglob('*.png'):
  b=f.read_bytes();w,h=struct.unpack('>II',b[16:24]);visual.append({'path':str(f.relative_to(p)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'width':w,'height':h,'viewedOriginalDetail':True,'scope':'visible selected state; no universal pixel or OCR assertion'})
 scan.append({'archive':run,'payloads':total,'utf8Payloads':texts,'jwtPatternHits':hits,'knownLiteralScan':'archived worker/parent scope reused; private values not read by this reviewer'})
assert len(visual)==15 and all(not x['jwtPatternHits'] for x in scan)
(p/'source-binding-visual-sanitation.json').write_text(json.dumps({'nativeInputBoundScopePaths':len(binding),'nativeInputExact':True,'postNativeDocsArchivesOnly':extras,'visual':visual,'publicSanitation':scan},indent=2)+'\n')
print(json.dumps({'exit':len(out),'boundNativeScope':len(binding),'postNativeDocsArchives':extras,'visual':len(visual),'sanitation':scan},indent=2))
