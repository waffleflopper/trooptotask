# Next #1363 deliverable: valid Reopen and retention/History/export composition

Read-only preparation at root `614b93747954ba7b457c01792544334cfc06c184` on 2026-10-02 UTC, while root finishes current PR #1490 and its separately delegated feedback repair. No tracked edits, services, browser, data, tracker, publication or live tests were performed. `support.json` captures inspected source/archive bindings. This is preparation, not live proof, independent acceptance or permission to begin another issue. Recheck the integrated root after #1490 merges; the exact-current-head check/acceptance gates remain root-owned. Applicable AGENTS, t2t-engineer, verify-trooptotask, packet recipe, operating rules, TESTING and stabilization guidance were read. No installed pstack capabilities were available in this agent's tool catalog.

## Smallest preparation change

The earlier `remaining-s9eu4n7c` report incorrectly says onboarding-request admits lifecycle PUT. Current `helpers/onboarding-request.mjs` only admits onboarding POST, steps PUT/DELETE and resync POST. SKILL.md's documented allowance agrees. `control.mjs` already supplies the exact doctor-owned origin, allowlisted fixture Organization segment and normally signed-in browser page to that helper. No dispatch or actor change is necessary.

Other current helpers do not solve this: settings-request admits only Settings operations; artifact-http admits only Personnel artifact paths; onboarding-start-provider/removal-provider deliberately perform fixed privileged provider preparation/observation, not ordinary lifecycle HTTP. The accepted lifecycle archive contains `driving-inputs/d15-packets/owned-onboarding-http.mjs` and its 14,070-byte `onboarding-http.mjs`, which log in normally outside the browser with a private cookie cache. These scratch modules can technically submit lifecycle PUT, but copying/adopting a separate authentication stack for one missing method adds unnecessary inputs and login/rate-limit work. Use the existing page helper instead.

Propose only `onboarding: { POST: existingFields, PUT: ['id', 'status'] }` in onboarding-request. Add one focused ordinary Reopen case preserving exact JSON/path/method, a real unsuccessful HTTP status/body and a subsequent successful authoritative body; strengthen the existing unsupported-input case for PUT with Start-only/extra or nested fields to prove no request is sent. Existing shared deferred capture/restore/capacity/transport tests already cover optional start and need no mirrored lifecycle copies. Keep current scalar allowance and API validation: do not add a helper status whitelist or synthetic HTTP mapping that prevents valid rejection probes. Update the SKILL allowance and packet recipe to document lifecycle PUT and this collision/retention composition. No new fixture/provider helper, arbitrary fetch evaluator, generic request layer, application edit or migration is established necessary.

Before a frozen run, focused checks are `node --test .agents/skills/verify-trooptotask/helpers/onboarding-request.test.mjs`, syntax/format on changed helper/test, and the repo document checker. Freeze the actual helper, control, recipes, drivers, bodies and plan before launch through final doctor/cleanup. A helper repair before driving is preparation; one fresh unchanged-application proof can supply both current baseline and final verification for a verification-only candidate, without two redundant identical campaigns. Any actual application defect needs its own failing and matching repaired observations.

## Owned environment and commands

All commands run at the root. Use worker 1 only when root's current worker is fully disposed; do not double-drive. Native tools always go through verify:app, whereas helpers go through control.mjs. Illustrative shell wrappers (the evidence wrapper must preserve every actual argv/stdout/stderr/exit under a new durable run):

```bash
v() { node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1 "$@"; }
a() { npm run --silent verify:app -- "$@" --worker 1; }
a launch
a doctor
v fixture
v retention settings
v actor onboardingOperate onboarding
v seed onboarding-legacy
```

Use the returned page/context/origin/IDs and actual selected date, never historical values. Do not print private fixtures/session tokens. Save all twelve full original projected A/B Personnel, packets, progress, Training, templates and definition readbacks before the first mutation, plus settings and notification/export records separately. The root wrappers can reuse their existing checked command/evidence mechanics but require new labels and frozen bytes. For rows, use unfiltered `v rows TABLE orgA|orgB` or exact allowed ID filters; do not invent `personnel_id` on progress.

```bash
v rows personnel_onboardings orgA personnel_id PERSON_UUID
v rows onboarding_step_progress orgA onboarding_id PACKET_UUID
v rows personnel_onboardings orgB
v rows onboarding_step_progress orgB
v rows data_exports orgA
v rows data_exports orgB
v rows notifications orgA
v rows notifications orgB
```

The packet projection includes id/Organization/Person/template/start/completed/cancelled/status/created_at. Progress includes id/Organization/parent/definition/snapshot/type/Training/stages/order/completed/current_stage/notes/active/updated_at. Compare every actually captured field. Template/definition/Training projections omit some timestamps; do not claim all schema columns.

## Valid Reopen collision → native cancellation → ordinary retry

Use the ledgered legacy Person and active null-template packet plus three existing completed/incomplete/stage/note witnesses. No Assign is required for this boundary; keeping null-template also preserves legacy retention. Use the Onboarding-only Operate actor's normal admitted session, separately from privileged seed/readbacks.

1. Save the initial actual parent and three progress rows. Open the unique `SPC MapLegacyTAG, Synthetic` active card through its fresh AX UID; native Cancel → Cancel Onboarding confirmation creates an authoritative recent cancellation date. Preserve full real PUT request/response, same parent/progress IDs, unchanged start/template/created time/work/notes, native History disclosure and reload. Do not use seeded terminal status to claim native cancellation.
2. Return to Onboarding. Native Start Onboarding → Member → search unique MapLegacy tag → normal result option. Inspect the visible valid Start Date and selected configured fixture template. With one template no Template selector renders. Submit normally; preserve real POST200 and returned competing parent plus its three fresh progress IDs. Reload and require exactly one active packet for this same Person. The old cancelled packet/progress remain exact.
3. With no network fault or hold, submit the valid ordinary request **after the proposed allowance exists**:

```bash
v onboarding-request PAGE orgA PUT onboarding '{"id":"OLD_CANCELLED_PACKET_UUID","status":"in_progress"}'
```

Require an actual rejected 4xx/5xx transport result, complete submitted/body receipt and no effects: both parents/all six progress fields exact, no new rows, only competitor active. Existing provider deliberately propagates 23505; the HTTP adapter wraps untyped failures as 500/Internal server error. Do not invent required409. A 500 alone does not prove its cause: retain the corresponding sanitized bounded `[http-adapter] Unhandled route error` app.log diagnostic naming `personnel_onboardings_active_idx`, attributed to this one sequential request. Read only that private worker's app.log after the request and copy just the relevant sanitized diagnostic to durable evidence before disposal. No provider fault/control or new SQL query is needed. The source index and existing real-SDK provider test separately establish 23505 handling; do not claim a numeric provider code was directly observed if the log only names the unique constraint.
4. Reload/open the competitor card and natively Cancel → Cancel Onboarding. Capture real200, recent cancelledAt, completedAt null, same work and old cancelled packet unchanged. Ordinary retry the **identical** Reopen body above without another setup mutation. Require real200 returning old ID/in_progress/null terminal dates. Only old parent status/cancelledAt may differ from its cancelled snapshot; Person/template/start/created time and all original three progress fields/IDs/notes must remain exact. Competitor stays cancelled with its own exact rows.
5. Reload, require the old legacy active card and its retained 2/3 work, open it and inspect Reviewed, completed checklist entries and any supported retained content. This is API Reopen + native readback, not a native Reopen control. No History Reopen control or note editor exists. The legacy notes are setup witnesses, not new ordinary note creation or independently bound numeric actor-author proof. Current ordinary append/native History proof remains the previously accepted selected contract.

Native selectors are source-derived hints only: obtain fresh snapshots and actual UIDs each time. Card accessible text includes Person, template label, percentage and Started date. Detail button `Cancel`; confirmation dialog/title/button `Cancel Onboarding`; dismiss button `Cancel`. Start dialog title/submit `Start Onboarding`, Member combobox `Member` (`#personnel-select`), search placeholder `Search for a member...`, result name `SPC MapLegacyTAG, Synthetic`, Start Date control `#start-date`; normal keyboard selection if native AX options are missing. No stale UID, direct DOM selection mutation, app callback or store evaluation.

## Current retention → History → JSON/Excel composition

After Reopen proof leaves old active/competitor recently cancelled, keep that cohort and separately run `v seed onboarding-retention`. It ledger-records eight parent/progress IDs before writes: expired completed and cancelled A; recent completed/cancelled, null-timestamp completed/cancelled and active A; recent completed B. Expired dates are 2000-01-01; recent dates are now minus one day. Read actual A/B retention settings first: current default36month is a verified assumption, not a hardcoded production setting. B must remain recent because the admitted job processes every synthetic Organization. Never alter settings to make the proof pass.

Preserve exact eight seed parents/progress and complete A/B rowsets before jobs. Before deletion, native History must show/disclose both expired witnesses with their tagged step names and saved notes. Also choose one recent completion and one null-terminal cancellation and disclose notes; preserve readable snapshots/screenshots. Their collapsed captions share PersonA/template/start1999, so distinguish status and completed/cancelled date (expired2000, recent yesterday, null has no terminal date), then verify the exact tagged step after expansion. Read-only DOM can inspect rendered `[data-slot="onboarding-packet-trigger"]` captions and item attributes; do not assume Bits exports packet UUIDs or choose positional rows. Native History load is streamed layout/bootstrap, not an invented GET `/api/onboarding` route. Use actual navigation/response, provider readbacks and rendered witness labels together.

```bash
v retention cron missing onboarding
v retention cron wrong onboarding
v retention cron run onboarding
v retention cron run onboarding
```

Missing/wrong must each return401 and leave every captured packet/progress and notification field unchanged. Real admitted request must return200/deletedCount2/orgsAffected1. Require exact eligible two parents and their two note-bearing progress rows absent; all six sentinels, March history, old reopened packet and recent competitor—including every captured survivor field—remain exact. No other row may disappear. Capture actual new administrator summaries separately; unchanged source proof supplies delivery semantics, while current rows/counts establish this run. Second real request returns200/count0/orgs0 and no additional packet/progress/summary changes. Do not infer rollback from client503 or claim wall-clock equality/fault/race/bulk proof from this small campaign.

After admitted job and after a separate reload, native A History must exclude the two tagged expired witnesses and preserve all four terminal A sentinels, original March history and recent competitor. Open recent completion and null-terminal cancellation again, disclose `Toggle notes`, require retained tagged text/time and read-only status/work. Active sentinel and reopened old packet belong to Onboarding, not History. Use an ordinary B-only actor/page (`onboardingForeign onboarding/history`) for foreign recent History if choosing positive B UI proof; provider preservation already proves B stored effect and native A absence proves A isolation, but neither alone proves B UI. Only 2–3 normal actor logins are needed in the core selection; retain existing pages rather than repeating logins.

Enter Settings → Exports as normal `orgOwner`. Capture before lifecycle records, then the actual native successful downloads:

```bash
v actor orgOwner settings/exports
v network arm-observe OWNER_PAGE export
v export arm OWNER_PAGE
# Native fresh-snapshot click: Export JSON
v network state OWNER_PAGE
v export state OWNER_PAGE
v export save OWNER_PAGE .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.json
v export restore OWNER_PAGE
v network restore OWNER_PAGE
v network arm-observe OWNER_PAGE export-excel
v export arm OWNER_PAGE
# Native fresh-snapshot click: Export Excel
v network state OWNER_PAGE
v export state OWNER_PAGE
v export save OWNER_PAGE .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.xlsx
v export restore OWNER_PAGE
v network restore OWNER_PAGE
v workbook .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.xlsx 'Export Inventory'
v workbook .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.xlsx 'Onboarding Progress'
v workbook .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.xlsx 'Raw - Personnel Onboardings'
v workbook .verification/evidence/verify-trooptotask/NEW_RUN/after-retention.xlsx 'Raw - Onboarding Step Progress'
```

The last raw title is exactly30characters and currently does not truncate. Native buttons `Export JSON`/`Export Excel` and success text `Export downloaded successfully.` come from current Settings source. Require actual POST200/public headers and anchor filename/MIME/bytes/SHA plus saved bytes, then reload visible export result/controls and separately read saved lifecycle status/requester/bytes/completed_at. Do not infer tracking success from bytes; updates remain best-effort. No native export action is supplied by `export request`.

JSON `personnelOnboardings`/`onboardingStepProgress` top-level keys and corresponding `sections` arrays must agree; inventory entries must count actual arrays. Compare full ID sets against current A projected rowsets: eligible two IDs/progress absent, all A survivors present, B IDs absent. Compare every captured field, exact nested note text/time/userId and untouched stage/work; full raw JSON may carry additional columns, but readback only earns its actual projections. Excel raw headers/cells must preserve the same IDs/fields, null cells empty, booleans preserved, and notes/stages JSON cell strings decoded before comparison. Readable `Onboarding Progress` has Person/status/start/completed/cancelled fields only; notes/stages/step IDs belong raw sections. Compare readable rows as a multiset—null sentinels can share labels/dates—without assuming incidental order or independently proving identity from a sheet that omits ID. This fresh composition does not repeat accepted broad export admission/scope/client-recovery/bulk provider campaigns.

## Cleanup ownership and residuals

Restore every network/Blob/feedback/request capture; require no pending request before request-restore. Normally cancel any remaining temporary active packet if desired, capturing the intentional final transition separately; clean-seeds owns only the recorded cohorts. The legacy ledger explicitly lists its Person/old parent/three progress, and the retention ledger all eight parent/progress. The native competitor/three progress are **not individually ledgered**. However `20260413001158_remote_schema.sql:3586` has Person→packet CASCADE and `:3506` packet→progress CASCADE, so deleting only the ledgered temporary Person through clean-seeds also removes those generated children. This is source expectation until exact post-clean readback proves it: preserve their ordinary returned IDs and require both old/new parents and all six progress absent, then all sixteen retention IDs absent. Do not claim direct ledger ownership or unobserved hard deletion. All twelve original projected rowsets must equal before, including original March IDs/notes/timestamps. UI-generated export/audit/notification records are declared effects and may remain until whole owned-provider disposal; record actual IDs/counts separately and do not claim clean-seeds deletes them.

Finish matching final doctor, all frozen-source/recipe/helper/driver hashes, supported verify:app cleanup, and exact owned original process/container/volume/network/private-directory absence. Preserve original resource full IDs and supervisor process identity before cleanup. Only after disposal package sanitized raw artifacts with inventories/fresh bounded readers, preserving every predecessor archive and unrelated D17 content. No production credentials, remote query, maintenance-stack operation, migration, arbitrary SQL or whole-dev-database reset is involved.

## Exact reuse and whole-issue accounting

Support records all member inventories checked **in memory**, not fresh expanded behavioral acceptance. Prior actual observations keep their own revisions/digests. Selected source applicability at614b:

- #1468 archive `c1851ba59ff9d35a0ece20c2693c7be5ee09b2f2ded95ed20c62a68d94e79700`: all13 selected retention operation/provider/ports/tests/cutoff/mapping/cron/admission/pagination/notification sources equal. All161 selected prior migration/Onboarding SQL inputs remain byte-identical. Five later additive migrations exist; they introduce reconciliation, append, atomic Start and Organization file registration/cleanup functions and do not replace the active unique index or these two cascade FKs. Reuse only the accepted guarded cascade, fault rollback/partial batch, eligibility waits/races, real1002 traversal/repeat/notification and selected SQL boundaries; no new run or entire current replay claim.
- #1475 export final `5ab0eec4cc1ec18834afefa3ac44dd40926a92e999d78b450d1e76cabc169be6`: all14 selected owned reads/orchestration/workbook/manifest/lifecycle/ordinary routes/Settings/pagination sources equal; all167 selected prior database inputs equal. Later append/Start/file registration additions are distinct. Reuse accepted admission/foreign403or404 exact method distinctions, selected saved raw/readable semantics,1001 traversal/error and client recovery only; fresh small retention composition above adds current deletion visibility.
- #1479 lifecycle `ce3f3787e768245d1a3a8e27f49f15d6ba07ff57c65212f4209247cd466384db`: provider/test/policy/PUT route4of6 selected entire files equal; lifecycle and adapter files changed. Exact tail from `interface LifecycleResult` through Cancel/Reopen/Complete equals frozen582e3387 (both SHA in support); changes before it are the separately accepted atomic Start. Adapter still binds the ordinary Supabase lifecycle factory in all three contexts; later additions concern Start/removal/sign-in-file ports. Reuse accepted conditional [200,409], sequential native/API/History and valid denial scopes only; current client store/context changed and need their earned #1489/#1490 proofs, not whole-file lifecycle-era equivalence. All170 selected prior DB inputs remain equal.

Root must recheck these hashes/bindings on its post-#1490 integrated candidate and independently accept reuse selection. The full CI DB matrix on a newer migration set is separately identified, not silently inherited from old SQL counts. Latest pinned ARM64 SQL/provider proof belongs its exact accepted CI input; do not claim all current SQL was rerun by this preparation.

Final #1363 accounting should map owned start/packet query/progress/note/lifecycle/reconciliation/retention; Web/public roster/Training/Calendar/AddPerson; Settings raw/readable export; supported operations/access/retry/concurrency; every consumed route/adapter/job/reverse seam; and deletions of obsolete global/private/list/note paths to exact integrated receipts and actual input applicability. Current reproduction/repair PR #1490 feedback acceptance must finish first. Existing #1470/#1474 reconciliation, #1478 append, #1479 lifecycle, #1482 consumers, #1484 Paperwork, #1485 step/removal, #1486 active-list/History, #1487 Start, #1489 checkbox and current #1490 delivery each retain bounded claims and historical failures. Global Dashboard/export/cron composition is legitimate retained orchestration, not another feature ownership cutover; D23/D24/D25 infrastructure and unrelated D17 remain outside this issue. No consumed obsolete global packet authority or private Personnel/Training dependency was found by this bounded investigation; a source census alone is not behavior proof.

Keep TODO08-M09-02a/b open until every complete requirement and current candidate passes final independent acceptance, complete CodeRabbit/hosted review and exact-head DoD/build/CI. Only then may a final PR say Closes#1363; do not close phase parent or move to another issue. This preparation indicates no new migration/manual gate, but any actual migration found during a repair still requires Robert's live application boundary.


Root campaign follows this preparation on a clean post-#1490 integrated checkout. One unchanged-application run is baseline/final for this verification-only outcome. Actual observations govern; preserve any failed/inconclusive attempt and stop dependent acceptance if defects emerge.


Workstation /tmp is inode constrained (9,305 free at preparation). Every captured verify/helper command uses only this campaign's ignored runtime-tmp as TMPDIR. This avoids shared-directory cleanup and does not alter app behavior or global configuration. Remove only this owned directory after supported disposal and save absence; the exact override is recorded per command.

Hosted #1490 has a separate inferred unknown-provider-order hardening note, independently assessed as outside the declared known saved-order repair. It is an unproved hypothesis, not accepted concurrency proof or a migration requirement. Final whole-issue accounting must retain exact boundaries without implying arbitrary client submission equals database commit order.


Startup attempt was fully outside business proof and preserves its BLOCKED results/cleanup. A long TMPDIR is a possible Chromium socket-path cause, not a proven diagnosis; after supported disposal, retry uses short owned /home/waffleflops/.cache/t2t-d15-closing-703a1ec4. Prior frozen driver copies are retained under startup-attempt. Application source and recipes stay unchanged.
