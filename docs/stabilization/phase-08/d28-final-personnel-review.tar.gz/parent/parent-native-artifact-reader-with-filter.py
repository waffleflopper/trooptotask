import argparse, hashlib, json, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as X

p = argparse.ArgumentParser()
p.add_argument('raw', type=Path)
p.add_argument('--checkout', type=Path)
p.add_argument('--freeze', type=Path)
a = p.parse_args()
r = a.raw
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda n: json.loads((r / (n + '.json')).read_text())
rows = lambda n: load(n)['rows']
def helper(n):
    x = load(n)
    assert x['exit'] == 0, n
    return json.loads(x['stdout'])
def byid(rs):
    assert len({x['id'] for x in rs}) == len(rs)
    return {x['id']: x for x in rs}
def one(n, table, identity):
    return byid(rows(n)['orgA'][table])[identity]
def same_business(left, right, except_tables=()):
    assert set(left) == set(right)
    for org, tables in left.items():
        assert set(tables) == set(right[org])
        for table, records in tables.items():
            if table != 'audit_logs' and table not in except_tables:
                assert byid(records) == byid(right[org][table]), (org, table)

manifest = load('artifact-inventory')['publicPayload']
assert len(manifest) == 474
assert set(x['path'] for x in manifest) == {x.relative_to(r).as_posix() for x in r.rglob('*') if x.is_file() and x.name != 'artifact-inventory.json'}
for item in manifest:
    b = (r / item['path']).read_bytes()
    assert len(b) == item['bytes'] and sha(b) == item['sha256'], item['path']
original = rows('original-preseed-full')
seed = helper('lifecycle-seed')
person = '7689e156-831d-44ca-8737-5c1ad6703b4b'
org = '61ca03ee-823b-4d18-bb38-3caed99d9875'
actor = '46eedc34-c22a-4f95-8229-d5c39cee5343'
assert seed['ids']['person'] == person and seed['ids']['criticalTask'] == '4d245a8b-6cc3-476d-844b-6b80b66d9cde'
assert person not in byid(original['orgA']['personnel'])
assert len(original['orgA']['personnel']) == 3
assert load('fixture-preseed')['at'] < load('lifecycle-seed')['at']
rankid = '45b91816-d062-4e8a-8cfb-4c2d69476cbc'
rank = one('rank-created-full', 'organization_rank_catalog', rankid)
rank_expected = dict(id=rankid, organization_id=org, code='FINAL-E9F8E1A9', label='Synthetic baseline rank', service='custom', category='custom', pay_grade='ungraded', state='active', source='custom', sort_order=120)
assert set(rank) == set(rank_expected) | {'created_at', 'updated_at'}
assert {k: rank[k] for k in rank_expected} == rank_expected
for n, state in [('rank-edited-full', 'active'), ('rank-retired-full', 'retired'), ('rank-active-full', 'active')]:
    x = one(n, 'organization_rank_catalog', rankid)
    assert set(x) == set(rank) and x['created_at'] == rank['created_at']
    assert {k: x[k] for k in rank_expected} == {**rank_expected, 'label':'Synthetic baseline rank edited', 'state':state}
same_business(original, rows('rank-removed-full'))
assert sum(x['rank'] == 'SPC' for x in original['orgA']['personnel']) == 3
rosters = original['orgA']['sign_in_rosters']
assert sum(any(y['rank'] == 'SPC' for y in (x['personnel_snapshot'] or [])) for x in rosters) == 2
assert sum(any(y['rank'] == 'PFC' for y in (x['personnel_snapshot'] or [])) for x in rosters) == 1
assert sum('PFC' in ((x['filter_config'] or {}).get('ranks') or []) for x in rosters) == 1

sdsid = 'fdeb5658-9ab2-42d4-8621-90f1f39fb50c'
expected = {'blood_type':'O+','basd':'2020-01-02','date_of_rank':'2024-03-04','marital_status':'Single','number_of_dependents':2,'children':[{'name':'Alex','age':7},{'name':'Jamie','age':None}],'civilian_education':'Associate','military_education':['BLS','ACLS'],'emergency_contact_name':'Synthetic Contact','emergency_contact_relationship':'Sibling','emergency_contact_phone':'555-0101','spouse_name':'Synthetic Spouse','spouse_phone':'555-0102','vehicle_make_model':'Synthetic Sedan','vehicle_plate':'VFY1376','vehicle_color':'Blue','personal_email':'sheet@example.invalid','personal_phone':'555-0103','address_street':'1 Test Street','address_city':'Test City','address_state':'AK','address_zip':'99501'}
saved = one('sds-saved-full', 'personnel_extended_info', sdsid)
assert set(saved) == set(expected) | {'id','organization_id','personnel_id','created_at','updated_at','award_tracking_acknowledged_at'}
assert saved['organization_id'] == org and saved['personnel_id'] == person
assert {k:saved[k] for k in expected} == expected and saved['award_tracking_acknowledged_at'] is None
ack = []
for n in ['award-set-full','sds-phone-cleared-full','award-replayed-full','award-cleared-full']:
    x = one(n, 'personnel_extended_info', sdsid)
    assert set(x) == set(saved) and x['created_at'] == saved['created_at']
    assert {k:x[k] for k in expected} == {**expected, **({'personal_phone':None} if n != 'award-set-full' else {})}
    ack.append(x['award_tracking_acknowledged_at'])
assert ack[0] is not None and ack[1] == ack[0] and ack[2] > ack[0] and ack[3] is None
for actor_key, status in [('viewer',403),('personnelForeign',404)]:
    assert helper('award-'+actor_key+'-denial')['status'] == status
    same_business(rows('award-cleared-full'), rows('award-'+actor_key+'-unchanged-full'))
same_business(rows('seeded-full'), rows('award-cleared-full'), ('personnel_extended_info',))

cid = '27a31aaf-6b91-4acf-ac8d-5fd49092075b'
did = 'a8e3b05c-934a-49ec-b627-d90e2e80791f'
fid = '85379f58-cc75-479a-af56-842275a7de00'
nid = '95bca08c-c8c9-4ee1-9c11-98c90b9e552a'
cpath = org+'/counseling-records/'+person+'/d84faac8-683f-4c39-9371-83cc5b7cd876-synthetic.pdf'
dpath = org+'/personnel/'+person+'/documents/a9a61080-a37f-4383-ae43-0abbe57236b4-synthetic.pdf'
c = one('counsel-confirmed-saved-full','counseling_records',cid)
ce = dict(id=cid,organization_id=org,personnel_id=person,date_conducted='2026-10-07',subject='FINAL-E9F8E1A9 counseling',key_points=None,plan_of_action=None,follow_up_date=None,status='completed',counselor_signed=False,counselor_signed_at=None,soldier_signed=False,soldier_signed_at=None,notes='Literal counseling summary',file_path=cpath,title='FINAL-E9F8E1A9 counseling',summary='Literal counseling summary',uploaded_by=actor,archived_at=None)
assert set(c) == set(ce) | {'created_at','updated_at'} and {k:c[k] for k in ce} == ce
x = one('document-saved-full','personnel_documents',did)
de = dict(id=did,organization_id=org,personnel_id=person,title='FINAL-E9F8E1A9 document',file_path=dpath,file_size_bytes=4159,content_type='application/pdf',uploaded_by=actor,archived_at=None)
assert set(x) == set(de) | {'created_at','updated_at'} and {k:x[k] for k in de} == de
f = one('follow-created-full','personnel_follow_ups',fid)
fe = dict(id=fid,organization_id=org,personnel_id=person,title='FINAL-E9F8E1A9 follow-up',notes='Literal follow-up notes',due_date='2026-11-01',status='open',created_by=actor,completed_at=None,archived_at=None)
assert set(f) == set(fe) | {'created_at','updated_at'} and {k:f[k] for k in fe} == fe
for n, status in [('follow-edited-full','open'),('follow-completed-full','completed'),('follow-open-full','open')]:
    x = one(n,'personnel_follow_ups',fid)
    assert set(x) == set(f) and x['created_at'] == f['created_at']
    assert {k:x[k] for k in fe if k != 'completed_at'} == {**{k:v for k,v in fe.items() if k != 'completed_at'},'notes':'Literal follow-up notes edited','status':status}
    assert (x['completed_at'] is not None) == (status == 'completed')
n = one('note-created-full','leader_notes',nid)
ne = dict(id=nid,organization_id=org,personnel_id=person,author=actor,text='Literal final persistence note FINAL-E9F8E1A9',archived_at=None)
assert set(n) == set(ne) | {'created_at'} and {k:n[k] for k in ne} == ne
assert one('note-archived-full','leader_notes',nid)['archived_at'] is not None
assert one('note-restored-full','leader_notes',nid) == n
files = {x['path']:x for x in helper('parent-restored-files')['files']}
for path in [cpath,dpath]:
    assert files[path]['present'] and files[path]['size'] == 4159 and files[path]['sha256'] == '05ffcb4e81ebff28114e13d72dc85635b5f6a1177ddaff3d7513465ecfcd4d91'
for wire, suffix in [('counsel-actual-save-wire','counseling-records'),('document-save-wire','documents'),('document-open-wire','documents/'+did+'/download')]:
    w = helper(wire)['structuredContent']['networkRequest']
    assert str(w['status']) == '200' and w['url'].endswith('/'+suffix)

before, archived, restored = [rows(n) for n in ['before-parent-archive-full','parent-archived-full','parent-restored-full']]
event = '2026-10-08T03:30:03.187+00:00'
event_ids = {cid,did,fid,nid,seed['ids']['counselingActive'],seed['ids']['documentActive'],seed['ids']['followOpen'],seed['ids']['noteActive']}
observed = set()
for org_key, tables in before.items():
    for table, records in tables.items():
        if table == 'audit_logs':continue
        bm, am, rm = [byid(frame[org_key][table]) for frame in [before,archived,restored]]
        assert bm.keys() == am.keys() == rm.keys(), (org_key,table)
        for identity, b in bm.items():
            ax, rx = am[identity], rm[identity]
            affected = org_key == 'orgA' and (identity in event_ids or (table == 'personnel' and identity == person))
            if not affected:
                assert ax == rx == b, (org_key,table,identity)
                continue
            assert ax['archived_at'] == event and rx['archived_at'] is None
            if identity in event_ids:observed.add(identity)
            allowed = {'archived_at'}
            if 'updated_at' in b:allowed.add('updated_at')
            if table == 'personnel_follow_ups':
                allowed.add('status');assert ax['status'] == 'archived' and rx['status'] == b['status'] == 'open'
            for key in set(b)-allowed:assert ax[key] == rx[key] == b[key], (table,identity,key)
assert observed == event_ids and len(observed) == 8

ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
workbook = r/'personnel-records.xlsx'
assert sha(workbook.read_bytes()) == '0d5288e84ffc339cb669d5f71ae216c4de0365fd3e8a1012c87796ba86e96f8e'
with zipfile.ZipFile(workbook) as z:
    for name in z.namelist():
        assert not name.startswith('/') and '..' not in Path(name).parts
        z.read(name)
    strings = [''.join(x.itertext()) for x in X.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
    names = [x.attrib['name'] for x in X.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',ns)]
    assert names == ['Personnel Info','Training Records','Counseling Records','Availability History']
    sheets = []
    for i,width in enumerate([2,4,7,3],1):
        cells = []
        for row in X.fromstring(z.read(f'xl/worksheets/sheet{i}.xml')).findall('s:sheetData/s:row',ns):
            values = {}
            for cell in row.findall('s:c',ns):
                index = 0
                for letter in re.match('[A-Z]+',cell.attrib['r'])[0]:index=index*26+ord(letter)-64
                v = cell.find('s:v',ns);value = v.text if v is not None else None
                if cell.attrib.get('t') == 's':value=strings[int(value)]
                if cell.attrib.get('t') == 'inlineStr':value=''.join(cell.find('s:is',ns).itertext())
                values[index-1] = value if value != '' else None
            assert max(values,default=-1) < width
            cells.append([values.get(k) for k in range(width)])
        sheets.append(cells)
info = [['Field','Value'],['Rank','SPC'],['Last Name','MapLifecycle3cbe642e'],['First Name','Synthetic'],['MOS','68W'],['Duty Role','Medic'],['Group','Alpha'],['ETS',None],['PCS / DEROS',None],['Archived At',None],['Emergency Contact Name','Synthetic Contact'],['Emergency Contact Relationship','Sibling'],['Emergency Contact Phone','555-0101'],['Spouse Name','Synthetic Spouse'],['Spouse Phone','555-0102'],['Vehicle Make/Model','Synthetic Sedan'],['Vehicle Plate','VFY1376'],['Vehicle Color','Blue'],['Personal Email','sheet@example.invalid'],['Personal Phone',None],['Address','1 Test Street, Test City, AK, 99501'],['Leader Notes',None]]
assert sheets[0] == info
assert sheets[1] == [['Training Type','Completed Date','Expiration Date','Notes'],['Verification Required Training','2026-09-14',None,None]]
assert sheets[2][:2] == [['Date','Subject','Key Points','Plan of Action','Status','Follow-Up Date','Notes'],['2026-10-07','FINAL-E9F8E1A9 counseling',None,None,'completed',None,'Literal counseling summary']]
assert sorted(sheets[2][2:],key=lambda x:x[1]) == sorted([['2026-09-14',kind+' counseling 3cbe642e',None,None,'draft',None,None] for kind in ['Active','Archived']],key=lambda x:x[1])
assert sheets[3] == [['Status','Start Date','End Date']]
for family, identity, endpoint in [('counseling',cid,'counseling-records'),('document',did,'documents'),('follow',fid,'follow-ups'),('note',nid,'leader-notes')]:
    h = helper('cleanup-'+family+'-delete')
    assert h['status'] == 200 and h['method'] == 'DELETE' and h['path'].endswith('/'+endpoint+'/'+identity)
absence = {x['path']:x for x in helper('cleanup-created-file-absence')['files']}
assert all(not absence[path]['present'] for path in [cpath,dpath])
assert helper('cleanup-maintained-seeds') == {'cleaned':True,'artifactHttpSessionsCleared':True}
final = rows('restored-original-full')
same_business(original,final)
assert sum(len(v) for tables in original.values() for table,v in tables.items() if table != 'audit_logs') == 27
assert len(final['orgA']['audit_logs']) == 31 and len(final['orgB']['audit_logs']) == 0
assert len([x for x in manifest if x['path'].endswith('.png')]) == 14
if a.checkout and a.freeze:
    frozen = json.loads(a.freeze.read_text())
    assert len(frozen['inputs']) == 5388
    for item in frozen['inputs']:
        b = (a.checkout/item['path']).read_bytes()
        assert sha(b) == item['sha256'] and len(b) == item['bytes'], item['path']
print(json.dumps({'status':'PASS','publicPayloadHashes':474,'originalBusinessRows':27,'SDSLiteralFields':22,'exactArchiveEventChildren':8,'completeWorkbookSheets':4,'storedPDFBytes':4159,'nativeDownloadByteProof':False,'actualPNGs':14,'legitimateAuditsUntilDisposal':31,'CriticalTaskProof':'Registered lifecycle seed ID and maintained journal cleanup; outside full-row tables','frozenInputsChecked':5388 if a.checkout else None},indent=2))
