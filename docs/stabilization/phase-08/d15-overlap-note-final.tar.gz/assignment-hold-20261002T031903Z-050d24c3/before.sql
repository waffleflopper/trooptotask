SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = 'ffebf369-a1b5-4f7c-8154-6c98ae41927f'::uuid AND p.id = 'f6a57232-3999-421e-a72c-b4eef9e7069d'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = 'ffebf369-a1b5-4f7c-8154-6c98ae41927f'::uuid AND id = '06b3adf5-0910-435a-ba1b-4fa6a4043e66'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = 'ffebf369-a1b5-4f7c-8154-6c98ae41927f'::uuid AND s.onboarding_id = 'f6a57232-3999-421e-a72c-b4eef9e7069d'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
