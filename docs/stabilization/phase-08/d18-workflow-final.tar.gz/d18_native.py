import re
import d18_ui as v

def uid(line):
    return line.split('uid=',1)[1].split()[0]

def click(name,page,label,after=None):
    snapshot=v.snap(name+'-before',page)
    area=snapshot.split(after,1)[1] if after else snapshot
    lines=[line for line in area.splitlines() if label in line and 'uid=' in line]
    if len(lines)!=1:
        raise AssertionError((name,label,'expected unique current snapshot control',lines))
    return v.tool(name,'click',pageId=page,uid=uid(lines[0]))

def fill(name,page,label,value):
    snapshot=v.snap(name+'-before',page)
    lines=[line for line in snapshot.splitlines() if label in line and 'uid=' in line]
    if len(lines)!=1: raise AssertionError((name,label,lines))
    return v.tool(name,'fill',pageId=page,uid=uid(lines[0]),value=value)

def screenshot(name,page):
    return v.tool(name,'take_screenshot',pageId=page,filePath=str(v.root/(name+'.png')))

def rows(name,table,organization,field=None,value=None):
    return v.helper(name,'rows',table,organization,*([field,value] if field else []))

def review_click(name,page,resource,button):
    snapshot=v.snap(name+'-before',page)
    area=snapshot.split('StaticText "'+resource+'"',1)[1]
    lines=area.splitlines()[:5]
    matches=[line for line in lines if 'button "'+button+'"' in line]
    if len(matches)!=1: raise AssertionError((name,resource,button,lines))
    return v.tool(name,'click',pageId=page,uid=uid(matches[0]))

def click_group(name,page,group,next_group,label):
    snapshot=v.snap(name+'-before',page)
    area=snapshot.split('row "Collapse '+group+'"',1)[1]
    if next_group: area=area.split('row "Collapse '+next_group+'"',1)[0]
    lines=[line for line in area.splitlines() if label in line and 'uid=' in line]
    if len(lines)!=1: raise AssertionError((name,group,label,lines))
    return v.tool(name,'click',pageId=page,uid=uid(lines[0]))

def click_group_person(name,page,group,next_group,person,button):
    snapshot=v.snap(name+'-before',page)
    area=snapshot.split('row "Collapse '+group+'"',1)[1]
    if next_group: area=area.split('row "Collapse '+next_group+'"',1)[0]
    area=area.split('StaticText "'+person+'"',1)[1].split('\n        uid=',1)[0]
    lines=[line for line in area.splitlines() if 'button "'+button+'"' in line]
    if len(lines)!=1: raise AssertionError((name,group,person,button,area))
    return v.tool(name,'click',pageId=page,uid=uid(lines[0]))
