# Training two-port implementation handoff

Training ordinary persistence is implemented through exactly `TrainingCatalogPersistence` with 17 methods and `TrainingCompletionPersistence` with ten methods. All affected direct and reverse callers are migrated. The old generic Training stores, catalog read wrappers, and all three Entity facades are removed. Focused lower checks pass. No native app was launched. This is an implementation handoff, not independent acceptance.

The branch is `stabilization/1376-training-owned-persistence`. HEAD remains `c911e0a114e1425541fa91a7b66db04bd904dc22`. The executable candidate is `52ef5289737349d6867346bf488184680d3218abb7439448c3dcf7ca54377202`. The stage date is 2026-10-07. `source-census.json` binds the final source hashes. `verify-info-final.log` independently reports the same candidate. Node 24.21.0 was used for npm checks. Installed Supabase SDK 2.106.1 executed against a guarded synthetic HTTP provider in adapter tests. There was no remote or existing local database access. The SDK fixture uses org-a and a foreign org-b, saved actor-a View metadata, and the literal timestamp `2026-10-07T12:00:00.123456Z`. The existing completion is dated 2026-01-01. Operation fixtures include owner, ordinary member, Training-none, and Group-scoped grants. No native actor, Organization, or UI date was invented for this stage.

## Implementation and authority

Each ordinary factory captures the admitted request Supabase client and canonical Organization once. Narrow contexts expose only the operation's required method Picks. The ordinary ports never acquire an admin client and never accept caller Organization, table, select, filter language, or generic Record/result. A request-authority test constructs factories, mutates a separate mutable auth fixture afterward, and still reads only org-a. Its admin acquisition stub throws and is never called.

Fixed projections retain the saved Type/View/Completion key sets of 20, seven, and ten. Type retains `organization_id` and `created_at`, without `updated_at`. View retains `createdBy`, `createdAt`, and `updatedAt`, plus `organization_id`. Completion retains `organization_id`, `created_at`, and `updated_at`. Private named SQL row mappers preserve missing-property omission. Known present NULL arrays become empty arrays and known present NULL flags become false where the old full model did so. Raw timing, import, and rank references retain their existing NULL meaning. The adapter's final saved-model assertion preserves the previous permissive missing-row-property behavior instead of adding a new runtime decoder.

All complete list methods use the shared installed-SDK page helper. Tests cover 1001 matching rows and a rejected later page in ten list families. Estimated count retains id-only selection, range 0..0, and NULL as zero. `.single()` lookups retain PGRST116-to-null behavior and reject other errors. Starter name-race reread remains. Ordinary create/update Zod validation, defaults, messages, and read-only stripping remain at the operation boundary. Direct completion patch intentionally retains its old malformed-known runtime semantics. Its behavior test forwards malformed known notes/certificate values while stripping unrelated fields and retaining omitted dates.

Batch completed upsert precedes serial exemption rechecks and updates. It preserves existing record IDs and omitted certificate. A late exemption error leaves the already completed upsert and earlier exemption change intact and prevents the final audit. No transaction, RPC, new N+1, or speculative validation was added. Workspace and report source branches remain parallel with seven inputs. Personnel readiness admits the Person/Group before either Training source. Personnel export receives four facts mapped by delivery into its existing workbook keys. This avoids a new Personnel-to-Training ownership cycle. Training-none retains the empty Training sheet.

Onboarding references remain separately admitted and lazily privileged. Their 500-row paging, 100-Person chunks, four parallel batches, and join scope remain intact. Approved deletion, type-name audit, platform support count, and raw archive retain their independent authority. Raw archive retains complete select * for the three approved tables. Generic shared facades remain for later feature owners only.

## Changed paths and removals

`changed-paths.json` is the complete list of 66 stage-changed paths, including seven deletions. `caller-census.md` names every consumer and retained purpose boundary. `legacy-symbol-census.txt` has zero surviving old Training seam or Entity references. `port-caller-census.txt` and `purpose-table-census.txt` preserve the searches. Both contract method lists are recorded literally in `source-census.json`.

The source groups are Training contracts, both adapters and private mappers, narrow operation contexts, operations/batch/read/workspace/report/readiness orchestration, feature request factories, Dashboard, Personnel export delivery, Getting Started, Starter, rank settings, Onboarding references, and approved deletion. Feature-owned memory ports and installed-SDK provider fixtures replace generic Training test inputs. Seven obsolete files are deleted as listed in the census. Obsolete exports are removed in the same wave.

`scripts/module-boundaries.json` registers only three exact private Training test-support files and the exact request-authority test under delivery ownership. No scanner waiver, broad allowance, or new feature dependency was introduced. The root Person repair, its test, client stores, print components, and report/export calculations were not edited. All 59 protected Training UI/store/utility files match their stage-entry hashes. Existing root ledgers, recipes, and archives remain untouched by this stage.

## Current checks

| Check | Result and exact receipt |
| --- | --- |
| Final affected selection | 31 suites / 252 tests selected. `focused-final.log` preserves 29 passing suites and 250 passing tests with two fixture failures. Those two are now resolved by the focused receipts below. This is composed proof, not a fabricated single green run. |
| Operation and memory boundary | PASS, four suites / 45 tests in `operations-current.log`. This includes the earlier remaining memory projection failure. |
| Final failed and adjacent fixtures | PASS, three suites / 21 tests in `final-failed-adjacent.log`. Onboarding references, report-page delivery, and report query. |
| Request authority after readonly fixture correction | PASS, one suite / one test in `request-authority-final.log`. |
| Installed-SDK adapters and request/report/workspace boundary | PASS, four suites / 30 tests in `request-parallel-sources.log`, including all 13 adapter tests. |
| Starter and Personnel export | PASS, three suites / 24 tests in `starter-export-fixed.log`. |
| Types | PASS, zero errors and zero warnings in `types-final-fixed.log`. |
| Governance | PASS regression in `governance-final-fixed.log`. Existing 157 program findings remain open. |
| Governance rule tests | PASS, two suites / 22 tests in `governance-rules-final.log`. |
| Touched TypeScript lint | PASS, zero warnings/errors in `lint-ts-final.log`. |
| Touched format and whitespace | PASS in `format-final-fixed.log` and `diff-final-fixed.log`. |
| Native, production build, full DoD, current-head CI | UNRUN in this stage by explicit scope. Root owns later exact-head CI and native reconciliation. |

The logs preserve every failure. `adapters-first.log` caught the synthetic provider's unsupported on_conflict filter, fixed in the private provider. `operations-first.log` caught an actual mechanical exemptPersonnelIds naming error, corrected before the current PASS. `operations-fixed.log` retained one memory-label projection failure, resolved by a narrow projection in the memory port. `types-first.log` and `types-final.log` preserve obsolete fixture types and the readonly test mutation respectively. `boundaries-first.log` and `starter-fixed.log` preserve the old Starter fake's missing insert behavior. `governance-first.log`, `governance-second.log`, and `governance-final.log` preserve missing exact ownership and a rejected dependency cycle. The cycle was removed through delivery mapping, not waived. `focused-final.log` preserves the last two stale fixtures. The final lint receipt supersedes the earlier JSON ignored-file warning. No failed observation was erased or converted into a PASS without a passing check.

## Prior proof and remaining acceptance

`proposed-native-selection.md` ties each next check to the changed persistence path. Representative catalog/View writes, record/batch identity and nullable fields, ordinary scope/denial, complete report/detail/workbook rows, and affected reverse consumers need new integration evidence. No current native PASS is claimed. The selected lower tests leave no known implementation gap, subject to root inspection and independent review.

The original baseline remains bound to candidate 590fe5b7 and its original actor, fixtures, and archive. Root's Person save repair remains bound to candidate 93ab5146 and session 9a0503f5-2d8c-4e39-a014-2e1894a4c3dd. The required supplement remains bound to candidate 4f9ff79a and closed session c86d4eb9-2d3f-4fd8-9e5d-fa92a2c8e38a. Those sources have not been changed by this implementation except the ordinary persistence wiring that the proposal explicitly rechecks. The original 36 PASS observations are not silently rebound to this candidate.

Accepted #1562 retired-editor lifetime and unchanged root draft/retry/Cancel UI behavior do not need wholesale replay. The supplement's exact Dense PDF has intact organization/title/range/context on all five pages under the separate artifact-correction receipt. No print source repair exists. Accepted #1550 Short/Empty layout, theme, and paper variants retain only their original exact source/input binding. They do not imply a new PDF capture at this candidate. Original Offline control FAIL and associated historical UNRUN remain explicit. Starter has no native Apply UI, and deferred rank edges remain deferred. D29/D30 and ordinary Onboarding persistence were not opened.

Issue remainder is current-candidate native integration, full exact-head CI, independent reviews, and root reconciliation/packaging. No commit, archive, publication, or approval claim was made here.

## Decisions, throughput, and terminal closure

Model the Domain fixed saved models and narrow projections before migration. Boundary Discipline retained operation validation and private SQL mapping. Migrate Callers Then Delete removed all obsolete seams in one wave. Laziness Protocol removed catalog pass-through wrappers and avoided a third ordinary port. Test Behavior Not Implementation preserved literal metadata, authority, identity, NULL/omission, certificate, paging/error, and partial-effect outcomes. Prove It Works kept current native and independent acceptance pending rather than treating lower checks as end-to-end proof. Their leaf skills were read. `selection.md` and `decisions.tsv` retain the bounded sequential workflow and substantive choices.

The throughput checkpoint was adapter proof first, cohesive caller/removal migration second, focused behavior/type/governance repair third, and handoff last. No production build or long-lived service consumed shared app capacity. All short-lived check commands finished. This stage acquired zero app sessions, browsers, containers, database rows, or owned long-lived process identities. No hook or database restoration was necessary. `stage-resource-receipt.json` rechecks the exact prior nine owned ports and worker-1 directory as absent. Prior actual PID/start/group, five-container removal, and retention of 41 preexisting containers, seven networks, and 17 volumes remain in the linked earlier closure receipt. This is reuse of actual closure proof, not a new claim that this stage inspected every resource.

The earlier exploratory guessed-port probe remains separately labeled in `initial-port-probe.json` and is not used as an ownership receipt. The authoritative current stage receipt uses the actual prior owned port list. Root's sources and archives remain present. Ownership is released to root at this terminal handoff. Native remains unlaunched.
