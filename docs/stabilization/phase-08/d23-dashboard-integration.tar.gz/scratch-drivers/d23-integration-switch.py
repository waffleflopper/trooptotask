import importlib.util,re,json
spec=importlib.util.spec_from_file_location('capture','.verification/tmp/d23-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
actor=m.call('helper','actor',['dashboardSwitch','calendar'],'actor-switch.json');page=actor['pageId']
def snap(label):
 x=m.native('take_snapshot',{'pageId':page},label+'.json');return '\n'.join(c.get('text','')for c in x['content'])
def click(label,role,name):
 t=snap(label+'-before')
 modal=re.search(r'uid=(\S+) button "Got it"',t)
 if modal:
  m.native('click',{'pageId':page,'uid':modal[1]},label+'-dismiss.json');t=snap(label+'-dismissed')
 uid=re.search(r'uid=(\S+) '+role+r' "'+re.escape(name)+r'"',t)
 if not uid:raise RuntimeError('Missing '+name)
 m.native('click',{'pageId':page,'uid':uid[1]},label+'-click.json')
def key(label,k):m.native('press_key',{'pageId':page,'key':k},label+'.json')
def choose(label,org):
 click(label+'-menu','button','Switch organization')
 for i in range(4):
  key(label+'-key-'+str(i),'ArrowDown');t=snap(label+'-focused-'+str(i))
  if re.search(r'menuitem "VO Verification Organization '+org+r' member"[^\n]*focused',t):break
 else:raise RuntimeError('No keyboard focus on '+org)
 key(label+'-enter','Enter')
m.call('helper','server-source',['arm','availability_entries','hold','1','120000'],'held-switch-arm.json')
click('held-switch-home','link','Home')
state=m.call('helper','server-source',['state'],'held-switch-state.json');assert state['control']['phase']=='held'
choose('held-switch-B','B')
t=snap('held-switch-B-before-release');assert 'Verification Organization B — Dashboard' in t and 'StaticText "100%"' in t
m.call('helper','server-source',['release'],'held-switch-release.json')
m.call('helper','server-source',['restore'],'held-switch-restore.json')
m.capture(page,'held-switch-B')
choose('held-switch-return','A');m.capture(page,'held-switch-A')
m.call('helper','dashboard-access',['dashboardSwitch','alpha'],'scope-narrowed-change.json')
m.call('helper','rows',['organization_memberships','orgA'],'scope-narrowed-memberships.json');m.capture(page,'scope-narrowed')
m.call('helper','dashboard-access',['dashboardSwitch','restore'],'scope-restored-change.json')
m.call('helper','rows',['organization_memberships','orgA'],'scope-restored-memberships.json');m.capture(page,'scope-restored')
print('Held source keyboard switch and restored membership captured',flush=True)
