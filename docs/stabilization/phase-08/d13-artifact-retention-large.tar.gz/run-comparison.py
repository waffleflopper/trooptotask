from pathlib import Path
import json
p=Path(__file__).parent; seed=json.load(open(p/'seed.json'));results=[]
for f in p.glob('before-org*.json'):
 before=json.load(open(f));after=json.load(open(p/f.name.replace('before-','after-')));assert before==after,f.name
 results.append({'organization':before['organization'],'table':before['table'],'count':before['count'],'allFieldsUnchanged':True})
for family in seed['rows']:
 before=json.load(open(p/('before-orgA-'+family['table']+'.json')))['rows'];ids={r['id'] for r in before}
 expected={i['row']['id'] for i in family['records'] if i['row']['organization_id']==seed['parents'][0]['row']['organization_id']}
 assert expected==ids,family['table'];assert seed['pageMarkerIds'][family['table']] in ids
 assert sum(r['archived_at']==seed['expiredAt'][:19]+'+00:00' for r in before)==1001,(family['table'],before[0]['archived_at'])
assert json.load(open(p/'files-before.json'))==json.load(open(p/'files-after.json'))
files=json.load(open(p/'files-after.json'))['files'];expected={f['path']:f for f in seed['files']};assert len(files)==len(expected)==14
for f in files:
 assert f['present'] and f['observedSize']==expected[f['path']]['size'] and f['observedSha256']==expected[f['path']]['sha256'],f['path']
assert json.load(open(p/'settings-before.json'))==json.load(open(p/'settings-after.json'))
cron=json.load(open(p/'cron-run.json'));assert cron['status']==500 and json.loads(cron['body'])=={'message':'Internal Error'}
assert 'Error: URI too long' in (p/'app-after-job.log').read_text()
report={'expected':'Successful4004expiredchild deletions and matching counts/files with active parents retained','actual':'Owned admitted jobHTTP500/Internal Error; production app logURI too long at generic child delete','completeRowComparisons':results,'realFilesUnchangedExactHashes':14,'expiredRowsRemainingPerFamily':1001,'notifications':0,'settingsUnchanged':True,'limitations':'Actual early Follow-up deletion rejection stops later families. Independent real-SDK probes establish each separate family failure; this live call provides no later-family dispatch or providerHTTPstatus/URLlength receipt. Final-generated IDs prove known cohort rows, not discovery-page placement.'}
(p/'run-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'jobStatus':500,'completeRowsComparisons':len(results),'expiredRowsRemaining':4004,'retainedRealFileHashes':14,'noNotification':True}))
