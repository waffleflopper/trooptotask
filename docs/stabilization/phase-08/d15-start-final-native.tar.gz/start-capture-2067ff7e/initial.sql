SET statement_timeout='10s'; SET lock_timeout='3s';
SELECT json_build_object(
 'person', (SELECT json_build_object('id',id,'organization_id',organization_id,'group_id',group_id,
 'rank',rank,'first_name',first_name,'last_name',last_name,'slug',slug,'archived_at',archived_at)
 FROM public.personnel WHERE organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND id='0dd9c08e-efb0-4613-ba37-cd935cda817e'::uuid),
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND p.personnel_id='0dd9c08e-efb0-4613-ba37-cd935cda817e'::uuid),'[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 JOIN public.personnel_onboardings p ON p.organization_id=s.organization_id AND p.id=s.onboarding_id
 WHERE p.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND p.personnel_id='0dd9c08e-efb0-4613-ba37-cd935cda817e'::uuid),'[]'::json),
 'training', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.personnel_trainings t
 WHERE t.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND t.personnel_id='0dd9c08e-efb0-4613-ba37-cd935cda817e'::uuid),'[]'::json),
 'templates', COALESCE((SELECT json_agg(t ORDER BY t.id) FROM public.onboarding_templates t
 WHERE t.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND t.id='27a373f6-2843-4fbe-93f4-8442c01c1dc2'::uuid),'[]'::json),
 'definitions', COALESCE((SELECT json_agg(d ORDER BY d.sort_order,d.id) FROM public.onboarding_template_steps d
 WHERE d.organization_id='952f59bb-9db8-4a2a-852b-3fcea91b2b24'::uuid AND d.template_id='27a373f6-2843-4fbe-93f4-8442c01c1dc2'::uuid),'[]'::json));
