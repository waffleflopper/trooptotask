# Validation receipts

Node24.21.0, npm11.19.0, SupabaseCLI2.101.0, isolated Postgres17.6, pg_prove3.36 and Chromium152.0.7977.82. PATH selected /home/waffleflops/.local/share/mise/installs/node/24.21.0/bin. TMPDIR=/home/waffleflops/.cache/t2t-1501-tmp. Later commands used NODE_DISABLE_COMPILE_CACHE=1. No protected existing or remote database was accessed.

Required npm run format completed0. Final npm run gate completed0. It includes format:check,lint,governance:check,check,test. Final tests660files6384tests; typecheck0errors0warnings. npm run build completed0. Touched Markdown explicitly formatted and local links checked. Helpers24tests and CI lifecycle/safety14tests pass.

Build non-secret overrides are PUBLIC_SUPABASE_URL=http://127.0.0.1:59999, PUBLIC_SUPABASE_ANON_KEY=ci-synthetic-anon, SUPABASE_SERVICE_ROLE_KEY=ci-synthetic-service, ACCOUNT_SETUP_LINK_SECRET=ci-synthetic-setup, ACCOUNT_SETUP_SESSION_SECRET=ci-synthetic-session, APP_PUBLIC_ORIGIN=http://127.0.0.1:4173, PUBLIC_APP_ORIGIN='',PUBLIC_SITE_URL='',APP_PUBLIC_ORIGIN_ALLOWLIST=''. These are intentionally synthetic values and unreachable local providers.

Material warnings remain unchanged: three Svelte Map/Set lint warnings in Calendar/Onboarding, governance's418reported historical findings with regression gate passing, build chunk-size warning and optional @opentelemetry/api dependency-resolution warning. Test bad-revision1234567890abcdef is an intentional negative fixture; tests pass.

## Database

python3 scripts/ci/database.py completed0 in database-accepted.log. It starts seed-disabled disposable stacks, runs npm run db:test, retained pgTAP suites, added fresh/migration contracts and real provider probes, then cleans only owned resources. Fresh167migrations from20260413001158_remote_schema through20261004000100_training_readiness_goal. Populated audited predecessor141migrations through20261002000100_atomic_onboarding_note_append, creates synthetic historical witnesses, then supabase migration up --local --yes --include-all applies staged26migrations. New goal contract19assertions passes fresh and upgraded. Existing predecessor identities/values remain protected by exact comparisons, apart from the intentionally added goal field checked separately.

Fresh project t2t-ci-db-na7441qt in TMPDIR. Ports api62126,db62824,shadow64225,pooler64246,studio62014,inbucket64980,edge63688,analytics59813. Populated project t2t-ci-db-y6qxptyd and its exact allocated ports/commands appear in database-accepted.log. Both cleanup completed0.

database.log and database-upgrade-final.log are superseded failing predecessor-schema comparisons. database-final.log is a superseded Docker temporary-mount failure due to /tmp inode exhaustion. Reclaimed5000regular Node compile-cache entries owned by this user, older than one hour, in /tmp/node-compile-cache/v24.21.0-x64-964aae3f-1000. They are regenerable cache bytes, not database/project data. The accepted complete replay covers all failed test paths with unchanged budgets.

## Decision trail and reviews

decisions.tsv is append-only. Timestamps are log-entry times. Its first five rows retrospectively summarize earlier work from the active digest; they are not original action timestamps. Later rows supersede pending results and add acceptance checkpoints. No private host store was read.

Visual review accepted desktop light screenshots and accessible descriptions. Its audit flags led to final gate/build repetition, explicit startup-attempt labeling, complete checkpoint rows and finished packaging. The delegate report preserves its original earlier scope and flags. Codex independent source review found no correctness/security/performance defects and three prose corrections were applied. Subsequent expanded-artifact acceptance is recorded in the task acceptance record.

Deslop was absent. Parent directly checked the actual diff for dead code, speculative abstractions, casts, suppressions, stale caller paths, incidental test assertions and unrelated changes. Independent no-comments pass removed three new SQL narration comments; required public readiness-contract comments remain.

candidate.patch contains the application/contract/SQL diff against4d1f1dec6f96b6892245522fa3dfefd5cf4c7fae before final evidence packaging. Browser candidateb1f29a4ec4f8769735c3642790fcb529007d95bb85c24fa21ce67fef32c74136 is retained in accepted doctor receipts. Later architecture wording and acceptance packaging are prose/evidence-only; executable and driving inputs did not change.

