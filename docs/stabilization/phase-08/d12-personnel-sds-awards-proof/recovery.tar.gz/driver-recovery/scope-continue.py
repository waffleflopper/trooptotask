import json
from scope_helpers import *
page=json.loads((base/'scope-personnelScoped-page.json').read_text())['pageId']
before={o:{t:json.loads((base/('scope-alpha-denials-before-'+o+'-'+t+'.json')).read_text())['rows'] for t in ['personnel','personnel_extended_info']} for o in ['orgA','orgB']}
after=projections('scope-alpha-initial-attempt-after');assert before==after
beforeAudits=json.loads((base/'scope-alpha-denials-audit-before.json').read_text())['rows'];afterAudits=call('scope-alpha-initial-attempt-audit-after','control','rows','audit_logs','orgA')['rows']
select=lambda rows:sorted((r['id'],r['action'],r.get('resource_id')) for r in rows if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared'])
assert select(beforeAudits)==select(afterAudits)
checks.append({'scenario':'Initial Bravo denial with unsupported403 scratch expectation','result':'ACTUAL_CONTRACT_PASS_EXPECTATION_ATTEMPT_RETAINED','ackStatus':404,'sdsStatus':404,'allFullABRowsExact':True,'successAuditsExact':True})
for role,field,expected in [('manager','emergency_contact_phone','907-555-0188'),('personnelScoped','emergency_contact_name','Scoped Synthetic Contact')]:
 b=json.loads((base/('scope-'+role+'-sds-before.json')).read_text())['rows'][0];a=json.loads((base/('scope-'+role+'-sds-after.json')).read_text())['rows'][0]
 siblings_equal(b,a,{field,'updated_at'});assert a[field]==expected and a['award_tracking_acknowledged_at']==b['award_tracking_acknowledged_at']
 checks.append({'scenario':role+' native admitted save/reload preserves siblings','result':'PASS','before':b,'after':a})
denied_batch('scope-alpha-confirmed-denials',page,[('bravo',seed['ids']['duplicateBravo'],ORG,404,404),('unassigned',fixture['ids']['personUnassigned'],ORG,404,404),('foreign-person',fixture['ids']['personForeign'],ORG,404,404),('missing','11111111-1111-4111-8111-111111111111',ORG,404,404)])
for role in ['scoped','personnelOperate','personnelEmpty','viewer','foreign']:
 actor=call('scope-'+role+'-login','control','actor',role,'personnel');page=actor['pageId'];(base/('scope-'+role+'-page.json')).write_text(json.dumps({'pageId':page},indent=2)+'\n')
 s=snapshot('scope-'+role+'-roster',page);shot('scope-'+role+'-roster',page)
 if role=='scoped':
  f=flags('scope-view-only-flags',page);assert any(set(m['ids'])=={PERSON} for m in f['matches']),f
  assert 'More info' not in s
  denied_batch('scope-view-only-denied',page,[('alpha',PERSON,ORG,403,403)])
 elif role=='personnelOperate':
  open_person('scope-operate-detail-open',page);s=snapshot('scope-operate-detail-denial',page);shot('scope-operate-detail-denial',page);assert 'More info' not in s and ('Forbidden' in s or '403' in s),s
  before=row('scope-operate-before')[0]
  r=request('scope-operate-sds-allowed',page,'/org/'+ORG+'/api/personnel/'+PERSON+'/extended-info','PUT',{**BODY,'emergencyContactName':'Scoped Synthetic Contact','emergencyContactPhone':'907-555-0177'});assert r['status']==200,r
  after=row('scope-operate-after')[0];siblings_equal(before,after,{'emergency_contact_phone','updated_at'});assert after['emergency_contact_phone']=='907-555-0177'
  assert ack('scope-operate-ack-allowed',page)['status']==200
  checks.append({'scenario':'operate-only API permitted while native dashboard remains denied','result':'PASS','before':before,'after':after,'nativeLimit':'Actual More info unavailable through denied detail dashboard; no bypassed UI pass.'})
 elif role=='personnelEmpty':
  f=flags('scope-empty-flags',page);assert any(m['ids']==[] for m in f['matches']),f
  assert seed['name'] not in s
  denied_batch('scope-empty-denied',page,[('alpha',PERSON,ORG,404,404)])
 elif role=='viewer':
  f=flags('scope-viewer-flags',page);assert any(set(m['ids'])=={PERSON,seed['ids']['duplicateBravo']} for m in f['matches']),f
  denied_batch('scope-viewer-denied',page,[('alpha',PERSON,ORG,403,403)])
 elif role=='foreign':
  assert seed['name'] not in s
  denied_batch('scope-foreign-org-denied',page,[('a-target',PERSON,ORG,403,403)])
(base/'scope-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'boundary':'Native normal/denied affordances, ordinary authenticated requests, public authorized IDs and real28-field A/B provider rows; no full data stream retained.','originalFailure':'Initial scratch403 expectation corrected from independently observed identical baseline404 and same authenticated request-storeRLS; exact initial artifacts retained.'},indent=2)+'\n')
