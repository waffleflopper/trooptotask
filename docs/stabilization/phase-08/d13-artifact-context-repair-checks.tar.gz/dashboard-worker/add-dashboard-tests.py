from pathlib import Path
p=Path('/home/waffleflops/.cache/t2t-d13-context-test-preparation/src/features/personnel/components/PersonnelDetailPageView.svelte.test.ts')
s=p.read_text().replace('{ cleanup, fireEvent, render, screen, waitFor }','{ act, cleanup, fireEvent, render, screen, waitFor, within }')
s=s.replace("import type { PersonnelDetailStreams }", "import type { PersonnelDetailStreams, PersonnelFollowUp, PersonnelDocument, PersonnelCounselingRecord }")
s=s.replace("import type { Personnel } from '../personnel.types';", "import type { Personnel } from '../personnel.types';\nimport type { PersonnelLeaderNote } from '$features/personnel/contracts';")
s += r'''

const dashboardContextChanges = [
	{ name: 'another Person', orgId: 'org-1', personId: 'person-2' },
	{ name: 'another Organization and Person', orgId: 'org-2', personId: 'person-2' }
];
const dashboardFamilies = [
	{ name: 'follow-up', key: 'followUp', field: 'Follow-up title', endpoint: 'follow-ups', fileField: null },
	{ name: 'document', key: 'document', field: 'Document title', endpoint: 'documents', fileField: 'Document file' },
	{ name: 'counseling', key: 'counseling', field: 'Counseling title', endpoint: 'counseling-records', fileField: 'Counseling PDF' },
	{ name: 'note', key: 'note', field: 'New leader note', endpoint: 'leader-notes', fileField: null }
] as const;
type DashboardFamily = (typeof dashboardFamilies)[number];

function dashboardArtifacts(personnelId: string, marker: string) {
	const common = { personnelId, createdAt: '2026-06-08T10:00:00.000Z', archivedAt: null };
	return {
		followUp: { ...common, id: `follow-up-${personnelId}`, title: `${marker} follow-up`, notes: '', dueDate: null, status: 'open', createdBy: 'Synthetic leader', updatedAt: common.createdAt, completedAt: null } satisfies PersonnelFollowUp,
		document: { ...common, id: `document-${personnelId}`, title: `${marker} document`, fileName: 'document.pdf', fileSizeBytes: 1024, contentType: 'application/pdf', uploadedBy: 'Synthetic leader' } satisfies PersonnelDocument,
		counseling: { ...common, id: `counseling-${personnelId}`, title: `${marker} counseling`, dateConducted: '2026-06-08', summary: 'Synthetic goals', status: 'uploaded', uploadedBy: 'Synthetic leader', fileName: 'counseling.pdf' } satisfies PersonnelCounselingRecord,
		note: { ...common, id: `note-${personnelId}`, text: `${marker} note`, author: 'Synthetic leader', date: '2026-06-08' } satisfies PersonnelLeaderNote
	};
}

function dashboardDetail(personnelId: string, marker: string) {
	const rows = dashboardArtifacts(personnelId, marker);
	return makeDetail({
		followUps: Promise.resolve([rows.followUp]),
		documents: Promise.resolve([rows.document]),
		counselingRecords: Promise.resolve([rows.counseling]),
		leaderNotes: Promise.resolve([rows.note])
	});
}

function dashboardProps(orgId = 'org-1', personId = 'person-1', detail = makeDetail()) {
	return { requestArchiveApproval, orgId, orgName: 'Synthetic unit', person: { ...person, id: personId, slug: `synthetic-${personId}` }, detail };
}

function dashboardDeferred() {
	let resolve!: (response: Response) => void;
	const promise = new Promise<Response>((respond) => { resolve = respond; });
	return { promise, resolve };
}

async function settleDashboardResponse(pending: ReturnType<typeof dashboardDeferred>, body: unknown) {
	const response = Response.json(body);
	await act(async () => {
		pending.resolve(response);
		await pending.promise;
		await response.clone().text();
	});
}

async function fillDashboardArtifact(family: DashboardFamily, text: string) {
	const field = await screen.findByLabelText(family.field);
	if (family.fileField) {
		const input = screen.getByLabelText(family.fileField) as HTMLInputElement;
		const transfer = new DataTransfer();
		transfer.items.add(new File(['%PDF-1.4\nsynthetic'], `${text}.pdf`, { type: 'application/pdf' }));
		// Preserve the native files setter so value='' can actually clear the picker.
		input.files = transfer.files;
		await fireEvent.change(input);
		expect(input.files?.[0]?.name).toBe(`${text}.pdf`);
	}
	await fireEvent.input(field, { target: { value: text } });
}

async function submitDashboardArtifact(family: DashboardFamily) {
	const form = screen.getByLabelText(family.field).closest('form');
	if (!form) throw new Error('Dashboard artifact form not found');
	await fireEvent.click(within(form).getByRole('button', { name: /^(Add|Add note|Upload|Upload PDF)$/ }));
}

describe('Personnel Dashboard artifact context and pickers', () => {
	describe.each(dashboardFamilies)('$name', (family) => {
		it.each(dashboardContextChanges)('clears the previous draft and created rows on $name', async (next) => {
			const fetchMock = vi.fn().mockResolvedValueOnce(Response.json(dashboardArtifacts('person-1', 'Saved A')[family.key]));
			vi.stubGlobal('fetch', fetchMock);
			const view = render(PersonnelDetailPageView, { props: dashboardProps() });
			await fillDashboardArtifact(family, `Saved A ${family.name}`);
			await submitDashboardArtifact(family);
			await screen.findByText(`Saved A ${family.name}`);
			await fillDashboardArtifact(family, 'A unsaved draft');
			await view.rerender(dashboardProps(next.orgId, next.personId, dashboardDetail(next.personId, 'Loaded B')));

			expect(await screen.findByText(`Loaded B ${family.name}`)).toBeTruthy();
			expect.soft((screen.getByLabelText(family.field) as HTMLInputElement).value).toBe('');
			expect.soft(screen.queryByText(`Saved A ${family.name}`)).toBeNull();
			if (family.fileField) expect.soft((screen.getByLabelText(family.fileField) as HTMLInputElement).files?.length).toBe(0);
		});

		it('preserves the next record draft when the old create completes', async () => {
			const pending = dashboardDeferred();
			const fetchMock = vi.fn().mockReturnValueOnce(pending.promise);
			vi.stubGlobal('fetch', fetchMock);
			const view = render(PersonnelDetailPageView, { props: dashboardProps() });
			await fillDashboardArtifact(family, `Pending A ${family.name}`);
			await submitDashboardArtifact(family);
			expect(fetchMock.mock.calls[0][0]).toBe(`/org/org-1/api/personnel/person-1/${family.endpoint}`);
			await view.rerender(dashboardProps('org-2', 'person-2', dashboardDetail('person-2', 'Loaded B')));
			await fillDashboardArtifact(family, 'B unsaved draft');
			await settleDashboardResponse(pending, dashboardArtifacts('person-1', 'Pending A')[family.key]);

			expect.soft((screen.getByLabelText(family.field) as HTMLInputElement).value).toBe('B unsaved draft');
			expect.soft(screen.queryByText(`Pending A ${family.name}`)).toBeNull();
			expect.soft(screen.getByText(`Loaded B ${family.name}`)).toBeTruthy();
			if (family.fileField) expect.soft((screen.getByLabelText(family.fileField) as HTMLInputElement).files?.[0]?.name).toBe('B unsaved draft.pdf');
		});
	});

	it.each([dashboardFamilies[1], dashboardFamilies[2]])('retains the $name picker on failure and clears it after successful retry', async (family) => {
		const fetchMock = vi.fn().mockResolvedValueOnce(new Response(null, { status: 503 })).mockResolvedValueOnce(Response.json(dashboardArtifacts('person-1', 'Retried')[family.key]));
		vi.stubGlobal('fetch', fetchMock);
		render(PersonnelDetailPageView, { props: dashboardProps() });
		await fillDashboardArtifact(family, `Retried ${family.name}`);
		await submitDashboardArtifact(family);
		const form = screen.getByLabelText(family.field).closest('form');
		if (!form) throw new Error('Dashboard artifact form not found');
		await waitFor(() => expect(within(form).getByRole('button', { name: /^(Upload|Upload PDF)$/ }).hasAttribute('disabled')).toBe(false));
		expect((screen.getByLabelText(family.field) as HTMLInputElement).value).toBe(`Retried ${family.name}`);
		expect((screen.getByLabelText(family.fileField) as HTMLInputElement).files?.[0]?.name).toBe(`Retried ${family.name}.pdf`);
		await submitDashboardArtifact(family);
		await screen.findByText(`Retried ${family.name}`);
		expect((fetchMock.mock.calls[1][1].body as FormData).get('file')).toMatchObject({ name: `Retried ${family.name}.pdf` });
		expect.soft((screen.getByLabelText(family.field) as HTMLInputElement).value).toBe('');
		expect.soft((screen.getByLabelText(family.fileField) as HTMLInputElement).files?.length).toBe(0);
	});

	it('preserves current drafts and files when the same record streams refresh', async () => {
		const view = render(PersonnelDetailPageView, { props: dashboardProps('org-1', 'person-1', dashboardDetail('person-1', 'Earlier')) });
		for (const family of dashboardFamilies) await fillDashboardArtifact(family, `Still editing ${family.name}`);
		await view.rerender(dashboardProps('org-1', 'person-1', dashboardDetail('person-1', 'Refreshed')));
		for (const family of dashboardFamilies) {
			expect(await screen.findByText(`Refreshed ${family.name}`)).toBeTruthy();
			expect((screen.getByLabelText(family.field) as HTMLInputElement).value).toBe(`Still editing ${family.name}`);
			if (family.fileField) expect((screen.getByLabelText(family.fileField) as HTMLInputElement).files?.[0]?.name).toBe(`Still editing ${family.name}.pdf`);
		}
	});

	it('does not clear a new Person pending status action when the old action completes', async () => {
		const pendingA = dashboardDeferred();
		const pendingB = dashboardDeferred();
		const fetchMock = vi.fn().mockReturnValueOnce(pendingA.promise).mockReturnValueOnce(pendingB.promise);
		vi.stubGlobal('fetch', fetchMock);
		const view = render(PersonnelDetailPageView, { props: dashboardProps('org-1', 'person-1', dashboardDetail('person-1', 'A')) });
		await fireEvent.click(await screen.findByRole('button', { name: 'Complete A follow-up' }));
		await view.rerender(dashboardProps('org-1', 'person-2', dashboardDetail('person-2', 'B')));
		await fireEvent.click(await screen.findByRole('button', { name: 'Complete B follow-up' }));
		expect(screen.getByRole('button', { name: 'Complete B follow-up' }).hasAttribute('disabled')).toBe(true);
		await settleDashboardResponse(pendingA, { ...dashboardArtifacts('person-1', 'A').followUp, status: 'completed', completedAt: '2026-06-08T10:10:00.000Z' });
		expect.soft(screen.getByRole('button', { name: 'Complete B follow-up' }).hasAttribute('disabled')).toBe(true);
		await settleDashboardResponse(pendingB, { ...dashboardArtifacts('person-2', 'B').followUp, status: 'completed', completedAt: '2026-06-08T10:11:00.000Z' });
		expect(screen.queryByRole('button', { name: 'Complete B follow-up' })).toBeNull();
	});

	it('ignores the previous Organization document Open response and opens the current one', async () => {
		const pending = dashboardDeferred();
		const open = vi.spyOn(window, 'open').mockImplementation(() => null);
		const fetchMock = vi.fn().mockReturnValueOnce(pending.promise).mockResolvedValueOnce(Response.json({ url: 'https://example.invalid/b.pdf' }));
		vi.stubGlobal('fetch', fetchMock);
		const view = render(PersonnelDetailPageView, { props: dashboardProps('org-1', 'person-1', dashboardDetail('person-1', 'A')) });
		await fireEvent.click(await screen.findByRole('button', { name: 'Open' }));
		await view.rerender(dashboardProps('org-2', 'person-2', dashboardDetail('person-2', 'B')));
		await screen.findByText('B document');
		await settleDashboardResponse(pending, { url: 'https://example.invalid/a.pdf' });
		expect.soft(open).not.toHaveBeenCalled();
		await fireEvent.click(screen.getByRole('button', { name: 'Open' }));
		await waitFor(() => expect(open).toHaveBeenCalledWith('https://example.invalid/b.pdf', '_blank', 'noopener,noreferrer'));
		expect(fetchMock.mock.calls[1][0]).toBe('/org/org-2/api/personnel/person-2/documents/document-person-2/download');
	});
});
'''
p.write_text(s)
