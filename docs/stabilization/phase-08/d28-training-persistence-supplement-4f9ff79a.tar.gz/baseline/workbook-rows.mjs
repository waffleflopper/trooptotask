import ExcelJS from '/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-ef045b93/node_modules/exceljs/excel.js';
import fs from 'node:fs/promises';
const workbook = new ExcelJS.Workbook();
await workbook.xlsx.readFile(process.argv[2]);
const sheets = Object.fromEntries(workbook.worksheets.map(sheet => [sheet.name, Array.from({length: sheet.rowCount}, (_, i) => sheet.getRow(i + 1).values.slice(1))]));
await fs.writeFile(process.argv[3], JSON.stringify(sheets, null, 2));
console.log(JSON.stringify(Object.fromEntries(Object.entries(sheets).map(([name, rows]) => [name, rows.length]))));
console.log(JSON.stringify(sheets.Summary?.slice(0, 24)));
console.log(JSON.stringify(sheets.Requirements?.slice(0, 3)));
