SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 2362 AND backend_start = '2026-10-01 22:16:37.860604+00'::timestamptz AND application_name = 't2t-d15-hold-82bd648b036448649c3a92b612c111c0' AND usename = 'supabase_admin' AND datname = 'postgres';
