import json,re
from flow import call,tool,snapshot,click,shot,base
from http import ack,flags,row,PERSON,ORG,siblings_equal
from sds import fill_values
page=json.loads((base/'owner-page.json').read_text())['pageId'];seed=json.loads((base/'seed-lifecycle.json').read_text());checks=[]
b=row('ack-set-before')[0];r=ack('ack-set',page);assert r['status']==200,r
a=row('ack-set-after')[0];siblings_equal(b,a,{'award_tracking_acknowledged_at','updated_at'});assert a['award_tracking_acknowledged_at']
for route in ['personnel','']:
 f=flags('ack-set-'+('personnel' if route else 'dashboard')+'-flags',page,route);assert f['status']==200 and any(PERSON in m['ids'] for m in f['matches']),f
r=ack('ack-true-replay',page);assert r['status']==200,r
c=row('ack-true-replay-after')[0];siblings_equal(a,c,{'award_tracking_acknowledged_at','updated_at'});assert c['award_tracking_acknowledged_at']>a['award_tracking_acknowledged_at']
checks.append({'scenario':'true set and real true replay','result':'PASS','before':b,'set':a,'replay':c})
click('sds-ack-preserve-open',page,'More info');fill_values('sds-ack-preserve-fill',page,{'Emergency phone':'907-555-0199'})
click('sds-ack-preserve-save',page,'Save');d=row('sds-ack-preserved-row')[0]
siblings_equal(c,d,{'emergency_contact_phone','updated_at'});assert d['emergency_contact_phone']=='907-555-0199' and d['award_tracking_acknowledged_at']==c['award_tracking_acknowledged_at']
click('sds-color-clear-open',page,'More info');s=snapshot('sds-color-clear-input-before',page);s=s[s.rfind('dialog "Soldier Data Sheet"'):]
uid=re.search(r'StaticText "Vehicle color"\n\s*uid=([^ ]+) textbox',s).group(1)
tool('sds-color-clear-focus','click',{'pageId':page,'uid':uid});tool('sds-color-select-all','press_key',{'pageId':page,'key':'Control+A'});tool('sds-color-backspace','press_key',{'pageId':page,'key':'Backspace'})
snapshot('sds-color-keyboard-cleared',page);shot('sds-color-keyboard-cleared',page)
click('sds-color-keyboard-save',page,'Save');e=row('sds-color-keyboard-after')[0]
siblings_equal(d,e,{'vehicle_color','updated_at'});assert e['vehicle_color'] is None and e['award_tracking_acknowledged_at']==c['award_tracking_acknowledged_at']
tool('sds-ack-preserve-reload','navigate_page',{'pageId':page,'type':'reload'});snapshot('sds-ack-preserve-reloaded-detail',page)
click('sds-ack-preserve-reloaded-open',page,'More info');s=snapshot('sds-ack-preserve-reloaded-form',page);shot('sds-ack-preserve-reloaded-form',page)
assert '907-555-0199' in s and 'Gray' not in s
click('sds-ack-preserve-reloaded-close',page,'Cancel')
checks.append({'scenario':'native SDS save and keyboard NULL preserve acknowledgement and sibling fields','result':'PASS','before':c,'after':e})
r=ack('ack-clear',page,value=False);assert r['status']==200,r
f=row('ack-clear-after')[0];siblings_equal(e,f,{'award_tracking_acknowledged_at','updated_at'});assert f['award_tracking_acknowledged_at'] is None
for route in ['personnel','']:
 g=flags('ack-clear-'+('personnel' if route else 'dashboard')+'-flags',page,route);assert g['status']==200 and all(PERSON not in m['ids'] for m in g['matches']),g
checks.append({'scenario':'real clear preserves all SDS values/identity and removes projection','result':'PASS','before':e,'after':f})
for i in range(1,3):
 assert row('ack-no-row-before-'+str(i),seed['ids']['duplicateAlpha'])==[]
 r=ack('ack-no-row-clear-'+str(i),page,person=seed['ids']['duplicateAlpha'],value=False);assert r['status']==200,r
 assert row('ack-no-row-after-'+str(i),seed['ids']['duplicateAlpha'])==[]
checks.append({'scenario':'no-row false clear and replay create no SDS row','result':'PASS','personnelId':seed['ids']['duplicateAlpha']})
(base/'ack-sibling-check.json').write_text(json.dumps({'result':'PASS','checks':checks,'boundary':'Ordinary authenticated endpoints; real28-field provider rows; native SDS sibling interaction; public IDs only','limits':'No native acknowledgement toggle/badge exists. No invented UI transition or full session-bearing stream capture.'},indent=2)+'\n')
