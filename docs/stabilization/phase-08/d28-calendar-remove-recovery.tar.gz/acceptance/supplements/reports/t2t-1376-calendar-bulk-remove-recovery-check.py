import hashlib, json, re, socket, subprocess
from pathlib import Path
repo=Path('/home/waffleflops/.cache/t2t-1376-calendar-persistence-owner')
raw=repo/'.verification/evidence/verify-trooptotask/d28-calendar-bulk-remove-recovery'
load=lambda n:json.loads((raw/n).read_text())
text=lambda n:'\n'.join(x['text'] for x in load(n)['content'] if x.get('type')=='text')
rows=lambda n:{r['id']:r for r in load(n)['rows']}
f=load('fixture.json'); ids=f['ids']; manifest=load('input-manifest.json')
tracked=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=repo).decode().split('\0')
selected=[]
for name in sorted(set(filter(None,tracked))):
 driving=name=='.agents/skills/verify-trooptotask/SKILL.md' or (name.startswith('.agents/skills/verify-trooptotask/features/') and name.endswith('.md'))
 if (name.endswith('.md') and not driving) or Path(name).name.startswith('.env'):continue
 selected.append(name)
assert selected==[e['file'] for e in manifest['entries']]
h=hashlib.sha256()
for e in manifest['entries']:
 b=(repo/e['file']).read_bytes();assert len(b)==e['bytes'];assert hashlib.sha256(b).hexdigest()==e['sha256'];h.update(e['file'].encode()+b'\0'+b+b'\0')
assert h.hexdigest()==manifest['candidate']
rev,tree=subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=repo).decode().splitlines();assert [rev,tree]==[manifest['revision'],manifest['tree']]
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
original_checks=[]
for table in ['status_types','assignment_types','special_days','availability_entries','daily_assignments','personnel']:
 for org in ['A','B']:
  expected=rows(f'original-{table}-{org}.json');assert rows(f'final-before-clean-{table}-{org}.json')==expected
  original_checks.append({'table':table,'org':org,'fullRowCount':len(expected),'allFullRowsExact':True})
for org in ['A','B']:
 expected=rows(f'original-availability_entries-{org}.json')
 for stage in ['baker-reviewed','baker-back','range-failed','range-retried','overlap-removed','overlap-reloaded','switch-B-before-release','switch-B-after-release','after-clean-seeds']:
  assert rows(f'{stage}-{org}.json')==expected
 assert rows(f'overlap-reviewed-{org}.json')==rows(f'overlap-original-{org}.json')
seed=load('overlap-seed.json')['firstId'];expected=rows('original-availability_entries-A.json');added=rows('overlap-original-A.json')
assert set(added)-set(expected)=={seed};assert {k:added[k] for k in expected}==expected
assert added[seed]['personnel_id']==ids['personA'] and added[seed]['status_type_id']==ids['statusLeave'] and added[seed]['start_date']==f['dates']['uiBefore'] and added[seed]['end_date']==f['dates']['uiAfter']
assert seed not in rows('overlap-removed-A.json');assert seed not in rows('overlap-reloaded-A.json')
for n in ['baker-review-action.json','range-retry-review.json','overlap-review-action.json']:
 s=text(n);assert '1 partial overlap' in s and 'removed entirely' in s;assert 'Oct 4, 2026 – Oct 6, 2026' in s and 'Nothing is removed until you confirm.' in s
assert 'Baker, Synthetic' in text('baker-review-action.json');assert 'Able, Synthetic' in text('overlap-review-action.json')
assert 'Removed 1 status entry' in text('overlap-confirm-removal.json');assert 'No matching status entries were found' in text('overlap-reloaded-zero-review.json')
assert 'Unable to load status entries for the selected date range. Try again.' in text('range-fail-review.json')
for n,status in [('baker-range-state.json',200),('range-fail-state.json',503),('range-retry-state.json',200),('overlap-range-state.json',200)]:
 d=load(n);assert len(d['calls'])==1 and d['calls'][0]['status']==status
requests=load('baker-native-network.json')['structuredContent']['networkRequests'];r=[x for x in requests if '/api/calendar-range?' in x['url']];assert len(r)==1 and r[0]['requestId']==135 and r[0]['method']=='GET' and r[0]['status']=='200';assert '/org/'+ids['orgA']+'/api/calendar-range?' in r[0]['url']
requests=load('overlap-remove-native-network.json')['structuredContent']['networkRequests'];deletes=[x for x in requests if x['method']=='DELETE'];assert len(deletes)==1 and deletes[0]['requestId']==138 and deletes[0]['status']=='200';assert deletes[0]['url'].endswith('/org/'+ids['orgA']+'/api/availability/batch')
scoped=text('scoped-remove-tab.json');assert 'Select SPC Able, Synthetic' in scoped and '0 of 1 selected' in scoped;assert 'Baker, Synthetic' not in scoped and 'Unassigned, Synthetic' not in scoped and 'Foreign, Synthetic' not in scoped
empty=text('empty-remove.json');assert 'No personnel available' in empty and '0 of 0 selected' in empty and re.search(r'button "Review Matching Entries".*disabled',empty)
view=(raw/'view-denial.txt').read_text();assert 'Access restricted.' in view and 'Calendar operation access is required' in view;assert not re.search(r'button "(?:Add|Remove|Import)"',view)
http=[]
for n,expected_ids in [('scoped-september-range-http-corrected.json',{ids['availabilityAlpha']}),('empty-september-range-http.json',set())]:
 d=json.loads(text(n).split('```json\n',1)[1].split('\n```',1)[0]);assert d['status']==200;b=json.loads(d['body']);assert {x['id'] for x in b['availabilityEntries']}==expected_ids
 for key in ['personForeign','availabilityForeign','statusForeign','availabilityBravo','availabilityUnassigned']:assert ids[key] not in d['body']
 assert 'Foreign Private Status' not in d['body'];http.append({'file':n,'status':200,'expectedAvailabilityIds':sorted(expected_ids),'proof':'ordinary authenticated read, distinct from native UI'})
held=load('switch-held-range-state.json');assert held['held'] and len(held['calls'])==1 and held['calls'][0]['status']==200
heldB=load('switch-B-september-range-held-state.json');assert heldB['held'] and len(heldB['calls'])==1 and heldB['calls'][0]['status']==200
heldNative=load('switch-held-range-native-network.json')['structuredContent']['networkRequests'];a=[x for x in heldNative if '/api/calendar-range?' in x['url']];assert len(a)==1 and a[0]['method']=='GET' and a[0]['status']=='200' and '/org/'+ids['orgA']+'/api/calendar-range?' in a[0]['url']
assert 'Successfully clicked' in text('switch-native-menu-to-B.json');assert '/org/'+ids['orgB']+'/calendar/bulk' in (raw/'switch-B-admitted-before-release.txt').read_text()
assert load('switch-release.json')['released'];assert not load('switch-after-release-range-state.json')['held']
for n in ['switch-B-september-before-release.json','switch-B-after-release.json','switch-B-detail-after-release.json']:
 s=text(n) if n.endswith('before-release.json') or n.endswith('detail-after-release.json') else (raw/'switch-B-after-release.txt').read_text()
 assert '/org/'+ids['orgB']+'/calendar' in s and 'September 2026' in s and 'SPC Foreign, Synthetic' in s and 'Foreign Private Status - Foreign private leave' in s and 'Foreign Private Closure Foreign Private Duty' in s
 for bad in ['Baker, Synthetic','Able, Synthetic','Verification Training','Review matching entries','Unable to load status entries']:assert bad not in s
for n in ['switch-B-feedback-before-release.json','switch-B-feedback-after-release.json']:assert load(n)['armed'] and load(n)['entries']==[]
for n in ['baker-observe-restored.json','range-fail-restored.json','range-retry-restored.json','overlap-observe-restored.json','switch-network-restored.json','switch-feedback-restored.json']:assert load(n)['restored']
assert load('clean-seeds.json')['cleaned']
for n in ['launch.json','doctor-initial.json','doctor-final.json']:
 d=load(n);assert d['status']=='PASS' and d['candidate']==manifest['candidate'] and d['revision']==rev and d['session']=='ad5cffdd-1d95-47b7-a420-6718b916d3dd' and d['origin']=='http://127.0.0.1:40689'
cleanup=load('cleanup.json');assert cleanup['status']=='PASS' and cleanup['phase']=='cleaned';assert not (raw/'cleanup.stderr').read_bytes();assert not Path('/home/waffleflops/.local/state/trooptotask-verification/100db5631cfc8c68/worker-2').exists()
s=socket.socket();s.settimeout(1);assert s.connect_ex(('127.0.0.1',40689))!=0;s.close()
processes=load('owned-state-before-cleanup.json')['processes']
for p in processes:assert not Path('/proc/'+str(p['pid'])).exists()
assert (raw/'scoped-september-range-http.json').stat().st_size==0
receipt={'result':'PASS','scope':'Calendar canonical-shell Bulk Remove affected repair baseline only','revision':rev,'tree':tree,'candidate':h.hexdigest(),'inputEntriesRecomputed':len(selected),'gitClean':True,'session':'ad5cffdd-1d95-47b7-a420-6718b916d3dd','origin':'http://127.0.0.1:40689','fullOriginalTableComparisons':original_checks,'canonicalRangeRequest':r[0],'confirmedTemporaryOverlap':{'id':seed,'nativeDeleteRequest':deletes[0],'onlyIntentionalTemporaryDeletion':True},'nativeWholeWarningBackFailureRetryReload':True,'scopeReadbacks':http,'heldRange':{'actualARead':a[0],'actualNativeOrganizationMenuReceipt':'switch-native-menu-to-B.json','BAdmittedBeforeRelease':True,'trueRelease':True,'renderedStoreProjectionStayedB':True,'noStaleFeedback':True,'noInternalStoreIntrospectionClaim':True},'healthyFinalDoctor':True,'allSeedComparisonsBeforeCleanup':True,'noTemporaryGrantsChanged':True,'controlsRestored':True,'cleanup':cleanup,'ownedWorkerDirectoryAbsent':True,'originalOriginClosed':True,'recordedProcessesAbsent':processes,'preparationAttemptPreserved':{'artifact':'scoped-september-range-http.json','empty':True,'shellExit':127,'readerExit':1,'correctedRead':'scoped-september-range-http-corrected.json','noCreditForFailedAttempt':True}}
(raw/'recovery-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['result','scope','revision','candidate','inputEntriesRecomputed','gitClean','healthyFinalDoctor','ownedWorkerDirectoryAbsent','originalOriginClosed']},indent=2))
