SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 879 AND backend_start = '2026-10-02 03:01:30.509337+00'::timestamptz AND application_name = 't2t-d15-overlap-49b5a561e8e04f5a9dba32366c3f2bd9' AND usename = 'supabase_admin' AND datname = 'postgres';
