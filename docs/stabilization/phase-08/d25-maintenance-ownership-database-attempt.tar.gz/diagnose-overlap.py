import importlib.util,json,pathlib,subprocess
repo=pathlib.Path.cwd()
session=pathlib.Path('/home/waffleflops/.local/state/trooptotask-verification/ced9b3c7d1be5784/worker-1')
spec=importlib.util.spec_from_file_location('owned_environment',repo/'scripts/verification/environment.py')
envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod)
print(json.dumps(envmod.status(session)),flush=True)
state,workdir,environment=envmod.owned(session)
source=(repo/'supabase/tests/archive_retention_critical_tasks_concurrency.sql').read_text()
point="SELECT ok(pg_temp.ct_retention_waits_for('t3_ct_retention_overlap','t3_ct_retention_writer'),'the overlapping cleanup waits on the same candidate');"
replacement="SELECT pg_sleep(0.05); SELECT diag(application_name||' blocked_by='||coalesce((SELECT string_agg(holder.application_name,',') FROM pg_stat_activity holder WHERE holder.pid=ANY(pg_blocking_pids(waiting.pid))),'none')||' wait='||coalesce(wait_event_type,'none')) FROM pg_stat_activity waiting WHERE application_name IN ('t3_ct_retention_overlap','t3_ct_retention_cleanup','t3_ct_retention_writer');\n"+point
assert point in source
probe=workdir/'supabase/tests/d25_overlap_diagnostic.sql';probe.write_text(source.replace(point,replacement))
try:
 result=subprocess.run(['supabase','test','db',str(probe)],cwd=workdir,env=environment,capture_output=True,text=True)
 print(result.stdout);print(result.stderr);print('Diagnostic exit',result.returncode)
finally:probe.unlink()
