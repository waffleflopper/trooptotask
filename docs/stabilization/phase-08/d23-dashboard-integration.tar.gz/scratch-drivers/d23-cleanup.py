import json,subprocess,os
from pathlib import Path
out=Path('.verification/evidence/verify-trooptotask')/os.environ.get('D23_RUN','d23-projections-before')
for p in out.glob('original-*.json'):
 original=json.loads(p.read_text())
 r=subprocess.run(['python3','.verification/tmp/d23-projection-call.py','helper','rows',json.dumps([original['table'],original['organization']]),p.name.replace('original-','cleaned-')],capture_output=True,text=True)
 if r.returncode:print(r.stdout,r.stderr);raise SystemExit(r.returncode)
print('All cleaned table reads saved',flush=True)
comparisons=[{'file':p.name,'equal':json.loads(p.read_text())==json.loads((out/p.name.replace('original-','cleaned-')).read_text())} for p in out.glob('original-*.json')]
absent=[]
for seedname in ['seed-dashboard.json','seed-currency.json']:
 if not (out/seedname).exists():continue
 seed=json.loads((out/seedname).read_text())
 for b in seed['batches']:
  current=json.loads((out/f"cleaned-{b['organization']}-{b['table']}.json").read_text())['rows']
  remaining={r['id'] for r in current}
  absent.extend({'table':b['table'],'id':r['id'],'absent':r['id'] not in remaining} for r in b['rows'])
(out/'cleanup-comparison.json').write_text(json.dumps({'original':comparisons,'seededRows':absent},indent=2)+'\n')
print('Original equal:',all(x['equal'] for x in comparisons),'seeded absent:',sum(x['absent'] for x in absent),'/',len(absent),flush=True)
assert all(x['equal'] for x in comparisons) and all(x['absent'] for x in absent)
for command,filename in [('doctor','doctor-final.json'),('cleanup','disposal.json')]:
 r=subprocess.run(['mise','exec','node@24','--','npm','run','--silent','verify:app','--',command,'--worker','2'],capture_output=True,text=True)
 (out/filename).write_text(r.stdout)
 if r.stderr:(out/(filename+'.stderr')).write_text(r.stderr)
 print(command,r.returncode,r.stdout,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
