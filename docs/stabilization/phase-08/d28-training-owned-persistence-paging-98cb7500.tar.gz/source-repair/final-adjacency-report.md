# D28/#1376 grouped raw archive paging repair handoff

The additional bounded source/lower stage is complete. Ownership is released to root. The raw Training archive shares the reproduced page-order failure and is now repaired in the same Training PR. Original three FAILs, current eight archive PASSs and two focused Organization export delivery PASSs are preserved. No app, native browser, build, provider, archive, push, GitHub write, remote/existing-local database or private worktree action occurred. No additional commit was made.

## Current complete source binding

The authorized local merge remains `74c351ab391c8e3d955984653306bd1e270bab74`, parents `1c9d1e0760b73f1c8f70b88ac4c18c81667ba1df` and actual main `837a43508d31ab4f82da8e3235382d708f065ead`. All four previous uncommitted repairs are unchanged (`six-path-preservation.json`). Previous `final-report.md`, proposal and failure/check receipts remain untouched as historical evidence. Its raw-reader limitation is superseded by this report, not retroactively marked stable.

Final uncommitted scope is six paths:

- `src/features/training/server/trainingCatalogPersistence.server.ts` retains six ordinary ID tie orders.
- `src/features/training/server/trainingCompletionPersistence.server.ts` retains four ordinary ID orders.
- `src/features/training/server/trainingPersistence.server.test.ts` retains ten complete projected identity/page-drift/late-error cases.
- `src/lib/server/adapters/trainingRequestContext.server.test.ts` retains correctly owned error-trust composition tests.
- `src/features/training/server/trainingExportRead.server.ts` now adds unique ID order to the existing raw select* builder.
- `src/features/training/server/trainingArchiveExportRead.server.test.ts` upgrades three existing saved-table cases with physical page drift and complete independently numbered row expectations.

Complete PR diff against actual main now has **78 paths**, not the earlier77. The newly differing path is the formerly unchanged archive SDK test. Stage diff against pre-merge local head has63 paths, with zero nonignored untracked files. `final-source-census-freeze.json` lists every path/status and all 5357 tracked source hashes. Exact current uncommitted binary patch SHA256 is `cbcc28127d927f424439ce954ee7c20cd845016824d8b21dd2fe5c8e1a046a9f`. `final-uncommitted.patch` preserves it. This is a current source binding, not a launched native candidate. No source changed after that inventory.

## Mechanism, fixture and repair

The existing raw SDK fixture exposes the same mechanism as the ten ordinary contracts. Its second-page physical order reverses before SQL ordering. Without explicit unique order, page2 contributes saved-0001 a second time and omits saved-1001. Each of training_types, personnel_trainings and training_views exhibits this failure. The 1001 expected IDs are independently constructed as saved-0001 through saved-1001, with literal saved fields, NULL values, timestamps, retained archived identities and unknown nested metadata. The expected result does not invoke a production mapper or derive itself from the subject under test.

The fixture already uses installed Supabase SDK2.106.1 and parses actual filter/order/range requests. A small unstablePages flag uses the existing reversal/sort logic; no new provider framework is introduced. Each positive case asserts all1001 complete saved objects in ID order, foreign Organization exclusion and empty Organization behavior. Existing first/late provider rejection, null response and unsupported-table-before-access cases remain. Full select* retains unknown metadata, malformed historical notes17 and saved nulls rather than applying ordinary DTO normalization.

Production adds exactly one `.order('id', { ascending: true })` immediately before range on the existing whitelisted three-table raw builder. No new ordinary port, table allowance, admin client, query projection, filter, metadata mapper, RPC or N+1 is introduced. Existing shared RequestFailure unsupported-table handling remains. Raw archive order is changed and is no longer described as unchanged.

Actual purpose consumers remain `createRequestOrganizationExportContext(...).archiveReaders.training`, then `src/routes/org/[orgId]/api/organizationDataExportDelivery.server.ts` trainingTypes/personnelTrainings/trainingViews sections declared by the data-export manifest. Ordinary captured client and canonical Org continue to bind the reader. The focused existing delivery test constructs those request readers through the installed SDK and validates exact raw fields/IDs in both JSON and workbook output while excluding foreign rows under legacy and retired commercial schema fixtures.

## Failure-to-pass and current checks

Original `archive-before-fix.log` is preserved, with pre-fix adapter/test hashes in `archive-before-source-hashes.json`:

```text
Test Files  1 failed (1)
Tests       3 failed | 5 skipped (8)
```

After the one query ordering addition, `archive-after-fix.log` proves the failing cases plus all existing adjacent archive boundaries:

```text
Test Files  1 passed (1)
Tests       8 passed (8)
```

`delivery-archive-focused.log` proves the existing retained Organization export projection tests:

```text
Test Files  1 passed (1)
Tests       2 passed | 6 skipped (8)
```

Six unrelated delivery cases were excluded by the explicit test-name selection. They are not new UNRUN required obligations for this repair. Current changed two-file lint and format pass in `lint-final.log` and `format-final.log`. Working and complete PR whitespace checks pass in `diff-check-final.log`; its first stale77 count label is preserved with an appended correction to actual78. No unexpected product failure remains in the selected adjacency, and no assertion/guard/scan was weakened.

Reuse earlier focused nine suites/127 tests, current relocated three-case authority/error suite, current type0errors/0warnings and governancePASS157-finding receipts from the previous stage. Their unchanged paths/semantics match; the prior four repair/test files are byte-exact. No repeat type/governance command was justified for this adjacency. The only production addition calls an already-used typed SDK order method, with no signature or schema change; test changes use the existing Row[] and boolean drift flag, with no new import/owner/manifest/authority dependency. Focused executable SDK/delivery behavior and touched lint/format establish this repair. Required full current-head CI remains later and is not claimed here.

## Consolidated dispositions and acceptance remainder

Hosted paging finding PRRT_kwDORLALT86p_vye is fixed for all ten ordinary reads. Root grouped the closely related raw-purpose query, which is now fixed as well. The settled17 Catalog/10 Completion contracts, all Entity/generic Training seam removals and direct/reverse migration census remain intact. Accepted main shared RequestFailure/fail trust and all six source overlap resolutions remain preserved. The previous52 nonoverlapping main changed paths remain exact; no broad scanner waiver, inherited main rewrite, recipe change or ledger/archive edit occurred.

Certificate finding PRRT_kwDORLALT86p_vyp remains disproved by actual4e84 native repeated/mixed imports with200 acknowledgements, same saved ID/full10 SQL fields and preserved certificate, plus installed SDK columns mechanism. No upsert/provider-fixture change. The separate raw archive no longer has the earlier unordered known limit. No new code gap remains in the selected source/lower repair; independent acceptance, proposed native adjacency, exact-head CI/review and publication remain root-owned gates. PR1565/#1376 are not declared merged or complete.

`amended-proposed-final-native-selection.md` retains one Dense report/whole-workbook ordinary native proposal with1902 saved completions/1990 rows and exact independently derived identities/dates/order/counts. It explicitly asks the independent reviewer to assess current raw SDK/delivery sufficiency rather than adding a broad native Organization export matrix by default. No print/control/theme/normal/CRUD/reverse/six-part/64-case repeat. Prior protected59 UI/store/utility hashes remain matching; prior native/workbook/print/error/lifetime/restoration proof retains original binding and historical controlFAIL/UNRUN remains visible.

Test Behavior shaped complete saved-object and ID expectations rather than call trivia. Boundary Discipline keeps raw saved history separate from ordinary normalized projections and retains captured request authority. Laziness chose the same existing builder/three existing cases, one ID-order addition and no abstraction. Prove It Works preserves the original3FAIL and actual current SDK/delivery PASS. Root's grouping decision keeps a known closely related Training defect in the same cohesive PR. No narrative comments were added. Direct diff/lint/format cleanup is the deslop fallback; no fanout or independent self-review is claimed under the sequential brief.

No owned app/native/build/session/resources were created. All lower commands ended. Worker1 directory remains absent. Existing cancellation/audit/restoration/closure proof remains historical at4e84; this stage touched no grants, app data, UI state or controls. Ownership is now released with all six uncommitted paths preserved for one independent complete-diff review and root's next accepted stage.
