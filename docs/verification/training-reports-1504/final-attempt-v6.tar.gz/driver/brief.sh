#!/bin/bash
# brief.sh NAME PAGE TOOL JSON -> act.sh, printing only after state and last 2 requests
D=/home/waffleflops/.t3/worktrees/trooptotask-v1-maintenance/t3code-6ed7bc4e/.verification/evidence/verify-trooptotask/1504-final-v6/driver
TAILN=2 $D/act.sh "$@" | sed -n '/== after/,$p' | grep -v '^rc=\|== after' | python3 -c "
import sys,json
for l in sys.stdin:
  l=l.rstrip()
  try:
    d=json.loads(l); f=d['focus']; print('URL',d['url'].split('/training')[1],'| focus',f['tag'],f['id'],f['label'] or f['text'][:30],'| checked',d['checked'],'| busy',d['briefing'] and d['briefing']['busy'],'| alerts',d['alerts'],'| detail',d['detail'] and (d['detail']['ranges'],d['detail']['rows']),'| sel',d['cellSel'],d['ariaSel'],'| cur',d['current'][2:])
  except Exception: print(l[:220])
"
