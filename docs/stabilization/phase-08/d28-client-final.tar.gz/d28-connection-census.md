# D28 connection and private-bucket census

This source-only census starts from merged #1534, `4b5c4b5a4a34157a24979b875904c7f5dfb4a754`, on `stabilization/1376-owned-persistence`. The coordinator owns source changes and all live verification. No credentials, database contents, network, browser, or services were inspected or used. The accepted Storage implementation and proof remain prerequisites, not new execution credit.

## Independently useful connection outcome

At the baseline, `src/lib/server/supabase.ts:10–13` constructs a fresh service client for every call and sets only `persistSession: false`. Installed `@supabase/supabase-js` and `@supabase/auth-js` are 2.106.1. SDK auth defaults enable `autoRefreshToken` and `detectSessionInUrl` in `node_modules/@supabase/supabase-js/src/lib/constants.ts:28–32`. `GoTrueClient.ts:611` enters visibility handling after initialization. Its Node branch at `5044–5050` starts automatic refresh, and `4838` creates an interval retaining the client callback. The interval is unref'd. This establishes unnecessary background lifecycle from source. It does not measure memory, latency, or throughput.

The smallest repair explicitly disables service-client session persistence, automatic refresh, and URL session detection. Keep per-call construction and lazy callbacks. No singleton, cache, ordinary-client replacement, or authorization change is required. `src/features/identity/passwordProof.server.ts:11–13` is the nearest existing configuration precedent.

The baseline `getSupabaseClient` at `supabase.ts:19–20` returns only `locals.supabase`. Its optional Cookies argument and import are unused. Its only production caller is `src/features/identity/accountSetupRouteFlow.server.ts:610`. Replace that call with the existing ordinary client and delete the abandoned getter and type import together. The coordinator has begun that repair. These changes require no migration.

## Ordinary client and setup contract

`src/hooks.server.ts:52–79` creates request-local user storage and one cookie-backed SSR client using the public URL and anonymous key. Its cookie bridge retains tokens-only encoding and Identity cookie policy. Verified session and actor admission follow at `82–117`, then fresh Organization admission applies before write or API dispatch. Do not move this client into module state or replace it with the service client.

Installed `@supabase/ssr` is 0.10.3. `node_modules/@supabase/ssr/src/createServerClient.ts:157–181` supplies PKCE, no automatic refresh, no URL detection, cookie persistence, and staged server storage. `src/routes/+layout.ts:3–5` returns only the server-provided session. No production browser Supabase client was found.

Other ordinary creation edges are Identity's staged `confirmSensitiveIdentity.server.ts:36–44` and isolated `passwordProof.server.ts:11–13`. Both retain their own identity/session contracts. The census found no service-client user sign-in call. `accountSetupCompletionSupabase.server.ts:104–149` deliberately uses admin `createUser` or `updateUserById` on its service input, then `signInWithPassword` on its separate session input. Setup flow composition lazily creates and caches those collaborators per flow at `accountSetupRouteFlow.server.ts:599–624`.

Existing `accountSetupRouteFlow.server.test.ts` exercises an injected pure flow. `accountSetupCompletionSupabase.server.test.ts:79–85` uses a mocked session client's sign-in, and `src/routes/auth/setup-account/page.server.test.ts:11` mocks the complete factory. They do not prove that the real factory binds sign-in to the ordinary request session.

The new exclusive `src/features/identity/accountSetupConnection.server.test.ts` runs the actual factory, stores, completion service, and auth adapter through real SDK service and cookie-backed SSR clients. Its finite transport requires service authority for administrative effects and an ordinary public-key password grant after acknowledged completion. It observes the created/completed provider fixture state, browser access/refresh cookie values, preserved unrelated cookie, authenticated follow-up from the exact ordinary client, and unchanged service authority after sign-in. Only `getAdminClient` is substituted. Async `importOriginal` preserves the original module exports before or after getter removal. The original getter version was not separately executed in this task.

The fixture acknowledges an approved request, started claim, actual Auth creation, committed reconciliation, and successful completion RPC in that order. Those are synthetic provider responses, not new ordering guarantees. No SQL transaction, claims authenticity, provider-user trigger, cookie-policy enforcement, real account activation, or native acquisition proof is earned by the finite test.

Node 24.21.0 focused command passed at 21:30:56 on October 4, 2026:

```sh
env PATH="/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:$PATH" npm run test -- src/features/identity/accountSetupConnection.server.test.ts
```

Vitest 4.1.8 reported one passing file and one passing test, 219 ms total and 24 ms test time. The owned file's Prettier check passed. No global fetch replacement is used. Both clients explicitly stop automatic refresh in cleanup. The author cannot independently accept this test.

## Complete named service-client consumer census

The baseline search found 37 production consumer files, excluding `supabase.ts` itself and tests. This is a connection-edge inventory, not independent review of unrelated feature behavior. Reproduce the inventory with:

```sh
rg -n 'getAdminClient|getSupabaseClient' src --glob '*.{ts,svelte}' --glob '!*.test.ts'
```

| Consumer | Relevant baseline lines and role |
| --- | --- |
| `src/lib/server/adapters/requestContexts.server.ts` | 145,256,389 bind Personnel file writers. 348–349 bind Notification delivery. 452,472,490 bind Calendar's owned Personnel lookup. 508 binds roster Personnel lookup. 523 binds roster file writes. 558 binds Organization export. 581–582 bind Dashboard roster collaborators. All pass the factory callback. |
| `src/lib/server/adapters/featureRequestContexts.server.ts` | 63 binds Training roster. 87,97,108 bind Critical Tasks roster. 129,155 bind Rating roster. 162,172,223 bind Training references. 171,182,192,202,212,222 bind Onboarding roster. All retain the owner port's lazy acquisition. |
| `src/lib/server/adapters/httpAdapter.ts` | 39–41 bind Feedback service collaborators after route admission. |
| `src/lib/access/durableRateLimit.server.ts` | 33 supplies a default service client for the durable limiter. |
| `src/lib/audit/auditLog.server.ts` | 191 creates a client per best-effort Audit write. |
| `src/routes/api/cleanup-old-data/+server.ts` | 11 supplies service authority to admitted Audit cleanup. |
| `src/routes/api/cleanup-expired-onboardings/+server.ts` | 17 creates one admitted job client. 29 returns that same client to Notification delivery. |
| `src/routes/api/cleanup-archived-records/+server.ts` | 47 creates one admitted job client. 55 returns that same client to Notification delivery. |
| `src/routes/org/[orgId]/settings/settingsRequestContexts.server.ts` | 52 binds the narrow invitation setup-state lookup callback. |
| `src/routes/org/[orgId]/settings/members/+page.server.ts` | 59–62 and 93–94 construct admitted invitation delivery, limiting, and setup-link ports. Multiple calls create multiple clients. |
| `src/routes/org/[orgId]/settings/logs/+page.server.ts` | 39 creates the admitted service client for log operations. |
| `src/routes/org/[orgId]/api/deletion-requests/review/+server.ts` | 52,54 bind owned Training and counseling approval callbacks with the pending guard. |
| `src/features/training/onboardingReferences.server.ts` | 26,53 acquire the supplied callback inside owned reference reads. |
| `src/features/training/server/approvedTrainingDeletion.server.ts` | 55 acquires the callback after reviewer admission. |
| `src/features/sign-in-rosters/fileWrites.server.ts` | 33 acquires service authority after ordinary roster lookup and Training scope policy. |
| `src/features/personnel/artifactWrites.server.ts` | 80,194 acquire service authority after ordinary Person lookup and policy. |
| `src/features/personnel/governanceDeletion.server.ts` | 33 acquires it after Organization reviewer admission. |
| `src/features/personnel/calendarRoster.server.ts` | 27,35,50 pass the callback to the scoped query helper. |
| `src/features/personnel/criticalTasksRoster.server.ts` | 32,40,49,57 pass it to the scoped query helper. |
| `src/features/personnel/trainingRoster.server.ts` | 18,35 pass it to the scoped query helper. |
| `src/features/personnel/onboardingRoster.server.ts` | 23,31 pass it to the scoped query helper. |
| `src/features/personnel/ratingSchemeRoster.server.ts` | 48,67 pass it to the scoped query helper. |
| `src/features/personnel/scopedRosterQuery.server.ts` | 16 invokes the supplied callback for its explicit Organization/scope query. |
| `src/features/personnel/signInRosterPersonnelLookup.server.ts` | 23 invokes the supplied callback inside the owned snapshot lookup. |
| `src/features/personnel/organizationExport.server.ts` | 33 creates the client for owned export reads. |
| `src/features/personnel/rankCatalogAdministration.server.ts` | 12 retains dependency fallback. 16 invokes it for the owned delete-unused RPC. |
| `src/features/organization/memberManagementProvider.server.ts` | 72 retains dependency fallback. 116,159,163,215,277 invoke it for admitted member and recipient operations. |
| `src/features/organization/invitationSetupStateProvider.server.ts` | 47 invokes the narrow platform-owned lookup callback. |
| `src/features/organization/administratorRecipients.server.ts` | 7 invokes the callback for administrator recipients. |
| `src/features/platform-admin/server/admission.server.ts` | 14 creates a service client after verified actor presence and before current platform authority lookup. |
| `src/features/platform-admin/server/accessRequestOperations.server.ts` | 30 supplies the already-admitted client to setup-link operations. |
| `src/features/notifications/delivery.server.ts` | 32 invokes the callback for Notification insert. |
| `src/features/identity/accessRequestSetupDelivery.server.ts` | 254 creates the service client for approved setup delivery. |
| `src/features/identity/accountSetupRouteFlow.server.ts` | 608 creates and caches one client per lazily resolved flow. The baseline 610 also uses the sole ordinary getter call. |
| `src/features/identity/accountSetupLinks.server.ts` | 679 creates the service client for stale-link cleanup. |
| `src/features/identity/passwordCompletion.server.ts` | 32 uses service authority for password-attempt reconciliation. |
| `src/features/identity/authEmailDelivery.server.ts` | 93 creates the service client for Auth recovery email. |

## Retained private buckets and effective policy chain

`supabase/migrations/20260515000800_counseling_files_bucket.sql:1–13` defines `counseling-files` as private, 10,485,760 bytes, PDF only. Its conflict branch reapplies those retained values. `20260515000300_personnel_documents.sql:104–116` defines `personnel-documents` as private with the same limit and PDF, JPEG, PNG, HEIC, and HEIF. Its conflict branch also reapplies those values. No later bucket-property change was found.

`supabase/config.toml:105–108` enables local Storage and sets the global ceiling to 50 MiB. Bucket limits remain the migration-defined 10 MiB. Commented example bucket configuration is not a retained bucket declaration. S3-compatible local endpoints are enabled at 118–119. This is not hosted-provider inspection.

The relevant effective policy provenance is:

- `20260515000900_personnel_artifact_rls_group_scope.sql:143–245` replaces broad document-file policies with exact Organization, Person, documents prefix, and Group-aware policies.
- `20260601000200_remove_counseling_template_sensitive_scope.sql:1–10` retains only PDF `sign-in-rosters` and `counseling-records` paths in the shared bucket. It binds the four sensitive Storage policies at 112–139.
- `20260615000200_harden_sign_in_roster_scope_boundaries.sql` and `20260615000600_preserve_roster_reads_and_strict_follow_up_scope.sql` transfer roster file scope to Training, preserving saved Group scope. Their later helper definitions are superseded below.
- `20260615000300_drop_legacy_sensitive_file_storage_policies.sql:1–8` removes all eight older permissive counseling-file policies. `004`, `005`, and `006` revoke anonymous and PUBLIC helper execution while retaining authenticated and service grants.
- `20260926000800_personnel_counseling_file_scope.sql:60–111` supplies current writable helper semantics. It requires an exact Person with editable strict row scope, or an exact roster with Training operate and saved Group scope.
- `20260926001100_personnel_sensitive_artifact_reads.sql:6–22,48–113` supplies current sensitive SELECT semantics. Personnel files require configure plus exact in-scope Person. The separate Training roster read branch remains. Operate-only Personnel writes do not gain direct sensitive SELECT.
- `20261002001000_organization_storage_cleanup.sql:6–38` adds ordinary owner SELECT and DELETE for both fixed buckets, including orphan paths and other uploaders. It validates the Organization UUID prefix, current owner, unsuspended user, and existing unsuspended Organization. It adds no INSERT or UPDATE.
- `20261002002000_organization_file_upload_registration.sql:24–82,84–122` keeps registration and settlement service-only. Retained-bucket byte-changing metadata writes require the service role and the exact durable registration, including privileged writes. The narrow historical postgres fixture exception is explicit. Changing only auth lifecycle flags does not alter that enforcement.

No observed source/config defect warrants a new bucket migration, historical migration rewrite, new table grant, or broader RLS policy. Changing any bucket property, predicate, execution grant, trigger, or registration schema would require a forward migration and Robert's stop-before-merge/manual operation. Hosted parity remains unverified under the existing release holds.

## Existing proof and outstanding verification

Relevant retained unit coverage includes hook identity and Organization admission, root layout session handling, password proof/session-cookie tests, setup flow and completion tests, owner file writers, approved counseling deletion, Storage responses, retention, Organization destruction, file upload registration, durable limiting, Notification delivery, Audit writes, and affected cron admission. The connection factory had no direct baseline test file. The coordinator owns its new actual-SDK lifecycle test and integration commands.

Relevant tracked isolated SQL contracts are `supabase/tests/sensitive_rpc_privileges.sql`, `sign_in_rosters_rls_scope.sql`, `personnel_sensitive_artifact_reads.sql`, `personnel_counseling_file_scope.sql`, `personnel_artifact_rls_group_scope.sql`, and `organization_file_upload_concurrency.sql`. They protect helper grants, exact file scope, sensitive read/write separation, and real registration/delete waits. No tracked SQL test currently asserts `storage.buckets` privacy, limits, or allowed MIME sets. No tracked SQL assertion on `organization_storage_object_is_owner_removable` was found. Do not count the unrelated platform membership test as owner-file cleanup proof. Existing destruction provider tests and accepted D17/#1534 evidence are separate sources of owner cleanup credit, not newly executed SQL.

The connection deliverable needs baseline and repaired actual-SDK background lifecycle evidence, continued service authorization for REST, RPC, Storage, and Auth admin, and the new factory-level ordinary setup session regression. It also needs the complete required application check sequence and independent acceptance. Preserve #1534 Storage bytes and receipts. Existing request isolation, suspension/MFA/session, private-file scope, and denial tests must remain applicable.

Any fresh private-bucket configuration proof must inspect only a disposable migration replay and record privacy, 10 MiB limits, and exact allowed MIME sets. A source census establishes provenance but not the actual catalog. No database was launched here.

`docs/local-auth-testing.md:36–44` supplies the affected native setup journey through reviewed approval, isolated email capture, token-to-setup-cookie exchange, ordinary automatic sign-in, and Dashboard. `.agents/skills/verify-trooptotask/features/organization-invitations.md:18` explicitly leaves safe private setup-link capture as a missing prerequisite. No maintained helper grants live account activation proof merely by existing. If the isolated email capture or necessary controls are unavailable, record the native setup path as unrun and retain the bounded real-SDK composition result. Do not expose setup tokens, cookies, or credentials in artifacts.

The broad generic Storage upload method has no production consumer outside `inMemory.ts` test infrastructure. `src/lib/server/core/ports.ts:97–100`, `adapters/supabaseStorage.ts`, and in-memory file writer helpers retain that shape. Its cleanup belongs to the later complete D28 provider/interface consumer wave, together with the coordinator's separately delegated generic persistence census. It is not needed to repair the service-client timer or remove the ordinary identity getter. D29 and unrelated feature work remain excluded.
