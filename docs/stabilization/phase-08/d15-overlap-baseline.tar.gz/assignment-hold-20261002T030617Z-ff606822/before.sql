SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM public.personnel_onboardings p
 WHERE p.organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND p.id = '70b322e2-66af-4c1f-afde-cef1b59ebfb3'::uuid), '[]'::json),
 'person', (SELECT json_build_object('id', id, 'organization_id', organization_id, 'group_id', group_id,
 'rank', rank, 'first_name', first_name, 'last_name', last_name, 'slug', slug) FROM public.personnel
 WHERE organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND id = '775b67f0-847d-4b0f-a26e-bbd0db9112b2'::uuid),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM public.onboarding_step_progress s
 WHERE s.organization_id = 'd0a8b0cd-7e37-4a62-b16f-f045e3fd8771'::uuid AND s.onboarding_id = '70b322e2-66af-4c1f-afde-cef1b59ebfb3'::uuid), '[]'::json),
 'probe_trigger_count', (SELECT count(*) FROM pg_trigger WHERE tgrelid IN ('public.onboarding_step_progress'::regclass,
 'public.personnel_onboardings'::regclass) AND NOT tgisinternal AND tgname LIKE 't2t_d15_%'));
