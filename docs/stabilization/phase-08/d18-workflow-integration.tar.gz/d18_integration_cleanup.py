import sys,json,uuid
sys.path.insert(0,'.verification');import d18_ui as v,d18_native as n,d18_final as f
seed=f.read('04-source-seed');life=f.read('05-lifecycle-seed');ids={value for sources in seed['sources'].values() for key,value in sources.items() if key!='label'}|set(life['ids'].values());assert len(ids)==28 and all(str(uuid.UUID(value))==value for value in ids)
for org in ['orgA','orgB']:assert f.read('06-source-pdf-before-'+org+'-files')==f.read('54-source-pdf-before-cleanup-'+org+'-files'),org
for page in [2,3,4]:
 for family in ['network','feedback']:v.helper(f'57-restore-{page}-{family}',family,'restore',str(page))
 v.helper(f'58-clear-{page}-network','network','state',str(page))
clear=v.helper('59-owned-check-clear','deletion-review-failure','state');assert clear['phase']=='clear' and clear['armed'] is False
r=v.helper('60-merged-owned-seed-cleanup','clean-seeds');assert r['cleaned'] is True,r
f.capture('61-after-cleanup');comparisons=[]
for org in ['orgA','orgB']:
 for table in f.TABLES:
  sort=lambda rows:sorted(rows,key=lambda r:r['id']);original=f.read('original-'+org+'-'+table)['rows'];after=f.read('61-after-cleanup-'+org+'-'+table)['rows'];assert sort(original)==sort(after),(org,table)
  assert not any(row.get('id') in ids or row.get('resource_id') in ids for row in after),(org,table)
  comparisons.append({'organization':org,'table':table,'exactOriginalProjection':'PASS','recordedTemporaryRowsAbsent':True})
f.file_capture('62-after-cleanup-pdf');paths=[]
for org in ['orgA','orgB']:
 r=f.read('62-after-cleanup-pdf-'+org+'-files');parent=seed['sources'][org]['parent'];expected=next(file['path'] for file in seed['files'] if '/'+parent+'/' in file['path']);assert len(r['files'])==1 and r['files'][0]['path']==expected and r['files'][0]['present'] is False and all(rows==[] for rows in r['tables'].values()),r;paths.append(expected)
result={'status':'PASS','recordedTemporarySourceArtifactIdsAbsent':28,'originalProjectionSetsExact':20,'recordedActualPdfPathsAbsent':paths,'allTargetingRequestHistoryAbsent':True,'actualPdfHashesBeforeCleanupUnchanged':True,'comparisons':comparisons}
(v.root/'63-integration-cleanup-comparison.json').write_text(json.dumps(result,indent=2)+'\n');v.call('64-final-doctor','tool','doctor');v.call('65-owned-disposal','tool','cleanup');assert f.read('01-launch')==f.read('64-final-doctor');assert f.read('65-owned-disposal')['status']=='PASS';print('PASS 28recordedUUID/request absence,20originalsets,2actualPDFabsence/equality, frozen doctor and disposal',flush=True)
