from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();out=root/'.verification/tmp/review-feedback-vky1wph0'
name=sys.argv[1];argv=sys.argv[2:]
assert name and argv
original=json.loads((out/'adopted-source-identity.json').read_text())
files=[{'path':item['path'],'sha256':hashlib.sha256((root/item['path']).read_bytes()).hexdigest()} for item in original['files']]
overrides={}
if name.startswith('focused-final-02'):
 overrides={'TMPDIR':(out/'owned-tmpdir.txt').read_text().strip()}
if name.startswith('typecheck'):
 overrides={'TMPDIR':(out/'owned-tmpdir.txt').read_text().strip(),'PUBLIC_SUPABASE_URL':'http://127.0.0.1:59999','PUBLIC_SUPABASE_ANON_KEY':'ci-synthetic-anon','SUPABASE_SERVICE_ROLE_KEY':'ci-synthetic-service','ACCOUNT_SETUP_LINK_SECRET':'ci-synthetic-setup','ACCOUNT_SETUP_SESSION_SECRET':'ci-synthetic-session','APP_PUBLIC_ORIGIN':'','PUBLIC_APP_ORIGIN':'','PUBLIC_SITE_URL':'','APP_PUBLIC_ORIGIN_ALLOWLIST':'','VITEST_MAX_WORKERS':'1'}
meta={'command':argv,'envOverrides':overrides,'inheritedEnvironment':'not recorded','files':files,'workerHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
assert not (out/(name+'.log')).exists()
(out/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
with (out/(name+'.log')).open('x') as f:
 r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,**overrides})
meta['exitCode']=r.returncode
(out/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(name,'exit',r.returncode)
print((out/(name+'.log')).read_text()[-18000:])
sys.exit(r.returncode)
