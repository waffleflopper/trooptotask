# Training Reports #1503 v5 expanded evidence audit

**Artifact audit: PASS with the limits below. Product acceptance: remains FAIL on D4.** No missing, mismatched or mutated inventoried payload was found. The delegated reviewer reports D3 PASS over 384 programmatic measurements, but D4 FAIL: the dashed goal rule crosses the end-value label in the goal-95/flat-100 state. This audit preserves that verdict; it makes no appearance, layout, color, focus-visible or Paper judgment.

Reviewed 2026-10-04T06:56:52.325629+00:00. Scope is the immutable failed-v5 archive and expanded saved artifacts only. No current or in-progress application/correction source was inspected; no browser, service, database or test was run. Only this ignored report was written. This is same-provider artifact reading, not a new model-diversity review or independent live execution.

## Exact historical binding and integrity

Archive: `docs/verification/training-reports-1503/visual-failure-v5.tar.gz`, **1,696,296 bytes**, independently re-hashed to `f316ce2e80ac8f038530c2cf1093b0ac834483face74caa9fb24566dca018d8b`.

Expanded root: `.verification/packaged/1503/visual-failure-v5/`.

| Binding                       | Saved value                                                                                                         |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Candidate                     | `34438fcff6e95e651d3f6dcbd17453bfbc0e44234c3dc0ed8ac41367b6949f8f`                                                  |
| Revision                      | `d6a61861061d6bdb7f917180d988c49675922897`                                                                          |
| Base                          | `ad63659aa69b6db046bae94878d9ec55d8b23132`                                                                          |
| Session                       | `34ec9b7e-a20d-4939-86fd-2314839257fc`                                                                              |
| Actual UI route               | `http://localhost:43125`                                                                                            |
| Configured primary            | `http://127.0.0.1:43125`                                                                                            |
| Attempted private HTTPS route | `https://omarchy.tail930090.ts.net:18031`                                                                           |
| Source patch                  | `SOURCE.patch`, 47 source/scripts paths, SHA-256 `0e56ee01a3e8f5e42121a9b38e74daa31fa1f3a4da6e9cefe2f98ff867433f89` |
| Source digest                 | `c5bcb977881152624a1b9d1ba06edf04e915319a2f879ca32546f2cfb7171d27`                                                  |
| Output/build digest           | `f8890df83f7d160ea82c94bd18da8e863208e163ed338e6503f8f6def36e1676`                                                  |
| Adapter digest                | `7d4293a8e3aa20ac3088bf02cd1326762cb63e66630283b7f91e34b09aa817c7`                                                  |

`SOURCE-BINDING.json`, launch, start/before-driver/final doctors and adapter checkpoints consistently name this historical candidate/session/revision. The actual source-patch bytes match the recorded hash and the prior complete v5 nonvisual source review. I compared the saved source/output/adapter digest values across receipts; I did not rebuild the destroyed runtime to recompute those aggregate digests. All five archived adapter files named by `adapter-static/source-sha256.json` match their individual hashes.

All **441 inventory payload entries** exist and match their SHA-256 values. The archive contains **442 regular files**: those 441 payloads plus `inventory.json` itself. Every tar member is byte-identical to its expanded counterpart, with no missing/extra tar or expansion member. Inventory SHA-256: `f5b8134b300fe41df908fe0d68e7fc5d40834bd1c284c3a14d18d96973e4c7f4`.

All **277 supported dynamic-tool JSON records** parse and contain actual `toolName`, `input` and `output` fields. All **51 separately labelled durable command-text records** also match their hashes. Their 328 positions are unique, and the recovery index and hash audit name exactly the same files. Sixteen records were initially stored-text-truncated and have indexed recovery chunks (maximum 18); the archived recovery account identifies supported T3 itemId/UTF-16-offset retrieval. This audit validates the saved records/index/hashes, rather than re-querying T3 history. Command texts are not represented as full tool API envelopes.

`SUPPORTED-RAW-AUDIT.json` SHA-256: `daf2b4a74798d598bfb60b3b053180a075d21a9584c5bcd353cf5b9f4510ea9a`. `supported-raw-index.json` SHA-256: `a5499bc2c1c0bd02b65a0bd16c060a55e2d0864bd5b87ea3cf65ba19bc5f1dc9`. Driver condensed logs remain interpretation, not verbatim raw records. Stored-text recovery does not recreate intrinsically omitted tool results: position 0489 explicitly retains **108 older console entries omitted**, plus its action-timeline/network/console-list omissions. Consequently no complete-console or complete-network-history claim is made.

Root's recorded credential scan found zero matches and applied zero redactions (`redactions: []`). My bounded read-only scan of 425 textual payloads likewise found no JWT, Supabase secret, provider-key, GitHub-token or literal Bearer-token pattern. This pattern scan is not a guarantee about every possible credential format. Private runtime/carrier/helper-log/fixture files remain excluded; I did not inspect current private provider stores.

## Actual route and native authentication records

The transport failure and deviation are substantiated by actual records:

- Dynamic position **0017** opens the supplied HTTPS login URL. Positions **0018/0020** show a loaded but empty page. Position 0020 records an **X11/Linux T3/Electron user agent**, not a Mac user agent; position 0019's Sign In wait times out.
- Durable command positions **0025/0031** retain actual `HTTP/2 403` and `HTTP/1.1 200 OK` results. The H1 reply names this exact session in `X-T2T-1503-Session`. Archived `cookieMiddleware` requires `req.headers.host === expectedHost` even when `:authority` is present, supporting the delegated explanation of the protocol mismatch. The diagnosis remains grounded in this archived adapter, not a judgment of a later correction.
- Position **0033** switches to the primary loopback login. Command **0044** starts a one-shot localhost relay and records primary login 200; dynamic **0045** opens it and lands at `http://localhost:43125/auth/login`. **0046** fills email/password from the temporary carrier and clears `window.name`, returning only filled/cleared booleans. **0048** clicks the native Sign In button; **0049** reads back the admitted Organization A Dashboard route. No literal credential is in those recorded inputs/outputs.
- This route used the application's original cookies. It did not demonstrate the adapter's namespaced-cookie path. The saved checkpoint's `nativeHTTPS: true` describes adapter setup/check metadata; it does not turn the failed HTTPS browser attempt or H1-only check into Mac/HTTPS UI acceptance.
- Position **0492** clears driver session-storage keys, theme storage and `window.name`, and reports `__hk` undefined. Position **0488** preserves the exact unhook result `restored false`; the archived helper assigns its captured original fetch/Blob functions before computing that native-code-string heuristic. I do not silently replace that heuristic result with a native-function identity PASS.
- **0495** clicks native Sign Out. The immediate **0496** wait times out and **0497** reports unavailable automation host; these failures remain preserved. Subsequently **0501** requests the protected Training Reports URL in the same tab and returns the login route/title. **0502** confirms `/auth/login`, a password field, empty `window.name`, no driver session-storage keys and absent theme storage at `2026-10-04T06:31:29.120Z`. This supports successful native Sign Out for that primary session; it is not proof about other sessions or cookie namespaces.

No Mac route, successful browser HTTPS route, namespaced-cookie login, or browser-session-isolation UI claim is granted. The driver deviation remains explicitly labelled and does not establish permission/default workflow for later rounds. Passing H1-only adapter checkpoints do not close the recorded H2 blocker.

## Actual visible-button workbook

I followed the actual saved action/output chain rather than relying on the narrative export-200 claim:

1. Position **0475** reads the reloaded report with Alpha selected, one Type selected, and no summary request on that page load. The page URL contains the same `group`/`types` parameters as the export receipt.
2. **0477** clicks the visible `Export Excel` button.
3. **0478** returns actual response and Blob sizes/hashes/headers captured by the labelled fetch/`URL.createObjectURL` instrumentation. Its `value` exactly equals saved `root-visible-export-receipt.json`.
4. **0481** returns that response's complete Base64 bytes. I decoded them and verified byte equality with `driver/downloads/training-report-alpha-required.xlsx`.

Response, Blob, decoded raw output and saved workbook agree on **9,431 bytes**, SHA-256 `24bbdd474089a246a43dab9080398199356f5ee11040ba9dffd19b52e3e52502`, response status **200**, and the filtered export URL. Literal relevant response headers remain:

```text
cache-control: private, no-store
vary: Cookie
content-type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
content-disposition: attachment; filename="training-report-2026-10-03.xlsx"
```

Offline inspection of the actual XLSX ZIP/XML, independently of root's workbook-summary JSON, finds exactly one sheet, **Training Report**, six columns and 102 rows including the header. Headers are exactly `Name`, `Rank`, `MOS`, `Duty Role`, `Group`, `Verification Required Training`. There are **101 unique Soldier names**, all Group **Alpha**. The literal Able row is:

```text
Able, Synthetic | SPC | 68W | Medic | Alpha | Current (2027-09-26)
```

The other **100 rows are Not Done**. Every decoded cell/row equals `root-workbook-audit.json`. This is meaningful saved workbook-content evidence from that native button, and my verification is offline artifact inspection, not another browser execution.

## Complete captured restoration and owned cleanup

Each original/restored pair matches **byte-for-byte and as parsed JSON**, including the complete capture envelope and every retained captured field:

| Capture        | Rows/fields                                      | Original and restored SHA-256                                      |
| -------------- | ------------------------------------------------ | ------------------------------------------------------------------ |
| Organization A | One twelve-field profile; goal 90                | `8d28bd2c7b428fbd6ec1a174217b91316e0bfa28cc3f83a2b758378523e60752` |
| Organization B | One twelve-field profile; goal 90                | `a1d9789f4d9504447fe78666fbc97dd6a5a195235d8c4c01e056d8639165b381` |
| Training A     | One ten-field saved record, including timestamps | `b666080f5ec89a116813963b50b599778e62f1ee14b9427d965ab3717633a619` |
| Training B     | Empty saved row set                              | `7adbb67c4386551adbf0c5e63ae433312ee2748fd423352e45dddd3349d2b9a4` |

Seed setup/initial/admission/absence records agree on candidate/session. I compared the exact journaled ID sets with initial readback: **100 Personnel, 13 Types, one View, 852 Training records**, every ID unique and every set equal. The saved absence readback returns four empty arrays for precisely those tables. The archived seed readback implementation binds the owned session/candidate/Organization and reads only the journal's IDs in 100-ID chunks, with the Organization predicate retained. This establishes the intended exact-ID absence meaning; it does not claim every table is globally empty.

`root-clean-seeds.json` explicitly records `cleaned: true` and `artifactHttpSessionsCleared: true`. `root-restoration-audit.json` explicitly records complete equality, exact seed absence and both goals 90. The post-seed doctor passes on the same candidate/session/revision. The closeout script/log records the ordered readback, journal cleanup, post-seed doctor, H1-only transport check, adapter stop and worker cleanup; no current provider read was made by this reviewer.

`root-transport-stop.json` explicitly passes for this session with **helperGone, sidecarGone, forwardingGone, localListenerGone and serveMappingGone all true**; it names local port 19031/public port 18031. `root-owned-cleanup.json` explicitly says **PASS / cleaned**. **Worker-directory absence is root's separate observation**, reported in ROOT-CLOSEOUT and the coordinating message. Root confirms no separate structured absence receipt was saved before packaging; I therefore do not present that absence as an independently verified field or a current filesystem observation.

The stored provider/readback/stop receipts establish the recorded historical restoration and owned-cleanup outcome. They are distinct from ordinary UI access/write proof and are not a present database/process/listener observation.

## Acceptance and scope limits retained

`TASK-RESULT.json` is a completed T3 Claude result (`claudeAgent`, `claude-opus-5-5`) for `1503-final-chart-acceptance-v5`, with no pending child run. SHA-256 `cf231740fbc07830ff33a237ec269d567ec4723725f21eb70e3ffd28b3916845`.

Its **overall FAIL and D4 FAIL remain unchanged**. Its D3 PASS/384 measurements and outcome-2 PASS remain delegated observations of the exact candidate above, under the disclosed primary-route deviation. I did not view the screenshots or recalculate/approve their visual conclusions. Goals 1/100 and keyboard focus were not run. Server access/fault/race proof inherited from older v3 remains supplementary, not re-executed v5 proof. Retained-console absence of hydration warnings is qualified by intrinsic omissions. The driver retains the narrow 390 actions-row caveat.

The driver's outcome-3 statement mentions only the chart and Onboarding source-test changes; it is not the complete integration/source scope. `.verification/1503-prefinal-source-review-v5.md` independently binds the **complete 100-text-path cumulative review**, including main's registry/Data Export ownership integration and retained #1501/#1502 source. Its unchanged report SHA-256 is `2ff52f3d4f4116885b31753fff3fc3c9621c13a0c430d495faac2ab05ff7cf4f`. This artifact audit does not expand or replace that source verdict.

The failed archive stays tied to **d6a61861/ad63659a/34438fcf/session34ec9b7e**, even though main subsequently advanced (#1519) and another correction was assigned. It is neither new-main integration proof nor pending-v6 source/visual acceptance. No #1503 or parent #1433 completion is claimed.
