from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path.cwd()
evidence = root / '.verification/evidence/verify-trooptotask/1504-final-v7'
evidence.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment.update({
    'PATH': '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + environment['PATH'],
    'TMPDIR': '/home/waffleflops/.cache/t2t-1502-tmp',
    'NODE_DISABLE_COMPILE_CACHE': '1'
})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
base = subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
checks = json.loads((root / '.verification/1504-v8-required-checks.json').read_text())
assert len(checks) == 7
assert all(item['exitCode'] == 0 for item in checks if item['command'][2] != 'governance:check')
assert next(item for item in checks if item['command'][2] == 'governance:check')['exitCode'] == 1
assert f'Branch is behind origin/main ({base})' in (root / '.verification/1504-v8-governance-check.log').read_text()
reviewed_base = 'ee1ca2b275d71cd0b9a51367b58c4754a687a443'
files = subprocess.check_output(['git', 'diff', '--name-only', base, head], text=True).splitlines()
patch = subprocess.check_output(['git', 'diff', '--binary', base, head, '--', 'src', 'scripts', 'supabase', '.agents/skills/verify-trooptotask'])
checkpoint = {
    'head': head, 'base': base, 'reviewedIntegratedBase': reviewed_base, 'governanceStatus': 'BLOCKED by newer phase8 main; no guard changed or gate bypassed; scoped local proof only', 'changedFiles': files, 'totalFiles': len(files),
    'sourcePatchSha256': hashlib.sha256(patch).hexdigest(),
    'filesAtHead': [{'path': name, 'sha256': hashlib.sha256((root / name).read_bytes()).hexdigest() if (root / name).is_file() else None} for name in files],
    'requiredChecks': checks, 'state': 'source frozen before fresh owned launch; live acceptance pending'
}
(evidence / 'root-source-checkpoint.json').write_text(json.dumps(checkpoint, indent=2) + '\n')
receipts = []
def run(name, arguments):
    command = ['npm', 'run', '--silent', 'verify:app', '--', *arguments, '--worker', '1']
    started = time.time()
    print(f'Start {name}', flush=True)
    result = subprocess.run(command, env=environment, capture_output=True, text=True)
    (evidence / f'root-{name}.json').write_text(result.stdout)
    (evidence / f'root-{name}.stderr').write_text(result.stderr)
    receipts.append({'command': command, 'exitCode': result.returncode, 'seconds': round(time.time() - started, 3), 'stdout': f'root-{name}.json', 'stderr': f'root-{name}.stderr'})
    (evidence / 'root-launch-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    if result.returncode:
        print(f'{name}: exit {result.returncode}; inspect saved outputs', flush=True)
        raise SystemExit(result.returncode)
    value = json.loads(result.stdout)
    print(json.dumps({'phase': name, 'status': value.get('status'), 'candidate': value.get('candidate'), 'origin': value.get('origin'), 'session': value.get('session')}), flush=True)
    return value

info = run('info', ['info'])
assert info['status'] == 'PASS'
launch = run('launch', ['launch'])
assert launch['status'] == 'PASS'
doctor = run('doctor-start', ['doctor'])
assert doctor['status'] == 'PASS' and doctor['candidate'] == launch['candidate'] and doctor['session'] == launch['session']
runtime = {'phase': 'final-v7-owned-proof-launched-governance-blocked', 'head': head, 'base': base, 'reviewedIntegratedBase': reviewed_base, 'governanceStatus': 'BLOCKED by newer phase8 main; integration explicitly deferred; scoped local proof only', 'worker': '1', 'candidate': launch['candidate'], 'origin': launch['origin'], 'session': launch['session'], 'browser': info['browser'], 'evidence': str(evidence.relative_to(root))}
(root / '.verification/1504-final-v7-runtime.json').write_text(json.dumps(runtime, indent=2) + '\n')
print('Fresh owned launch and doctor PASS; no browser driver started.', flush=True)
