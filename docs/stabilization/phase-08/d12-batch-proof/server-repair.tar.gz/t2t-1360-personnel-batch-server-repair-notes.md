# D12 Personnel CSV server repair handoff

Base: 480e1e5142beb3b3a3667b6f956cef78a99a70d6. Worktree /tmp/t2t-1360-personnel-batch-server; branch stabilization/1360-personnel-batch-server.

Apply the baseline test commit 2106d75d8fbf3d84529602bf58442570672f1eee before the following repair commit. The baseline receipt and full actual five-failure output are retained in /tmp/t2t-1360-personnel-batch-server-baseline-notes.md and /tmp/t2t-1360-personnel-batch-baseline-final.txt. No production source changed before that baseline run.

Owned files:

- personnelBatch.server.ts and moved tests: creation operation, numeric slug assignment and one healthy atomic bulk insert; at most three bulk attempts only after exact submitted-candidate conflicts.
- personnelDateBackfill.server.ts and moved tests: date-only operation, acknowledged-snapshot file order, update-only catch, safe indexed unconfirmed errors, continued independent rows, normal result/audit.
- personnelImport.types.ts: the coordinator's fixed portable input/result/message types, importing Personnel from private personnel.types.
- personnelBatchContext.server.ts: shared narrow request policy/audit/read facts for two actual operations; each operation extends with only insertMany or update. Optional rawStore remains rank-catalog reads only; Personnel lookup/recovery uses ordinary store.
- personnelSlug.server.ts and tests: strict named-index/code/key-detail/current-Organization/current-candidate extraction. Missing/unrelated/foreign/unsolicited metadata does not trigger retry.
- supabaseDataStore.ts and tests: preserve code/details internally only for the named Personnel slug unique conflict. Existing generic HTTP error boundary still conceals raw provider details.

Old central operation and test files are removed. No legacy export or facade is added. Operations use direct owner-private imports. Root owns public entrypoints/contracts, route cutovers, manifest/governance entries, UI, fixture controls and docs; these were not edited.

Actual validation:

- Focused five-file suite: 90 tests pass, output /tmp/t2t-1360-personnel-batch-focused-final.txt. Covers all original tests and baseline defects, three-attempt exhaustion with no partial persistence, unaffected names, one healthy 500-row batch, arbitrary/unconfirmed conflict nonretry, continued following row, lost acknowledgement and fresh replay, same/evolving repeated dates and privacy.
- Initial repaired run: two failures only because the test's unconfirmed-message expression omitted the grammatically equivalent "not be confirmed". The expression now permits that wording while still requiring uncertainty and excluding private provider content. /tmp/t2t-1360-personnel-batch-focused-initial.txt retains the failure; no behavioral expectation was removed.
- Focused ESLint, Prettier check and git diff --check pass.
- Full types before root integration: exactly two missing-module errors in root-owned batch/merge routes still importing removed central operations; no errors in worker-owned files. /tmp/t2t-1360-personnel-batch-types-preintegration.txt. Root route/public seam integration and final-candidate type/full checks remain required.

No browser/service/database/migration/publication ran in this worker. Controlled fake persistence proves orchestration and fault timing, not SQL enforcement or native user journeys. Root reported separately that its unchanged-source ordinary Alpha bulk request returned generic 500 with hidden Bravo unchanged and unrelated Alpha absent; its native evidence remains independently owned.

Limits: ordinary bulk creation is still a distinct create, not an idempotent upsert. Only confirmed atomic unique rejection is retried; unknown acknowledgement is not blindly retried. Three rejected candidates exhaust the bulk attempt bound and return the existing request failure. Backfill remains nontransactional; errors report unconfirmed updates without implying no persisted effect. File-order results compare against acknowledged state only; a contradictory multi-value file replay can perform writes while retaining the same final state. Remaining lifecycle/detail/bootstrap/approval/export/switch obligations and issue #1360 remain open.
