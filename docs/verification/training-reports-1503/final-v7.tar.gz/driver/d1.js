async () => {
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  const r1 = (v) => Math.round(v * 10) / 10;
  const box = (el) => { if (!el) return null; const b = el.getBoundingClientRect(); return { l: r1(b.left), t: r1(b.top), r: r1(b.right), b: r1(b.bottom) }; };
  const actions = document.querySelector('[aria-label="Training report actions"]');
  const toolbar = document.querySelector('[aria-label="Training report controls"]');
  const kids = actions ? [...actions.children].map((c) => ({ text: c.textContent.trim(), box: box(c), visible: c.getBoundingClientRect().width > 0 })) : [];
  const controls = toolbar ? [...toolbar.querySelectorAll('button, [role=radio]')].filter((c) => c.getBoundingClientRect().width > 0).map((c) => ({ name: c.getAttribute('aria-label') ?? c.textContent.trim(), box: box(c), checked: c.getAttribute('aria-checked') ?? c.getAttribute('data-state') })) : [];
  const overlaps = [];
  const all = [...kids.filter((k) => k.visible && k.text), ...controls.map((c) => ({ text: c.name, box: c.box }))];
  for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
    const a = all[i].box, b = all[j].box;
    if (a.l < b.r - 0.5 && b.l < a.r - 0.5 && a.t < b.b - 0.5 && b.t < a.b - 0.5) overlaps.push([all[i].text, all[j].text]);
  }
  const main = document.querySelector('main main') ?? document.querySelector('main');
  const vw = document.documentElement.clientWidth;
  const offscreen = all.filter((c) => c.box.r > vw + 0.5 || c.box.l < -0.5).map((c) => c.text);
  const heading = document.querySelector('h1');
  const alert = [...document.querySelectorAll('[role=alert]')].map((a) => a.innerText.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const bl = document.querySelector('[aria-label="Bottom line"]')?.innerText.replace(/\s+/g, ' ').slice(0, 90);
  return {
    href: location.href, viewport: [innerWidth, innerHeight], theme: document.documentElement.dataset.theme,
    status: document.querySelector('[aria-label="Training report actions"] [role=status]')?.textContent.trim(),
    heading: box(heading), actions: box(actions), actionKids: kids, toolbar: box(toolbar),
    toolbarRows: [...new Set(controls.map((c) => c.box.t))].length, controls,
    radios: controls.filter((c) => /days$/.test(c.name)).map((c) => `${c.name}:${c.checked}`),
    overlaps, offscreen, docOverflowX: document.documentElement.scrollWidth - vw, mainOverflowX: main ? main.scrollWidth - main.clientWidth : null,
    toolbarPosition: toolbar ? getComputedStyle(toolbar).position : null, alert, bottomLine: bl,
    focus: { el: document.activeElement?.getAttribute('aria-label') ?? document.activeElement?.textContent?.trim().slice(0, 40), visible: document.activeElement?.matches(':focus-visible') }
  };
}
