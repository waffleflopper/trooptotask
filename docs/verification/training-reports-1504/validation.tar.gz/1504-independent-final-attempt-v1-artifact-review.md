# Independent nonvisual review: #1504 final-attempt-v1 artifacts

**Verdict: the preserved v1 evidence supports the bounded non-print Training journeys below. This attempt does not complete acceptance.** PDF capture failed twice, no PDF exists, and successful keyboard Retry left focus on BODY. Later source corrections and the pending v2 runtime cannot repair those historical observations. No additional Training calculation, detail, export-content or authorization defect was found in the inspected v1 evidence.

This is an independent artifact/source-context review, using the previously supplied portable Poteto persona and repository contracts. I read the actual expanded receipt payloads, accessibility snapshots, provider rows and workbook ZIP/XML. I did not use the driver's decoded workbook files or report as the source of expected results. No application/helper execution, test/gate, browser/service, database, connector, Git/PR action, nested delegate, source/doc edit, or external write was performed. The sole write is this report. Images were inventoried/hash-checked but not visually judged; T3 Claude owns visual/design/PDF judgment. This reviewer inherits the parent's model: no independent live execution or model diversity is claimed.

## Candidate and evidence binding

- Reviewed live-attempt source: **2e3aea52ad01e33e173b769f285b0ab6103547d7**, against current-main base **a59c6c92bba242cde37f15a5d59e6d305e5267ac**.
- Owned worker 1, session **b4853547-1f21-457b-9c3d-325985de2f67**, candidate **3c5c3154c89d03781d701ad70518b6338395baa25aa55937c57d06bea11ee787**, origin **http://127.0.0.1:33931**. The start, driver final, root closeout and after-seeds doctor receipts all report PASS with those same identities.
- Archive: `docs/verification/training-reports-1504/final-attempt-v1.tar.gz`, 8,194,402 bytes, SHA-256 **0347ab3ccd6e78bc303fe65c8171126e9b0b98d4e9bf108b9cdd4ad33ab85104**.
- Expanded root, used for all relative evidence paths below: `.verification/packaged/1504/final-attempt-v1/`.
- `inventory.json`: 189,323 bytes, SHA-256 **870f38d8e02f89876e93a0e1cf5d151ddbdfaaa61a737423c0029a096a633c06**. All 1,364 unique inventoried payloads exist with their stated hashes. There are 1,365 actual regular files including the inventory itself. Archive and expansion have identical member sets and bytes; no unsafe/traversing or special/link member was found.
- `root-source-checkpoint.json` has 137 entries: 133 existing files and four deletion markers. Every entry/hash agrees with the complete independently pinned cumulative census in `.verification/1504-independent-cumulative-source-review-v1.md` (SHA-256 **c54fb7fc6588687f14e1af38c5b6e910de1a9e1b619b55ef9ec5470be036bdeb**). This round reuses that source/spec/consumer verdict rather than repeating the entire source sweep.
- Root later reported corrections committed at **580c24fa10d517065894ca4bc1e6856746890f7c**: daemon structured-content flag, detail-Retry focus handling/test, and this failed-run archive. Their current checks/runtime are outside this v1 verdict.

The receipt index records **565 actions** from 10:32:38 through 11:22:40 Alaska time on 2026-10-04, but only **563 distinct stdout/stderr pairs** survive. Two names were reused with the same output/capture paths:

1. `snap-p2-matrix-pre`: 10:37:07 and 10:37:31.
2. `snap-p3-group-open`: 10:40:16 and 10:40:24.

Only the latest payload for each remains. The earlier output/snapshot bytes are overwritten, not preserved or reconstructed. The index preserves the attempted actions, not both original captures.

There are 14 nonzero action receipts: stale-UID clicks 042/065; waits 044/056/081/118/340/399/419; print saves 135/138; invalid evaluate argument 342; empty-UID delete confirmation 403; mistyped doctor command 428. Later actual observations support the recovered states. The driver's initial failure list is not exhaustive: 403 is disclosed later in its restoration prose. Failed stdout may be empty; preserved stderr and index exit codes are the failure evidence.

## Independently counted fixture

The provider originals and fixture contracts establish 2026-10-04 as the observation day. Alpha contains Able (68W/Medic); Bravo contains Baker (11B/NCO); Unassigned is 68W/NCO. Required applies to all three. Targeted applies to 68W excluding NCO, hence Able alone. Optional is excluded. Therefore the original denominator is **four required Soldier/type pairs**, not three people or three catalog types. Able Required is the only original completion: 2026-09-27 through 2027-09-27. Expiration day remains ready; lapse is the next calendar day. Goal is 90. Horizon ends are 2026-11-03, 2027-01-02 and 2027-04-02 for 30/90/180 days.

| State | Soldiers / applicable | Ready / expired / missing / horizon lapses | Today → horizon |
|---|---:|---:|---:|
| Original | 3 / 4 | 1 / 0 / 3 / 0 | 25% → 25% |
| Dated import | 3 / 4 | 2 / 1 / 1 / 1 | 50% → 25% |
| Dated Alpha | 1 / 2 | 2 / 0 / 0 / 1 | 100% → 50% |
| Dated Bravo | 1 / 1 | 0 / 1 / 0 / 0 | 0% → 0% |
| Dated MOS 68W | 2 / 3 | 2 / 0 / 1 / 1 | 67% → 33% |
| Dated NCO | 2 / 2 | 0 / 1 / 1 / 0 | 0% → 0% |
| Dated + 26 seeded people | 29 / 31 | 2 / 1 / 28 / 1 | 6% → 3% |
| Authorized empty roster | 0 / 0 | 0 / 0 / 0 / 0 | blank percentages |

Actual CSV preview contains two valid rows, with provider count still one before import (`048-rows-A`). Native Import writes two rows; actual POST batch result and `053-rows-A` agree:

- Able Targeted: **4fdcda50-c6af-44ea-ae77-f0804d3caabe**, completion 2025-10-19, expiration 2026-10-19, note “Verification warning”; ready for 15 more days, lapses 2026-10-20.
- Baker Required: **f4a6d59a-e8f5-4060-bf90-04be8a552a9d**, completion 2024-10-04, expiration 2025-10-04, note “Verification expired”; expired 365 days.

Required risk is 2 not-ready / 0 horizon lapses; Targeted is 0 / 1. The dated grid orders Bravo, Unassigned, Alpha, then Total; Required Total is 33%, Targeted Total 100%, organization 50%/25%. Original Focus has the two standing gaps. Dated Focus has Required standing gap (organization forecast 25→75), then Alpha Targeted (row forecast 50→100). One horizon lapse cannot satisfy the five-lapse minimum for a cliff, so no wave is expected in this fixture. These figures and ordering agree with the actual complete snapshots and workbook contents.

## Bounded journey coverage

| Journey | Artifact-derived result and limit |
|---|---|
| Native report admission / SSR / reload | Supported. Visible Reports navigation, original grid/risk/Focus, cell and Focus actions are recorded. Actual document with scripts stripped contains the figures, cell labels and Focus templates. Navigation network list 017 and reload 021 contain the route data/document, without a second summary API fetch. Filtered reload 086 likewise has only document plus notification-count. This is a request-count observation, not a measured large-data performance result. |
| Dated matrix and report | Supported by native preview/import, actual POST/provider readback, dated matrix and full briefing snapshot. Literal totals/date labels/type ordering agree. |
| Filters | Supported: Alpha, Required, 30/180, Focus view (Targeted before Required), MOS 68W, NCO, SPC, MOS/role rows; selected URL/labels survive reload. SPC includes the three original people. Alpha+Required is 100/100, and no-applicable cells are distinct from zero readiness. |
| Held / failed summary | Supported. Failed Bravo refresh records synthetic503, retains unfiltered50/25 with last-shown URL/control state, and Retry later loads Bravo0/0. During held Alpha refresh the shown report remains Bravo, control pending Alpha; native export is Bravo and release loads Alpha. Print output of these states is unproved. |
| Initial detail and failure/Retry | Supported for exact Total Required, Alpha Targeted and Focus keys. Original Required has two missing rows; dated Required is Unassigned missing then Baker expired; Targeted/Alpha Focus is Able with literal expiry and Yes. Initial focus moves to the named region and cell/link selected state is captured. Initial503 does not invent a table/count; Retry loads the attempted scope. Successful keyboard Retry focus has the separate failure below. |
| Late detail guards | Supported for the two actually exercised races. A real held200 Focus response released after Clear filters leaves detail absent (`174`, `177`, `178`, `p4-after-late-release.txt`). A held200 Total Required response released after opening Alpha Targeted does not replace the newer one-row detail (`185`, `186`, `p4-race2-after.txt`). These isolated-page races do not prove same-session Organization switching or sign-out races. |
| Pagination and full export | Supported. Seed receipt188 records tag c42b2731/count26; helper fixture specification makes all26 Required and only temp00 Targeted. Total Required has28 affected rows. Receipt193 is temp00–24, 200 is temp25/Unassigned/Baker, with no duplicate/omitted pair. Held page2 keeps page1. Failed Previous keeps exact page2/range (205 equals200); Retry210 equals193. 100-row214 contains all28; new Alpha Required scope218 contains26 at page1 with100 retained. Request URLs201/211/215/219 corroborate page2/pageSize100/newscope. Workbook exported with the26-row detail open contains **all30** affected pairs, including two outside that detail. |
| Native Excel success/failure | Supported: eight report button captures and one separate Person capture. Failure263 has captured=false and264 actual503; visible Retry produces the correct Alpha workbook via269–271. No failed download is relabeled successful. |
| Roles / cross-org / zero scope | Supported for actual actors/requests listed below; no mutation/RLS/remote certification. Actor helper admission claims alone were not treated as proof. |
| Retained consumers | Supported proportional spot-checks of Training matrix, Able/Baker Training lane, actual Person Training Records workbook and Dashboard Training identities. Other Personnel lanes are unavailable for this actor, not successful flows. Full raw-Organization export and Onboarding journeys remain explicitly UNRUN; their unchanged contracts/current source and earlier lower-level evidence were reviewed in the cumulative lane. |
| Print / paper-only error and no-applicable states / wide cases | **FAIL/UNRUN.** Only native invocation is proved. No PDF, rendered page or live successful print-capture transport exists in v1. |
| Visual widths/themes/layout | Screenshots/actions are preserved, but this reviewer makes no visual verdict. Keyboard selected-state/initial focus facts are inspectable independently; Retry loses focus. |
| Restoration / owned cleanup | Supported as recorded evidence, with browser-key limitations below. No independent live process/database inspection was performed by this reviewer. |

Selection is proportionate to the cumulative #1433/#1501–1504 change: current model/URL/loading/admission/rendering/detail/export/retained consumers receive affected live coverage, while the prior goal SQL/settings contract and large arithmetic/clock/cliff/order boundaries keep their existing lower-level and prior-candidate evidence. V1 does **not** independently exercise live goal editing, exact expiry-day/leap-month boundaries, ≥5-lapse waves, all three Focus slots, many-column print, thousands of records, or Organization/sign-out races. A two-required-type fixture and31 pairs cannot certify those as current live journeys. No requirement was silently replaced by the Paper illustration or a geometry/copy assertion.

## Actual workbook bytes

I parsed each of the 12 actual XLSX ZIP/XML buffers independently, including shared strings, worksheet relationships and ordered sheet rows. No formula objects occur. All **11 report workbooks** have exactly ordered **Summary / Forecast / Hot spots / Focus / Requirements**; the separate Person export keeps its distinct four-sheet contract.

Summary contains literal numbers, dates, goal and all eight normalized filter descriptions; zero denominators yield omitted/blank percentages rather than a fabricated0%. Forecast is today plus13 bucket-end points, ending2Jan; the only lapse is in19–25Oct, and all cliff flags are No. Hot spots/Focus match the independently counted population. Unfiltered Requirements are, exactly in order: Unassigned Required Not Done; Baker Required expired with2025-10-04; Able Targeted15d left with2026-10-19, lapse2026-10-20, Yes. Quiet-ready Able Required, optional, N/A and foreign pairs are absent.

| Actual file in `accept/` | Provenance | Bytes | Requirements data rows | SHA-256 |
|---|---|---:|---:|---|
| dated-unfiltered.xlsx | native trainingConfigure button; detail open | 11859 | 3 | 257fb8d5c86f9cec980f5064eb7b9d111c25abf295dc7965328ac6376f8c92a7 |
| dated-alpha.xlsx | native; empty Alpha Required detail open | 11552 | 1 | c09756fb120b414fbc9393b9e6c5797d2a5d58626fc7cf574729f4b44f5ee7d7 |
| seeded-detail-open.xlsx | native; Alpha Required detail open | 12579 | 30 | 324ab556ebab1e616f02e6d3034d86365f2688f453cf813cbcb74e2d4b20a1bd |
| held-export.xlsx | native; shown Bravo while Alpha pending | 11516 | 1 | f6b6be1389aa6196de1f3ebfd864fa149a0ee2ee28b2c42407676b219754bb4e |
| export-retry.xlsx | native Retry after503 | 11553 | 1 | 072977db26f05c6d65d8f4e022c8b0208ece0da51b459ac76f372d6ee9f01b95 |
| view-export.xlsx | native trainingView | 11859 | 3 | e3ec26b10a46063f2aa734f0de6b95a91d1de12ef582aa284d532ac6c3eee38c |
| scoped-export.xlsx | native rosterScoped | 11558 | 1 | 07647c8c14b9dc7319e092a2bcfa1f5720ddf89755d84a046842a2df2285c25c |
| foreign-export.xlsx | native trainingForeign | 11468 | 1 | acf34d1befca436c671cc7f2454b83d54d1e4045096a2eebc43fd6e34503767b |
| empty-probe-1.xlsx | direct authenticated API, NOT a button download | 11219 | 0 | 5892803e2bc7767ed34601cbc8476ccb1f1997f1472ee8c4f6bbf1fea379564c |
| scoped-probe-6.xlsx | direct API Bravo outside permitted roster | 11223 | 0 | 0ce2a8d307ef5f27ddfcb9117a7a26920c0b3120ca7a0ea1bc4741225dcc8d50 |
| foreign-probe-3.xlsx | direct API with A keys, B session | 11468 | 1 | aaa3949fefa97cc00e153372abeba3706b51704b7b8a9a2c1a6e90efb763ba24 |
| able-person-export.xlsx | native separate Export records | 9383 | separate contract | 8b1e2b24324b2edf60aeb8f74c5c9dabc56530260b607efe2922c556c684341a |

The eight native report saves use `training-report-2026-10-04.xlsx` and the XLSX MIME. The separate Person filename is `SPC_Able_Synthetic-export-2026-10-04.xlsx`. Actual direct-probe base64 bytes exactly equal the three API-only files; those probes cannot be called native downloads. The driver's 11 decoded-JSON files agree with actual XML, but that agreement was a cross-check after independent parsing.

Seeded Requirements exactly matches the26 literal temp Required pairs, temp00 Targeted directly after temp00 Required, then Unassigned Required, Baker Required, Able Targeted. Thus all30 pairs, full order/status/expiry/lapse/Yes-No data, are checked—not merely a30-row count. Seeded summary31 applicable /2ready /1expired /28missing /1lapse and6→3 agrees. Required Focus has28 affected,97% of29 people and3→94; Targeted standing-gap body describes one already-missing person while its full affected link/export includes temp00 plus Able's future lapse (two people/two requirements),3→10. Those distinct counts are intentional.

## Role and retained-consumer boundaries

Native isolated contexts actually establish: trainingConfigure page2; trainingView3; Alpha-only rosterScoped4 (Training operate, Personnel none); empty5; viewer6; foreignB7; rosterManager8. Their snapshots and actual workbook contents are consistent with their contracts.

Direct authenticated requests are separately labeled API proof. Scoped Bravo summary200 has zero people; foreign group normalizes to owned one-person scope; scoped Bravo-row/foreign-type/invalid Required-gap detail404. Scoped valid quiet Total Required detail200 is empty. Empty summary/detail are zero, button disabled; authorized API export still has exactly five populated-structure sheets and empty Requirements. Viewer route/summary/detail/export are403. B session with A group normalizes to B; A type/focus detail404; A group/types export contains only Foreign Private Training; B session requesting A organization endpoints404 “Organization not found.”

**Evidence limit:** `mkprobe.py` and the recorded evaluation arguments truncate JSON/HTML bodies at4,000 characters. Full detail/error bodies below that limit and full binary XLSX are preserved, but larger summary bodies are not. In particular, `acceptance-report.md:196`'s broad scoped “all of the above: no identifiers” cannot prove absence throughout an omitted JSON tail. Complete native snapshots and full workbook rows do establish their own bounded known-person/type exclusions; static authorization was independently reviewed earlier.

**Evidence limit:** `374-obs.stdout` arms an **OrgA** export suffix on native **OrgB page7**. `377-ns.stdout` consequently has `calls:[]`. Native click376, save378 and the full B-only workbook remain actual evidence of capture, but this observer supplies **no HTTP status** for that native export. The direct B API export in372 has200 and its own separate bytes. Do not substitute that status into377 or infer a provider/export failure from the empty observer.

Baker and Able's Training cards reflect their actual expiry/warning facts. Their Availability/Critical Tasks/Rating Scheme cards are Unavailable. Direct source context explains this without accepting those flows: `scripts/verification/fixtures.mjs:153` grants rosterManager Training operate/Personnel configure; capability assembly371/373/375 defaults its other three lanes to none. `src/routes/org/[orgId]/personnel/[personnelSlug]/+page.server.ts:31` independently authorizes each readiness lane; `personnelDetail.server.ts:93` requires Calendar policy before reads; `PersonnelDetailContent.svelte:122` renders rejected lanes as Unavailable. This is a source-supported permission explanation, not captured successful lane responses or a full other-feature check.

The actual Person Training Records sheet has Able Targeted2025-10-19/2026-10-19 plus Required2026-09-27/2027-09-27, including warning notes. Dashboard reports33% training current, one person with expired training and one expiring item. Those retained currency meanings need not equal Reports50%; the snapshot is consistent with the fixture. What's New stayed open; no acknowledgement/preference write is invented.

## Concrete residual findings and claim corrections

1. **Acceptance blocker: print capture cannot run at pinned2e3.** Producer: `scripts/verification/daemon.mjs` MCP launch around233; consumer `scripts/verification/print-capture.mjs:147`; evidence `135-print-save.stderr` and bounded retry138 both say “Native page list has no structured pages.” Actual137 lists page2 and one matching URL only in text, with no structured pages. Installed MCP1.10.1 `config/mcp-options.js:65` defaults experimentalStructuredContent=false; `ToolHandler.js:280` emits structuredContent only when enabled. Minimal correction is enabling the installed supported flag and proving a fresh owned native run. Root reports that correction, but v1 does not prove it. Prior isolated print-source review explicitly had runtime UNRUN; its mocked structured responses did not establish launch-flag compatibility. **No PDF** is present among all1,364 payloads. Light/dark/Alpha-with-detail, failed-summary/detail, no-applicable, wide and collapsed-sidebar paper requirements remain unaccepted. Native132 arm→133click→134state has beforeprint1 **before** either capture attempt, proving invocation separately; it cannot prove successful capture/rendering or PDF layout.

2. **Observed keyboard defect: successful detail Retry leaves focus on BODY.** `acceptance-report.md:177`, native327 Enter, loaded-detail328 and actual329 active-element result agree. The Retry button unmounts and the region does not reclaim focus on this candidate. Minimal correction is moving focus to the existing affected-soldiers region on explicit Retry while preserving failed page/range and attempted request semantics; root reports a later bounded correction. Fresh keyboard and failed-page Retry evidence is required before closing it. The opening statement at report5 (“Every other required journey passed”) and table46's blanket keyboard PASS must retain this qualification.

3. **Preservation / claim boundary:** two earlier snapshots/outputs are overwritten; complete-summary tail absence is not preserved; foreign native export status is not observed by377. Minimal correction is honest scoped labeling and unique names in future captures, not reconstruction of missing bytes. The read-only matrix print-selector query343 finds23 rules with zero matches on that page; report45's “Other page's print-media effect PASS” is supported only as this selector observation. It does not prove actual media rendering or a PDF of another page.

The driver's visual V1/V2 judgments and their stated priority are outside this review. No conclusion about screenshot legibility, geometry, chart clipping, color, section splitting or print appearance is made.

## Restoration, privacy and closeout

I independently compared the entire parsed JSON and byte hashes of each `root-*-original.json` versus corresponding `root-*-restored.json`: **personnel_trainings, training_types, training_views and organizations for bothA/B**. All fields—including IDs, completion/expiration values, null notes/certificates and created/updated timestamps—are equal. All eight `421-final-*` driver readbacks also equal the originals. Original completion **c072729e-9423-4fae-b810-a01b8818ce3f** remains exactly intact. TrainingConfigure preference originals/restored are equal.

Failed confirm403 is not called a deletion:404 has no calls and406 still has three completions. Subsequent visible confirmation408 yields DELETE200 at409 and two rows411; second visible deletion415/416 removes Able's imported row. Final rows return to the one originalA row and zeroB rows. Seed cleanup and reload restore three-person totals, then root records final clean-seeds, doctor and owned cleanup. All28 final network/export/print/feedback restore receipts across pages2–8 report restored=false, consistent with earlier per-operation restorations leaving nothing armed; these are recorded helper results, not a fresh independent observer inspection.

Original viewport1905×2053/light is restored visibly. Exact browser storage is **not** fully restored: final427 has localStorage.theme=light where no such key existed and sidebar:state=true where no cookie existed; mode-watcher system stays unchanged. The root audit records these additions. They belong to the destroyed private profile; no claim is made that the before/after browser-key sets are equal.

`root-owned-absence.json` records exact-owned supervisor/app/MCP/browser process absence using PID/start/command identity, no profile processes, absent private worker directory and retained payloads. I reviewed that receipt; I did not inspect live processes, and the subsequently launched v2 worker is outside this historical cleanup claim.

`REDACTIONS.json` records **1,309 UTF-8 files at redaction time**, two synthetic access/refresh value substitutions in the one HTML response, original hash95bd2d07d28d2c61bb4c0c58b7e530e879885442c4b14ff32d83b3c6c6eba97c, sanitized hash**d4785261d374295ee556f58532d057a058033024970ece910656fb0262e55fed**. The original unredacted bytes are not preserved in this package. I inspected **all1,313 currently expanded UTF-8 files including final metadata/inventory**, found the two [REDACTED] session values only in that file, and zero remaining session-token/JWT/bearer/service-role/private-key pattern matches. These are distinct packaging-stage census counts, not1,309 claimed as the final full scan. Binary workbooks/images were not changed by redaction. Pattern scanning cannot certify every possible secret representation.

## Key evidence hashes

All other payload hashes are pinned by the verified inventory. These selected SHA-256 values identify the actionable receipts and review inputs:

| Relative path | SHA-256 |
|---|---|
| root-source-checkpoint.json | 9033c9325f08e161b1f005d7b709227030c409545c44ed4eaa23f45bb784aca6 |
| root-public-fixture.json | cec94479efd3d20d239dd8f5c6ab7e3efc032e424959268a19aed93f79111f37 |
| acceptance-report.md | 99fe2ee163db7de4dc88697a4cec1e06a86070180415ea7ca22ec55b3120eef3 |
| accept/expectations.md | ad3c83c7f105bcaf955b624eba97deaf61233e85b445070789f50f26e04be355 |
| accept/receipts/index.jsonl | 04584bae32b9045b3a88ba0c6086b792c0ac80e20f5378d9334323406a464571 |
| accept/receipts/134-print-state.stdout | 8a5f8ddccb6175f3aefdd2a8296f990c8f3a42dfab35464808a1baf8661be661 |
| accept/receipts/135-print-save.stderr and138-print-save-retry.stderr | f8911cbebc535737c5992b201e6bb12e6b3c461efddafcceab13936d776ca20f |
| accept/receipts/137-pages.stdout | 601e86aab305671a086cf89a950c49444de5e9bbf1d5eb8edcdb9aa5efb2c845 |
| accept/receipts/329-ae.stdout | ae6ff59524cb7326804095cb18125ecf49dfc1467778f5da5dcf60471d8467d4 |
| accept/receipts/374-obs.stdout | 9316a5871dfec3f6a5f175de6cd38ad5f11711efb771439ea4e28a71da4dc307 |
| accept/receipts/377-ns.stdout | 29e135ff74cc47aad5e13f3ad13da72e31682e1bca55649733ef6077559eacb0 |
| accept/receipts/193-rows.stdout and210-rows.stdout | 541175050556f950af2b87cad03d18b1b679c556c5848f13bcbed815b06670a9 |
| accept/receipts/200-rows.stdout and205-rows.stdout | 4ad166fdd5a3c16d2bd3b675c2bec26ab65dd53cd9022967ae6924c35064ac39 |
| accept/receipts/214-rows.stdout | 0df03ba3ca43ba2f4ca3ed4d6cc32bf58036bfcf2d07fffe9316acca1d065bf4 |
| accept/receipts/218-rows.stdout | 277df683a069bc855926961879b03b667d4be0adfb477b4a874892d3e001ffbf |
| accept/p4-after-late-release.txt | dc3d421937dbb9c8122a075db86dfb7ecb9988f5dc4dce6e6dbd4d2dd442f012 |
| accept/p4-race2-after.txt | abb9f039249039cb3ea8d90fc1c8b7ac7d4be726b59c3fee041db6bac78c7108 |
| root-restoration-audit.json | 2505ff7e993bb40d80b3ac5d15619903a9d8719905c69e8a6587f854e0d58e3d |
| root-owned-absence.json | dfc723cd9a7bc974f36cf3a105019a7e95d420c2523efe962aee828aab97f16b |
| REDACTIONS.json | 929b1e7363ec35a14e7e5672c5e46850a6ff29bfec1ae82b4b04d7afdd9c4968 |

This report does not certify the later source delta, v2 print transport/output, visual acceptance, hosted CI/review/readiness, or the whole final task. Those require their separately pinned evidence and acceptance.
