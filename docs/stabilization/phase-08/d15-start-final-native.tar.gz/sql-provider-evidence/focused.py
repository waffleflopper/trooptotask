import hashlib,importlib.util,json,os,shutil,signal,subprocess,tempfile,tomllib
from pathlib import Path
repo=Path.cwd(); proof=repo/'.verification/tmp/start-sql'
spec=importlib.util.spec_from_file_location('db',repo/'scripts/ci/database.py');db=importlib.util.module_from_spec(spec);spec.loader.exec_module(db)
files=sorted([p for p in (repo/'supabase').rglob('*') if p.is_file() and '.temp' not in p.parts and '.branches' not in p.parts]+[repo/'scripts/ci/database.py',repo/'scripts/ci/onboarding_start_provider_probe.mjs',Path(__file__).resolve()])
def fingerprints():return {str(p.relative_to(repo)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
freeze=fingerprints();(proof/'focused-inputs-before.json').write_text(json.dumps(freeze,indent=2)+'\n')
source=tomllib.loads((repo/'supabase/config.toml').read_text());reservations=db.reserve_ports(len(list(db.port_fields(source))));work=Path(tempfile.mkdtemp(prefix='t2t-ci-db-start-focus-'));project=work.name;container='supabase_db_'+project
metadata={'project_id':project,'directory':str(work),'container':container,'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'mode':'fresh selected SQL and ordinary provider probe','source_files':len(freeze)}
env=db.local_docker_environment(repo);started=False
try:
 ports=[s.getsockname()[1] for s in reservations];cfg=db.prepare_project(repo,work,project,ports);metadata['ports']={'.'.join(f):p for f,p in zip(db.port_fields(cfg),ports)};metadata['seed']=cfg['db']['seed'];m=sorted((work/'supabase/migrations').glob('*.sql'));metadata['migration_count']=len(m);metadata['migration_range']=[m[0].name,m[-1].name];print(json.dumps(metadata),flush=True);(proof/'focused-project.json').write_text(json.dumps(metadata,indent=2)+'\n')
 def execute(command,**kwargs):return db.run(command,work,environment=env,**kwargs)
 execute(['supabase','--version'])
 for s in reservations:s.close()
 started=True;execute(['supabase','start','--exclude',db.EXCLUDED_SERVICES],quiet=True)
 psql=['docker','exec','-e','PGPASSWORD=postgres',container,'psql','-U','supabase_admin','-d','postgres','-v','ON_ERROR_STOP=1']
 execute([*psql,'-c','SHOW server_version;','-c',"ALTER SYSTEM SET supautils.hint_roles = '';",'-c','SELECT pg_reload_conf();'])
 execute(['supabase','test','db','supabase/tests/onboarding_atomic_start.sql'])
 provider=db._provider_environment(repo,work,lambda command,workdir,**kwargs:db.run(command,workdir,environment=env,**kwargs))
 db.run(['node',str(repo/'scripts/ci/onboarding_start_provider_probe.mjs')],work,environment=provider)
 metadata['result']='PASS'
except BaseException as error:
 metadata['result']='FAIL';metadata['error']=str(error);raise
finally:
 for s in reservations:s.close()
 if started:db.run(['supabase','stop','--project-id',project,'--no-backup'],work,environment=env)
 shutil.rmtree(work)
 owned={}
 for kind,command in [('containers',['docker','ps','-a','--format','{{.Names}}']),('networks',['docker','network','ls','--format','{{.Name}}']),('volumes',['docker','volume','ls','--format','{{.Name}}'])]:
  result=subprocess.check_output(command,env=env,text=True);owned[kind]=[v for v in result.splitlines() if v.endswith('_'+project) or v==project]
 metadata['cleanup']={'directory_absent':not work.exists(),'remaining_owned_resources':owned};metadata['inputs_unchanged']=freeze==fingerprints();(proof/'focused-project-result.json').write_text(json.dumps(metadata,indent=2)+'\n');(proof/'focused-inputs-after.json').write_text(json.dumps(fingerprints(),indent=2)+'\n');print(json.dumps(metadata),flush=True)
 assert metadata['inputs_unchanged'];assert not any(owned.values()) and not work.exists()
