SQL note append handoff for #1363

Candidate: 9ee0bdfc29f900bc341346ddf94a26650dbb07ca, based on 44f580e9a4f6f0bfb3655a80ae0a9888b80c65a9. Exactly three shipped SQL files, 566 added lines; worktree clean. No push, publication, remote database access or existing local database operation was performed. This is direct authenticated-role SQL verification, not native browser execution or independent acceptance.

The new append_onboarding_step_note(uuid,uuid,text) function returns {id,notes}. It locks the selected progress row, rechecks Operate and parent Person scope after a wait, and appends original text with server auth.uid() and UTC millisecond-Z time to the latest saved array. It keeps all original note attributes and saved work. Terminal/inactive/completed rows retain their current note admission. Non-array saved notes fail closed with 22023; missing/invisible targets use P0002 and denied operation uses 42501. Unexpected write failures roll back. Invoker/volatile/empty-search-path attributes and no PUBLIC/anon/service_role grants are checked against actual database metadata. A schema reload notification commits with the function. Existing rows and policies are unchanged.

Migration SHA256: cac714d4f4f95af2209d0d85a70277121a77f4b11646bb9565e9add9b7635c35.
The timestamp was absent in the local origin/main and base trees before commit; both had 160 migrations ending 20261001000200. No network fetch was performed.

| Run | Disposable project | API / DB | Replay and result |
| --- | --- | --- | --- |
| Focused | t2t-note-focused-s7q9sr12 | 62786 / 62075 | 161 migrations; behavior/scope/rollback 35 + concurrency 26 = 61 assertions PASS |
| Full fresh SQL | t2t-note-fresh-2zntqutz | 60856 / 64593 | 161 migrations; all 52 SQL files / 1,374 assertions PASS |
| Populated upgrade | t2t-note-upgrade-8z06vqhn | 62578 / 62010 | Old 160 migrations, 18 populated rows, then only the held new migration; upgrade 10 + same 61 = 71 assertions PASS |

Range: 20260413001158_remote_schema.sql through 20261002000100_atomic_onboarding_note_append.sql. CLI 2.101.0; actual SHOW server_version result 17.6. All configured ports, exact temporary directories and cleanup commands are recorded in the corresponding logs/receipts. Seed loading was disabled with empty sql_paths in every copied project. The lifecycle script restricts Docker to a local Unix socket, reserves unused 58000–64999 ports, and never copies a linked-project reference. It applies only the existing disposable-stack supautils hint workaround; role/grant/RLS/error expectations stay intact. CLI reports an available update; the installed version was not changed.

Every passing run has all 246 copied SQL input hashes unchanged and matching the committed candidate. All project-specific containers, volumes and networks were absent after exact-project supabase stop --no-backup; each disposable directory was removed. Full fresh and upgrade share the same recorded proof script and fixture hashes. The full fresh receipt starts at base HEAD because the exact final SQL working-tree bytes were committed while the copied run was active; all 246 hashes were independently compared with git blobs at 9ee0bdfc afterwards. No shipped SQL bytes changed during either final run.

The populated upgrade inserted six parents (active, completed, cancelled and foreign), eight progress rows (legacy note attributes, work/stages, inactive history and malformed notes), and four People. The actual before/after comparison retained every field of all 18 rows when the new migration was applied. Denied View/other-Group calls preserved these rows; an allowed scoped append to completed inactive history retained the old note and all work fields. The function was proven absent before the held migration. The upgrade contract ran through the real pgTAP runner, so failed assertions would fail the command.

Reproduce from this worktree with:
python3 .verification/tmp/note-sql/note_sql_validation.py focused
python3 .verification/tmp/note-sql/note_sql_validation.py fresh
python3 .verification/tmp/note-sql/note_sql_validation.py upgrade

Each invocation creates and disposes its own project sequentially. The full fresh command runs the repository's unchanged npm run db:test command against the copied project. This is the complete retained SQL contract suite; the separate existing three migration regression files and SDK provider probes in scripts/ci/database.py were not run by this scoped script and remain integration/CI evidence.

Retained failures and corrections:
- focused-attempt1: metadata record comparison had mixed catalog/default collation; three assertions passed before the pgTAP comparison error. The metadata check now uses independently specified scalar predicates.
- focused-attempt2: behavior 33 PASS; concurrency 21 assertions passed before an extra two-appends-in-one-explicit-SQL-transaction interaction encountered a real deadlock with reconciliation.
- focused-attempt3: moving the test session time zone after capturing JSON snapshots changed timestamp renderings, causing four comparison failures out of 35. No stored row values changed. The test now sets its non-UTC session before both baseline and later captures; the generated note timestamps must still be current UTC.
All three failed projects have unchanged SQL inputs and complete exact-project cleanup in their receipts. All nine attemptN SQL source snapshots match their respective recorded input SHA256 values exactly. Earlier files reconstructed from the subsequent copy and known edits were accepted only after that exact hash check.

The two-call failure is a retained limitation, not passing evidence. PostgreSQL rechecks a foreign key when a tuple was written by the same transaction, even if keys are unchanged; its key-share request can conflict with reconciliation's parent-first lock. See the primary PostgreSQL 17 source, RI_FKey_fk_upd_check_required:
https://raw.githubusercontent.com/postgres/postgres/REL_17_STABLE/src/backend/utils/adt/ri_triggers.c
The supported interaction proof performs one append RPC on an unchanged held step while reconciliation holds parent and waits for progress. It succeeds without an explicit parent lock and reconciliation preserves the committed note/work. Multiple append calls batched in one explicit SQL transaction, arbitrary direct writers and other mutation overlaps are not proven. No constraints or shared policies were altered to conceal this boundary.

handoff.json contains exact source hashes, project/port/range/count/disposal metadata. Each mode has a .log and -receipt.json. upgrade-before.sql, upgrade-after.sql and note_sql_validation.py are the actual guarded upgrade fixtures/runner. Failed attempts preserve their source, logs and receipts. The shipped source is frozen; integration/browser/full application CI and Robert's manual migration application remain with the coordinator.
