import json, os, subprocess, sys
from pathlib import Path
run=os.environ.get('D18_RUN','d18-settings-baseline')
root=Path('.verification/evidence/verify-trooptotask')/run
root.mkdir(parents=True,exist_ok=True)
env=dict(os.environ); env['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+env['PATH']
def call(name,kind,*args):
    cmd=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1'] if kind=='helper' else ['npm','run','--silent','verify:app','--']
    result=subprocess.run(cmd+list(args),capture_output=True,text=True,env=env)
    (root/(name+'.json')).write_text(result.stdout)
    if result.returncode: raise RuntimeError((result.stderr+result.stdout)[-1600:])
    return json.loads(result.stdout)
def helper(name,*args): return call(name,'helper',*args)
def tool(name,operation,**args): return call(name,'tool','tool',operation,json.dumps(args))
def snap(name,page):
    tool(name,'take_snapshot',pageId=page,filePath=str(root/(name+'.txt')))
    return (root/(name+'.txt')).read_text()
if __name__=='__main__':
    kind,name,*args=sys.argv[1:]
    if kind=='snap': print(snap(name,int(args[0])))
    elif kind=='helper': print(json.dumps(helper(name,*args),indent=2))
    else: print(json.dumps(tool(name,args[0],**json.loads(args[1])),indent=2))
