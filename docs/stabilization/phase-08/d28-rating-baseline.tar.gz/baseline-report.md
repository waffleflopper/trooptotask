# D28 Rating Scheme unchanged baseline and contract sketch

Status is PASS for the selected unchanged baseline, with explicit retained and unrun paths below. This is not final cutover acceptance. There are no tracked application, helper or recipe edits. `git status --short` is empty. The owned worker has been disposed.

The exclusive checkout is `/home/waffleflops/.cache/t2t-1376-rating-owner`, branch `stabilization/1376-rating-owner`. Tested revision is `51e4a9eb78ac4541b1a323dfbceeb9f3f36523cc`. Candidate `4291aca5871f0d0a9eaf313f5d670658826fa68af2a2ff91f57b1ced6792a92b` binds 5,021 inputs. Owned worker 1 launched and both doctors passed at `http://127.0.0.1:35947`, session `be849aba-1339-4e46-aeb8-e9db1824479f`, Chromium `152.0.7977.82`, Node `24.21.0`, npm `11.19.0`. Seed tag is `a8f6b182`. Fixture/browser date stayed October 5, 2026 in America/Anchorage; final capture is `2026-10-06T02:48:59.601Z`, local 18:48:59. No date expectation crossed local midnight.

Artifacts are under `/home/waffleflops/.cache/t2t-1376-rating-owner/.verification/evidence/verify-trooptotask/d28-rating-baseline/`. All filenames below are relative to that directory. `inventory.json` binds the expanded payload set; `input-manifest-start.json`, `input-manifest-final.json` and `input-comparison.json` bind unchanged candidate inputs. The launcher, fixture and native actions are real run captures, not reconstructed tool transcripts. There is one saved screenshot of failed edit recovery, native before/action/reloaded accessibility captures, actual downloaded workbooks, synthetic HTTP responses and separate provider readbacks. A screenshot was not captured for every action; those paths are supported by their actual native snapshots/request/readback artifacts.

Throughput checkpoint is n/a for source investigation. Native baseline CRUD touched only the owned disposable synthetic fixture under the parent's authorization. No remote or existing local database, provider-admin API, integrated browser or browser substitute was used.

## Complete proposed owned shape

The coordinator accepted the following narrow shape provisionally. Implementation remains gated on coordinator inspection of this report and captures. Context property is `ratingScheme`; factory is `createSupabaseRatingSchemePersistence(client, orgId)` and captures the ordinary authenticated client and admitted Organization. It fixes table, projections and query construction privately.

```ts
interface SavedRatingSchemeEntry extends RatingSchemeEntry {
  readonly organization_id: string;
  readonly created_at: string;
  readonly updated_at: string;
}

interface RatingSchemeCreateValues {
  ratedPersonId: string;
  evalType: 'OER' | 'NCOER' | 'WOER';
  ratingPeriodStart: string;
  ratingPeriodEnd: string;
  status: 'active' | 'completed' | 'change-of-rater';
  raterPersonId?: string | null;
  raterName?: string | null;
  seniorRaterPersonId?: string | null;
  seniorRaterName?: string | null;
  intermediateRaterPersonId?: string | null;
  intermediateRaterName?: string | null;
  reviewerPersonId?: string | null;
  reviewerName?: string | null;
  notes?: string | null;
  reportType?: string | null;
  workflowStatus?: string | null;
}

type RatingSchemePatchValues = Partial<RatingSchemeCreateValues>;

interface RatingSchemeWriteReference {
  readonly ratedPersonId: string | null;
  readonly raterPersonId: string | null;
  readonly seniorRaterPersonId: string | null;
  readonly intermediateRaterPersonId: string | null;
  readonly reviewerPersonId: string | null;
}

interface RatingSchemeReadinessEntry {
  readonly status: RatingSchemeEntry['status'];
  readonly raterPersonId: string | null;
  readonly raterName: string | null;
  readonly seniorRaterPersonId: string | null;
  readonly seniorRaterName: string | null;
}

interface RatingSchemePersistence {
  listWorkspace(): Promise<SavedRatingSchemeEntry[]>;
  findWriteReference(id: string): Promise<RatingSchemeWriteReference | null>;
  listPersonReadiness(personnelId: string): Promise<RatingSchemeReadinessEntry[]>;
  countEntries(): Promise<number>;
  create(values: RatingSchemeCreateValues): Promise<SavedRatingSchemeEntry>;
  update(id: string, values: RatingSchemePatchValues): Promise<SavedRatingSchemeEntry>;
  delete(id: string): Promise<void>;
}
```

The existing domain entry's 17 fields plus three explicit provider metadata fields are the complete supported JSON output. Preserve the three snake-case metadata spellings and exact timestamp strings. The native POST response has exactly those 20 keys and agrees with the persisted row after mapped-name comparison. Required metadata is supported behavior in `ratingSchemeEntryEntity.server.test.ts`, not an arbitrary unknown-row extension. A fixed 20-column projection and explicit map exclude future unrelated columns. No index signature, raw row/client return, table argument or query options survive in owner ports.

`reportType` and `workflowStatus` input values remain nullable strings because the unchanged entity validator accepts them beyond presentation enums. Preserve current validation rather than adding a narrower enum check. Patch excludes ID, Organization and timestamps and distinguishes omitted values from null. Current `coerceEmptyStrings` loops every mapped value, including required strings. Preserve the validated empty-string to provider-null behavior explicitly without a generic bag cast or new validation. Optional create defaults remain null.

Workspace pages retain `rating_period_end` then `id` ascending and complete pagination. Readiness retains end/id descending and the newest non-completed/missing-rater rules. Reference lookup retains `.single()` with PGRST116 mapping to null. Count retains select `id`, range 0..0, estimated count and null-to-zero. Absent/empty-lane decisions remain in policy/read operations. Rating has no generic `scopeRules` entry; ordinary SQL RLS and feature/Person policy remain the current authority. Do not introduce a new Personnel SELECT waterfall or privileged Rating reader.

All four evaluator-reference guards stay with operations and the Personnel-owned roster. Existing same-Organization archived, cross-Group/unassigned and repeated/case-insensitive references remain valid. Unchanged historical foreign links remain untouched on unrelated updates. Ordinary delete preserves error propagation and idempotent approved-deletion retry. It does not start checking affected row counts or claiming an atomic approval operation.

Actual generic dependencies are `ratingSchemeReadPorts`, `ratingSchemeEntryPorts`, entry operations, workspace query, Personnel readiness, read count and approved Rating deletion. Reverse consumers include request contexts, Personnel detail, Getting Started and deletion review. `approvedRatingSchemeDeletion`'s authenticated `requestStore.delete` must move in the same cutover wave. Root owns public contracts/exports, shared contexts/fakes, delivery and reverse wiring, manifest and tracker/evidence publication. Existing Dashboard due and Organization raw export stay with their already accepted narrow owners.

Boundary Discipline led to fixed domain results. Model the Domain led to saved-entry/reference/readiness values. Migrate Callers Then Delete Legacy APIs includes both reverse generic consumers in the same later wave. Prove It Works led to native JSON/provider comparison. The how playbook routed this phase through a source investigation and an unchanged baseline. No Comments introduces no new-comment review obligation yet because this phase changes no application code; independent comment review is not self-certified.

## Fresh observed coverage

Expectations were selected from the retained D16 contract, actual current operation/schema/policy callers and the full Evals feature recipe before driving. Core data movement, CRUD serialization, ordinary scope, count/readiness and consumed approved deletion are directly affected by the later owner port. Date/filter/presentation paths are included as practical native witnesses. Unchanged due/export orchestration, broader switching and SQL history are qualified separately below.

| Path and actor | Expected and observed result | Actual artifacts |
| --- | --- | --- |
| Rating-only operator workspace | Personnel absent; native Evals loads active 7 of9, overdue2, 30-day4 and60-day1. | `actor-operate.json`, `operate-workspace.txt` |
| Required fields | Empty native Save reports missing rated Person/evaluators/dates and keeps draft. | `add-open.json`, `required-feedback.json` |
| Native create/reload, operator | Seeded Officer suggests OER. Annual start2026-10-05 fills thru2027-10-04. External rater/senior and optional intermediate persist. POST200 creates ID `3b8a45ac-77c3-4974-ab54-9b20957c34b4`; exact20-key response agrees with provider; reload retains entry. | `annual-visible-fields.json`, `create-save.json`, `create-request.network-request`, `create-response.network-response`, `native-created-row.json`, `create-wire-provider-comparison.json`, `create-reloaded.txt` |
| Edit503/retry/null clearing | One pre-dispatch PUT503 preserves exact20-field row and open notes/optional-clear draft. Restored native PUT200 keeps ID/creation timestamp, changes updated timestamp and clears both intermediate fields to null. Reload/reopen retains values. | `edit-draft.json`, `edit-failure-state.json`, `edit-failed.json`, `edit-failed-row.json`, `edit-failed.png`, `edit-retry-state.json`, `edit-retry-row.json`, `edit-reloaded.txt`, `edit-reopened.json` |
| Cancel | Native edited notes draft is cancelled; provider row equals successful edit exactly. | `cancel-draft.json`, `cancel-action.json`, `cancel-row.json` |
| Dedicated view | Loaded records with no Add/Edit; valid ordinary POST/PUT/DELETE return403, unchanged provider rows. Getting Started200 count10 while first UI-created row existed. | `view-loaded.txt`, `view-http-denials-count-complete.json`, `rows-A-after-denials.json` |
| Actual filtered Evals XLSX | Native OER/active and Table show2 of10. Captured filename is `rating-scheme-2026-10-06.xlsx`; workbook has15 retained columns and those2 actual rows. The refreshed download after reload contains saved null clearing, notes, evaluator names and actual period/due values. | `view-oer-table.json`, `rating-oer-active-reloaded.xlsx`, `reloaded-export-save.json`, `reloaded-export-workbook.json`, `reloaded-export-click.json` |
| Alpha scope | Native6 of8 while created witness existed, due2/2/1, archived entry has unavailable active-roster label. Native rated-Person lookup has exactly four active Alpha People and excludes Bravo/unassigned/archived/foreign. POST Bravo/unassigned403, PUT/DELETE404. Current Getting Started200 count7 after witnesses removed. | `scoped-loaded.txt`, `scoped-lookup-opened.json`, `scoped-lookup-options.json`, `scoped-http-denials.json`, `scoped-count.json` |
| Empty Group scope | Native0 of0, all due buckets0, rated-Person lookup0 choices. Valid POST403, PUT/DELETE404; count0. | `empty-loaded.txt`, `empty-lookup-opened.json`, `empty-lookup-options.json`, `empty-http-denials-count.json` |
| Foreign Organization | Native B has its one foreign entry. B actor's valid A POST/PUT/DELETE404 Organization not found; A operator's foreign-entry PUT/DELETE404. | `foreign-B-loaded.txt`, `foreign-A-http-denials.json`, `operator-foreign-evaluator-denials.json` |
| All evaluator slots | Foreign Person, missing valid UUID and malformed ID each receive generic400 for each of four slots, with no hidden-name response or mutation. | `operator-foreign-evaluator-denials.json`, `rows-A-after-denials.json`, `rows-B-after-denials.json` |
| Operator Delete503 | Pre-dispatch DELETE503 leaves exact target and open confirmation/editor, with visible failure. | `delete-failed.json`, `delete-failed-row.json`, `delete-failure-state.json` |
| Request submission503/retry | Rating DELETE202 followed by synthetic request POST503 leaves target exact and requests0, keeps confirmation/editor. Restored native retry DELETE202/request201 leaves target exact and creates one pending request. | `request-failed.json`, `request-failed-row.json`, `request-failed-requests.json`, `request-failure-state.json`, `request-retry-action.json`, `request-retry-state.json`, `request-native-network-list.json`, `request-pending-row.json`, `request-pending-source.json` |
| Consumed owner Approvals | Owner enters actual Settings Approvals. Review POST503 preserves pending article/request/source. Native retry200 removes exact source and marks request approved with reviewer/time; reload0 pending and Evals returns7 of9. | `owner-approvals-before.txt`, `approval-failed-action.json`, `approval-failure-state.json`, `approval-failed-request.json`, `approval-failed-source.json`, `approval-retry-action.json`, `approval-retry-state.json`, `approval-approved-request.json`, `approval-deleted-source.json`, `approvals-approved-reloaded.txt`, `operator-after-deletions-reloaded.txt` |
| Owner direct deletion | A separate native owner-created OER witness `b7222cdb-faf5-48c5-8598-6f7695a48123` saves200 and Delete200 removes it; no request row is created, reload restores7 of9. | `direct-created-action.json`, `direct-created-rows.json`, `direct-delete-confirmation.json`, `direct-deleted-action.json`, `direct-deleted-state.json`, `direct-deleted-row.json`, `direct-deleted-requests.json`, `direct-delete-reloaded.txt` |
| Personnel reverse readiness | Actual native owner Personnel Officer details show Aligned and assigned rater/senior. Personnel-only manager opens the same Person and settles Unavailable. | `owner-personnel-open.json`, `owner-readiness-opened.json`, `owner-personnel-readiness.txt`, `manager-personnel-roster.txt`, `manager-readiness-opened.json`, `manager-personnel-readiness.txt` |
| Absent Rating manager | Direct Evals navigation settles Access Restricted with no editor or busy shell. Valid POST/PUT/DELETE403; Getting Started200 count0. | `manager-evals-restricted.txt`, `manager-http-denials-count.json` |
| Exact persisted effects/count | Every original A9/B1 row matches all20 fields after all denial/create/edit/delete/approval activity. Operator current count9; Alpha7, empty0 and manager0. Both UI-created entries are absent. | `rows-A-before.json`, `rows-B-before.json`, `rows-A-after-native-deletions.json`, `rows-B-after-native-deletions.json`, `exact-sentinel-comparison.json`, `native-comparisons.json`, `operator-count-final.json`, `scoped-count.json` |

The approval request is `5815d6a1-dbd3-4a69-9d3b-5a3575fa69d7`, pending from `2026-10-06T02:35:50.720754+00:00`, approved by synthetic owner `18fb0ca9-c496-4f5c-9ffa-48a80ff71c1a` at `2026-10-06T02:40:22.12+00:00`. Native approval proves the Rating source effect and review readback; it does not establish D18 transactionality. Its approved request history remains legitimate disposable history until worker destruction.

`rating-oer-active.xlsx` is a retained earlier view-page download before the separate operator edit. It contains the earlier client-loaded optional intermediate value. It is not mislabelled as latest persisted proof; `rating-oer-active-reloaded.xlsx` is the refreshed comparison. The initial `view-http-denials.json` lacks submitted-payload capture; `view-http-denials-count-complete.json` supersedes it. Native portal options omitted some accessibility labels, so read-only rendered DOM inspection plus native keyboard selection was used. No handlers or DOM state were mutated. A native network body tool appends `.network-request`/`.network-response`; one attempted `.json` read failed and was corrected. Failed helper/read attempts earn no app-behavior credit.

Synthetic503 observations establish browser failure/recovery, not provider rollback or an actual provider outage. Authenticated HTTP denials and privileged bounded fixture readback are identified separately from native user actions and SQL enforcement.

## Lower checks and retained applicability

Focused unchanged Vitest passes7 files/70 tests in `focused-baseline-tests.log`. Executed files are entry entity, entry operations, workspace query, Personnel readiness, read count, approved Rating deletion and Evals export. These cover supported metadata, policy/all-slot guards and unchanged historical references, null values, complete1001-row stable paging/later-page error, count authorization/empty/error, readiness newest/missing branches, approved-effect error/retry and export values. This is neither full CI nor new adapter acceptance. No tests were skipped or weakened. Production `verify:app` launch built this unchanged candidate; no concurrent full application checks were run.

`d16-applicability-byte-comparison.json` compares actual current bytes against tested D16 revocation revision `641e29d9c62c62b894e417fe57112f3ff33b0cdd`. Nine relevant seams are byte-identical: Rating due source, domain types, entity, entry operations, readiness, store, Entry Modal, workspace hydration and Personnel Rating roster. The D16 receipt `docs/stabilization/phase-08/d16-rating-ownership.md` records original actual archives and their tested revisions/hashes. Prior native OER/NCOER/WOER suggestions, optional/workflow/calendar-date behavior and busy guards, Dashboard due/projection, ordinary A/B switching, and rule tests may retain scoped credit for those unchanged seams. Their current provider replacement still requires fresh owner SDK/query/mapping and integrated native proof. No wholesale old candidate or archive relabelling is proposed.

D16 Dashboard follow-up observed Organization2/4, Alpha2/2 and empty0 without Personnel. `ratingSchemeDue.server.ts` is byte-identical and already owned; this baseline does not claim a fresh Dashboard visit or due-payload capture. D16 visible A/B switching exists, but its attempted held-mutation switch was blocked by the busy modal. Do not claim delayed cross-Organization browser proof. Retained unchanged store/hydration tests cover late response rules separately.

Current workspace query, read/entry ports, read count/raw export and approved-effect binding have changed since D16, so old evidence is not enough for their changed integration. The fresh native count/readiness/consumed approved deletion above covers current behavior, while later owner provider obligations remain open. Organization raw20-field JSON/readable12-column Excel is already accepted under its Data Export/Rating source owners. It is not freshly downloaded in this run. Native create20-field wire comparison establishes current Rating endpoint serialization, not Organization backup orchestration.

Actual Git comparison finds no changes since D16 in `supabase/tests/rating_scheme_lane_scope.sql`, `rating_scheme_evaluator_integrity.sql` or Rating-named migration provenance. Subsequent additive migrations concern other domains. Retained SQL scope/evaluator/history checks remain database provenance; no fresh SQL suite or live historical Person-deletion rollback was executed here. The proposed cutover has demonstrated no SQL/migration need. Do not infer SQL enforcement solely from HTTP403/400 results.

D16 revocation proof is precise. After admitted admin downgrade, the same ordinary client DELETE returned204 and removed zero rows under live RLS; coordinator request PATCH406 then rejected approval. Restoring exact membership enabled same-client DELETE204/PATCH200 and persisted approval. It establishes ordinary RLS and coordinator failure, neither delete-level zero-row detection nor atomicity. Current generic DELETE still uses the ordinary client with Organization/id predicates and no selected row count. The future factory must preserve that authority and idempotence; lower ordinary SDK/revocation integration must be reviewed again for the changed adapter.

Unrun fresh paths include dedicated NCO/WOER creation, report/workflow combinations, all-status/Alpha workbooks, successful same-Organization archived/cross-Group/unassigned/repeated/case evaluator writes, unchanged historical foreign resubmission, real provider integrity/Person-delete rollback, delayed-save/delete/request busy guards, delayed Organization switch, and repeat already-pending submission. They are not silently dropped after failures. Applicable existing native/rule/database proof stays tied to original revisions; changed owner mapping/query/error paths must receive independent acceptance and the appropriate fresh final coverage. No application regression, blocked prerequisite or unresolved browser failure was found in this selected baseline.

## Lifecycle and handoff

`final-network-operator.json` and `final-network-owner.json` report armed false, no held responses or calls; feedback is disarmed and viewer export is not captured after restoration. Native-created source rows were removed through owner UI/Approvals before seed cleanup. All original rows matched before cleanup. `seed-cleanup.json` passes; `rows-A-after-cleanup.json`/`rows-B-after-cleanup.json` each contain zero Rating rows. `doctor-final.json` passes the original candidate. All5,021 input byte/size/path hashes match exactly. `owned-cleanup.json` is PASS/cleaned and durable files remain outside the disposed worker.

`sanitizer-scan.json` scans text payloads for JWTs, assigned credential fields, token query values and Authorization bearer values without printing matched values. It reports zero findings. Captures use redacted native network headers, safe synthetic mutation bodies, named helper outputs and readonly rendered observations. No raw auth body, credential store, token-bearing URL or secret value is retained. Synthetic example.test actor emails and fixture UUIDs are intended public evidence.

Root should inspect the actual expanded captures and source applicability before authorizing the isolated implementation. Accepted public Saved DTO/create/patch/reference/readiness/interface scaffolding can be supplied now that this frozen run is disposed. The later adapter/caller integration needs complete current-candidate checks, independent artifact/source acceptance and PR gates before D28 closure. This report changes neither those gates nor root's exclusive publication/merge ownership.
