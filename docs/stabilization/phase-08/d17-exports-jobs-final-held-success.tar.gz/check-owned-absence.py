import json,pathlib,datetime,subprocess,os,socket,urllib.parse
p=pathlib.Path(__file__).parent
identity=json.loads((p/'owned-public-identity-final-before-cleanup.json').read_text())
assert (p/'docker-local-context.stdout').read_text().strip()==identity['provider']['docker_host']=='unix:///var/run/docker.sock'
processes={k:{'pid':v['pid'],'originalStart':v['start'],'absent':not pathlib.Path(f"/proc/{v['pid']}").exists()}for k,v in identity['processes'].items()}
assert all(v['absent'] for v in processes.values())
ports=[urllib.parse.urlparse(identity['origin']).port,*identity['provider']['ports'].values()];checks=[]
for port in ports:
 with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
  sock.bind(('127.0.0.1',port));checks.append({'port':port,'bindable':True})
env=os.environ.copy()
for k in ['DOCKER_CONTEXT','DOCKER_HOST','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(k,None)
cmd=['docker','--host',identity['provider']['docker_host'],'ps','--all','--filter','label=com.supabase.cli.project='+identity['provider']['project'],'--format','{{.ID}} {{.Names}}']
r=subprocess.run(cmd,env=env,capture_output=True,text=True);assert r.returncode==0,r.stderr;assert not r.stdout.strip(),r.stdout
for id in identity['provider']['container_ids']:
 r2=subprocess.run(['docker','--host',identity['provider']['docker_host'],'ps','--all','--filter','id='+id,'--format','{{.ID}}'],env=env,capture_output=True,text=True);assert r2.returncode==0 and not r2.stdout.strip()
assert not pathlib.Path(identity['stateDirectory']).exists()
out={'passed':True,'session':identity['id'],'candidate':identity['candidate'],'revision':'080b4abc59ee221a9c76f21ada104138fc7f1af0','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processes':processes,'ports':checks,'dockerHost':identity['provider']['docker_host'],'project':identity['provider']['project'],'exactOwnedContainerIdsAbsent':len(identity['provider']['container_ids']),'projectCurrentOrStoppedContainerCount':0,'dockerAbsenceCommand':cmd,'privateWorkerDirectoryAbsent':True}
(p/'owned-absence-after-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
