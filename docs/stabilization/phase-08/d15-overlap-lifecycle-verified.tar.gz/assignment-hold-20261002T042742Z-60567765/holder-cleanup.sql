SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object('terminated', COALESCE(json_agg(
 json_build_object('pid', pid, 'termination_requested', pg_terminate_backend(pid, 3000))), '[]'::json))
FROM pg_stat_activity WHERE pid = 865 AND backend_start = '2026-10-02 04:27:43.544658+00'::timestamptz AND application_name = 't2t-d15-overlap-50ccb1cf30f14ab88a60ad01061e3b26' AND usename = 'supabase_admin' AND datname = 'postgres';
