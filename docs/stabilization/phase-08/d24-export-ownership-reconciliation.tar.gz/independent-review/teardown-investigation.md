# D24 full-suite teardown investigation

Keep the parent's two-line test-only repair in `src/features/onboarding/components/OnboardingInteraction.svelte.test.ts:99-101`. Make `afterEach` asynchronous and, immediately after `cleanup()`, await `waitFor(() => expect(document.body.style.overflow).not.toBe('hidden'))`. Leave the remaining mock, clock and store resets in their existing order. I reviewed that exact delta and found no weakened assertion, skipped test, suppression or application change.

## Root cause

Both original full-suite logs show all 679 files and 6,643 tests passing, followed by the same uncaught `ReferenceError: document is not defined`. The stack identifies Bits UI `resetBodyStyle`, its delayed cleanup callback and the Onboarding interaction test environment. Passing assertion counts therefore did not establish a passing gate.

The last test opens the actual detail sheet at line 569, exercises denied completion and retry, and ends without closing that sheet. Testing Library `cleanup()` synchronously unmounts the components. Its Svelte 5 mount helper calls `flushSync(() => unmount(component))` at `node_modules/@testing-library/svelte-core/src/mount.js:23-25`. Unmounting the final lock calls Bits UI `scheduleCleanupIfNoNewLocks` at `node_modules/bits-ui/dist/internal/body-scroll-lock.svelte.js:172-186`. Its default delay is 24 ms at lines 75-76. The callback later reads global `document.body` at lines 31-38 to restore the body style.

Vitest's ordinary Happy DOM environment aliases `window` to the worker global and preserves pre-existing Node timers. See `node_modules/vitest/dist/chunks/index.DC7d2Pf8.js:242-247`, `274-284` and `363-395`. Consequently, Bits UI's `window.setTimeout` is a native Node timeout, outside Happy DOM's task manager. Environment teardown aborts Happy DOM work and removes the global DOM properties before that outstanding native callback necessarily runs. The late timer then reads a deleted global `document`.

The existing audited dependency patches do not patch this body-scroll module. They address different timer/focus/presence paths. There is no need to extend those application dependency patches to repair this test lifecycle.

## Why the predicate is sufficient here

Bits UI's `scroll-lock.svelte` constructs `BodyScrollLock` only inside `if (preventScroll)`. A false lock is not created by this path. The application dialog wrapper supplies the child snippet, whose Bits UI content mounts a lock only while open. The sheet uses the default content branch with no `forceMount`. Closed, never-opened overlays do not create a pending false-lock cleanup.

Every interaction that opens an overlay awaits the event or resulting UI. Opening applies `overflow = 'hidden'`; neither Testing Library unmount nor our tests remove that style directly. After cleanup destroys all locks, an outstanding restore therefore leaves `overflow` hidden until `resetBodyStyle` runs. Tests that never opened an overlay can satisfy the predicate immediately because they created no such cleanup.

`resetBodyStyle` restores overflow and pointer-events in the same synchronous `document.body.setAttribute` call at line 34. Adding a pointer-events predicate would not establish an independent completion condition. The scrollbar custom property is removed by the next synchronous statement. JavaScript cannot run the `waitFor` assertion between these statements. The wait consequently permits the actual cleanup to finish while `document` still exists.

The test file already freezes only `Date`, through `vi.useFakeTimers({ toFake: ['Date'] })`. Timeout callbacks remain native. The repair neither advances application time nor cancels work.

## Alternatives

| Choice | Finding |
| --- | --- |
| Await the body unlock after cleanup | Recommended. Observe the actual cleanup result before environment teardown. Reuse the existing `waitFor` import. |
| Await `window.happyDOM.waitUntilComplete()` alone | Insufficient. The API is real, but this timer is not tracked by it. |
| Replace the file's clocks with fully fake timers | Larger change. Existing interaction waits would need reconsideration, and previously scheduled native callbacks are not adopted when fake timers begin later. |
| Sleep for a chosen duration or cancel callbacks | Avoid. A delay would replace completion with a timing assumption. Cancellation would skip the real restore. |

The local API definition is `node_modules/happy-dom/lib/window/DetachedWindowAPI.d.ts:33`, with implementation at `DetachedWindowAPI.js:35-36`. It delegates to the frame task manager. That manager waits only for its registered tasks, timers and immediates at `node_modules/happy-dom/lib/async-task-manager/AsyncTaskManager.js:205-233`. Happy DOM's own timer wrapper registers timers at `node_modules/happy-dom/lib/window/BrowserWindow.js:1957-1979`. The native timer bypasses that wrapper.

## Evidence and limits

Installed versions inspected are Vitest 4.1.8, Happy DOM 20.9.0, Bits UI 2.18.1, Testing Library Svelte 5.3.1 and Svelte Core 1.0.0.

I ran a small in-memory probe against Vitest's installed public `builtinEnvironments` API. It confirms `window.setTimeout ===` the native Node timer, schedules the same known 24 ms restore, and observes Happy DOM's waiting API return with the native cleanup still pending. It then awaits the callback's actual completion before invoking environment teardown. The executable is `wait-api-probe.mjs`; its output is `wait-api-probe.log`. Run it from the checkout with `node /home/waffleflops/.cache/t2t-d24-comment-review/wait-api-probe.mjs`. The probe models the timer/teardown seam and does not claim to execute the Svelte component.

I inspected the parent's completed verification logs under `.verification/evidence/verify-trooptotask/d24-export-ownership-reconciliation/`. `onboarding-teardown-fixed.log` records all 15 existing interaction tests passing. `full-test-final.log` records all 679 files and 6,643 tests passing, with no unhandled error section. The parent reported exit 0. These are artifact review of the parent's execution, not a second independent full-suite execution. The two failed full-suite logs remain available as the reproduction.

The reviewed test file SHA-256 is `25f3d959ca8473d01807eca048dc6030e41b180dad756c071cf06e0e4fe9afae`. Future changes that deliberately begin with a locked body style, manually clear the style, or mount nonstandard false locks would need a different completion signal. None exists in this file today. The repair adds up to the real cleanup and polling latency per affected test; it avoids a fixed sleep for every test.

No source, test, dependency, database or app service was changed by this investigation. Writes were limited to the external cache. The Fix Root Causes principle changed the recommendation from waiting on a library API to observing the native restore that actually fails. Prove It Works required the API probe and inspection of the repaired candidate's real logs.
