# Issue 1503 Mac transport HTTP/2 correction

The scratch adapter now admits this preview's exact HTTP/2 `:authority` without requiring a separate Host header. `check` and startup readiness also negotiate native, certificate-verified HTTP/2 alongside the existing Node fetch login check. No app, installed helper, recipe, fixture lever or production output changed. This agent launched no worker, provider, browser, preview or Serve mapping.

## Demonstrated defect and source boundary

Root reported that the completed v5 T3 HTTPS attempt returned 403, while its comparative curl requests returned HTTP/1.1 200 and HTTP/2 403 (`driver/raw/01-transport-h1-vs-h2.txt`). The prior middleware required `req.headers.host`; native Node HTTP/2 supplies `:authority` without that field. The existing fetch-only checkpoint did not exercise the failing protocol. Root confirmed goal/restoration, exact seed cleanup, adapter stop and ordinary worker cleanup before authorizing this correction. Those are root observations, not new agent-run service checks.

Installed source confirms the proper boundary:

- `node_modules/vite/dist/node/chunks/node.js:10639`: native HTTPS uses Node `http2.createSecureServer` with `allowHTTP1:true`.
- `node_modules/vite/dist/node/chunks/node.js:33911`: preview hooks execute before their returned post-hooks; the existing early middleware still surrounds SSR.
- `node_modules/@sveltejs/kit/src/exports/vite/preview/index.js:28` and `:199`: preview derives `https` from native TLS configuration and constructs the SSR request base with `:authority || host`.
- `node_modules/@sveltejs/kit/src/exports/node/index.js:122`: `getRequest` already maps HTTP/2 `:authority` into Fetch Host and removes pseudo-headers from the Fetch headers.
- `node_modules/@sveltejs/kit/src/runtime/server/respond.js:74`: ordinary Origin/CSRF validation remains in the native server path.

The adapter therefore validates native header fields without replacing Host, authority, scheme or Origin. The HTTP/2 probe uses Node's native client and checks the negotiated ALPN value, as documented by the [Node HTTP/2 API](https://nodejs.org/api/http2.html#http2sessionalpnprotocol); local Node 24 types also expose this property.

## Narrow correction

`cookieMiddleware` requires at least one authority field. Every present Host or `:authority` must be the exact expected string, including the public port. Thus consistent dual fields pass, while absent, conflicting, foreign, empty, array, URL/path/user-info/comma or whitespace variants fail before SSR, cookie translation or the session header. TLS remains mandatory. Every present Origin must exactly match the HTTPS origin. Namespaced incoming/outgoing cookie behavior, secure attributes, chunk values and deletion are unchanged.

`command.mjs` retains its existing five-second, certificate-verified fetch request to `/auth/login`, with redirects rejected and its body cancelled. In parallel it calls the native HTTP/2 probe, also with a five-second total deadline. The probe explicitly enables certificate validation, requires encrypted/authorized TLS and negotiated `h2`, requests the exact authority and login path, and requires a 2xx status plus this run's exact public session header. It closes the connection at response headers. No response body, cookie value, full headers, thrown message or TLS error detail is logged or retained. Safe failures identify protocol, TLS, status, session, close, connection or timeout failures.

Successful checkpoints add `externalLoginChecks: { http1Login: true, http2: { alpn: 'h2', certificateVerified: true, status: 200 } }` (the status records the actual successful response). Startup readiness uses the same pair of probes. The fetch check retains its existing Node HTTP/1 behavior; the separate HTTP/2 probe cannot pass through fallback. Doctor/source/output/adapter/process binding and exact-owned cleanup remain unchanged.

## Actual scratch checks

Node 24.21.0 was used. All commands completed with exit 0; results are preserved under `.verification/mac-preview-1503/`.

| Check                                                            | Result              | Receipt      |
| ---------------------------------------------------------------- | ------------------- | ------------ |
| `node --test transport.test.mjs`                                 | 18 passed, 0 failed | `tests.log`  |
| `node --check` on three runtime modules                          | All passed          | `syntax.log` |
| Focused ESLint on modules and test                               | Passed              | `eslint.log` |
| Explicit Prettier check of modules, test, README and this report | Passed              | `format.log` |
| `command.mjs help`                                               | Passed; no launch   | `help.log`   |

Five added tests prove authority-only and consistent dual-field admission with native form Origin/cookie behavior; hostile/missing/conflicting authority and non-TLS denial; verified native HTTP/2 success; rejection of fallback, unverified TLS, 3xx/403, foreign session and connection failure; and deterministic deadline cancellation. Fake in-memory requests and EventEmitter client/stream objects are used. No server, worker, fixture or browser is accessed by tests. Existing cookie, lifecycle, interpreter-transition and cleanup tests remain.

`validation-before-http2/` preserves the previous runtime/test/README bytes, manifest and scratch logs for digest `7d4293a8e3aa20ac3088bf02cd1326762cb63e66630283b7f91e34b09aa817c7`. Earlier `validation-initial/` and `validation-interpreter-capture/` records remain unchanged. Existing runtime receipts and prior root evidence were not edited. Current per-file hashes are in `source-sha256.json`; the new ordered three-module runtime digest is `aac7a76e5e1abcf14f9edc187cda8fe6869dc3f758a8aff67eafd757d97f84b0`.

## Readiness and limits

This correction has no live HTTP/2, Mac, TLS-cookie round trip, native login or chart acceptance evidence. Root must freeze its new chart/source candidate and driving inputs, launch/doctor a fresh owned normal worker, then use `start` and `check`. Both public login checks must pass before native T3 login and the chart proof. The same frozen source/output and original doctor/cleanup contract still apply. No rebuild, provider proxy, HTTP/1 forcing, certificate bypass, Origin rewrite or retry framework was introduced. No executable or documentation edits remain pending after this report.
