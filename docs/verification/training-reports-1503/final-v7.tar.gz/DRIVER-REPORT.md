# 1503 final chart v7 independent acceptance report

This is interpretation. The raw captures are in `.verification/evidence/verify-trooptotask/1503-final-chart-v7/`; see its `INDEX.md`. Do not declare 1503 complete from this report alone. Root still owns packaging, cleanup, integration and the PR.

## Binding

- Candidate `7159b96787d5d6d603762d3a54db05ed260b50fd849911e59ffee80c70cbc055`, revision `3c0b6f2a9cb4`, base `0fa29609`.
- Origin `http://127.0.0.1:42057`, worker 1, session `983bff0a-f8a3-44ad-92dc-7d9ea3f5839f`, Chromium 152.0.7977.82 (Arch Linux), owned private profile.
- `SOURCE.patch` sha256 `eab7bf70…92bd` and boundary seed sha256 `1fc8ad6f…4995` were re-hashed and match. `ReportForecastChart.svelte` sha256 is `706cd892…7b831`, the v6 value.
- Doctor PASS at start (`0001`), at a checkpoint before Sign Out, and at the end (`2570`), all on the same candidate.
- Driving ran 2026-10-04 from 00:07 to 01:55 AKDT. The report's asOf was 4 Oct throughout and the app clock was not touched. The 30-day final-bucket witness was still on day 30 (lapse 3 Nov = horizon end), so the original D3 state was reproduced.
- Browser authority: Robert's explicit "Use the owned verify:app browser". Only the native `verify:app` DevTools tools and the documented helper were used. There was one normal sign-in (`actor orgOwner training/reports`, page 2) and one native Sign Out. This proves the Linux synthetic-browser boundary only. It makes no Mac, external-HTTPS or T3-browser claim.

## Proof classes used

- **Native actions.** Settings goal fill/Save, Toggle theme, view listbox option, Duty role checkbox via keyboard Space, horizon radios, Retry, hot-spot cell click, Tab, Export Excel, Account menu → Sign Out, visible Organization Settings/Training/Reports/Policies links.
- **Native navigation.** `navigate_page` to URL-kept states (SSR loads) and `emulate` viewport/DPR. The sweeps use this rather than control clicks for each of the 684 cases.
- **Read-only measurement.** `evaluate_script` reading rendered SVG geometry, computed fonts, canvas font metrics, DOM state and focus.
- **Documented controls.** `network arm-hold/arm-fail/arm-observe/restore/state`, `export arm/state/save/restore`, `workbook`. These schedule client responses only. They are not real server or provider failures.
- **Privileged readback.** `rows organizations orgA|orgB`, `rows personnel_trainings`. This is separate from UI proof.
- **Storage restore.** One `evaluate_script` call `localStorage.removeItem('theme')` to put back the original absent key after the native theme toggles. This is the only storage write.
- **Source inspection** and **historical evidence** are named as such where used.

## Outcome 1. D4 resolved, D3 preserved, annotation legibility: PASS (with minor objections)

**Lever.** `driver/sweep.sh` + `driver/measure.js` + `driver/analyze.py`. Each case measures every annotation actor (start value, end value, goal label) against every plotted mark: all gridlines and the goal rule (stroke-edge gap), the spline (sampled every 0.5px), both dots, bars, bar counts, axis line, every other text, the band, the SVG box and the nearest clipping ancestor. Glyph ink comes from canvas `measureText` with the element's computed font, positioned at the real SVG glyph origin.

**Matrix.** There are 684 cases.
- Goals 85 and 95: both themes × 1440/1024/390 × nine states × 30/60/90/180.
- Goals 1 and 100: light full matrix, plus dark 1440/390 at 90 days.
- The nine states are ordinary org-wide, saved view, mixed view+dedicated role (74→61), Cliff fifty, final bucket, flat 100 (Medic+Required), near-end flat 85 (Rounding 11/13), at-goal 85→75 and Drop nine 85→76.

**Result.** There were zero problems in 684 cases (`measure/analysis-all.txt`).
- Start labels: minimum gap to any rule is 2.0px, to the line 7px, to the other dot 175px.
- End labels: minimum gap to any rule is 2.4px, to the line 12.4px, to its own dot 8.4px, to any other text 10.6px (bar count), to bars 22.6px.
- Goal label: always 13px right of the rule end; nearest dot 8px (end dot sitting on the goal); never clipped (≥19.6px slack at 390).
- No label extends outside the SVG vertically or past any clipping ancestor horizontally.
- Label drift from the default position is at most 11.7px. No case drifts more than 15px.

**D4 (goal 95, flat 100).** Fixed in all 24 width/theme/horizon combinations. The end label "100%" now sits 2.4px below the dashed goal-95 rule and 2.5px above the 90% gridline. Nothing crosses it. In the DPR2 crops (`png/hires/g95-{dark-390,light-1440}-flat100-90.png`, `zoom/z-g95-light-flat100.png`) the green label clearly separates from the green dashes and reads as belonging to the end dot directly above and right of it. v5 had the rule through the middle of the glyphs.

**D3 (goal 85, final 30-day bucket).** Preserved. The turn into the final bucket is unmasked. The end dot, "50%", the bar count "50" and the right-aligned caption "2 NOV – 3 NOV · 50 lapse · Final bucket fifty" are all separate at 1440/1024/390 in both themes (`zoom/montage-g85-light-final30.png`, `zoom/montage-g85-dark-1440.png`). The band's right edge meets the plot edge exactly (`rightVsPlot` 0). Screen-reader rows end "1 Nov|100%|0|No" and "3 Nov|50%|50|Yes", matching receipt expiry 2026-11-02 and lapse 2026-11-03.

**Gridline contact (not measured in v5).** Zero strikes. The rule-aware offset does what the v6 report predicted.

**Extreme goals.** Neither goal produced a collision.
- Goal 1 widens the domain to 0–100. The dashed rule sits at the floor with "Goal 1%" in the gutter, and all end tones are success (`zoom/montage-g1-1440.png`).
- Goal 100 puts the dashed rule under a flat 100% line. It is hidden there, and the gutter label "Goal 100%" still marks it (`zoom/montage-g100-390.png`).

**Literal facts.** These are read from rendered text, not app functions, and match the seed receipt.
- Mixed: 74%→61%, Ready 752 / not recorded 261 / lapse 139, 139 lapses in the week of 18 Oct.
- Cliff fifty: 100→50, 50 lapses in the 18 Oct bucket (lapse 15 Oct).
- Final bucket: 100→50 by 3 Nov.
- Rounding: 85% flat, Ready 11 / not recorded 2.
- At goal: 85→75. Drop nine: 85→76. Flat 100: Ready 1.

**Font.** The rendered labels are IBM Plex Mono.
- The latin faces at 400/500/600 report `loaded`. Computed family is `"IBM Plex Mono", monospace`. `getComputedTextLength` equals the Plex canvas width for every value and goal label in all 684 cases.
- Plex 12px figure ascent is 8.0px, against the model's 8.4px (0.7em). That is a 0.4px extra margin.
- A live fallback-font render was **not run** because it would need a CSS override. Instead I measured fallback metrics on the same page (`measure/fallback-font-metrics.json`). Generic monospace (Liberation Mono) has a 9px ascent at the same width, so the tightest 2.0px gap would drop to about 1.4px, which is still no strike. Sans-serif fallback widens "100%" from 28.8 to 30.7px; the end label is end-anchored and the start label has more than 100px of room. "Goal 95%" is not wider in any fallback measured, so the gutter would not clip.

**1024/180 legibility.** The plot is about 222px wide (`zoom/montage-g85-light-1024-180.png`).
- Month ticks thin to Today · 4 Oct / 1 Feb / 2 Apr. They are sparse but legible and never overlap.
- Bars are narrow but visible. Counts "139" and "50" read clearly. The highlighted band stays distinct.

**Paper relationship.** Paper artboard "03 — Training Reports / Briefing forecast" (read-only, `Forecast` frame at 2x) puts "Goal 90%" inside the plot, green, above the right end of the dashed rule. The start value sits just above and right of its dot, and the end value just below and left of its dot, with no rule between label and dot. The candidate departs from Paper in two ways.
- The goal label lives in the right gutter, muted, vertically centred on the rule. This is the v5 legibility move the brief authorized. It keeps the dashed success line labelled.
- Value labels keep Paper's sides and only step past a rule they would otherwise cross. In the common case they are pixel-identical to Paper's placement (drift 0). When displaced, the label stays in its dot's column, on the side the line can never reach.

**Minor objections (not blocking in my judgment).**
1. Displaced start label across a gridline. In the mixed state the start "74%" sits above the 80% gridline (11.2px drift, 16px from its dot) with the gridline between label and dot. At goal 85 it is wedged 2.0px above the 80% gridline and 2.9px below the goal-85 rule (`zoom/z0004-mixed-start.png`, `png/hires/g95-light-1440-mixed-90.png`). It is legible and nothing else competes for the dot. Its height still reads near 83% on the axis while the dot is at 74%. Paper never shows this state.
2. The tightest glyph-to-rule visible gap is 2.0–2.5px. That is clear at 1x and 2x but has little margin for fallback fonts, as estimated above.

## Outcome 2. D1, D2, smoke, focus, export: PASS

**D1.** `driver/d1flow.sh` ran at 1440×900, 1024×768 and 390×844, in both themes, through steady → pending → after-release → error → Retry. Every click was native. The mixed filters were loaded so Clear filters shows. Results are in `measure/d1/`, `png/d1/`.
- Every state at every width/theme showed zero overlaps, zero off-screen controls and zero horizontal page overflow.
- The action group and toolbar boxes are pixel-identical across all five states in all six combinations. The reserved status slot absorbs "Updating briefing" without shifting Clear filters or Export Excel.
- The toolbar wraps to two rows at 1440, three at 1024 and three at 390. All filters and horizon radios stay reachable. At 390 the view select truncates to "Boundar…".
- Pending: `network arm-hold training-reports` held a real 200 (`held:true`), the status read "Updating briefing", and the radio showed the attempted 30 D. After release the 30-day briefing loaded.
- Error: `arm-fail` delivered the synthetic 503 and "Unable to update the briefing … (503). Showing the last briefing that loaded. Retry" appeared. Controls reverted to the shown 30-day briefing. Retry applied the attempted 60 days ("FORECAST · NEXT 60 DAYS", `zoom/d1-eyebrows.png`).
- Polish note: at 390 the actions row has 23px of right slack beside the reserved empty status slot. The buttons are neither page-left nor page-right aligned. There is no wrap. The v5 4.3px wrap caveat did not recur.

**D2.** Across all 684 cases, the caption is at least 24px from every value label and bar count, 4px above the SVG, and never more than two lines (32.8px).

**Native filter, URL and SSR smoke.**
- Choosing the saved view through the listbox issued one `api/training-reports?view=…` GET and the URL became `?view=…`.
- Keyboard Space on the Duty role checkbox appended `&role=…`.
- A plain reload, and a reload of the filtered URL `?view&role&horizon=180&rowsBy=role`, each showed only the document GET and a notification count. There was no initial summary GET. The filtered reload restored 180 days and Rows by Duty role.

**Cell smoke.** The cell click issued one `training-reports/detail?…&scope=cell&row=…&type=…` (200, `cache-control: private, no-store`). The page URL was unchanged, with no record IDs. The response has 25 rows, page 1 of 1, pageSize 25. Status read "…At goal 85: 25 requirements not ready or lapsing by 2 Apr" (15 not ready + 10 lapses).

**Refetch.** Each change produced a new GET. Abort and stale-reply sequencing are **source-mapped** only (`trainingBriefingSession.svelte.ts` `AbortController` plus request id check). A live stale-reply race was not driven this round. Older V3 race proof remains qualified supplementary evidence.

**Focus-visible.** Both checks used the native `press_key`.
- After Escape closed the Duty role menu, focus returned to its trigger with `:focus-visible` and a 3px ring.
- Tab from a clicked cell moved focus to the next cell with `:focus-visible` and a 4px background + 6px dark double ring (`png/0007-focus-cell-tab.png`). That is distinct from the selected cell's dashed outline and the drop cells' 2px inset outline.

**Console.** The hydrated filtered page logged 8 messages: Vercel insights script 404s and MIME refusals, a CSP eval issue, and a preload warning. None came from the app or hydration. The tool lists only messages since that navigation, so earlier pages' messages are intrinsically omitted.

**Export.**
- Setup: filtered reload, `network arm-observe training-reports/export` + `export arm`, then a native click on the visible Export Excel button.
- Response: 200, `Content-Disposition: attachment; filename="training-report-2026-10-04.xlsx"`, `Content-Type` spreadsheetml. The Blob was 12,252 bytes, sha256 `eeefca82…e548`, saved as `downloads/training-report-filtered.xlsx`.
- Contents: sheet "Training Report". Headers are Name, Rank, MOS, Duty Role, Group plus the 12 saved-view columns. There are 100 Person rows, all in the dedicated role, and no Able, Baker or Foreign row.
- Status labels: 139 "10d left (2026-10-14)", 613 Current, 261 Not Done, 187 N/A. That matches the briefing's 752 ready (613 + 139), 261 not recorded and 139 lapses. Both controls were restored. The export failure path was not re-run this round.

## Outcome 3. Contracts preserved by smoke: PASS for the scope observed

- **Math and input.** The literal briefing numbers, screen-reader rows, detail counts and workbook counts all agree with the seed receipt (above).
- **Access and shared consumers.** Not re-driven. The complete non-visual branch review is root's `.verification/1503-prefinal-source-review-v6.md` with required checks/build receipts. Older V3 auth/API/server-fault/race/scoped proof remains candidate-qualified supplementary evidence. This report is not a complete branch acceptance.

## Restoration and cleanup state

- **Goal.** Changed natively 90→85→95→100→1→100→90, each read back with `rows organizations orgA`. The final OrgA and OrgB rows are identical to root's originals (`diff` empty). `personnel_trainings` OrgA `trainingCurrent` and OrgB rows are identical to the originals. I wrote no training rows.
- **Theme and storage.** Theme was toggled natively light→dark→light→dark→light. `localStorage.theme` was removed to match the original absent key. `mode-watcher-*` keys were never changed.
- **Viewport.** Emulation cleared and the window restored to 1905×2053 at DPR 1.
- **Controls.** No `network` or `export` control is armed (`network state`: armed false).
- **Session.** Native Account menu → Sign Out landed on `/`. Navigating to the protected Reports route redirected to `/auth/login`.
- **Left for root.** Final doctor PASS. Worker 1, the 966 seeded IDs and the journal remain running for root's guarded comparisons, `clean-seeds`, exact-ID absence and worker cleanup. I ran no cleanup, restart or launch.

## Failures, limitations and unrun paths

- **Non-zero receipts, all non-product.** 12 `wait_for` timeouts on "NEXT 30/60 DAYS": the accessible text is mixed case and CSS uppercases it. The screenshots confirm the briefings loaded. One first attempt to reach Policies at 390, where the sidebar is not exposed; no click landed and the goal was unchanged (read back 85). One trial screenshot to a disallowed `/tmp` path.
- **Superseded crops.** The first-pass 390 crops were wrong because `main` is the scroll container. Crops were redone; the measurements were valid.
- **Unrun this round.**
  - Live fallback-font render.
  - Live stale-reply race.
  - Export failure.
  - Real server/provider faults.
  - Scoped/foreign actors.
  - Mac/HTTPS/H2/T3-browser.
  - An actual screen reader (the table was read from the DOM).
  - Control-click for every sweep case (URL navigation was used).
  - The model-only 74→60 state (not a required fixture).
- **No Paper writes. No source, recipe, helper or adapter edits.** Driver files exist only in this run's evidence directory.

## Verdict

D4 resolved and D3 preserved, with PASS on D1, D2, smoke, focus and export in this owned Linux browser. Two minor objections are recorded for Robert's call: the displaced start label above a gridline, and tight 2px rule clearance. Neither is a strike, clip or collision.
