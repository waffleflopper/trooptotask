import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
output = root / '.verification/evidence/verify-trooptotask/training-matrix-export/validation'
environment = os.environ.copy()
environment.update({
    'PATH': '/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:' + environment['PATH'],
    'PUBLIC_SUPABASE_URL': 'http://127.0.0.1:59999',
    'PUBLIC_SUPABASE_ANON_KEY': 'ci-synthetic-anon',
    'SUPABASE_SERVICE_ROLE_KEY': 'ci-synthetic-service',
    'ACCOUNT_SETUP_LINK_SECRET': 'ci-synthetic-setup',
    'ACCOUNT_SETUP_SESSION_SECRET': 'ci-synthetic-session',
    'APP_PUBLIC_ORIGIN': '',
    'TMPDIR': str(root / '.verification/tmp/training-matrix-export-validation'),
    'PUBLIC_APP_ORIGIN': '',
    'PUBLIC_SITE_URL': '',
    'APP_PUBLIC_ORIGIN_ALLOWLIST': '',
    'VITEST_MAX_WORKERS': '1'
})
results = []
for script in ['format', 'format:check', 'lint', 'governance:check', 'check', 'test', 'build']:
    environment['APP_PUBLIC_ORIGIN'] = 'http://127.0.0.1:4173' if script == 'build' else ''
    with (output / (script.replace(':', '-') + '.log')).open('w') as log:
        result = subprocess.run(['npm', 'run', script], cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    results.append({'command': 'npm run ' + script, 'exit_code': result.returncode})
    (output / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
    print('PASS' if result.returncode == 0 else 'FAIL', 'npm run ' + script, flush=True)
