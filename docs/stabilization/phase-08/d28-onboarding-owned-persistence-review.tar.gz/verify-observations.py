import json,pathlib,re,hashlib
P=pathlib.Path(__file__).parent
J=lambda p:json.loads(p.read_text())
def rows(run,n): return J(P/(run+'-expanded')/'raw'/n)['rows']
def keyed(rs):return {r['id']:r for r in rs}
receipt={'independentExecution':'artifact readers only; no app/test/DB execution','restoration':{},'semantic':{}}
for run in ['baseline','final']:
 o=rows(run,'original-full.json');a=rows(run,'after-clean-seeds-full.json');checks=[];extras={};originalIds=set();addedIds=set()
 for org,ts in o.items():
  for t,rr in ts.items():
   originalIds.update(r['id'] for r in rr);aa=keyed(a[org][t]);assert all(aa.get(r['id'])==r for r in rr),(run,org,t)
   new=[r for r in a[org][t] if r['id'] not in keyed(rr)];
   if new:extras[org+'/'+t]=len(new)
   checks.append({'org':org,'table':t,'originalCount':len(rr),'exactCompleteFields':True})
 assert sum(x['originalCount'] for x in checks)==118 and len(checks)==28
 assert sum(extras.values())==(56 if run=='baseline' else 42),extras
 for p in (P/(run+'-expanded')/'raw').glob('*-full.json'):
  try:r=J(p)['rows']
  except (KeyError,TypeError):continue
  addedIds.update(x['id'] for ts in r.values() for rr in ts.values() for x in rr if x['id'] not in originalIds)
 present={x['id'] for ts in a.values() for rr in ts.values() for x in rr};remaining=addedIds&present
 assert all(x['id'] not in (addedIds-remaining) for ts in a.values() for rr in ts.values() for x in rr)
 receipt['restoration'][run]={'tables':checks,'originalRows':118,'remainingSeparateNewRows':extras,'distinctObservedTemporaryIds':len(addedIds-remaining),'temporaryAbsent':True,'remainingObservedAddedIds':len(remaining)}
T={'id':'id','orgId':'organization_id','name':'name','description':'description','createdAt':'created_at'}
S={'id':'id','organization_id':'organization_id','templateId':'template_id','name':'name','description':'description','stepType':'step_type','trainingTypeId':'training_type_id','stages':'stages','sortOrder':'sort_order','created_at':'created_at'}
O={'id':'id','personnelId':'personnel_id','startedAt':'started_at','completedAt':'completed_at','cancelledAt':'cancelled_at','status':'status','templateId':'template_id'}
N={'id':'id','onboardingId':'onboarding_id','stepName':'step_name','stepType':'step_type','trainingTypeId':'training_type_id','stages':'stages','sortOrder':'sort_order','completed':'completed','currentStage':'current_stage','notes':'notes','templateStepId':'template_step_id','active':'active'}
A={'id':'id','onboardingId':'onboarding_id','stepName':'step_name','stepType':'step_type','completed':'completed','currentStage':'current_stage'}
data=J(P/'history-independent-decoded.json')[0]['data'];saved=rows('final','after-complete-full.json')['orgA']
def projection(row,m):
 out={k:row.get(v) for k,v in m.items()}
 if 'notes' in out and not isinstance(out['notes'],list):out['notes']=[]
 if 'active' in out and out['active'] is None:out['active']=True
 return out
for family,table,m in [('onboardingTemplates','onboarding_templates',T),('onboardingTemplateSteps','onboarding_template_steps',S)]:
 assert data[family]==sorted([projection(r,m) for r in saved[table]],key=(lambda x:(x['name'],x['id'])) if m is T else (lambda x:(x['sortOrder'],x['id'])))
 receipt['semantic'][family]={'count':len(data[family]),'keys':list(m),'fullLiteralSQLMatch':True}
ss=keyed(saved['onboarding_step_progress']);oo=keyed(saved['personnel_onboardings']);nn=0
for packet in data['onboardings']:
 expected=projection(oo[packet['id']],O);expected['steps']=sorted([projection(r,N) for r in ss.values() if r['onboarding_id']==packet['id']],key=lambda x:x['sortOrder']);assert packet==expected;nn+=len(packet['steps'])
assert len(data['onboardings'])==5 and nn==21
receipt['semantic']['history']={'parents':5,'nested':nn,'parentKeys':list(O)+['steps'],'nestedKeys':list(N),'fullLiteralSQLMatch':True,'independentlyDecodedFromSanitizedDocument':True,'nativeDocumentRequest':271,'originalBodyBytes':48912,'sanitizedBodyBytes':(P/'final-expanded/raw/history-document-sanitized.html').stat().st_size}
def wire(n):
 d=J(P/'final-expanded/raw'/n);d=JString(d['stdout']) if 'stdout' in d else d
 text='\n'.join(c.get('text','') for c in d.get('content',[]));status=int(re.search(r'\nStatus: (\d+)',text)[1]);body=text.split('### Response Body\n',1)[1].strip();return status,json.loads(body)
def JString(s):return json.loads(s)
for n,snapshot in [('template-clear-wire.json','catalog-final-full.json'),('training-restored-wire.json','catalog-final-full.json'),('checkbox-progress-wire.json','after-progress-full.json'),('paperwork-progress-wire.json','after-progress-full.json'),('start-wire.json','after-start-full.json')]:
 status,response=wire(n);assert status==200
 m=T if n.startswith('template') else A if 'progress' in n else O if n.startswith('start') else S
 table='onboarding_templates' if m is T else 'onboarding_step_progress' if m is A else 'personnel_onboardings' if m is O else 'onboarding_template_steps'
 rr=keyed(rows('final',snapshot)['orgA'][table]);r=response.get('data',response) if isinstance(response,dict) else response
 if m is O:
  expected=projection(rr[r['id']],O);ps=rows('final',snapshot)['orgA']['onboarding_step_progress'];expected['steps']=sorted([projection(x,N) for x in ps if x['onboarding_id']==r['id']],key=lambda x:x['sortOrder'])
 else:expected=projection(rr[r['id']],m)
 assert r==expected,(n,r,expected)
 receipt['semantic'][n]={'status':status,'id':r['id'],'keyCount':len(r),'fullSQLMatch':True}
# Lifecycle preserves progress content and identity, terminal updates only parent lifecycle fields.
pid=receipt['semantic']['start-wire.json']['id']; stages=['after-progress-full.json','after-cancel-full.json','after-reopen-full.json','after-complete-full.json'];pr=[]
for n in stages:
 r=rows('final',n)['orgA'];pr.append(keyed([x for x in r['onboarding_step_progress'] if x['onboarding_id']==pid]));packet=keyed(r['personnel_onboardings'])[pid]
 assert len(pr[-1])==3
 receipt['semantic'][n]={'status':packet['status'],'id':packet['id'],'progressCount':len(pr[-1]),'notes':sum(len(x['notes']) for x in pr[-1].values())}
assert all(x==pr[1] for x in pr[2:]);assert all({k:v for k,v in r.items() if k!='notes'}=={k:v for k,v in pr[1][i].items() if k!='notes'} for i,r in pr[0].items());assert sum(len(r['notes']) for r in pr[1].values())==1;receipt['semantic']['lifecycleProgressRetained']=True
# Scope business data cannot move during any denial; audit is separate.
b=rows('final','scope-before-denials-full.json')
for n in ['scoped-bravo-after-full.json','foreign-step-after-full.json','foreign-org-after-full.json','catalog-denied-after-full.json','none-denied-after-full.json']:
 a=rows('final',n);assert all(keyed(b[org][t])==keyed(a[org][t]) for org in b for t in b[org] if t!='audit_logs');receipt['semantic'][n]={'businessRowsets':26,'allFieldsUnchanged':True}
# Actual Starter first changes and repeat exact all rows.
b=rows('final','before-starter-full.json');a=rows('final','after-starter-first-full.json');a2=rows('final','after-starter-reapply-full.json');assert a==a2
changes={}
for org in b:
 for t in b[org]:
  old=keyed(b[org][t]);new=[x for x in a[org][t] if x['id'] not in old];assert all(keyed(a[org][t]).get(k)==v for k,v in old.items());
  if new:changes[org+'/'+t]=[x.get('name',x['id']) for x in new]
assert {k:len(v) for k,v in changes.items()}=={'orgA/onboarding_templates':1,'orgA/onboarding_template_steps':4,'orgA/training_types':2,'orgA/audit_logs':7}
receipt['semantic']['starter']={'firstExactDeltas':changes,'reapplyAll28RowsetsExact':True,'authority':'authenticated API; no native Starter UI credit'}
(P/'semantic-restoration.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'restoration':{k:{x:v for x,v in d.items() if x!='tables'} for k,d in receipt['restoration'].items()},'semanticChecks':len(receipt['semantic'])},indent=2))
