from pathlib import Path
import subprocess,json,hashlib,time
out=Path('.verification/evidence/critical-task-completion-owner')
b=Path('src/features/critical-tasks/server')
provider=b/'criticalTaskCompletionPersistence.server.ts'
mapping=b/'personnelIctCompletionMapping.server.ts'
batch=b/'ictCompletionsBatch.server.ts'
cmd=['npm','test','--',str(b/'criticalTaskCompletionPersistence.server.test.ts')]
cases=[
 ('lost-read-tenant',provider,".select(COMPLETION_SELECT).eq('organization_id', orgId)",'.select(COMPLETION_SELECT)'),
 ('lost-tail',provider,'.range(from, to)','.range(from, from + 998)'),
 ('report-max8',provider,'pending.length === 4','pending.length === 8'),
 ('report-filter51',provider,'people.slice(personIndex, personIndex + 50)','people.slice(personIndex, personIndex + 51)'),
 ('import-filter500',provider,'index += 50) {\n\t\t\t\tconst batch = uniquePairs.slice(index, index + 50)','index += 500) {\n\t\t\t\tconst batch = uniquePairs.slice(index, index + 500)'),
 ('expanded-projection',provider,'.select(COMPLETION_SELECT)',".select('*')"),
 ('wrong-write-tenant',provider,'...completionCreateValues(input), organization_id: orgId',"...completionCreateValues(input), organization_id: 'org-b'"),
 ('lost-null-clear',mapping,'value !== undefined','value != null'),
 ('lost-timestamp-precision',mapping,'createdAt: row.created_at','createdAt: row.created_at.slice(0, 19)'),
 ('lost-bulk-fallback',batch,'} catch {\n\t\t\tfor (const row of createRows)',"} catch {\n\t\t\tthrow new Error('Bulk fallback removed');\n\t\t\tfor (const row of createRows)"),
 ('partial-on-read-error',provider,'if (error) throw new Error((error as { message: string }).message);','if (error) return [];')
]
records=[]
for name,path,old,new in cases:
 original=path.read_bytes();source=original.decode();assert old in source,(name,old)
 before=hashlib.sha256(original).hexdigest();start=time.time()
 try:
  path.write_text(source.replace(old,new,1))
  mutated=hashlib.sha256(path.read_bytes()).hexdigest()
  r=subprocess.run(cmd,capture_output=True,text=True,timeout=40)
  (out/(name+'-red.log')).write_text(r.stdout+r.stderr)
  record={'name':name,'source':str(path),'command':cmd,'exitCode':r.returncode,'originalSha256':before,'mutatedSha256':mutated,'seconds':round(time.time()-start,3),'log':name+'-red.log'}
 finally:
  path.write_bytes(original)
 record['restoredSha256']=hashlib.sha256(path.read_bytes()).hexdigest();records.append(record)
 (out/'fault-probes.json').write_text(json.dumps(records,indent=2))
 print(name,r.returncode,flush=True)
 if r.returncode==0: raise SystemExit('Fault survived: '+name)
cmd=json.loads((out/'focused-command.json').read_text())['command']
r=subprocess.run(cmd,capture_output=True,text=True,timeout=40);(out/'restored-focused-green.log').write_text(r.stdout+r.stderr)
(out/'restoration.json').write_text(json.dumps({'command':cmd,'exitCode':r.returncode,'node':subprocess.check_output(['node','--version'],text=True).strip(),'npm':subprocess.check_output(['npm','--version'],text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2));print('restored',r.returncode,flush=True)
raise SystemExit(r.returncode)
