from pathlib import Path
import json,sys,datetime
p=Path(__file__).parent
load=lambda n:json.loads((p/(n+'.stdout')).read_text())
rows=lambda stage,t,o:{r['id']:r for r in load(f'{stage}-{t}-{o}')['rows']}
tables=['personnel','personnel_documents','counseling_records','personnel_follow_ups','leader_notes','rating_scheme_entries','personnel_onboardings','onboarding_step_progress','notifications']
mode=sys.argv[1]
result={'passed':True,'mode':mode}
if mode=='denial':
 for t in tables:
  for o in ['orgA','orgB']:assert rows('retention-before',t,o)==rows('retention-denied',t,o),(t,o)
 assert load('retention-before-files')==load('retention-denied-files')
 for f in ['records','personnel','onboarding']:
  for m in ['missing','wrong']:assert load(f'retention-{f}-{m}')['status']==401
 result.update(sixCredentialDenials=401,tableReadbacksUnchanged=18,fileCount=32,filesExactlyUnchanged=True)
elif mode=='records':
 # Independent specimen expectation: 2000 archive timestamps are expired at the observed 2026 clock;
 # yesterday and null archives remain. Parent removal also removes all of its child rows.
 expired=set(load('retention-personnel-seed')['expiredIds']);removed={}
 for t in tables[:-1]:
  for o in ['orgA','orgB']:
   before=rows('retention-before',t,o);expected={};gone=[]
   for i,r in before.items():
    old=bool(r.get('archived_at') and r['archived_at'].startswith('2000-01-01'))
    delete=(i in expired if t=='personnel' else r.get('personnel_id') in expired or old if t in ['personnel_documents','counseling_records','personnel_follow_ups','leader_notes'] else False)
    if delete:gone.append(i);continue
    saved=dict(r)
    if t=='rating_scheme_entries':
     for k,v in saved.items():
      if k.endswith('_id') and v in expired:saved[k]=None
    expected[i]=saved
   assert rows('retention-records',t,o)==expected,(t,o)
   removed[t+'-'+o]=gone
 response=load('retention-records-run');assert response['status']==200
 body=json.loads(response['body']);assert body['deletedCount']==8 and body['orgsAffected']==1
 assert {f['table']:f['deletedCount'] for f in body['families']}=={'personnel_follow_ups':1,'counseling_records':2,'personnel_documents':2,'leader_notes':1,'personnel':2,'ict_tasks':0,'assignment_types':0}
 beforefiles=load('retention-before-files')['files'];afterfiles={f['path']:f for f in load('retention-records-files')['files']}
 files=[]
 for f in beforefiles:
  a=afterfiles[f['path']];deleted=f.get('personnelId') in expired or f.get('classification')=='expired'
  assert a['present']==(not deleted),f['path']
  if not deleted:assert a['observedSize']==f['observedSize'] and a['observedSha256']==f['observedSha256']
  files.append({'path':f['path'],'expectedRemoved':deleted,'observedPresent':a['present']})
 result.update(exactRemovedIds=removed,job=body,files=files,remainingRatingFieldsExactlyPreserved=True)
elif mode in ['legacy-retry','records-retry','onboarding-retry']:
 prev={'legacy-retry':'retention-records','records-retry':'retention-legacy-retry','onboarding-retry':'retention-onboarding'}[mode]
 stage='retention-'+mode
 checked=tables if mode!='onboarding-retry' else ['personnel_onboardings','onboarding_step_progress','notifications']
 for t in checked:
  for o in ['orgA','orgB']:assert rows(prev,t,o)==rows(stage,t,o),(t,o)
 response=load(stage+'-run');assert response['status']==200
 body=json.loads(response['body']);assert body['deletedCount']==0 and body['orgsAffected']==0
 if mode!='onboarding-retry':assert load(prev+'-files')==load(stage+'-files')
 result.update(job=body,tableReadbacksUnchanged=len(checked)*2,filesExactlyUnchanged=mode!='onboarding-retry')
elif mode=='onboarding':
 specimen=load('retention-onboarding-seed');expired={r['id'] for r in specimen['packets'] if r['key'].startswith('expired')}
 gone={}
 for t in ['personnel_onboardings','onboarding_step_progress']:
  for o in ['orgA','orgB']:
   before=rows('retention-records-retry',t,o)
   expected={i:r for i,r in before.items() if (i if t=='personnel_onboardings' else r['onboarding_id']) not in expired}
   assert rows('retention-onboarding',t,o)==expected,(t,o)
   gone[t+'-'+o]=list(set(before)-set(expected))
 response=load('retention-onboarding-run');assert response['status']==200
 body=json.loads(response['body']);assert body['deletedCount']==2 and body['orgsAffected']==1
 result.update(job=body,exactRemovedIds=gone,allSurvivorFieldsUnchanged=True)
else:raise ValueError(mode)
(p/('retention-'+mode+'-analysis.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
