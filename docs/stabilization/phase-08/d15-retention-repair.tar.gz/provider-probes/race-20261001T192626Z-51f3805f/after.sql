SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('de6649a0-9a31-4ef5-bd29-e22a2ba9c255'::uuid,'cc0ec6bb-7d2f-4808-b2c6-d671536bcfd0'::uuid,'9b42909f-ba00-42ff-9e92-31f30e335428'::uuid,'5c046db5-f1f5-40d3-a211-a7563e12e109'::uuid,'e112a7ff-a2bc-4910-8d9e-0631403ce10a'::uuid,'742f102a-d3fb-45b6-b244-d829bc5733bf'::uuid,'b5295150-fd3d-42b2-ab6a-d0fc2161ff9b'::uuid,'a7323c45-1cb8-4811-9b20-6a00889a3501'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('0194bfc4-5207-4559-a08d-f926a5754025'::uuid,'bd6bf5ad-8b86-45db-adad-0dceb0b8ac08'::uuid,'16eda5e6-1340-41f3-b46d-766603a26f4f'::uuid,'8c494f57-ac25-4947-93b1-685586ecebab'::uuid,'8464f09a-2eeb-47bf-94f9-7647c8fe16cf'::uuid,'ef2c1c04-9f0a-4f50-8726-959aee38a3b6'::uuid,'a919b119-d9a7-41bc-88f5-e91109ebedd2'::uuid,'5d02a0b8-62b6-4add-89c7-9f94846851c1'::uuid)) s), '[]'::json));
