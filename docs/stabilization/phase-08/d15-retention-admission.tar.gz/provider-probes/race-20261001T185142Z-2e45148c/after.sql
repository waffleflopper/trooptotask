SET statement_timeout = '10s'; SET lock_timeout = '3s';
SELECT json_build_object(
 'packets', COALESCE((SELECT json_agg(p ORDER BY p.id) FROM
   (SELECT id, organization_id, personnel_id, template_id, started_at, completed_at, cancelled_at, status
    FROM public.personnel_onboardings WHERE id IN ('491e7dd7-7705-45c6-adc3-630f7425e14e'::uuid,'ae333df7-4b21-46de-841d-f3913e51b638'::uuid,'10401a23-ece6-43a7-acfa-89f84080fed5'::uuid,'5f4eb235-41f3-46a3-a824-f7e31e92c00b'::uuid,'dd00b436-5595-420e-a687-d8a7072e5189'::uuid,'3ddf4260-9a19-4f63-8986-706c68899a37'::uuid,'f7aef74c-a6cc-4676-9ddd-194b2ab465a1'::uuid,'c35a4184-2a03-4514-aae2-aced74f0a7d2'::uuid)) p), '[]'::json),
 'progress', COALESCE((SELECT json_agg(s ORDER BY s.id) FROM
   (SELECT id, organization_id, onboarding_id, template_step_id, step_name, step_type, training_type_id,
           stages, sort_order, completed, current_stage, notes, active
    FROM public.onboarding_step_progress WHERE id IN ('fe9a0f3c-0140-4905-8d93-eb6c33d8c68a'::uuid,'f6c5bb71-6143-4c3e-9f28-b4b887661f40'::uuid,'9878254f-9ff7-4771-b8f8-bd46b3e5dad2'::uuid,'eaaf64c8-7489-4c85-8e08-422b57dab64d'::uuid,'b5d45a75-ccaa-4285-aa1b-6e948a766b39'::uuid,'ee130205-3c4d-4984-ae5c-d8c57ca87bac'::uuid,'167d499a-a271-4dca-980e-83a29bd96822'::uuid,'cbb4391c-8f04-474d-8a72-7d705a1683f5'::uuid)) s), '[]'::json));
