import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import type { CalendarRangeData, CalendarWorkspaceHydration } from './calendar.types';
import { createCalendarWorkspaceHydrator } from './calendarWorkspaceHydration.svelte';
import { availabilityStore } from './stores/availability.svelte';
import { dailyAssignmentsStore } from './stores/dailyAssignments.svelte';
import { specialDaysStore } from './stores/specialDays.svelte';
import { mergeCalendarRangeIntoStores } from './utils/calendarRangeLoader';

function deferred<T>() {
	let resolve!: (value: T) => void;
	let reject!: (reason: unknown) => void;
	const promise = new Promise<T>((res, rej) => {
		resolve = res;
		reject = rej;
	});
	return { promise, resolve, reject };
}

function range(month: '10' | '12'): CalendarRangeData {
	const date = `2026-${month}-15`;
	return {
		rangeStart: `2026-${month}-01`,
		rangeEnd: `2026-${month}-31`,
		availabilityEntries: [
			{ id: `availability-${month}`, personnelId: 'p1', statusTypeId: 'leave', startDate: date, endDate: date }
		],
		specialDays: [{ id: `closure-${month}`, name: 'Unit closure', date, type: 'org-closure' }],
		dailyAssignments: [{ id: `assignment-${month}`, date, assignmentTypeId: 'cq', assigneeId: 'p1' }]
	};
}

function streamedBootstrap() {
	const availability = deferred<CalendarRangeData['availabilityEntries']>();
	const specialDays = deferred<CalendarRangeData['specialDays']>();
	const assignments = deferred<{ types: []; assignments: CalendarRangeData['dailyAssignments'] }>();
	const hydration: CalendarWorkspaceHydration = {
		orgId: 'org-1',
		personnel: { mode: 'preserve-client', snapshotKey: 'personnel', items: [] },
		groups: { mode: 'preserve-client', snapshotKey: 'groups', items: [] },
		statusTypes: { mode: 'preserve-client', snapshotKey: 'statuses', items: [] },
		pinnedGroups: { mode: 'preserve-client', snapshotKey: 'pins', items: [] },
		availabilityEntries: { mode: 'merge', snapshotKey: 'october-availability', items: availability.promise },
		specialDays: { mode: 'merge', snapshotKey: 'october-closures', items: specialDays.promise },
		calendarAssignments: {
			mode: 'merge',
			snapshotKey: 'october-assignments',
			rangeStart: '2026-10-01',
			rangeEnd: '2026-10-31',
			items: assignments.promise
		}
	};
	return {
		hydration,
		availability,
		resolve() {
			const october = range('10');
			availability.resolve(october.availabilityEntries);
			specialDays.resolve(october.specialDays);
			assignments.resolve({ types: [], assignments: october.dailyAssignments });
		}
	};
}

function clearRangeStores() {
	availabilityStore.load([], '');
	specialDaysStore.load([], '');
	dailyAssignmentsStore.load([], [], '');
}

beforeEach(clearRangeStores);
afterEach(() => {
	clearRangeStores();
	vi.restoreAllMocks();
});

it('retains every bootstrap stream when a later Calendar range arrives first', async () => {
	const bootstrap = streamedBootstrap();
	const pending = createCalendarWorkspaceHydrator().hydrate(bootstrap.hydration);
	mergeCalendarRangeIntoStores('org-1', range('12'));
	bootstrap.resolve();
	await pending;

	expect.soft(availabilityStore.items.map((item) => item.id)).toEqual(['availability-12', 'availability-10']);
	expect.soft(specialDaysStore.items.map((item) => item.id)).toEqual(['closure-12', 'closure-10']);
	expect.soft(dailyAssignmentsStore.assignments.map((item) => item.id)).toEqual(['assignment-12', 'assignment-10']);
});

it('discards all delayed bootstrap streams after their stores are cleared', async () => {
	const bootstrap = streamedBootstrap();
	const pending = createCalendarWorkspaceHydrator().hydrate(bootstrap.hydration);
	clearRangeStores();
	bootstrap.resolve();
	await pending;

	expect(availabilityStore.items).toEqual([]);
	expect(specialDaysStore.items).toEqual([]);
	expect(dailyAssignmentsStore.assignments).toEqual([]);
});

it('keeps a cancelled bootstrap out of a newly allowed workspace for the same organization', async () => {
	const bootstrap = streamedBootstrap();
	const hydrator = createCalendarWorkspaceHydrator();
	const pending = hydrator.hydrate(bootstrap.hydration);
	hydrator.restrict();
	mergeCalendarRangeIntoStores('org-1', range('12'));
	bootstrap.resolve();
	await pending;

	expect(availabilityStore.items.map((item) => item.id)).toEqual(['availability-12']);
	expect(specialDaysStore.items.map((item) => item.id)).toEqual(['closure-12']);
	expect(dailyAssignmentsStore.assignments.map((item) => item.id)).toEqual(['assignment-12']);
});

it('reports a bootstrap failure after another valid Calendar range arrives', async () => {
	vi.spyOn(console, 'error').mockImplementation(() => {});
	const bootstrap = streamedBootstrap();
	const pending = createCalendarWorkspaceHydrator().hydrate(bootstrap.hydration);
	const result = expect(pending).rejects.toThrow('Bootstrap unavailable');
	mergeCalendarRangeIntoStores('org-1', range('12'));
	bootstrap.availability.reject(new Error('Bootstrap unavailable'));
	bootstrap.resolve();
	await result;
});
