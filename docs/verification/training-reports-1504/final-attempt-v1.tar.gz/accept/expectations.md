# Independent expectations (from spec #1433/#1504 + literal fixture, no app calculators)

Fixture day 2026-10-04. Horizon 90 → horizonEnd 2027-01-02. 30 → 2026-11-03. 180 → 2027-04-02.
People A: Able (Alpha, 68W, Medic), Baker (Bravo, 11B, NCO), Unassigned (no group, 68W, NCO).
Types: Required (all), Targeted (68W, excl NCO → Able only), Optional (excluded). 4 applicable cells.
Original row: Able Required c072729e… 2026-09-27→2027-09-27 (ready, no lapse within 180d: 2027-09-28 > 2027-04-02).

## Original
Ready 1, expired 0, not recorded 3, lapse 0 → 25% today, 25% horizon. "Nothing lapses before 2 Jan".
Grid by group: Alpha 50 (Req 100, Tgt 0); Bravo 0 (Req 0, Tgt —); Unassigned 0 (Req 0, Tgt —). Total Req 1/3=33, Tgt 0/1=0.
Type risk: Required notReady 2 / by-horizon 0; Targeted 1/0. Required above Targeted.
Focus (B standing gap only; no lapses): Required 2/3 not ready, score = (3/4-1/4)=50; Targeted 1/1, score = (2/4-1/4)=25. Order Required, Targeted.
Detail Total Required: Baker + Unassigned, both Not Done (2). Alpha×Targeted: Able Not Done (1).

## Dated (after import of Baker Req 2024-10-04→2025-10-04, Able Tgt 2025-10-19→2026-10-19)
Ready 2, expired 1 (Baker Req), not recorded 1 (Unassigned Req), lapse 1 (Able Tgt lapses 2026-10-20) → 50% today, 25% horizon, drop 25.
Grid: Alpha today 100 / horizon 50, Alpha×Tgt ▼100 (100→0). Bravo 0, Unassigned 0. Total Req 33, Total Tgt 100 (horizon 0).
Type risk: Required 2/0 (total 2) above Targeted 0/1 (total 1).
Cliff: 13 buckets, k=3, total lapses 1 < 5 → no cliff, no wave (A) focus.
Focus: B Required (records Baker, Unassigned; what-if horizon 25→75, score 50), C Alpha—Targeted (Able Tgt; pop what-if 25→50 score 25; row chip Alpha 50→100). Targeted B: 0 not ready → no.
Detail Total Required: Unassigned Not Done first, Baker expired 2025-10-04 (2 rows). Alpha×Tgt / Total Tgt: Able, warning label, 2026-10-19, Yes.
Export Requirements (unfiltered): Unassigned Req NotDone; Baker Req expired 2025-10-04; Able Tgt warning 2026-10-19 Yes. Alpha: Able Tgt only.
Alpha filter: 100% today, 50% horizon, Ready 2, lapse 1.

## training-pages seed (+26 Alpha PFC: #1 68W/Medic, 25× 11B/NCO)
29 People, 31 cells (29 Req + Able Tgt + temp#1 Tgt).
Before dated: ready 1, missing 30 → 3% (1/31=3.2).
After dated: ready 2, expired 1, missing 28, lapse 1 → 6% (6.45) today, 3% (3.2) horizon.
Required Total affected = 28 rows (26 temp + Unassigned + Baker). Requirements (full) = 30 rows (+temp#1 Tgt missing, +Able Tgt lapse).
Paging 25: page1 rows 1–25, page2 26–28.
