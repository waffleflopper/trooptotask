# Foreign Organization Start response adjudication

**Accepted boundary observation: actual 404, not planned 403.** This is a read-only source/saved-artifact interpretation at frozen `efd2801cfa9f5cbdcb13593e659002f2bfd9b51a`; it adds no live, final-run/cleanup, remote or whole-issue acceptance.

`access-foreign-actor.json` and the native snapshot place the normal `onboardingForeign` page 5 in Organization B. The exact saved helper invocation/receipt sends POST `/org/<A>/api/onboarding`, with the fresh A Alpha Person, actual A template and `2026-10-02`. It returns **404** with `{message:'Organization not found'}`. I independently compared the immediately preceding `access-empty-readback.json` to `access-foreign-readback.json`: identical ownership binding and complete selected prepared snapshot (`person`, `packets`, `progress`, `training`, `templates`, `definitions`); packet and progress arrays remain empty. This is equality of the captured prepared fields, not an unrecorded all-table comparison.

The actual dispatch path supports this result:

- `src/hooks.server.ts:120–127` runs `requireActiveOrganization` on Organization writes/APIs before endpoint resolution. A POST to the UUID target still takes this gate.
- `src/lib/server/adapters/supabaseOrganizationAdmission.ts:7–26` selects Organization status with the caller's RLS-scoped Supabase client and returns **404 / Organization not found** when that caller sees no Organization row. Suspension has a separate 403 at lines 27–29.
- The retained Organization member SELECT policy is `supabase/migrations/20260413001158_remote_schema.sql:4188`; invitation visibility is separately at 4182. The captured B-only actor receives no visible A row at the existing shared admission boundary.
- `src/routes/org/[orgId]/api/onboarding/+server.ts:11–20,39` dispatches the feature operation only after the hook admits the request. Thus this foreign-Organization request is rejected before feature lane/Person admission; its status does not establish a feature-level 403.
- `docs/stabilization/BASELINE.md:29` (R1) retains tenancy, server policy enforcement and RLS. The current authoritative packet recipe `.agents/skills/verify-trooptotask/features/onboarding-packets.md:25` explicitly allows captured **403/404** for valid foreign-resource requests. No retained contract demands 403 for this non-visible Organization.

`driver-error-003.json` correctly preserves the final plan's erroneous expected-403 assertion and supersedes it with the observed 404. This is a driving expectation mismatch, not a product failure. Do not count a planned 403 as passed, conflate this with a scoped/lane denial, or change the live frozen plan/source. Valid View/Empty/scoped denials and allowed scoped creation remain separate evidence. Final run disposal/frozen-input equality and complete native/archive acceptance are still pending.

`support.json` records the exact captured input hashes and recomputed equality. No services, browser, database, tracked/raw edits or external publication were used.
