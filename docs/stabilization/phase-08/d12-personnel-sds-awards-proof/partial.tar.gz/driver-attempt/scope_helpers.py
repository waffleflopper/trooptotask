import json,re
from flow import call,tool,snapshot,click,shot,base
from http import ack,flags,row,request,ORG,PERSON,siblings_equal
from sds import fill_values
seed=json.loads((base/'seed-lifecycle.json').read_text());fixture=json.loads((base/'fixture.json').read_text());owner=json.loads((base/'owner-page.json').read_text())['pageId'];checks=[]
BODY={'personnelId':PERSON,'bloodType':'O+','basd':'2020-02-03','dateOfRank':'2024-06-01','maritalStatus':'Married','numberOfDependents':2,'children':[{'name':'Avery','age':7},{'name':'Morgan','age':None}],'civilianEducation':'BSN','militaryEducation':['BLC','Air Assault'],'emergencyContactName':'Synthetic Contact','emergencyContactRelationship':'Sibling','emergencyContactPhone':'907-555-0188','spouseName':'Synthetic Spouse','spousePhone':'907-555-0101','vehicleMakeModel':'Toyota Tacoma','vehiclePlate':'VFY482','vehicleColor':'','personalEmail':'synthetic-sds@example.test','personalPhone':'907-555-0102','addressStreet':'100 Synthetic Way','addressCity':'Anchorage','addressState':'AK','addressZip':'99501'}
def projections(label):return {org:{t:call(label+'-'+org+'-'+t,'control','rows',t,org)['rows'] for t in ['personnel','personnel_extended_info']} for org in ['orgA','orgB']}
def successes(label):
 rows=call(label,'control','rows','audit_logs','orgA')['rows']
 return sorted((r['id'],r['action'],r.get('resource_id')) for r in rows if r['action'] in ['personnel.extended_info.updated','personnel.award_tracking_acknowledged','personnel.award_tracking_cleared'])
def open_person(label,page):
 s=snapshot(label+'-before',page);name='Open SPC '+seed['name']+', Synthetic'
 m=re.search(r'row '+re.escape(json.dumps(name))+r'\n([\s\S]*?)(?=\n        uid=|\n  uid=)',s)
 if not m:raise RuntimeError('Exact Person row missing '+name)
 uid=re.search(r'uid=([^ ]+) button "Details"',m[1]).group(1)
 tool(label,'click',{'pageId':page,'uid':uid})
def denied_batch(label,page,targets):
 before=projections(label+'-before');auditBefore=successes(label+'-audit-before');results=[]
 for key,person,org,expectedA,expectedS in targets:
  a=ack(label+'-'+key+'-ack',page,person=person,org=org)
  b=request(label+'-'+key+'-sds',page,'/org/'+org+'/api/personnel/'+person+'/extended-info','PUT',{**BODY,'personnelId':person,'bloodType':'AB-'})
  assert a['status']==expectedA and b['status']==expectedS,(key,a,b)
  results.append({'case':key,'personnelId':person,'organizationId':org,'ackStatus':a['status'],'sdsStatus':b['status']})
 after=projections(label+'-after');auditAfter=successes(label+'-audit-after');assert before==after and auditBefore==auditAfter
 checks.append({'scenario':label,'result':'PASS','requests':results,'allFullABRowsExact':True,'successAuditsExact':True})
