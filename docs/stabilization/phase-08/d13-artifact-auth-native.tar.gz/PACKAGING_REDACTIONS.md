# Packaging and redactions

This archive was packaged after the run's final doctor, frozen-input checks, seed cleanup and owned disposal. Packaging adds no fresh application proof. The original ignored capture files remain unchanged.

Every original relative filename is retained. Apart from the token query-value replacements listed below, all original payload bytes are preserved exactly; no captures, request inputs, PDFs, screenshots or outcome fields were removed or rewritten. `ARTIFACT_SHA256SUMS` hashes the sanitized expanded payload files and excludes itself.

Only actual signed URL `token` query values were replaced with `[REDACTED]` in packaged copies. URL origins, object paths and all other bytes remain unchanged. There are 16 replacements across 10 JSON files; static fake token literals in the captured source patch are unchanged.

| Original relative filename | Token values replaced |
| --- | ---: |
| `16-A-opened-pages.json` | 1 |
| `17-A-opened-pdf.json` | 1 |
| `21-scoped-Alpha-documents.json` | 1 |
| `24-scoped-opened-pages.json` | 2 |
| `26-scoped-Bravo-documents.json` | 2 |
| `41-B-reload.json` | 2 |
| `44-B-opened-pages.json` | 3 |
| `45-B-opened-pdf.json` | 1 |
| `48-close-pdf-3.json` | 2 |
| `48-close-pdf-5.json` | 1 |

All four original PNGs were visually inspected: both one-page synthetic PDF viewers render correctly, the operate Archived screenshot displays403, and the empty-scope Alpha screenshot displays404. No signed token is visible in the PNGs.
