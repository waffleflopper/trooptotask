import subprocess,json,pathlib,datetime,os,re
os.environ['TMPDIR']='/home/waffleflops/.cache/v1376'
os.environ['PATH']='/home/waffleflops/.local/share/mise/installs/node/24.21.0/bin:'+os.environ['PATH']
E=pathlib.Path.cwd()/'.verification/evidence/verify-trooptotask/d28-training-twoport-final-native-20261007'
def call(label,args,helper=False):
 print(label,flush=True)
 assert not (E/(label+'.json')).exists(),label
 cmd=['node','.agents/skills/verify-trooptotask/helpers/control.mjs','--worker','1',*args] if helper else ['npm','run','--silent','verify:app','--',*args,'--worker','1']
 p=subprocess.run(cmd,text=True,capture_output=True)
 if not helper and args[:2]==['tool','get_network_request']:
  def redact(v):
   if isinstance(v,dict):
    if str(v.get('name','')).lower() in ['cookie','set-cookie','authorization','apikey']:return {**v,'value':'[REDACTED]'}
    return {k:'[REDACTED]' if k.lower() in ['cookie','set-cookie','authorization','apikey'] else redact(a) for k,a in v.items()}
   if isinstance(v,list):return [redact(a) for a in v]
   if isinstance(v,str):return re.sub(r'(?im)^([ \-]*(?:cookie|set-cookie|authorization|apikey):).+$',r'\1 [REDACTED]',v)
   return v
  p.stdout=json.dumps(redact(json.loads(p.stdout)))
 payload={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}; f=E/(label+'.json');assert not f.exists(),label;f.write_text(json.dumps(payload,indent=2)+'\n')
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 return json.loads(p.stdout)
def tool(label,name,args):return call(label,['tool',name,json.dumps(args)])
def txt(r):return '\n'.join(x['text'] for x in r.get('content',[]) if x['type']=='text')
def snap(label,page=2):
 r=tool(label,'take_snapshot',{'pageId':page});return r

def walk(node):
 yield node
 for c in node.get('children',[]):yield from walk(c)
def act(label,role,name,page=2,value=None,index=None):
 r=snap(label+'-before',page);nodes=[n for n in walk(r['structuredContent']['snapshot']) if n.get('role')==role and n.get('name')==name];assert len(nodes)==1 or index is not None,(role,name,len(nodes));uid=nodes[index or 0]['id'];a={'pageId':page,'uid':uid};a.update({'value':value} if value is not None else {});return tool(label,'fill' if value is not None else 'click',a)
def shot(label,page=2):return tool(label+'-capture','take_screenshot',{'pageId':page,'filePath':str(E/(label+'.png')),'fullPage':True})
def evaluate(label,fn,page=2):return tool(label,'evaluate_script',{'pageId':page,'function':fn,'waitForStableDom':False})

def result_value(r):
 return json.loads(txt(r).split('```json\n')[1].split('\n```')[0])
def select(label,name,value,page=2):
 act(label+'-open','button',name,page=page)
 r=evaluate(label+'-options',"() => [...document.querySelectorAll('[role=option]')].map(x=>({text:x.textContent.trim(),selected:x.getAttribute('aria-selected')}))",page=page)
 options=result_value(r);i=[x['text'] for x in options].index(value)
 tool(label+'-home','press_key',{'pageId':page,'key':'Home'})
 for k in range(i):tool(label+'-down-'+str(k),'press_key',{'pageId':page,'key':'ArrowDown'})
 tool(label+'-enter','press_key',{'pageId':page,'key':'Enter'})
 return snap(label+'-selected',page)

def wire(label,page,family):
 r=tool(label+'-requests','list_network_requests',{'pageId':page,'resourceTypes':['fetch','xhr'],'includePreservedRequests':True})
 requests=r['structuredContent']['networkRequests'];matching=[x for x in requests if '/api/'+family in x['url'] and x['method']!='GET']
 if not matching:raise RuntimeError('No native matched write '+family)
 x=matching[-1]
 return tool(label,'get_network_request',{'pageId':page,'reqid':x['requestId']})

def act_prefix(label,role,prefix,page=2):
 r=snap(label+'-before',page);nodes=[n for n in walk(r['structuredContent']['snapshot']) if n.get('role')==role and n.get('name','').startswith(prefix)];assert len(nodes)==1,(prefix,len(nodes));return tool(label,'click',{'pageId':page,'uid':nodes[0]['id']})

def get_wire(label,page,family):
 r=tool(label+'-requests','list_network_requests',{'pageId':page,'resourceTypes':['fetch','xhr'],'includePreservedRequests':True})
 requests=r['structuredContent']['networkRequests'];matching=[x for x in requests if '/api/'+family in x['url']]
 if not matching:raise RuntimeError('No native matched request '+family)
 return tool(label,'get_network_request',{'pageId':page,'reqid':matching[-1]['requestId']})
def workbook(label,page,sheets,filename=None):
 file=E/(filename or label+'.xlsx')
 call(label+'-export-arm',['export','arm',str(page)],True)
 act(label+'-export-action','button','Export Excel',page=page)
 call(label+'-export-state',['export','state',str(page)],True)
 call(label+'-export-save',['export','save',str(page),str(file)],True)
 for sheet in sheets: call(label+'-sheet-'+sheet.replace(' ','-'),['workbook',str(file),sheet],True)
 call(label+'-export-restore',['export','restore',str(page)],True)

def within(label,scope_role,scope_name,role,name,page=2,value=None):
 r=snap(label+'-before',page)
 scopes=[n for n in walk(r['structuredContent']['snapshot']) if n.get('role')==scope_role and n.get('name')==scope_name]
 assert len(scopes)==1,(scope_role,scope_name,len(scopes))
 nodes=[n for n in walk(scopes[0]) if n.get('role')==role and n.get('name')==name]
 assert len(nodes)==1,(role,name,len(nodes))
 args={'pageId':page,'uid':nodes[0]['id']}
 if value is not None:args['value']=value
 return tool(label,'fill' if value is not None else 'click',args)

def select_listbox(label,name,value,page=2):
 act(label+'-open','button',name,page)
 r=evaluate(label+'-listboxes',"()=>[...document.querySelectorAll('[role=listbox]')].map(l=>({options:[...l.querySelectorAll('[role=option]')].map(x=>({text:x.textContent.trim(),selected:x.getAttribute('aria-selected')}))}))",page)
 lists=[x['options'] for x in result_value(r) if value in [v['text'] for v in x['options']]]
 assert len(lists)==1,(value,len(lists))
 i=[x['text'] for x in lists[0]].index(value)
 tool(label+'-home','press_key',{'pageId':page,'key':'Home'})
 for k in range(i):tool(label+'-down-'+str(k),'press_key',{'pageId':page,'key':'ArrowDown'})
 tool(label+'-enter','press_key',{'pageId':page,'key':'Enter'})
 evaluate(label+'-selected-buttons',"()=>[...document.querySelectorAll('button[aria-haspopup=listbox]')].map(b=>({text:b.textContent.trim(),label:b.getAttribute('aria-label')}))",page)
 return snap(label+'-selected',page)
