import http from 'node:http';
import fs from 'node:fs';
const [, , fixtureFile, appOrigin] = process.argv;
const server = http.createServer((req, res) => {
	if (new URL(req.url, 'http://localhost').pathname !== '/orgOwner') {
		res.writeHead(404).end();
		return;
	}
	const actor = JSON.parse(fs.readFileSync(fixtureFile, 'utf8')).actors.orgOwner;
	const payload = JSON.stringify({ e: actor.email, p: actor.password }).replace(/</g, '\\u003c');
	res.writeHead(200, { 'content-type': 'text/html', 'cache-control': 'no-store' });
	res.end(`<!doctype html><script>window.name=${JSON.stringify(payload)};location.replace(${JSON.stringify(appOrigin + '/auth/login')});</script>`);
	console.log(new Date().toISOString(), 'served orgOwner relay once; closing');
	server.close();
});
server.listen(0, 'localhost', () => console.log(new Date().toISOString(), 'relay port', server.address().port));
setTimeout(() => {
	console.log(new Date().toISOString(), 'relay expired unused');
	process.exit(0);
}, 120000).unref();
