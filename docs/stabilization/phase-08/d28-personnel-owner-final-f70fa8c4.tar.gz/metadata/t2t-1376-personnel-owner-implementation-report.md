The bounded Personnel owner implementation is complete and source writes/tests are CLOSED. Integrate `c086773406b26c678de29adf1939db463d2aa68f`, tree `d405b64c503947e2bd2d87496432bdd4ff62d92e`, from sole base `15f6787bfd43fcb623a22b70c7d578fe53b4c295`. Commit has exactly 39 exclusive paths: 12 added, 23 modified, 4 deleted, 1,396 insertions/717 deletions. No shared contract/index/context/reverse-feature/manifest/toolkit/recipe/doc paths are committed.

Root's copied `contracts.ts` remains the only working diff, uncommitted and never edited by this worker; SHA256 `dd67ed9a99bb06b4e4188124371414146cec9b32f24229ee37f79d73b2ae644b`. It is agreed read-only input, deliberately absent from this commit. The adjacent `t2t-1376-personnel-owner-implementation-ledger.json` records exact membership and identity. Root should integrate the complete owned commit with its independently maintained contract/composition/caller work.

Four ordinary factories now implement the selected contracts: `createSupabasePersonnelRosterReader(client,orgId,scope?)`, `createSupabasePersonnelRecordPersistence(client,orgId,scope?)`, `createSupabaseGroupPersistence(client,orgId)` and `createSupabaseSelfPinPersistence(client,orgId,userId)`. Personnel read scope is copied/normalized once; empty scope/IDs short-circuit. Writes stay ordinary Organization/RLS effects governed by use-case policy rather than app read filtering. Stable primary plus ID order completes pages. Private Personnel mapping retains current null/default fields and same-org Group join. CRUD acknowledgements are joined; updateDates acknowledgement remains unjoined with empty Group name. Archive mutation retains `.select('*').single()` acknowledgement before void return. Only named `23505 personnel_org_slug_key` metadata is preserved exactly; other errors keep existing plain message behavior. Bulk uncertain effects are never automatically probed/replayed. Pin replace retains delete→ordered insert and acknowledged deletion after insert failure. No migration, cache, transaction, stricter validation or new concurrency was added.

Owner operations, roster/Group/pin wrappers, rank validation and detail now consume fixed ports. Rank validator receives `loadRankCatalog()`; normalization/admission semantics remain unchanged. Privileged Calendar/Training/ICT/Onboarding roster providers use the new private projection/map while retaining their existing purpose guards, scopes and lazy admin opening. After a zero remaining owned importer census, the Personnel entity/mapping test, Group entity and PersonnelBatchContext were removed. Protected #1552 UI sources/tests, Calendar permanent remover/DELETE operation/route are byte-identical to base. Preserved private Personnel owner remains clean at exact52a8a036/tree6ebc1d30; no preserved checkout was edited. No SQL, global facade or neighboring row-family owner was changed.

Context signatures for parent composition:

| Consumer | Required fixed fields, in addition to existing auth/audit/other owned capabilities |
| --- | --- |
| Create/edit | personnel findWriteReference/create/updateEditable; organizationPersonnel listSlugCandidates; groups findReference; loadRankCatalog |
| Import | personnel listImportSlugs/createMany; groups listCatalog; loadRankCatalog |
| Backfill | personnel listBackfillCandidates/updateDates; groups listCatalog; loadRankCatalog |
| Lifecycle | personnel listArchiveCandidates/setArchivedAt/delete; organizationPersonnel findWriteReference/findArchiveEvent; existing artifactWrites |
| Detail/readiness | organizationPersonnel findBySlug/findById; existing scope |
| Roster/count | roster list/countArchived; caller binds organizationRoster explicitly for ordinary reads |
| Group catalog/names/writes | groups narrow Picks for each consumed method |
| Pin names/writes | selfPins listNames or insert/removeName/replaceNames |

Test-only `inMemoryPersonnelPersistence.server.ts` supplies `createInMemoryPersonnelRecordPersistence(store,orgId)`, `createInMemoryPersonnelRosterReader(store,orgId)`, `createInMemoryGroupPersistence(store,orgId)` and `createInMemorySelfPinPersistence(store,orgId,userId)`. It reads store methods dynamically, preserving existing fault injection. It shares the Personnel map rather than a production generic backing. Root may use these factories from test-only inMemory; keep them and `personnelPersistence.test-support.server.ts` out of production index. The latter binds current local test contexts only. Root copied the memory factory file as input while completing reverse test composition; root retains manifest ownership.

Actual checks used Node24.21.0 first in PATH, npm11.19.0, login disabled and worktree-local output. Dependencies were linked into this worktree without installs or lock changes; `.vite`/`.vite-temp`/`.cache` were excluded from shared links.

| Selected command/evidence | Actual result | Cache log |
| --- | --- | --- |
| 12 existing owner operation/detail/roster/purpose suites, Vitest maxWorkers2 | 12 suites / 168 tests PASS | `t2t-1376-personnel-owner-focused-first.log` |
| Four new installed-SDK suites, first run | 13 PASS / 1 failed: new transport fixture omitted exact-count Content-Range. This was a fixture defect, not accepted application failure. | `t2t-1376-personnel-owner-sdk-first.log` |
| Four SDK suites after fixture correction | 4 suites / 14 tests PASS | `t2t-1376-personnel-owner-sdk-green.log` |
| Final CRUD-only rerun after removing redundant update parse | 1 suite / 32 tests PASS; other behavior/source inputs unchanged | `t2t-1376-personnel-owner-record-final.log` |
| Controlled removal of unique ID paging order | Selected complete-tie paging regression fails; original bytes restored | `t2t-1376-personnel-owner-counterfactual-personnelRosterReader.server.ts.log` |
| Controlled dropping of named slug code/details | Selected metadata/uncertain-effect regression fails; original bytes restored | `t2t-1376-personnel-owner-counterfactual-personnelPersistenceMapping.server.ts.log` |
| Touched Prettier/ESLint and git diff --check | All PASS | `t2t-1376-personnel-owner-format-lint-final.log` |
| Initial touched formatting | One unformatted self-pin provider; formatted, final check passed | `t2t-1376-personnel-owner-format-lint.log` |
| Local npm run check with non-secret compile placeholders | 75 errors / 0 warnings while root callers/context were not integrated. Two owned optional backfill date errors corrected; remaining integrated type result belongs to root. No 0-error claim here. | `t2t-1376-personnel-owner-check-first.log` |

The check placeholders were `PUBLIC_SUPABASE_URL=http://127.0.0.1:56321`, `PUBLIC_SUPABASE_ANON_KEY=your_local_anon_key`; no service was started/contacted by that compiler command. Existing tests preserve denied/no-effect, hidden slug collision, redacted/named splitting, uncertain committed writes/no replay, backfill ordered acknowledgement and lifecycle partial/retry/audit behavior. New SDK tests prove ordinary credentials, captured org/user/scope, complete tie pages, minimal/null references, archive/all-status/backfill separation, known DTO/default/null/join effects, mutation acknowledgement, named metadata, uncertain write and self-pin partial failure. They do not prove hosted RLS or SQL FK effects. No final native acceptance is claimed.

Full project tests/build, merged caller/type/governance checks, native affected verification, independent complete acceptance and PR actions remain with root. This worktree's isolated types cannot substitute for combined composition validation. No services, browser, database operation, full build/test sequence, remote action, PR/publication or nested agent occurred. Normal Git maintenance hook reported checkout/configuration verification during authorized commit; no database action was initiated. All owned command sessions completed. D28 remains open for other domains and final facade work; historical failed/unrun proof retains its original status.

Exact committed paths:

- `src/features/personnel/calendarRoster.server.ts`
- `src/features/personnel/criticalTasksRoster.server.ts`
- `src/features/personnel/groupCatalog.server.ts`
- `src/features/personnel/groupEntity.server.ts`
- `src/features/personnel/groupOperations.server.ts`
- `src/features/personnel/groupPersistence.server.test.ts`
- `src/features/personnel/groupPersistence.server.ts`
- `src/features/personnel/inMemoryPersonnelPersistence.server.ts`
- `src/features/personnel/onboardingRoster.server.ts`
- `src/features/personnel/personnelBatch.server.test.ts`
- `src/features/personnel/personnelBatch.server.ts`
- `src/features/personnel/personnelBatchContext.server.ts`
- `src/features/personnel/personnelDateBackfill.server.test.ts`
- `src/features/personnel/personnelDateBackfill.server.ts`
- `src/features/personnel/personnelDetail.server.test.ts`
- `src/features/personnel/personnelDetail.server.ts`
- `src/features/personnel/personnelEntity.server.test.ts`
- `src/features/personnel/personnelEntity.server.ts`
- `src/features/personnel/personnelLifecycle.server.test.ts`
- `src/features/personnel/personnelLifecycle.server.ts`
- `src/features/personnel/personnelPersistence.test-support.server.ts`
- `src/features/personnel/personnelPersistenceMapping.server.ts`
- `src/features/personnel/personnelRecordOperations.server.test.ts`
- `src/features/personnel/personnelRecordOperations.server.ts`
- `src/features/personnel/personnelRecordPersistence.server.test.ts`
- `src/features/personnel/personnelRecordPersistence.server.ts`
- `src/features/personnel/personnelRosterReader.server.test.ts`
- `src/features/personnel/personnelRosterReader.server.ts`
- `src/features/personnel/personnelSlug.server.ts`
- `src/features/personnel/pinnedGroupNames.server.test.ts`
- `src/features/personnel/pinnedGroupNames.server.ts`
- `src/features/personnel/pinnedGroupOperations.server.ts`
- `src/features/personnel/rankValidation.server.ts`
- `src/features/personnel/rosterRead.server.test.ts`
- `src/features/personnel/rosterRead.server.ts`
- `src/features/personnel/selfPinPersistence.server.test.ts`
- `src/features/personnel/selfPinPersistence.server.ts`
- `src/features/personnel/test-support/personnelProvider.ts`
- `src/features/personnel/trainingRoster.server.ts`
