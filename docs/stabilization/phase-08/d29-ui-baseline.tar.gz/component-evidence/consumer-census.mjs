import { readFileSync } from 'node:fs';
import { scanRepository } from '../../scripts/module-imports.ts';
import { checkModuleBoundaries } from '../../scripts/module-boundaries.ts';

const graph = scanRepository(process.cwd());
const families = ['tooltip', 'alert-dialog', 'dialog', 'calendar', 'range-calendar', 'pagination'];
const production = (file) => !(/\.test\.|Test\.svelte$/.test(file));
const runtime = graph.edges.filter((edge) => edge.classification === 'local' && edge.to && !edge.typeOnly && edge.kind !== 'import-type');
const manifest = JSON.parse(readFileSync('scripts/module-boundaries.json', 'utf8'));
const cycles = checkModuleBoundaries(graph, manifest).filter((issue) => issue.kind === 'source-cycle' && families.some((family) => issue.message.includes(`/ui/${family}/`)));
const consumers = families.map((family) => {
  const root = `src/lib/components/ui/${family}/`;
  const direct = [...new Set(runtime.filter((edge) => edge.to.startsWith(root) && !edge.from.startsWith(root) && production(edge.from)).map((edge) => edge.from))].sort();
  const reached = new Set(graph.sourcePaths.filter((file) => file.startsWith(root)));
  let changed = true;
  while (changed) {
    changed = false;
    for (const edge of runtime) {
      if (reached.has(edge.to) && !reached.has(edge.from)) {
        reached.add(edge.from);
        changed = true;
      }
    }
  }
  const reverse = [...reached].filter((file) => !file.startsWith(root) && production(file)).sort();
  return { family, directCount: direct.length, direct, reverseCount: reverse.length, reverse };
});
console.log(JSON.stringify({ sourceCount: graph.sourcePaths.length, failures: graph.failures, cycles, consumers }, null, 2));
if (graph.failures.length) process.exitCode = 1;
