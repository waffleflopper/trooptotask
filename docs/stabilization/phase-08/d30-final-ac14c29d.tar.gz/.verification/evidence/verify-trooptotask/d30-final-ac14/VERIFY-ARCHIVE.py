from pathlib import Path
import hashlib
import json

root = Path(".verification/evidence/verify-trooptotask/d30-final-ac14")
inventory = root / "INVENTORY.sha256"
expected = {}
for line in inventory.read_text().splitlines():
    digest, name = line.split("  ", 1)
    assert name not in expected, f"Duplicate inventory path: {name}"
    path = Path(name)
    assert not path.is_absolute() and ".." not in path.parts, "Unsafe path"
    assert path.is_relative_to(root), "Path outside the evidence directory"
    expected[name] = digest
actual = {p.as_posix() for p in root.rglob("*") if p.is_file() and p != inventory}
assert actual == set(expected), {"missing": sorted(set(expected) - actual), "extra": sorted(actual - set(expected))}
for name, digest in expected.items():
    path = Path(name)
    assert not path.is_symlink(), f"Unexpected symlink: {name}"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, f"Hash mismatch: {name}"
print(json.dumps({"status": "PASS", "payloadFiles": len(expected), "fileSetMatches": True, "allExpandedHashesMatch": True}, indent=2))
