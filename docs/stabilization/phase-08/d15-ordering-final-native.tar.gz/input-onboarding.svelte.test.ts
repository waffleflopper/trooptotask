import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { onboardingStore } from './onboarding.svelte';
import type { PersonnelOnboarding } from '../onboarding.types';

const mockOnboarding: PersonnelOnboarding = {
	id: 'ob-1',
	personnelId: 'p-1',
	templateId: null,
	status: 'in_progress',
	startedAt: '2026-03-01',
	completedAt: null,
	cancelledAt: null,
	steps: [
		{
			id: 'step-1',
			onboardingId: 'ob-1',
			templateStepId: null,
			stepName: 'Inprocess',
			stepType: 'checkbox',
			trainingTypeId: null,
			stages: null,
			sortOrder: 0,
			completed: false,
			currentStage: null,
			notes: [],
			active: true
		}
	]
};

const paperworkOnboarding: PersonnelOnboarding = {
	...mockOnboarding,
	steps: [
		{
			...mockOnboarding.steps[0],
			stepType: 'paperwork',
			stages: ['Submitted', 'Reviewed', 'Filed'],
			currentStage: 'Submitted',
			notes: [{ text: 'Saved work', timestamp: '2026-10-01T12:00:00.000Z', userId: 'operator' }]
		}
	]
};

function deferredResponse() {
	let respond!: (response: Response) => void;
	const promise = new Promise<Response>((resolve) => {
		respond = resolve;
	});
	return { promise, respond };
}

describe('onboardingStore - load during in-flight mutations (issue #113)', () => {
	beforeEach(() => {
		vi.restoreAllMocks();
		onboardingStore.load([], 'reset');
		onboardingStore.load([], 'org-1');
	});
	afterEach(() => vi.unstubAllGlobals());

	it('retains confirmed Filed after an earlier Reviewed response arrives last', async () => {
		const original = paperworkOnboarding;
		onboardingStore.load([original], 'org-1');
		let reviewedResponse!: (response: Response) => void;
		let filedResponse!: (response: Response) => void;
		vi.stubGlobal(
			'fetch',
			vi
				.fn()
				.mockImplementationOnce(() => new Promise<Response>((resolve) => (reviewedResponse = resolve)))
				.mockImplementationOnce(() => new Promise<Response>((resolve) => (filedResponse = resolve)))
		);

		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');
		const expected = { ...original, steps: [{ ...original.steps[0], currentStage: 'Filed', completed: true }] };
		expect(onboardingStore.getById('ob-1')).toEqual(expected);

		filedResponse(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(filed).resolves.toBe(true);
		expect.soft(onboardingStore.getById('ob-1')).toEqual(expected);

		reviewedResponse(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
	});

	it('keeps an earlier pending stage when the newer request fails and permits retry', async () => {
		onboardingStore.load([paperworkOnboarding], 'org-1');
		const reviewedResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValueOnce(reviewedResponse.promise).mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');

		filedResponse.respond(Response.json({ message: 'Save failed' }, { status: 500 }));
		await expect(filed).resolves.toBe(false);
		const expectedReviewed = {
			...paperworkOnboarding,
			steps: [{ ...paperworkOnboarding.steps[0], currentStage: 'Reviewed' }]
		};
		expect(onboardingStore.getById('ob-1')).toEqual(expectedReviewed);

		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expectedReviewed);

		vi.mocked(fetch).mockResolvedValueOnce(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(onboardingStore.advanceStage('step-1', 'Filed')).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual({
			...paperworkOnboarding,
			steps: [{ ...paperworkOnboarding.steps[0], currentStage: 'Filed', completed: true }]
		});
	});

	it('rolls back a later failed stage to the earlier confirmed selection', async () => {
		onboardingStore.load([paperworkOnboarding], 'org-1');
		const reviewedResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValueOnce(reviewedResponse.promise).mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');

		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual({
			...paperworkOnboarding,
			steps: [{ ...paperworkOnboarding.steps[0], currentStage: 'Filed', completed: true }]
		});

		filedResponse.respond(Response.json({ message: 'Save failed' }, { status: 500 }));
		await expect(filed).resolves.toBe(false);
		expect(onboardingStore.getById('ob-1')).toEqual({
			...paperworkOnboarding,
			steps: [{ ...paperworkOnboarding.steps[0], currentStage: 'Reviewed' }]
		});
	});

	it('preserves a different pending checkbox while retiring an older stage selection', async () => {
		const checkbox = { ...mockOnboarding.steps[0], id: 'checkbox-2', stepName: 'Orientation' };
		onboardingStore.load([{ ...paperworkOnboarding, steps: [...paperworkOnboarding.steps, checkbox] }], 'org-1');
		const reviewedResponse = deferredResponse();
		const checkboxResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi
				.fn()
				.mockReturnValueOnce(reviewedResponse.promise)
				.mockReturnValueOnce(checkboxResponse.promise)
				.mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const checked = onboardingStore.toggleCheckbox('checkbox-2', true);
		const filed = onboardingStore.advanceStage('step-1', 'Filed');
		const expected = {
			...paperworkOnboarding,
			steps: [
				{ ...paperworkOnboarding.steps[0], currentStage: 'Filed', completed: true },
				{ ...checkbox, completed: true }
			]
		};

		filedResponse.respond(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(filed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		checkboxResponse.respond(Response.json({ currentStage: null, completed: true }));
		await expect(checked).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
	});

	it('adopts saved notes without bringing back a superseded pending stage', async () => {
		onboardingStore.load([paperworkOnboarding], 'org-1');
		const reviewedResponse = deferredResponse();
		const noteResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi
				.fn()
				.mockReturnValueOnce(reviewedResponse.promise)
				.mockReturnValueOnce(noteResponse.promise)
				.mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const noted = onboardingStore.addNote('step-1', 'Filed with clinic');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');

		filedResponse.respond(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(filed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')?.steps[0]).toMatchObject({
			currentStage: 'Filed',
			completed: true,
			notes: [{ text: 'Filed with clinic', userId: '' }, ...paperworkOnboarding.steps[0].notes]
		});

		const notes = [
			...paperworkOnboarding.steps[0].notes,
			{ text: 'Another committed note', timestamp: '2026-10-02T12:00:00.001Z', userId: 'other-author' },
			{ text: 'Filed with clinic', timestamp: '2026-10-02T12:00:00.002Z', userId: 'operator' }
		];
		noteResponse.respond(Response.json({ id: 'step-1', notes }));
		await expect(noted).resolves.toBe(true);
		const expected = {
			...paperworkOnboarding,
			steps: [{ ...paperworkOnboarding.steps[0], currentStage: 'Filed', completed: true, notes }]
		};
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
	});

	it.each([200, 500])('keeps the confirmed stage when a pending deprecated-step removal returns %s', async (status) => {
		const deprecated = {
			...mockOnboarding.steps[0],
			id: 'obsolete-step',
			stepName: 'Retired work',
			active: false,
			completed: true,
			notes: [{ text: 'Keep saved history', timestamp: '2026-09-01T12:00:00.000Z', userId: 'author' }]
		};
		onboardingStore.load([{ ...paperworkOnboarding, steps: [...paperworkOnboarding.steps, deprecated] }], 'org-1');
		const reviewedResponse = deferredResponse();
		const removalResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi
				.fn()
				.mockReturnValueOnce(reviewedResponse.promise)
				.mockReturnValueOnce(removalResponse.promise)
				.mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const removed = onboardingStore.removeDeprecatedStep('obsolete-step');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');
		const savedPaperwork = { ...paperworkOnboarding.steps[0], currentStage: 'Filed', completed: true };

		filedResponse.respond(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(filed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual({ ...paperworkOnboarding, steps: [savedPaperwork] });
		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual({ ...paperworkOnboarding, steps: [savedPaperwork] });

		removalResponse.respond(Response.json({ success: status === 200 }, { status }));
		await expect(removed).resolves.toBe(status === 200);
		expect(onboardingStore.getById('ob-1')).toEqual({
			...paperworkOnboarding,
			steps: status === 200 ? [savedPaperwork] : [savedPaperwork, deprecated]
		});
	});

	it('rebases pending stages over fresh same-organization saved work', async () => {
		onboardingStore.load([paperworkOnboarding], 'org-1');
		const reviewedResponse = deferredResponse();
		const filedResponse = deferredResponse();
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValueOnce(reviewedResponse.promise).mockReturnValueOnce(filedResponse.promise)
		);
		const reviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		const filed = onboardingStore.advanceStage('step-1', 'Filed');
		const refreshed = {
			...paperworkOnboarding,
			startedAt: '2026-03-02',
			steps: [
				{
					...paperworkOnboarding.steps[0],
					notes: [{ text: 'Fresh saved note', timestamp: '2026-10-02T12:00:00.000Z', userId: 'other-author' }]
				},
				{ ...mockOnboarding.steps[0], id: 'checkbox-2', completed: true }
			]
		};
		onboardingStore.load([refreshed], 'org-1');
		const expected = {
			...refreshed,
			steps: [{ ...refreshed.steps[0], currentStage: 'Filed', completed: true }, refreshed.steps[1]]
		};
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		filedResponse.respond(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(filed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		reviewedResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(reviewed).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
	});

	it('ignores a response after disposal without disturbing a new same-organization request', async () => {
		onboardingStore.load([paperworkOnboarding], 'org-1');
		const oldResponse = deferredResponse();
		const newResponse = deferredResponse();
		vi.stubGlobal('fetch', vi.fn().mockReturnValueOnce(oldResponse.promise).mockReturnValueOnce(newResponse.promise));
		const oldReviewed = onboardingStore.advanceStage('step-1', 'Reviewed');
		onboardingStore.invalidatePendingRequests();
		const refreshed = { ...paperworkOnboarding, startedAt: '2026-03-02' };
		onboardingStore.load([refreshed], 'org-1');
		const newFiled = onboardingStore.advanceStage('step-1', 'Filed');
		const expected = { ...refreshed, steps: [{ ...refreshed.steps[0], currentStage: 'Filed', completed: true }] };

		oldResponse.respond(Response.json({ currentStage: 'Reviewed', completed: false }));
		await expect(oldReviewed).resolves.toBe(false);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
		newResponse.respond(Response.json({ currentStage: 'Filed', completed: true }));
		await expect(newFiled).resolves.toBe(true);
		expect(onboardingStore.getById('ob-1')).toEqual(expected);
	});

	it('adopts authoritative note attribution and another committed note instead of retaining its optimistic placeholder', async () => {
		const originalNote = { text: 'Original note', timestamp: '2026-09-01T12:00:00.000Z', userId: 'original-author' };
		onboardingStore.load(
			[{ ...mockOnboarding, steps: [{ ...mockOnboarding.steps[0], notes: [originalNote] }] }],
			'org-1'
		);
		const notes = [
			originalNote,
			{ text: 'Another committed note', timestamp: '2026-10-01T12:00:00.001Z', userId: 'other-author' },
			{ text: 'Sent to clinic', timestamp: '2026-10-01T12:00:00.002Z', userId: 'operator' }
		];
		vi.stubGlobal('fetch', vi.fn().mockResolvedValue(Response.json({ id: 'step-1', notes })));

		await expect(onboardingStore.addNote('step-1', 'Sent to clinic')).resolves.toBe(true);

		expect(onboardingStore.getById('ob-1')?.steps[0].notes).toEqual(notes);
	});

	it('removes an unsuccessful optimistic note while retaining saved notes', async () => {
		const originalNote = { text: 'Original note', timestamp: '2026-09-01T12:00:00.000Z', userId: 'original-author' };
		onboardingStore.load(
			[{ ...mockOnboarding, steps: [{ ...mockOnboarding.steps[0], notes: [originalNote] }] }],
			'org-1'
		);
		vi.stubGlobal(
			'fetch',
			vi.fn().mockResolvedValue(Response.json({ message: 'Note append failed' }, { status: 500 }))
		);

		await expect(onboardingStore.addNote('step-1', 'Uncommitted note')).resolves.toBe(false);

		expect(onboardingStore.getById('ob-1')?.steps[0].notes).toEqual([originalNote]);
	});

	it.each(['cancel', 'complete'] as const)(
		'rolls back optimistic %s after a 409 while retaining saved work and notes',
		async (operation) => {
			const original = {
				...mockOnboarding,
				steps: [
					{
						...mockOnboarding.steps[0],
						completed: true,
						notes: [{ text: 'Saved work', timestamp: '2026-09-01T12:00:00.000Z', userId: 'author-1' }]
					},
					{
						...mockOnboarding.steps[0],
						id: 'inactive-training',
						stepType: 'training' as const,
						trainingTypeId: 'training-1',
						active: false,
						completed: true
					}
				]
			};
			onboardingStore.load([original], 'org-1');
			let respond!: (response: Response) => void;
			vi.stubGlobal(
				'fetch',
				vi.fn(
					() =>
						new Promise<Response>((resolve) => {
							respond = resolve;
						})
				)
			);

			const pending =
				operation === 'cancel' ? onboardingStore.cancelOnboarding('ob-1') : onboardingStore.completeOnboarding('ob-1');
			expect(onboardingStore.getById('ob-1')?.status).toBe(operation === 'cancel' ? 'cancelled' : 'completed');
			respond(Response.json({ message: 'Onboarding changed before persistence' }, { status: 409 }));

			await expect(pending).resolves.toBe(false);
			expect(onboardingStore.items).toEqual([original]);
		}
	);

	it('resyncs the template and steps when another user has switched the packet', async () => {
		onboardingStore.load([{ ...mockOnboarding, templateId: 'template-a' }], 'org-1');
		const steps = [{ ...mockOnboarding.steps[0], templateStepId: 'template-b-step', stepName: 'Equipment' }];
		vi.stubGlobal('fetch', vi.fn().mockResolvedValue(Response.json({ templateId: 'template-b', steps })));

		await expect(onboardingStore.resync('ob-1')).resolves.toEqual({ success: true });

		expect(onboardingStore.getById('ob-1')).toEqual({ ...mockOnboarding, templateId: 'template-b', steps });
	});

	it.each([
		[
			'start',
			() => onboardingStore.startOnboarding('p-new', '2026-03-15', 'template-1'),
			{ ...mockOnboarding, id: 'ob-new', personnelId: 'p-new' }
		],
		['checkbox', () => onboardingStore.toggleCheckbox('step-1', true), { completed: true, currentStage: null }],
		['stage', () => onboardingStore.advanceStage('step-1', 'Filed'), { completed: true, currentStage: 'Filed' }],
		[
			'note',
			() => onboardingStore.addNote('step-1', 'Received'),
			{ notes: [{ text: 'Received', userId: 'u-1', timestamp: '2026-03-15T12:00:00Z' }] }
		],
		['remove', () => onboardingStore.removeDeprecatedStep('step-1'), { success: true }],
		['resync', () => onboardingStore.resync('ob-1'), { steps: [] }],
		['switch', () => onboardingStore.switchTemplate('ob-1', 'template-2'), { templateId: 'template-2', steps: [] }],
		['assign', () => onboardingStore.assignTemplate('ob-1', 'template-2'), { templateId: 'template-2', steps: [] }],
		[
			'cancel',
			() => onboardingStore.cancelOnboarding('ob-1'),
			{ status: 'cancelled', cancelledAt: '2026-03-15', completedAt: null }
		],
		[
			'complete',
			() => onboardingStore.completeOnboarding('ob-1'),
			{ status: 'completed', completedAt: '2026-03-15', cancelledAt: null }
		]
	] as const)(
		'ignores a late %s result after leaving and re-entering the organization',
		async (name, mutate, result) => {
			const original = {
				...mockOnboarding,
				templateId: name === 'assign' ? null : 'template-1',
				steps: [
					{
						...mockOnboarding.steps[0],
						stepType: name === 'stage' ? ('paperwork' as const) : ('checkbox' as const),
						stages: name === 'stage' ? ['Submitted', 'Reviewed', 'Filed'] : null,
						active: name !== 'remove'
					}
				]
			};
			onboardingStore.load([original], 'org-1');
			let respond!: (response: Response) => void;
			vi.stubGlobal(
				'fetch',
				vi.fn(
					() =>
						new Promise<Response>((resolve) => {
							respond = resolve;
						})
				)
			);
			const pending = mutate();
			// Entering B invalidates A immediately, even before B's workspace has loaded.
			onboardingStore.enterOrganization('org-2');
			const refreshed = { ...original, startedAt: '2026-03-16' };
			onboardingStore.load([refreshed], 'org-1');
			respond(Response.json(result));
			await pending;
			expect(onboardingStore.items).toEqual([refreshed]);
		}
	);

	it('ignores a start response whose body arrives after the organization changes', async () => {
		let body!: (packet: PersonnelOnboarding) => void;
		let reading!: () => void;
		const startedReading = new Promise<void>((resolve) => {
			reading = resolve;
		});
		vi.stubGlobal(
			'fetch',
			vi.fn().mockResolvedValue({
				ok: true,
				json: () => {
					reading();
					return new Promise<PersonnelOnboarding>((resolve) => {
						body = resolve;
					});
				}
			})
		);
		const pending = onboardingStore.startOnboarding('p-1', '2026-03-15', 'template-1');
		await startedReading;
		onboardingStore.enterOrganization('org-2');
		body(mockOnboarding);
		await expect(pending).resolves.toBeNull();
		expect(onboardingStore.items).toEqual([]);
	});

	it('should not clobber optimistic toggleCheckbox when load is called mid-flight', async () => {
		onboardingStore.load([mockOnboarding], 'org-1');

		let resolveFetch!: (value: unknown) => void;
		const fetchPromise = new Promise((resolve) => {
			resolveFetch = resolve;
		});
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValue(
				fetchPromise.then(() => ({
					ok: true,
					status: 200,
					json: () => Promise.resolve({ completed: true, currentStage: null })
				}))
			)
		);

		const updatePromise = onboardingStore.toggleCheckbox('step-1', true);

		// Optimistic: step should show completed
		const ob = onboardingStore.getById('ob-1');
		expect(ob?.steps[0].completed).toBe(true);

		// Stale load (step not completed)
		onboardingStore.load([mockOnboarding], 'org-1');

		// Should NOT clobber optimistic update
		const obAfterLoad = onboardingStore.getById('ob-1');
		expect(obAfterLoad?.steps[0].completed).toBe(true);

		resolveFetch(undefined);
		await updatePromise;
	});

	it('should allow load when org changes during in-flight mutation', async () => {
		onboardingStore.load([mockOnboarding], 'org-1');

		let resolveFetch!: (value: unknown) => void;
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValue(
				new Promise((resolve) => {
					resolveFetch = resolve;
				}).then(() => ({ ok: true, status: 200, json: () => Promise.resolve({ completed: true, currentStage: null }) }))
			)
		);

		const pending = onboardingStore.toggleCheckbox('step-1', true);

		// Different org — should go through
		onboardingStore.load([], 'org-2');
		expect(onboardingStore.items).toEqual([]);

		resolveFetch(undefined);
		await expect(pending).resolves.toBe(false);
		expect(onboardingStore.items).toEqual([]);
	});

	it('includes the selected start date when creating an onboarding', async () => {
		onboardingStore.load([], 'org-1');
		vi.stubGlobal(
			'fetch',
			vi.fn().mockResolvedValue({
				ok: true,
				status: 200,
				json: () => Promise.resolve(mockOnboarding)
			})
		);

		await onboardingStore.startOnboarding('p-1', '2026-03-15', 'template-1');

		expect(fetch).toHaveBeenCalledWith('/org/org-1/api/onboarding', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ personnelId: 'p-1', templateId: 'template-1', startedAt: '2026-03-15' })
		});
	});

	it('uses the local calendar date for optimistic completion', async () => {
		const originalTimezone = process.env.TZ;
		process.env.TZ = 'America/Anchorage';
		vi.useFakeTimers();
		vi.setSystemTime(new Date('2026-05-05T02:00:00.000Z'));
		onboardingStore.load([mockOnboarding], 'org-1');

		let resolveFetch!: (value: unknown) => void;
		vi.stubGlobal(
			'fetch',
			vi.fn().mockReturnValue(
				new Promise((resolve) => {
					resolveFetch = resolve;
				})
			)
		);

		try {
			const updatePromise = onboardingStore.completeOnboarding('ob-1');

			expect(onboardingStore.getById('ob-1')).toMatchObject({
				status: 'completed',
				completedAt: '2026-05-04'
			});
			expect(fetch).toHaveBeenCalledWith('/org/org-1/api/onboarding', {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ id: 'ob-1', status: 'completed', completedAt: '2026-05-04' })
			});

			resolveFetch({
				ok: true,
				status: 200,
				json: async () => ({ status: 'completed', completedAt: '2026-05-04', cancelledAt: null })
			});
			await expect(updatePromise).resolves.toBe(true);
		} finally {
			vi.useRealTimers();
			if (originalTimezone === undefined) {
				delete process.env.TZ;
			} else {
				process.env.TZ = originalTimezone;
			}
		}
	});
});
