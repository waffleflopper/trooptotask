# Onboarding ordinary persistence baseline brief

This is a selection and execution brief, not executed proof. Drive the unchanged application at f064ae099ab4354cca9c87792f5167a9b3c54230 before implementing the accepted 16-method Catalog and 10-method Workflow ports. Use one owned worker sequentially. Freeze source, recipes, helpers, bounded request/readback drivers and this plan before launch. Do not edit live source. A failed affected baseline blocks cutover until repaired and accepted; retain the actual failure.

Read both complete maintained recipes. Their procedures supply controls and expected behavior; the bounded selection below determines which families need fresh observations. Do not run every procedure in the 200-line packet recipe automatically.

## Preflight and commands

Use Node24.21.0 and a task-specific TMPDIR. Root's prerequisite info is separate parent-run evidence, not this reviewer's execution. Consult help, then use these exact argument positions. Native verify:app worker selection is a command suffix; control.mjs worker selection precedes its subcommand.

```bash
npm run --silent verify:app -- --help
npm run --silent verify:app -- info --worker 1
npm run --silent verify:app -- launch --worker 1
npm run --silent verify:app -- doctor --worker 1
npm run --silent verify:app -- tools --worker 1
V='node .agents/skills/verify-trooptotask/helpers/control.mjs --worker 1'
$V fixture
$V actor onboardingConfigure onboarding/templates
$V rows onboarding_templates orgA
$V rows onboarding_template_steps orgA
$V rows personnel_onboardings orgA
$V rows onboarding_step_progress orgA
npm run --silent verify:app -- tool take_snapshot '{"pageId":ACTUAL_PAGE_ID,"filePath":".verification/evidence/verify-trooptotask/RUN/before.txt"}' --worker 1
```

Substitute actual run directory, page IDs and JSON, not the illustrative ACTUAL_PAGE_ID token. Keep evidence outside the disposable private worker. Require matching doctor session, origin, candidate, revision, browser/Node version and actual fixture date. Capture process PID/start/group, owned ports and complete container/network/volume identities plus preexisting inventories before launch. A full-machine comparison failure must remain separate from owned disposal.

Before any setup, capture complete raw A/B rows for all four Onboarding tables, Personnel/Groups/ranks, Training types/completions and used memberships/grants. The rows helper is projected evidence. A frozen provider reader restricted to doctor-owned tables/Organizations is needed for all-column/key/timestamp comparisons; do not describe projected captures as full rows. Record seeded and ordinary-generated IDs separately before cleanup. Preserve the original March packet as an independent witness.

The current onboarding-request helper admits ONLY onboarding POST/PUT, onboarding-steps PUT/DELETE and onboarding-resync POST. It does not admit catalog, Getting Started or starter-pack endpoints. Use the already accepted bounded normal-session request procedure for those endpoints if available. If missing, prepare a narrow fixed-family capture before launch and review it; do not pretend the workflow helper covers catalog denial. No arbitrary SQL, service-role authorization probe or invocation of application handlers supplies ordinary-request credit.

## Ordered batch 1. Catalog and ordinary workspace

As Onboarding-only Configure, load Templates, Start and shared labels. Confirm A's three step meanings/order and A Training choices, no B labels, Personnel choices despite other lanes none, and no Add Person. Create one uniquely tagged temporary template with description; save/reload, edit same ID, clear description to null, cancel a draft without effects. Create checkbox, paperwork and Training steps. Save distinct stages/order, edit a step through Training/checkbox/paperwork types and verify irrelevant fields clear with the same ID. Reorder through native controls and compare exact IDs/saved sort orders. Duplicate a configured template twice, inspect distinct names and new parent/step IDs with retained source descriptions/stages/Training references; preserve original source rows. Delete one temporary step and unlinked copy through confirmations/readbacks.

Capture full actual catalog request/response and SQL key sets, not only visible labels. Required saved Template is five keys; Step is ten including raw organization_id and created_at. Read-only DTO boundary observations cover nullable template created time using existing lower arranged rows, not privileged edits to the original fixture. New native null-time fixture is unnecessary.

Use one template save and one step save client503 with readable error, retained draft, unchanged rows and visible real retry/reload. These are representative changed wiring consumers. Reuse unchanged reorder/duplicate/delete-specific client recovery and late-result matrices at their accepted bindings rather than replaying each control. They remain required if the implementation changes those client paths or this baseline exposes a related failure.

## Ordered batch 2. Start, ordinary progress and lifecycle references

Capture the separately admitted native Dashboard active count immediately before this batch’s native Start. Return to the Onboarding-only Operate page and use one ledgered onboarding-start cohort. Native Start selects actual Person/template/date and returns one packet plus three fresh snapshots. Compare all eight parent DTO keys, twelve nested keys, every saved raw field and actual derived expired-Training presence. After Start, inspect the separately admitted Dashboard and require exactly this new saved active packet represented in its scoped count, then return to Onboarding. Active eligibility excludes that Person; a valid duplicate start returns409 with no effects. Do not mutate Training solely to replay D28's accepted current/expired/delete matrix.

Natively toggle checkbox forward/reverse on the same ID. Natively select Paperwork Reviewed, Filed and back to Reviewed; only last stage completes. Save/reload and compare six returned progress keys with actual raw saved work. A client503 progress attempt must show feedback/rollback and real retry, with unchanged provider rows during failure. Lower provider/route checks will separately prove generic500 and deliberate400/404.

Dismiss Cancel first without effects, then native Cancel. Immediately inspect Dashboard again and require that packet removed from its active count, preserving unrelated saved-active witnesses. Return to Onboarding. Reopen with the supported ordinary request, require same IDs/work/notes and both terminal dates cleared, then native Complete with unfinished-step warning (dismiss once before confirming). Read actual incomplete active count and final audit effects separately; the new ordinary list cannot turn Training-derived UI completion into a persisted progress update. Preserve old collision/wait/atomicity proof; no fresh concurrency campaign is required.

```bash
$V seed onboarding-start
$V onboarding-request PAGE orgA PUT onboarding '{"id":"RECORDED_PACKET_UUID","status":"in_progress"}'
$V onboarding-request-state PAGE
$V onboarding-request-restore PAGE
```

## Ordered batch 3. Resource references and retained purpose integration

Use a separate ledgered onboarding-legacy cohort and two temporary native templates. Follow recipe exact-name preparation for Orientation/Paperwork before seeding when legacy matching is being tested. Configure normally Assigns, Re-syncs and Switches. Verify retained matching IDs/work/stages/notes, unmatched inactive work, new IDs and immediate/reloaded order. One explicit definition addition/removal and resync proves current catalog selection meets the retained reconciliation provider. API append one tagged note and compare saved text/time/author. Native Remove one incomplete inactive step; separately valid API deletion of completed inactive work retains the wider API contract. These representative calls are fresh because their policy-reference collaborator changes, even though RPC/conditional-write implementations remain unchanged.

Use a separate dedicated Group-edit cohort if exercising a current Group move. Do not edit the provider-fault/wait cohort's original slug/notes, relax helper predicates or perform privileged restoration. This brief does not require fault/wait cohorts at all unless changed purpose code or a consequential failure invalidates their accepted proof.

```bash
$V seed onboarding-legacy
$V onboarding-request PAGE orgA POST onboarding-resync '{"onboardingId":"RECORDED_PACKET_UUID","newTemplateId":"RECORDED_TEMPLATE_UUID"}'
$V onboarding-request PAGE orgA PUT onboarding-steps '{"action":"addNote","stepId":"RECORDED_STEP_UUID","text":"UNIQUE_MARKER"}'
$V onboarding-request PAGE orgA DELETE onboarding-steps '{"id":"RECORDED_INACTIVE_STEP_UUID"}'
```

## Ordered batch 4. Admission, scope and saved History

Use View, Scoped Configure (Alpha), Empty, foreign B and Switch with other lanes none. Cover readonly controls and actual active/history/bootstrap row sets. A scoped configurator may reconcile an allowed packet but cannot mutate the organization catalog. Ordinary valid mutation bodies establish View denial, Operate configure denial, out-of-Group/Unassigned denial, foreign reference/target denial and foreign Organization admission without effects. Use original/temporary recorded valid IDs and existing policy outcomes; malformed400 is not authority proof. Missing same-Organization resources and deliberate input errors remain separate404/400 cases. Capture whole A/B before/after row sets.

Use onboarding-history for discriminating completed/cancelled/archived/scoped snapshots, saved Training state independent of current matching completion, known/unknown Paperwork stages, retained removed work and notes. Native History disclosure/reload is fresh because listPackets and DTO mapping change. One representative keyboard disclosure check retains accessibility. No note editor, author label or inactive-note rendering is claimed. Switch A→B→A and inspect positive B source witnesses, exact isolation and return state. Reuse unchanged held-response, same-route-disposal and every response-order permutation after byte applicability checks; new ports alone do not invalidate those client algorithms.

## Ordered batch 5. Direct reverse callers and setup

The Dashboard observations are bracketed around Start and Cancel in batch2, before those mutations can obscure their before images. Dashboard consumes listSavedActivePackets after separate Personnel admission. Compare saved packet facts without deriving Training current-state into this saved-only read. This batch handles Getting Started/setup count and starter readiness consume Catalog. Capture their actual current outputs, estimated count behavior separately protected below, and ordinary starter-pack missing-only application/reapply with recorded IDs and no duplicate steps. If no native starter action exists, label this ordinary API proof; do not invent UI execution.

Calendar markers use their separate unchanged purpose RPC. Personnel Add Person and Training references already have accepted D12/D15/D28 ordinary-owned proof. Reuse those scopes at their original candidates and limitations, plus current source hashes. No new Calendar/Training mutation matrix, Personnel create/rank failure, workbook, PDF, Admin support, raw archive, retention cron or 1001-retention seed is required for this ordinary cutover.

## Literal expected DTO key sets

- Template5. id, orgId, name, description, createdAt. createdAt may be null.
- Step10. id, templateId, name, description, stepType, trainingTypeId, stages, sortOrder, organization_id, created_at.
- Parent8. id, personnelId, startedAt, completedAt, cancelledAt, status, steps, templateId.
- Nested progress12. id, onboardingId, stepName, stepType, trainingTypeId, stages, sortOrder, completed, currentStage, notes, templateStepId, active.
- Ordinary saved progress6. id, onboardingId, stepName, stepType, completed, currentStage.

Compare each actual key set exactly as well as submitted/saved values. Raw provider rows have separate5/10/9/14schema column sets plus any actual unknown metadata. Control rows are projections; only the separately frozen full raw reader supplies all-column capture. Never infer raw metadata absence from the DTO or a projected helper result.

## Lower boundary coverage to preserve or add with implementation

This review executes none. New adapters need real installed SDK fake-transport tests against literal independently arranged rows. Cover canonical captured Organization/client without admin acquisition, full five/ten/eight/twelve/six DTO sets, raw extra metadata/null/missing defaults, primary sort plus unique id query order before each range,1001 identity/no duplicate/missing pairs under page-plan drift, empty/null page and later-page error rejection. Keep nested progress sort semantics separate from paged parent ordering. Preserve estimated range0..0/null→zero, one-row existence and strict named starter selection. Preserve PGRST116 null versus other plain errors; trusted app400/403/404 versus spoofed provider status generic500 at the real route. Mutation tests assert saved acknowledgement, same IDs and exact changed/unchanged fields, not replacement method-name spies. Fault-placement cases protect duplicate partial parent insertion, serial reorder partial writes, delete audit-before-dependent cleanup and25-way template clearing. No transaction rewrite or generic interface waiver.

Raw Onboarding archive currently uses unordered ranges. Record this as a source risk, not a newly observed loss. Do not silently copy it into new ordinary adapters. If the implementation's owner/mechanism census or a literal installed-SDK adjacency test reproduces archive loss, group the smallest same-owner fix and existing export-delivery tests. Query-order-only repair need not replay raw/native workbook families automatically; declare the actual affected selection before running.

## Cleanup and acceptance

Finish every seed-dependent read before clean-seeds, which removes all helper cohorts. Restore every network/request/feedback/export hook first. Delete native temporary definitions/templates visibly with actual absence, and remove supported native-created rows through ordinary UI. Cancelled packet history, audits and export effects may remain until whole-provider disposal; list them rather than asserting all table counts equal.

```bash
$V network restore PAGE
$V feedback restore PAGE
$V onboarding-request-restore PAGE
$V clean-seeds
npm run --silent verify:app -- doctor --worker 1
npm run --silent verify:app -- cleanup --worker 1
```

Apply restores only to namespaces armed by this run and retain actual outputs. Compare every original captured raw field/timestamp and every recorded temporary/generated ID's absence or declared residual. Prove owned PID/start/group, ports, five containers, network/volumes and private directory absent while preexisting full configurations/mounts/identities remain. No remote or existing development provider is used. Package sanitized actual raw captures only after closure; fresh inventory/hash acceptance is separate from semantic acceptance. Preserve failed attempts and historical FAIL/UNRUN, runtime, controls and sanitation limits. Stop with sole-worker ownership released before source implementation. Final cutover needs selected current integration, mandatory exact-head CI/build and independent source/expanded acceptance, CLI/hosted gates. #1376 stays open for residual settings/facade obligations; D29/D30 are excluded.
