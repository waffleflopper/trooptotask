import json,pathlib,hashlib,datetime,subprocess
p=pathlib.Path(__file__).parent
load=lambda n:json.loads((p/(n+'.stdout')).read_text())
files=load('retention-before-files')['files']
(p/'recorded-original-file-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
seeds=[load('retention-'+x+'-seed') for x in ['artifact','personnel','onboarding']]
(p/'recorded-original-seeds.json').write_text(json.dumps(seeds,indent=2)+'\n')
identity=json.loads((p/'owned-public-identity-before-cleanup.json').read_text())
for k,v in identity['processes'].items():
 current=pathlib.Path(f"/proc/{v['pid']}/stat").read_text().rsplit(')',1)[1].split()[19]
 assert current==v['start'],k
identity['recordedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'owned-public-identity-final-before-cleanup.json').write_text(json.dumps(identity,indent=2)+'\n')
frozen=json.loads((p/'frozen-inputs.json').read_text());assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==frozen['revision']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for name,digest in frozen['files'].items():assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest,name
out={'passed':True,'revision':frozen['revision'],'unchangedTrackedInputs':len(frozen['files']),'preservedFileManifestCount':len(files),'ownedPidStartChecks':4,'observedAt':identity['recordedAt']}
(p/'pre-cleanup-input-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
